; ModuleID = '/data/home/chh/kernel-benchmark-suite-dataflow-b2b/build/dataflow-corpus/step7/MapAiry/anchor/trial-20/fused.ll'
source_filename = "/home/chh/kernel-benchmark-suite/cases/boost-mapairy/source/kernel.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

@_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 0x3FE428A2F98D728B, double 0x3FE965FEA53D6E3D, double 1.000000e+00, double 0x3FF428A2F98D728B, double 0x3FF965FEA53D6E3D], align 16

; Function Attrs: nofree norecurse nounwind
define protected amdgpu_kernel void @evaluate(double addrspace(1)* nocapture readonly %input.coerce, double addrspace(1)* nocapture %output.coerce, i32 %n) local_unnamed_addr #0 {
entry:
  %0 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %1 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %2 = getelementptr i8, i8 addrspace(4)* %1, i64 4
  %3 = bitcast i8 addrspace(4)* %2 to i16 addrspace(4)*
  %4 = load i16, i16 addrspace(4)* %3, align 4, !range !5, !invariant.load !6
  %5 = zext i16 %4 to i32
  %6 = mul i32 %0, %5
  %7 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !7
  %add = add i32 %6, %7
  %cmp = icmp slt i32 %add, %n
  br i1 %cmp, label %if.end8.i.i, label %if.end

if.end8.i.i:                                      ; preds = %entry
  %idxprom = sext i32 %add to i64
  %arrayidx11 = getelementptr inbounds double, double addrspace(1)* %input.coerce, i64 %idxprom
  %arrayidx.val = load double, double addrspace(1)* %arrayidx11, align 8, !tbaa !8
  %cmp.i3.i.i = fcmp olt double %arrayidx.val, 0.000000e+00
  %cmp1.i.i.i = fcmp ogt double %arrayidx.val, 1.000000e+00
  %or.cond.i.i.i = or i1 %cmp.i3.i.i, %cmp1.i.i.i
  br i1 %or.cond.i.i.i, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %lor.lhs.false2.i.i.i

lor.lhs.false2.i.i.i:                             ; preds = %if.end8.i.i
  %cmp.i.i.i.i.i = fcmp uno double %arrayidx.val, 0.000000e+00
  %cmp.i3.i.i.i.i = fcmp ogt double %arrayidx.val, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i4.i.i = fcmp olt double %arrayidx.val, 0xFFEFFFFFFFFFFFFF
  %lnot.i.i.i.i.not = or i1 %cmp.i3.i.i.i.i, %cmp1.i.i.i4.i.i
  %brmerge = or i1 %cmp.i.i.i.i.i, %lnot.i.i.i.i.not
  br i1 %brmerge, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %if.end14.i.i

if.end14.i.i:                                     ; preds = %lor.lhs.false2.i.i.i
  %cmp.i.i.i = fcmp ogt double %arrayidx.val, 5.000000e-01
  br i1 %cmp.i.i.i, label %if.then.i.i.i, label %cond.false7.i.i.i

if.then.i.i.i:                                    ; preds = %if.end14.i.i
  %sub.i.i.i = fsub double 1.000000e+00, %arrayidx.val
  %cmp.i.i.i.i = fcmp ult double %sub.i.i.i, 2.500000e-01
  br i1 %cmp.i.i.i.i, label %if.else.i.i.i.i, label %if.then.i.i.i.i

if.then.i.i.i.i:                                  ; preds = %if.then.i.i.i
  %sub.i.i.i.i = fadd double %sub.i.i.i, -2.500000e-01
  %mul.i.i.i.i.i.i = fmul double %sub.i.i.i.i, %sub.i.i.i.i
  %mul1.i.i.i.i.i.i = fmul double %mul.i.i.i.i.i.i, 0x404567B47A5D8CA4
  %8 = fsub double 0x405E69E51891A050, %mul1.i.i.i.i.i.i
  %mul5.i.i.i.i.i.i = fmul double %mul.i.i.i.i.i.i, 0x4050AAC38C60A1E3
  %9 = fsub double 0x40548E4AE13E33D8, %mul5.i.i.i.i.i.i
  %mul10.i.i.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %8
  %mul12.i.i.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %9
  %add15.i.i.i.i.i.i = fadd double %mul10.i.i.i.i.i.i, 0xC04860792DC1D02E
  %add18.i.i.i.i.i.i = fadd double %mul12.i.i.i.i.i.i, 0xC0407FAA65922A12
  %mul20.i.i.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %add15.i.i.i.i.i.i
  %mul22.i.i.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %add18.i.i.i.i.i.i
  %add25.i.i.i.i.i.i = fadd double %mul20.i.i.i.i.i.i, 0xC005F196AB7EF904
  %add28.i.i.i.i.i.i = fadd double %mul22.i.i.i.i.i.i, 0x3FDED118296B2018
  %mul30.i.i.i.i.i.i = fmul double %sub.i.i.i.i, %add25.i.i.i.i.i.i
  %add33.i.i.i.i.i.i = fadd double %add28.i.i.i.i.i.i, %mul30.i.i.i.i.i.i
  %mul1.i.i724.i.i.i.i = fmul double %mul.i.i.i.i.i.i, 0x3FF51F0306685285
  %10 = fsub double 0xBFEEB82FAA589934, %mul1.i.i724.i.i.i.i
  %mul5.i.i726.i.i.i.i = fmul double %mul.i.i.i.i.i.i, 0x3FEFDC5AEE1525E4
  %11 = fsub double 0x4043A793DEC20DEB, %mul5.i.i726.i.i.i.i
  %mul10.i.i728.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %10
  %mul12.i.i729.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %11
  %add15.i.i730.i.i.i.i = fadd double %mul10.i.i728.i.i.i.i, 0x401A11C0BB0DC22E
  %add18.i.i731.i.i.i.i = fadd double %mul12.i.i729.i.i.i.i, 0xC04B158FF790C730
  %mul20.i.i732.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %add15.i.i730.i.i.i.i
  %mul22.i.i733.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %add18.i.i731.i.i.i.i
  %add25.i.i734.i.i.i.i = fadd double %mul20.i.i732.i.i.i.i, 0xC02E8C55CA7195EF
  %add28.i.i735.i.i.i.i = fadd double %mul22.i.i733.i.i.i.i, 0x403058D46A8EC004
  %mul30.i.i736.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %add25.i.i734.i.i.i.i
  %mul32.i.i737.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %add28.i.i735.i.i.i.i
  %add35.i.i738.i.i.i.i = fadd double %mul30.i.i736.i.i.i.i, 0x4020675EC4F85A38
  %add38.i.i739.i.i.i.i = fadd double %mul32.i.i737.i.i.i.i, 1.000000e+00
  %mul40.i.i740.i.i.i.i = fmul double %sub.i.i.i.i, %add35.i.i738.i.i.i.i
  %add43.i.i741.i.i.i.i = fadd double %add38.i.i739.i.i.i.i, %mul40.i.i740.i.i.i.i
  %div.i.i.i.i = fdiv double %add33.i.i.i.i.i.i, %add43.i.i741.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else.i.i.i.i:                                  ; preds = %if.then.i.i.i
  %cmp2.i.i.i.i = fcmp ult double %sub.i.i.i, 1.250000e-01
  br i1 %cmp2.i.i.i.i, label %if.else9.i.i.i.i, label %if.then3.i.i.i.i

if.then3.i.i.i.i:                                 ; preds = %if.else.i.i.i.i
  %sub5.i.i.i.i = fadd double %sub.i.i.i, -1.250000e-01
  %mul.i.i712.i.i.i.i = fmul double %sub5.i.i.i.i, %sub5.i.i.i.i
  %mul1.i.i713.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, 0x409819CEF5B4E6C7
  %add.i.i714.i.i.i.i = fadd double %mul1.i.i713.i.i.i.i, 0xC096FC492E087B38
  %mul5.i.i715.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, 0x4051B7FD7FEEB259
  %12 = fsub double 0xC07E56261CB553E9, %mul5.i.i715.i.i.i.i
  %mul10.i.i717.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, %add.i.i714.i.i.i.i
  %mul12.i.i718.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, %12
  %add15.i.i719.i.i.i.i = fadd double %mul10.i.i717.i.i.i.i, 0x4036AD73494335DA
  %add18.i.i720.i.i.i.i = fadd double %mul12.i.i718.i.i.i.i, 0x4034FFCB850049DF
  %mul20.i.i721.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, %add15.i.i719.i.i.i.i
  %add23.i.i.i.i.i.i = fadd double %mul20.i.i721.i.i.i.i, 0x3FFB3E8B8B7EC8F9
  %mul25.i.i.i.i.i.i = fmul double %sub5.i.i.i.i, %add18.i.i720.i.i.i.i
  %add28.i.i722.i.i.i.i = fadd double %mul25.i.i.i.i.i.i, %add23.i.i.i.i.i.i
  %mul1.i.i698.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, 0x406113A5A6902AC1
  %add.i.i699.i.i.i.i = fadd double %mul1.i.i698.i.i.i.i, 0xC083E59B9D34A0F1
  %mul5.i.i700.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, 0x4071AEC837B9190D
  %13 = fsub double 0x406A5A0FD2D4B901, %mul5.i.i700.i.i.i.i
  %mul10.i.i702.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, %add.i.i699.i.i.i.i
  %mul12.i.i703.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, %13
  %add15.i.i704.i.i.i.i = fadd double %mul10.i.i702.i.i.i.i, 0x407BA4300BFE5087
  %add18.i.i705.i.i.i.i = fadd double %mul12.i.i703.i.i.i.i, 0x4063AA2F5D62DCD3
  %mul20.i.i706.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, %add15.i.i704.i.i.i.i
  %mul22.i.i707.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, %add18.i.i705.i.i.i.i
  %add25.i.i708.i.i.i.i = fadd double %mul20.i.i706.i.i.i.i, 0x40354F2A1256B431
  %add28.i.i709.i.i.i.i = fadd double %mul22.i.i707.i.i.i.i, 1.000000e+00
  %mul30.i.i710.i.i.i.i = fmul double %sub5.i.i.i.i, %add25.i.i708.i.i.i.i
  %add33.i.i711.i.i.i.i = fadd double %add28.i.i709.i.i.i.i, %mul30.i.i710.i.i.i.i
  %div8.i.i.i.i = fdiv double %add28.i.i722.i.i.i.i, %add33.i.i711.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else9.i.i.i.i:                                 ; preds = %if.else.i.i.i.i
  %14 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %sub.i.i.i) #3
  %15 = add nsw i32 %14, -1
  %16 = fcmp uno double %sub.i.i.i, 0.000000e+00
  %17 = tail call double @llvm.fabs.f64(double %sub.i.i.i) #4
  %18 = fcmp oeq double %17, 0x7FF0000000000000
  %19 = or i1 %16, %18
  %20 = select i1 %19, i32 2147483647, i32 %15
  %21 = fcmp oeq double %sub.i.i.i, 0.000000e+00
  %22 = select i1 %21, i32 -2147483648, i32 %20
  %cmp11.i.i.i.i = icmp sgt i32 %22, -5
  br i1 %cmp11.i.i.i.i, label %if.then12.i.i.i.i, label %if.else21.i.i.i.i

if.then12.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %23 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 3) #3
  %24 = tail call double @llvm.amdgcn.frexp.mant.f64(double %23) #3
  %25 = fcmp olt double %24, 0x3FE5555555555555
  %26 = zext i1 %25 to i32
  %27 = tail call double @llvm.amdgcn.ldexp.f64(double %24, i32 %26) #3
  %28 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %23) #3
  %29 = sub nsw i32 %28, %26
  %30 = fadd double %27, -1.000000e+00
  %31 = fadd double %27, 1.000000e+00
  %32 = fsub double %31, %27
  %33 = fsub double %31, %32
  %34 = fsub double %27, %33
  %35 = fsub double 1.000000e+00, %32
  %36 = fadd double %35, %34
  %37 = tail call double @llvm.amdgcn.rcp.f64(double %31) #3
  %38 = fneg double %31
  %39 = tail call double @llvm.fma.f64(double %38, double %37, double 1.000000e+00) #3
  %40 = tail call double @llvm.fma.f64(double %39, double %37, double %37) #3
  %41 = tail call double @llvm.fma.f64(double %38, double %40, double 1.000000e+00) #3
  %42 = tail call double @llvm.fma.f64(double %41, double %40, double %40) #3
  %43 = fmul double %30, %42
  %44 = fmul double %31, %43
  %45 = fneg double %44
  %46 = tail call double @llvm.fma.f64(double %43, double %31, double %45) #3
  %47 = tail call double @llvm.fma.f64(double %43, double %36, double %46) #3
  %48 = fadd double %44, %47
  %49 = fsub double %48, %44
  %50 = fsub double %47, %49
  %51 = fsub double %30, %48
  %52 = fsub double %30, %51
  %53 = fsub double %52, %48
  %54 = fsub double %53, %50
  %55 = fadd double %51, %54
  %56 = fmul double %42, %55
  %57 = fadd double %43, %56
  %58 = fsub double %57, %43
  %59 = fsub double %56, %58
  %60 = fmul double %57, %57
  %61 = fneg double %60
  %62 = tail call double @llvm.fma.f64(double %57, double %57, double %61) #3
  %63 = fmul double %59, 2.000000e+00
  %64 = tail call double @llvm.fma.f64(double %57, double %63, double %62) #3
  %65 = tail call double @llvm.fma.f64(double %59, double %59, double %64) #3
  %66 = fadd double %60, %65
  %67 = fsub double %66, %60
  %68 = fsub double %65, %67
  %69 = tail call double @llvm.fma.f64(double %66, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %70 = tail call double @llvm.fma.f64(double %66, double %69, double 0x3FC7474DD7F4DF2E) #3
  %71 = tail call double @llvm.fma.f64(double %66, double %70, double 0x3FCC71C016291751) #3
  %72 = tail call double @llvm.fma.f64(double %66, double %71, double 0x3FD249249B27ACF1) #3
  %73 = tail call double @llvm.fma.f64(double %66, double %72, double 0x3FD99999998EF7B6) #3
  %74 = tail call double @llvm.fma.f64(double %66, double %73, double 0x3FE5555555555780) #3
  %75 = tail call double @llvm.amdgcn.ldexp.f64(double %57, i32 1) #3
  %76 = tail call double @llvm.amdgcn.ldexp.f64(double %59, i32 1) #3
  %77 = fmul double %57, %66
  %78 = fneg double %77
  %79 = tail call double @llvm.fma.f64(double %57, double %66, double %78) #3
  %80 = fmul double %59, %66
  %81 = tail call double @llvm.fma.f64(double %57, double %68, double %80) #3
  %82 = fadd double %79, %81
  %83 = fadd double %77, %82
  %84 = fsub double %83, %77
  %85 = fsub double %82, %84
  %86 = fmul double %83, %74
  %87 = fneg double %86
  %88 = tail call double @llvm.fma.f64(double %83, double %74, double %87) #3
  %89 = tail call double @llvm.fma.f64(double %85, double %74, double %88) #3
  %90 = fadd double %86, %89
  %91 = fsub double %90, %86
  %92 = fsub double %89, %91
  %93 = fadd double %75, %90
  %94 = fsub double %93, %75
  %95 = fsub double %93, %94
  %96 = fsub double %75, %95
  %97 = fsub double %90, %94
  %98 = fadd double %97, %96
  %99 = fadd double %76, %92
  %100 = fsub double %99, %76
  %101 = fsub double %99, %100
  %102 = fsub double %76, %101
  %103 = fsub double %92, %100
  %104 = fadd double %103, %102
  %105 = fadd double %99, %98
  %106 = fadd double %93, %105
  %107 = fsub double %106, %93
  %108 = fsub double %105, %107
  %109 = fadd double %104, %108
  %110 = fadd double %106, %109
  %111 = fsub double %110, %106
  %112 = fsub double %109, %111
  %113 = sitofp i32 %29 to double
  %114 = fmul double %110, 0x3FF71547652B82FE
  %115 = fneg double %114
  %116 = fmul double %110, 0x3C7777D0FFDA0D24
  %117 = insertelement <2 x double> undef, double %110, i32 0
  %118 = insertelement <2 x double> %117, double %112, i32 1
  %119 = insertelement <2 x double> undef, double %115, i32 0
  %120 = insertelement <2 x double> %119, double %116, i32 1
  %121 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %118, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %120) #3
  %122 = extractelement <2 x double> %121, i32 0
  %123 = extractelement <2 x double> %121, i32 1
  %124 = fadd double %122, %123
  %125 = fadd double %114, %124
  %126 = fsub double %125, %114
  %127 = fsub double %124, %126
  %128 = fadd double %125, %113
  %129 = fsub double %128, %113
  %130 = fsub double %129, %128
  %131 = fadd double %130, %113
  %132 = fsub double %125, %129
  %133 = fadd double %132, %131
  %134 = fadd double %127, %133
  %135 = fadd double %128, %134
  %136 = tail call double @llvm.fabs.f64(double %23) #4
  %137 = fcmp oeq double %136, 0x7FF0000000000000
  %138 = select i1 %137, double %23, double %135
  %139 = fcmp olt double %23, 0.000000e+00
  %140 = select i1 %139, double 0x7FF8000000000000, double %138
  %141 = fcmp oeq double %23, 0.000000e+00
  %142 = select i1 %141, double 0xFFF0000000000000, double %140
  %mul.i.i682.i.i.i.i = fmul double %142, %142
  %mul1.i.i683.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3ED3E1F985CBB733
  %add.i.i684.i.i.i.i = fadd double %mul1.i.i683.i.i.i.i, 0x3F385DA443F57737
  %mul5.i.i685.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F24E9382EAABDBB
  %add7.i.i686.i.i.i.i = fadd double %mul5.i.i685.i.i.i.i, 0x3F77E2A342AA4E3B
  %mul10.i.i687.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i684.i.i.i.i
  %mul12.i.i688.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i686.i.i.i.i
  %add15.i.i689.i.i.i.i = fadd double %mul10.i.i687.i.i.i.i, 0x3F9808F2B640E69B
  %add18.i.i690.i.i.i.i = fadd double %mul12.i.i688.i.i.i.i, 0x3F9DD5C523A6CF6D
  %mul20.i.i691.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i689.i.i.i.i
  %mul22.i.i692.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i690.i.i.i.i
  %add25.i.i693.i.i.i.i = fadd double %mul20.i.i691.i.i.i.i, 0x3FD3E6D375851610
  %add28.i.i694.i.i.i.i = fadd double %mul22.i.i692.i.i.i.i, 0x3FDB3E8B8B7EC8FA
  %143 = fmul double %142, %add25.i.i693.i.i.i.i
  %add33.i.i696.i.i.i.i = fsub double %add28.i.i694.i.i.i.i, %143
  %mul1.i.i668.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3EF03AD80F271435
  %add.i.i669.i.i.i.i = fadd double %mul1.i.i668.i.i.i.i, 0x3F577B23357A1929
  %mul5.i.i670.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F27C5B13F4BAFF2
  %add7.i.i671.i.i.i.i = fadd double %mul5.i.i670.i.i.i.i, 0x3F825620F70E4E86
  %mul10.i.i672.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i669.i.i.i.i
  %mul12.i.i673.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i671.i.i.i.i
  %add15.i.i674.i.i.i.i = fadd double %mul10.i.i672.i.i.i.i, 0x3FA38976FFA62DF3
  %add18.i.i675.i.i.i.i = fadd double %mul12.i.i673.i.i.i.i, 0x3FBACD3553111974
  %mul20.i.i676.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i674.i.i.i.i
  %mul22.i.i677.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i675.i.i.i.i
  %add25.i.i678.i.i.i.i = fadd double %mul20.i.i676.i.i.i.i, 0x3FDA8C1A7A09CF75
  %add28.i.i679.i.i.i.i = fadd double %mul22.i.i677.i.i.i.i, 1.000000e+00
  %144 = fmul double %142, %add25.i.i678.i.i.i.i
  %add33.i.i681.i.i.i.i = fsub double %add28.i.i679.i.i.i.i, %144
  %mul.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i590.i.i.i.i = fcmp ogt double %mul.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i591.i.i.i.i = fcmp oeq double %mul.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i592.i.i.i.i = or i1 %cmp.i.i.i.i590.i.i.i.i, %cmp.i.i.i591.i.i.i.i
  br i1 %or.cond.i.i.i592.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end.i.i.i594.i.i.i.i

if.end.i.i.i594.i.i.i.i:                          ; preds = %if.then12.i.i.i.i
  %cmp.i.i.i.i.i593.i.i.i.i = fcmp uno double %mul.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i593.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end7.i.i.i620.i.i.i.i

if.end7.i.i.i620.i.i.i.i:                         ; preds = %if.end.i.i.i594.i.i.i.i
  %145 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul.i.i.i.i) #3
  %146 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul.i.i.i.i) #3
  %147 = tail call i1 @llvm.amdgcn.class.f64(double %mul.i.i.i.i, i32 519) #3
  %148 = select i1 %147, i32 0, i32 %145
  %149 = select i1 %147, double %mul.i.i.i.i, double %146
  %mul.i.i.i.i.i606.i.i.i.i = fmul double %149, %149
  %mul1.i.i.i.i.i607.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i608.i.i.i.i = fadd double %mul1.i.i.i.i.i607.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i609.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FE479D17050CA47
  %150 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i609.i.i.i.i
  %mul10.i.i.i.i.i611.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %add.i.i.i.i.i608.i.i.i.i
  %mul12.i.i.i.i.i612.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %150
  %add15.i.i.i.i.i613.i.i.i.i = fadd double %mul10.i.i.i.i.i611.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i614.i.i.i.i = fadd double %mul12.i.i.i.i.i612.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i615.i.i.i.i = fmul double %149, %add15.i.i.i.i.i613.i.i.i.i
  %add23.i.i.i.i.i616.i.i.i.i = fadd double %add18.i.i.i.i.i614.i.i.i.i, %mul20.i.i.i.i.i615.i.i.i.i
  %.frozen = freeze i32 %148
  %div.i.i.i617.i.i.i.i = sdiv i32 %.frozen, 3
  %151 = sub nsw i32 0, %div.i.i.i617.i.i.i.i
  %152 = call i32 @llvm.abs.i32(i32 %div.i.i.i617.i.i.i.i, i1 true)
  %cmp11.i.i.i619.i.i.i.i = icmp ult i32 %152, 64
  br i1 %cmp11.i.i.i619.i.i.i.i, label %if.then12.i.i.i622.i.i.i.i, label %if.else21.i.i.i634.i.i.i.i

if.then12.i.i.i622.i.i.i.i:                       ; preds = %if.end7.i.i.i620.i.i.i.i
  %cmp13.i.i.i621.i.i.i.i = icmp sgt i32 %148, 2
  br i1 %cmp13.i.i.i621.i.i.i.i, label %if.then14.i.i.i627.i.i.i.i, label %if.else.i.i.i633.i.i.i.i

if.then14.i.i.i627.i.i.i.i:                       ; preds = %if.then12.i.i.i622.i.i.i.i
  %sh_prom.i.i.i623.i.i.i.i = zext i32 %div.i.i.i617.i.i.i.i to i64
  %shl.i.i.i624.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i623.i.i.i.i
  %conv.i.i.i625.i.i.i.i = uitofp i64 %shl.i.i.i624.i.i.i.i to double
  %mul.i.i.i626.i.i.i.i = fmul double %add23.i.i.i.i.i616.i.i.i.i, %conv.i.i.i625.i.i.i.i
  br label %if.end23.i.i.i640.i.i.i.i

if.else.i.i.i633.i.i.i.i:                         ; preds = %if.then12.i.i.i622.i.i.i.i
  %sh_prom16.i.i.i629.i.i.i.i = zext i32 %151 to i64
  %shl17.i.i.i630.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i629.i.i.i.i
  %conv18.i.i.i631.i.i.i.i = uitofp i64 %shl17.i.i.i630.i.i.i.i to double
  %div19.i.i.i632.i.i.i.i = fdiv double %add23.i.i.i.i.i616.i.i.i.i, %conv18.i.i.i631.i.i.i.i
  br label %if.end23.i.i.i640.i.i.i.i

if.else21.i.i.i634.i.i.i.i:                       ; preds = %if.end7.i.i.i620.i.i.i.i
  %153 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i616.i.i.i.i, i32 %div.i.i.i617.i.i.i.i) #3
  br label %if.end23.i.i.i640.i.i.i.i

if.end23.i.i.i640.i.i.i.i:                        ; preds = %if.else21.i.i.i634.i.i.i.i, %if.else.i.i.i633.i.i.i.i, %if.then14.i.i.i627.i.i.i.i
  %guess.i.i.i589.i.i.i.i.0 = phi double [ %mul.i.i.i626.i.i.i.i, %if.then14.i.i.i627.i.i.i.i ], [ %div19.i.i.i632.i.i.i.i, %if.else.i.i.i633.i.i.i.i ], [ %153, %if.else21.i.i.i634.i.i.i.i ]
  %.neg6 = mul nsw i32 %div.i.i.i617.i.i.i.i, -3
  %rem.i.i.i635.i.i.i.i.decomposed = add i32 %.frozen, 2
  %add.i.i.i636.i.i.i.i = add i32 %rem.i.i.i635.i.i.i.i.decomposed, %.neg6
  %154 = zext i32 %add.i.i.i636.i.i.i.i to i64
  %arrayidx1.i.i.i637.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %154
  %155 = load double, double addrspace(4)* %arrayidx1.i.i.i637.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i638.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.0, %155
  %cmp26.i.i.i639.i.i.i.i = icmp slt i32 %148, 1021
  br i1 %cmp26.i.i.i639.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i

do.body.i.i.i651.i.i.i.i:                         ; preds = %do.body.i.i.i651.i.i.i.i, %if.end23.i.i.i640.i.i.i.i
  %guess.i.i.i589.i.i.i.i.1 = phi double [ %mul24.i.i.i638.i.i.i.i, %if.end23.i.i.i640.i.i.i.i ], [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ]
  %mul28.i.i.i641.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %guess.i.i.i589.i.i.i.i.1
  %mul29.i.i.i642.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %mul28.i.i.i641.i.i.i.i
  %add30.i.i.i643.i.i.i.i = fadd double %mul.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add31.i.i.i644.i.i.i.i = fadd double %mul.i.i.i.i, %add30.i.i.i643.i.i.i.i
  %add32.i.i.i645.i.i.i.i = fadd double %mul29.i.i.i642.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add33.i.i.i646.i.i.i.i = fadd double %mul.i.i.i.i, %add32.i.i.i645.i.i.i.i
  %div34.i.i.i647.i.i.i.i = fdiv double %add31.i.i.i644.i.i.i.i, %add33.i.i.i646.i.i.i.i
  %mul35.i.i.i648.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %div34.i.i.i647.i.i.i.i
  %sub36.i.i.i649.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i647.i.i.i.i
  %156 = tail call double @llvm.fabs.f64(double %sub36.i.i.i649.i.i.i.i) #3
  %cmp38.i.i.i650.i.i.i.i = fcmp ogt double %156, 0x3EC0000000000000
  br i1 %cmp38.i.i.i650.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

do.body40.i.i.i662.i.i.i.i:                       ; preds = %do.body40.i.i.i662.i.i.i.i, %if.end23.i.i.i640.i.i.i.i
  %guess.i.i.i589.i.i.i.i.2 = phi double [ %mul24.i.i.i638.i.i.i.i, %if.end23.i.i.i640.i.i.i.i ], [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ]
  %mul41.i.i.i652.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, %guess.i.i.i589.i.i.i.i.2
  %div42.i.i.i653.i.i.i.i = fdiv double %mul.i.i.i.i, %guess.i.i.i589.i.i.i.i.2
  %sub43.i.i.i654.i.i.i.i = fsub double %mul41.i.i.i652.i.i.i.i, %div42.i.i.i653.i.i.i.i
  %mul44.i.i.i655.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i656.i.i.i.i = fdiv double %mul.i.i.i.i, %mul41.i.i.i652.i.i.i.i
  %add46.i.i.i657.i.i.i.i = fadd double %mul44.i.i.i655.i.i.i.i, %div45.i.i.i656.i.i.i.i
  %div47.i.i.i658.i.i.i.i = fdiv double %sub43.i.i.i654.i.i.i.i, %add46.i.i.i657.i.i.i.i
  %sub48.i.i.i659.i.i.i.i = fsub double %guess.i.i.i589.i.i.i.i.2, %div47.i.i.i658.i.i.i.i
  %mul50.i.i.i660.i.i.i.i = fmul double %sub48.i.i.i659.i.i.i.i, 0x3EC0000000000000
  %157 = tail call double @llvm.fabs.f64(double %div47.i.i.i658.i.i.i.i) #3
  %cmp52.i.i.i661.i.i.i.i = fcmp olt double %mul50.i.i.i660.i.i.i.i, %157
  br i1 %cmp52.i.i.i661.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i: ; preds = %do.body40.i.i.i662.i.i.i.i, %do.body.i.i.i651.i.i.i.i, %if.end.i.i.i594.i.i.i.i, %if.then12.i.i.i.i
  %retval.0.i.i.i665.i.i.i.i = phi double [ %mul.i.i.i.i, %if.then12.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i594.i.i.i.i ], [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ], [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ]
  %mul19.i.i.i.i = fmul double %add33.i.i681.i.i.i.i, %retval.0.i.i.i665.i.i.i.i
  %div20.i.i.i.i = fdiv double %add33.i.i696.i.i.i.i, %mul19.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else21.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %cmp23.i.i.i.i = icmp sgt i32 %22, -9
  br i1 %cmp23.i.i.i.i, label %if.then24.i.i.i.i, label %if.else35.i.i.i.i

if.then24.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %158 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 4) #3
  %159 = tail call double @llvm.amdgcn.frexp.mant.f64(double %158) #3
  %160 = fcmp olt double %159, 0x3FE5555555555555
  %161 = zext i1 %160 to i32
  %162 = tail call double @llvm.amdgcn.ldexp.f64(double %159, i32 %161) #3
  %163 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %158) #3
  %164 = sub nsw i32 %163, %161
  %165 = fadd double %162, -1.000000e+00
  %166 = fadd double %162, 1.000000e+00
  %167 = fsub double %166, %162
  %168 = fsub double %166, %167
  %169 = fsub double %162, %168
  %170 = fsub double 1.000000e+00, %167
  %171 = fadd double %170, %169
  %172 = tail call double @llvm.amdgcn.rcp.f64(double %166) #3
  %173 = fneg double %166
  %174 = tail call double @llvm.fma.f64(double %173, double %172, double 1.000000e+00) #3
  %175 = tail call double @llvm.fma.f64(double %174, double %172, double %172) #3
  %176 = tail call double @llvm.fma.f64(double %173, double %175, double 1.000000e+00) #3
  %177 = tail call double @llvm.fma.f64(double %176, double %175, double %175) #3
  %178 = fmul double %165, %177
  %179 = fmul double %166, %178
  %180 = fneg double %179
  %181 = tail call double @llvm.fma.f64(double %178, double %166, double %180) #3
  %182 = tail call double @llvm.fma.f64(double %178, double %171, double %181) #3
  %183 = fadd double %179, %182
  %184 = fsub double %183, %179
  %185 = fsub double %182, %184
  %186 = fsub double %165, %183
  %187 = fsub double %165, %186
  %188 = fsub double %187, %183
  %189 = fsub double %188, %185
  %190 = fadd double %186, %189
  %191 = fmul double %177, %190
  %192 = fadd double %178, %191
  %193 = fsub double %192, %178
  %194 = fsub double %191, %193
  %195 = fmul double %192, %192
  %196 = fneg double %195
  %197 = tail call double @llvm.fma.f64(double %192, double %192, double %196) #3
  %198 = fmul double %194, 2.000000e+00
  %199 = tail call double @llvm.fma.f64(double %192, double %198, double %197) #3
  %200 = tail call double @llvm.fma.f64(double %194, double %194, double %199) #3
  %201 = fadd double %195, %200
  %202 = fsub double %201, %195
  %203 = fsub double %200, %202
  %204 = tail call double @llvm.fma.f64(double %201, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %205 = tail call double @llvm.fma.f64(double %201, double %204, double 0x3FC7474DD7F4DF2E) #3
  %206 = tail call double @llvm.fma.f64(double %201, double %205, double 0x3FCC71C016291751) #3
  %207 = tail call double @llvm.fma.f64(double %201, double %206, double 0x3FD249249B27ACF1) #3
  %208 = tail call double @llvm.fma.f64(double %201, double %207, double 0x3FD99999998EF7B6) #3
  %209 = tail call double @llvm.fma.f64(double %201, double %208, double 0x3FE5555555555780) #3
  %210 = tail call double @llvm.amdgcn.ldexp.f64(double %192, i32 1) #3
  %211 = tail call double @llvm.amdgcn.ldexp.f64(double %194, i32 1) #3
  %212 = fmul double %192, %201
  %213 = fneg double %212
  %214 = tail call double @llvm.fma.f64(double %192, double %201, double %213) #3
  %215 = fmul double %194, %201
  %216 = tail call double @llvm.fma.f64(double %192, double %203, double %215) #3
  %217 = fadd double %214, %216
  %218 = fadd double %212, %217
  %219 = fsub double %218, %212
  %220 = fsub double %217, %219
  %221 = fmul double %218, %209
  %222 = fneg double %221
  %223 = tail call double @llvm.fma.f64(double %218, double %209, double %222) #3
  %224 = tail call double @llvm.fma.f64(double %220, double %209, double %223) #3
  %225 = fadd double %221, %224
  %226 = fsub double %225, %221
  %227 = fsub double %224, %226
  %228 = fadd double %210, %225
  %229 = fsub double %228, %210
  %230 = fsub double %228, %229
  %231 = fsub double %210, %230
  %232 = fsub double %225, %229
  %233 = fadd double %232, %231
  %234 = fadd double %211, %227
  %235 = fsub double %234, %211
  %236 = fsub double %234, %235
  %237 = fsub double %211, %236
  %238 = fsub double %227, %235
  %239 = fadd double %238, %237
  %240 = fadd double %234, %233
  %241 = fadd double %228, %240
  %242 = fsub double %241, %228
  %243 = fsub double %240, %242
  %244 = fadd double %239, %243
  %245 = fadd double %241, %244
  %246 = fsub double %245, %241
  %247 = fsub double %244, %246
  %248 = sitofp i32 %164 to double
  %249 = fmul double %245, 0x3FF71547652B82FE
  %250 = fneg double %249
  %251 = fmul double %245, 0x3C7777D0FFDA0D24
  %252 = insertelement <2 x double> undef, double %245, i32 0
  %253 = insertelement <2 x double> %252, double %247, i32 1
  %254 = insertelement <2 x double> undef, double %250, i32 0
  %255 = insertelement <2 x double> %254, double %251, i32 1
  %256 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %253, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %255) #3
  %257 = extractelement <2 x double> %256, i32 0
  %258 = extractelement <2 x double> %256, i32 1
  %259 = fadd double %257, %258
  %260 = fadd double %249, %259
  %261 = fsub double %260, %249
  %262 = fsub double %259, %261
  %263 = fadd double %260, %248
  %264 = fsub double %263, %248
  %265 = fsub double %264, %263
  %266 = fadd double %265, %248
  %267 = fsub double %260, %264
  %268 = fadd double %267, %266
  %269 = fadd double %262, %268
  %270 = fadd double %263, %269
  %271 = tail call double @llvm.fabs.f64(double %158) #4
  %272 = fcmp oeq double %271, 0x7FF0000000000000
  %273 = select i1 %272, double %158, double %270
  %274 = fcmp olt double %158, 0.000000e+00
  %275 = select i1 %274, double 0x7FF8000000000000, double %273
  %276 = fcmp oeq double %158, 0.000000e+00
  %277 = select i1 %276, double 0xFFF0000000000000, double %275
  %mul.i.i565.i.i.i.i = fmul double %277, %277
  %mul1.i.i566.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3E919A5BE1262808
  %add.i.i567.i.i.i.i = fadd double %mul1.i.i566.i.i.i.i, 0x3F07A5175B4661FC
  %mul5.i.i568.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3ED3058F91E15D9E
  %add7.i.i569.i.i.i.i = fadd double %mul5.i.i568.i.i.i.i, 0x3F360A6A52B6CEE1
  %mul10.i.i570.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i567.i.i.i.i
  %mul12.i.i571.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i569.i.i.i.i
  %add15.i.i572.i.i.i.i = fadd double %mul10.i.i570.i.i.i.i, 0x3F5C5B8FA36BAEC3
  %add18.i.i573.i.i.i.i = fadd double %mul12.i.i571.i.i.i.i, 0x3F80EDCAE3A5BFEE
  %mul20.i.i574.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i572.i.i.i.i
  %mul22.i.i575.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i573.i.i.i.i
  %add25.i.i576.i.i.i.i = fadd double %mul20.i.i574.i.i.i.i, 0x3F9A5E78F653B833
  %add28.i.i577.i.i.i.i = fadd double %mul22.i.i575.i.i.i.i, 0x3FB5AC2080A26513
  %mul30.i.i578.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i576.i.i.i.i
  %mul32.i.i579.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i577.i.i.i.i
  %add35.i.i580.i.i.i.i = fadd double %mul30.i.i578.i.i.i.i, 0x3FC65686F7A4EE22
  %add38.i.i581.i.i.i.i = fadd double %mul32.i.i579.i.i.i.i, 0x3FD3F40EF6582604
  %mul40.i.i582.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i580.i.i.i.i
  %add43.i.i583.i.i.i.i = fadd double %mul40.i.i582.i.i.i.i, 0x3FE03C236600AD0B
  %278 = fmul double %277, %add38.i.i581.i.i.i.i
  %add48.i.i585.i.i.i.i = fsub double %add43.i.i583.i.i.i.i, %278
  %mul1.i.i547.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EA0457562E8B20F
  %add.i.i548.i.i.i.i = fadd double %mul1.i.i547.i.i.i.i, 0x3F16154BBE28AEB9
  %mul5.i.i549.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EE174949F46ED05
  %add7.i.i550.i.i.i.i = fadd double %mul5.i.i549.i.i.i.i, 0x3F43E3B25F7FFBED
  %mul10.i.i551.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i548.i.i.i.i
  %mul12.i.i552.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i550.i.i.i.i
  %add15.i.i553.i.i.i.i = fadd double %mul10.i.i551.i.i.i.i, 0x3F6B2284D418EE28
  %add18.i.i554.i.i.i.i = fadd double %mul12.i.i552.i.i.i.i, 0x3F8DC663E91E38DD
  %mul20.i.i555.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i553.i.i.i.i
  %mul22.i.i556.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i554.i.i.i.i
  %add25.i.i557.i.i.i.i = fadd double %mul20.i.i555.i.i.i.i, 0x3FA9F261B3019817
  %add28.i.i558.i.i.i.i = fadd double %mul22.i.i556.i.i.i.i, 0x3FC29CC24A62017B
  %mul30.i.i559.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i557.i.i.i.i
  %mul32.i.i560.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i558.i.i.i.i
  %add35.i.i561.i.i.i.i = fadd double %mul30.i.i559.i.i.i.i, 0x3FD660DD0F65AD11
  %add38.i.i562.i.i.i.i = fadd double %mul32.i.i560.i.i.i.i, 0x3FE0E738E979F959
  %mul40.i.i563.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i561.i.i.i.i
  %add43.i.i564.i.i.i.i = fadd double %mul40.i.i563.i.i.i.i, 1.000000e+00
  %279 = fmul double %277, %add38.i.i562.i.i.i.i
  %add48.i.i.i.i.i.i = fsub double %add43.i.i564.i.i.i.i, %279
  %mul31.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i469.i.i.i.i = fcmp ogt double %mul31.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i470.i.i.i.i = fcmp oeq double %mul31.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i471.i.i.i.i = or i1 %cmp.i.i.i.i469.i.i.i.i, %cmp.i.i.i470.i.i.i.i
  br i1 %or.cond.i.i.i471.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end.i.i.i473.i.i.i.i

if.end.i.i.i473.i.i.i.i:                          ; preds = %if.then24.i.i.i.i
  %cmp.i.i.i.i.i472.i.i.i.i = fcmp uno double %mul31.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i472.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end7.i.i.i499.i.i.i.i

if.end7.i.i.i499.i.i.i.i:                         ; preds = %if.end.i.i.i473.i.i.i.i
  %280 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul31.i.i.i.i) #3
  %281 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul31.i.i.i.i) #3
  %282 = tail call i1 @llvm.amdgcn.class.f64(double %mul31.i.i.i.i, i32 519) #3
  %283 = select i1 %282, i32 0, i32 %280
  %284 = select i1 %282, double %mul31.i.i.i.i, double %281
  %mul.i.i.i.i.i485.i.i.i.i = fmul double %284, %284
  %mul1.i.i.i.i.i486.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i487.i.i.i.i = fadd double %mul1.i.i.i.i.i486.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i488.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FE479D17050CA47
  %285 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i488.i.i.i.i
  %mul10.i.i.i.i.i490.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %add.i.i.i.i.i487.i.i.i.i
  %mul12.i.i.i.i.i491.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %285
  %add15.i.i.i.i.i492.i.i.i.i = fadd double %mul10.i.i.i.i.i490.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i493.i.i.i.i = fadd double %mul12.i.i.i.i.i491.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i494.i.i.i.i = fmul double %284, %add15.i.i.i.i.i492.i.i.i.i
  %add23.i.i.i.i.i495.i.i.i.i = fadd double %add18.i.i.i.i.i493.i.i.i.i, %mul20.i.i.i.i.i494.i.i.i.i
  %.frozen209 = freeze i32 %283
  %div.i.i.i496.i.i.i.i = sdiv i32 %.frozen209, 3
  %286 = sub nsw i32 0, %div.i.i.i496.i.i.i.i
  %287 = call i32 @llvm.abs.i32(i32 %div.i.i.i496.i.i.i.i, i1 true)
  %cmp11.i.i.i498.i.i.i.i = icmp ult i32 %287, 64
  br i1 %cmp11.i.i.i498.i.i.i.i, label %if.then12.i.i.i501.i.i.i.i, label %if.else21.i.i.i513.i.i.i.i

if.then12.i.i.i501.i.i.i.i:                       ; preds = %if.end7.i.i.i499.i.i.i.i
  %cmp13.i.i.i500.i.i.i.i = icmp sgt i32 %283, 2
  br i1 %cmp13.i.i.i500.i.i.i.i, label %if.then14.i.i.i506.i.i.i.i, label %if.else.i.i.i512.i.i.i.i

if.then14.i.i.i506.i.i.i.i:                       ; preds = %if.then12.i.i.i501.i.i.i.i
  %sh_prom.i.i.i502.i.i.i.i = zext i32 %div.i.i.i496.i.i.i.i to i64
  %shl.i.i.i503.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i502.i.i.i.i
  %conv.i.i.i504.i.i.i.i = uitofp i64 %shl.i.i.i503.i.i.i.i to double
  %mul.i.i.i505.i.i.i.i = fmul double %add23.i.i.i.i.i495.i.i.i.i, %conv.i.i.i504.i.i.i.i
  br label %if.end23.i.i.i519.i.i.i.i

if.else.i.i.i512.i.i.i.i:                         ; preds = %if.then12.i.i.i501.i.i.i.i
  %sh_prom16.i.i.i508.i.i.i.i = zext i32 %286 to i64
  %shl17.i.i.i509.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i508.i.i.i.i
  %conv18.i.i.i510.i.i.i.i = uitofp i64 %shl17.i.i.i509.i.i.i.i to double
  %div19.i.i.i511.i.i.i.i = fdiv double %add23.i.i.i.i.i495.i.i.i.i, %conv18.i.i.i510.i.i.i.i
  br label %if.end23.i.i.i519.i.i.i.i

if.else21.i.i.i513.i.i.i.i:                       ; preds = %if.end7.i.i.i499.i.i.i.i
  %288 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i495.i.i.i.i, i32 %div.i.i.i496.i.i.i.i) #3
  br label %if.end23.i.i.i519.i.i.i.i

if.end23.i.i.i519.i.i.i.i:                        ; preds = %if.else21.i.i.i513.i.i.i.i, %if.else.i.i.i512.i.i.i.i, %if.then14.i.i.i506.i.i.i.i
  %guess.i.i.i468.i.i.i.i.0 = phi double [ %mul.i.i.i505.i.i.i.i, %if.then14.i.i.i506.i.i.i.i ], [ %div19.i.i.i511.i.i.i.i, %if.else.i.i.i512.i.i.i.i ], [ %288, %if.else21.i.i.i513.i.i.i.i ]
  %.neg5 = mul nsw i32 %div.i.i.i496.i.i.i.i, -3
  %rem.i.i.i514.i.i.i.i.decomposed = add i32 %.frozen209, 2
  %add.i.i.i515.i.i.i.i = add i32 %rem.i.i.i514.i.i.i.i.decomposed, %.neg5
  %289 = zext i32 %add.i.i.i515.i.i.i.i to i64
  %arrayidx1.i.i.i516.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %289
  %290 = load double, double addrspace(4)* %arrayidx1.i.i.i516.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i517.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.0, %290
  %cmp26.i.i.i518.i.i.i.i = icmp slt i32 %283, 1021
  br i1 %cmp26.i.i.i518.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i

do.body.i.i.i530.i.i.i.i:                         ; preds = %do.body.i.i.i530.i.i.i.i, %if.end23.i.i.i519.i.i.i.i
  %guess.i.i.i468.i.i.i.i.1 = phi double [ %mul24.i.i.i517.i.i.i.i, %if.end23.i.i.i519.i.i.i.i ], [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ]
  %mul28.i.i.i520.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %guess.i.i.i468.i.i.i.i.1
  %mul29.i.i.i521.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %mul28.i.i.i520.i.i.i.i
  %add30.i.i.i522.i.i.i.i = fadd double %mul31.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add31.i.i.i523.i.i.i.i = fadd double %mul31.i.i.i.i, %add30.i.i.i522.i.i.i.i
  %add32.i.i.i524.i.i.i.i = fadd double %mul29.i.i.i521.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add33.i.i.i525.i.i.i.i = fadd double %mul31.i.i.i.i, %add32.i.i.i524.i.i.i.i
  %div34.i.i.i526.i.i.i.i = fdiv double %add31.i.i.i523.i.i.i.i, %add33.i.i.i525.i.i.i.i
  %mul35.i.i.i527.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %div34.i.i.i526.i.i.i.i
  %sub36.i.i.i528.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i526.i.i.i.i
  %291 = tail call double @llvm.fabs.f64(double %sub36.i.i.i528.i.i.i.i) #3
  %cmp38.i.i.i529.i.i.i.i = fcmp ogt double %291, 0x3EC0000000000000
  br i1 %cmp38.i.i.i529.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

do.body40.i.i.i541.i.i.i.i:                       ; preds = %do.body40.i.i.i541.i.i.i.i, %if.end23.i.i.i519.i.i.i.i
  %guess.i.i.i468.i.i.i.i.2 = phi double [ %mul24.i.i.i517.i.i.i.i, %if.end23.i.i.i519.i.i.i.i ], [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ]
  %mul41.i.i.i531.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, %guess.i.i.i468.i.i.i.i.2
  %div42.i.i.i532.i.i.i.i = fdiv double %mul31.i.i.i.i, %guess.i.i.i468.i.i.i.i.2
  %sub43.i.i.i533.i.i.i.i = fsub double %mul41.i.i.i531.i.i.i.i, %div42.i.i.i532.i.i.i.i
  %mul44.i.i.i534.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i535.i.i.i.i = fdiv double %mul31.i.i.i.i, %mul41.i.i.i531.i.i.i.i
  %add46.i.i.i536.i.i.i.i = fadd double %mul44.i.i.i534.i.i.i.i, %div45.i.i.i535.i.i.i.i
  %div47.i.i.i537.i.i.i.i = fdiv double %sub43.i.i.i533.i.i.i.i, %add46.i.i.i536.i.i.i.i
  %sub48.i.i.i538.i.i.i.i = fsub double %guess.i.i.i468.i.i.i.i.2, %div47.i.i.i537.i.i.i.i
  %mul50.i.i.i539.i.i.i.i = fmul double %sub48.i.i.i538.i.i.i.i, 0x3EC0000000000000
  %292 = tail call double @llvm.fabs.f64(double %div47.i.i.i537.i.i.i.i) #3
  %cmp52.i.i.i540.i.i.i.i = fcmp olt double %mul50.i.i.i539.i.i.i.i, %292
  br i1 %cmp52.i.i.i540.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i: ; preds = %do.body40.i.i.i541.i.i.i.i, %do.body.i.i.i530.i.i.i.i, %if.end.i.i.i473.i.i.i.i, %if.then24.i.i.i.i
  %retval.0.i.i.i544.i.i.i.i = phi double [ %mul31.i.i.i.i, %if.then24.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i473.i.i.i.i ], [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ], [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ]
  %mul33.i.i.i.i = fmul double %add48.i.i.i.i.i.i, %retval.0.i.i.i544.i.i.i.i
  %div34.i.i.i.i = fdiv double %add48.i.i585.i.i.i.i, %mul33.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else35.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %cmp37.i.i.i.i = icmp sgt i32 %22, -17
  br i1 %cmp37.i.i.i.i, label %if.then38.i.i.i.i, label %if.else49.i.i.i.i

if.then38.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %293 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 8) #3
  %294 = tail call double @llvm.amdgcn.frexp.mant.f64(double %293) #3
  %295 = fcmp olt double %294, 0x3FE5555555555555
  %296 = zext i1 %295 to i32
  %297 = tail call double @llvm.amdgcn.ldexp.f64(double %294, i32 %296) #3
  %298 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %293) #3
  %299 = sub nsw i32 %298, %296
  %300 = fadd double %297, -1.000000e+00
  %301 = fadd double %297, 1.000000e+00
  %302 = fsub double %301, %297
  %303 = fsub double %301, %302
  %304 = fsub double %297, %303
  %305 = fsub double 1.000000e+00, %302
  %306 = fadd double %305, %304
  %307 = tail call double @llvm.amdgcn.rcp.f64(double %301) #3
  %308 = fneg double %301
  %309 = tail call double @llvm.fma.f64(double %308, double %307, double 1.000000e+00) #3
  %310 = tail call double @llvm.fma.f64(double %309, double %307, double %307) #3
  %311 = tail call double @llvm.fma.f64(double %308, double %310, double 1.000000e+00) #3
  %312 = tail call double @llvm.fma.f64(double %311, double %310, double %310) #3
  %313 = fmul double %300, %312
  %314 = fmul double %301, %313
  %315 = fneg double %314
  %316 = tail call double @llvm.fma.f64(double %313, double %301, double %315) #3
  %317 = tail call double @llvm.fma.f64(double %313, double %306, double %316) #3
  %318 = fadd double %314, %317
  %319 = fsub double %318, %314
  %320 = fsub double %317, %319
  %321 = fsub double %300, %318
  %322 = fsub double %300, %321
  %323 = fsub double %322, %318
  %324 = fsub double %323, %320
  %325 = fadd double %321, %324
  %326 = fmul double %312, %325
  %327 = fadd double %313, %326
  %328 = fsub double %327, %313
  %329 = fsub double %326, %328
  %330 = fmul double %327, %327
  %331 = fneg double %330
  %332 = tail call double @llvm.fma.f64(double %327, double %327, double %331) #3
  %333 = fmul double %329, 2.000000e+00
  %334 = tail call double @llvm.fma.f64(double %327, double %333, double %332) #3
  %335 = tail call double @llvm.fma.f64(double %329, double %329, double %334) #3
  %336 = fadd double %330, %335
  %337 = fsub double %336, %330
  %338 = fsub double %335, %337
  %339 = tail call double @llvm.fma.f64(double %336, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %340 = tail call double @llvm.fma.f64(double %336, double %339, double 0x3FC7474DD7F4DF2E) #3
  %341 = tail call double @llvm.fma.f64(double %336, double %340, double 0x3FCC71C016291751) #3
  %342 = tail call double @llvm.fma.f64(double %336, double %341, double 0x3FD249249B27ACF1) #3
  %343 = tail call double @llvm.fma.f64(double %336, double %342, double 0x3FD99999998EF7B6) #3
  %344 = tail call double @llvm.fma.f64(double %336, double %343, double 0x3FE5555555555780) #3
  %345 = tail call double @llvm.amdgcn.ldexp.f64(double %327, i32 1) #3
  %346 = tail call double @llvm.amdgcn.ldexp.f64(double %329, i32 1) #3
  %347 = fmul double %327, %336
  %348 = fneg double %347
  %349 = tail call double @llvm.fma.f64(double %327, double %336, double %348) #3
  %350 = fmul double %329, %336
  %351 = tail call double @llvm.fma.f64(double %327, double %338, double %350) #3
  %352 = fadd double %349, %351
  %353 = fadd double %347, %352
  %354 = fsub double %353, %347
  %355 = fsub double %352, %354
  %356 = fmul double %353, %344
  %357 = fneg double %356
  %358 = tail call double @llvm.fma.f64(double %353, double %344, double %357) #3
  %359 = tail call double @llvm.fma.f64(double %355, double %344, double %358) #3
  %360 = fadd double %356, %359
  %361 = fsub double %360, %356
  %362 = fsub double %359, %361
  %363 = fadd double %345, %360
  %364 = fsub double %363, %345
  %365 = fsub double %363, %364
  %366 = fsub double %345, %365
  %367 = fsub double %360, %364
  %368 = fadd double %367, %366
  %369 = fadd double %346, %362
  %370 = fsub double %369, %346
  %371 = fsub double %369, %370
  %372 = fsub double %346, %371
  %373 = fsub double %362, %370
  %374 = fadd double %373, %372
  %375 = fadd double %369, %368
  %376 = fadd double %363, %375
  %377 = fsub double %376, %363
  %378 = fsub double %375, %377
  %379 = fadd double %374, %378
  %380 = fadd double %376, %379
  %381 = fsub double %380, %376
  %382 = fsub double %379, %381
  %383 = sitofp i32 %299 to double
  %384 = fmul double %380, 0x3FF71547652B82FE
  %385 = fneg double %384
  %386 = fmul double %380, 0x3C7777D0FFDA0D24
  %387 = insertelement <2 x double> undef, double %380, i32 0
  %388 = insertelement <2 x double> %387, double %382, i32 1
  %389 = insertelement <2 x double> undef, double %385, i32 0
  %390 = insertelement <2 x double> %389, double %386, i32 1
  %391 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %388, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %390) #3
  %392 = extractelement <2 x double> %391, i32 0
  %393 = extractelement <2 x double> %391, i32 1
  %394 = fadd double %392, %393
  %395 = fadd double %384, %394
  %396 = fsub double %395, %384
  %397 = fsub double %394, %396
  %398 = fadd double %395, %383
  %399 = fsub double %398, %383
  %400 = fsub double %399, %398
  %401 = fadd double %400, %383
  %402 = fsub double %395, %399
  %403 = fadd double %402, %401
  %404 = fadd double %397, %403
  %405 = fadd double %398, %404
  %406 = tail call double @llvm.fabs.f64(double %293) #4
  %407 = fcmp oeq double %406, 0x7FF0000000000000
  %408 = select i1 %407, double %293, double %405
  %409 = fcmp olt double %293, 0.000000e+00
  %410 = select i1 %409, double 0x7FF8000000000000, double %408
  %411 = fcmp oeq double %293, 0.000000e+00
  %412 = select i1 %411, double 0xFFF0000000000000, double %410
  %mul.i.i450.i.i.i.i = fmul double %412, %412
  %mul1.i.i451.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3D1C49F35743D651
  %add.i.i452.i.i.i.i = fadd double %mul1.i.i451.i.i.i.i, 0x3EC5BDF8ABE0C4D2
  %mul5.i.i453.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E74DE722017F09B
  %add7.i.i454.i.i.i.i = fadd double %mul5.i.i453.i.i.i.i, 0x3F08B20867234AE0
  %mul10.i.i455.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i452.i.i.i.i
  %mul12.i.i456.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i454.i.i.i.i
  %add15.i.i457.i.i.i.i = fadd double %mul10.i.i455.i.i.i.i, 0x3F43291C59111954
  %add18.i.i458.i.i.i.i = fadd double %mul12.i.i456.i.i.i.i, 0x3F7555F81DC90AE6
  %mul20.i.i459.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i457.i.i.i.i
  %mul22.i.i460.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i458.i.i.i.i
  %add25.i.i461.i.i.i.i = fadd double %mul20.i.i459.i.i.i.i, 0x3FA118409603E368
  %add28.i.i462.i.i.i.i = fadd double %mul22.i.i460.i.i.i.i, 0x3FC2F812CF93403D
  %mul30.i.i463.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i461.i.i.i.i
  %mul32.i.i.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add28.i.i462.i.i.i.i
  %add35.i.i.i.i.i.i = fadd double %mul30.i.i463.i.i.i.i, 0x3FDA4ECF31EE23E1
  %add38.i.i464.i.i.i.i = fadd double %mul32.i.i.i.i.i.i, 0x3FE15637BD9C1C6C
  %413 = fmul double %412, %add35.i.i.i.i.i.i
  %add43.i.i.i.i.i.i = fsub double %add38.i.i464.i.i.i.i, %413
  %mul1.i.i434.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E834146FFF39045
  %add.i.i435.i.i.i.i = fadd double %mul1.i.i434.i.i.i.i, 0x3F16C942D4A0C545
  %mul5.i.i436.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3ED40F287F6755C5
  %add7.i.i437.i.i.i.i = fadd double %mul5.i.i436.i.i.i.i, 0x3F51AD434F5D94BA
  %mul10.i.i438.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i435.i.i.i.i
  %mul12.i.i439.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i437.i.i.i.i
  %add15.i.i440.i.i.i.i = fadd double %mul10.i.i438.i.i.i.i, 0x3F83AFF5A756295F
  %add18.i.i441.i.i.i.i = fadd double %mul12.i.i439.i.i.i.i, 0x3FAF8A313C5B71D0
  %mul20.i.i442.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i440.i.i.i.i
  %mul22.i.i443.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i441.i.i.i.i
  %add25.i.i444.i.i.i.i = fadd double %mul20.i.i442.i.i.i.i, 0x3FD1813788B6276A
  %add28.i.i445.i.i.i.i = fadd double %mul22.i.i443.i.i.i.i, 0x3FE84455F48DB67F
  %mul30.i.i446.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i444.i.i.i.i
  %add33.i.i447.i.i.i.i = fadd double %mul30.i.i446.i.i.i.i, 1.000000e+00
  %414 = fmul double %412, %add28.i.i445.i.i.i.i
  %add38.i.i449.i.i.i.i = fsub double %add33.i.i447.i.i.i.i, %414
  %mul45.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i356.i.i.i.i = fcmp ogt double %mul45.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i357.i.i.i.i = fcmp oeq double %mul45.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i358.i.i.i.i = or i1 %cmp.i.i.i.i356.i.i.i.i, %cmp.i.i.i357.i.i.i.i
  br i1 %or.cond.i.i.i358.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end.i.i.i360.i.i.i.i

if.end.i.i.i360.i.i.i.i:                          ; preds = %if.then38.i.i.i.i
  %cmp.i.i.i.i.i359.i.i.i.i = fcmp uno double %mul45.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i359.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end7.i.i.i386.i.i.i.i

if.end7.i.i.i386.i.i.i.i:                         ; preds = %if.end.i.i.i360.i.i.i.i
  %415 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul45.i.i.i.i) #3
  %416 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul45.i.i.i.i) #3
  %417 = tail call i1 @llvm.amdgcn.class.f64(double %mul45.i.i.i.i, i32 519) #3
  %418 = select i1 %417, i32 0, i32 %415
  %419 = select i1 %417, double %mul45.i.i.i.i, double %416
  %mul.i.i.i.i.i372.i.i.i.i = fmul double %419, %419
  %mul1.i.i.i.i.i373.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i374.i.i.i.i = fadd double %mul1.i.i.i.i.i373.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i375.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FE479D17050CA47
  %420 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i375.i.i.i.i
  %mul10.i.i.i.i.i377.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %add.i.i.i.i.i374.i.i.i.i
  %mul12.i.i.i.i.i378.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %420
  %add15.i.i.i.i.i379.i.i.i.i = fadd double %mul10.i.i.i.i.i377.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i380.i.i.i.i = fadd double %mul12.i.i.i.i.i378.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i381.i.i.i.i = fmul double %419, %add15.i.i.i.i.i379.i.i.i.i
  %add23.i.i.i.i.i382.i.i.i.i = fadd double %add18.i.i.i.i.i380.i.i.i.i, %mul20.i.i.i.i.i381.i.i.i.i
  %.frozen210 = freeze i32 %418
  %div.i.i.i383.i.i.i.i = sdiv i32 %.frozen210, 3
  %421 = sub nsw i32 0, %div.i.i.i383.i.i.i.i
  %422 = call i32 @llvm.abs.i32(i32 %div.i.i.i383.i.i.i.i, i1 true)
  %cmp11.i.i.i385.i.i.i.i = icmp ult i32 %422, 64
  br i1 %cmp11.i.i.i385.i.i.i.i, label %if.then12.i.i.i388.i.i.i.i, label %if.else21.i.i.i400.i.i.i.i

if.then12.i.i.i388.i.i.i.i:                       ; preds = %if.end7.i.i.i386.i.i.i.i
  %cmp13.i.i.i387.i.i.i.i = icmp sgt i32 %418, 2
  br i1 %cmp13.i.i.i387.i.i.i.i, label %if.then14.i.i.i393.i.i.i.i, label %if.else.i.i.i399.i.i.i.i

if.then14.i.i.i393.i.i.i.i:                       ; preds = %if.then12.i.i.i388.i.i.i.i
  %sh_prom.i.i.i389.i.i.i.i = zext i32 %div.i.i.i383.i.i.i.i to i64
  %shl.i.i.i390.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i389.i.i.i.i
  %conv.i.i.i391.i.i.i.i = uitofp i64 %shl.i.i.i390.i.i.i.i to double
  %mul.i.i.i392.i.i.i.i = fmul double %add23.i.i.i.i.i382.i.i.i.i, %conv.i.i.i391.i.i.i.i
  br label %if.end23.i.i.i406.i.i.i.i

if.else.i.i.i399.i.i.i.i:                         ; preds = %if.then12.i.i.i388.i.i.i.i
  %sh_prom16.i.i.i395.i.i.i.i = zext i32 %421 to i64
  %shl17.i.i.i396.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i395.i.i.i.i
  %conv18.i.i.i397.i.i.i.i = uitofp i64 %shl17.i.i.i396.i.i.i.i to double
  %div19.i.i.i398.i.i.i.i = fdiv double %add23.i.i.i.i.i382.i.i.i.i, %conv18.i.i.i397.i.i.i.i
  br label %if.end23.i.i.i406.i.i.i.i

if.else21.i.i.i400.i.i.i.i:                       ; preds = %if.end7.i.i.i386.i.i.i.i
  %423 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i382.i.i.i.i, i32 %div.i.i.i383.i.i.i.i) #3
  br label %if.end23.i.i.i406.i.i.i.i

if.end23.i.i.i406.i.i.i.i:                        ; preds = %if.else21.i.i.i400.i.i.i.i, %if.else.i.i.i399.i.i.i.i, %if.then14.i.i.i393.i.i.i.i
  %guess.i.i.i355.i.i.i.i.0 = phi double [ %mul.i.i.i392.i.i.i.i, %if.then14.i.i.i393.i.i.i.i ], [ %div19.i.i.i398.i.i.i.i, %if.else.i.i.i399.i.i.i.i ], [ %423, %if.else21.i.i.i400.i.i.i.i ]
  %.neg4 = mul nsw i32 %div.i.i.i383.i.i.i.i, -3
  %rem.i.i.i401.i.i.i.i.decomposed = add i32 %.frozen210, 2
  %add.i.i.i402.i.i.i.i = add i32 %rem.i.i.i401.i.i.i.i.decomposed, %.neg4
  %424 = zext i32 %add.i.i.i402.i.i.i.i to i64
  %arrayidx1.i.i.i403.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %424
  %425 = load double, double addrspace(4)* %arrayidx1.i.i.i403.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i404.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.0, %425
  %cmp26.i.i.i405.i.i.i.i = icmp slt i32 %418, 1021
  br i1 %cmp26.i.i.i405.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i

do.body.i.i.i417.i.i.i.i:                         ; preds = %do.body.i.i.i417.i.i.i.i, %if.end23.i.i.i406.i.i.i.i
  %guess.i.i.i355.i.i.i.i.1 = phi double [ %mul24.i.i.i404.i.i.i.i, %if.end23.i.i.i406.i.i.i.i ], [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ]
  %mul28.i.i.i407.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %guess.i.i.i355.i.i.i.i.1
  %mul29.i.i.i408.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %mul28.i.i.i407.i.i.i.i
  %add30.i.i.i409.i.i.i.i = fadd double %mul45.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add31.i.i.i410.i.i.i.i = fadd double %mul45.i.i.i.i, %add30.i.i.i409.i.i.i.i
  %add32.i.i.i411.i.i.i.i = fadd double %mul29.i.i.i408.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add33.i.i.i412.i.i.i.i = fadd double %mul45.i.i.i.i, %add32.i.i.i411.i.i.i.i
  %div34.i.i.i413.i.i.i.i = fdiv double %add31.i.i.i410.i.i.i.i, %add33.i.i.i412.i.i.i.i
  %mul35.i.i.i414.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %div34.i.i.i413.i.i.i.i
  %sub36.i.i.i415.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i413.i.i.i.i
  %426 = tail call double @llvm.fabs.f64(double %sub36.i.i.i415.i.i.i.i) #3
  %cmp38.i.i.i416.i.i.i.i = fcmp ogt double %426, 0x3EC0000000000000
  br i1 %cmp38.i.i.i416.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

do.body40.i.i.i428.i.i.i.i:                       ; preds = %do.body40.i.i.i428.i.i.i.i, %if.end23.i.i.i406.i.i.i.i
  %guess.i.i.i355.i.i.i.i.2 = phi double [ %mul24.i.i.i404.i.i.i.i, %if.end23.i.i.i406.i.i.i.i ], [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ]
  %mul41.i.i.i418.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, %guess.i.i.i355.i.i.i.i.2
  %div42.i.i.i419.i.i.i.i = fdiv double %mul45.i.i.i.i, %guess.i.i.i355.i.i.i.i.2
  %sub43.i.i.i420.i.i.i.i = fsub double %mul41.i.i.i418.i.i.i.i, %div42.i.i.i419.i.i.i.i
  %mul44.i.i.i421.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i422.i.i.i.i = fdiv double %mul45.i.i.i.i, %mul41.i.i.i418.i.i.i.i
  %add46.i.i.i423.i.i.i.i = fadd double %mul44.i.i.i421.i.i.i.i, %div45.i.i.i422.i.i.i.i
  %div47.i.i.i424.i.i.i.i = fdiv double %sub43.i.i.i420.i.i.i.i, %add46.i.i.i423.i.i.i.i
  %sub48.i.i.i425.i.i.i.i = fsub double %guess.i.i.i355.i.i.i.i.2, %div47.i.i.i424.i.i.i.i
  %mul50.i.i.i426.i.i.i.i = fmul double %sub48.i.i.i425.i.i.i.i, 0x3EC0000000000000
  %427 = tail call double @llvm.fabs.f64(double %div47.i.i.i424.i.i.i.i) #3
  %cmp52.i.i.i427.i.i.i.i = fcmp olt double %mul50.i.i.i426.i.i.i.i, %427
  br i1 %cmp52.i.i.i427.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i: ; preds = %do.body40.i.i.i428.i.i.i.i, %do.body.i.i.i417.i.i.i.i, %if.end.i.i.i360.i.i.i.i, %if.then38.i.i.i.i
  %retval.0.i.i.i431.i.i.i.i = phi double [ %mul45.i.i.i.i, %if.then38.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i360.i.i.i.i ], [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ], [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ]
  %mul47.i.i.i.i = fmul double %add38.i.i449.i.i.i.i, %retval.0.i.i.i431.i.i.i.i
  %div48.i.i.i.i = fdiv double %add43.i.i.i.i.i.i, %mul47.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else49.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %cmp51.i.i.i.i = icmp sgt i32 %22, -33
  br i1 %cmp51.i.i.i.i, label %if.then52.i.i.i.i, label %if.else63.i.i.i.i

if.then52.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %428 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 16) #3
  %429 = tail call double @llvm.amdgcn.frexp.mant.f64(double %428) #3
  %430 = fcmp olt double %429, 0x3FE5555555555555
  %431 = zext i1 %430 to i32
  %432 = tail call double @llvm.amdgcn.ldexp.f64(double %429, i32 %431) #3
  %433 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %428) #3
  %434 = sub nsw i32 %433, %431
  %435 = fadd double %432, -1.000000e+00
  %436 = fadd double %432, 1.000000e+00
  %437 = fsub double %436, %432
  %438 = fsub double %436, %437
  %439 = fsub double %432, %438
  %440 = fsub double 1.000000e+00, %437
  %441 = fadd double %440, %439
  %442 = tail call double @llvm.amdgcn.rcp.f64(double %436) #3
  %443 = fneg double %436
  %444 = tail call double @llvm.fma.f64(double %443, double %442, double 1.000000e+00) #3
  %445 = tail call double @llvm.fma.f64(double %444, double %442, double %442) #3
  %446 = tail call double @llvm.fma.f64(double %443, double %445, double 1.000000e+00) #3
  %447 = tail call double @llvm.fma.f64(double %446, double %445, double %445) #3
  %448 = fmul double %435, %447
  %449 = fmul double %436, %448
  %450 = fneg double %449
  %451 = tail call double @llvm.fma.f64(double %448, double %436, double %450) #3
  %452 = tail call double @llvm.fma.f64(double %448, double %441, double %451) #3
  %453 = fadd double %449, %452
  %454 = fsub double %453, %449
  %455 = fsub double %452, %454
  %456 = fsub double %435, %453
  %457 = fsub double %435, %456
  %458 = fsub double %457, %453
  %459 = fsub double %458, %455
  %460 = fadd double %456, %459
  %461 = fmul double %447, %460
  %462 = fadd double %448, %461
  %463 = fsub double %462, %448
  %464 = fsub double %461, %463
  %465 = fmul double %462, %462
  %466 = fneg double %465
  %467 = tail call double @llvm.fma.f64(double %462, double %462, double %466) #3
  %468 = fmul double %464, 2.000000e+00
  %469 = tail call double @llvm.fma.f64(double %462, double %468, double %467) #3
  %470 = tail call double @llvm.fma.f64(double %464, double %464, double %469) #3
  %471 = fadd double %465, %470
  %472 = fsub double %471, %465
  %473 = fsub double %470, %472
  %474 = tail call double @llvm.fma.f64(double %471, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %475 = tail call double @llvm.fma.f64(double %471, double %474, double 0x3FC7474DD7F4DF2E) #3
  %476 = tail call double @llvm.fma.f64(double %471, double %475, double 0x3FCC71C016291751) #3
  %477 = tail call double @llvm.fma.f64(double %471, double %476, double 0x3FD249249B27ACF1) #3
  %478 = tail call double @llvm.fma.f64(double %471, double %477, double 0x3FD99999998EF7B6) #3
  %479 = tail call double @llvm.fma.f64(double %471, double %478, double 0x3FE5555555555780) #3
  %480 = tail call double @llvm.amdgcn.ldexp.f64(double %462, i32 1) #3
  %481 = tail call double @llvm.amdgcn.ldexp.f64(double %464, i32 1) #3
  %482 = fmul double %462, %471
  %483 = fneg double %482
  %484 = tail call double @llvm.fma.f64(double %462, double %471, double %483) #3
  %485 = fmul double %464, %471
  %486 = tail call double @llvm.fma.f64(double %462, double %473, double %485) #3
  %487 = fadd double %484, %486
  %488 = fadd double %482, %487
  %489 = fsub double %488, %482
  %490 = fsub double %487, %489
  %491 = fmul double %488, %479
  %492 = fneg double %491
  %493 = tail call double @llvm.fma.f64(double %488, double %479, double %492) #3
  %494 = tail call double @llvm.fma.f64(double %490, double %479, double %493) #3
  %495 = fadd double %491, %494
  %496 = fsub double %495, %491
  %497 = fsub double %494, %496
  %498 = fadd double %480, %495
  %499 = fsub double %498, %480
  %500 = fsub double %498, %499
  %501 = fsub double %480, %500
  %502 = fsub double %495, %499
  %503 = fadd double %502, %501
  %504 = fadd double %481, %497
  %505 = fsub double %504, %481
  %506 = fsub double %504, %505
  %507 = fsub double %481, %506
  %508 = fsub double %497, %505
  %509 = fadd double %508, %507
  %510 = fadd double %504, %503
  %511 = fadd double %498, %510
  %512 = fsub double %511, %498
  %513 = fsub double %510, %512
  %514 = fadd double %509, %513
  %515 = fadd double %511, %514
  %516 = fsub double %515, %511
  %517 = fsub double %514, %516
  %518 = sitofp i32 %434 to double
  %519 = fmul double %515, 0x3FF71547652B82FE
  %520 = fneg double %519
  %521 = fmul double %515, 0x3C7777D0FFDA0D24
  %522 = insertelement <2 x double> undef, double %515, i32 0
  %523 = insertelement <2 x double> %522, double %517, i32 1
  %524 = insertelement <2 x double> undef, double %520, i32 0
  %525 = insertelement <2 x double> %524, double %521, i32 1
  %526 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %523, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %525) #3
  %527 = extractelement <2 x double> %526, i32 0
  %528 = extractelement <2 x double> %526, i32 1
  %529 = fadd double %527, %528
  %530 = fadd double %519, %529
  %531 = fsub double %530, %519
  %532 = fsub double %529, %531
  %533 = fadd double %530, %518
  %534 = fsub double %533, %518
  %535 = fsub double %534, %533
  %536 = fadd double %535, %518
  %537 = fsub double %530, %534
  %538 = fadd double %537, %536
  %539 = fadd double %532, %538
  %540 = fadd double %533, %539
  %541 = tail call double @llvm.fabs.f64(double %428) #4
  %542 = fcmp oeq double %541, 0x7FF0000000000000
  %543 = select i1 %542, double %428, double %540
  %544 = fcmp olt double %428, 0.000000e+00
  %545 = select i1 %544, double 0x7FF8000000000000, double %543
  %546 = fcmp oeq double %428, 0.000000e+00
  %547 = select i1 %546, double 0xFFF0000000000000, double %545
  %mul.i.i335.i.i.i.i = fmul double %547, %547
  %mul1.i.i336.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EBF7344DBF5E403
  %add.i.i337.i.i.i.i = fadd double %mul1.i.i336.i.i.i.i, 0x3F2CFF1E2D54E4E7
  %mul5.i.i338.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EEF8CF23CAED047
  %add7.i.i339.i.i.i.i = fadd double %mul5.i.i338.i.i.i.i, 0x3F5CF8F0FF9B6F59
  %mul10.i.i340.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i337.i.i.i.i
  %mul12.i.i341.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i339.i.i.i.i
  %add15.i.i342.i.i.i.i = fadd double %mul10.i.i340.i.i.i.i, 0x3F8857AD74D33625
  %add18.i.i343.i.i.i.i = fadd double %mul12.i.i341.i.i.i.i, 0x3FAE52179C3AEDE6
  %mul20.i.i344.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i342.i.i.i.i
  %mul22.i.i345.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i343.i.i.i.i
  %add25.i.i346.i.i.i.i = fadd double %mul20.i.i344.i.i.i.i, 0x3FCB21A22303D8FC
  %add28.i.i347.i.i.i.i = fadd double %mul22.i.i345.i.i.i.i, 0x3FDF29CE00A8804B
  %mul30.i.i348.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i346.i.i.i.i
  %add33.i.i349.i.i.i.i = fadd double %mul30.i.i348.i.i.i.i, 0x3FE15775564555E5
  %548 = fmul double %547, %add28.i.i347.i.i.i.i
  %add38.i.i351.i.i.i.i = fsub double %add33.i.i349.i.i.i.i, %548
  %mul1.i.i321.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3ECD04621671DBCE
  %add.i.i322.i.i.i.i = fadd double %mul1.i.i321.i.i.i.i, 0x3F3AC0D433DC2A4E
  %mul5.i.i323.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EFD1C12EAA62BE9
  %add7.i.i324.i.i.i.i = fadd double %mul5.i.i323.i.i.i.i, 0x3F6ABB215A001E96
  %mul10.i.i325.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i322.i.i.i.i
  %mul12.i.i326.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i324.i.i.i.i
  %add15.i.i327.i.i.i.i = fadd double %mul10.i.i325.i.i.i.i, 0x3F967590758A1B1A
  %add18.i.i328.i.i.i.i = fadd double %mul12.i.i326.i.i.i.i, 0x3FBBF9941AE7DFDE
  %mul20.i.i329.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i327.i.i.i.i
  %mul22.i.i330.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i328.i.i.i.i
  %add25.i.i331.i.i.i.i = fadd double %mul20.i.i329.i.i.i.i, 0x3FD90848F242167F
  %add28.i.i332.i.i.i.i = fadd double %mul22.i.i330.i.i.i.i, 0x3FECC09A37BCEE76
  %mul30.i.i333.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i331.i.i.i.i
  %add33.i.i334.i.i.i.i = fadd double %mul30.i.i333.i.i.i.i, 1.000000e+00
  %549 = fmul double %547, %add28.i.i332.i.i.i.i
  %add38.i.i.i.i.i.i = fsub double %add33.i.i334.i.i.i.i, %549
  %mul59.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i243.i.i.i.i = fcmp ogt double %mul59.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i244.i.i.i.i = fcmp oeq double %mul59.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i245.i.i.i.i = or i1 %cmp.i.i.i.i243.i.i.i.i, %cmp.i.i.i244.i.i.i.i
  br i1 %or.cond.i.i.i245.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end.i.i.i247.i.i.i.i

if.end.i.i.i247.i.i.i.i:                          ; preds = %if.then52.i.i.i.i
  %cmp.i.i.i.i.i246.i.i.i.i = fcmp uno double %mul59.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i246.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end7.i.i.i273.i.i.i.i

if.end7.i.i.i273.i.i.i.i:                         ; preds = %if.end.i.i.i247.i.i.i.i
  %550 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul59.i.i.i.i) #3
  %551 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul59.i.i.i.i) #3
  %552 = tail call i1 @llvm.amdgcn.class.f64(double %mul59.i.i.i.i, i32 519) #3
  %553 = select i1 %552, i32 0, i32 %550
  %554 = select i1 %552, double %mul59.i.i.i.i, double %551
  %mul.i.i.i.i.i259.i.i.i.i = fmul double %554, %554
  %mul1.i.i.i.i.i260.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i261.i.i.i.i = fadd double %mul1.i.i.i.i.i260.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i262.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FE479D17050CA47
  %555 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i262.i.i.i.i
  %mul10.i.i.i.i.i264.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %add.i.i.i.i.i261.i.i.i.i
  %mul12.i.i.i.i.i265.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %555
  %add15.i.i.i.i.i266.i.i.i.i = fadd double %mul10.i.i.i.i.i264.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i267.i.i.i.i = fadd double %mul12.i.i.i.i.i265.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i268.i.i.i.i = fmul double %554, %add15.i.i.i.i.i266.i.i.i.i
  %add23.i.i.i.i.i269.i.i.i.i = fadd double %add18.i.i.i.i.i267.i.i.i.i, %mul20.i.i.i.i.i268.i.i.i.i
  %.frozen211 = freeze i32 %553
  %div.i.i.i270.i.i.i.i = sdiv i32 %.frozen211, 3
  %556 = sub nsw i32 0, %div.i.i.i270.i.i.i.i
  %557 = call i32 @llvm.abs.i32(i32 %div.i.i.i270.i.i.i.i, i1 true)
  %cmp11.i.i.i272.i.i.i.i = icmp ult i32 %557, 64
  br i1 %cmp11.i.i.i272.i.i.i.i, label %if.then12.i.i.i275.i.i.i.i, label %if.else21.i.i.i287.i.i.i.i

if.then12.i.i.i275.i.i.i.i:                       ; preds = %if.end7.i.i.i273.i.i.i.i
  %cmp13.i.i.i274.i.i.i.i = icmp sgt i32 %553, 2
  br i1 %cmp13.i.i.i274.i.i.i.i, label %if.then14.i.i.i280.i.i.i.i, label %if.else.i.i.i286.i.i.i.i

if.then14.i.i.i280.i.i.i.i:                       ; preds = %if.then12.i.i.i275.i.i.i.i
  %sh_prom.i.i.i276.i.i.i.i = zext i32 %div.i.i.i270.i.i.i.i to i64
  %shl.i.i.i277.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i276.i.i.i.i
  %conv.i.i.i278.i.i.i.i = uitofp i64 %shl.i.i.i277.i.i.i.i to double
  %mul.i.i.i279.i.i.i.i = fmul double %add23.i.i.i.i.i269.i.i.i.i, %conv.i.i.i278.i.i.i.i
  br label %if.end23.i.i.i293.i.i.i.i

if.else.i.i.i286.i.i.i.i:                         ; preds = %if.then12.i.i.i275.i.i.i.i
  %sh_prom16.i.i.i282.i.i.i.i = zext i32 %556 to i64
  %shl17.i.i.i283.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i282.i.i.i.i
  %conv18.i.i.i284.i.i.i.i = uitofp i64 %shl17.i.i.i283.i.i.i.i to double
  %div19.i.i.i285.i.i.i.i = fdiv double %add23.i.i.i.i.i269.i.i.i.i, %conv18.i.i.i284.i.i.i.i
  br label %if.end23.i.i.i293.i.i.i.i

if.else21.i.i.i287.i.i.i.i:                       ; preds = %if.end7.i.i.i273.i.i.i.i
  %558 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i269.i.i.i.i, i32 %div.i.i.i270.i.i.i.i) #3
  br label %if.end23.i.i.i293.i.i.i.i

if.end23.i.i.i293.i.i.i.i:                        ; preds = %if.else21.i.i.i287.i.i.i.i, %if.else.i.i.i286.i.i.i.i, %if.then14.i.i.i280.i.i.i.i
  %guess.i.i.i242.i.i.i.i.0 = phi double [ %mul.i.i.i279.i.i.i.i, %if.then14.i.i.i280.i.i.i.i ], [ %div19.i.i.i285.i.i.i.i, %if.else.i.i.i286.i.i.i.i ], [ %558, %if.else21.i.i.i287.i.i.i.i ]
  %.neg3 = mul nsw i32 %div.i.i.i270.i.i.i.i, -3
  %rem.i.i.i288.i.i.i.i.decomposed = add i32 %.frozen211, 2
  %add.i.i.i289.i.i.i.i = add i32 %rem.i.i.i288.i.i.i.i.decomposed, %.neg3
  %559 = zext i32 %add.i.i.i289.i.i.i.i to i64
  %arrayidx1.i.i.i290.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %559
  %560 = load double, double addrspace(4)* %arrayidx1.i.i.i290.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i291.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.0, %560
  %cmp26.i.i.i292.i.i.i.i = icmp slt i32 %553, 1021
  br i1 %cmp26.i.i.i292.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i

do.body.i.i.i304.i.i.i.i:                         ; preds = %do.body.i.i.i304.i.i.i.i, %if.end23.i.i.i293.i.i.i.i
  %guess.i.i.i242.i.i.i.i.1 = phi double [ %mul24.i.i.i291.i.i.i.i, %if.end23.i.i.i293.i.i.i.i ], [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ]
  %mul28.i.i.i294.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %guess.i.i.i242.i.i.i.i.1
  %mul29.i.i.i295.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %mul28.i.i.i294.i.i.i.i
  %add30.i.i.i296.i.i.i.i = fadd double %mul59.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add31.i.i.i297.i.i.i.i = fadd double %mul59.i.i.i.i, %add30.i.i.i296.i.i.i.i
  %add32.i.i.i298.i.i.i.i = fadd double %mul29.i.i.i295.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add33.i.i.i299.i.i.i.i = fadd double %mul59.i.i.i.i, %add32.i.i.i298.i.i.i.i
  %div34.i.i.i300.i.i.i.i = fdiv double %add31.i.i.i297.i.i.i.i, %add33.i.i.i299.i.i.i.i
  %mul35.i.i.i301.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %div34.i.i.i300.i.i.i.i
  %sub36.i.i.i302.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i300.i.i.i.i
  %561 = tail call double @llvm.fabs.f64(double %sub36.i.i.i302.i.i.i.i) #3
  %cmp38.i.i.i303.i.i.i.i = fcmp ogt double %561, 0x3EC0000000000000
  br i1 %cmp38.i.i.i303.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

do.body40.i.i.i315.i.i.i.i:                       ; preds = %do.body40.i.i.i315.i.i.i.i, %if.end23.i.i.i293.i.i.i.i
  %guess.i.i.i242.i.i.i.i.2 = phi double [ %mul24.i.i.i291.i.i.i.i, %if.end23.i.i.i293.i.i.i.i ], [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ]
  %mul41.i.i.i305.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, %guess.i.i.i242.i.i.i.i.2
  %div42.i.i.i306.i.i.i.i = fdiv double %mul59.i.i.i.i, %guess.i.i.i242.i.i.i.i.2
  %sub43.i.i.i307.i.i.i.i = fsub double %mul41.i.i.i305.i.i.i.i, %div42.i.i.i306.i.i.i.i
  %mul44.i.i.i308.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i309.i.i.i.i = fdiv double %mul59.i.i.i.i, %mul41.i.i.i305.i.i.i.i
  %add46.i.i.i310.i.i.i.i = fadd double %mul44.i.i.i308.i.i.i.i, %div45.i.i.i309.i.i.i.i
  %div47.i.i.i311.i.i.i.i = fdiv double %sub43.i.i.i307.i.i.i.i, %add46.i.i.i310.i.i.i.i
  %sub48.i.i.i312.i.i.i.i = fsub double %guess.i.i.i242.i.i.i.i.2, %div47.i.i.i311.i.i.i.i
  %mul50.i.i.i313.i.i.i.i = fmul double %sub48.i.i.i312.i.i.i.i, 0x3EC0000000000000
  %562 = tail call double @llvm.fabs.f64(double %div47.i.i.i311.i.i.i.i) #3
  %cmp52.i.i.i314.i.i.i.i = fcmp olt double %mul50.i.i.i313.i.i.i.i, %562
  br i1 %cmp52.i.i.i314.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i: ; preds = %do.body40.i.i.i315.i.i.i.i, %do.body.i.i.i304.i.i.i.i, %if.end.i.i.i247.i.i.i.i, %if.then52.i.i.i.i
  %retval.0.i.i.i318.i.i.i.i = phi double [ %mul59.i.i.i.i, %if.then52.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i247.i.i.i.i ], [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ], [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ]
  %mul61.i.i.i.i = fmul double %add38.i.i.i.i.i.i, %retval.0.i.i.i318.i.i.i.i
  %div62.i.i.i.i = fdiv double %add38.i.i351.i.i.i.i, %mul61.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else63.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %mul64.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp1.i.i.i.i.i = fcmp oge double %mul64.i.i.i.i, 0x10000000000000
  %cmp2.i.i.i.i.i = fcmp ole double %mul64.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %563 = and i1 %cmp1.i.i.i.i.i, %cmp2.i.i.i.i.i
  br i1 %563, label %if.then66.i.i.i.i, label %if.else71.i.i.i.i

if.then66.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %mul68.i.i.i.i = fmul double %mul64.i.i.i.i, 0x401921FB54442D18
  %cmp.i.i.i.i162.i.i.i.i = fcmp ogt double %mul68.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i163.i.i.i.i = fcmp oeq double %mul68.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i164.i.i.i.i = or i1 %cmp.i.i.i.i162.i.i.i.i, %cmp.i.i.i163.i.i.i.i
  br i1 %or.cond.i.i.i164.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end.i.i.i166.i.i.i.i

if.end.i.i.i166.i.i.i.i:                          ; preds = %if.then66.i.i.i.i
  %cmp.i.i.i.i.i165.i.i.i.i = fcmp uno double %mul68.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i165.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end7.i.i.i192.i.i.i.i

if.end7.i.i.i192.i.i.i.i:                         ; preds = %if.end.i.i.i166.i.i.i.i
  %564 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul68.i.i.i.i) #3
  %565 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul68.i.i.i.i) #3
  %566 = tail call i1 @llvm.amdgcn.class.f64(double %mul68.i.i.i.i, i32 519) #3
  %567 = select i1 %566, i32 0, i32 %564
  %568 = select i1 %566, double %mul68.i.i.i.i, double %565
  %mul.i.i.i.i.i178.i.i.i.i = fmul double %568, %568
  %mul1.i.i.i.i.i179.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i180.i.i.i.i = fadd double %mul1.i.i.i.i.i179.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i181.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FE479D17050CA47
  %569 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i181.i.i.i.i
  %mul10.i.i.i.i.i183.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %add.i.i.i.i.i180.i.i.i.i
  %mul12.i.i.i.i.i184.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %569
  %add15.i.i.i.i.i185.i.i.i.i = fadd double %mul10.i.i.i.i.i183.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i186.i.i.i.i = fadd double %mul12.i.i.i.i.i184.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i187.i.i.i.i = fmul double %568, %add15.i.i.i.i.i185.i.i.i.i
  %add23.i.i.i.i.i188.i.i.i.i = fadd double %add18.i.i.i.i.i186.i.i.i.i, %mul20.i.i.i.i.i187.i.i.i.i
  %.frozen212 = freeze i32 %567
  %div.i.i.i189.i.i.i.i = sdiv i32 %.frozen212, 3
  %570 = sub nsw i32 0, %div.i.i.i189.i.i.i.i
  %571 = call i32 @llvm.abs.i32(i32 %div.i.i.i189.i.i.i.i, i1 true)
  %cmp11.i.i.i191.i.i.i.i = icmp ult i32 %571, 64
  br i1 %cmp11.i.i.i191.i.i.i.i, label %if.then12.i.i.i194.i.i.i.i, label %if.else21.i.i.i206.i.i.i.i

if.then12.i.i.i194.i.i.i.i:                       ; preds = %if.end7.i.i.i192.i.i.i.i
  %cmp13.i.i.i193.i.i.i.i = icmp sgt i32 %567, 2
  br i1 %cmp13.i.i.i193.i.i.i.i, label %if.then14.i.i.i199.i.i.i.i, label %if.else.i.i.i205.i.i.i.i

if.then14.i.i.i199.i.i.i.i:                       ; preds = %if.then12.i.i.i194.i.i.i.i
  %sh_prom.i.i.i195.i.i.i.i = zext i32 %div.i.i.i189.i.i.i.i to i64
  %shl.i.i.i196.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i195.i.i.i.i
  %conv.i.i.i197.i.i.i.i = uitofp i64 %shl.i.i.i196.i.i.i.i to double
  %mul.i.i.i198.i.i.i.i = fmul double %add23.i.i.i.i.i188.i.i.i.i, %conv.i.i.i197.i.i.i.i
  br label %if.end23.i.i.i212.i.i.i.i

if.else.i.i.i205.i.i.i.i:                         ; preds = %if.then12.i.i.i194.i.i.i.i
  %sh_prom16.i.i.i201.i.i.i.i = zext i32 %570 to i64
  %shl17.i.i.i202.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i201.i.i.i.i
  %conv18.i.i.i203.i.i.i.i = uitofp i64 %shl17.i.i.i202.i.i.i.i to double
  %div19.i.i.i204.i.i.i.i = fdiv double %add23.i.i.i.i.i188.i.i.i.i, %conv18.i.i.i203.i.i.i.i
  br label %if.end23.i.i.i212.i.i.i.i

if.else21.i.i.i206.i.i.i.i:                       ; preds = %if.end7.i.i.i192.i.i.i.i
  %572 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i188.i.i.i.i, i32 %div.i.i.i189.i.i.i.i) #3
  br label %if.end23.i.i.i212.i.i.i.i

if.end23.i.i.i212.i.i.i.i:                        ; preds = %if.else21.i.i.i206.i.i.i.i, %if.else.i.i.i205.i.i.i.i, %if.then14.i.i.i199.i.i.i.i
  %guess.i.i.i161.i.i.i.i.0 = phi double [ %mul.i.i.i198.i.i.i.i, %if.then14.i.i.i199.i.i.i.i ], [ %div19.i.i.i204.i.i.i.i, %if.else.i.i.i205.i.i.i.i ], [ %572, %if.else21.i.i.i206.i.i.i.i ]
  %.neg2 = mul nsw i32 %div.i.i.i189.i.i.i.i, -3
  %rem.i.i.i207.i.i.i.i.decomposed = add i32 %.frozen212, 2
  %add.i.i.i208.i.i.i.i = add i32 %rem.i.i.i207.i.i.i.i.decomposed, %.neg2
  %573 = zext i32 %add.i.i.i208.i.i.i.i to i64
  %arrayidx1.i.i.i209.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %573
  %574 = load double, double addrspace(4)* %arrayidx1.i.i.i209.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i210.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.0, %574
  %cmp26.i.i.i211.i.i.i.i = icmp slt i32 %567, 1021
  br i1 %cmp26.i.i.i211.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i

do.body.i.i.i223.i.i.i.i:                         ; preds = %do.body.i.i.i223.i.i.i.i, %if.end23.i.i.i212.i.i.i.i
  %guess.i.i.i161.i.i.i.i.1 = phi double [ %mul24.i.i.i210.i.i.i.i, %if.end23.i.i.i212.i.i.i.i ], [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ]
  %mul28.i.i.i213.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %guess.i.i.i161.i.i.i.i.1
  %mul29.i.i.i214.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %mul28.i.i.i213.i.i.i.i
  %add30.i.i.i215.i.i.i.i = fadd double %mul68.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add31.i.i.i216.i.i.i.i = fadd double %mul68.i.i.i.i, %add30.i.i.i215.i.i.i.i
  %add32.i.i.i217.i.i.i.i = fadd double %mul29.i.i.i214.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add33.i.i.i218.i.i.i.i = fadd double %mul68.i.i.i.i, %add32.i.i.i217.i.i.i.i
  %div34.i.i.i219.i.i.i.i = fdiv double %add31.i.i.i216.i.i.i.i, %add33.i.i.i218.i.i.i.i
  %mul35.i.i.i220.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %div34.i.i.i219.i.i.i.i
  %sub36.i.i.i221.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i219.i.i.i.i
  %575 = tail call double @llvm.fabs.f64(double %sub36.i.i.i221.i.i.i.i) #3
  %cmp38.i.i.i222.i.i.i.i = fcmp ogt double %575, 0x3EC0000000000000
  br i1 %cmp38.i.i.i222.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

do.body40.i.i.i234.i.i.i.i:                       ; preds = %do.body40.i.i.i234.i.i.i.i, %if.end23.i.i.i212.i.i.i.i
  %guess.i.i.i161.i.i.i.i.2 = phi double [ %mul24.i.i.i210.i.i.i.i, %if.end23.i.i.i212.i.i.i.i ], [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ]
  %mul41.i.i.i224.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, %guess.i.i.i161.i.i.i.i.2
  %div42.i.i.i225.i.i.i.i = fdiv double %mul68.i.i.i.i, %guess.i.i.i161.i.i.i.i.2
  %sub43.i.i.i226.i.i.i.i = fsub double %mul41.i.i.i224.i.i.i.i, %div42.i.i.i225.i.i.i.i
  %mul44.i.i.i227.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i228.i.i.i.i = fdiv double %mul68.i.i.i.i, %mul41.i.i.i224.i.i.i.i
  %add46.i.i.i229.i.i.i.i = fadd double %mul44.i.i.i227.i.i.i.i, %div45.i.i.i228.i.i.i.i
  %div47.i.i.i230.i.i.i.i = fdiv double %sub43.i.i.i226.i.i.i.i, %add46.i.i.i229.i.i.i.i
  %sub48.i.i.i231.i.i.i.i = fsub double %guess.i.i.i161.i.i.i.i.2, %div47.i.i.i230.i.i.i.i
  %mul50.i.i.i232.i.i.i.i = fmul double %sub48.i.i.i231.i.i.i.i, 0x3EC0000000000000
  %576 = tail call double @llvm.fabs.f64(double %div47.i.i.i230.i.i.i.i) #3
  %cmp52.i.i.i233.i.i.i.i = fcmp olt double %mul50.i.i.i232.i.i.i.i, %576
  br i1 %cmp52.i.i.i233.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i: ; preds = %do.body40.i.i.i234.i.i.i.i, %do.body.i.i.i223.i.i.i.i, %if.end.i.i.i166.i.i.i.i, %if.then66.i.i.i.i
  %retval.0.i.i.i237.i.i.i.i = phi double [ %mul68.i.i.i.i, %if.then66.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i166.i.i.i.i ], [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ], [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ]
  %div70.i.i.i.i = fdiv double 1.000000e+00, %retval.0.i.i.i237.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else71.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %cmp72.i.i.i.i = fcmp ogt double %sub.i.i.i, 0.000000e+00
  br i1 %cmp72.i.i.i.i, label %if.then73.i.i.i.i, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.then73.i.i.i.i:                                ; preds = %if.else71.i.i.i.i
  %cmp.i.i.i.i79.i.i.i.i = fcmp ogt double %sub.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i.i80.i.i.i.i = fcmp olt double %sub.i.i.i, 0xFFEFFFFFFFFFFFFF
  %577 = or i1 %cmp.i.i.i.i79.i.i.i.i, %cmp1.i.i.i.i80.i.i.i.i
  %or.cond.i.i.i82.i.i.i.i = or i1 %21, %577
  %brmerge170 = or i1 %16, %or.cond.i.i.i82.i.i.i.i
  %sub.i.i.i.mux = select i1 %or.cond.i.i.i82.i.i.i.i, double %sub.i.i.i, double 0x7FF8000000000000
  br i1 %brmerge170, label %if.end7.i.i.i.i.i.i.i, label %if.end4.i.i.i92.i.i.i.i

if.end4.i.i.i92.i.i.i.i:                          ; preds = %if.then73.i.i.i.i
  %cmp5.i.i.i91.i.i.i.i = fcmp olt double %sub.i.i.i, 0.000000e+00
  %fneg.i.i.i93.i.i.i.i = fneg double %sub.i.i.i
  %z.addr.i.i.i76.i.i.i.i.0 = select i1 %cmp5.i.i.i91.i.i.i.i, double %fneg.i.i.i93.i.i.i.i, double %sub.i.i.i
  %578 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %579 = tail call double @llvm.amdgcn.frexp.mant.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %580 = tail call i1 @llvm.amdgcn.class.f64(double %z.addr.i.i.i76.i.i.i.i.0, i32 519) #3
  %581 = select i1 %580, i32 0, i32 %578
  %582 = select i1 %580, double %z.addr.i.i.i76.i.i.i.i.0, double %579
  %mul.i.i.i.i.i97.i.i.i.i = fmul double %582, %582
  %mul1.i.i.i.i.i98.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i99.i.i.i.i = fadd double %mul1.i.i.i.i.i98.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i100.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FE479D17050CA47
  %583 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i100.i.i.i.i
  %mul10.i.i.i.i.i102.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %add.i.i.i.i.i99.i.i.i.i
  %mul12.i.i.i.i.i103.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %583
  %add15.i.i.i.i.i104.i.i.i.i = fadd double %mul10.i.i.i.i.i102.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i105.i.i.i.i = fadd double %mul12.i.i.i.i.i103.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i106.i.i.i.i = fmul double %582, %add15.i.i.i.i.i104.i.i.i.i
  %add23.i.i.i.i.i107.i.i.i.i = fadd double %add18.i.i.i.i.i105.i.i.i.i, %mul20.i.i.i.i.i106.i.i.i.i
  %.frozen213 = freeze i32 %581
  %div.i.i.i108.i.i.i.i = sdiv i32 %.frozen213, 3
  %584 = sub nsw i32 0, %div.i.i.i108.i.i.i.i
  %585 = call i32 @llvm.abs.i32(i32 %div.i.i.i108.i.i.i.i, i1 true)
  %cmp11.i.i.i110.i.i.i.i = icmp ult i32 %585, 64
  br i1 %cmp11.i.i.i110.i.i.i.i, label %if.then12.i.i.i113.i.i.i.i, label %if.else21.i.i.i125.i.i.i.i

if.then12.i.i.i113.i.i.i.i:                       ; preds = %if.end4.i.i.i92.i.i.i.i
  %cmp13.i.i.i112.i.i.i.i = icmp sgt i32 %581, 2
  br i1 %cmp13.i.i.i112.i.i.i.i, label %if.then14.i.i.i118.i.i.i.i, label %if.else.i.i.i124.i.i.i.i

if.then14.i.i.i118.i.i.i.i:                       ; preds = %if.then12.i.i.i113.i.i.i.i
  %sh_prom.i.i.i114.i.i.i.i = zext i32 %div.i.i.i108.i.i.i.i to i64
  %shl.i.i.i115.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i114.i.i.i.i
  %conv.i.i.i116.i.i.i.i = uitofp i64 %shl.i.i.i115.i.i.i.i to double
  %mul.i.i.i117.i.i.i.i = fmul double %add23.i.i.i.i.i107.i.i.i.i, %conv.i.i.i116.i.i.i.i
  br label %if.end23.i.i.i131.i.i.i.i

if.else.i.i.i124.i.i.i.i:                         ; preds = %if.then12.i.i.i113.i.i.i.i
  %sh_prom16.i.i.i120.i.i.i.i = zext i32 %584 to i64
  %shl17.i.i.i121.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i120.i.i.i.i
  %conv18.i.i.i122.i.i.i.i = uitofp i64 %shl17.i.i.i121.i.i.i.i to double
  %div19.i.i.i123.i.i.i.i = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %conv18.i.i.i122.i.i.i.i
  br label %if.end23.i.i.i131.i.i.i.i

if.else21.i.i.i125.i.i.i.i:                       ; preds = %if.end4.i.i.i92.i.i.i.i
  %586 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  br label %if.end23.i.i.i131.i.i.i.i

if.end23.i.i.i131.i.i.i.i:                        ; preds = %if.else21.i.i.i125.i.i.i.i, %if.else.i.i.i124.i.i.i.i, %if.then14.i.i.i118.i.i.i.i
  %guess.i.i.i78.i.i.i.i.0 = phi double [ %mul.i.i.i117.i.i.i.i, %if.then14.i.i.i118.i.i.i.i ], [ %div19.i.i.i123.i.i.i.i, %if.else.i.i.i124.i.i.i.i ], [ %586, %if.else21.i.i.i125.i.i.i.i ]
  %.neg = mul nsw i32 %div.i.i.i108.i.i.i.i, -3
  %rem.i.i.i126.i.i.i.i.decomposed = add i32 %.frozen213, 2
  %add.i.i.i127.i.i.i.i = add i32 %rem.i.i.i126.i.i.i.i.decomposed, %.neg
  %587 = zext i32 %add.i.i.i127.i.i.i.i to i64
  %arrayidx1.i.i.i128.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %587
  %588 = load double, double addrspace(4)* %arrayidx1.i.i.i128.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i129.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.0, %588
  %cmp26.i.i.i130.i.i.i.i = icmp slt i32 %581, 1021
  br i1 %cmp26.i.i.i130.i.i.i.i, label %do.body.i.i.i142.i.i.i.i, label %do.body40.i.i.i153.i.i.i.i

do.body.i.i.i142.i.i.i.i:                         ; preds = %do.body.i.i.i142.i.i.i.i, %if.end23.i.i.i131.i.i.i.i
  %guess.i.i.i78.i.i.i.i.1 = phi double [ %mul24.i.i.i129.i.i.i.i, %if.end23.i.i.i131.i.i.i.i ], [ %mul35.i.i.i139.i.i.i.i, %do.body.i.i.i142.i.i.i.i ]
  %mul28.i.i.i132.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.1, %guess.i.i.i78.i.i.i.i.1
  %mul29.i.i.i133.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.1, %mul28.i.i.i132.i.i.i.i
  %add30.i.i.i134.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %mul29.i.i.i133.i.i.i.i
  %add31.i.i.i135.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add30.i.i.i134.i.i.i.i
  %add32.i.i.i136.i.i.i.i = fadd double %mul29.i.i.i133.i.i.i.i, %mul29.i.i.i133.i.i.i.i
  %add33.i.i.i137.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add32.i.i.i136.i.i.i.i
  %div34.i.i.i138.i.i.i.i = fdiv double %add31.i.i.i135.i.i.i.i, %add33.i.i.i137.i.i.i.i
  %mul35.i.i.i139.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.1, %div34.i.i.i138.i.i.i.i
  %sub36.i.i.i140.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i138.i.i.i.i
  %589 = tail call double @llvm.fabs.f64(double %sub36.i.i.i140.i.i.i.i) #3
  %cmp38.i.i.i141.i.i.i.i = fcmp ogt double %589, 0x3EC0000000000000
  br i1 %cmp38.i.i.i141.i.i.i.i, label %do.body.i.i.i142.i.i.i.i, label %if.end4.i.i.i.i.i.i.i

do.body40.i.i.i153.i.i.i.i:                       ; preds = %do.body40.i.i.i153.i.i.i.i, %if.end23.i.i.i131.i.i.i.i
  %guess.i.i.i78.i.i.i.i.2 = phi double [ %mul24.i.i.i129.i.i.i.i, %if.end23.i.i.i131.i.i.i.i ], [ %sub48.i.i.i150.i.i.i.i, %do.body40.i.i.i153.i.i.i.i ]
  %mul41.i.i.i143.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.2, %guess.i.i.i78.i.i.i.i.2
  %div42.i.i.i144.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %guess.i.i.i78.i.i.i.i.2
  %sub43.i.i.i145.i.i.i.i = fsub double %mul41.i.i.i143.i.i.i.i, %div42.i.i.i144.i.i.i.i
  %mul44.i.i.i146.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i147.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %mul41.i.i.i143.i.i.i.i
  %add46.i.i.i148.i.i.i.i = fadd double %mul44.i.i.i146.i.i.i.i, %div45.i.i.i147.i.i.i.i
  %div47.i.i.i149.i.i.i.i = fdiv double %sub43.i.i.i145.i.i.i.i, %add46.i.i.i148.i.i.i.i
  %sub48.i.i.i150.i.i.i.i = fsub double %guess.i.i.i78.i.i.i.i.2, %div47.i.i.i149.i.i.i.i
  %mul50.i.i.i151.i.i.i.i = fmul double %sub48.i.i.i150.i.i.i.i, 0x3EC0000000000000
  %590 = tail call double @llvm.fabs.f64(double %div47.i.i.i149.i.i.i.i) #3
  %cmp52.i.i.i152.i.i.i.i = fcmp olt double %mul50.i.i.i151.i.i.i.i, %590
  br i1 %cmp52.i.i.i152.i.i.i.i, label %do.body40.i.i.i153.i.i.i.i, label %if.end4.i.i.i.i.i.i.i

if.end4.i.i.i.i.i.i.i:                            ; preds = %do.body40.i.i.i153.i.i.i.i, %do.body.i.i.i142.i.i.i.i
  %guess.i.i.i78.i.i.i.i.3 = phi double [ %mul35.i.i.i139.i.i.i.i, %do.body.i.i.i142.i.i.i.i ], [ %sub48.i.i.i150.i.i.i.i, %do.body40.i.i.i153.i.i.i.i ]
  %591 = fneg double %guess.i.i.i78.i.i.i.i.3
  %592 = select i1 %cmp5.i.i.i91.i.i.i.i, double %591, double %guess.i.i.i78.i.i.i.i.3
  br i1 %cmp11.i.i.i110.i.i.i.i, label %if.then12.i.i.i32.i.i.i.i, label %if.else21.i.i.i44.i.i.i.i

if.then12.i.i.i32.i.i.i.i:                        ; preds = %if.end4.i.i.i.i.i.i.i
  %cmp13.i.i.i31.i.i.i.i = icmp sgt i32 %581, 2
  br i1 %cmp13.i.i.i31.i.i.i.i, label %if.then14.i.i.i37.i.i.i.i, label %if.else.i.i.i43.i.i.i.i

if.then14.i.i.i37.i.i.i.i:                        ; preds = %if.then12.i.i.i32.i.i.i.i
  %sh_prom.i.i.i33.i.i.i.i = zext i32 %div.i.i.i108.i.i.i.i to i64
  %shl.i.i.i34.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i33.i.i.i.i
  %conv.i.i.i35.i.i.i.i = uitofp i64 %shl.i.i.i34.i.i.i.i to double
  %mul.i.i.i36.i.i.i.i = fmul double %add23.i.i.i.i.i107.i.i.i.i, %conv.i.i.i35.i.i.i.i
  br label %if.end23.i.i.i50.i.i.i.i

if.else.i.i.i43.i.i.i.i:                          ; preds = %if.then12.i.i.i32.i.i.i.i
  %sh_prom16.i.i.i39.i.i.i.i = zext i32 %584 to i64
  %shl17.i.i.i40.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i39.i.i.i.i
  %conv18.i.i.i41.i.i.i.i = uitofp i64 %shl17.i.i.i40.i.i.i.i to double
  %div19.i.i.i42.i.i.i.i = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %conv18.i.i.i41.i.i.i.i
  br label %if.end23.i.i.i50.i.i.i.i

if.else21.i.i.i44.i.i.i.i:                        ; preds = %if.end4.i.i.i.i.i.i.i
  %593 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  br label %if.end23.i.i.i50.i.i.i.i

if.end23.i.i.i50.i.i.i.i:                         ; preds = %if.else21.i.i.i44.i.i.i.i, %if.else.i.i.i43.i.i.i.i, %if.then14.i.i.i37.i.i.i.i
  %guess.i.i.i10.i.i.i.i.0 = phi double [ %mul.i.i.i36.i.i.i.i, %if.then14.i.i.i37.i.i.i.i ], [ %div19.i.i.i42.i.i.i.i, %if.else.i.i.i43.i.i.i.i ], [ %593, %if.else21.i.i.i44.i.i.i.i ]
  %mul24.i.i.i48.i.i.i.i = fmul double %588, %guess.i.i.i10.i.i.i.i.0
  br i1 %cmp26.i.i.i130.i.i.i.i, label %do.body.i.i.i61.i.i.i.i, label %do.body40.i.i.i72.i.i.i.i

do.body.i.i.i61.i.i.i.i:                          ; preds = %do.body.i.i.i61.i.i.i.i, %if.end23.i.i.i50.i.i.i.i
  %guess.i.i.i10.i.i.i.i.1 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %mul35.i.i.i58.i.i.i.i, %do.body.i.i.i61.i.i.i.i ]
  %mul28.i.i.i51.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.1, %guess.i.i.i10.i.i.i.i.1
  %mul29.i.i.i52.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.1, %mul28.i.i.i51.i.i.i.i
  %add30.i.i.i53.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %mul29.i.i.i52.i.i.i.i
  %add31.i.i.i54.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add30.i.i.i53.i.i.i.i
  %add32.i.i.i55.i.i.i.i = fadd double %mul29.i.i.i52.i.i.i.i, %mul29.i.i.i52.i.i.i.i
  %add33.i.i.i56.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add32.i.i.i55.i.i.i.i
  %div34.i.i.i57.i.i.i.i = fdiv double %add31.i.i.i54.i.i.i.i, %add33.i.i.i56.i.i.i.i
  %mul35.i.i.i58.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.1, %div34.i.i.i57.i.i.i.i
  %sub36.i.i.i59.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i57.i.i.i.i
  %594 = tail call double @llvm.fabs.f64(double %sub36.i.i.i59.i.i.i.i) #3
  %cmp38.i.i.i60.i.i.i.i = fcmp ogt double %594, 0x3EC0000000000000
  br i1 %cmp38.i.i.i60.i.i.i.i, label %do.body.i.i.i61.i.i.i.i, label %if.end54.i.i.i.i.i.i.i

do.body40.i.i.i72.i.i.i.i:                        ; preds = %do.body40.i.i.i72.i.i.i.i, %if.end23.i.i.i50.i.i.i.i
  %guess.i.i.i10.i.i.i.i.2 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %sub48.i.i.i69.i.i.i.i, %do.body40.i.i.i72.i.i.i.i ]
  %mul41.i.i.i62.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.2, %guess.i.i.i10.i.i.i.i.2
  %div42.i.i.i63.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %guess.i.i.i10.i.i.i.i.2
  %sub43.i.i.i64.i.i.i.i = fsub double %mul41.i.i.i62.i.i.i.i, %div42.i.i.i63.i.i.i.i
  %mul44.i.i.i65.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i66.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %mul41.i.i.i62.i.i.i.i
  %add46.i.i.i67.i.i.i.i = fadd double %mul44.i.i.i65.i.i.i.i, %div45.i.i.i66.i.i.i.i
  %div47.i.i.i68.i.i.i.i = fdiv double %sub43.i.i.i64.i.i.i.i, %add46.i.i.i67.i.i.i.i
  %sub48.i.i.i69.i.i.i.i = fsub double %guess.i.i.i10.i.i.i.i.2, %div47.i.i.i68.i.i.i.i
  %mul50.i.i.i70.i.i.i.i = fmul double %sub48.i.i.i69.i.i.i.i, 0x3EC0000000000000
  %595 = tail call double @llvm.fabs.f64(double %div47.i.i.i68.i.i.i.i) #3
  %cmp52.i.i.i71.i.i.i.i = fcmp olt double %mul50.i.i.i70.i.i.i.i, %595
  br i1 %cmp52.i.i.i71.i.i.i.i, label %do.body40.i.i.i72.i.i.i.i, label %if.end54.i.i.i.i.i.i.i

if.end54.i.i.i.i.i.i.i:                           ; preds = %do.body40.i.i.i72.i.i.i.i, %do.body.i.i.i61.i.i.i.i
  %guess.i.i.i10.i.i.i.i.3 = phi double [ %mul35.i.i.i58.i.i.i.i, %do.body.i.i.i61.i.i.i.i ], [ %sub48.i.i.i69.i.i.i.i, %do.body40.i.i.i72.i.i.i.i ]
  %596 = fneg double %guess.i.i.i10.i.i.i.i.3
  %597 = select i1 %cmp5.i.i.i91.i.i.i.i, double %596, double %guess.i.i.i10.i.i.i.i.3
  br label %if.end7.i.i.i.i.i.i.i

if.end7.i.i.i.i.i.i.i:                            ; preds = %if.end54.i.i.i.i.i.i.i, %if.then73.i.i.i.i
  %retval.0.i.i.i156.i.i.i.i162 = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %592, %if.end54.i.i.i.i.i.i.i ]
  %retval.0.i.i.i.i.i.i.i = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %597, %if.end54.i.i.i.i.i.i.i ]
  %mul76.i.i.i.i = fmul double %retval.0.i.i.i156.i.i.i.i162, %retval.0.i.i.i.i.i.i.i
  %mul79.i.i.i.i = fmul double %mul76.i.i.i.i, 0x3FFD8639FDCB60EB
  %div80.i.i.i.i = fdiv double 1.000000e+00, %mul79.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

cond.false7.i.i.i:                                ; preds = %if.end14.i.i
  %cmp.i4.i.i.i = fcmp ult double %arrayidx.val, 3.750000e-01
  br i1 %cmp.i4.i.i.i, label %if.else.i23.i.i.i, label %if.then.i21.i.i.i

if.then.i21.i.i.i:                                ; preds = %cond.false7.i.i.i
  %sub.i5.i.i.i = fadd double %arrayidx.val, -3.750000e-01
  %mul.i.i.i6.i.i.i = fmul double %sub.i5.i.i.i, %sub.i5.i.i.i
  %mul1.i.i.i7.i.i.i = fmul double %mul.i.i.i6.i.i.i, 0x40132BDEE3243B58
  %add.i.i.i8.i.i.i = fadd double %mul1.i.i.i7.i.i.i, 0xC0360FDD97954BA2
  %mul5.i.i.i9.i.i.i = fmul double %mul.i.i.i6.i.i.i, 0x401CB5EDEDB31A3B
  %add7.i.i.i10.i.i.i = fadd double %mul5.i.i.i9.i.i.i, 0xC017CB97C9E45E0D
  %mul10.i.i.i11.i.i.i = fmul double %mul.i.i.i6.i.i.i, %add.i.i.i8.i.i.i
  %mul12.i.i.i12.i.i.i = fmul double %mul.i.i.i6.i.i.i, %add7.i.i.i10.i.i.i
  %add15.i.i.i13.i.i.i = fadd double %mul10.i.i.i11.i.i.i, 0x4027FEF192CFFD80
  %add18.i.i.i14.i.i.i = fadd double %mul12.i.i.i12.i.i.i, 0x3FF83BDAD25D5F48
  %mul20.i.i.i15.i.i.i = fmul double %mul.i.i.i6.i.i.i, %add15.i.i.i13.i.i.i
  %add23.i.i.i16.i.i.i = fadd double %mul20.i.i.i15.i.i.i, 0xBFF2C5AD0DCDC29A
  %mul25.i.i.i17.i.i.i = fmul double %sub.i5.i.i.i, %add18.i.i.i14.i.i.i
  %add28.i.i.i18.i.i.i = fadd double %mul25.i.i.i17.i.i.i, %add23.i.i.i16.i.i.i
  %mul1.i.i310.i.i.i.i = fmul double %mul.i.i.i6.i.i.i, 0x3FF693D2420640AD
  %598 = fsub double 0x401B5545C0CB5BDA, %mul1.i.i310.i.i.i.i
  %mul5.i.i312.i.i.i.i = fmul double %mul.i.i.i6.i.i.i, 0x40074E9A9F865729
  %add7.i.i313.i.i.i.i = fadd double %mul5.i.i312.i.i.i.i, 0xC016B372910B83AB
  %mul10.i.i314.i.i.i.i = fmul double %mul.i.i.i6.i.i.i, %598
  %mul12.i.i315.i.i.i.i = fmul double %mul.i.i.i6.i.i.i, %add7.i.i313.i.i.i.i
  %add15.i.i316.i.i.i.i = fadd double %mul10.i.i314.i.i.i.i, 0xC0138A29DF206C0B
  %add18.i.i317.i.i.i.i = fadd double %mul12.i.i315.i.i.i.i, 0x3FFC33F0B4C09D66
  %mul20.i.i318.i.i.i.i = fmul double %mul.i.i.i6.i.i.i, %add15.i.i316.i.i.i.i
  %add23.i.i319.i.i.i.i = fadd double %mul20.i.i318.i.i.i.i, 1.000000e+00
  %mul25.i.i320.i.i.i.i = fmul double %sub.i5.i.i.i, %add18.i.i317.i.i.i.i
  %add28.i.i321.i.i.i.i = fadd double %mul25.i.i320.i.i.i.i, %add23.i.i319.i.i.i.i
  %div.i20.i.i.i = fdiv double %add28.i.i.i18.i.i.i, %add28.i.i321.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else.i23.i.i.i:                                ; preds = %cond.false7.i.i.i
  %cmp2.i22.i.i.i = fcmp ult double %arrayidx.val, 2.500000e-01
  br i1 %cmp2.i22.i.i.i, label %if.else9.i28.i.i.i, label %if.then3.i27.i.i.i

if.then3.i27.i.i.i:                               ; preds = %if.else.i23.i.i.i
  %sub5.i24.i.i.i = fadd double %arrayidx.val, -2.500000e-01
  %mul.i.i296.i.i.i.i = fmul double %sub5.i24.i.i.i, %sub5.i24.i.i.i
  %mul1.i.i297.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, 0x402A50B00A1E7B86
  %add.i.i298.i.i.i.i = fadd double %mul1.i.i297.i.i.i.i, 0xC03EAAFBAB179207
  %mul5.i.i299.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, 0x403CBAD71AE3B29A
  %599 = fsub double 0x4040A8BCD7811DE4, %mul5.i.i299.i.i.i.i
  %mul10.i.i301.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, %add.i.i298.i.i.i.i
  %mul12.i.i302.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, %599
  %add15.i.i303.i.i.i.i = fadd double %mul10.i.i301.i.i.i.i, 0x402CB09090084637
  %add18.i.i304.i.i.i.i = fadd double %mul12.i.i302.i.i.i.i, 0xC013B1AD6B90733F
  %mul20.i.i305.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, %add15.i.i303.i.i.i.i
  %add23.i.i306.i.i.i.i = fadd double %mul20.i.i305.i.i.i.i, 0xBFFA1FFFE7A41296
  %mul25.i.i307.i.i.i.i = fmul double %sub5.i24.i.i.i, %add18.i.i304.i.i.i.i
  %add28.i.i308.i.i.i.i = fadd double %mul25.i.i307.i.i.i.i, %add23.i.i306.i.i.i.i
  %mul1.i.i286.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, 0x40296F06194D60C2
  %add.i.i287.i.i.i.i = fadd double %mul1.i.i286.i.i.i.i, 0xC030F25386AA802B
  %mul5.i.i288.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, 0x40199996D51EE9B7
  %600 = fsub double 0x40034649FCCCF81F, %mul5.i.i288.i.i.i.i
  %mul10.i.i290.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, %add.i.i287.i.i.i.i
  %mul12.i.i291.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, %600
  %add15.i.i292.i.i.i.i = fadd double %mul10.i.i290.i.i.i.i, 0x40158CEB587D3265
  %add18.i.i293.i.i.i.i = fadd double %mul12.i.i291.i.i.i.i, 1.000000e+00
  %mul20.i.i294.i.i.i.i = fmul double %sub5.i24.i.i.i, %add15.i.i292.i.i.i.i
  %add23.i.i295.i.i.i.i = fadd double %add18.i.i293.i.i.i.i, %mul20.i.i294.i.i.i.i
  %div8.i26.i.i.i = fdiv double %add28.i.i308.i.i.i.i, %add23.i.i295.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else9.i28.i.i.i:                               ; preds = %if.else.i23.i.i.i
  %cmp10.i.i.i.i = fcmp ult double %arrayidx.val, 1.250000e-01
  %decision.left = xor i1 %cmp10.i.i.i.i, true
  br i1 %cmp10.i.i.i.i, label %if.else17.i.i.i.i, label %decision.gate, !decision.condition_prefix !6

if.then11.i.i.i.i:                                ; preds = %decision.dispatch2
  %sub13.i.i.i.i = fadd double %arrayidx.val, -1.250000e-01
  %mul.i.i270.i.i.i.i = fmul double %sub13.i.i.i.i, %sub13.i.i.i.i
  %mul1.i.i271.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x406D392CDE09E490
  %601 = fsub double 0x408C7AAA9D225E9A, %mul1.i.i271.i.i.i.i
  %mul5.i.i273.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x408B6249334DA816
  %602 = fsub double 0x408C1B9BAF952B96, %mul5.i.i273.i.i.i.i
  %mul10.i.i275.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %601
  %mul12.i.i276.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %602
  %add15.i.i277.i.i.i.i = fadd double %mul10.i.i275.i.i.i.i, 0xC05E9BCF5C362E51
  %add18.i.i278.i.i.i.i = fadd double %mul12.i.i276.i.i.i.i, 0xC066A4A24A4E1713
  %mul20.i.i279.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add15.i.i277.i.i.i.i
  %mul22.i.i280.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add18.i.i278.i.i.i.i
  %add25.i.i281.i.i.i.i = fadd double %mul20.i.i279.i.i.i.i, 0xC04249A2BD20D346
  %add28.i.i282.i.i.i.i = fadd double %mul22.i.i280.i.i.i.i, 0xC001804F92FE2A82
  %mul30.i.i283.i.i.i.i = fmul double %sub13.i.i.i.i, %add25.i.i281.i.i.i.i
  %add33.i.i284.i.i.i.i = fadd double %add28.i.i282.i.i.i.i, %mul30.i.i283.i.i.i.i
  %mul1.i.i256.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x405E5232607614DB
  %add.i.i257.i.i.i.i = fadd double %mul1.i.i256.i.i.i.i, 0xC0809E1D789AFFE5
  %mul5.i.i258.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x404C078043CB129C
  %603 = fsub double 0xC0320C17B7F0ED52, %mul5.i.i258.i.i.i.i
  %mul10.i.i260.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add.i.i257.i.i.i.i
  %mul12.i.i261.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %603
  %add15.i.i262.i.i.i.i = fadd double %mul10.i.i260.i.i.i.i, 0x4071A64A34042F35
  %add18.i.i263.i.i.i.i = fadd double %mul12.i.i261.i.i.i.i, 0x405F12CC60181A8F
  %mul20.i.i264.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add15.i.i262.i.i.i.i
  %mul22.i.i265.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add18.i.i263.i.i.i.i
  %add25.i.i266.i.i.i.i = fadd double %mul20.i.i264.i.i.i.i, 0x40332E0500972875
  %add28.i.i267.i.i.i.i = fadd double %mul22.i.i265.i.i.i.i, 1.000000e+00
  %mul30.i.i268.i.i.i.i = fmul double %sub13.i.i.i.i, %add25.i.i266.i.i.i.i
  %add33.i.i269.i.i.i.i = fadd double %add28.i.i267.i.i.i.i, %mul30.i.i268.i.i.i.i
  %div16.i.i.i.i = fdiv double %add33.i.i284.i.i.i.i, %add33.i.i269.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i.pair.join

if.else17.i.i.i.i:                                ; preds = %if.else9.i28.i.i.i
  %604 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %arrayidx.val) #3
  %605 = add nsw i32 %604, -1
  %606 = tail call double @llvm.fabs.f64(double %arrayidx.val) #4
  %607 = fcmp oeq double %606, 0x7FF0000000000000
  %608 = select i1 %607, i32 2147483647, i32 %605
  %609 = fcmp oeq double %arrayidx.val, 0.000000e+00
  %610 = select i1 %609, i32 -2147483648, i32 %608
  %cmp19.i.i.i.i = icmp sgt i32 %610, -5
  br label %decision.gate

decision.gate:                                    ; preds = %if.else17.i.i.i.i, %if.else9.i28.i.i.i
  %decision.value = phi i32 [ undef, %if.else9.i28.i.i.i ], [ %610, %if.else17.i.i.i.i ]
  %decision.take = phi i1 [ true, %if.else9.i28.i.i.i ], [ %cmp19.i.i.i.i, %if.else17.i.i.i.i ]
  br i1 %decision.take, label %decision.dispatch2, label %if.else27.i.i.i.i, !decision.short_gate !6

decision.dispatch2:                               ; preds = %decision.gate
  br i1 %decision.left, label %if.then11.i.i.i.i, label %if.then20.i.i.i.i, !decision.merged_from !12, !decision.origin !13

if.then20.i.i.i.i:                                ; preds = %decision.dispatch2
  %611 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 3) #3
  %612 = tail call double @llvm.amdgcn.frexp.mant.f64(double %611) #3
  %613 = fcmp olt double %612, 0x3FE5555555555555
  %614 = zext i1 %613 to i32
  %615 = tail call double @llvm.amdgcn.ldexp.f64(double %612, i32 %614) #3
  %616 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %611) #3
  %617 = sub nsw i32 %616, %614
  %618 = fadd double %615, -1.000000e+00
  %619 = fadd double %615, 1.000000e+00
  %620 = fsub double %619, %615
  %621 = fsub double %619, %620
  %622 = fsub double %615, %621
  %623 = fsub double 1.000000e+00, %620
  %624 = fadd double %623, %622
  %625 = tail call double @llvm.amdgcn.rcp.f64(double %619) #3
  %626 = fneg double %619
  %627 = tail call double @llvm.fma.f64(double %626, double %625, double 1.000000e+00) #3
  %628 = tail call double @llvm.fma.f64(double %627, double %625, double %625) #3
  %629 = tail call double @llvm.fma.f64(double %626, double %628, double 1.000000e+00) #3
  %630 = tail call double @llvm.fma.f64(double %629, double %628, double %628) #3
  %631 = fmul double %618, %630
  %632 = fmul double %619, %631
  %633 = fneg double %632
  %634 = tail call double @llvm.fma.f64(double %631, double %619, double %633) #3
  %635 = tail call double @llvm.fma.f64(double %631, double %624, double %634) #3
  %636 = fadd double %632, %635
  %637 = fsub double %636, %632
  %638 = fsub double %635, %637
  %639 = fsub double %618, %636
  %640 = fsub double %618, %639
  %641 = fsub double %640, %636
  %642 = fsub double %641, %638
  %643 = fadd double %639, %642
  %644 = fmul double %630, %643
  %645 = fadd double %631, %644
  %646 = fsub double %645, %631
  %647 = fsub double %644, %646
  %648 = fmul double %645, %645
  %649 = fneg double %648
  %650 = tail call double @llvm.fma.f64(double %645, double %645, double %649) #3
  %651 = fmul double %647, 2.000000e+00
  %652 = tail call double @llvm.fma.f64(double %645, double %651, double %650) #3
  %653 = tail call double @llvm.fma.f64(double %647, double %647, double %652) #3
  %654 = fadd double %648, %653
  %655 = fsub double %654, %648
  %656 = fsub double %653, %655
  %657 = tail call double @llvm.fma.f64(double %654, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %658 = tail call double @llvm.fma.f64(double %654, double %657, double 0x3FC7474DD7F4DF2E) #3
  %659 = tail call double @llvm.fma.f64(double %654, double %658, double 0x3FCC71C016291751) #3
  %660 = tail call double @llvm.fma.f64(double %654, double %659, double 0x3FD249249B27ACF1) #3
  %661 = tail call double @llvm.fma.f64(double %654, double %660, double 0x3FD99999998EF7B6) #3
  %662 = tail call double @llvm.fma.f64(double %654, double %661, double 0x3FE5555555555780) #3
  %663 = tail call double @llvm.amdgcn.ldexp.f64(double %645, i32 1) #3
  %664 = tail call double @llvm.amdgcn.ldexp.f64(double %647, i32 1) #3
  %665 = fmul double %645, %654
  %666 = fneg double %665
  %667 = tail call double @llvm.fma.f64(double %645, double %654, double %666) #3
  %668 = fmul double %647, %654
  %669 = tail call double @llvm.fma.f64(double %645, double %656, double %668) #3
  %670 = fadd double %667, %669
  %671 = fadd double %665, %670
  %672 = fsub double %671, %665
  %673 = fsub double %670, %672
  %674 = fmul double %671, %662
  %675 = fneg double %674
  %676 = tail call double @llvm.fma.f64(double %671, double %662, double %675) #3
  %677 = tail call double @llvm.fma.f64(double %673, double %662, double %676) #3
  %678 = fadd double %674, %677
  %679 = fsub double %678, %674
  %680 = fsub double %677, %679
  %681 = fadd double %663, %678
  %682 = fsub double %681, %663
  %683 = fsub double %681, %682
  %684 = fsub double %663, %683
  %685 = fsub double %678, %682
  %686 = fadd double %685, %684
  %687 = fadd double %664, %680
  %688 = fsub double %687, %664
  %689 = fsub double %687, %688
  %690 = fsub double %664, %689
  %691 = fsub double %680, %688
  %692 = fadd double %691, %690
  %693 = fadd double %687, %686
  %694 = fadd double %681, %693
  %695 = fsub double %694, %681
  %696 = fsub double %693, %695
  %697 = fadd double %692, %696
  %698 = fadd double %694, %697
  %699 = fsub double %698, %694
  %700 = fsub double %697, %699
  %701 = sitofp i32 %617 to double
  %702 = fmul double %698, 0x3FF71547652B82FE
  %703 = fneg double %702
  %704 = fmul double %698, 0x3C7777D0FFDA0D24
  %705 = insertelement <2 x double> undef, double %698, i32 0
  %706 = insertelement <2 x double> %705, double %700, i32 1
  %707 = insertelement <2 x double> undef, double %703, i32 0
  %708 = insertelement <2 x double> %707, double %704, i32 1
  %709 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %706, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %708) #3
  %710 = extractelement <2 x double> %709, i32 0
  %711 = extractelement <2 x double> %709, i32 1
  %712 = fadd double %710, %711
  %713 = fadd double %702, %712
  %714 = fsub double %713, %702
  %715 = fsub double %712, %714
  %716 = fadd double %713, %701
  %717 = fsub double %716, %701
  %718 = fsub double %717, %716
  %719 = fadd double %718, %701
  %720 = fsub double %713, %717
  %721 = fadd double %720, %719
  %722 = fadd double %715, %721
  %723 = fadd double %716, %722
  %724 = tail call double @llvm.fabs.f64(double %611) #4
  %725 = fcmp oeq double %724, 0x7FF0000000000000
  %726 = select i1 %725, double %611, double %723
  %727 = fcmp olt double %611, 0.000000e+00
  %728 = select i1 %727, double 0x7FF8000000000000, double %726
  %729 = fcmp oeq double %611, 0.000000e+00
  %730 = select i1 %729, double 0xFFF0000000000000, double %728
  %mul.i.i244.i.i.i.i = fmul double %730, %730
  %mul1.i.i245.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F1989D450BBA5CA
  %731 = fsub double 0xBFBD94CCEC41CB08, %mul1.i.i245.i.i.i.i
  %mul5.i.i247.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F7B3A00DD9C9429
  %732 = fsub double 0xBFE8DDD719DA7D3E, %mul5.i.i247.i.i.i.i
  %mul10.i.i249.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %731
  %mul12.i.i250.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %732
  %add15.i.i251.i.i.i.i = fadd double %mul10.i.i249.i.i.i.i, 0xC001974D2C397C76
  %add18.i.i252.i.i.i.i = fadd double %mul12.i.i250.i.i.i.i, 0xC001804F92FE2A82
  %733 = fmul double %730, %add15.i.i251.i.i.i.i
  %add23.i.i254.i.i.i.i = fsub double %add18.i.i252.i.i.i.i, %733
  %mul1.i.i234.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3EDBEC7AF5AC0D6F
  %add.i.i235.i.i.i.i = fadd double %mul1.i.i234.i.i.i.i, 0x3F98BA1DB321D0E9
  %mul5.i.i236.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F4ED662BB480251
  %add7.i.i237.i.i.i.i = fadd double %mul5.i.i236.i.i.i.i, 0x3FCBD444F5D4FCC2
  %mul10.i.i238.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %add.i.i235.i.i.i.i
  %mul12.i.i239.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %add7.i.i237.i.i.i.i
  %add15.i.i240.i.i.i.i = fadd double %mul10.i.i238.i.i.i.i, 0x3FE957680773BEB6
  %add18.i.i241.i.i.i.i = fadd double %mul12.i.i239.i.i.i.i, 1.000000e+00
  %734 = fmul double %730, %add15.i.i240.i.i.i.i
  %add23.i.i243.i.i.i.i = fsub double %add18.i.i241.i.i.i.i, %734
  %div26.i.i.i.i = fdiv double %add23.i.i254.i.i.i.i, %add23.i.i243.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i.pair.join

if.else27.i.i.i.i:                                ; preds = %decision.gate
  %cmp40.i.i.i.i = icmp sgt i32 %decision.value, -17
  br i1 %cmp40.i.i.i.i, label %decision.dispatch, label %if.else49.i32.i.i.i, !decision.condition_prefix !6

decision.dispatch:                                ; preds = %if.else27.i.i.i.i
  %cmp29.i.i.i.i = icmp sgt i32 %decision.value, -9
  %735 = select i1 %cmp29.i.i.i.i, i32 4, i32 8
  %736 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %735) #3
  %737 = tail call double @llvm.amdgcn.frexp.mant.f64(double %736) #3
  %738 = fcmp olt double %737, 0x3FE5555555555555
  %739 = zext i1 %738 to i32
  %740 = tail call double @llvm.amdgcn.ldexp.f64(double %737, i32 %739) #3
  %741 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %736) #3
  %742 = sub nsw i32 %741, %739
  %743 = fadd double %740, -1.000000e+00
  %744 = fadd double %740, 1.000000e+00
  %745 = fsub double %744, %740
  %746 = fsub double %744, %745
  %747 = fsub double %740, %746
  %748 = fsub double 1.000000e+00, %745
  %749 = fadd double %748, %747
  %750 = tail call double @llvm.amdgcn.rcp.f64(double %744) #3
  %751 = fneg double %744
  %752 = tail call double @llvm.fma.f64(double %751, double %750, double 1.000000e+00) #3
  %753 = tail call double @llvm.fma.f64(double %752, double %750, double %750) #3
  %754 = tail call double @llvm.fma.f64(double %751, double %753, double 1.000000e+00) #3
  %755 = tail call double @llvm.fma.f64(double %754, double %753, double %753) #3
  %756 = fmul double %743, %755
  %757 = fmul double %744, %756
  %758 = fneg double %757
  %759 = tail call double @llvm.fma.f64(double %756, double %744, double %758) #3
  %760 = tail call double @llvm.fma.f64(double %756, double %749, double %759) #3
  %761 = fadd double %757, %760
  %762 = fsub double %761, %757
  %763 = fsub double %760, %762
  %764 = fsub double %743, %761
  %765 = fsub double %743, %764
  %766 = fsub double %765, %761
  %767 = fsub double %766, %763
  %768 = fadd double %764, %767
  %769 = fmul double %755, %768
  %770 = fadd double %756, %769
  %771 = fsub double %770, %756
  %772 = fsub double %769, %771
  %773 = fmul double %770, %770
  %774 = fneg double %773
  %775 = tail call double @llvm.fma.f64(double %770, double %770, double %774) #3
  %776 = fmul double %772, 2.000000e+00
  %777 = tail call double @llvm.fma.f64(double %770, double %776, double %775) #3
  %778 = tail call double @llvm.fma.f64(double %772, double %772, double %777) #3
  %779 = fadd double %773, %778
  %780 = fsub double %779, %773
  %781 = fsub double %778, %780
  %782 = tail call double @llvm.fma.f64(double %779, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %783 = tail call double @llvm.fma.f64(double %779, double %782, double 0x3FC7474DD7F4DF2E) #3
  %784 = tail call double @llvm.fma.f64(double %779, double %783, double 0x3FCC71C016291751) #3
  %785 = tail call double @llvm.fma.f64(double %779, double %784, double 0x3FD249249B27ACF1) #3
  %786 = tail call double @llvm.fma.f64(double %779, double %785, double 0x3FD99999998EF7B6) #3
  %787 = tail call double @llvm.fma.f64(double %779, double %786, double 0x3FE5555555555780) #3
  %788 = tail call double @llvm.amdgcn.ldexp.f64(double %770, i32 1) #3
  %789 = tail call double @llvm.amdgcn.ldexp.f64(double %772, i32 1) #3
  %790 = fmul double %770, %779
  %791 = fneg double %790
  %792 = tail call double @llvm.fma.f64(double %770, double %779, double %791) #3
  %793 = fmul double %772, %779
  %794 = tail call double @llvm.fma.f64(double %770, double %781, double %793) #3
  %795 = fadd double %792, %794
  %796 = fadd double %790, %795
  %797 = fsub double %796, %790
  %798 = fsub double %795, %797
  %799 = fmul double %796, %787
  %800 = fneg double %799
  %801 = tail call double @llvm.fma.f64(double %796, double %787, double %800) #3
  %802 = tail call double @llvm.fma.f64(double %798, double %787, double %801) #3
  %803 = fadd double %799, %802
  %804 = fsub double %803, %799
  %805 = fsub double %802, %804
  %806 = fadd double %788, %803
  %807 = fsub double %806, %788
  %808 = fsub double %806, %807
  %809 = fsub double %788, %808
  %810 = fsub double %803, %807
  %811 = fadd double %810, %809
  %812 = fadd double %789, %805
  %813 = fsub double %812, %789
  %814 = fsub double %812, %813
  %815 = fsub double %789, %814
  %816 = fsub double %805, %813
  %817 = fadd double %816, %815
  %818 = fadd double %812, %811
  %819 = fadd double %806, %818
  %820 = fsub double %819, %806
  %821 = fsub double %818, %820
  %822 = fadd double %817, %821
  %823 = fadd double %819, %822
  %824 = fsub double %823, %819
  %825 = fsub double %822, %824
  %826 = sitofp i32 %742 to double
  %827 = fmul double %823, 0x3FF71547652B82FE
  %828 = fneg double %827
  %829 = fmul double %823, 0x3C7777D0FFDA0D24
  br i1 %cmp29.i.i.i.i, label %fusion.side, label %fusion.side1

if.else49.i32.i.i.i:                              ; preds = %if.else27.i.i.i.i
  %cmp62.i.i.i.i = icmp sgt i32 %decision.value, -65
  br i1 %cmp62.i.i.i.i, label %decision.dispatch1, label %if.else71.i37.i.i.i, !decision.condition_prefix !6

decision.dispatch1:                               ; preds = %if.else49.i32.i.i.i
  %cmp51.i31.i.i.i = icmp sgt i32 %decision.value, -33
  %830 = select i1 %cmp51.i31.i.i.i, i32 16, i32 32
  %831 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %830) #3
  %832 = tail call double @llvm.amdgcn.frexp.mant.f64(double %831) #3
  %833 = fcmp olt double %832, 0x3FE5555555555555
  %834 = zext i1 %833 to i32
  %835 = tail call double @llvm.amdgcn.ldexp.f64(double %832, i32 %834) #3
  %836 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %831) #3
  %837 = sub nsw i32 %836, %834
  %838 = fadd double %835, -1.000000e+00
  %839 = fadd double %835, 1.000000e+00
  %840 = fsub double %839, %835
  %841 = fsub double %839, %840
  %842 = fsub double %835, %841
  %843 = fsub double 1.000000e+00, %840
  %844 = fadd double %843, %842
  %845 = tail call double @llvm.amdgcn.rcp.f64(double %839) #3
  %846 = fneg double %839
  %847 = tail call double @llvm.fma.f64(double %846, double %845, double 1.000000e+00) #3
  %848 = tail call double @llvm.fma.f64(double %847, double %845, double %845) #3
  %849 = tail call double @llvm.fma.f64(double %846, double %848, double 1.000000e+00) #3
  %850 = tail call double @llvm.fma.f64(double %849, double %848, double %848) #3
  %851 = fmul double %838, %850
  %852 = fmul double %839, %851
  %853 = fneg double %852
  %854 = tail call double @llvm.fma.f64(double %851, double %839, double %853) #3
  %855 = tail call double @llvm.fma.f64(double %851, double %844, double %854) #3
  %856 = fadd double %852, %855
  %857 = fsub double %856, %852
  %858 = fsub double %855, %857
  %859 = fsub double %838, %856
  %860 = fsub double %838, %859
  %861 = fsub double %860, %856
  %862 = fsub double %861, %858
  %863 = fadd double %859, %862
  %864 = fmul double %850, %863
  %865 = fadd double %851, %864
  %866 = fsub double %865, %851
  %867 = fsub double %864, %866
  %868 = fmul double %865, %865
  %869 = fneg double %868
  %870 = tail call double @llvm.fma.f64(double %865, double %865, double %869) #3
  %871 = fmul double %867, 2.000000e+00
  %872 = tail call double @llvm.fma.f64(double %865, double %871, double %870) #3
  %873 = tail call double @llvm.fma.f64(double %867, double %867, double %872) #3
  %874 = fadd double %868, %873
  %875 = fsub double %874, %868
  %876 = fsub double %873, %875
  %877 = tail call double @llvm.fma.f64(double %874, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %878 = tail call double @llvm.fma.f64(double %874, double %877, double 0x3FC7474DD7F4DF2E) #3
  %879 = tail call double @llvm.fma.f64(double %874, double %878, double 0x3FCC71C016291751) #3
  %880 = tail call double @llvm.fma.f64(double %874, double %879, double 0x3FD249249B27ACF1) #3
  %881 = tail call double @llvm.fma.f64(double %874, double %880, double 0x3FD99999998EF7B6) #3
  %882 = tail call double @llvm.fma.f64(double %874, double %881, double 0x3FE5555555555780) #3
  %883 = tail call double @llvm.amdgcn.ldexp.f64(double %865, i32 1) #3
  %884 = tail call double @llvm.amdgcn.ldexp.f64(double %867, i32 1) #3
  %885 = fmul double %865, %874
  %886 = fneg double %885
  %887 = tail call double @llvm.fma.f64(double %865, double %874, double %886) #3
  %888 = fmul double %867, %874
  %889 = tail call double @llvm.fma.f64(double %865, double %876, double %888) #3
  %890 = fadd double %887, %889
  %891 = fadd double %885, %890
  %892 = fsub double %891, %885
  %893 = fsub double %890, %892
  %894 = fmul double %891, %882
  %895 = fneg double %894
  %896 = tail call double @llvm.fma.f64(double %891, double %882, double %895) #3
  %897 = tail call double @llvm.fma.f64(double %893, double %882, double %896) #3
  %898 = fadd double %894, %897
  %899 = fsub double %898, %894
  %900 = fsub double %897, %899
  %901 = fadd double %883, %898
  %902 = fsub double %901, %883
  %903 = fsub double %901, %902
  %904 = fsub double %883, %903
  %905 = fsub double %898, %902
  %906 = fadd double %905, %904
  %907 = fadd double %884, %900
  %908 = fsub double %907, %884
  %909 = fsub double %907, %908
  %910 = fsub double %884, %909
  %911 = fsub double %900, %908
  %912 = fadd double %911, %910
  %913 = fadd double %907, %906
  %914 = fadd double %901, %913
  %915 = fsub double %914, %901
  %916 = fsub double %913, %915
  %917 = fadd double %912, %916
  %918 = fadd double %914, %917
  %919 = fsub double %918, %914
  %920 = fsub double %917, %919
  %921 = sitofp i32 %837 to double
  %922 = fmul double %918, 0x3FF71547652B82FE
  %923 = fneg double %922
  %924 = fmul double %918, 0x3C7777D0FFDA0D24
  br i1 %cmp51.i31.i.i.i, label %fusion.side2, label %fusion.side3

if.else71.i37.i.i.i:                              ; preds = %if.else49.i32.i.i.i
  %cmp73.i.i.i.i = icmp sgt i32 %decision.value, -129
  br i1 %cmp73.i.i.i.i, label %if.then74.i.i.i.i, label %if.else82.i.i.i.i

if.then74.i.i.i.i:                                ; preds = %if.else71.i37.i.i.i
  %925 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 64) #3
  %926 = tail call double @llvm.amdgcn.frexp.mant.f64(double %925) #3
  %927 = fcmp olt double %926, 0x3FE5555555555555
  %928 = zext i1 %927 to i32
  %929 = tail call double @llvm.amdgcn.ldexp.f64(double %926, i32 %928) #3
  %930 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %925) #3
  %931 = sub nsw i32 %930, %928
  %932 = fadd double %929, -1.000000e+00
  %933 = fadd double %929, 1.000000e+00
  %934 = fsub double %933, %929
  %935 = fsub double %933, %934
  %936 = fsub double %929, %935
  %937 = fsub double 1.000000e+00, %934
  %938 = fadd double %937, %936
  %939 = tail call double @llvm.amdgcn.rcp.f64(double %933) #3
  %940 = fneg double %933
  %941 = tail call double @llvm.fma.f64(double %940, double %939, double 1.000000e+00) #3
  %942 = tail call double @llvm.fma.f64(double %941, double %939, double %939) #3
  %943 = tail call double @llvm.fma.f64(double %940, double %942, double 1.000000e+00) #3
  %944 = tail call double @llvm.fma.f64(double %943, double %942, double %942) #3
  %945 = fmul double %932, %944
  %946 = fmul double %933, %945
  %947 = fneg double %946
  %948 = tail call double @llvm.fma.f64(double %945, double %933, double %947) #3
  %949 = tail call double @llvm.fma.f64(double %945, double %938, double %948) #3
  %950 = fadd double %946, %949
  %951 = fsub double %950, %946
  %952 = fsub double %949, %951
  %953 = fsub double %932, %950
  %954 = fsub double %932, %953
  %955 = fsub double %954, %950
  %956 = fsub double %955, %952
  %957 = fadd double %953, %956
  %958 = fmul double %944, %957
  %959 = fadd double %945, %958
  %960 = fsub double %959, %945
  %961 = fsub double %958, %960
  %962 = fmul double %959, %959
  %963 = fneg double %962
  %964 = tail call double @llvm.fma.f64(double %959, double %959, double %963) #3
  %965 = fmul double %961, 2.000000e+00
  %966 = tail call double @llvm.fma.f64(double %959, double %965, double %964) #3
  %967 = tail call double @llvm.fma.f64(double %961, double %961, double %966) #3
  %968 = fadd double %962, %967
  %969 = fsub double %968, %962
  %970 = fsub double %967, %969
  %971 = tail call double @llvm.fma.f64(double %968, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %972 = tail call double @llvm.fma.f64(double %968, double %971, double 0x3FC7474DD7F4DF2E) #3
  %973 = tail call double @llvm.fma.f64(double %968, double %972, double 0x3FCC71C016291751) #3
  %974 = tail call double @llvm.fma.f64(double %968, double %973, double 0x3FD249249B27ACF1) #3
  %975 = tail call double @llvm.fma.f64(double %968, double %974, double 0x3FD99999998EF7B6) #3
  %976 = tail call double @llvm.fma.f64(double %968, double %975, double 0x3FE5555555555780) #3
  %977 = tail call double @llvm.amdgcn.ldexp.f64(double %959, i32 1) #3
  %978 = tail call double @llvm.amdgcn.ldexp.f64(double %961, i32 1) #3
  %979 = fmul double %959, %968
  %980 = fneg double %979
  %981 = tail call double @llvm.fma.f64(double %959, double %968, double %980) #3
  %982 = fmul double %961, %968
  %983 = tail call double @llvm.fma.f64(double %959, double %970, double %982) #3
  %984 = fadd double %981, %983
  %985 = fadd double %979, %984
  %986 = fsub double %985, %979
  %987 = fsub double %984, %986
  %988 = fmul double %985, %976
  %989 = fneg double %988
  %990 = tail call double @llvm.fma.f64(double %985, double %976, double %989) #3
  %991 = tail call double @llvm.fma.f64(double %987, double %976, double %990) #3
  %992 = fadd double %988, %991
  %993 = fsub double %992, %988
  %994 = fsub double %991, %993
  %995 = fadd double %977, %992
  %996 = fsub double %995, %977
  %997 = fsub double %995, %996
  %998 = fsub double %977, %997
  %999 = fsub double %992, %996
  %1000 = fadd double %999, %998
  %1001 = fadd double %978, %994
  %1002 = fsub double %1001, %978
  %1003 = fsub double %1001, %1002
  %1004 = fsub double %978, %1003
  %1005 = fsub double %994, %1002
  %1006 = fadd double %1005, %1004
  %1007 = fadd double %1001, %1000
  %1008 = fadd double %995, %1007
  %1009 = fsub double %1008, %995
  %1010 = fsub double %1007, %1009
  %1011 = fadd double %1006, %1010
  %1012 = fadd double %1008, %1011
  %1013 = fsub double %1012, %1008
  %1014 = fsub double %1011, %1013
  %1015 = sitofp i32 %931 to double
  %1016 = fmul double %1012, 0x3FF71547652B82FE
  %1017 = fneg double %1016
  %1018 = fmul double %1012, 0x3C7777D0FFDA0D24
  %1019 = insertelement <2 x double> undef, double %1012, i32 0
  %1020 = insertelement <2 x double> %1019, double %1014, i32 1
  %1021 = insertelement <2 x double> undef, double %1017, i32 0
  %1022 = insertelement <2 x double> %1021, double %1018, i32 1
  %1023 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1020, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1022) #3
  %1024 = extractelement <2 x double> %1023, i32 0
  %1025 = extractelement <2 x double> %1023, i32 1
  %1026 = fadd double %1024, %1025
  %1027 = fadd double %1016, %1026
  %1028 = fsub double %1027, %1016
  %1029 = fsub double %1026, %1028
  %1030 = fadd double %1027, %1015
  %1031 = fsub double %1030, %1015
  %1032 = fsub double %1031, %1030
  %1033 = fadd double %1032, %1015
  %1034 = fsub double %1027, %1031
  %1035 = fadd double %1034, %1033
  %1036 = fadd double %1029, %1035
  %1037 = fadd double %1030, %1036
  %1038 = tail call double @llvm.fabs.f64(double %925) #4
  %1039 = fcmp oeq double %1038, 0x7FF0000000000000
  %1040 = select i1 %1039, double %925, double %1037
  %1041 = fcmp olt double %925, 0.000000e+00
  %1042 = select i1 %1041, double 0x7FF8000000000000, double %1040
  %1043 = fcmp oeq double %925, 0.000000e+00
  %1044 = select i1 %1043, double 0xFFF0000000000000, double %1042
  %mul.i.i106.i.i.i.i = fmul double %1044, %1044
  %mul1.i.i107.i.i.i.i = fmul double %mul.i.i106.i.i.i.i, 0x3C819FA1E5E36C20
  %1045 = fsub double 0xBE050B1B8007F8FF, %mul1.i.i107.i.i.i.i
  %mul5.i.i109.i.i.i.i = fmul double %mul.i.i106.i.i.i.i, 0x3D5CB3C39661DD79
  %1046 = fsub double 0xBE94B8A80FB81310, %mul5.i.i109.i.i.i.i
  %mul10.i.i111.i.i.i.i = fmul double %mul.i.i106.i.i.i.i, %1045
  %mul12.i.i112.i.i.i.i = fmul double %mul.i.i106.i.i.i.i, %1046
  %add15.i.i113.i.i.i.i = fadd double %mul10.i.i111.i.i.i.i, 0xBF1232A95F4E8466
  %add18.i.i114.i.i.i.i = fadd double %mul12.i.i112.i.i.i.i, 0xBF7F5FDEC6827012
  %mul20.i.i115.i.i.i.i = fmul double %mul.i.i106.i.i.i.i, %add15.i.i113.i.i.i.i
  %mul22.i.i116.i.i.i.i = fmul double %mul.i.i106.i.i.i.i, %add18.i.i114.i.i.i.i
  %add25.i.i117.i.i.i.i = fadd double %mul20.i.i115.i.i.i.i, 0xBFD9F6368DFEFDDF
  %add28.i.i118.i.i.i.i = fadd double %mul22.i.i116.i.i.i.i, 0xC0207852FA1731C0
  %1047 = fmul double %1044, %add25.i.i117.i.i.i.i
  %add33.i.i120.i.i.i.i = fsub double %add28.i.i118.i.i.i.i, %1047
  %mul1.i.i94.i.i.i.i = fmul double %mul.i.i106.i.i.i.i, 0x3D0A81E9CB6A1EA5
  %add.i.i95.i.i.i.i = fadd double %mul1.i.i94.i.i.i.i, 0x3E553724D72BE5C7
  %mul5.i.i96.i.i.i.i = fmul double %mul.i.i106.i.i.i.i, 0x3DC001D96C7E2C9D
  %add7.i.i97.i.i.i.i = fadd double %mul5.i.i96.i.i.i.i, 0x3ED71590B83839D8
  %mul10.i.i98.i.i.i.i = fmul double %mul.i.i106.i.i.i.i, %add.i.i95.i.i.i.i
  %mul12.i.i99.i.i.i.i = fmul double %mul.i.i106.i.i.i.i, %add7.i.i97.i.i.i.i
  %add15.i.i100.i.i.i.i = fadd double %mul10.i.i98.i.i.i.i, 0x3F478C82425FFDCE
  %add18.i.i101.i.i.i.i = fadd double %mul12.i.i99.i.i.i.i, 0x3FA66506CA3FCEB3
  %mul20.i.i102.i.i.i.i = fmul double %mul.i.i106.i.i.i.i, %add15.i.i100.i.i.i.i
  %add23.i.i103.i.i.i.i = fadd double %mul20.i.i102.i.i.i.i, 1.000000e+00
  %1048 = fmul double %1044, %add18.i.i101.i.i.i.i
  %add28.i.i105.i.i.i.i = fsub double %add23.i.i103.i.i.i.i, %1048
  %div81.i.i.i.i = fdiv double %add33.i.i120.i.i.i.i, %add28.i.i105.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else82.i.i.i.i:                                ; preds = %if.else71.i37.i.i.i
  %cmp84.i.i.i.i = icmp sgt i32 %decision.value, -257
  br i1 %cmp84.i.i.i.i, label %if.then85.i.i.i.i, label %if.else93.i.i.i.i

if.then85.i.i.i.i:                                ; preds = %if.else82.i.i.i.i
  %1049 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 128) #3
  %1050 = tail call double @llvm.amdgcn.frexp.mant.f64(double %1049) #3
  %1051 = fcmp olt double %1050, 0x3FE5555555555555
  %1052 = zext i1 %1051 to i32
  %1053 = tail call double @llvm.amdgcn.ldexp.f64(double %1050, i32 %1052) #3
  %1054 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %1049) #3
  %1055 = sub nsw i32 %1054, %1052
  %1056 = fadd double %1053, -1.000000e+00
  %1057 = fadd double %1053, 1.000000e+00
  %1058 = fsub double %1057, %1053
  %1059 = fsub double %1057, %1058
  %1060 = fsub double %1053, %1059
  %1061 = fsub double 1.000000e+00, %1058
  %1062 = fadd double %1061, %1060
  %1063 = tail call double @llvm.amdgcn.rcp.f64(double %1057) #3
  %1064 = fneg double %1057
  %1065 = tail call double @llvm.fma.f64(double %1064, double %1063, double 1.000000e+00) #3
  %1066 = tail call double @llvm.fma.f64(double %1065, double %1063, double %1063) #3
  %1067 = tail call double @llvm.fma.f64(double %1064, double %1066, double 1.000000e+00) #3
  %1068 = tail call double @llvm.fma.f64(double %1067, double %1066, double %1066) #3
  %1069 = fmul double %1056, %1068
  %1070 = fmul double %1057, %1069
  %1071 = fneg double %1070
  %1072 = tail call double @llvm.fma.f64(double %1069, double %1057, double %1071) #3
  %1073 = tail call double @llvm.fma.f64(double %1069, double %1062, double %1072) #3
  %1074 = fadd double %1070, %1073
  %1075 = fsub double %1074, %1070
  %1076 = fsub double %1073, %1075
  %1077 = fsub double %1056, %1074
  %1078 = fsub double %1056, %1077
  %1079 = fsub double %1078, %1074
  %1080 = fsub double %1079, %1076
  %1081 = fadd double %1077, %1080
  %1082 = fmul double %1068, %1081
  %1083 = fadd double %1069, %1082
  %1084 = fsub double %1083, %1069
  %1085 = fsub double %1082, %1084
  %1086 = fmul double %1083, %1083
  %1087 = fneg double %1086
  %1088 = tail call double @llvm.fma.f64(double %1083, double %1083, double %1087) #3
  %1089 = fmul double %1085, 2.000000e+00
  %1090 = tail call double @llvm.fma.f64(double %1083, double %1089, double %1088) #3
  %1091 = tail call double @llvm.fma.f64(double %1085, double %1085, double %1090) #3
  %1092 = fadd double %1086, %1091
  %1093 = fsub double %1092, %1086
  %1094 = fsub double %1091, %1093
  %1095 = tail call double @llvm.fma.f64(double %1092, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %1096 = tail call double @llvm.fma.f64(double %1092, double %1095, double 0x3FC7474DD7F4DF2E) #3
  %1097 = tail call double @llvm.fma.f64(double %1092, double %1096, double 0x3FCC71C016291751) #3
  %1098 = tail call double @llvm.fma.f64(double %1092, double %1097, double 0x3FD249249B27ACF1) #3
  %1099 = tail call double @llvm.fma.f64(double %1092, double %1098, double 0x3FD99999998EF7B6) #3
  %1100 = tail call double @llvm.fma.f64(double %1092, double %1099, double 0x3FE5555555555780) #3
  %1101 = tail call double @llvm.amdgcn.ldexp.f64(double %1083, i32 1) #3
  %1102 = tail call double @llvm.amdgcn.ldexp.f64(double %1085, i32 1) #3
  %1103 = fmul double %1083, %1092
  %1104 = fneg double %1103
  %1105 = tail call double @llvm.fma.f64(double %1083, double %1092, double %1104) #3
  %1106 = fmul double %1085, %1092
  %1107 = tail call double @llvm.fma.f64(double %1083, double %1094, double %1106) #3
  %1108 = fadd double %1105, %1107
  %1109 = fadd double %1103, %1108
  %1110 = fsub double %1109, %1103
  %1111 = fsub double %1108, %1110
  %1112 = fmul double %1109, %1100
  %1113 = fneg double %1112
  %1114 = tail call double @llvm.fma.f64(double %1109, double %1100, double %1113) #3
  %1115 = tail call double @llvm.fma.f64(double %1111, double %1100, double %1114) #3
  %1116 = fadd double %1112, %1115
  %1117 = fsub double %1116, %1112
  %1118 = fsub double %1115, %1117
  %1119 = fadd double %1101, %1116
  %1120 = fsub double %1119, %1101
  %1121 = fsub double %1119, %1120
  %1122 = fsub double %1101, %1121
  %1123 = fsub double %1116, %1120
  %1124 = fadd double %1123, %1122
  %1125 = fadd double %1102, %1118
  %1126 = fsub double %1125, %1102
  %1127 = fsub double %1125, %1126
  %1128 = fsub double %1102, %1127
  %1129 = fsub double %1118, %1126
  %1130 = fadd double %1129, %1128
  %1131 = fadd double %1125, %1124
  %1132 = fadd double %1119, %1131
  %1133 = fsub double %1132, %1119
  %1134 = fsub double %1131, %1133
  %1135 = fadd double %1130, %1134
  %1136 = fadd double %1132, %1135
  %1137 = fsub double %1136, %1132
  %1138 = fsub double %1135, %1137
  %1139 = sitofp i32 %1055 to double
  %1140 = fmul double %1136, 0x3FF71547652B82FE
  %1141 = fneg double %1140
  %1142 = fmul double %1136, 0x3C7777D0FFDA0D24
  %1143 = insertelement <2 x double> undef, double %1136, i32 0
  %1144 = insertelement <2 x double> %1143, double %1138, i32 1
  %1145 = insertelement <2 x double> undef, double %1141, i32 0
  %1146 = insertelement <2 x double> %1145, double %1142, i32 1
  %1147 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1144, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1146) #3
  %1148 = extractelement <2 x double> %1147, i32 0
  %1149 = extractelement <2 x double> %1147, i32 1
  %1150 = fadd double %1148, %1149
  %1151 = fadd double %1140, %1150
  %1152 = fsub double %1151, %1140
  %1153 = fsub double %1150, %1152
  %1154 = fadd double %1151, %1139
  %1155 = fsub double %1154, %1139
  %1156 = fsub double %1155, %1154
  %1157 = fadd double %1156, %1139
  %1158 = fsub double %1151, %1155
  %1159 = fadd double %1158, %1157
  %1160 = fadd double %1153, %1159
  %1161 = fadd double %1154, %1160
  %1162 = tail call double @llvm.fabs.f64(double %1049) #4
  %1163 = fcmp oeq double %1162, 0x7FF0000000000000
  %1164 = select i1 %1163, double %1049, double %1161
  %1165 = fcmp olt double %1049, 0.000000e+00
  %1166 = select i1 %1165, double 0x7FF8000000000000, double %1164
  %1167 = fcmp oeq double %1049, 0.000000e+00
  %1168 = select i1 %1167, double 0xFFF0000000000000, double %1166
  %mul.i.i78.i.i.i.i = fmul double %1168, %1168
  %mul1.i.i79.i.i.i.i = fmul double %mul.i.i78.i.i.i.i, 0x3C158FD8B3C1B0C0
  %1169 = fsub double 0xBDB9FC7E20BD04CC, %mul1.i.i79.i.i.i.i
  %mul5.i.i81.i.i.i.i = fmul double %mul.i.i78.i.i.i.i, 0x3D01A287ED1019B8
  %1170 = fsub double 0xBE59BA2A0439E4A9, %mul5.i.i81.i.i.i.i
  %mul10.i.i83.i.i.i.i = fmul double %mul.i.i78.i.i.i.i, %1169
  %mul12.i.i84.i.i.i.i = fmul double %mul.i.i78.i.i.i.i, %1170
  %add15.i.i85.i.i.i.i = fadd double %mul10.i.i83.i.i.i.i, 0xBEE6B9C7BCE39403
  %add18.i.i86.i.i.i.i = fadd double %mul12.i.i84.i.i.i.i, 0xBF63B612102F3C24
  %mul20.i.i87.i.i.i.i = fmul double %mul.i.i78.i.i.i.i, %add15.i.i85.i.i.i.i
  %mul22.i.i88.i.i.i.i = fmul double %mul.i.i78.i.i.i.i, %add18.i.i86.i.i.i.i
  %add25.i.i89.i.i.i.i = fadd double %mul20.i.i87.i.i.i.i, 0xBFD06A8AF4A3FC55
  %add28.i.i90.i.i.i.i = fadd double %mul22.i.i88.i.i.i.i, 0xC024F817DD06EE79
  %1171 = fmul double %1168, %add25.i.i89.i.i.i.i
  %add33.i.i92.i.i.i.i = fsub double %add28.i.i90.i.i.i.i, %1171
  %mul1.i.i66.i.i.i.i = fmul double %mul.i.i78.i.i.i.i, 0x3CA9D032740CF69A
  %add.i.i67.i.i.i.i = fadd double %mul1.i.i66.i.i.i.i, 0x3E14D76BE5BA042B
  %mul5.i.i68.i.i.i.i = fmul double %mul.i.i78.i.i.i.i, 0x3D6F4FAB0C90F842
  %add7.i.i69.i.i.i.i = fadd double %mul5.i.i68.i.i.i.i, 0x3EA6C7746378848A
  %mul10.i.i70.i.i.i.i = fmul double %mul.i.i78.i.i.i.i, %add.i.i67.i.i.i.i
  %mul12.i.i71.i.i.i.i = fmul double %mul.i.i78.i.i.i.i, %add7.i.i69.i.i.i.i
  %add15.i.i72.i.i.i.i = fadd double %mul10.i.i70.i.i.i.i, 0x3F275783E6F9B4DA
  %add18.i.i73.i.i.i.i = fadd double %mul12.i.i71.i.i.i.i, 0x3F964BEF3074CF28
  %mul20.i.i74.i.i.i.i = fmul double %mul.i.i78.i.i.i.i, %add15.i.i72.i.i.i.i
  %add23.i.i75.i.i.i.i = fadd double %mul20.i.i74.i.i.i.i, 1.000000e+00
  %1172 = fmul double %1168, %add18.i.i73.i.i.i.i
  %add28.i.i77.i.i.i.i = fsub double %add23.i.i75.i.i.i.i, %1172
  %div92.i.i.i.i = fdiv double %add33.i.i92.i.i.i.i, %add28.i.i77.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else93.i.i.i.i:                                ; preds = %if.else82.i.i.i.i
  %cmp95.i.i.i.i = icmp sgt i32 %decision.value, -513
  br i1 %cmp95.i.i.i.i, label %if.then96.i.i.i.i, label %if.else104.i.i.i.i

if.then96.i.i.i.i:                                ; preds = %if.else93.i.i.i.i
  %1173 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 256) #3
  %1174 = tail call double @llvm.amdgcn.frexp.mant.f64(double %1173) #3
  %1175 = fcmp olt double %1174, 0x3FE5555555555555
  %1176 = zext i1 %1175 to i32
  %1177 = tail call double @llvm.amdgcn.ldexp.f64(double %1174, i32 %1176) #3
  %1178 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %1173) #3
  %1179 = sub nsw i32 %1178, %1176
  %1180 = fadd double %1177, -1.000000e+00
  %1181 = fadd double %1177, 1.000000e+00
  %1182 = fsub double %1181, %1177
  %1183 = fsub double %1181, %1182
  %1184 = fsub double %1177, %1183
  %1185 = fsub double 1.000000e+00, %1182
  %1186 = fadd double %1185, %1184
  %1187 = tail call double @llvm.amdgcn.rcp.f64(double %1181) #3
  %1188 = fneg double %1181
  %1189 = tail call double @llvm.fma.f64(double %1188, double %1187, double 1.000000e+00) #3
  %1190 = tail call double @llvm.fma.f64(double %1189, double %1187, double %1187) #3
  %1191 = tail call double @llvm.fma.f64(double %1188, double %1190, double 1.000000e+00) #3
  %1192 = tail call double @llvm.fma.f64(double %1191, double %1190, double %1190) #3
  %1193 = fmul double %1180, %1192
  %1194 = fmul double %1181, %1193
  %1195 = fneg double %1194
  %1196 = tail call double @llvm.fma.f64(double %1193, double %1181, double %1195) #3
  %1197 = tail call double @llvm.fma.f64(double %1193, double %1186, double %1196) #3
  %1198 = fadd double %1194, %1197
  %1199 = fsub double %1198, %1194
  %1200 = fsub double %1197, %1199
  %1201 = fsub double %1180, %1198
  %1202 = fsub double %1180, %1201
  %1203 = fsub double %1202, %1198
  %1204 = fsub double %1203, %1200
  %1205 = fadd double %1201, %1204
  %1206 = fmul double %1192, %1205
  %1207 = fadd double %1193, %1206
  %1208 = fsub double %1207, %1193
  %1209 = fsub double %1206, %1208
  %1210 = fmul double %1207, %1207
  %1211 = fneg double %1210
  %1212 = tail call double @llvm.fma.f64(double %1207, double %1207, double %1211) #3
  %1213 = fmul double %1209, 2.000000e+00
  %1214 = tail call double @llvm.fma.f64(double %1207, double %1213, double %1212) #3
  %1215 = tail call double @llvm.fma.f64(double %1209, double %1209, double %1214) #3
  %1216 = fadd double %1210, %1215
  %1217 = fsub double %1216, %1210
  %1218 = fsub double %1215, %1217
  %1219 = tail call double @llvm.fma.f64(double %1216, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %1220 = tail call double @llvm.fma.f64(double %1216, double %1219, double 0x3FC7474DD7F4DF2E) #3
  %1221 = tail call double @llvm.fma.f64(double %1216, double %1220, double 0x3FCC71C016291751) #3
  %1222 = tail call double @llvm.fma.f64(double %1216, double %1221, double 0x3FD249249B27ACF1) #3
  %1223 = tail call double @llvm.fma.f64(double %1216, double %1222, double 0x3FD99999998EF7B6) #3
  %1224 = tail call double @llvm.fma.f64(double %1216, double %1223, double 0x3FE5555555555780) #3
  %1225 = tail call double @llvm.amdgcn.ldexp.f64(double %1207, i32 1) #3
  %1226 = tail call double @llvm.amdgcn.ldexp.f64(double %1209, i32 1) #3
  %1227 = fmul double %1207, %1216
  %1228 = fneg double %1227
  %1229 = tail call double @llvm.fma.f64(double %1207, double %1216, double %1228) #3
  %1230 = fmul double %1209, %1216
  %1231 = tail call double @llvm.fma.f64(double %1207, double %1218, double %1230) #3
  %1232 = fadd double %1229, %1231
  %1233 = fadd double %1227, %1232
  %1234 = fsub double %1233, %1227
  %1235 = fsub double %1232, %1234
  %1236 = fmul double %1233, %1224
  %1237 = fneg double %1236
  %1238 = tail call double @llvm.fma.f64(double %1233, double %1224, double %1237) #3
  %1239 = tail call double @llvm.fma.f64(double %1235, double %1224, double %1238) #3
  %1240 = fadd double %1236, %1239
  %1241 = fsub double %1240, %1236
  %1242 = fsub double %1239, %1241
  %1243 = fadd double %1225, %1240
  %1244 = fsub double %1243, %1225
  %1245 = fsub double %1243, %1244
  %1246 = fsub double %1225, %1245
  %1247 = fsub double %1240, %1244
  %1248 = fadd double %1247, %1246
  %1249 = fadd double %1226, %1242
  %1250 = fsub double %1249, %1226
  %1251 = fsub double %1249, %1250
  %1252 = fsub double %1226, %1251
  %1253 = fsub double %1242, %1250
  %1254 = fadd double %1253, %1252
  %1255 = fadd double %1249, %1248
  %1256 = fadd double %1243, %1255
  %1257 = fsub double %1256, %1243
  %1258 = fsub double %1255, %1257
  %1259 = fadd double %1254, %1258
  %1260 = fadd double %1256, %1259
  %1261 = fsub double %1260, %1256
  %1262 = fsub double %1259, %1261
  %1263 = sitofp i32 %1179 to double
  %1264 = fmul double %1260, 0x3FF71547652B82FE
  %1265 = fneg double %1264
  %1266 = fmul double %1260, 0x3C7777D0FFDA0D24
  %1267 = insertelement <2 x double> undef, double %1260, i32 0
  %1268 = insertelement <2 x double> %1267, double %1262, i32 1
  %1269 = insertelement <2 x double> undef, double %1265, i32 0
  %1270 = insertelement <2 x double> %1269, double %1266, i32 1
  %1271 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1268, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1270) #3
  %1272 = extractelement <2 x double> %1271, i32 0
  %1273 = extractelement <2 x double> %1271, i32 1
  %1274 = fadd double %1272, %1273
  %1275 = fadd double %1264, %1274
  %1276 = fsub double %1275, %1264
  %1277 = fsub double %1274, %1276
  %1278 = fadd double %1275, %1263
  %1279 = fsub double %1278, %1263
  %1280 = fsub double %1279, %1278
  %1281 = fadd double %1280, %1263
  %1282 = fsub double %1275, %1279
  %1283 = fadd double %1282, %1281
  %1284 = fadd double %1277, %1283
  %1285 = fadd double %1278, %1284
  %1286 = tail call double @llvm.fabs.f64(double %1173) #4
  %1287 = fcmp oeq double %1286, 0x7FF0000000000000
  %1288 = select i1 %1287, double %1173, double %1285
  %1289 = fcmp olt double %1173, 0.000000e+00
  %1290 = select i1 %1289, double 0x7FF8000000000000, double %1288
  %1291 = fcmp oeq double %1173, 0.000000e+00
  %1292 = select i1 %1291, double 0xFFF0000000000000, double %1290
  %mul.i.i50.i.i.i.i = fmul double %1292, %1292
  %mul1.i.i51.i.i.i.i = fmul double %mul.i.i50.i.i.i.i, 0x3BAA9A26E0297ED8
  %1293 = fsub double 0xBD7021DF3392EE60, %mul1.i.i51.i.i.i.i
  %mul5.i.i53.i.i.i.i = fmul double %mul.i.i50.i.i.i.i, 0x3CA5D280D4B5A285
  %1294 = fsub double 0xBE2007A65CA14E38, %mul5.i.i53.i.i.i.i
  %mul10.i.i55.i.i.i.i = fmul double %mul.i.i50.i.i.i.i, %1293
  %mul12.i.i56.i.i.i.i = fmul double %mul.i.i50.i.i.i.i, %1294
  %add15.i.i57.i.i.i.i = fadd double %mul10.i.i55.i.i.i.i, 0xBEBC6E261AE99633
  %add18.i.i58.i.i.i.i = fadd double %mul12.i.i56.i.i.i.i, 0xBF48C2CA21FD14A5
  %mul20.i.i59.i.i.i.i = fmul double %mul.i.i50.i.i.i.i, %add15.i.i57.i.i.i.i
  %mul22.i.i60.i.i.i.i = fmul double %mul.i.i50.i.i.i.i, %add18.i.i58.i.i.i.i
  %add25.i.i61.i.i.i.i = fadd double %mul20.i.i59.i.i.i.i, 0xBFC4B5F131A679CC
  %add28.i.i62.i.i.i.i = fadd double %mul22.i.i60.i.i.i.i, 0xC02A92BAF87A7B72
  %1295 = fmul double %1292, %add25.i.i61.i.i.i.i
  %add33.i.i64.i.i.i.i = fsub double %add28.i.i62.i.i.i.i, %1295
  %mul1.i.i38.i.i.i.i = fmul double %mul.i.i50.i.i.i.i, 0x3C495387D39D2504
  %add.i.i39.i.i.i.i = fadd double %mul1.i.i38.i.i.i.i, 0x3DD49301DA58AEFA
  %mul5.i.i40.i.i.i.i = fmul double %mul.i.i50.i.i.i.i, 0x3D1ED0326F0CBDDC
  %add7.i.i41.i.i.i.i = fadd double %mul5.i.i40.i.i.i.i, 0x3E768F19E4302EF3
  %mul10.i.i42.i.i.i.i = fmul double %mul.i.i50.i.i.i.i, %add.i.i39.i.i.i.i
  %mul12.i.i43.i.i.i.i = fmul double %mul.i.i50.i.i.i.i, %add7.i.i41.i.i.i.i
  %add15.i.i44.i.i.i.i = fadd double %mul10.i.i42.i.i.i.i, 0x3F0730EC426E6E84
  %add18.i.i45.i.i.i.i = fadd double %mul12.i.i43.i.i.i.i, 0x3F86397D81A61D6E
  %mul20.i.i46.i.i.i.i = fmul double %mul.i.i50.i.i.i.i, %add15.i.i44.i.i.i.i
  %add23.i.i47.i.i.i.i = fadd double %mul20.i.i46.i.i.i.i, 1.000000e+00
  %1296 = fmul double %1292, %add18.i.i45.i.i.i.i
  %add28.i.i49.i.i.i.i = fsub double %add23.i.i47.i.i.i.i, %1296
  %div103.i.i.i.i = fdiv double %add33.i.i64.i.i.i.i, %add28.i.i49.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else104.i.i.i.i:                               ; preds = %if.else93.i.i.i.i
  %cmp106.i.i.i.i = icmp sgt i32 %decision.value, -1025
  br i1 %cmp106.i.i.i.i, label %if.then107.i.i.i.i, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.then107.i.i.i.i:                               ; preds = %if.else104.i.i.i.i
  %1297 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 512) #3
  %1298 = tail call double @llvm.amdgcn.frexp.mant.f64(double %1297) #3
  %1299 = fcmp olt double %1298, 0x3FE5555555555555
  %1300 = zext i1 %1299 to i32
  %1301 = tail call double @llvm.amdgcn.ldexp.f64(double %1298, i32 %1300) #3
  %1302 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %1297) #3
  %1303 = sub nsw i32 %1302, %1300
  %1304 = fadd double %1301, -1.000000e+00
  %1305 = fadd double %1301, 1.000000e+00
  %1306 = fsub double %1305, %1301
  %1307 = fsub double %1305, %1306
  %1308 = fsub double %1301, %1307
  %1309 = fsub double 1.000000e+00, %1306
  %1310 = fadd double %1309, %1308
  %1311 = tail call double @llvm.amdgcn.rcp.f64(double %1305) #3
  %1312 = fneg double %1305
  %1313 = tail call double @llvm.fma.f64(double %1312, double %1311, double 1.000000e+00) #3
  %1314 = tail call double @llvm.fma.f64(double %1313, double %1311, double %1311) #3
  %1315 = tail call double @llvm.fma.f64(double %1312, double %1314, double 1.000000e+00) #3
  %1316 = tail call double @llvm.fma.f64(double %1315, double %1314, double %1314) #3
  %1317 = fmul double %1304, %1316
  %1318 = fmul double %1305, %1317
  %1319 = fneg double %1318
  %1320 = tail call double @llvm.fma.f64(double %1317, double %1305, double %1319) #3
  %1321 = tail call double @llvm.fma.f64(double %1317, double %1310, double %1320) #3
  %1322 = fadd double %1318, %1321
  %1323 = fsub double %1322, %1318
  %1324 = fsub double %1321, %1323
  %1325 = fsub double %1304, %1322
  %1326 = fsub double %1304, %1325
  %1327 = fsub double %1326, %1322
  %1328 = fsub double %1327, %1324
  %1329 = fadd double %1325, %1328
  %1330 = fmul double %1316, %1329
  %1331 = fadd double %1317, %1330
  %1332 = fsub double %1331, %1317
  %1333 = fsub double %1330, %1332
  %1334 = fmul double %1331, %1331
  %1335 = fneg double %1334
  %1336 = tail call double @llvm.fma.f64(double %1331, double %1331, double %1335) #3
  %1337 = fmul double %1333, 2.000000e+00
  %1338 = tail call double @llvm.fma.f64(double %1331, double %1337, double %1336) #3
  %1339 = tail call double @llvm.fma.f64(double %1333, double %1333, double %1338) #3
  %1340 = fadd double %1334, %1339
  %1341 = fsub double %1340, %1334
  %1342 = fsub double %1339, %1341
  %1343 = tail call double @llvm.fma.f64(double %1340, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %1344 = tail call double @llvm.fma.f64(double %1340, double %1343, double 0x3FC7474DD7F4DF2E) #3
  %1345 = tail call double @llvm.fma.f64(double %1340, double %1344, double 0x3FCC71C016291751) #3
  %1346 = tail call double @llvm.fma.f64(double %1340, double %1345, double 0x3FD249249B27ACF1) #3
  %1347 = tail call double @llvm.fma.f64(double %1340, double %1346, double 0x3FD99999998EF7B6) #3
  %1348 = tail call double @llvm.fma.f64(double %1340, double %1347, double 0x3FE5555555555780) #3
  %1349 = tail call double @llvm.amdgcn.ldexp.f64(double %1331, i32 1) #3
  %1350 = tail call double @llvm.amdgcn.ldexp.f64(double %1333, i32 1) #3
  %1351 = fmul double %1331, %1340
  %1352 = fneg double %1351
  %1353 = tail call double @llvm.fma.f64(double %1331, double %1340, double %1352) #3
  %1354 = fmul double %1333, %1340
  %1355 = tail call double @llvm.fma.f64(double %1331, double %1342, double %1354) #3
  %1356 = fadd double %1353, %1355
  %1357 = fadd double %1351, %1356
  %1358 = fsub double %1357, %1351
  %1359 = fsub double %1356, %1358
  %1360 = fmul double %1357, %1348
  %1361 = fneg double %1360
  %1362 = tail call double @llvm.fma.f64(double %1357, double %1348, double %1361) #3
  %1363 = tail call double @llvm.fma.f64(double %1359, double %1348, double %1362) #3
  %1364 = fadd double %1360, %1363
  %1365 = fsub double %1364, %1360
  %1366 = fsub double %1363, %1365
  %1367 = fadd double %1349, %1364
  %1368 = fsub double %1367, %1349
  %1369 = fsub double %1367, %1368
  %1370 = fsub double %1349, %1369
  %1371 = fsub double %1364, %1368
  %1372 = fadd double %1371, %1370
  %1373 = fadd double %1350, %1366
  %1374 = fsub double %1373, %1350
  %1375 = fsub double %1373, %1374
  %1376 = fsub double %1350, %1375
  %1377 = fsub double %1366, %1374
  %1378 = fadd double %1377, %1376
  %1379 = fadd double %1373, %1372
  %1380 = fadd double %1367, %1379
  %1381 = fsub double %1380, %1367
  %1382 = fsub double %1379, %1381
  %1383 = fadd double %1378, %1382
  %1384 = fadd double %1380, %1383
  %1385 = fsub double %1384, %1380
  %1386 = fsub double %1383, %1385
  %1387 = sitofp i32 %1303 to double
  %1388 = fmul double %1384, 0x3FF71547652B82FE
  %1389 = fneg double %1388
  %1390 = fmul double %1384, 0x3C7777D0FFDA0D24
  %1391 = insertelement <2 x double> undef, double %1384, i32 0
  %1392 = insertelement <2 x double> %1391, double %1386, i32 1
  %1393 = insertelement <2 x double> undef, double %1389, i32 0
  %1394 = insertelement <2 x double> %1393, double %1390, i32 1
  %1395 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1392, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1394) #3
  %1396 = extractelement <2 x double> %1395, i32 0
  %1397 = extractelement <2 x double> %1395, i32 1
  %1398 = fadd double %1396, %1397
  %1399 = fadd double %1388, %1398
  %1400 = fsub double %1399, %1388
  %1401 = fsub double %1398, %1400
  %1402 = fadd double %1399, %1387
  %1403 = fsub double %1402, %1387
  %1404 = fsub double %1403, %1402
  %1405 = fadd double %1404, %1387
  %1406 = fsub double %1399, %1403
  %1407 = fadd double %1406, %1405
  %1408 = fadd double %1401, %1407
  %1409 = fadd double %1402, %1408
  %1410 = tail call double @llvm.fabs.f64(double %1297) #4
  %1411 = fcmp oeq double %1410, 0x7FF0000000000000
  %1412 = select i1 %1411, double %1297, double %1409
  %1413 = fcmp olt double %1297, 0.000000e+00
  %1414 = select i1 %1413, double 0x7FF8000000000000, double %1412
  %1415 = fcmp oeq double %1297, 0.000000e+00
  %1416 = select i1 %1415, double 0xFFF0000000000000, double %1414
  %mul.i.i26.i.i.i.i = fmul double %1416, %1416
  %mul1.i.i27.i.i.i.i = fmul double %mul.i.i26.i.i.i.i, 0x3B408480D3491A50
  %1417 = fsub double 0xBD241E51766A91FB, %mul1.i.i27.i.i.i.i
  %mul5.i.i29.i.i.i.i = fmul double %mul.i.i26.i.i.i.i, 0x3C4B275AC5F91B68
  %1418 = fsub double 0xBDE40A018263D493, %mul5.i.i29.i.i.i.i
  %mul10.i.i31.i.i.i.i = fmul double %mul.i.i26.i.i.i.i, %1417
  %mul12.i.i32.i.i.i.i = fmul double %mul.i.i26.i.i.i.i, %1418
  %add15.i.i33.i.i.i.i = fadd double %mul10.i.i31.i.i.i.i, 0xBE91D0F7FEBA5A35
  %add18.i.i34.i.i.i.i = fadd double %mul12.i.i32.i.i.i.i, 0xBF2F1E266EB4C824
  %mul20.i.i35.i.i.i.i = fmul double %mul.i.i26.i.i.i.i, %add15.i.i33.i.i.i.i
  %mul22.i.i.i38.i.i.i = fmul double %mul.i.i26.i.i.i.i, %add18.i.i34.i.i.i.i
  %add25.i.i.i39.i.i.i = fadd double %mul20.i.i35.i.i.i.i, 0xBFBA19EDB555D8AD
  %add28.i.i36.i.i.i.i = fadd double %mul22.i.i.i38.i.i.i, 0xC030CB31255FFA09
  %1419 = fmul double %1416, %add25.i.i.i39.i.i.i
  %add33.i.i.i41.i.i.i = fsub double %add28.i.i36.i.i.i.i, %1419
  %mul1.i.i14.i.i.i.i = fmul double %mul.i.i26.i.i.i.i, 0x3BE8FEBB5A4047D7
  %add.i.i15.i.i.i.i = fadd double %mul1.i.i14.i.i.i.i, 0x3D9463E48A976F97
  %mul5.i.i16.i.i.i.i = fmul double %mul.i.i26.i.i.i.i, 0x3CCE78F4A7F13C7D
  %add7.i.i17.i.i.i.i = fadd double %mul5.i.i16.i.i.i.i, 0x3E46680C94743FD9
  %mul10.i.i18.i.i.i.i = fmul double %mul.i.i26.i.i.i.i, %add.i.i15.i.i.i.i
  %mul12.i.i19.i.i.i.i = fmul double %mul.i.i26.i.i.i.i, %add7.i.i17.i.i.i.i
  %add15.i.i20.i.i.i.i = fadd double %mul10.i.i18.i.i.i.i, 0x3EE71602E8EA99F3
  %add18.i.i21.i.i.i.i = fadd double %mul12.i.i19.i.i.i.i, 0x3F762C8C65771E78
  %mul20.i.i22.i.i.i.i = fmul double %mul.i.i26.i.i.i.i, %add15.i.i20.i.i.i.i
  %add23.i.i23.i.i.i.i = fadd double %mul20.i.i22.i.i.i.i, 1.000000e+00
  %1420 = fmul double %1416, %add18.i.i21.i.i.i.i
  %add28.i.i25.i.i.i.i = fsub double %add23.i.i23.i.i.i.i, %1420
  %div114.i.i.i.i = fdiv double %add33.i.i.i41.i.i.i, %add28.i.i25.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

fusion.side:                                      ; preds = %decision.dispatch
  %1421 = insertelement <2 x double> undef, double %823, i32 0
  %1422 = insertelement <2 x double> %1421, double %825, i32 1
  %1423 = insertelement <2 x double> undef, double %828, i32 0
  %1424 = insertelement <2 x double> %1423, double %829, i32 1
  %1425 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1422, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1424) #3
  %1426 = extractelement <2 x double> %1425, i32 0
  %1427 = extractelement <2 x double> %1425, i32 1
  br label %fusion.common

fusion.side1:                                     ; preds = %decision.dispatch
  %1428 = insertelement <2 x double> undef, double %823, i32 0
  %1429 = insertelement <2 x double> %1428, double %825, i32 1
  %1430 = insertelement <2 x double> undef, double %828, i32 0
  %1431 = insertelement <2 x double> %1430, double %829, i32 1
  %1432 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1429, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1431) #3
  %1433 = extractelement <2 x double> %1432, i32 0
  %1434 = extractelement <2 x double> %1432, i32 1
  br label %fusion.common

fusion.common:                                    ; preds = %fusion.side1, %fusion.side
  %1435 = phi double [ 0x3FE7235AE26E3A60, %fusion.side ], [ 0x3FD6E5B7AB236028, %fusion.side1 ]
  %1436 = phi double [ 0x3FC92E7DCCD1B70C, %fusion.side ], [ 0x3FA8A45F1AE4ADBE, %fusion.side1 ]
  %1437 = phi double [ 0x3F999857B526C821, %fusion.side ], [ 0x3F68BF137C253BD1, %fusion.side1 ]
  %1438 = phi double [ 0x3F0330822740ADF9, %fusion.side ], [ 0x3EB20E304F6E5BCE, %fusion.side1 ]
  %1439 = phi double [ 0x3F586FC94B9EAD30, %fusion.side ], [ 0x3F1751EF5755C229, %fusion.side1 ]
  %1440 = phi double [ 0x3E9090FBB4B042AE, %fusion.side ], [ 0x3E2EB2F3F6504F32, %fusion.side1 ]
  %1441 = phi double [ 0xC004C929A952DE48, %fusion.side ], [ 0xC00D636ADAEC3C05, %fusion.side1 ]
  %1442 = phi double [ 0xC001F1CD6A03BCAA, %fusion.side ], [ 0xBFF8595CA25899FD, %fusion.side1 ]
  %1443 = phi double [ 0xBFE78F054AC7A90B, %fusion.side ], [ 0xBFCED54905311121, %fusion.side1 ]
  %1444 = phi double [ 0xBFBD7935AC58B5B5, %fusion.side ], [ 0xBF92AE2345C460A0, %fusion.side1 ]
  %1445 = phi double [ 0xBF81F96D17A7115B, %fusion.side ], [ 0xBF4625660A41D7B1, %fusion.side1 ]
  %1446 = phi double [ 0x3ECBFD524C94F258, %fusion.side ], [ 0x3E70731CF2A765F0, %fusion.side1 ]
  %1447 = phi double [ 0xBF336C13BBA203F3, %fusion.side ], [ 0xBEE755F1646665DB, %fusion.side1 ]
  %1448 = phi double [ 0x3E32022ABCFF5DE7, %fusion.side ], [ 0x3DC4C8BD76453064, %fusion.side1 ]
  %fusion.paired = phi double [ %1426, %fusion.side ], [ %1433, %fusion.side1 ]
  %fusion.paired2 = phi double [ %1427, %fusion.side ], [ %1434, %fusion.side1 ]
  %1449 = fadd double %fusion.paired, %fusion.paired2
  %1450 = fadd double %827, %1449
  %1451 = fsub double %1450, %827
  %1452 = fsub double %1449, %1451
  %1453 = fadd double %1450, %826
  %1454 = fsub double %1453, %826
  %1455 = fsub double %1454, %1453
  %1456 = fadd double %1455, %826
  %1457 = fsub double %1450, %1454
  %1458 = fadd double %1457, %1456
  %1459 = fadd double %1452, %1458
  %1460 = fadd double %1453, %1459
  %1461 = tail call double @llvm.fabs.f64(double %736) #4
  %1462 = fcmp oeq double %1461, 0x7FF0000000000000
  %1463 = select i1 %1462, double %736, double %1460
  %1464 = fcmp olt double %736, 0.000000e+00
  %1465 = select i1 %1464, double 0x7FF8000000000000, double %1463
  %1466 = fcmp oeq double %736, 0.000000e+00
  %1467 = select i1 %1466, double 0xFFF0000000000000, double %1465
  %1468 = fmul double %1467, %1467
  %1469 = fmul double %1468, %1448
  %1470 = fsub double %1447, %1469
  %1471 = fmul double %1468, %1446
  %1472 = fsub double %1445, %1471
  %1473 = fmul double %1468, %1470
  %1474 = fmul double %1468, %1472
  %1475 = fadd double %1473, %1444
  %1476 = fadd double %1474, %1443
  %1477 = fmul double %1468, %1475
  %1478 = fmul double %1468, %1476
  %1479 = fadd double %1477, %1442
  %1480 = fadd double %1478, %1441
  %1481 = fmul double %1467, %1479
  %1482 = fsub double %1480, %1481
  %1483 = fmul double %1468, %1440
  %1484 = fadd double %1483, %1439
  %1485 = fmul double %1468, %1438
  %1486 = fadd double %1485, %1437
  %1487 = fmul double %1468, %1484
  %1488 = fmul double %1468, %1486
  %1489 = fadd double %1487, %1436
  %1490 = fadd double %1488, %1435
  %1491 = fmul double %1468, %1489
  %1492 = fadd double %1491, 1.000000e+00
  %1493 = fmul double %1467, %1490
  %1494 = fsub double %1492, %1493
  %1495 = fdiv double %1482, %1494
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

fusion.side2:                                     ; preds = %decision.dispatch1
  %1496 = insertelement <2 x double> undef, double %918, i32 0
  %1497 = insertelement <2 x double> %1496, double %920, i32 1
  %1498 = insertelement <2 x double> undef, double %923, i32 0
  %1499 = insertelement <2 x double> %1498, double %924, i32 1
  %1500 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1497, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1499) #3
  %1501 = extractelement <2 x double> %1500, i32 0
  %1502 = extractelement <2 x double> %1500, i32 1
  br label %fusion.common1

fusion.side3:                                     ; preds = %decision.dispatch1
  %1503 = insertelement <2 x double> undef, double %918, i32 0
  %1504 = insertelement <2 x double> %1503, double %920, i32 1
  %1505 = insertelement <2 x double> undef, double %923, i32 0
  %1506 = insertelement <2 x double> %1505, double %924, i32 1
  %1507 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1504, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1506) #3
  %1508 = extractelement <2 x double> %1507, i32 0
  %1509 = extractelement <2 x double> %1507, i32 1
  br label %fusion.common1

fusion.common1:                                   ; preds = %fusion.side3, %fusion.side2
  %1510 = phi double [ 0x3FB68627D1A51CB5, %fusion.side3 ], [ 0x3FC6B0CE3157BCB1, %fusion.side2 ]
  %1511 = phi double [ 0x3F67D3564F778B21, %fusion.side3 ], [ 0x3F882FD20DA34F30, %fusion.side2 ]
  %1512 = phi double [ 0x3F077F4625619D43, %fusion.side3 ], [ 0x3F380B62C1407B15, %fusion.side2 ]
  %1513 = phi double [ 0x3E107ECF99D6009A, %fusion.side3 ], [ 0x3E6129D961D79065, %fusion.side2 ]
  %1514 = phi double [ 0x3E95BA568EDD3BFB, %fusion.side3 ], [ 0x3ED66AFC954DE682, %fusion.side2 ]
  %1515 = phi double [ 0x3D6B7BD497A2CD17, %fusion.side3 ], [ 0x3DCCD7C812F40049, %fusion.side2 ]
  %1516 = phi double [ 0xC019A861C808DCFC, %fusion.side3 ], [ 0xC013B000D66B8269, %fusion.side2 ]
  %1517 = phi double [ 0xBFE46D859460DB51, %fusion.side3 ], [ 0xBFEFD66AE54A0BCB, %fusion.side2 ]
  %1518 = phi double [ 0xBF98ED20B1D6A6D8, %fusion.side3 ], [ 0xBFB3B5B6F694BB9E, %fusion.side2 ]
  %1519 = phi double [ 0xBF3D2E78945F9AC6, %fusion.side3 ], [ 0xBF676495E4B7EAAA, %fusion.side2 ]
  %1520 = phi double [ 0xBED0C1E92AD969EF, %fusion.side3 ], [ 0xBF0B3634004E0F5C, %fusion.side2 ]
  %1521 = phi double [ 0x3DB79116B58241AA, %fusion.side3 ], [ 0x3E1390C28573DB0F, %fusion.side2 ]
  %1522 = phi double [ 0xBE512769C01EA7C5, %fusion.side3 ], [ 0xBE9C2F1FFD2FFECD, %fusion.side2 ]
  %1523 = phi double [ 0x3CED1FCD2AD8841F, %fusion.side3 ], [ 0x3D5866A3E6D0F156, %fusion.side2 ]
  %fusion.paired4 = phi double [ %1508, %fusion.side3 ], [ %1501, %fusion.side2 ]
  %fusion.paired5 = phi double [ %1509, %fusion.side3 ], [ %1502, %fusion.side2 ]
  %1524 = fadd double %fusion.paired4, %fusion.paired5
  %1525 = fadd double %922, %1524
  %1526 = fsub double %1525, %922
  %1527 = fsub double %1524, %1526
  %1528 = fadd double %1525, %921
  %1529 = fsub double %1528, %921
  %1530 = fsub double %1529, %1528
  %1531 = fadd double %1530, %921
  %1532 = fsub double %1525, %1529
  %1533 = fadd double %1532, %1531
  %1534 = fadd double %1527, %1533
  %1535 = fadd double %1528, %1534
  %1536 = tail call double @llvm.fabs.f64(double %831) #4
  %1537 = fcmp oeq double %1536, 0x7FF0000000000000
  %1538 = select i1 %1537, double %831, double %1535
  %1539 = fcmp olt double %831, 0.000000e+00
  %1540 = select i1 %1539, double 0x7FF8000000000000, double %1538
  %1541 = fcmp oeq double %831, 0.000000e+00
  %1542 = select i1 %1541, double 0xFFF0000000000000, double %1540
  %1543 = fmul double %1542, %1542
  %1544 = fmul double %1543, %1523
  %1545 = fsub double %1522, %1544
  %1546 = fmul double %1543, %1521
  %1547 = fsub double %1520, %1546
  %1548 = fmul double %1543, %1545
  %1549 = fmul double %1543, %1547
  %1550 = fadd double %1548, %1519
  %1551 = fadd double %1549, %1518
  %1552 = fmul double %1543, %1550
  %1553 = fmul double %1543, %1551
  %1554 = fadd double %1552, %1517
  %1555 = fadd double %1553, %1516
  %1556 = fmul double %1542, %1554
  %1557 = fsub double %1555, %1556
  %1558 = fmul double %1543, %1515
  %1559 = fadd double %1558, %1514
  %1560 = fmul double %1543, %1513
  %1561 = fadd double %1560, %1512
  %1562 = fmul double %1543, %1559
  %1563 = fmul double %1543, %1561
  %1564 = fadd double %1562, %1511
  %1565 = fadd double %1563, %1510
  %1566 = fmul double %1543, %1564
  %1567 = fadd double %1566, 1.000000e+00
  %1568 = fmul double %1542, %1565
  %1569 = fsub double %1567, %1568
  %1570 = fdiv double %1557, %1569
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i.pair.join: ; preds = %if.then20.i.i.i.i, %if.then11.i.i.i.i
  %retval.0.i.i.i.ph = phi double [ %div26.i.i.i.i, %if.then20.i.i.i.i ], [ %div16.i.i.i.i, %if.then11.i.i.i.i ]
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i: ; preds = %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i.pair.join, %fusion.common1, %fusion.common, %if.then107.i.i.i.i, %if.else104.i.i.i.i, %if.then96.i.i.i.i, %if.then85.i.i.i.i, %if.then74.i.i.i.i, %if.then3.i27.i.i.i, %if.then.i21.i.i.i, %if.end7.i.i.i.i.i.i.i, %if.else71.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, %if.then3.i.i.i.i, %if.then.i.i.i.i
  %retval.0.i.i.i = phi double [ %div.i.i.i.i, %if.then.i.i.i.i ], [ %div8.i.i.i.i, %if.then3.i.i.i.i ], [ %div20.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i ], [ %div34.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i ], [ %div48.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i ], [ %div62.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i ], [ %div70.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i ], [ 0x7FF0000000000000, %if.else71.i.i.i.i ], [ %div80.i.i.i.i, %if.end7.i.i.i.i.i.i.i ], [ %div.i20.i.i.i, %if.then.i21.i.i.i ], [ %div8.i26.i.i.i, %if.then3.i27.i.i.i ], [ %div81.i.i.i.i, %if.then74.i.i.i.i ], [ %div92.i.i.i.i, %if.then85.i.i.i.i ], [ %div103.i.i.i.i, %if.then96.i.i.i.i ], [ 0xFFF0000000000000, %if.else104.i.i.i.i ], [ %div114.i.i.i.i, %if.then107.i.i.i.i ], [ %1495, %fusion.common ], [ %1570, %fusion.common1 ], [ %retval.0.i.i.i.ph, %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i.pair.join ]
  %add.i.i = fadd double %retval.0.i.i.i, 0.000000e+00
  br label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit

_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit: ; preds = %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, %lor.lhs.false2.i.i.i, %if.end8.i.i
  %retval.0.i.i = phi double [ 0x7FF8000000000000, %if.end8.i.i ], [ 0x7FF8000000000000, %lor.lhs.false2.i.i.i ], [ %add.i.i, %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i ]
  %arrayidx712 = getelementptr inbounds double, double addrspace(1)* %output.coerce, i64 %idxprom
  store double %retval.0.i.i, double addrspace(1)* %arrayidx712, align 8, !tbaa !8
  br label %if.end

if.end:                                           ; preds = %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, %entry
  ret void
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.frexp.exp.i32.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.frexp.mant.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i1 @llvm.amdgcn.class.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.ldexp.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rcp.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fma.v2f64(<2 x double>, <2 x double>, <2 x double>) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.abs.i32(i32, i1 immarg) #1

attributes #0 = { nofree norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="128" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }
attributes #4 = { nounwind readnone }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/charitha22/cgo22ae-darm-code.git e9bc0540325ad9806313d34e84fc901496fd8be6)"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i16 1, i16 1025}
!6 = !{}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = !{!"evaluate:%if.then11.i.i.i.i", !"evaluate:%if.then20.i.i.i.i"}
!13 = !{!"merge(evaluate:%if.then11.i.i.i.i,evaluate:%if.then20.i.i.i.i)"}
