; ModuleID = 'lud_kernel.hip.cpp'
source_filename = "lud_kernel.hip.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

@_ZZ12lud_diagonalPfiiE6shadow = internal unnamed_addr addrspace(3) global [8 x [8 x float]] undef, align 16
@_ZZ13lud_perimeterPfiiE3dia = internal unnamed_addr addrspace(3) global [8 x [8 x float]] undef, align 16
@_ZZ13lud_perimeterPfiiE8peri_row = internal unnamed_addr addrspace(3) global [8 x [8 x float]] undef, align 16
@_ZZ13lud_perimeterPfiiE8peri_col = internal unnamed_addr addrspace(3) global [8 x [8 x float]] undef, align 16
@_ZZ12lud_internalPfiiE8peri_row = internal unnamed_addr addrspace(3) global [8 x [8 x float]] undef, align 16
@_ZZ12lud_internalPfiiE8peri_col = internal unnamed_addr addrspace(3) global [8 x [8 x float]] undef, align 16

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z12lud_diagonalPfii(float addrspace(1)* nocapture %0, i32 %1, i32 %2) local_unnamed_addr #0 {
  %4 = mul nsw i32 %2, %1
  %5 = add nsw i32 %4, %2
  %6 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !4
  %7 = zext i32 %6 to i64
  %8 = sext i32 %5 to i64
  %9 = add nsw i64 %8, %7
  %10 = getelementptr inbounds float, float addrspace(1)* %0, i64 %9
  %11 = bitcast float addrspace(1)* %10 to i32 addrspace(1)*
  %12 = load i32, i32 addrspace(1)* %11, align 4, !tbaa !5
  %13 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %14 = bitcast float addrspace(3)* %13 to i32 addrspace(3)*
  store i32 %12, i32 addrspace(3)* %14, align 4, !tbaa !5
  %15 = add nsw i32 %5, %1
  %16 = sext i32 %15 to i64
  %17 = add nsw i64 %16, %7
  %18 = getelementptr inbounds float, float addrspace(1)* %0, i64 %17
  %19 = bitcast float addrspace(1)* %18 to i32 addrspace(1)*
  %20 = load i32, i32 addrspace(1)* %19, align 4, !tbaa !5
  %21 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %22 = bitcast float addrspace(3)* %21 to i32 addrspace(3)*
  store i32 %20, i32 addrspace(3)* %22, align 4, !tbaa !5
  %23 = add nsw i32 %15, %1
  %24 = sext i32 %23 to i64
  %25 = add nsw i64 %24, %7
  %26 = getelementptr inbounds float, float addrspace(1)* %0, i64 %25
  %27 = bitcast float addrspace(1)* %26 to i32 addrspace(1)*
  %28 = load i32, i32 addrspace(1)* %27, align 4, !tbaa !5
  %29 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %30 = bitcast float addrspace(3)* %29 to i32 addrspace(3)*
  store i32 %28, i32 addrspace(3)* %30, align 4, !tbaa !5
  %31 = add nsw i32 %23, %1
  %32 = sext i32 %31 to i64
  %33 = add nsw i64 %32, %7
  %34 = getelementptr inbounds float, float addrspace(1)* %0, i64 %33
  %35 = bitcast float addrspace(1)* %34 to i32 addrspace(1)*
  %36 = load i32, i32 addrspace(1)* %35, align 4, !tbaa !5
  %37 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %38 = bitcast float addrspace(3)* %37 to i32 addrspace(3)*
  store i32 %36, i32 addrspace(3)* %38, align 4, !tbaa !5
  %39 = add nsw i32 %31, %1
  %40 = sext i32 %39 to i64
  %41 = add nsw i64 %40, %7
  %42 = getelementptr inbounds float, float addrspace(1)* %0, i64 %41
  %43 = bitcast float addrspace(1)* %42 to i32 addrspace(1)*
  %44 = load i32, i32 addrspace(1)* %43, align 4, !tbaa !5
  %45 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %46 = bitcast float addrspace(3)* %45 to i32 addrspace(3)*
  store i32 %44, i32 addrspace(3)* %46, align 4, !tbaa !5
  %47 = add nsw i32 %39, %1
  %48 = sext i32 %47 to i64
  %49 = add nsw i64 %48, %7
  %50 = getelementptr inbounds float, float addrspace(1)* %0, i64 %49
  %51 = bitcast float addrspace(1)* %50 to i32 addrspace(1)*
  %52 = load i32, i32 addrspace(1)* %51, align 4, !tbaa !5
  %53 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  %54 = bitcast float addrspace(3)* %53 to i32 addrspace(3)*
  store i32 %52, i32 addrspace(3)* %54, align 4, !tbaa !5
  %55 = add nsw i32 %47, %1
  %56 = sext i32 %55 to i64
  %57 = add nsw i64 %56, %7
  %58 = getelementptr inbounds float, float addrspace(1)* %0, i64 %57
  %59 = bitcast float addrspace(1)* %58 to i32 addrspace(1)*
  %60 = load i32, i32 addrspace(1)* %59, align 4, !tbaa !5
  %61 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 %6
  %62 = bitcast float addrspace(3)* %61 to i32 addrspace(3)*
  store i32 %60, i32 addrspace(3)* %62, align 4, !tbaa !5
  %63 = add nsw i32 %55, %1
  %64 = sext i32 %63 to i64
  %65 = add nsw i64 %64, %7
  %66 = getelementptr inbounds float, float addrspace(1)* %0, i64 %65
  %67 = bitcast float addrspace(1)* %66 to i32 addrspace(1)*
  %68 = load i32, i32 addrspace(1)* %67, align 4, !tbaa !5
  %69 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 %6
  %70 = bitcast float addrspace(3)* %69 to i32 addrspace(3)*
  store i32 %68, i32 addrspace(3)* %70, align 4, !tbaa !5
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %71 = icmp eq i32 %6, 0
  br i1 %71, label %78, label %72

72:                                               ; preds = %3
  %73 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %74 = load float, float addrspace(3)* %73, align 16, !tbaa !5
  %75 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 0), align 16, !tbaa !5
  %76 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %77 = fdiv contract float %74, %75
  store float %77, float addrspace(3)* %76, align 16, !tbaa !5
  br label %78

78:                                               ; preds = %72, %3
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %71, label %86, label %79

79:                                               ; preds = %78
  %80 = load float, float addrspace(3)* %21, align 4, !tbaa !5
  %81 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %82 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 0), align 16, !tbaa !5
  %83 = load float, float addrspace(3)* %81, align 4, !tbaa !5
  %84 = fmul contract float %82, %83
  %85 = fsub contract float %80, %84
  store float %85, float addrspace(3)* %21, align 4, !tbaa !5
  br label %86

86:                                               ; preds = %79, %78
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %87 = icmp ugt i32 %6, 1
  br i1 %87, label %88, label %99

88:                                               ; preds = %86
  %89 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %90 = load float, float addrspace(3)* %89, align 4, !tbaa !5
  %91 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %92 = load float, float addrspace(3)* %91, align 16, !tbaa !5
  %93 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 1), align 4, !tbaa !5
  %94 = fmul contract float %92, %93
  %95 = fsub contract float %90, %94
  store float %95, float addrspace(3)* %89, align 4, !tbaa !5
  %96 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 1), align 4, !tbaa !5
  %97 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %98 = fdiv contract float %95, %96
  store float %98, float addrspace(3)* %97, align 4, !tbaa !5
  br label %99

99:                                               ; preds = %88, %86
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %87, label %100, label %112

100:                                              ; preds = %99
  %101 = load float, float addrspace(3)* %29, align 4, !tbaa !5
  %102 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 0), align 16, !tbaa !5
  %103 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %104 = load float, float addrspace(3)* %103, align 4, !tbaa !5
  %105 = fmul contract float %102, %104
  %106 = fsub contract float %101, %105
  store float %106, float addrspace(3)* %29, align 4, !tbaa !5
  %107 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 1), align 4, !tbaa !5
  %108 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %109 = load float, float addrspace(3)* %108, align 4, !tbaa !5
  %110 = fmul contract float %107, %109
  %111 = fsub contract float %106, %110
  store float %111, float addrspace(3)* %29, align 4, !tbaa !5
  br label %112

112:                                              ; preds = %100, %99
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %113 = icmp ugt i32 %6, 2
  br i1 %113, label %114, label %130

114:                                              ; preds = %112
  %115 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %116 = load float, float addrspace(3)* %115, align 8, !tbaa !5
  %117 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %118 = load float, float addrspace(3)* %117, align 16, !tbaa !5
  %119 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 2), align 8, !tbaa !5
  %120 = fmul contract float %118, %119
  %121 = fsub contract float %116, %120
  store float %121, float addrspace(3)* %115, align 8, !tbaa !5
  %122 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %123 = load float, float addrspace(3)* %122, align 4, !tbaa !5
  %124 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 2), align 8, !tbaa !5
  %125 = fmul contract float %123, %124
  %126 = fsub contract float %121, %125
  store float %126, float addrspace(3)* %115, align 8, !tbaa !5
  %127 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 2), align 8, !tbaa !5
  %128 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %129 = fdiv contract float %126, %127
  store float %129, float addrspace(3)* %128, align 8, !tbaa !5
  br label %130

130:                                              ; preds = %114, %112
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %113, label %131, label %148

131:                                              ; preds = %130
  %132 = load float, float addrspace(3)* %37, align 4, !tbaa !5
  %133 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 0), align 16, !tbaa !5
  %134 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %135 = load float, float addrspace(3)* %134, align 4, !tbaa !5
  %136 = fmul contract float %133, %135
  %137 = fsub contract float %132, %136
  store float %137, float addrspace(3)* %37, align 4, !tbaa !5
  %138 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 1), align 4, !tbaa !5
  %139 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %140 = load float, float addrspace(3)* %139, align 4, !tbaa !5
  %141 = fmul contract float %138, %140
  %142 = fsub contract float %137, %141
  store float %142, float addrspace(3)* %37, align 4, !tbaa !5
  %143 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 2), align 8, !tbaa !5
  %144 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %145 = load float, float addrspace(3)* %144, align 4, !tbaa !5
  %146 = fmul contract float %143, %145
  %147 = fsub contract float %142, %146
  store float %147, float addrspace(3)* %37, align 4, !tbaa !5
  br label %148

148:                                              ; preds = %131, %130
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %149 = icmp ugt i32 %6, 3
  br i1 %149, label %150, label %171

150:                                              ; preds = %148
  %151 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %152 = load float, float addrspace(3)* %151, align 4, !tbaa !5
  %153 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %154 = load float, float addrspace(3)* %153, align 16, !tbaa !5
  %155 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 3), align 4, !tbaa !5
  %156 = fmul contract float %154, %155
  %157 = fsub contract float %152, %156
  store float %157, float addrspace(3)* %151, align 4, !tbaa !5
  %158 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %159 = load float, float addrspace(3)* %158, align 4, !tbaa !5
  %160 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 3), align 4, !tbaa !5
  %161 = fmul contract float %159, %160
  %162 = fsub contract float %157, %161
  store float %162, float addrspace(3)* %151, align 4, !tbaa !5
  %163 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %164 = load float, float addrspace(3)* %163, align 8, !tbaa !5
  %165 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 3), align 4, !tbaa !5
  %166 = fmul contract float %164, %165
  %167 = fsub contract float %162, %166
  store float %167, float addrspace(3)* %151, align 4, !tbaa !5
  %168 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 3), align 4, !tbaa !5
  %169 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %170 = fdiv contract float %167, %168
  store float %170, float addrspace(3)* %169, align 4, !tbaa !5
  br label %171

171:                                              ; preds = %150, %148
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %149, label %172, label %194

172:                                              ; preds = %171
  %173 = load float, float addrspace(3)* %45, align 4, !tbaa !5
  %174 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 0), align 16, !tbaa !5
  %175 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %176 = load float, float addrspace(3)* %175, align 4, !tbaa !5
  %177 = fmul contract float %174, %176
  %178 = fsub contract float %173, %177
  store float %178, float addrspace(3)* %45, align 4, !tbaa !5
  %179 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 1), align 4, !tbaa !5
  %180 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %181 = load float, float addrspace(3)* %180, align 4, !tbaa !5
  %182 = fmul contract float %179, %181
  %183 = fsub contract float %178, %182
  store float %183, float addrspace(3)* %45, align 4, !tbaa !5
  %184 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 2), align 8, !tbaa !5
  %185 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %186 = load float, float addrspace(3)* %185, align 4, !tbaa !5
  %187 = fmul contract float %184, %186
  %188 = fsub contract float %183, %187
  store float %188, float addrspace(3)* %45, align 4, !tbaa !5
  %189 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 3), align 4, !tbaa !5
  %190 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %191 = load float, float addrspace(3)* %190, align 4, !tbaa !5
  %192 = fmul contract float %189, %191
  %193 = fsub contract float %188, %192
  store float %193, float addrspace(3)* %45, align 4, !tbaa !5
  br label %194

194:                                              ; preds = %172, %171
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %195 = icmp ugt i32 %6, 4
  br i1 %195, label %196, label %222

196:                                              ; preds = %194
  %197 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %198 = load float, float addrspace(3)* %197, align 16, !tbaa !5
  %199 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %200 = load float, float addrspace(3)* %199, align 16, !tbaa !5
  %201 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 4), align 16, !tbaa !5
  %202 = fmul contract float %200, %201
  %203 = fsub contract float %198, %202
  store float %203, float addrspace(3)* %197, align 16, !tbaa !5
  %204 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %205 = load float, float addrspace(3)* %204, align 4, !tbaa !5
  %206 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 4), align 16, !tbaa !5
  %207 = fmul contract float %205, %206
  %208 = fsub contract float %203, %207
  store float %208, float addrspace(3)* %197, align 16, !tbaa !5
  %209 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %210 = load float, float addrspace(3)* %209, align 8, !tbaa !5
  %211 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 4), align 16, !tbaa !5
  %212 = fmul contract float %210, %211
  %213 = fsub contract float %208, %212
  store float %213, float addrspace(3)* %197, align 16, !tbaa !5
  %214 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %215 = load float, float addrspace(3)* %214, align 4, !tbaa !5
  %216 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 4), align 16, !tbaa !5
  %217 = fmul contract float %215, %216
  %218 = fsub contract float %213, %217
  store float %218, float addrspace(3)* %197, align 16, !tbaa !5
  %219 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 4), align 16, !tbaa !5
  %220 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %221 = fdiv contract float %218, %219
  store float %221, float addrspace(3)* %220, align 16, !tbaa !5
  br label %222

222:                                              ; preds = %196, %194
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %195, label %223, label %250

223:                                              ; preds = %222
  %224 = load float, float addrspace(3)* %53, align 4, !tbaa !5
  %225 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 0), align 16, !tbaa !5
  %226 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %227 = load float, float addrspace(3)* %226, align 4, !tbaa !5
  %228 = fmul contract float %225, %227
  %229 = fsub contract float %224, %228
  store float %229, float addrspace(3)* %53, align 4, !tbaa !5
  %230 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 1), align 4, !tbaa !5
  %231 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %232 = load float, float addrspace(3)* %231, align 4, !tbaa !5
  %233 = fmul contract float %230, %232
  %234 = fsub contract float %229, %233
  store float %234, float addrspace(3)* %53, align 4, !tbaa !5
  %235 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 2), align 8, !tbaa !5
  %236 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %237 = load float, float addrspace(3)* %236, align 4, !tbaa !5
  %238 = fmul contract float %235, %237
  %239 = fsub contract float %234, %238
  store float %239, float addrspace(3)* %53, align 4, !tbaa !5
  %240 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 3), align 4, !tbaa !5
  %241 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %242 = load float, float addrspace(3)* %241, align 4, !tbaa !5
  %243 = fmul contract float %240, %242
  %244 = fsub contract float %239, %243
  store float %244, float addrspace(3)* %53, align 4, !tbaa !5
  %245 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 4), align 16, !tbaa !5
  %246 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %247 = load float, float addrspace(3)* %246, align 4, !tbaa !5
  %248 = fmul contract float %245, %247
  %249 = fsub contract float %244, %248
  store float %249, float addrspace(3)* %53, align 4, !tbaa !5
  br label %250

250:                                              ; preds = %223, %222
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %251 = icmp ugt i32 %6, 5
  br i1 %251, label %252, label %283

252:                                              ; preds = %250
  %253 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %254 = load float, float addrspace(3)* %253, align 4, !tbaa !5
  %255 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %256 = load float, float addrspace(3)* %255, align 16, !tbaa !5
  %257 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 5), align 4, !tbaa !5
  %258 = fmul contract float %256, %257
  %259 = fsub contract float %254, %258
  store float %259, float addrspace(3)* %253, align 4, !tbaa !5
  %260 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %261 = load float, float addrspace(3)* %260, align 4, !tbaa !5
  %262 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 5), align 4, !tbaa !5
  %263 = fmul contract float %261, %262
  %264 = fsub contract float %259, %263
  store float %264, float addrspace(3)* %253, align 4, !tbaa !5
  %265 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %266 = load float, float addrspace(3)* %265, align 8, !tbaa !5
  %267 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 5), align 4, !tbaa !5
  %268 = fmul contract float %266, %267
  %269 = fsub contract float %264, %268
  store float %269, float addrspace(3)* %253, align 4, !tbaa !5
  %270 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %271 = load float, float addrspace(3)* %270, align 4, !tbaa !5
  %272 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 5), align 4, !tbaa !5
  %273 = fmul contract float %271, %272
  %274 = fsub contract float %269, %273
  store float %274, float addrspace(3)* %253, align 4, !tbaa !5
  %275 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %276 = load float, float addrspace(3)* %275, align 16, !tbaa !5
  %277 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 5), align 4, !tbaa !5
  %278 = fmul contract float %276, %277
  %279 = fsub contract float %274, %278
  store float %279, float addrspace(3)* %253, align 4, !tbaa !5
  %280 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 5), align 4, !tbaa !5
  %281 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %282 = fdiv contract float %279, %280
  store float %282, float addrspace(3)* %281, align 4, !tbaa !5
  br label %283

283:                                              ; preds = %252, %250
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %251, label %284, label %316

284:                                              ; preds = %283
  %285 = load float, float addrspace(3)* %61, align 4, !tbaa !5
  %286 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 0), align 16, !tbaa !5
  %287 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %288 = load float, float addrspace(3)* %287, align 4, !tbaa !5
  %289 = fmul contract float %286, %288
  %290 = fsub contract float %285, %289
  store float %290, float addrspace(3)* %61, align 4, !tbaa !5
  %291 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 1), align 4, !tbaa !5
  %292 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %293 = load float, float addrspace(3)* %292, align 4, !tbaa !5
  %294 = fmul contract float %291, %293
  %295 = fsub contract float %290, %294
  store float %295, float addrspace(3)* %61, align 4, !tbaa !5
  %296 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 2), align 8, !tbaa !5
  %297 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %298 = load float, float addrspace(3)* %297, align 4, !tbaa !5
  %299 = fmul contract float %296, %298
  %300 = fsub contract float %295, %299
  store float %300, float addrspace(3)* %61, align 4, !tbaa !5
  %301 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 3), align 4, !tbaa !5
  %302 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %303 = load float, float addrspace(3)* %302, align 4, !tbaa !5
  %304 = fmul contract float %301, %303
  %305 = fsub contract float %300, %304
  store float %305, float addrspace(3)* %61, align 4, !tbaa !5
  %306 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 4), align 16, !tbaa !5
  %307 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %308 = load float, float addrspace(3)* %307, align 4, !tbaa !5
  %309 = fmul contract float %306, %308
  %310 = fsub contract float %305, %309
  store float %310, float addrspace(3)* %61, align 4, !tbaa !5
  %311 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 5), align 4, !tbaa !5
  %312 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  %313 = load float, float addrspace(3)* %312, align 4, !tbaa !5
  %314 = fmul contract float %311, %313
  %315 = fsub contract float %310, %314
  store float %315, float addrspace(3)* %61, align 4, !tbaa !5
  br label %316

316:                                              ; preds = %284, %283
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %317 = icmp ugt i32 %6, 6
  br i1 %317, label %318, label %354

318:                                              ; preds = %316
  %319 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 6
  %320 = load float, float addrspace(3)* %319, align 8, !tbaa !5
  %321 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %322 = load float, float addrspace(3)* %321, align 16, !tbaa !5
  %323 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 6), align 8, !tbaa !5
  %324 = fmul contract float %322, %323
  %325 = fsub contract float %320, %324
  store float %325, float addrspace(3)* %319, align 8, !tbaa !5
  %326 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %327 = load float, float addrspace(3)* %326, align 4, !tbaa !5
  %328 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 6), align 8, !tbaa !5
  %329 = fmul contract float %327, %328
  %330 = fsub contract float %325, %329
  store float %330, float addrspace(3)* %319, align 8, !tbaa !5
  %331 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %332 = load float, float addrspace(3)* %331, align 8, !tbaa !5
  %333 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 6), align 8, !tbaa !5
  %334 = fmul contract float %332, %333
  %335 = fsub contract float %330, %334
  store float %335, float addrspace(3)* %319, align 8, !tbaa !5
  %336 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %337 = load float, float addrspace(3)* %336, align 4, !tbaa !5
  %338 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 6), align 8, !tbaa !5
  %339 = fmul contract float %337, %338
  %340 = fsub contract float %335, %339
  store float %340, float addrspace(3)* %319, align 8, !tbaa !5
  %341 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %342 = load float, float addrspace(3)* %341, align 16, !tbaa !5
  %343 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 6), align 8, !tbaa !5
  %344 = fmul contract float %342, %343
  %345 = fsub contract float %340, %344
  store float %345, float addrspace(3)* %319, align 8, !tbaa !5
  %346 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %347 = load float, float addrspace(3)* %346, align 4, !tbaa !5
  %348 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 6), align 8, !tbaa !5
  %349 = fmul contract float %347, %348
  %350 = fsub contract float %345, %349
  store float %350, float addrspace(3)* %319, align 8, !tbaa !5
  %351 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 6), align 8, !tbaa !5
  %352 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 6
  %353 = fdiv contract float %350, %351
  store float %353, float addrspace(3)* %352, align 8, !tbaa !5
  br label %354

354:                                              ; preds = %318, %316
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %317, label %355, label %392

355:                                              ; preds = %354
  %356 = load float, float addrspace(3)* %69, align 4, !tbaa !5
  %357 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 0), align 16, !tbaa !5
  %358 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %359 = load float, float addrspace(3)* %358, align 4, !tbaa !5
  %360 = fmul contract float %357, %359
  %361 = fsub contract float %356, %360
  store float %361, float addrspace(3)* %69, align 4, !tbaa !5
  %362 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 1), align 4, !tbaa !5
  %363 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %364 = load float, float addrspace(3)* %363, align 4, !tbaa !5
  %365 = fmul contract float %362, %364
  %366 = fsub contract float %361, %365
  store float %366, float addrspace(3)* %69, align 4, !tbaa !5
  %367 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 2), align 8, !tbaa !5
  %368 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %369 = load float, float addrspace(3)* %368, align 4, !tbaa !5
  %370 = fmul contract float %367, %369
  %371 = fsub contract float %366, %370
  store float %371, float addrspace(3)* %69, align 4, !tbaa !5
  %372 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 3), align 4, !tbaa !5
  %373 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %374 = load float, float addrspace(3)* %373, align 4, !tbaa !5
  %375 = fmul contract float %372, %374
  %376 = fsub contract float %371, %375
  store float %376, float addrspace(3)* %69, align 4, !tbaa !5
  %377 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 4), align 16, !tbaa !5
  %378 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %379 = load float, float addrspace(3)* %378, align 4, !tbaa !5
  %380 = fmul contract float %377, %379
  %381 = fsub contract float %376, %380
  store float %381, float addrspace(3)* %69, align 4, !tbaa !5
  %382 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 5), align 4, !tbaa !5
  %383 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  %384 = load float, float addrspace(3)* %383, align 4, !tbaa !5
  %385 = fmul contract float %382, %384
  %386 = fsub contract float %381, %385
  store float %386, float addrspace(3)* %69, align 4, !tbaa !5
  %387 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 6), align 8, !tbaa !5
  %388 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 %6
  %389 = load float, float addrspace(3)* %388, align 4, !tbaa !5
  %390 = fmul contract float %387, %389
  %391 = fsub contract float %386, %390
  store float %391, float addrspace(3)* %69, align 4, !tbaa !5
  br label %392

392:                                              ; preds = %355, %354
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %393 = add nsw i32 %2, 1
  %394 = mul nsw i32 %393, %1
  %395 = add nsw i32 %394, %2
  %396 = load i32, i32 addrspace(3)* %22, align 4, !tbaa !5
  %397 = sext i32 %395 to i64
  %398 = add nsw i64 %397, %7
  %399 = getelementptr inbounds float, float addrspace(1)* %0, i64 %398
  %400 = bitcast float addrspace(1)* %399 to i32 addrspace(1)*
  store i32 %396, i32 addrspace(1)* %400, align 4, !tbaa !5
  %401 = add nsw i32 %395, %1
  %402 = load i32, i32 addrspace(3)* %30, align 4, !tbaa !5
  %403 = sext i32 %401 to i64
  %404 = add nsw i64 %403, %7
  %405 = getelementptr inbounds float, float addrspace(1)* %0, i64 %404
  %406 = bitcast float addrspace(1)* %405 to i32 addrspace(1)*
  store i32 %402, i32 addrspace(1)* %406, align 4, !tbaa !5
  %407 = add nsw i32 %401, %1
  %408 = load i32, i32 addrspace(3)* %38, align 4, !tbaa !5
  %409 = sext i32 %407 to i64
  %410 = add nsw i64 %409, %7
  %411 = getelementptr inbounds float, float addrspace(1)* %0, i64 %410
  %412 = bitcast float addrspace(1)* %411 to i32 addrspace(1)*
  store i32 %408, i32 addrspace(1)* %412, align 4, !tbaa !5
  %413 = add nsw i32 %407, %1
  %414 = load i32, i32 addrspace(3)* %46, align 4, !tbaa !5
  %415 = sext i32 %413 to i64
  %416 = add nsw i64 %415, %7
  %417 = getelementptr inbounds float, float addrspace(1)* %0, i64 %416
  %418 = bitcast float addrspace(1)* %417 to i32 addrspace(1)*
  store i32 %414, i32 addrspace(1)* %418, align 4, !tbaa !5
  %419 = add nsw i32 %413, %1
  %420 = load i32, i32 addrspace(3)* %54, align 4, !tbaa !5
  %421 = sext i32 %419 to i64
  %422 = add nsw i64 %421, %7
  %423 = getelementptr inbounds float, float addrspace(1)* %0, i64 %422
  %424 = bitcast float addrspace(1)* %423 to i32 addrspace(1)*
  store i32 %420, i32 addrspace(1)* %424, align 4, !tbaa !5
  %425 = add nsw i32 %419, %1
  %426 = load i32, i32 addrspace(3)* %62, align 4, !tbaa !5
  %427 = sext i32 %425 to i64
  %428 = add nsw i64 %427, %7
  %429 = getelementptr inbounds float, float addrspace(1)* %0, i64 %428
  %430 = bitcast float addrspace(1)* %429 to i32 addrspace(1)*
  store i32 %426, i32 addrspace(1)* %430, align 4, !tbaa !5
  %431 = add nsw i32 %425, %1
  %432 = load i32, i32 addrspace(3)* %70, align 4, !tbaa !5
  %433 = sext i32 %431 to i64
  %434 = add nsw i64 %433, %7
  %435 = getelementptr inbounds float, float addrspace(1)* %0, i64 %434
  %436 = bitcast float addrspace(1)* %435 to i32 addrspace(1)*
  store i32 %432, i32 addrspace(1)* %436, align 4, !tbaa !5
  ret void
}

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z13lud_perimeterPfii(float addrspace(1)* nocapture %0, i32 %1, i32 %2) local_unnamed_addr #0 {
  %4 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !4
  %5 = zext i32 %4 to i64
  %6 = icmp ult i32 %4, 8
  br i1 %6, label %7, label %102

7:                                                ; preds = %3
  %8 = mul nsw i32 %2, %1
  %9 = add nsw i32 %8, %2
  %10 = add nsw i32 %9, %4
  %11 = sext i32 %10 to i64
  %12 = getelementptr inbounds float, float addrspace(1)* %0, i64 %11
  %13 = bitcast float addrspace(1)* %12 to i32 addrspace(1)*
  %14 = load i32, i32 addrspace(1)* %13, align 4, !tbaa !5
  %15 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 %4
  %16 = bitcast float addrspace(3)* %15 to i32 addrspace(3)*
  store i32 %14, i32 addrspace(3)* %16, align 4, !tbaa !5
  %17 = add nsw i32 %9, %1
  %18 = add nsw i32 %17, %4
  %19 = sext i32 %18 to i64
  %20 = getelementptr inbounds float, float addrspace(1)* %0, i64 %19
  %21 = bitcast float addrspace(1)* %20 to i32 addrspace(1)*
  %22 = load i32, i32 addrspace(1)* %21, align 4, !tbaa !5
  %23 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 %4
  %24 = bitcast float addrspace(3)* %23 to i32 addrspace(3)*
  store i32 %22, i32 addrspace(3)* %24, align 4, !tbaa !5
  %25 = add nsw i32 %17, %1
  %26 = add nsw i32 %25, %4
  %27 = sext i32 %26 to i64
  %28 = getelementptr inbounds float, float addrspace(1)* %0, i64 %27
  %29 = bitcast float addrspace(1)* %28 to i32 addrspace(1)*
  %30 = load i32, i32 addrspace(1)* %29, align 4, !tbaa !5
  %31 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 %4
  %32 = bitcast float addrspace(3)* %31 to i32 addrspace(3)*
  store i32 %30, i32 addrspace(3)* %32, align 4, !tbaa !5
  %33 = add nsw i32 %25, %1
  %34 = add nsw i32 %33, %4
  %35 = sext i32 %34 to i64
  %36 = getelementptr inbounds float, float addrspace(1)* %0, i64 %35
  %37 = bitcast float addrspace(1)* %36 to i32 addrspace(1)*
  %38 = load i32, i32 addrspace(1)* %37, align 4, !tbaa !5
  %39 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 %4
  %40 = bitcast float addrspace(3)* %39 to i32 addrspace(3)*
  store i32 %38, i32 addrspace(3)* %40, align 4, !tbaa !5
  %41 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %42 = zext i32 %41 to i64
  %43 = shl nuw nsw i64 %42, 3
  %44 = add nuw nsw i64 %5, 8
  %45 = add nuw nsw i64 %44, %43
  %46 = sext i32 %9 to i64
  %47 = add nsw i64 %45, %46
  %48 = getelementptr inbounds float, float addrspace(1)* %0, i64 %47
  %49 = bitcast float addrspace(1)* %48 to i32 addrspace(1)*
  %50 = load i32, i32 addrspace(1)* %49, align 4, !tbaa !5
  %51 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %52 = bitcast float addrspace(3)* %51 to i32 addrspace(3)*
  store i32 %50, i32 addrspace(3)* %52, align 4, !tbaa !5
  %53 = sext i32 %17 to i64
  %54 = add nsw i64 %45, %53
  %55 = getelementptr inbounds float, float addrspace(1)* %0, i64 %54
  %56 = bitcast float addrspace(1)* %55 to i32 addrspace(1)*
  %57 = load i32, i32 addrspace(1)* %56, align 4, !tbaa !5
  %58 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %59 = bitcast float addrspace(3)* %58 to i32 addrspace(3)*
  store i32 %57, i32 addrspace(3)* %59, align 4, !tbaa !5
  %60 = sext i32 %25 to i64
  %61 = add nsw i64 %45, %60
  %62 = getelementptr inbounds float, float addrspace(1)* %0, i64 %61
  %63 = bitcast float addrspace(1)* %62 to i32 addrspace(1)*
  %64 = load i32, i32 addrspace(1)* %63, align 4, !tbaa !5
  %65 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %66 = bitcast float addrspace(3)* %65 to i32 addrspace(3)*
  store i32 %64, i32 addrspace(3)* %66, align 4, !tbaa !5
  %67 = sext i32 %33 to i64
  %68 = add nsw i64 %45, %67
  %69 = getelementptr inbounds float, float addrspace(1)* %0, i64 %68
  %70 = bitcast float addrspace(1)* %69 to i32 addrspace(1)*
  %71 = load i32, i32 addrspace(1)* %70, align 4, !tbaa !5
  %72 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %73 = bitcast float addrspace(3)* %72 to i32 addrspace(3)*
  store i32 %71, i32 addrspace(3)* %73, align 4, !tbaa !5
  %74 = add nsw i32 %33, %1
  %75 = sext i32 %74 to i64
  %76 = add nsw i64 %45, %75
  %77 = getelementptr inbounds float, float addrspace(1)* %0, i64 %76
  %78 = bitcast float addrspace(1)* %77 to i32 addrspace(1)*
  %79 = load i32, i32 addrspace(1)* %78, align 4, !tbaa !5
  %80 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %81 = bitcast float addrspace(3)* %80 to i32 addrspace(3)*
  store i32 %79, i32 addrspace(3)* %81, align 4, !tbaa !5
  %82 = add nsw i32 %74, %1
  %83 = sext i32 %82 to i64
  %84 = add nsw i64 %45, %83
  %85 = getelementptr inbounds float, float addrspace(1)* %0, i64 %84
  %86 = bitcast float addrspace(1)* %85 to i32 addrspace(1)*
  %87 = load i32, i32 addrspace(1)* %86, align 4, !tbaa !5
  %88 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %89 = bitcast float addrspace(3)* %88 to i32 addrspace(3)*
  store i32 %87, i32 addrspace(3)* %89, align 4, !tbaa !5
  %90 = add nsw i32 %82, %1
  %91 = sext i32 %90 to i64
  %92 = add nsw i64 %45, %91
  %93 = getelementptr inbounds float, float addrspace(1)* %0, i64 %92
  %94 = bitcast float addrspace(1)* %93 to i32 addrspace(1)*
  %95 = load i32, i32 addrspace(1)* %94, align 4, !tbaa !5
  %96 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %97 = bitcast float addrspace(3)* %96 to i32 addrspace(3)*
  store i32 %95, i32 addrspace(3)* %97, align 4, !tbaa !5
  %98 = add nsw i32 %90, %1
  %99 = sext i32 %98 to i64
  %100 = add nsw i64 %45, %99
  %101 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  br label %203

102:                                              ; preds = %3
  %103 = add nsw i32 %4, -8
  %104 = add nsw i32 %2, 4
  %105 = mul nsw i32 %104, %1
  %106 = add nsw i32 %105, %2
  %107 = add nsw i32 %106, %103
  %108 = sext i32 %107 to i64
  %109 = getelementptr inbounds float, float addrspace(1)* %0, i64 %108
  %110 = bitcast float addrspace(1)* %109 to i32 addrspace(1)*
  %111 = load i32, i32 addrspace(1)* %110, align 4, !tbaa !5
  %112 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 %103
  %113 = bitcast float addrspace(3)* %112 to i32 addrspace(3)*
  store i32 %111, i32 addrspace(3)* %113, align 4, !tbaa !5
  %114 = add nsw i32 %106, %1
  %115 = add nsw i32 %114, %103
  %116 = sext i32 %115 to i64
  %117 = getelementptr inbounds float, float addrspace(1)* %0, i64 %116
  %118 = bitcast float addrspace(1)* %117 to i32 addrspace(1)*
  %119 = load i32, i32 addrspace(1)* %118, align 4, !tbaa !5
  %120 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 %103
  %121 = bitcast float addrspace(3)* %120 to i32 addrspace(3)*
  store i32 %119, i32 addrspace(3)* %121, align 4, !tbaa !5
  %122 = add nsw i32 %114, %1
  %123 = add nsw i32 %122, %103
  %124 = sext i32 %123 to i64
  %125 = getelementptr inbounds float, float addrspace(1)* %0, i64 %124
  %126 = bitcast float addrspace(1)* %125 to i32 addrspace(1)*
  %127 = load i32, i32 addrspace(1)* %126, align 4, !tbaa !5
  %128 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 %103
  %129 = bitcast float addrspace(3)* %128 to i32 addrspace(3)*
  store i32 %127, i32 addrspace(3)* %129, align 4, !tbaa !5
  %130 = add nsw i32 %122, %1
  %131 = add nsw i32 %130, %103
  %132 = sext i32 %131 to i64
  %133 = getelementptr inbounds float, float addrspace(1)* %0, i64 %132
  %134 = bitcast float addrspace(1)* %133 to i32 addrspace(1)*
  %135 = load i32, i32 addrspace(1)* %134, align 4, !tbaa !5
  %136 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 %103
  %137 = bitcast float addrspace(3)* %136 to i32 addrspace(3)*
  store i32 %135, i32 addrspace(3)* %137, align 4, !tbaa !5
  %138 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %139 = shl i32 %138, 3
  %140 = add i32 %2, 8
  %141 = add i32 %140, %139
  %142 = mul i32 %141, %1
  %143 = add i32 %142, %2
  %144 = add nsw i32 %143, %103
  %145 = sext i32 %144 to i64
  %146 = getelementptr inbounds float, float addrspace(1)* %0, i64 %145
  %147 = bitcast float addrspace(1)* %146 to i32 addrspace(1)*
  %148 = load i32, i32 addrspace(1)* %147, align 4, !tbaa !5
  %149 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 0, i32 %103
  %150 = bitcast float addrspace(3)* %149 to i32 addrspace(3)*
  store i32 %148, i32 addrspace(3)* %150, align 4, !tbaa !5
  %151 = add nsw i32 %143, %1
  %152 = add nsw i32 %151, %103
  %153 = sext i32 %152 to i64
  %154 = getelementptr inbounds float, float addrspace(1)* %0, i64 %153
  %155 = bitcast float addrspace(1)* %154 to i32 addrspace(1)*
  %156 = load i32, i32 addrspace(1)* %155, align 4, !tbaa !5
  %157 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 1, i32 %103
  %158 = bitcast float addrspace(3)* %157 to i32 addrspace(3)*
  store i32 %156, i32 addrspace(3)* %158, align 4, !tbaa !5
  %159 = add nsw i32 %151, %1
  %160 = add nsw i32 %159, %103
  %161 = sext i32 %160 to i64
  %162 = getelementptr inbounds float, float addrspace(1)* %0, i64 %161
  %163 = bitcast float addrspace(1)* %162 to i32 addrspace(1)*
  %164 = load i32, i32 addrspace(1)* %163, align 4, !tbaa !5
  %165 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 2, i32 %103
  %166 = bitcast float addrspace(3)* %165 to i32 addrspace(3)*
  store i32 %164, i32 addrspace(3)* %166, align 4, !tbaa !5
  %167 = add nsw i32 %159, %1
  %168 = add nsw i32 %167, %103
  %169 = sext i32 %168 to i64
  %170 = getelementptr inbounds float, float addrspace(1)* %0, i64 %169
  %171 = bitcast float addrspace(1)* %170 to i32 addrspace(1)*
  %172 = load i32, i32 addrspace(1)* %171, align 4, !tbaa !5
  %173 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 3, i32 %103
  %174 = bitcast float addrspace(3)* %173 to i32 addrspace(3)*
  store i32 %172, i32 addrspace(3)* %174, align 4, !tbaa !5
  %175 = add nsw i32 %167, %1
  %176 = add nsw i32 %175, %103
  %177 = sext i32 %176 to i64
  %178 = getelementptr inbounds float, float addrspace(1)* %0, i64 %177
  %179 = bitcast float addrspace(1)* %178 to i32 addrspace(1)*
  %180 = load i32, i32 addrspace(1)* %179, align 4, !tbaa !5
  %181 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 4, i32 %103
  %182 = bitcast float addrspace(3)* %181 to i32 addrspace(3)*
  store i32 %180, i32 addrspace(3)* %182, align 4, !tbaa !5
  %183 = add nsw i32 %175, %1
  %184 = add nsw i32 %183, %103
  %185 = sext i32 %184 to i64
  %186 = getelementptr inbounds float, float addrspace(1)* %0, i64 %185
  %187 = bitcast float addrspace(1)* %186 to i32 addrspace(1)*
  %188 = load i32, i32 addrspace(1)* %187, align 4, !tbaa !5
  %189 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 5, i32 %103
  %190 = bitcast float addrspace(3)* %189 to i32 addrspace(3)*
  store i32 %188, i32 addrspace(3)* %190, align 4, !tbaa !5
  %191 = add nsw i32 %183, %1
  %192 = add nsw i32 %191, %103
  %193 = sext i32 %192 to i64
  %194 = getelementptr inbounds float, float addrspace(1)* %0, i64 %193
  %195 = bitcast float addrspace(1)* %194 to i32 addrspace(1)*
  %196 = load i32, i32 addrspace(1)* %195, align 4, !tbaa !5
  %197 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 6, i32 %103
  %198 = bitcast float addrspace(3)* %197 to i32 addrspace(3)*
  store i32 %196, i32 addrspace(3)* %198, align 4, !tbaa !5
  %199 = add nsw i32 %191, %1
  %200 = add nsw i32 %199, %103
  %201 = sext i32 %200 to i64
  %202 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 7, i32 %103
  br label %203

203:                                              ; preds = %102, %7
  %204 = phi float addrspace(3)* [ %202, %102 ], [ %101, %7 ]
  %205 = phi i64 [ %201, %102 ], [ %100, %7 ]
  %206 = getelementptr inbounds float, float addrspace(1)* %0, i64 %205
  %207 = bitcast float addrspace(1)* %206 to i32 addrspace(1)*
  %208 = load i32, i32 addrspace(1)* %207, align 4, !tbaa !5
  %209 = bitcast float addrspace(3)* %204 to i32 addrspace(3)*
  store i32 %208, i32 addrspace(3)* %209, align 4, !tbaa !5
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %6, label %210, label %365

210:                                              ; preds = %203
  %211 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %212 = load float, float addrspace(3)* %211, align 4, !tbaa !5
  %213 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 0), align 16, !tbaa !5
  %214 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %215 = load float, float addrspace(3)* %214, align 4, !tbaa !5
  %216 = fmul contract float %213, %215
  %217 = fsub contract float %212, %216
  store float %217, float addrspace(3)* %211, align 4, !tbaa !5
  %218 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %219 = load float, float addrspace(3)* %218, align 4, !tbaa !5
  %220 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 0), align 16, !tbaa !5
  %221 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %222 = load float, float addrspace(3)* %221, align 4, !tbaa !5
  %223 = fmul contract float %220, %222
  %224 = fsub contract float %219, %223
  store float %224, float addrspace(3)* %218, align 4, !tbaa !5
  %225 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 1), align 4, !tbaa !5
  %226 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %227 = load float, float addrspace(3)* %226, align 4, !tbaa !5
  %228 = fmul contract float %225, %227
  %229 = fsub contract float %224, %228
  store float %229, float addrspace(3)* %218, align 4, !tbaa !5
  %230 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %231 = load float, float addrspace(3)* %230, align 4, !tbaa !5
  %232 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 0), align 16, !tbaa !5
  %233 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %234 = load float, float addrspace(3)* %233, align 4, !tbaa !5
  %235 = fmul contract float %232, %234
  %236 = fsub contract float %231, %235
  store float %236, float addrspace(3)* %230, align 4, !tbaa !5
  %237 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 1), align 4, !tbaa !5
  %238 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %239 = load float, float addrspace(3)* %238, align 4, !tbaa !5
  %240 = fmul contract float %237, %239
  %241 = fsub contract float %236, %240
  store float %241, float addrspace(3)* %230, align 4, !tbaa !5
  %242 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 2), align 8, !tbaa !5
  %243 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %244 = load float, float addrspace(3)* %243, align 4, !tbaa !5
  %245 = fmul contract float %242, %244
  %246 = fsub contract float %241, %245
  store float %246, float addrspace(3)* %230, align 4, !tbaa !5
  %247 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %248 = load float, float addrspace(3)* %247, align 4, !tbaa !5
  %249 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 0), align 16, !tbaa !5
  %250 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %251 = load float, float addrspace(3)* %250, align 4, !tbaa !5
  %252 = fmul contract float %249, %251
  %253 = fsub contract float %248, %252
  store float %253, float addrspace(3)* %247, align 4, !tbaa !5
  %254 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 1), align 4, !tbaa !5
  %255 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %256 = load float, float addrspace(3)* %255, align 4, !tbaa !5
  %257 = fmul contract float %254, %256
  %258 = fsub contract float %253, %257
  store float %258, float addrspace(3)* %247, align 4, !tbaa !5
  %259 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 2), align 8, !tbaa !5
  %260 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %261 = load float, float addrspace(3)* %260, align 4, !tbaa !5
  %262 = fmul contract float %259, %261
  %263 = fsub contract float %258, %262
  store float %263, float addrspace(3)* %247, align 4, !tbaa !5
  %264 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 3), align 4, !tbaa !5
  %265 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %266 = load float, float addrspace(3)* %265, align 4, !tbaa !5
  %267 = fmul contract float %264, %266
  %268 = fsub contract float %263, %267
  store float %268, float addrspace(3)* %247, align 4, !tbaa !5
  %269 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %270 = load float, float addrspace(3)* %269, align 4, !tbaa !5
  %271 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 0), align 16, !tbaa !5
  %272 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %273 = load float, float addrspace(3)* %272, align 4, !tbaa !5
  %274 = fmul contract float %271, %273
  %275 = fsub contract float %270, %274
  store float %275, float addrspace(3)* %269, align 4, !tbaa !5
  %276 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 1), align 4, !tbaa !5
  %277 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %278 = load float, float addrspace(3)* %277, align 4, !tbaa !5
  %279 = fmul contract float %276, %278
  %280 = fsub contract float %275, %279
  store float %280, float addrspace(3)* %269, align 4, !tbaa !5
  %281 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 2), align 8, !tbaa !5
  %282 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %283 = load float, float addrspace(3)* %282, align 4, !tbaa !5
  %284 = fmul contract float %281, %283
  %285 = fsub contract float %280, %284
  store float %285, float addrspace(3)* %269, align 4, !tbaa !5
  %286 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 3), align 4, !tbaa !5
  %287 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %288 = load float, float addrspace(3)* %287, align 4, !tbaa !5
  %289 = fmul contract float %286, %288
  %290 = fsub contract float %285, %289
  store float %290, float addrspace(3)* %269, align 4, !tbaa !5
  %291 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 4), align 16, !tbaa !5
  %292 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %293 = load float, float addrspace(3)* %292, align 4, !tbaa !5
  %294 = fmul contract float %291, %293
  %295 = fsub contract float %290, %294
  store float %295, float addrspace(3)* %269, align 4, !tbaa !5
  %296 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %297 = load float, float addrspace(3)* %296, align 4, !tbaa !5
  %298 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 0), align 16, !tbaa !5
  %299 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %300 = load float, float addrspace(3)* %299, align 4, !tbaa !5
  %301 = fmul contract float %298, %300
  %302 = fsub contract float %297, %301
  store float %302, float addrspace(3)* %296, align 4, !tbaa !5
  %303 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 1), align 4, !tbaa !5
  %304 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %305 = load float, float addrspace(3)* %304, align 4, !tbaa !5
  %306 = fmul contract float %303, %305
  %307 = fsub contract float %302, %306
  store float %307, float addrspace(3)* %296, align 4, !tbaa !5
  %308 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 2), align 8, !tbaa !5
  %309 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %310 = load float, float addrspace(3)* %309, align 4, !tbaa !5
  %311 = fmul contract float %308, %310
  %312 = fsub contract float %307, %311
  store float %312, float addrspace(3)* %296, align 4, !tbaa !5
  %313 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 3), align 4, !tbaa !5
  %314 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %315 = load float, float addrspace(3)* %314, align 4, !tbaa !5
  %316 = fmul contract float %313, %315
  %317 = fsub contract float %312, %316
  store float %317, float addrspace(3)* %296, align 4, !tbaa !5
  %318 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 4), align 16, !tbaa !5
  %319 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %320 = load float, float addrspace(3)* %319, align 4, !tbaa !5
  %321 = fmul contract float %318, %320
  %322 = fsub contract float %317, %321
  store float %322, float addrspace(3)* %296, align 4, !tbaa !5
  %323 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 5), align 4, !tbaa !5
  %324 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %325 = load float, float addrspace(3)* %324, align 4, !tbaa !5
  %326 = fmul contract float %323, %325
  %327 = fsub contract float %322, %326
  store float %327, float addrspace(3)* %296, align 4, !tbaa !5
  %328 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %329 = load float, float addrspace(3)* %328, align 4, !tbaa !5
  %330 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 0), align 16, !tbaa !5
  %331 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %332 = load float, float addrspace(3)* %331, align 4, !tbaa !5
  %333 = fmul contract float %330, %332
  %334 = fsub contract float %329, %333
  store float %334, float addrspace(3)* %328, align 4, !tbaa !5
  %335 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 1), align 4, !tbaa !5
  %336 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %337 = load float, float addrspace(3)* %336, align 4, !tbaa !5
  %338 = fmul contract float %335, %337
  %339 = fsub contract float %334, %338
  store float %339, float addrspace(3)* %328, align 4, !tbaa !5
  %340 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 2), align 8, !tbaa !5
  %341 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %342 = load float, float addrspace(3)* %341, align 4, !tbaa !5
  %343 = fmul contract float %340, %342
  %344 = fsub contract float %339, %343
  store float %344, float addrspace(3)* %328, align 4, !tbaa !5
  %345 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 3), align 4, !tbaa !5
  %346 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %347 = load float, float addrspace(3)* %346, align 4, !tbaa !5
  %348 = fmul contract float %345, %347
  %349 = fsub contract float %344, %348
  store float %349, float addrspace(3)* %328, align 4, !tbaa !5
  %350 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 4), align 16, !tbaa !5
  %351 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %352 = load float, float addrspace(3)* %351, align 4, !tbaa !5
  %353 = fmul contract float %350, %352
  %354 = fsub contract float %349, %353
  store float %354, float addrspace(3)* %328, align 4, !tbaa !5
  %355 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 5), align 4, !tbaa !5
  %356 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %357 = load float, float addrspace(3)* %356, align 4, !tbaa !5
  %358 = fmul contract float %355, %357
  %359 = fsub contract float %354, %358
  store float %359, float addrspace(3)* %328, align 4, !tbaa !5
  %360 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 6), align 8, !tbaa !5
  %361 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %362 = load float, float addrspace(3)* %361, align 4, !tbaa !5
  %363 = fmul contract float %360, %362
  %364 = fsub contract float %359, %363
  store float %364, float addrspace(3)* %328, align 4, !tbaa !5
  br label %533

365:                                              ; preds = %203
  %366 = add nsw i32 %4, -8
  %367 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 0
  %368 = load float, float addrspace(3)* %367, align 16, !tbaa !5
  %369 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 0), align 16, !tbaa !5
  %370 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 0
  %371 = fdiv contract float %368, %369
  store float %371, float addrspace(3)* %370, align 16, !tbaa !5
  %372 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 1
  %373 = load float, float addrspace(3)* %372, align 4, !tbaa !5
  %374 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 1), align 4, !tbaa !5
  %375 = fmul contract float %371, %374
  %376 = fsub contract float %373, %375
  store float %376, float addrspace(3)* %372, align 4, !tbaa !5
  %377 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 1), align 4, !tbaa !5
  %378 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 1
  %379 = fdiv contract float %376, %377
  store float %379, float addrspace(3)* %378, align 4, !tbaa !5
  %380 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 2
  %381 = load float, float addrspace(3)* %380, align 8, !tbaa !5
  %382 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 2), align 8, !tbaa !5
  %383 = fmul contract float %371, %382
  %384 = fsub contract float %381, %383
  store float %384, float addrspace(3)* %380, align 8, !tbaa !5
  %385 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 1
  %386 = load float, float addrspace(3)* %385, align 4, !tbaa !5
  %387 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 2), align 8, !tbaa !5
  %388 = fmul contract float %386, %387
  %389 = fsub contract float %384, %388
  store float %389, float addrspace(3)* %380, align 8, !tbaa !5
  %390 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 2), align 8, !tbaa !5
  %391 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 2
  %392 = fdiv contract float %389, %390
  store float %392, float addrspace(3)* %391, align 8, !tbaa !5
  %393 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 3
  %394 = load float, float addrspace(3)* %393, align 4, !tbaa !5
  %395 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 3), align 4, !tbaa !5
  %396 = fmul contract float %371, %395
  %397 = fsub contract float %394, %396
  store float %397, float addrspace(3)* %393, align 4, !tbaa !5
  %398 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 1
  %399 = load float, float addrspace(3)* %398, align 4, !tbaa !5
  %400 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 3), align 4, !tbaa !5
  %401 = fmul contract float %399, %400
  %402 = fsub contract float %397, %401
  store float %402, float addrspace(3)* %393, align 4, !tbaa !5
  %403 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 2
  %404 = load float, float addrspace(3)* %403, align 8, !tbaa !5
  %405 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 3), align 4, !tbaa !5
  %406 = fmul contract float %404, %405
  %407 = fsub contract float %402, %406
  store float %407, float addrspace(3)* %393, align 4, !tbaa !5
  %408 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 3), align 4, !tbaa !5
  %409 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 3
  %410 = fdiv contract float %407, %408
  store float %410, float addrspace(3)* %409, align 4, !tbaa !5
  %411 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 4
  %412 = load float, float addrspace(3)* %411, align 16, !tbaa !5
  %413 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 4), align 16, !tbaa !5
  %414 = fmul contract float %371, %413
  %415 = fsub contract float %412, %414
  store float %415, float addrspace(3)* %411, align 16, !tbaa !5
  %416 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 1
  %417 = load float, float addrspace(3)* %416, align 4, !tbaa !5
  %418 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 4), align 16, !tbaa !5
  %419 = fmul contract float %417, %418
  %420 = fsub contract float %415, %419
  store float %420, float addrspace(3)* %411, align 16, !tbaa !5
  %421 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 2
  %422 = load float, float addrspace(3)* %421, align 8, !tbaa !5
  %423 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 4), align 16, !tbaa !5
  %424 = fmul contract float %422, %423
  %425 = fsub contract float %420, %424
  store float %425, float addrspace(3)* %411, align 16, !tbaa !5
  %426 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 3
  %427 = load float, float addrspace(3)* %426, align 4, !tbaa !5
  %428 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 4), align 16, !tbaa !5
  %429 = fmul contract float %427, %428
  %430 = fsub contract float %425, %429
  store float %430, float addrspace(3)* %411, align 16, !tbaa !5
  %431 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 4), align 16, !tbaa !5
  %432 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 4
  %433 = fdiv contract float %430, %431
  store float %433, float addrspace(3)* %432, align 16, !tbaa !5
  %434 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 5
  %435 = load float, float addrspace(3)* %434, align 4, !tbaa !5
  %436 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 5), align 4, !tbaa !5
  %437 = fmul contract float %371, %436
  %438 = fsub contract float %435, %437
  store float %438, float addrspace(3)* %434, align 4, !tbaa !5
  %439 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 1
  %440 = load float, float addrspace(3)* %439, align 4, !tbaa !5
  %441 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 5), align 4, !tbaa !5
  %442 = fmul contract float %440, %441
  %443 = fsub contract float %438, %442
  store float %443, float addrspace(3)* %434, align 4, !tbaa !5
  %444 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 2
  %445 = load float, float addrspace(3)* %444, align 8, !tbaa !5
  %446 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 5), align 4, !tbaa !5
  %447 = fmul contract float %445, %446
  %448 = fsub contract float %443, %447
  store float %448, float addrspace(3)* %434, align 4, !tbaa !5
  %449 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 3
  %450 = load float, float addrspace(3)* %449, align 4, !tbaa !5
  %451 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 5), align 4, !tbaa !5
  %452 = fmul contract float %450, %451
  %453 = fsub contract float %448, %452
  store float %453, float addrspace(3)* %434, align 4, !tbaa !5
  %454 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 4
  %455 = load float, float addrspace(3)* %454, align 16, !tbaa !5
  %456 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 5), align 4, !tbaa !5
  %457 = fmul contract float %455, %456
  %458 = fsub contract float %453, %457
  store float %458, float addrspace(3)* %434, align 4, !tbaa !5
  %459 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 5), align 4, !tbaa !5
  %460 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 5
  %461 = fdiv contract float %458, %459
  store float %461, float addrspace(3)* %460, align 4, !tbaa !5
  %462 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 6
  %463 = load float, float addrspace(3)* %462, align 8, !tbaa !5
  %464 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 6), align 8, !tbaa !5
  %465 = fmul contract float %371, %464
  %466 = fsub contract float %463, %465
  store float %466, float addrspace(3)* %462, align 8, !tbaa !5
  %467 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 1
  %468 = load float, float addrspace(3)* %467, align 4, !tbaa !5
  %469 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 6), align 8, !tbaa !5
  %470 = fmul contract float %468, %469
  %471 = fsub contract float %466, %470
  store float %471, float addrspace(3)* %462, align 8, !tbaa !5
  %472 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 2
  %473 = load float, float addrspace(3)* %472, align 8, !tbaa !5
  %474 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 6), align 8, !tbaa !5
  %475 = fmul contract float %473, %474
  %476 = fsub contract float %471, %475
  store float %476, float addrspace(3)* %462, align 8, !tbaa !5
  %477 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 3
  %478 = load float, float addrspace(3)* %477, align 4, !tbaa !5
  %479 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 6), align 8, !tbaa !5
  %480 = fmul contract float %478, %479
  %481 = fsub contract float %476, %480
  store float %481, float addrspace(3)* %462, align 8, !tbaa !5
  %482 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 4
  %483 = load float, float addrspace(3)* %482, align 16, !tbaa !5
  %484 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 6), align 8, !tbaa !5
  %485 = fmul contract float %483, %484
  %486 = fsub contract float %481, %485
  store float %486, float addrspace(3)* %462, align 8, !tbaa !5
  %487 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 5
  %488 = load float, float addrspace(3)* %487, align 4, !tbaa !5
  %489 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 6), align 8, !tbaa !5
  %490 = fmul contract float %488, %489
  %491 = fsub contract float %486, %490
  store float %491, float addrspace(3)* %462, align 8, !tbaa !5
  %492 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 6), align 8, !tbaa !5
  %493 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 6
  %494 = fdiv contract float %491, %492
  store float %494, float addrspace(3)* %493, align 8, !tbaa !5
  %495 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 7
  %496 = load float, float addrspace(3)* %495, align 4, !tbaa !5
  %497 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 7), align 4, !tbaa !5
  %498 = fmul contract float %371, %497
  %499 = fsub contract float %496, %498
  store float %499, float addrspace(3)* %495, align 4, !tbaa !5
  %500 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 1
  %501 = load float, float addrspace(3)* %500, align 4, !tbaa !5
  %502 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 7), align 4, !tbaa !5
  %503 = fmul contract float %501, %502
  %504 = fsub contract float %499, %503
  store float %504, float addrspace(3)* %495, align 4, !tbaa !5
  %505 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 2
  %506 = load float, float addrspace(3)* %505, align 8, !tbaa !5
  %507 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 7), align 4, !tbaa !5
  %508 = fmul contract float %506, %507
  %509 = fsub contract float %504, %508
  store float %509, float addrspace(3)* %495, align 4, !tbaa !5
  %510 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 3
  %511 = load float, float addrspace(3)* %510, align 4, !tbaa !5
  %512 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 7), align 4, !tbaa !5
  %513 = fmul contract float %511, %512
  %514 = fsub contract float %509, %513
  store float %514, float addrspace(3)* %495, align 4, !tbaa !5
  %515 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 4
  %516 = load float, float addrspace(3)* %515, align 16, !tbaa !5
  %517 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 7), align 4, !tbaa !5
  %518 = fmul contract float %516, %517
  %519 = fsub contract float %514, %518
  store float %519, float addrspace(3)* %495, align 4, !tbaa !5
  %520 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 5
  %521 = load float, float addrspace(3)* %520, align 4, !tbaa !5
  %522 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 7), align 4, !tbaa !5
  %523 = fmul contract float %521, %522
  %524 = fsub contract float %519, %523
  store float %524, float addrspace(3)* %495, align 4, !tbaa !5
  %525 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 6
  %526 = load float, float addrspace(3)* %525, align 8, !tbaa !5
  %527 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 7), align 4, !tbaa !5
  %528 = fmul contract float %526, %527
  %529 = fsub contract float %524, %528
  store float %529, float addrspace(3)* %495, align 4, !tbaa !5
  %530 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 7), align 4, !tbaa !5
  %531 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %366, i32 7
  %532 = fdiv contract float %529, %530
  store float %532, float addrspace(3)* %531, align 4, !tbaa !5
  br label %533

533:                                              ; preds = %210, %365
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %6, label %534, label %594

534:                                              ; preds = %533
  %535 = add nsw i32 %2, 1
  %536 = mul nsw i32 %535, %1
  %537 = add nsw i32 %536, %2
  %538 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %539 = zext i32 %538 to i64
  %540 = shl nuw nsw i64 %539, 3
  %541 = add nuw nsw i64 %5, 8
  %542 = add nuw nsw i64 %541, %540
  %543 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %544 = bitcast float addrspace(3)* %543 to i32 addrspace(3)*
  %545 = load i32, i32 addrspace(3)* %544, align 4, !tbaa !5
  %546 = sext i32 %537 to i64
  %547 = add nsw i64 %542, %546
  %548 = getelementptr inbounds float, float addrspace(1)* %0, i64 %547
  %549 = bitcast float addrspace(1)* %548 to i32 addrspace(1)*
  store i32 %545, i32 addrspace(1)* %549, align 4, !tbaa !5
  %550 = add nsw i32 %537, %1
  %551 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %552 = bitcast float addrspace(3)* %551 to i32 addrspace(3)*
  %553 = load i32, i32 addrspace(3)* %552, align 4, !tbaa !5
  %554 = sext i32 %550 to i64
  %555 = add nsw i64 %542, %554
  %556 = getelementptr inbounds float, float addrspace(1)* %0, i64 %555
  %557 = bitcast float addrspace(1)* %556 to i32 addrspace(1)*
  store i32 %553, i32 addrspace(1)* %557, align 4, !tbaa !5
  %558 = add nsw i32 %550, %1
  %559 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %560 = bitcast float addrspace(3)* %559 to i32 addrspace(3)*
  %561 = load i32, i32 addrspace(3)* %560, align 4, !tbaa !5
  %562 = sext i32 %558 to i64
  %563 = add nsw i64 %542, %562
  %564 = getelementptr inbounds float, float addrspace(1)* %0, i64 %563
  %565 = bitcast float addrspace(1)* %564 to i32 addrspace(1)*
  store i32 %561, i32 addrspace(1)* %565, align 4, !tbaa !5
  %566 = add nsw i32 %558, %1
  %567 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %568 = bitcast float addrspace(3)* %567 to i32 addrspace(3)*
  %569 = load i32, i32 addrspace(3)* %568, align 4, !tbaa !5
  %570 = sext i32 %566 to i64
  %571 = add nsw i64 %542, %570
  %572 = getelementptr inbounds float, float addrspace(1)* %0, i64 %571
  %573 = bitcast float addrspace(1)* %572 to i32 addrspace(1)*
  store i32 %569, i32 addrspace(1)* %573, align 4, !tbaa !5
  %574 = add nsw i32 %566, %1
  %575 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %576 = bitcast float addrspace(3)* %575 to i32 addrspace(3)*
  %577 = load i32, i32 addrspace(3)* %576, align 4, !tbaa !5
  %578 = sext i32 %574 to i64
  %579 = add nsw i64 %542, %578
  %580 = getelementptr inbounds float, float addrspace(1)* %0, i64 %579
  %581 = bitcast float addrspace(1)* %580 to i32 addrspace(1)*
  store i32 %577, i32 addrspace(1)* %581, align 4, !tbaa !5
  %582 = add nsw i32 %574, %1
  %583 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %584 = bitcast float addrspace(3)* %583 to i32 addrspace(3)*
  %585 = load i32, i32 addrspace(3)* %584, align 4, !tbaa !5
  %586 = sext i32 %582 to i64
  %587 = add nsw i64 %542, %586
  %588 = getelementptr inbounds float, float addrspace(1)* %0, i64 %587
  %589 = bitcast float addrspace(1)* %588 to i32 addrspace(1)*
  store i32 %585, i32 addrspace(1)* %589, align 4, !tbaa !5
  %590 = add nsw i32 %582, %1
  %591 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %592 = sext i32 %590 to i64
  %593 = add nsw i64 %542, %592
  br label %661

594:                                              ; preds = %533
  %595 = add nsw i32 %4, -8
  %596 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %597 = shl i32 %596, 3
  %598 = add i32 %2, 8
  %599 = add i32 %598, %597
  %600 = mul i32 %599, %1
  %601 = add i32 %600, %2
  %602 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 0, i32 %595
  %603 = bitcast float addrspace(3)* %602 to i32 addrspace(3)*
  %604 = load i32, i32 addrspace(3)* %603, align 4, !tbaa !5
  %605 = add nsw i32 %601, %595
  %606 = sext i32 %605 to i64
  %607 = getelementptr inbounds float, float addrspace(1)* %0, i64 %606
  %608 = bitcast float addrspace(1)* %607 to i32 addrspace(1)*
  store i32 %604, i32 addrspace(1)* %608, align 4, !tbaa !5
  %609 = add nsw i32 %601, %1
  %610 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 1, i32 %595
  %611 = bitcast float addrspace(3)* %610 to i32 addrspace(3)*
  %612 = load i32, i32 addrspace(3)* %611, align 4, !tbaa !5
  %613 = add nsw i32 %609, %595
  %614 = sext i32 %613 to i64
  %615 = getelementptr inbounds float, float addrspace(1)* %0, i64 %614
  %616 = bitcast float addrspace(1)* %615 to i32 addrspace(1)*
  store i32 %612, i32 addrspace(1)* %616, align 4, !tbaa !5
  %617 = add nsw i32 %609, %1
  %618 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 2, i32 %595
  %619 = bitcast float addrspace(3)* %618 to i32 addrspace(3)*
  %620 = load i32, i32 addrspace(3)* %619, align 4, !tbaa !5
  %621 = add nsw i32 %617, %595
  %622 = sext i32 %621 to i64
  %623 = getelementptr inbounds float, float addrspace(1)* %0, i64 %622
  %624 = bitcast float addrspace(1)* %623 to i32 addrspace(1)*
  store i32 %620, i32 addrspace(1)* %624, align 4, !tbaa !5
  %625 = add nsw i32 %617, %1
  %626 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 3, i32 %595
  %627 = bitcast float addrspace(3)* %626 to i32 addrspace(3)*
  %628 = load i32, i32 addrspace(3)* %627, align 4, !tbaa !5
  %629 = add nsw i32 %625, %595
  %630 = sext i32 %629 to i64
  %631 = getelementptr inbounds float, float addrspace(1)* %0, i64 %630
  %632 = bitcast float addrspace(1)* %631 to i32 addrspace(1)*
  store i32 %628, i32 addrspace(1)* %632, align 4, !tbaa !5
  %633 = add nsw i32 %625, %1
  %634 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 4, i32 %595
  %635 = bitcast float addrspace(3)* %634 to i32 addrspace(3)*
  %636 = load i32, i32 addrspace(3)* %635, align 4, !tbaa !5
  %637 = add nsw i32 %633, %595
  %638 = sext i32 %637 to i64
  %639 = getelementptr inbounds float, float addrspace(1)* %0, i64 %638
  %640 = bitcast float addrspace(1)* %639 to i32 addrspace(1)*
  store i32 %636, i32 addrspace(1)* %640, align 4, !tbaa !5
  %641 = add nsw i32 %633, %1
  %642 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 5, i32 %595
  %643 = bitcast float addrspace(3)* %642 to i32 addrspace(3)*
  %644 = load i32, i32 addrspace(3)* %643, align 4, !tbaa !5
  %645 = add nsw i32 %641, %595
  %646 = sext i32 %645 to i64
  %647 = getelementptr inbounds float, float addrspace(1)* %0, i64 %646
  %648 = bitcast float addrspace(1)* %647 to i32 addrspace(1)*
  store i32 %644, i32 addrspace(1)* %648, align 4, !tbaa !5
  %649 = add nsw i32 %641, %1
  %650 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 6, i32 %595
  %651 = bitcast float addrspace(3)* %650 to i32 addrspace(3)*
  %652 = load i32, i32 addrspace(3)* %651, align 4, !tbaa !5
  %653 = add nsw i32 %649, %595
  %654 = sext i32 %653 to i64
  %655 = getelementptr inbounds float, float addrspace(1)* %0, i64 %654
  %656 = bitcast float addrspace(1)* %655 to i32 addrspace(1)*
  store i32 %652, i32 addrspace(1)* %656, align 4, !tbaa !5
  %657 = add nsw i32 %649, %1
  %658 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 7, i32 %595
  %659 = add nsw i32 %657, %595
  %660 = sext i32 %659 to i64
  br label %661

661:                                              ; preds = %594, %534
  %662 = phi i64 [ %660, %594 ], [ %593, %534 ]
  %663 = phi float addrspace(3)* [ %658, %594 ], [ %591, %534 ]
  %664 = bitcast float addrspace(3)* %663 to i32 addrspace(3)*
  %665 = load i32, i32 addrspace(3)* %664, align 4, !tbaa !5
  %666 = getelementptr inbounds float, float addrspace(1)* %0, i64 %662
  %667 = bitcast float addrspace(1)* %666 to i32 addrspace(1)*
  store i32 %665, i32 addrspace(1)* %667, align 4, !tbaa !5
  ret void
}

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z12lud_internalPfii(float addrspace(1)* nocapture %0, i32 %1, i32 %2) local_unnamed_addr #0 {
  %4 = sext i32 %2 to i64
  %5 = tail call i32 @llvm.amdgcn.workgroup.id.y() #3
  %6 = shl i32 %5, 3
  %7 = add i32 %2, 8
  %8 = add i32 %7, %6
  %9 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %10 = shl i32 %9, 3
  %11 = add i32 %7, %10
  %12 = tail call i32 @llvm.amdgcn.workitem.id.y() #3, !range !4
  %13 = zext i32 %12 to i64
  %14 = add nsw i64 %4, %13
  %15 = sext i32 %1 to i64
  %16 = mul i64 %14, %15
  %17 = sext i32 %11 to i64
  %18 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !4
  %19 = zext i32 %18 to i64
  %20 = add nsw i64 %17, %19
  %21 = add i64 %20, %16
  %22 = getelementptr inbounds float, float addrspace(1)* %0, i64 %21
  %23 = bitcast float addrspace(1)* %22 to i32 addrspace(1)*
  %24 = load i32, i32 addrspace(1)* %23, align 4, !tbaa !5
  %25 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 %12, i32 %18
  %26 = bitcast float addrspace(3)* %25 to i32 addrspace(3)*
  store i32 %24, i32 addrspace(3)* %26, align 4, !tbaa !5
  %27 = sext i32 %8 to i64
  %28 = add nsw i64 %27, %13
  %29 = mul i64 %28, %15
  %30 = add i64 %29, %19
  %31 = add i64 %30, %4
  %32 = getelementptr inbounds float, float addrspace(1)* %0, i64 %31
  %33 = bitcast float addrspace(1)* %32 to i32 addrspace(1)*
  %34 = load i32, i32 addrspace(1)* %33, align 4, !tbaa !5
  %35 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 %18
  %36 = bitcast float addrspace(3)* %35 to i32 addrspace(3)*
  store i32 %34, i32 addrspace(3)* %36, align 4, !tbaa !5
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %37 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 0
  %38 = load float, float addrspace(3)* %37, align 16, !tbaa !5
  %39 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 0, i32 %18
  %40 = load float, float addrspace(3)* %39, align 4, !tbaa !5
  %41 = fmul contract float %38, %40
  %42 = fadd contract float %41, 0.000000e+00
  %43 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 1
  %44 = load float, float addrspace(3)* %43, align 4, !tbaa !5
  %45 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 1, i32 %18
  %46 = load float, float addrspace(3)* %45, align 4, !tbaa !5
  %47 = fmul contract float %44, %46
  %48 = fadd contract float %42, %47
  %49 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 2
  %50 = load float, float addrspace(3)* %49, align 8, !tbaa !5
  %51 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 2, i32 %18
  %52 = load float, float addrspace(3)* %51, align 4, !tbaa !5
  %53 = fmul contract float %50, %52
  %54 = fadd contract float %48, %53
  %55 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 3
  %56 = load float, float addrspace(3)* %55, align 4, !tbaa !5
  %57 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 3, i32 %18
  %58 = load float, float addrspace(3)* %57, align 4, !tbaa !5
  %59 = fmul contract float %56, %58
  %60 = fadd contract float %54, %59
  %61 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 4
  %62 = load float, float addrspace(3)* %61, align 16, !tbaa !5
  %63 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 4, i32 %18
  %64 = load float, float addrspace(3)* %63, align 4, !tbaa !5
  %65 = fmul contract float %62, %64
  %66 = fadd contract float %60, %65
  %67 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 5
  %68 = load float, float addrspace(3)* %67, align 4, !tbaa !5
  %69 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 5, i32 %18
  %70 = load float, float addrspace(3)* %69, align 4, !tbaa !5
  %71 = fmul contract float %68, %70
  %72 = fadd contract float %66, %71
  %73 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 6
  %74 = load float, float addrspace(3)* %73, align 8, !tbaa !5
  %75 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 6, i32 %18
  %76 = load float, float addrspace(3)* %75, align 4, !tbaa !5
  %77 = fmul contract float %74, %76
  %78 = fadd contract float %72, %77
  %79 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 7
  %80 = load float, float addrspace(3)* %79, align 4, !tbaa !5
  %81 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 7, i32 %18
  %82 = load float, float addrspace(3)* %81, align 4, !tbaa !5
  %83 = fmul contract float %80, %82
  %84 = fadd contract float %78, %83
  %85 = add i64 %20, %29
  %86 = getelementptr inbounds float, float addrspace(1)* %0, i64 %85
  %87 = load float, float addrspace(1)* %86, align 4, !tbaa !5
  %88 = fsub contract float %87, %84
  store float %88, float addrspace(1)* %86, align 4, !tbaa !5
  ret void
}

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.y() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.y() #2

attributes #0 = { convergent norecurse nounwind "amdgpu-flat-work-group-size"="1,1024" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { convergent nounwind willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/RadeonOpenCompute/llvm-project roc-4.2.0 21161 b204d7f0cae65b6cd4446eec50fc1fb675d582af)"}
!4 = !{i32 0, i32 1024}
!5 = !{!6, !6, i64 0}
!6 = !{!"float", !7, i64 0}
!7 = !{!"omnipotent char", !8, i64 0}
!8 = !{!"Simple C++ TBAA"}
