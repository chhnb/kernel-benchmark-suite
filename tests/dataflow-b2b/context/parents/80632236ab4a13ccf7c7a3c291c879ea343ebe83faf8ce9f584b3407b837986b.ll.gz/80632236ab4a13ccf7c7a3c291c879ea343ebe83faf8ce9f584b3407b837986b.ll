; ModuleID = '/data/home/chh/kernel-benchmark-suite-dataflow-b2b/build/dataflow-corpus/step7/MapAiry/anchor/normalize-15-16-0/fused.ll'
source_filename = "/home/chh/kernel-benchmark-suite/cases/boost-mapairy/source/kernel.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

@_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 0x3FE428A2F98D728B, double 0x3FE965FEA53D6E3D, double 1.000000e+00, double 0x3FF428A2F98D728B, double 0x3FF965FEA53D6E3D], align 16

; Function Attrs: nofree norecurse nounwind
define protected amdgpu_kernel void @evaluate(double addrspace(1)* nocapture readonly %input.coerce, double addrspace(1)* nocapture %output.coerce, i32 %n) local_unnamed_addr #0 {
entry:
  %0 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %1 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %2 = getelementptr i8, i8 addrspace(4)* %1, i64 4
  %3 = bitcast i8 addrspace(4)* %2 to i16 addrspace(4)*
  %4 = load i16, i16 addrspace(4)* %3, align 4, !range !5, !invariant.load !6
  %5 = zext i16 %4 to i32
  %6 = mul i32 %0, %5
  %7 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !7
  %add = add i32 %6, %7
  %cmp = icmp slt i32 %add, %n
  br i1 %cmp, label %if.end8.i.i, label %if.end

if.end8.i.i:                                      ; preds = %entry
  %idxprom = sext i32 %add to i64
  %arrayidx11 = getelementptr inbounds double, double addrspace(1)* %input.coerce, i64 %idxprom
  %arrayidx.val = load double, double addrspace(1)* %arrayidx11, align 8, !tbaa !8
  %cmp.i3.i.i = fcmp olt double %arrayidx.val, 0.000000e+00
  %cmp1.i.i.i = fcmp ogt double %arrayidx.val, 1.000000e+00
  %or.cond.i.i.i = or i1 %cmp.i3.i.i, %cmp1.i.i.i
  br i1 %or.cond.i.i.i, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %lor.lhs.false2.i.i.i

lor.lhs.false2.i.i.i:                             ; preds = %if.end8.i.i
  %cmp.i.i.i.i.i = fcmp uno double %arrayidx.val, 0.000000e+00
  %cmp.i3.i.i.i.i = fcmp ogt double %arrayidx.val, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i4.i.i = fcmp olt double %arrayidx.val, 0xFFEFFFFFFFFFFFFF
  %lnot.i.i.i.i.not = or i1 %cmp.i3.i.i.i.i, %cmp1.i.i.i4.i.i
  %brmerge = or i1 %cmp.i.i.i.i.i, %lnot.i.i.i.i.not
  br i1 %brmerge, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %if.end14.i.i

if.end14.i.i:                                     ; preds = %lor.lhs.false2.i.i.i
  %cmp.i.i.i = fcmp ogt double %arrayidx.val, 5.000000e-01
  br i1 %cmp.i.i.i, label %if.then.i.i.i, label %cond.false7.i.i.i

if.then.i.i.i:                                    ; preds = %if.end14.i.i
  %sub.i.i.i = fsub double 1.000000e+00, %arrayidx.val
  %decision.interval4 = fcmp ult double %sub.i.i.i, 1.250000e-01
  br i1 %decision.interval4, label %if.else9.i.i.i.i, label %decision.dispatch3, !decision.condition_prefix !6

decision.dispatch3:                               ; preds = %if.then.i.i.i
  %cmp.i.i.i.i = fcmp ult double %sub.i.i.i, 2.500000e-01
  %8 = select i1 %cmp.i.i.i.i, double -1.250000e-01, double -2.500000e-01
  %9 = fadd double %sub.i.i.i, %8
  %10 = fmul double %9, %9
  %11 = fmul double %10, 0x409819CEF5B4E6C7
  %12 = fadd double %11, 0xC096FC492E087B38
  %13 = select i1 %cmp.i.i.i.i, double 0x4051B7FD7FEEB259, double 0x404567B47A5D8CA4
  %14 = fmul double %10, %13
  %15 = select i1 %cmp.i.i.i.i, double 0xC07E56261CB553E9, double 0x405E69E51891A050
  %16 = fsub double %15, %14
  %17 = fmul double %10, 0x4050AAC38C60A1E3
  %18 = fsub double 0x40548E4AE13E33D8, %17
  %19 = fmul double %10, %16
  %20 = select i1 %cmp.i.i.i.i, double %12, double %18
  %21 = fmul double %10, %20
  %.op = fadd double %19, 0xC04860792DC1D02E
  %22 = select i1 %cmp.i.i.i.i, double 0x4036AD73494335DA, double 0xC0407FAA65922A12
  %23 = fadd double %21, %22
  %24 = fmul double %10, %.op
  %.op1 = fadd double %19, 0x4034FFCB850049DF
  %25 = fmul double %10, %23
  %.op2 = fadd double %24, 0xC005F196AB7EF904
  %26 = select i1 %cmp.i.i.i.i, double 0x3FFB3E8B8B7EC8F9, double 0x3FDED118296B2018
  %27 = fadd double %25, %26
  %28 = select i1 %cmp.i.i.i.i, double %.op1, double %.op2
  %29 = fmul double %9, %28
  %30 = fadd double %27, %29
  br i1 %cmp.i.i.i.i, label %fusion.common11, label %fusion.side12

if.else9.i.i.i.i:                                 ; preds = %if.then.i.i.i
  %31 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %sub.i.i.i) #3
  %32 = add nsw i32 %31, -1
  %33 = fcmp uno double %sub.i.i.i, 0.000000e+00
  %34 = tail call double @llvm.fabs.f64(double %sub.i.i.i) #4
  %35 = fcmp oeq double %34, 0x7FF0000000000000
  %36 = or i1 %33, %35
  %37 = select i1 %36, i32 2147483647, i32 %32
  %38 = fcmp oeq double %sub.i.i.i, 0.000000e+00
  %39 = select i1 %38, i32 -2147483648, i32 %37
  %cmp11.i.i.i.i = icmp sgt i32 %39, -5
  br i1 %cmp11.i.i.i.i, label %if.then12.i.i.i.i, label %if.else21.i.i.i.i

if.then12.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %40 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 3) #3
  %41 = tail call double @llvm.amdgcn.frexp.mant.f64(double %40) #3
  %42 = fcmp olt double %41, 0x3FE5555555555555
  %43 = zext i1 %42 to i32
  %44 = tail call double @llvm.amdgcn.ldexp.f64(double %41, i32 %43) #3
  %45 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %40) #3
  %46 = sub nsw i32 %45, %43
  %47 = fadd double %44, -1.000000e+00
  %48 = fadd double %44, 1.000000e+00
  %49 = fsub double %48, %44
  %50 = fsub double %48, %49
  %51 = fsub double %44, %50
  %52 = fsub double 1.000000e+00, %49
  %53 = fadd double %52, %51
  %54 = tail call double @llvm.amdgcn.rcp.f64(double %48) #3
  %55 = fneg double %48
  %56 = tail call double @llvm.fma.f64(double %55, double %54, double 1.000000e+00) #3
  %57 = tail call double @llvm.fma.f64(double %56, double %54, double %54) #3
  %58 = tail call double @llvm.fma.f64(double %55, double %57, double 1.000000e+00) #3
  %59 = tail call double @llvm.fma.f64(double %58, double %57, double %57) #3
  %60 = fmul double %47, %59
  %61 = fmul double %48, %60
  %62 = fneg double %61
  %63 = tail call double @llvm.fma.f64(double %60, double %48, double %62) #3
  %64 = tail call double @llvm.fma.f64(double %60, double %53, double %63) #3
  %65 = fadd double %61, %64
  %66 = fsub double %65, %61
  %67 = fsub double %64, %66
  %68 = fsub double %47, %65
  %69 = fsub double %47, %68
  %70 = fsub double %69, %65
  %71 = fsub double %70, %67
  %72 = fadd double %68, %71
  %73 = fmul double %59, %72
  %74 = fadd double %60, %73
  %75 = fsub double %74, %60
  %76 = fsub double %73, %75
  %77 = fmul double %74, %74
  %78 = fneg double %77
  %79 = tail call double @llvm.fma.f64(double %74, double %74, double %78) #3
  %80 = fmul double %76, 2.000000e+00
  %81 = tail call double @llvm.fma.f64(double %74, double %80, double %79) #3
  %82 = tail call double @llvm.fma.f64(double %76, double %76, double %81) #3
  %83 = fadd double %77, %82
  %84 = fsub double %83, %77
  %85 = fsub double %82, %84
  %86 = tail call double @llvm.fma.f64(double %83, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %87 = tail call double @llvm.fma.f64(double %83, double %86, double 0x3FC7474DD7F4DF2E) #3
  %88 = tail call double @llvm.fma.f64(double %83, double %87, double 0x3FCC71C016291751) #3
  %89 = tail call double @llvm.fma.f64(double %83, double %88, double 0x3FD249249B27ACF1) #3
  %90 = tail call double @llvm.fma.f64(double %83, double %89, double 0x3FD99999998EF7B6) #3
  %91 = tail call double @llvm.fma.f64(double %83, double %90, double 0x3FE5555555555780) #3
  %92 = tail call double @llvm.amdgcn.ldexp.f64(double %74, i32 1) #3
  %93 = tail call double @llvm.amdgcn.ldexp.f64(double %76, i32 1) #3
  %94 = fmul double %74, %83
  %95 = fneg double %94
  %96 = tail call double @llvm.fma.f64(double %74, double %83, double %95) #3
  %97 = fmul double %76, %83
  %98 = tail call double @llvm.fma.f64(double %74, double %85, double %97) #3
  %99 = fadd double %96, %98
  %100 = fadd double %94, %99
  %101 = fsub double %100, %94
  %102 = fsub double %99, %101
  %103 = fmul double %100, %91
  %104 = fneg double %103
  %105 = tail call double @llvm.fma.f64(double %100, double %91, double %104) #3
  %106 = tail call double @llvm.fma.f64(double %102, double %91, double %105) #3
  %107 = fadd double %103, %106
  %108 = fsub double %107, %103
  %109 = fsub double %106, %108
  %110 = fadd double %92, %107
  %111 = fsub double %110, %92
  %112 = fsub double %110, %111
  %113 = fsub double %92, %112
  %114 = fsub double %107, %111
  %115 = fadd double %114, %113
  %116 = fadd double %93, %109
  %117 = fsub double %116, %93
  %118 = fsub double %116, %117
  %119 = fsub double %93, %118
  %120 = fsub double %109, %117
  %121 = fadd double %120, %119
  %122 = fadd double %116, %115
  %123 = fadd double %110, %122
  %124 = fsub double %123, %110
  %125 = fsub double %122, %124
  %126 = fadd double %121, %125
  %127 = fadd double %123, %126
  %128 = fsub double %127, %123
  %129 = fsub double %126, %128
  %130 = sitofp i32 %46 to double
  %131 = fmul double %127, 0x3FF71547652B82FE
  %132 = fneg double %131
  %133 = fmul double %127, 0x3C7777D0FFDA0D24
  %134 = insertelement <2 x double> undef, double %127, i32 0
  %135 = insertelement <2 x double> %134, double %129, i32 1
  %136 = insertelement <2 x double> undef, double %132, i32 0
  %137 = insertelement <2 x double> %136, double %133, i32 1
  %138 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %135, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %137) #3
  %139 = extractelement <2 x double> %138, i32 0
  %140 = extractelement <2 x double> %138, i32 1
  %141 = fadd double %139, %140
  %142 = fadd double %131, %141
  %143 = fsub double %142, %131
  %144 = fsub double %141, %143
  %145 = fadd double %142, %130
  %146 = fsub double %145, %130
  %147 = fsub double %146, %145
  %148 = fadd double %147, %130
  %149 = fsub double %142, %146
  %150 = fadd double %149, %148
  %151 = fadd double %144, %150
  %152 = fadd double %145, %151
  %153 = tail call double @llvm.fabs.f64(double %40) #4
  %154 = fcmp oeq double %153, 0x7FF0000000000000
  %155 = select i1 %154, double %40, double %152
  %156 = fcmp olt double %40, 0.000000e+00
  %157 = select i1 %156, double 0x7FF8000000000000, double %155
  %158 = fcmp oeq double %40, 0.000000e+00
  %159 = select i1 %158, double 0xFFF0000000000000, double %157
  %mul.i.i682.i.i.i.i = fmul double %159, %159
  %mul1.i.i683.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3ED3E1F985CBB733
  %add.i.i684.i.i.i.i = fadd double %mul1.i.i683.i.i.i.i, 0x3F385DA443F57737
  %mul5.i.i685.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F24E9382EAABDBB
  %add7.i.i686.i.i.i.i = fadd double %mul5.i.i685.i.i.i.i, 0x3F77E2A342AA4E3B
  %mul10.i.i687.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i684.i.i.i.i
  %mul12.i.i688.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i686.i.i.i.i
  %add15.i.i689.i.i.i.i = fadd double %mul10.i.i687.i.i.i.i, 0x3F9808F2B640E69B
  %add18.i.i690.i.i.i.i = fadd double %mul12.i.i688.i.i.i.i, 0x3F9DD5C523A6CF6D
  %mul20.i.i691.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i689.i.i.i.i
  %mul22.i.i692.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i690.i.i.i.i
  %add25.i.i693.i.i.i.i = fadd double %mul20.i.i691.i.i.i.i, 0x3FD3E6D375851610
  %add28.i.i694.i.i.i.i = fadd double %mul22.i.i692.i.i.i.i, 0x3FDB3E8B8B7EC8FA
  %160 = fmul double %159, %add25.i.i693.i.i.i.i
  %add33.i.i696.i.i.i.i = fsub double %add28.i.i694.i.i.i.i, %160
  %mul1.i.i668.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3EF03AD80F271435
  %add.i.i669.i.i.i.i = fadd double %mul1.i.i668.i.i.i.i, 0x3F577B23357A1929
  %mul5.i.i670.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F27C5B13F4BAFF2
  %add7.i.i671.i.i.i.i = fadd double %mul5.i.i670.i.i.i.i, 0x3F825620F70E4E86
  %mul10.i.i672.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i669.i.i.i.i
  %mul12.i.i673.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i671.i.i.i.i
  %add15.i.i674.i.i.i.i = fadd double %mul10.i.i672.i.i.i.i, 0x3FA38976FFA62DF3
  %add18.i.i675.i.i.i.i = fadd double %mul12.i.i673.i.i.i.i, 0x3FBACD3553111974
  %mul20.i.i676.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i674.i.i.i.i
  %mul22.i.i677.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i675.i.i.i.i
  %add25.i.i678.i.i.i.i = fadd double %mul20.i.i676.i.i.i.i, 0x3FDA8C1A7A09CF75
  %add28.i.i679.i.i.i.i = fadd double %mul22.i.i677.i.i.i.i, 1.000000e+00
  %161 = fmul double %159, %add25.i.i678.i.i.i.i
  %add33.i.i681.i.i.i.i = fsub double %add28.i.i679.i.i.i.i, %161
  %mul.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i590.i.i.i.i = fcmp ogt double %mul.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i591.i.i.i.i = fcmp oeq double %mul.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i592.i.i.i.i = or i1 %cmp.i.i.i.i590.i.i.i.i, %cmp.i.i.i591.i.i.i.i
  br i1 %or.cond.i.i.i592.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end.i.i.i594.i.i.i.i

if.end.i.i.i594.i.i.i.i:                          ; preds = %if.then12.i.i.i.i
  %cmp.i.i.i.i.i593.i.i.i.i = fcmp uno double %mul.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i593.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end7.i.i.i620.i.i.i.i

if.end7.i.i.i620.i.i.i.i:                         ; preds = %if.end.i.i.i594.i.i.i.i
  %162 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul.i.i.i.i) #3
  %163 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul.i.i.i.i) #3
  %164 = tail call i1 @llvm.amdgcn.class.f64(double %mul.i.i.i.i, i32 519) #3
  %165 = select i1 %164, i32 0, i32 %162
  %166 = select i1 %164, double %mul.i.i.i.i, double %163
  %mul.i.i.i.i.i606.i.i.i.i = fmul double %166, %166
  %mul1.i.i.i.i.i607.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i608.i.i.i.i = fadd double %mul1.i.i.i.i.i607.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i609.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FE479D17050CA47
  %167 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i609.i.i.i.i
  %mul10.i.i.i.i.i611.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %add.i.i.i.i.i608.i.i.i.i
  %mul12.i.i.i.i.i612.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %167
  %add15.i.i.i.i.i613.i.i.i.i = fadd double %mul10.i.i.i.i.i611.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i614.i.i.i.i = fadd double %mul12.i.i.i.i.i612.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i615.i.i.i.i = fmul double %166, %add15.i.i.i.i.i613.i.i.i.i
  %add23.i.i.i.i.i616.i.i.i.i = fadd double %add18.i.i.i.i.i614.i.i.i.i, %mul20.i.i.i.i.i615.i.i.i.i
  %.frozen = freeze i32 %165
  %div.i.i.i617.i.i.i.i = sdiv i32 %.frozen, 3
  %168 = call i32 @llvm.abs.i32(i32 %div.i.i.i617.i.i.i.i, i1 true)
  %cmp11.i.i.i619.i.i.i.i = icmp ugt i32 %168, 63
  %cmp13.i.i.i621.i.i.i.i = icmp sgt i32 %165, 2
  %decision.take = or i1 %cmp11.i.i.i619.i.i.i.i, %cmp13.i.i.i621.i.i.i.i
  %169 = sub nsw i32 0, %div.i.i.i617.i.i.i.i
  %fusion.paired.v = select i1 %decision.take, i32 %div.i.i.i617.i.i.i.i, i32 %169
  %fusion.paired = zext i32 %fusion.paired.v to i64
  %170 = shl nuw i64 1, %fusion.paired
  %171 = uitofp i64 %170 to double
  br i1 %decision.take, label %fusion.side4, label %fusion.side5

fusion.side4:                                     ; preds = %if.end7.i.i.i620.i.i.i.i
  %172 = fmul double %add23.i.i.i.i.i616.i.i.i.i, %171
  %173 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i616.i.i.i.i, i32 %div.i.i.i617.i.i.i.i) #3
  %174 = select i1 %cmp11.i.i.i619.i.i.i.i, double %173, double %172
  br label %if.end23.i.i.i640.i.i.i.i

fusion.side5:                                     ; preds = %if.end7.i.i.i620.i.i.i.i
  %175 = fdiv double %add23.i.i.i.i.i616.i.i.i.i, %171
  br label %if.end23.i.i.i640.i.i.i.i

if.end23.i.i.i640.i.i.i.i:                        ; preds = %fusion.side5, %fusion.side4
  %guess.i.i.i589.i.i.i.i.0 = phi double [ %174, %fusion.side4 ], [ %175, %fusion.side5 ]
  %.neg6 = mul nsw i32 %div.i.i.i617.i.i.i.i, -3
  %rem.i.i.i635.i.i.i.i.decomposed = add i32 %.frozen, 2
  %add.i.i.i636.i.i.i.i = add i32 %rem.i.i.i635.i.i.i.i.decomposed, %.neg6
  %176 = zext i32 %add.i.i.i636.i.i.i.i to i64
  %arrayidx1.i.i.i637.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %176
  %177 = load double, double addrspace(4)* %arrayidx1.i.i.i637.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i638.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.0, %177
  %cmp26.i.i.i639.i.i.i.i = icmp slt i32 %165, 1021
  br i1 %cmp26.i.i.i639.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i

do.body.i.i.i651.i.i.i.i:                         ; preds = %do.body.i.i.i651.i.i.i.i, %if.end23.i.i.i640.i.i.i.i
  %guess.i.i.i589.i.i.i.i.1 = phi double [ %mul24.i.i.i638.i.i.i.i, %if.end23.i.i.i640.i.i.i.i ], [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ]
  %mul28.i.i.i641.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %guess.i.i.i589.i.i.i.i.1
  %mul29.i.i.i642.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %mul28.i.i.i641.i.i.i.i
  %add30.i.i.i643.i.i.i.i = fadd double %mul.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add31.i.i.i644.i.i.i.i = fadd double %mul.i.i.i.i, %add30.i.i.i643.i.i.i.i
  %add32.i.i.i645.i.i.i.i = fadd double %mul29.i.i.i642.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add33.i.i.i646.i.i.i.i = fadd double %mul.i.i.i.i, %add32.i.i.i645.i.i.i.i
  %div34.i.i.i647.i.i.i.i = fdiv double %add31.i.i.i644.i.i.i.i, %add33.i.i.i646.i.i.i.i
  %mul35.i.i.i648.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %div34.i.i.i647.i.i.i.i
  %sub36.i.i.i649.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i647.i.i.i.i
  %178 = tail call double @llvm.fabs.f64(double %sub36.i.i.i649.i.i.i.i) #3
  %cmp38.i.i.i650.i.i.i.i = fcmp ogt double %178, 0x3EC0000000000000
  br i1 %cmp38.i.i.i650.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

do.body40.i.i.i662.i.i.i.i:                       ; preds = %do.body40.i.i.i662.i.i.i.i, %if.end23.i.i.i640.i.i.i.i
  %guess.i.i.i589.i.i.i.i.2 = phi double [ %mul24.i.i.i638.i.i.i.i, %if.end23.i.i.i640.i.i.i.i ], [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ]
  %mul41.i.i.i652.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, %guess.i.i.i589.i.i.i.i.2
  %div42.i.i.i653.i.i.i.i = fdiv double %mul.i.i.i.i, %guess.i.i.i589.i.i.i.i.2
  %sub43.i.i.i654.i.i.i.i = fsub double %mul41.i.i.i652.i.i.i.i, %div42.i.i.i653.i.i.i.i
  %mul44.i.i.i655.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i656.i.i.i.i = fdiv double %mul.i.i.i.i, %mul41.i.i.i652.i.i.i.i
  %add46.i.i.i657.i.i.i.i = fadd double %mul44.i.i.i655.i.i.i.i, %div45.i.i.i656.i.i.i.i
  %div47.i.i.i658.i.i.i.i = fdiv double %sub43.i.i.i654.i.i.i.i, %add46.i.i.i657.i.i.i.i
  %sub48.i.i.i659.i.i.i.i = fsub double %guess.i.i.i589.i.i.i.i.2, %div47.i.i.i658.i.i.i.i
  %mul50.i.i.i660.i.i.i.i = fmul double %sub48.i.i.i659.i.i.i.i, 0x3EC0000000000000
  %179 = tail call double @llvm.fabs.f64(double %div47.i.i.i658.i.i.i.i) #3
  %cmp52.i.i.i661.i.i.i.i = fcmp olt double %mul50.i.i.i660.i.i.i.i, %179
  br i1 %cmp52.i.i.i661.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i: ; preds = %do.body40.i.i.i662.i.i.i.i, %do.body.i.i.i651.i.i.i.i, %if.end.i.i.i594.i.i.i.i, %if.then12.i.i.i.i
  %retval.0.i.i.i665.i.i.i.i = phi double [ %mul.i.i.i.i, %if.then12.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i594.i.i.i.i ], [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ], [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ]
  %mul19.i.i.i.i = fmul double %add33.i.i681.i.i.i.i, %retval.0.i.i.i665.i.i.i.i
  %div20.i.i.i.i = fdiv double %add33.i.i696.i.i.i.i, %mul19.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else21.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %cmp23.i.i.i.i = icmp sgt i32 %39, -9
  br i1 %cmp23.i.i.i.i, label %if.then24.i.i.i.i, label %if.else35.i.i.i.i

if.then24.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %180 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 4) #3
  %181 = tail call double @llvm.amdgcn.frexp.mant.f64(double %180) #3
  %182 = fcmp olt double %181, 0x3FE5555555555555
  %183 = zext i1 %182 to i32
  %184 = tail call double @llvm.amdgcn.ldexp.f64(double %181, i32 %183) #3
  %185 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %180) #3
  %186 = sub nsw i32 %185, %183
  %187 = fadd double %184, -1.000000e+00
  %188 = fadd double %184, 1.000000e+00
  %189 = fsub double %188, %184
  %190 = fsub double %188, %189
  %191 = fsub double %184, %190
  %192 = fsub double 1.000000e+00, %189
  %193 = fadd double %192, %191
  %194 = tail call double @llvm.amdgcn.rcp.f64(double %188) #3
  %195 = fneg double %188
  %196 = tail call double @llvm.fma.f64(double %195, double %194, double 1.000000e+00) #3
  %197 = tail call double @llvm.fma.f64(double %196, double %194, double %194) #3
  %198 = tail call double @llvm.fma.f64(double %195, double %197, double 1.000000e+00) #3
  %199 = tail call double @llvm.fma.f64(double %198, double %197, double %197) #3
  %200 = fmul double %187, %199
  %201 = fmul double %188, %200
  %202 = fneg double %201
  %203 = tail call double @llvm.fma.f64(double %200, double %188, double %202) #3
  %204 = tail call double @llvm.fma.f64(double %200, double %193, double %203) #3
  %205 = fadd double %201, %204
  %206 = fsub double %205, %201
  %207 = fsub double %204, %206
  %208 = fsub double %187, %205
  %209 = fsub double %187, %208
  %210 = fsub double %209, %205
  %211 = fsub double %210, %207
  %212 = fadd double %208, %211
  %213 = fmul double %199, %212
  %214 = fadd double %200, %213
  %215 = fsub double %214, %200
  %216 = fsub double %213, %215
  %217 = fmul double %214, %214
  %218 = fneg double %217
  %219 = tail call double @llvm.fma.f64(double %214, double %214, double %218) #3
  %220 = fmul double %216, 2.000000e+00
  %221 = tail call double @llvm.fma.f64(double %214, double %220, double %219) #3
  %222 = tail call double @llvm.fma.f64(double %216, double %216, double %221) #3
  %223 = fadd double %217, %222
  %224 = fsub double %223, %217
  %225 = fsub double %222, %224
  %226 = tail call double @llvm.fma.f64(double %223, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %227 = tail call double @llvm.fma.f64(double %223, double %226, double 0x3FC7474DD7F4DF2E) #3
  %228 = tail call double @llvm.fma.f64(double %223, double %227, double 0x3FCC71C016291751) #3
  %229 = tail call double @llvm.fma.f64(double %223, double %228, double 0x3FD249249B27ACF1) #3
  %230 = tail call double @llvm.fma.f64(double %223, double %229, double 0x3FD99999998EF7B6) #3
  %231 = tail call double @llvm.fma.f64(double %223, double %230, double 0x3FE5555555555780) #3
  %232 = tail call double @llvm.amdgcn.ldexp.f64(double %214, i32 1) #3
  %233 = tail call double @llvm.amdgcn.ldexp.f64(double %216, i32 1) #3
  %234 = fmul double %214, %223
  %235 = fneg double %234
  %236 = tail call double @llvm.fma.f64(double %214, double %223, double %235) #3
  %237 = fmul double %216, %223
  %238 = tail call double @llvm.fma.f64(double %214, double %225, double %237) #3
  %239 = fadd double %236, %238
  %240 = fadd double %234, %239
  %241 = fsub double %240, %234
  %242 = fsub double %239, %241
  %243 = fmul double %240, %231
  %244 = fneg double %243
  %245 = tail call double @llvm.fma.f64(double %240, double %231, double %244) #3
  %246 = tail call double @llvm.fma.f64(double %242, double %231, double %245) #3
  %247 = fadd double %243, %246
  %248 = fsub double %247, %243
  %249 = fsub double %246, %248
  %250 = fadd double %232, %247
  %251 = fsub double %250, %232
  %252 = fsub double %250, %251
  %253 = fsub double %232, %252
  %254 = fsub double %247, %251
  %255 = fadd double %254, %253
  %256 = fadd double %233, %249
  %257 = fsub double %256, %233
  %258 = fsub double %256, %257
  %259 = fsub double %233, %258
  %260 = fsub double %249, %257
  %261 = fadd double %260, %259
  %262 = fadd double %256, %255
  %263 = fadd double %250, %262
  %264 = fsub double %263, %250
  %265 = fsub double %262, %264
  %266 = fadd double %261, %265
  %267 = fadd double %263, %266
  %268 = fsub double %267, %263
  %269 = fsub double %266, %268
  %270 = sitofp i32 %186 to double
  %271 = fmul double %267, 0x3FF71547652B82FE
  %272 = fneg double %271
  %273 = fmul double %267, 0x3C7777D0FFDA0D24
  %274 = insertelement <2 x double> undef, double %267, i32 0
  %275 = insertelement <2 x double> %274, double %269, i32 1
  %276 = insertelement <2 x double> undef, double %272, i32 0
  %277 = insertelement <2 x double> %276, double %273, i32 1
  %278 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %275, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %277) #3
  %279 = extractelement <2 x double> %278, i32 0
  %280 = extractelement <2 x double> %278, i32 1
  %281 = fadd double %279, %280
  %282 = fadd double %271, %281
  %283 = fsub double %282, %271
  %284 = fsub double %281, %283
  %285 = fadd double %282, %270
  %286 = fsub double %285, %270
  %287 = fsub double %286, %285
  %288 = fadd double %287, %270
  %289 = fsub double %282, %286
  %290 = fadd double %289, %288
  %291 = fadd double %284, %290
  %292 = fadd double %285, %291
  %293 = tail call double @llvm.fabs.f64(double %180) #4
  %294 = fcmp oeq double %293, 0x7FF0000000000000
  %295 = select i1 %294, double %180, double %292
  %296 = fcmp olt double %180, 0.000000e+00
  %297 = select i1 %296, double 0x7FF8000000000000, double %295
  %298 = fcmp oeq double %180, 0.000000e+00
  %299 = select i1 %298, double 0xFFF0000000000000, double %297
  %mul.i.i565.i.i.i.i = fmul double %299, %299
  %mul1.i.i566.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3E919A5BE1262808
  %add.i.i567.i.i.i.i = fadd double %mul1.i.i566.i.i.i.i, 0x3F07A5175B4661FC
  %mul5.i.i568.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3ED3058F91E15D9E
  %add7.i.i569.i.i.i.i = fadd double %mul5.i.i568.i.i.i.i, 0x3F360A6A52B6CEE1
  %mul10.i.i570.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i567.i.i.i.i
  %mul12.i.i571.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i569.i.i.i.i
  %add15.i.i572.i.i.i.i = fadd double %mul10.i.i570.i.i.i.i, 0x3F5C5B8FA36BAEC3
  %add18.i.i573.i.i.i.i = fadd double %mul12.i.i571.i.i.i.i, 0x3F80EDCAE3A5BFEE
  %mul20.i.i574.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i572.i.i.i.i
  %mul22.i.i575.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i573.i.i.i.i
  %add25.i.i576.i.i.i.i = fadd double %mul20.i.i574.i.i.i.i, 0x3F9A5E78F653B833
  %add28.i.i577.i.i.i.i = fadd double %mul22.i.i575.i.i.i.i, 0x3FB5AC2080A26513
  %mul30.i.i578.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i576.i.i.i.i
  %mul32.i.i579.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i577.i.i.i.i
  %add35.i.i580.i.i.i.i = fadd double %mul30.i.i578.i.i.i.i, 0x3FC65686F7A4EE22
  %add38.i.i581.i.i.i.i = fadd double %mul32.i.i579.i.i.i.i, 0x3FD3F40EF6582604
  %mul40.i.i582.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i580.i.i.i.i
  %add43.i.i583.i.i.i.i = fadd double %mul40.i.i582.i.i.i.i, 0x3FE03C236600AD0B
  %300 = fmul double %299, %add38.i.i581.i.i.i.i
  %add48.i.i585.i.i.i.i = fsub double %add43.i.i583.i.i.i.i, %300
  %mul1.i.i547.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EA0457562E8B20F
  %add.i.i548.i.i.i.i = fadd double %mul1.i.i547.i.i.i.i, 0x3F16154BBE28AEB9
  %mul5.i.i549.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EE174949F46ED05
  %add7.i.i550.i.i.i.i = fadd double %mul5.i.i549.i.i.i.i, 0x3F43E3B25F7FFBED
  %mul10.i.i551.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i548.i.i.i.i
  %mul12.i.i552.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i550.i.i.i.i
  %add15.i.i553.i.i.i.i = fadd double %mul10.i.i551.i.i.i.i, 0x3F6B2284D418EE28
  %add18.i.i554.i.i.i.i = fadd double %mul12.i.i552.i.i.i.i, 0x3F8DC663E91E38DD
  %mul20.i.i555.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i553.i.i.i.i
  %mul22.i.i556.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i554.i.i.i.i
  %add25.i.i557.i.i.i.i = fadd double %mul20.i.i555.i.i.i.i, 0x3FA9F261B3019817
  %add28.i.i558.i.i.i.i = fadd double %mul22.i.i556.i.i.i.i, 0x3FC29CC24A62017B
  %mul30.i.i559.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i557.i.i.i.i
  %mul32.i.i560.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i558.i.i.i.i
  %add35.i.i561.i.i.i.i = fadd double %mul30.i.i559.i.i.i.i, 0x3FD660DD0F65AD11
  %add38.i.i562.i.i.i.i = fadd double %mul32.i.i560.i.i.i.i, 0x3FE0E738E979F959
  %mul40.i.i563.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i561.i.i.i.i
  %add43.i.i564.i.i.i.i = fadd double %mul40.i.i563.i.i.i.i, 1.000000e+00
  %301 = fmul double %299, %add38.i.i562.i.i.i.i
  %add48.i.i.i.i.i.i = fsub double %add43.i.i564.i.i.i.i, %301
  %mul31.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i469.i.i.i.i = fcmp ogt double %mul31.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i470.i.i.i.i = fcmp oeq double %mul31.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i471.i.i.i.i = or i1 %cmp.i.i.i.i469.i.i.i.i, %cmp.i.i.i470.i.i.i.i
  br i1 %or.cond.i.i.i471.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end.i.i.i473.i.i.i.i

if.end.i.i.i473.i.i.i.i:                          ; preds = %if.then24.i.i.i.i
  %cmp.i.i.i.i.i472.i.i.i.i = fcmp uno double %mul31.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i472.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end7.i.i.i499.i.i.i.i

if.end7.i.i.i499.i.i.i.i:                         ; preds = %if.end.i.i.i473.i.i.i.i
  %302 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul31.i.i.i.i) #3
  %303 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul31.i.i.i.i) #3
  %304 = tail call i1 @llvm.amdgcn.class.f64(double %mul31.i.i.i.i, i32 519) #3
  %305 = select i1 %304, i32 0, i32 %302
  %306 = select i1 %304, double %mul31.i.i.i.i, double %303
  %mul.i.i.i.i.i485.i.i.i.i = fmul double %306, %306
  %mul1.i.i.i.i.i486.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i487.i.i.i.i = fadd double %mul1.i.i.i.i.i486.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i488.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FE479D17050CA47
  %307 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i488.i.i.i.i
  %mul10.i.i.i.i.i490.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %add.i.i.i.i.i487.i.i.i.i
  %mul12.i.i.i.i.i491.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %307
  %add15.i.i.i.i.i492.i.i.i.i = fadd double %mul10.i.i.i.i.i490.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i493.i.i.i.i = fadd double %mul12.i.i.i.i.i491.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i494.i.i.i.i = fmul double %306, %add15.i.i.i.i.i492.i.i.i.i
  %add23.i.i.i.i.i495.i.i.i.i = fadd double %add18.i.i.i.i.i493.i.i.i.i, %mul20.i.i.i.i.i494.i.i.i.i
  %.frozen209 = freeze i32 %305
  %div.i.i.i496.i.i.i.i = sdiv i32 %.frozen209, 3
  %308 = call i32 @llvm.abs.i32(i32 %div.i.i.i496.i.i.i.i, i1 true)
  %cmp11.i.i.i498.i.i.i.i = icmp ugt i32 %308, 63
  %cmp13.i.i.i500.i.i.i.i = icmp sgt i32 %305, 2
  %decision.take1 = or i1 %cmp11.i.i.i498.i.i.i.i, %cmp13.i.i.i500.i.i.i.i
  br i1 %decision.take1, label %decision.dispatch6, label %if.else.i.i.i512.i.i.i.i, !decision.condition_prefix !6, !decision.merged_from !12, !decision.origin !13

decision.dispatch6:                               ; preds = %if.end7.i.i.i499.i.i.i.i
  %sh_prom.i.i.i502.i.i.i.i = zext i32 %div.i.i.i496.i.i.i.i to i64
  %shl.i.i.i503.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i502.i.i.i.i
  %conv.i.i.i504.i.i.i.i = uitofp i64 %shl.i.i.i503.i.i.i.i to double
  %mul.i.i.i505.i.i.i.i = fmul double %add23.i.i.i.i.i495.i.i.i.i, %conv.i.i.i504.i.i.i.i
  %309 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i495.i.i.i.i, i32 %div.i.i.i496.i.i.i.i) #3
  %guess.i.i.i468.i.i.i.i.0.ph = select i1 %cmp11.i.i.i498.i.i.i.i, double %309, double %mul.i.i.i505.i.i.i.i
  br label %if.end23.i.i.i519.i.i.i.i.pair.join

if.else.i.i.i512.i.i.i.i:                         ; preds = %if.end7.i.i.i499.i.i.i.i
  %310 = sub nsw i32 0, %div.i.i.i496.i.i.i.i
  %sh_prom16.i.i.i508.i.i.i.i = zext i32 %310 to i64
  %shl17.i.i.i509.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i508.i.i.i.i
  %conv18.i.i.i510.i.i.i.i = uitofp i64 %shl17.i.i.i509.i.i.i.i to double
  %div19.i.i.i511.i.i.i.i = fdiv double %add23.i.i.i.i.i495.i.i.i.i, %conv18.i.i.i510.i.i.i.i
  br label %if.end23.i.i.i519.i.i.i.i.pair.join

if.end23.i.i.i519.i.i.i.i.pair.join:              ; preds = %if.else.i.i.i512.i.i.i.i, %decision.dispatch6
  %guess.i.i.i468.i.i.i.i.0.ph1 = phi double [ %div19.i.i.i511.i.i.i.i, %if.else.i.i.i512.i.i.i.i ], [ %guess.i.i.i468.i.i.i.i.0.ph, %decision.dispatch6 ]
  br label %if.end23.i.i.i519.i.i.i.i

if.end23.i.i.i519.i.i.i.i:                        ; preds = %if.end23.i.i.i519.i.i.i.i.pair.join
  %.neg5 = mul nsw i32 %div.i.i.i496.i.i.i.i, -3
  %rem.i.i.i514.i.i.i.i.decomposed = add i32 %.frozen209, 2
  %add.i.i.i515.i.i.i.i = add i32 %rem.i.i.i514.i.i.i.i.decomposed, %.neg5
  %311 = zext i32 %add.i.i.i515.i.i.i.i to i64
  %arrayidx1.i.i.i516.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %311
  %312 = load double, double addrspace(4)* %arrayidx1.i.i.i516.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i517.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.0.ph1, %312
  %cmp26.i.i.i518.i.i.i.i = icmp slt i32 %305, 1021
  br i1 %cmp26.i.i.i518.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i

do.body.i.i.i530.i.i.i.i:                         ; preds = %do.body.i.i.i530.i.i.i.i, %if.end23.i.i.i519.i.i.i.i
  %guess.i.i.i468.i.i.i.i.1 = phi double [ %mul24.i.i.i517.i.i.i.i, %if.end23.i.i.i519.i.i.i.i ], [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ]
  %mul28.i.i.i520.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %guess.i.i.i468.i.i.i.i.1
  %mul29.i.i.i521.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %mul28.i.i.i520.i.i.i.i
  %add30.i.i.i522.i.i.i.i = fadd double %mul31.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add31.i.i.i523.i.i.i.i = fadd double %mul31.i.i.i.i, %add30.i.i.i522.i.i.i.i
  %add32.i.i.i524.i.i.i.i = fadd double %mul29.i.i.i521.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add33.i.i.i525.i.i.i.i = fadd double %mul31.i.i.i.i, %add32.i.i.i524.i.i.i.i
  %div34.i.i.i526.i.i.i.i = fdiv double %add31.i.i.i523.i.i.i.i, %add33.i.i.i525.i.i.i.i
  %mul35.i.i.i527.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %div34.i.i.i526.i.i.i.i
  %sub36.i.i.i528.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i526.i.i.i.i
  %313 = tail call double @llvm.fabs.f64(double %sub36.i.i.i528.i.i.i.i) #3
  %cmp38.i.i.i529.i.i.i.i = fcmp ogt double %313, 0x3EC0000000000000
  br i1 %cmp38.i.i.i529.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

do.body40.i.i.i541.i.i.i.i:                       ; preds = %do.body40.i.i.i541.i.i.i.i, %if.end23.i.i.i519.i.i.i.i
  %guess.i.i.i468.i.i.i.i.2 = phi double [ %mul24.i.i.i517.i.i.i.i, %if.end23.i.i.i519.i.i.i.i ], [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ]
  %mul41.i.i.i531.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, %guess.i.i.i468.i.i.i.i.2
  %div42.i.i.i532.i.i.i.i = fdiv double %mul31.i.i.i.i, %guess.i.i.i468.i.i.i.i.2
  %sub43.i.i.i533.i.i.i.i = fsub double %mul41.i.i.i531.i.i.i.i, %div42.i.i.i532.i.i.i.i
  %mul44.i.i.i534.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i535.i.i.i.i = fdiv double %mul31.i.i.i.i, %mul41.i.i.i531.i.i.i.i
  %add46.i.i.i536.i.i.i.i = fadd double %mul44.i.i.i534.i.i.i.i, %div45.i.i.i535.i.i.i.i
  %div47.i.i.i537.i.i.i.i = fdiv double %sub43.i.i.i533.i.i.i.i, %add46.i.i.i536.i.i.i.i
  %sub48.i.i.i538.i.i.i.i = fsub double %guess.i.i.i468.i.i.i.i.2, %div47.i.i.i537.i.i.i.i
  %mul50.i.i.i539.i.i.i.i = fmul double %sub48.i.i.i538.i.i.i.i, 0x3EC0000000000000
  %314 = tail call double @llvm.fabs.f64(double %div47.i.i.i537.i.i.i.i) #3
  %cmp52.i.i.i540.i.i.i.i = fcmp olt double %mul50.i.i.i539.i.i.i.i, %314
  br i1 %cmp52.i.i.i540.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i: ; preds = %do.body40.i.i.i541.i.i.i.i, %do.body.i.i.i530.i.i.i.i, %if.end.i.i.i473.i.i.i.i, %if.then24.i.i.i.i
  %retval.0.i.i.i544.i.i.i.i = phi double [ %mul31.i.i.i.i, %if.then24.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i473.i.i.i.i ], [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ], [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ]
  %mul33.i.i.i.i = fmul double %add48.i.i.i.i.i.i, %retval.0.i.i.i544.i.i.i.i
  %div34.i.i.i.i = fdiv double %add48.i.i585.i.i.i.i, %mul33.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else35.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %cmp37.i.i.i.i = icmp sgt i32 %39, -17
  br i1 %cmp37.i.i.i.i, label %if.then38.i.i.i.i, label %if.else49.i.i.i.i

if.then38.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %315 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 8) #3
  %316 = tail call double @llvm.amdgcn.frexp.mant.f64(double %315) #3
  %317 = fcmp olt double %316, 0x3FE5555555555555
  %318 = zext i1 %317 to i32
  %319 = tail call double @llvm.amdgcn.ldexp.f64(double %316, i32 %318) #3
  %320 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %315) #3
  %321 = sub nsw i32 %320, %318
  %322 = fadd double %319, -1.000000e+00
  %323 = fadd double %319, 1.000000e+00
  %324 = fsub double %323, %319
  %325 = fsub double %323, %324
  %326 = fsub double %319, %325
  %327 = fsub double 1.000000e+00, %324
  %328 = fadd double %327, %326
  %329 = tail call double @llvm.amdgcn.rcp.f64(double %323) #3
  %330 = fneg double %323
  %331 = tail call double @llvm.fma.f64(double %330, double %329, double 1.000000e+00) #3
  %332 = tail call double @llvm.fma.f64(double %331, double %329, double %329) #3
  %333 = tail call double @llvm.fma.f64(double %330, double %332, double 1.000000e+00) #3
  %334 = tail call double @llvm.fma.f64(double %333, double %332, double %332) #3
  %335 = fmul double %322, %334
  %336 = fmul double %323, %335
  %337 = fneg double %336
  %338 = tail call double @llvm.fma.f64(double %335, double %323, double %337) #3
  %339 = tail call double @llvm.fma.f64(double %335, double %328, double %338) #3
  %340 = fadd double %336, %339
  %341 = fsub double %340, %336
  %342 = fsub double %339, %341
  %343 = fsub double %322, %340
  %344 = fsub double %322, %343
  %345 = fsub double %344, %340
  %346 = fsub double %345, %342
  %347 = fadd double %343, %346
  %348 = fmul double %334, %347
  %349 = fadd double %335, %348
  %350 = fsub double %349, %335
  %351 = fsub double %348, %350
  %352 = fmul double %349, %349
  %353 = fneg double %352
  %354 = tail call double @llvm.fma.f64(double %349, double %349, double %353) #3
  %355 = fmul double %351, 2.000000e+00
  %356 = tail call double @llvm.fma.f64(double %349, double %355, double %354) #3
  %357 = tail call double @llvm.fma.f64(double %351, double %351, double %356) #3
  %358 = fadd double %352, %357
  %359 = fsub double %358, %352
  %360 = fsub double %357, %359
  %361 = tail call double @llvm.fma.f64(double %358, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %362 = tail call double @llvm.fma.f64(double %358, double %361, double 0x3FC7474DD7F4DF2E) #3
  %363 = tail call double @llvm.fma.f64(double %358, double %362, double 0x3FCC71C016291751) #3
  %364 = tail call double @llvm.fma.f64(double %358, double %363, double 0x3FD249249B27ACF1) #3
  %365 = tail call double @llvm.fma.f64(double %358, double %364, double 0x3FD99999998EF7B6) #3
  %366 = tail call double @llvm.fma.f64(double %358, double %365, double 0x3FE5555555555780) #3
  %367 = tail call double @llvm.amdgcn.ldexp.f64(double %349, i32 1) #3
  %368 = tail call double @llvm.amdgcn.ldexp.f64(double %351, i32 1) #3
  %369 = fmul double %349, %358
  %370 = fneg double %369
  %371 = tail call double @llvm.fma.f64(double %349, double %358, double %370) #3
  %372 = fmul double %351, %358
  %373 = tail call double @llvm.fma.f64(double %349, double %360, double %372) #3
  %374 = fadd double %371, %373
  %375 = fadd double %369, %374
  %376 = fsub double %375, %369
  %377 = fsub double %374, %376
  %378 = fmul double %375, %366
  %379 = fneg double %378
  %380 = tail call double @llvm.fma.f64(double %375, double %366, double %379) #3
  %381 = tail call double @llvm.fma.f64(double %377, double %366, double %380) #3
  %382 = fadd double %378, %381
  %383 = fsub double %382, %378
  %384 = fsub double %381, %383
  %385 = fadd double %367, %382
  %386 = fsub double %385, %367
  %387 = fsub double %385, %386
  %388 = fsub double %367, %387
  %389 = fsub double %382, %386
  %390 = fadd double %389, %388
  %391 = fadd double %368, %384
  %392 = fsub double %391, %368
  %393 = fsub double %391, %392
  %394 = fsub double %368, %393
  %395 = fsub double %384, %392
  %396 = fadd double %395, %394
  %397 = fadd double %391, %390
  %398 = fadd double %385, %397
  %399 = fsub double %398, %385
  %400 = fsub double %397, %399
  %401 = fadd double %396, %400
  %402 = fadd double %398, %401
  %403 = fsub double %402, %398
  %404 = fsub double %401, %403
  %405 = sitofp i32 %321 to double
  %406 = fmul double %402, 0x3FF71547652B82FE
  %407 = fneg double %406
  %408 = fmul double %402, 0x3C7777D0FFDA0D24
  %409 = insertelement <2 x double> undef, double %402, i32 0
  %410 = insertelement <2 x double> %409, double %404, i32 1
  %411 = insertelement <2 x double> undef, double %407, i32 0
  %412 = insertelement <2 x double> %411, double %408, i32 1
  %413 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %410, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %412) #3
  %414 = extractelement <2 x double> %413, i32 0
  %415 = extractelement <2 x double> %413, i32 1
  %416 = fadd double %414, %415
  %417 = fadd double %406, %416
  %418 = fsub double %417, %406
  %419 = fsub double %416, %418
  %420 = fadd double %417, %405
  %421 = fsub double %420, %405
  %422 = fsub double %421, %420
  %423 = fadd double %422, %405
  %424 = fsub double %417, %421
  %425 = fadd double %424, %423
  %426 = fadd double %419, %425
  %427 = fadd double %420, %426
  %428 = tail call double @llvm.fabs.f64(double %315) #4
  %429 = fcmp oeq double %428, 0x7FF0000000000000
  %430 = select i1 %429, double %315, double %427
  %431 = fcmp olt double %315, 0.000000e+00
  %432 = select i1 %431, double 0x7FF8000000000000, double %430
  %433 = fcmp oeq double %315, 0.000000e+00
  %434 = select i1 %433, double 0xFFF0000000000000, double %432
  %mul.i.i450.i.i.i.i = fmul double %434, %434
  %mul1.i.i451.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3D1C49F35743D651
  %add.i.i452.i.i.i.i = fadd double %mul1.i.i451.i.i.i.i, 0x3EC5BDF8ABE0C4D2
  %mul5.i.i453.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E74DE722017F09B
  %add7.i.i454.i.i.i.i = fadd double %mul5.i.i453.i.i.i.i, 0x3F08B20867234AE0
  %mul10.i.i455.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i452.i.i.i.i
  %mul12.i.i456.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i454.i.i.i.i
  %add15.i.i457.i.i.i.i = fadd double %mul10.i.i455.i.i.i.i, 0x3F43291C59111954
  %add18.i.i458.i.i.i.i = fadd double %mul12.i.i456.i.i.i.i, 0x3F7555F81DC90AE6
  %mul20.i.i459.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i457.i.i.i.i
  %mul22.i.i460.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i458.i.i.i.i
  %add25.i.i461.i.i.i.i = fadd double %mul20.i.i459.i.i.i.i, 0x3FA118409603E368
  %add28.i.i462.i.i.i.i = fadd double %mul22.i.i460.i.i.i.i, 0x3FC2F812CF93403D
  %mul30.i.i463.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i461.i.i.i.i
  %mul32.i.i.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add28.i.i462.i.i.i.i
  %add35.i.i.i.i.i.i = fadd double %mul30.i.i463.i.i.i.i, 0x3FDA4ECF31EE23E1
  %add38.i.i464.i.i.i.i = fadd double %mul32.i.i.i.i.i.i, 0x3FE15637BD9C1C6C
  %435 = fmul double %434, %add35.i.i.i.i.i.i
  %add43.i.i.i.i.i.i = fsub double %add38.i.i464.i.i.i.i, %435
  %mul1.i.i434.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E834146FFF39045
  %add.i.i435.i.i.i.i = fadd double %mul1.i.i434.i.i.i.i, 0x3F16C942D4A0C545
  %mul5.i.i436.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3ED40F287F6755C5
  %add7.i.i437.i.i.i.i = fadd double %mul5.i.i436.i.i.i.i, 0x3F51AD434F5D94BA
  %mul10.i.i438.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i435.i.i.i.i
  %mul12.i.i439.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i437.i.i.i.i
  %add15.i.i440.i.i.i.i = fadd double %mul10.i.i438.i.i.i.i, 0x3F83AFF5A756295F
  %add18.i.i441.i.i.i.i = fadd double %mul12.i.i439.i.i.i.i, 0x3FAF8A313C5B71D0
  %mul20.i.i442.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i440.i.i.i.i
  %mul22.i.i443.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i441.i.i.i.i
  %add25.i.i444.i.i.i.i = fadd double %mul20.i.i442.i.i.i.i, 0x3FD1813788B6276A
  %add28.i.i445.i.i.i.i = fadd double %mul22.i.i443.i.i.i.i, 0x3FE84455F48DB67F
  %mul30.i.i446.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i444.i.i.i.i
  %add33.i.i447.i.i.i.i = fadd double %mul30.i.i446.i.i.i.i, 1.000000e+00
  %436 = fmul double %434, %add28.i.i445.i.i.i.i
  %add38.i.i449.i.i.i.i = fsub double %add33.i.i447.i.i.i.i, %436
  %mul45.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i356.i.i.i.i = fcmp ogt double %mul45.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i357.i.i.i.i = fcmp oeq double %mul45.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i358.i.i.i.i = or i1 %cmp.i.i.i.i356.i.i.i.i, %cmp.i.i.i357.i.i.i.i
  br i1 %or.cond.i.i.i358.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end.i.i.i360.i.i.i.i

if.end.i.i.i360.i.i.i.i:                          ; preds = %if.then38.i.i.i.i
  %cmp.i.i.i.i.i359.i.i.i.i = fcmp uno double %mul45.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i359.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end7.i.i.i386.i.i.i.i

if.end7.i.i.i386.i.i.i.i:                         ; preds = %if.end.i.i.i360.i.i.i.i
  %437 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul45.i.i.i.i) #3
  %438 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul45.i.i.i.i) #3
  %439 = tail call i1 @llvm.amdgcn.class.f64(double %mul45.i.i.i.i, i32 519) #3
  %440 = select i1 %439, i32 0, i32 %437
  %441 = select i1 %439, double %mul45.i.i.i.i, double %438
  %mul.i.i.i.i.i372.i.i.i.i = fmul double %441, %441
  %mul1.i.i.i.i.i373.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i374.i.i.i.i = fadd double %mul1.i.i.i.i.i373.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i375.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FE479D17050CA47
  %442 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i375.i.i.i.i
  %mul10.i.i.i.i.i377.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %add.i.i.i.i.i374.i.i.i.i
  %mul12.i.i.i.i.i378.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %442
  %add15.i.i.i.i.i379.i.i.i.i = fadd double %mul10.i.i.i.i.i377.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i380.i.i.i.i = fadd double %mul12.i.i.i.i.i378.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i381.i.i.i.i = fmul double %441, %add15.i.i.i.i.i379.i.i.i.i
  %add23.i.i.i.i.i382.i.i.i.i = fadd double %add18.i.i.i.i.i380.i.i.i.i, %mul20.i.i.i.i.i381.i.i.i.i
  %.frozen210 = freeze i32 %440
  %div.i.i.i383.i.i.i.i = sdiv i32 %.frozen210, 3
  %443 = sub nsw i32 0, %div.i.i.i383.i.i.i.i
  %444 = call i32 @llvm.abs.i32(i32 %div.i.i.i383.i.i.i.i, i1 true)
  %cmp11.i.i.i385.i.i.i.i = icmp ult i32 %444, 64
  br i1 %cmp11.i.i.i385.i.i.i.i, label %if.then12.i.i.i388.i.i.i.i, label %if.else21.i.i.i400.i.i.i.i

if.then12.i.i.i388.i.i.i.i:                       ; preds = %if.end7.i.i.i386.i.i.i.i
  %cmp13.i.i.i387.i.i.i.i = icmp sgt i32 %440, 2
  br i1 %cmp13.i.i.i387.i.i.i.i, label %if.then14.i.i.i393.i.i.i.i, label %if.else.i.i.i399.i.i.i.i

if.then14.i.i.i393.i.i.i.i:                       ; preds = %if.then12.i.i.i388.i.i.i.i
  %sh_prom.i.i.i389.i.i.i.i = zext i32 %div.i.i.i383.i.i.i.i to i64
  %shl.i.i.i390.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i389.i.i.i.i
  %conv.i.i.i391.i.i.i.i = uitofp i64 %shl.i.i.i390.i.i.i.i to double
  %mul.i.i.i392.i.i.i.i = fmul double %add23.i.i.i.i.i382.i.i.i.i, %conv.i.i.i391.i.i.i.i
  br label %if.end23.i.i.i406.i.i.i.i

if.else.i.i.i399.i.i.i.i:                         ; preds = %if.then12.i.i.i388.i.i.i.i
  %sh_prom16.i.i.i395.i.i.i.i = zext i32 %443 to i64
  %shl17.i.i.i396.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i395.i.i.i.i
  %conv18.i.i.i397.i.i.i.i = uitofp i64 %shl17.i.i.i396.i.i.i.i to double
  %div19.i.i.i398.i.i.i.i = fdiv double %add23.i.i.i.i.i382.i.i.i.i, %conv18.i.i.i397.i.i.i.i
  br label %if.end23.i.i.i406.i.i.i.i

if.else21.i.i.i400.i.i.i.i:                       ; preds = %if.end7.i.i.i386.i.i.i.i
  %445 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i382.i.i.i.i, i32 %div.i.i.i383.i.i.i.i) #3
  br label %if.end23.i.i.i406.i.i.i.i

if.end23.i.i.i406.i.i.i.i:                        ; preds = %if.else21.i.i.i400.i.i.i.i, %if.else.i.i.i399.i.i.i.i, %if.then14.i.i.i393.i.i.i.i
  %guess.i.i.i355.i.i.i.i.0 = phi double [ %mul.i.i.i392.i.i.i.i, %if.then14.i.i.i393.i.i.i.i ], [ %div19.i.i.i398.i.i.i.i, %if.else.i.i.i399.i.i.i.i ], [ %445, %if.else21.i.i.i400.i.i.i.i ]
  %.neg4 = mul nsw i32 %div.i.i.i383.i.i.i.i, -3
  %rem.i.i.i401.i.i.i.i.decomposed = add i32 %.frozen210, 2
  %add.i.i.i402.i.i.i.i = add i32 %rem.i.i.i401.i.i.i.i.decomposed, %.neg4
  %446 = zext i32 %add.i.i.i402.i.i.i.i to i64
  %arrayidx1.i.i.i403.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %446
  %447 = load double, double addrspace(4)* %arrayidx1.i.i.i403.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i404.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.0, %447
  %cmp26.i.i.i405.i.i.i.i = icmp slt i32 %440, 1021
  br i1 %cmp26.i.i.i405.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i

do.body.i.i.i417.i.i.i.i:                         ; preds = %do.body.i.i.i417.i.i.i.i, %if.end23.i.i.i406.i.i.i.i
  %guess.i.i.i355.i.i.i.i.1 = phi double [ %mul24.i.i.i404.i.i.i.i, %if.end23.i.i.i406.i.i.i.i ], [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ]
  %mul28.i.i.i407.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %guess.i.i.i355.i.i.i.i.1
  %mul29.i.i.i408.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %mul28.i.i.i407.i.i.i.i
  %add30.i.i.i409.i.i.i.i = fadd double %mul45.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add31.i.i.i410.i.i.i.i = fadd double %mul45.i.i.i.i, %add30.i.i.i409.i.i.i.i
  %add32.i.i.i411.i.i.i.i = fadd double %mul29.i.i.i408.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add33.i.i.i412.i.i.i.i = fadd double %mul45.i.i.i.i, %add32.i.i.i411.i.i.i.i
  %div34.i.i.i413.i.i.i.i = fdiv double %add31.i.i.i410.i.i.i.i, %add33.i.i.i412.i.i.i.i
  %mul35.i.i.i414.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %div34.i.i.i413.i.i.i.i
  %sub36.i.i.i415.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i413.i.i.i.i
  %448 = tail call double @llvm.fabs.f64(double %sub36.i.i.i415.i.i.i.i) #3
  %cmp38.i.i.i416.i.i.i.i = fcmp ogt double %448, 0x3EC0000000000000
  br i1 %cmp38.i.i.i416.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

do.body40.i.i.i428.i.i.i.i:                       ; preds = %do.body40.i.i.i428.i.i.i.i, %if.end23.i.i.i406.i.i.i.i
  %guess.i.i.i355.i.i.i.i.2 = phi double [ %mul24.i.i.i404.i.i.i.i, %if.end23.i.i.i406.i.i.i.i ], [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ]
  %mul41.i.i.i418.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, %guess.i.i.i355.i.i.i.i.2
  %div42.i.i.i419.i.i.i.i = fdiv double %mul45.i.i.i.i, %guess.i.i.i355.i.i.i.i.2
  %sub43.i.i.i420.i.i.i.i = fsub double %mul41.i.i.i418.i.i.i.i, %div42.i.i.i419.i.i.i.i
  %mul44.i.i.i421.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i422.i.i.i.i = fdiv double %mul45.i.i.i.i, %mul41.i.i.i418.i.i.i.i
  %add46.i.i.i423.i.i.i.i = fadd double %mul44.i.i.i421.i.i.i.i, %div45.i.i.i422.i.i.i.i
  %div47.i.i.i424.i.i.i.i = fdiv double %sub43.i.i.i420.i.i.i.i, %add46.i.i.i423.i.i.i.i
  %sub48.i.i.i425.i.i.i.i = fsub double %guess.i.i.i355.i.i.i.i.2, %div47.i.i.i424.i.i.i.i
  %mul50.i.i.i426.i.i.i.i = fmul double %sub48.i.i.i425.i.i.i.i, 0x3EC0000000000000
  %449 = tail call double @llvm.fabs.f64(double %div47.i.i.i424.i.i.i.i) #3
  %cmp52.i.i.i427.i.i.i.i = fcmp olt double %mul50.i.i.i426.i.i.i.i, %449
  br i1 %cmp52.i.i.i427.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i: ; preds = %do.body40.i.i.i428.i.i.i.i, %do.body.i.i.i417.i.i.i.i, %if.end.i.i.i360.i.i.i.i, %if.then38.i.i.i.i
  %retval.0.i.i.i431.i.i.i.i = phi double [ %mul45.i.i.i.i, %if.then38.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i360.i.i.i.i ], [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ], [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ]
  %mul47.i.i.i.i = fmul double %add38.i.i449.i.i.i.i, %retval.0.i.i.i431.i.i.i.i
  %div48.i.i.i.i = fdiv double %add43.i.i.i.i.i.i, %mul47.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else49.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %cmp51.i.i.i.i = icmp sgt i32 %39, -33
  br i1 %cmp51.i.i.i.i, label %if.then52.i.i.i.i, label %if.else63.i.i.i.i

if.then52.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %450 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 16) #3
  %451 = tail call double @llvm.amdgcn.frexp.mant.f64(double %450) #3
  %452 = fcmp olt double %451, 0x3FE5555555555555
  %453 = zext i1 %452 to i32
  %454 = tail call double @llvm.amdgcn.ldexp.f64(double %451, i32 %453) #3
  %455 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %450) #3
  %456 = sub nsw i32 %455, %453
  %457 = fadd double %454, -1.000000e+00
  %458 = fadd double %454, 1.000000e+00
  %459 = fsub double %458, %454
  %460 = fsub double %458, %459
  %461 = fsub double %454, %460
  %462 = fsub double 1.000000e+00, %459
  %463 = fadd double %462, %461
  %464 = tail call double @llvm.amdgcn.rcp.f64(double %458) #3
  %465 = fneg double %458
  %466 = tail call double @llvm.fma.f64(double %465, double %464, double 1.000000e+00) #3
  %467 = tail call double @llvm.fma.f64(double %466, double %464, double %464) #3
  %468 = tail call double @llvm.fma.f64(double %465, double %467, double 1.000000e+00) #3
  %469 = tail call double @llvm.fma.f64(double %468, double %467, double %467) #3
  %470 = fmul double %457, %469
  %471 = fmul double %458, %470
  %472 = fneg double %471
  %473 = tail call double @llvm.fma.f64(double %470, double %458, double %472) #3
  %474 = tail call double @llvm.fma.f64(double %470, double %463, double %473) #3
  %475 = fadd double %471, %474
  %476 = fsub double %475, %471
  %477 = fsub double %474, %476
  %478 = fsub double %457, %475
  %479 = fsub double %457, %478
  %480 = fsub double %479, %475
  %481 = fsub double %480, %477
  %482 = fadd double %478, %481
  %483 = fmul double %469, %482
  %484 = fadd double %470, %483
  %485 = fsub double %484, %470
  %486 = fsub double %483, %485
  %487 = fmul double %484, %484
  %488 = fneg double %487
  %489 = tail call double @llvm.fma.f64(double %484, double %484, double %488) #3
  %490 = fmul double %486, 2.000000e+00
  %491 = tail call double @llvm.fma.f64(double %484, double %490, double %489) #3
  %492 = tail call double @llvm.fma.f64(double %486, double %486, double %491) #3
  %493 = fadd double %487, %492
  %494 = fsub double %493, %487
  %495 = fsub double %492, %494
  %496 = tail call double @llvm.fma.f64(double %493, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %497 = tail call double @llvm.fma.f64(double %493, double %496, double 0x3FC7474DD7F4DF2E) #3
  %498 = tail call double @llvm.fma.f64(double %493, double %497, double 0x3FCC71C016291751) #3
  %499 = tail call double @llvm.fma.f64(double %493, double %498, double 0x3FD249249B27ACF1) #3
  %500 = tail call double @llvm.fma.f64(double %493, double %499, double 0x3FD99999998EF7B6) #3
  %501 = tail call double @llvm.fma.f64(double %493, double %500, double 0x3FE5555555555780) #3
  %502 = tail call double @llvm.amdgcn.ldexp.f64(double %484, i32 1) #3
  %503 = tail call double @llvm.amdgcn.ldexp.f64(double %486, i32 1) #3
  %504 = fmul double %484, %493
  %505 = fneg double %504
  %506 = tail call double @llvm.fma.f64(double %484, double %493, double %505) #3
  %507 = fmul double %486, %493
  %508 = tail call double @llvm.fma.f64(double %484, double %495, double %507) #3
  %509 = fadd double %506, %508
  %510 = fadd double %504, %509
  %511 = fsub double %510, %504
  %512 = fsub double %509, %511
  %513 = fmul double %510, %501
  %514 = fneg double %513
  %515 = tail call double @llvm.fma.f64(double %510, double %501, double %514) #3
  %516 = tail call double @llvm.fma.f64(double %512, double %501, double %515) #3
  %517 = fadd double %513, %516
  %518 = fsub double %517, %513
  %519 = fsub double %516, %518
  %520 = fadd double %502, %517
  %521 = fsub double %520, %502
  %522 = fsub double %520, %521
  %523 = fsub double %502, %522
  %524 = fsub double %517, %521
  %525 = fadd double %524, %523
  %526 = fadd double %503, %519
  %527 = fsub double %526, %503
  %528 = fsub double %526, %527
  %529 = fsub double %503, %528
  %530 = fsub double %519, %527
  %531 = fadd double %530, %529
  %532 = fadd double %526, %525
  %533 = fadd double %520, %532
  %534 = fsub double %533, %520
  %535 = fsub double %532, %534
  %536 = fadd double %531, %535
  %537 = fadd double %533, %536
  %538 = fsub double %537, %533
  %539 = fsub double %536, %538
  %540 = sitofp i32 %456 to double
  %541 = fmul double %537, 0x3FF71547652B82FE
  %542 = fneg double %541
  %543 = fmul double %537, 0x3C7777D0FFDA0D24
  %544 = insertelement <2 x double> undef, double %537, i32 0
  %545 = insertelement <2 x double> %544, double %539, i32 1
  %546 = insertelement <2 x double> undef, double %542, i32 0
  %547 = insertelement <2 x double> %546, double %543, i32 1
  %548 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %545, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %547) #3
  %549 = extractelement <2 x double> %548, i32 0
  %550 = extractelement <2 x double> %548, i32 1
  %551 = fadd double %549, %550
  %552 = fadd double %541, %551
  %553 = fsub double %552, %541
  %554 = fsub double %551, %553
  %555 = fadd double %552, %540
  %556 = fsub double %555, %540
  %557 = fsub double %556, %555
  %558 = fadd double %557, %540
  %559 = fsub double %552, %556
  %560 = fadd double %559, %558
  %561 = fadd double %554, %560
  %562 = fadd double %555, %561
  %563 = tail call double @llvm.fabs.f64(double %450) #4
  %564 = fcmp oeq double %563, 0x7FF0000000000000
  %565 = select i1 %564, double %450, double %562
  %566 = fcmp olt double %450, 0.000000e+00
  %567 = select i1 %566, double 0x7FF8000000000000, double %565
  %568 = fcmp oeq double %450, 0.000000e+00
  %569 = select i1 %568, double 0xFFF0000000000000, double %567
  %mul.i.i335.i.i.i.i = fmul double %569, %569
  %mul1.i.i336.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EBF7344DBF5E403
  %add.i.i337.i.i.i.i = fadd double %mul1.i.i336.i.i.i.i, 0x3F2CFF1E2D54E4E7
  %mul5.i.i338.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EEF8CF23CAED047
  %add7.i.i339.i.i.i.i = fadd double %mul5.i.i338.i.i.i.i, 0x3F5CF8F0FF9B6F59
  %mul10.i.i340.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i337.i.i.i.i
  %mul12.i.i341.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i339.i.i.i.i
  %add15.i.i342.i.i.i.i = fadd double %mul10.i.i340.i.i.i.i, 0x3F8857AD74D33625
  %add18.i.i343.i.i.i.i = fadd double %mul12.i.i341.i.i.i.i, 0x3FAE52179C3AEDE6
  %mul20.i.i344.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i342.i.i.i.i
  %mul22.i.i345.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i343.i.i.i.i
  %add25.i.i346.i.i.i.i = fadd double %mul20.i.i344.i.i.i.i, 0x3FCB21A22303D8FC
  %add28.i.i347.i.i.i.i = fadd double %mul22.i.i345.i.i.i.i, 0x3FDF29CE00A8804B
  %mul30.i.i348.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i346.i.i.i.i
  %add33.i.i349.i.i.i.i = fadd double %mul30.i.i348.i.i.i.i, 0x3FE15775564555E5
  %570 = fmul double %569, %add28.i.i347.i.i.i.i
  %add38.i.i351.i.i.i.i = fsub double %add33.i.i349.i.i.i.i, %570
  %mul1.i.i321.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3ECD04621671DBCE
  %add.i.i322.i.i.i.i = fadd double %mul1.i.i321.i.i.i.i, 0x3F3AC0D433DC2A4E
  %mul5.i.i323.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EFD1C12EAA62BE9
  %add7.i.i324.i.i.i.i = fadd double %mul5.i.i323.i.i.i.i, 0x3F6ABB215A001E96
  %mul10.i.i325.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i322.i.i.i.i
  %mul12.i.i326.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i324.i.i.i.i
  %add15.i.i327.i.i.i.i = fadd double %mul10.i.i325.i.i.i.i, 0x3F967590758A1B1A
  %add18.i.i328.i.i.i.i = fadd double %mul12.i.i326.i.i.i.i, 0x3FBBF9941AE7DFDE
  %mul20.i.i329.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i327.i.i.i.i
  %mul22.i.i330.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i328.i.i.i.i
  %add25.i.i331.i.i.i.i = fadd double %mul20.i.i329.i.i.i.i, 0x3FD90848F242167F
  %add28.i.i332.i.i.i.i = fadd double %mul22.i.i330.i.i.i.i, 0x3FECC09A37BCEE76
  %mul30.i.i333.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i331.i.i.i.i
  %add33.i.i334.i.i.i.i = fadd double %mul30.i.i333.i.i.i.i, 1.000000e+00
  %571 = fmul double %569, %add28.i.i332.i.i.i.i
  %add38.i.i.i.i.i.i = fsub double %add33.i.i334.i.i.i.i, %571
  %mul59.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i243.i.i.i.i = fcmp ogt double %mul59.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i244.i.i.i.i = fcmp oeq double %mul59.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i245.i.i.i.i = or i1 %cmp.i.i.i.i243.i.i.i.i, %cmp.i.i.i244.i.i.i.i
  br i1 %or.cond.i.i.i245.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end.i.i.i247.i.i.i.i

if.end.i.i.i247.i.i.i.i:                          ; preds = %if.then52.i.i.i.i
  %cmp.i.i.i.i.i246.i.i.i.i = fcmp uno double %mul59.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i246.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end7.i.i.i273.i.i.i.i

if.end7.i.i.i273.i.i.i.i:                         ; preds = %if.end.i.i.i247.i.i.i.i
  %572 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul59.i.i.i.i) #3
  %573 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul59.i.i.i.i) #3
  %574 = tail call i1 @llvm.amdgcn.class.f64(double %mul59.i.i.i.i, i32 519) #3
  %575 = select i1 %574, i32 0, i32 %572
  %576 = select i1 %574, double %mul59.i.i.i.i, double %573
  %mul.i.i.i.i.i259.i.i.i.i = fmul double %576, %576
  %mul1.i.i.i.i.i260.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i261.i.i.i.i = fadd double %mul1.i.i.i.i.i260.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i262.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FE479D17050CA47
  %577 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i262.i.i.i.i
  %mul10.i.i.i.i.i264.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %add.i.i.i.i.i261.i.i.i.i
  %mul12.i.i.i.i.i265.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %577
  %add15.i.i.i.i.i266.i.i.i.i = fadd double %mul10.i.i.i.i.i264.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i267.i.i.i.i = fadd double %mul12.i.i.i.i.i265.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i268.i.i.i.i = fmul double %576, %add15.i.i.i.i.i266.i.i.i.i
  %add23.i.i.i.i.i269.i.i.i.i = fadd double %add18.i.i.i.i.i267.i.i.i.i, %mul20.i.i.i.i.i268.i.i.i.i
  %.frozen211 = freeze i32 %575
  %div.i.i.i270.i.i.i.i = sdiv i32 %.frozen211, 3
  %578 = sub nsw i32 0, %div.i.i.i270.i.i.i.i
  %579 = call i32 @llvm.abs.i32(i32 %div.i.i.i270.i.i.i.i, i1 true)
  %cmp11.i.i.i272.i.i.i.i = icmp ult i32 %579, 64
  br i1 %cmp11.i.i.i272.i.i.i.i, label %if.then12.i.i.i275.i.i.i.i, label %if.else21.i.i.i287.i.i.i.i

if.then12.i.i.i275.i.i.i.i:                       ; preds = %if.end7.i.i.i273.i.i.i.i
  %cmp13.i.i.i274.i.i.i.i = icmp sgt i32 %575, 2
  br i1 %cmp13.i.i.i274.i.i.i.i, label %if.then14.i.i.i280.i.i.i.i, label %if.else.i.i.i286.i.i.i.i

if.then14.i.i.i280.i.i.i.i:                       ; preds = %if.then12.i.i.i275.i.i.i.i
  %sh_prom.i.i.i276.i.i.i.i = zext i32 %div.i.i.i270.i.i.i.i to i64
  %shl.i.i.i277.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i276.i.i.i.i
  %conv.i.i.i278.i.i.i.i = uitofp i64 %shl.i.i.i277.i.i.i.i to double
  %mul.i.i.i279.i.i.i.i = fmul double %add23.i.i.i.i.i269.i.i.i.i, %conv.i.i.i278.i.i.i.i
  br label %if.end23.i.i.i293.i.i.i.i

if.else.i.i.i286.i.i.i.i:                         ; preds = %if.then12.i.i.i275.i.i.i.i
  %sh_prom16.i.i.i282.i.i.i.i = zext i32 %578 to i64
  %shl17.i.i.i283.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i282.i.i.i.i
  %conv18.i.i.i284.i.i.i.i = uitofp i64 %shl17.i.i.i283.i.i.i.i to double
  %div19.i.i.i285.i.i.i.i = fdiv double %add23.i.i.i.i.i269.i.i.i.i, %conv18.i.i.i284.i.i.i.i
  br label %if.end23.i.i.i293.i.i.i.i

if.else21.i.i.i287.i.i.i.i:                       ; preds = %if.end7.i.i.i273.i.i.i.i
  %580 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i269.i.i.i.i, i32 %div.i.i.i270.i.i.i.i) #3
  br label %if.end23.i.i.i293.i.i.i.i

if.end23.i.i.i293.i.i.i.i:                        ; preds = %if.else21.i.i.i287.i.i.i.i, %if.else.i.i.i286.i.i.i.i, %if.then14.i.i.i280.i.i.i.i
  %guess.i.i.i242.i.i.i.i.0 = phi double [ %mul.i.i.i279.i.i.i.i, %if.then14.i.i.i280.i.i.i.i ], [ %div19.i.i.i285.i.i.i.i, %if.else.i.i.i286.i.i.i.i ], [ %580, %if.else21.i.i.i287.i.i.i.i ]
  %.neg3 = mul nsw i32 %div.i.i.i270.i.i.i.i, -3
  %rem.i.i.i288.i.i.i.i.decomposed = add i32 %.frozen211, 2
  %add.i.i.i289.i.i.i.i = add i32 %rem.i.i.i288.i.i.i.i.decomposed, %.neg3
  %581 = zext i32 %add.i.i.i289.i.i.i.i to i64
  %arrayidx1.i.i.i290.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %581
  %582 = load double, double addrspace(4)* %arrayidx1.i.i.i290.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i291.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.0, %582
  %cmp26.i.i.i292.i.i.i.i = icmp slt i32 %575, 1021
  br i1 %cmp26.i.i.i292.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i

do.body.i.i.i304.i.i.i.i:                         ; preds = %do.body.i.i.i304.i.i.i.i, %if.end23.i.i.i293.i.i.i.i
  %guess.i.i.i242.i.i.i.i.1 = phi double [ %mul24.i.i.i291.i.i.i.i, %if.end23.i.i.i293.i.i.i.i ], [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ]
  %mul28.i.i.i294.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %guess.i.i.i242.i.i.i.i.1
  %mul29.i.i.i295.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %mul28.i.i.i294.i.i.i.i
  %add30.i.i.i296.i.i.i.i = fadd double %mul59.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add31.i.i.i297.i.i.i.i = fadd double %mul59.i.i.i.i, %add30.i.i.i296.i.i.i.i
  %add32.i.i.i298.i.i.i.i = fadd double %mul29.i.i.i295.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add33.i.i.i299.i.i.i.i = fadd double %mul59.i.i.i.i, %add32.i.i.i298.i.i.i.i
  %div34.i.i.i300.i.i.i.i = fdiv double %add31.i.i.i297.i.i.i.i, %add33.i.i.i299.i.i.i.i
  %mul35.i.i.i301.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %div34.i.i.i300.i.i.i.i
  %sub36.i.i.i302.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i300.i.i.i.i
  %583 = tail call double @llvm.fabs.f64(double %sub36.i.i.i302.i.i.i.i) #3
  %cmp38.i.i.i303.i.i.i.i = fcmp ogt double %583, 0x3EC0000000000000
  br i1 %cmp38.i.i.i303.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

do.body40.i.i.i315.i.i.i.i:                       ; preds = %do.body40.i.i.i315.i.i.i.i, %if.end23.i.i.i293.i.i.i.i
  %guess.i.i.i242.i.i.i.i.2 = phi double [ %mul24.i.i.i291.i.i.i.i, %if.end23.i.i.i293.i.i.i.i ], [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ]
  %mul41.i.i.i305.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, %guess.i.i.i242.i.i.i.i.2
  %div42.i.i.i306.i.i.i.i = fdiv double %mul59.i.i.i.i, %guess.i.i.i242.i.i.i.i.2
  %sub43.i.i.i307.i.i.i.i = fsub double %mul41.i.i.i305.i.i.i.i, %div42.i.i.i306.i.i.i.i
  %mul44.i.i.i308.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i309.i.i.i.i = fdiv double %mul59.i.i.i.i, %mul41.i.i.i305.i.i.i.i
  %add46.i.i.i310.i.i.i.i = fadd double %mul44.i.i.i308.i.i.i.i, %div45.i.i.i309.i.i.i.i
  %div47.i.i.i311.i.i.i.i = fdiv double %sub43.i.i.i307.i.i.i.i, %add46.i.i.i310.i.i.i.i
  %sub48.i.i.i312.i.i.i.i = fsub double %guess.i.i.i242.i.i.i.i.2, %div47.i.i.i311.i.i.i.i
  %mul50.i.i.i313.i.i.i.i = fmul double %sub48.i.i.i312.i.i.i.i, 0x3EC0000000000000
  %584 = tail call double @llvm.fabs.f64(double %div47.i.i.i311.i.i.i.i) #3
  %cmp52.i.i.i314.i.i.i.i = fcmp olt double %mul50.i.i.i313.i.i.i.i, %584
  br i1 %cmp52.i.i.i314.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i: ; preds = %do.body40.i.i.i315.i.i.i.i, %do.body.i.i.i304.i.i.i.i, %if.end.i.i.i247.i.i.i.i, %if.then52.i.i.i.i
  %retval.0.i.i.i318.i.i.i.i = phi double [ %mul59.i.i.i.i, %if.then52.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i247.i.i.i.i ], [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ], [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ]
  %mul61.i.i.i.i = fmul double %add38.i.i.i.i.i.i, %retval.0.i.i.i318.i.i.i.i
  %div62.i.i.i.i = fdiv double %add38.i.i351.i.i.i.i, %mul61.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else63.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %mul64.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp1.i.i.i.i.i = fcmp oge double %mul64.i.i.i.i, 0x10000000000000
  %cmp2.i.i.i.i.i = fcmp ole double %mul64.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %585 = and i1 %cmp1.i.i.i.i.i, %cmp2.i.i.i.i.i
  br i1 %585, label %if.then66.i.i.i.i, label %if.else71.i.i.i.i

if.then66.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %mul68.i.i.i.i = fmul double %mul64.i.i.i.i, 0x401921FB54442D18
  %cmp.i.i.i.i162.i.i.i.i = fcmp ogt double %mul68.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i163.i.i.i.i = fcmp oeq double %mul68.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i164.i.i.i.i = or i1 %cmp.i.i.i.i162.i.i.i.i, %cmp.i.i.i163.i.i.i.i
  br i1 %or.cond.i.i.i164.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end.i.i.i166.i.i.i.i

if.end.i.i.i166.i.i.i.i:                          ; preds = %if.then66.i.i.i.i
  %cmp.i.i.i.i.i165.i.i.i.i = fcmp uno double %mul68.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i165.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end7.i.i.i192.i.i.i.i

if.end7.i.i.i192.i.i.i.i:                         ; preds = %if.end.i.i.i166.i.i.i.i
  %586 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul68.i.i.i.i) #3
  %587 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul68.i.i.i.i) #3
  %588 = tail call i1 @llvm.amdgcn.class.f64(double %mul68.i.i.i.i, i32 519) #3
  %589 = select i1 %588, i32 0, i32 %586
  %590 = select i1 %588, double %mul68.i.i.i.i, double %587
  %mul.i.i.i.i.i178.i.i.i.i = fmul double %590, %590
  %mul1.i.i.i.i.i179.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i180.i.i.i.i = fadd double %mul1.i.i.i.i.i179.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i181.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FE479D17050CA47
  %591 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i181.i.i.i.i
  %mul10.i.i.i.i.i183.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %add.i.i.i.i.i180.i.i.i.i
  %mul12.i.i.i.i.i184.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %591
  %add15.i.i.i.i.i185.i.i.i.i = fadd double %mul10.i.i.i.i.i183.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i186.i.i.i.i = fadd double %mul12.i.i.i.i.i184.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i187.i.i.i.i = fmul double %590, %add15.i.i.i.i.i185.i.i.i.i
  %add23.i.i.i.i.i188.i.i.i.i = fadd double %add18.i.i.i.i.i186.i.i.i.i, %mul20.i.i.i.i.i187.i.i.i.i
  %.frozen212 = freeze i32 %589
  %div.i.i.i189.i.i.i.i = sdiv i32 %.frozen212, 3
  %592 = sub nsw i32 0, %div.i.i.i189.i.i.i.i
  %593 = call i32 @llvm.abs.i32(i32 %div.i.i.i189.i.i.i.i, i1 true)
  %cmp11.i.i.i191.i.i.i.i = icmp ult i32 %593, 64
  br i1 %cmp11.i.i.i191.i.i.i.i, label %if.then12.i.i.i194.i.i.i.i, label %if.else21.i.i.i206.i.i.i.i

if.then12.i.i.i194.i.i.i.i:                       ; preds = %if.end7.i.i.i192.i.i.i.i
  %cmp13.i.i.i193.i.i.i.i = icmp sgt i32 %589, 2
  br i1 %cmp13.i.i.i193.i.i.i.i, label %if.then14.i.i.i199.i.i.i.i, label %if.else.i.i.i205.i.i.i.i

if.then14.i.i.i199.i.i.i.i:                       ; preds = %if.then12.i.i.i194.i.i.i.i
  %sh_prom.i.i.i195.i.i.i.i = zext i32 %div.i.i.i189.i.i.i.i to i64
  %shl.i.i.i196.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i195.i.i.i.i
  %conv.i.i.i197.i.i.i.i = uitofp i64 %shl.i.i.i196.i.i.i.i to double
  %mul.i.i.i198.i.i.i.i = fmul double %add23.i.i.i.i.i188.i.i.i.i, %conv.i.i.i197.i.i.i.i
  br label %if.end23.i.i.i212.i.i.i.i

if.else.i.i.i205.i.i.i.i:                         ; preds = %if.then12.i.i.i194.i.i.i.i
  %sh_prom16.i.i.i201.i.i.i.i = zext i32 %592 to i64
  %shl17.i.i.i202.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i201.i.i.i.i
  %conv18.i.i.i203.i.i.i.i = uitofp i64 %shl17.i.i.i202.i.i.i.i to double
  %div19.i.i.i204.i.i.i.i = fdiv double %add23.i.i.i.i.i188.i.i.i.i, %conv18.i.i.i203.i.i.i.i
  br label %if.end23.i.i.i212.i.i.i.i

if.else21.i.i.i206.i.i.i.i:                       ; preds = %if.end7.i.i.i192.i.i.i.i
  %594 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i188.i.i.i.i, i32 %div.i.i.i189.i.i.i.i) #3
  br label %if.end23.i.i.i212.i.i.i.i

if.end23.i.i.i212.i.i.i.i:                        ; preds = %if.else21.i.i.i206.i.i.i.i, %if.else.i.i.i205.i.i.i.i, %if.then14.i.i.i199.i.i.i.i
  %guess.i.i.i161.i.i.i.i.0 = phi double [ %mul.i.i.i198.i.i.i.i, %if.then14.i.i.i199.i.i.i.i ], [ %div19.i.i.i204.i.i.i.i, %if.else.i.i.i205.i.i.i.i ], [ %594, %if.else21.i.i.i206.i.i.i.i ]
  %.neg2 = mul nsw i32 %div.i.i.i189.i.i.i.i, -3
  %rem.i.i.i207.i.i.i.i.decomposed = add i32 %.frozen212, 2
  %add.i.i.i208.i.i.i.i = add i32 %rem.i.i.i207.i.i.i.i.decomposed, %.neg2
  %595 = zext i32 %add.i.i.i208.i.i.i.i to i64
  %arrayidx1.i.i.i209.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %595
  %596 = load double, double addrspace(4)* %arrayidx1.i.i.i209.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i210.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.0, %596
  %cmp26.i.i.i211.i.i.i.i = icmp slt i32 %589, 1021
  br i1 %cmp26.i.i.i211.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i

do.body.i.i.i223.i.i.i.i:                         ; preds = %do.body.i.i.i223.i.i.i.i, %if.end23.i.i.i212.i.i.i.i
  %guess.i.i.i161.i.i.i.i.1 = phi double [ %mul24.i.i.i210.i.i.i.i, %if.end23.i.i.i212.i.i.i.i ], [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ]
  %mul28.i.i.i213.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %guess.i.i.i161.i.i.i.i.1
  %mul29.i.i.i214.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %mul28.i.i.i213.i.i.i.i
  %add30.i.i.i215.i.i.i.i = fadd double %mul68.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add31.i.i.i216.i.i.i.i = fadd double %mul68.i.i.i.i, %add30.i.i.i215.i.i.i.i
  %add32.i.i.i217.i.i.i.i = fadd double %mul29.i.i.i214.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add33.i.i.i218.i.i.i.i = fadd double %mul68.i.i.i.i, %add32.i.i.i217.i.i.i.i
  %div34.i.i.i219.i.i.i.i = fdiv double %add31.i.i.i216.i.i.i.i, %add33.i.i.i218.i.i.i.i
  %mul35.i.i.i220.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %div34.i.i.i219.i.i.i.i
  %sub36.i.i.i221.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i219.i.i.i.i
  %597 = tail call double @llvm.fabs.f64(double %sub36.i.i.i221.i.i.i.i) #3
  %cmp38.i.i.i222.i.i.i.i = fcmp ogt double %597, 0x3EC0000000000000
  br i1 %cmp38.i.i.i222.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

do.body40.i.i.i234.i.i.i.i:                       ; preds = %do.body40.i.i.i234.i.i.i.i, %if.end23.i.i.i212.i.i.i.i
  %guess.i.i.i161.i.i.i.i.2 = phi double [ %mul24.i.i.i210.i.i.i.i, %if.end23.i.i.i212.i.i.i.i ], [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ]
  %mul41.i.i.i224.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, %guess.i.i.i161.i.i.i.i.2
  %div42.i.i.i225.i.i.i.i = fdiv double %mul68.i.i.i.i, %guess.i.i.i161.i.i.i.i.2
  %sub43.i.i.i226.i.i.i.i = fsub double %mul41.i.i.i224.i.i.i.i, %div42.i.i.i225.i.i.i.i
  %mul44.i.i.i227.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i228.i.i.i.i = fdiv double %mul68.i.i.i.i, %mul41.i.i.i224.i.i.i.i
  %add46.i.i.i229.i.i.i.i = fadd double %mul44.i.i.i227.i.i.i.i, %div45.i.i.i228.i.i.i.i
  %div47.i.i.i230.i.i.i.i = fdiv double %sub43.i.i.i226.i.i.i.i, %add46.i.i.i229.i.i.i.i
  %sub48.i.i.i231.i.i.i.i = fsub double %guess.i.i.i161.i.i.i.i.2, %div47.i.i.i230.i.i.i.i
  %mul50.i.i.i232.i.i.i.i = fmul double %sub48.i.i.i231.i.i.i.i, 0x3EC0000000000000
  %598 = tail call double @llvm.fabs.f64(double %div47.i.i.i230.i.i.i.i) #3
  %cmp52.i.i.i233.i.i.i.i = fcmp olt double %mul50.i.i.i232.i.i.i.i, %598
  br i1 %cmp52.i.i.i233.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i: ; preds = %do.body40.i.i.i234.i.i.i.i, %do.body.i.i.i223.i.i.i.i, %if.end.i.i.i166.i.i.i.i, %if.then66.i.i.i.i
  %retval.0.i.i.i237.i.i.i.i = phi double [ %mul68.i.i.i.i, %if.then66.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i166.i.i.i.i ], [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ], [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ]
  %div70.i.i.i.i = fdiv double 1.000000e+00, %retval.0.i.i.i237.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else71.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %cmp72.i.i.i.i = fcmp ogt double %sub.i.i.i, 0.000000e+00
  br i1 %cmp72.i.i.i.i, label %if.then73.i.i.i.i, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.then73.i.i.i.i:                                ; preds = %if.else71.i.i.i.i
  %cmp.i.i.i.i79.i.i.i.i = fcmp ogt double %sub.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i.i80.i.i.i.i = fcmp olt double %sub.i.i.i, 0xFFEFFFFFFFFFFFFF
  %599 = or i1 %cmp.i.i.i.i79.i.i.i.i, %cmp1.i.i.i.i80.i.i.i.i
  %or.cond.i.i.i82.i.i.i.i = or i1 %38, %599
  %brmerge170 = or i1 %33, %or.cond.i.i.i82.i.i.i.i
  %sub.i.i.i.mux = select i1 %or.cond.i.i.i82.i.i.i.i, double %sub.i.i.i, double 0x7FF8000000000000
  br i1 %brmerge170, label %if.end7.i.i.i.i.i.i.i, label %if.end4.i.i.i92.i.i.i.i

if.end4.i.i.i92.i.i.i.i:                          ; preds = %if.then73.i.i.i.i
  %cmp5.i.i.i91.i.i.i.i = fcmp olt double %sub.i.i.i, 0.000000e+00
  %fneg.i.i.i93.i.i.i.i = fneg double %sub.i.i.i
  %z.addr.i.i.i76.i.i.i.i.0 = select i1 %cmp5.i.i.i91.i.i.i.i, double %fneg.i.i.i93.i.i.i.i, double %sub.i.i.i
  %600 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %601 = tail call double @llvm.amdgcn.frexp.mant.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %602 = tail call i1 @llvm.amdgcn.class.f64(double %z.addr.i.i.i76.i.i.i.i.0, i32 519) #3
  %603 = select i1 %602, i32 0, i32 %600
  %604 = select i1 %602, double %z.addr.i.i.i76.i.i.i.i.0, double %601
  %mul.i.i.i.i.i97.i.i.i.i = fmul double %604, %604
  %mul1.i.i.i.i.i98.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i99.i.i.i.i = fadd double %mul1.i.i.i.i.i98.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i100.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FE479D17050CA47
  %605 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i100.i.i.i.i
  %mul10.i.i.i.i.i102.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %add.i.i.i.i.i99.i.i.i.i
  %mul12.i.i.i.i.i103.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %605
  %add15.i.i.i.i.i104.i.i.i.i = fadd double %mul10.i.i.i.i.i102.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i105.i.i.i.i = fadd double %mul12.i.i.i.i.i103.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i106.i.i.i.i = fmul double %604, %add15.i.i.i.i.i104.i.i.i.i
  %add23.i.i.i.i.i107.i.i.i.i = fadd double %add18.i.i.i.i.i105.i.i.i.i, %mul20.i.i.i.i.i106.i.i.i.i
  %.frozen213 = freeze i32 %603
  %div.i.i.i108.i.i.i.i = sdiv i32 %.frozen213, 3
  %606 = sub nsw i32 0, %div.i.i.i108.i.i.i.i
  %607 = call i32 @llvm.abs.i32(i32 %div.i.i.i108.i.i.i.i, i1 true)
  %cmp11.i.i.i110.i.i.i.i = icmp ult i32 %607, 64
  br i1 %cmp11.i.i.i110.i.i.i.i, label %if.then12.i.i.i113.i.i.i.i, label %if.else21.i.i.i125.i.i.i.i

if.then12.i.i.i113.i.i.i.i:                       ; preds = %if.end4.i.i.i92.i.i.i.i
  %cmp13.i.i.i112.i.i.i.i = icmp sgt i32 %603, 2
  br i1 %cmp13.i.i.i112.i.i.i.i, label %if.then14.i.i.i118.i.i.i.i, label %if.else.i.i.i124.i.i.i.i

if.then14.i.i.i118.i.i.i.i:                       ; preds = %if.then12.i.i.i113.i.i.i.i
  %sh_prom.i.i.i114.i.i.i.i = zext i32 %div.i.i.i108.i.i.i.i to i64
  %shl.i.i.i115.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i114.i.i.i.i
  %conv.i.i.i116.i.i.i.i = uitofp i64 %shl.i.i.i115.i.i.i.i to double
  %mul.i.i.i117.i.i.i.i = fmul double %add23.i.i.i.i.i107.i.i.i.i, %conv.i.i.i116.i.i.i.i
  br label %if.end23.i.i.i131.i.i.i.i

if.else.i.i.i124.i.i.i.i:                         ; preds = %if.then12.i.i.i113.i.i.i.i
  %sh_prom16.i.i.i120.i.i.i.i = zext i32 %606 to i64
  %shl17.i.i.i121.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i120.i.i.i.i
  %conv18.i.i.i122.i.i.i.i = uitofp i64 %shl17.i.i.i121.i.i.i.i to double
  %div19.i.i.i123.i.i.i.i = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %conv18.i.i.i122.i.i.i.i
  br label %if.end23.i.i.i131.i.i.i.i

if.else21.i.i.i125.i.i.i.i:                       ; preds = %if.end4.i.i.i92.i.i.i.i
  %608 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  br label %if.end23.i.i.i131.i.i.i.i

if.end23.i.i.i131.i.i.i.i:                        ; preds = %if.else21.i.i.i125.i.i.i.i, %if.else.i.i.i124.i.i.i.i, %if.then14.i.i.i118.i.i.i.i
  %guess.i.i.i78.i.i.i.i.0 = phi double [ %mul.i.i.i117.i.i.i.i, %if.then14.i.i.i118.i.i.i.i ], [ %div19.i.i.i123.i.i.i.i, %if.else.i.i.i124.i.i.i.i ], [ %608, %if.else21.i.i.i125.i.i.i.i ]
  %.neg = mul nsw i32 %div.i.i.i108.i.i.i.i, -3
  %rem.i.i.i126.i.i.i.i.decomposed = add i32 %.frozen213, 2
  %add.i.i.i127.i.i.i.i = add i32 %rem.i.i.i126.i.i.i.i.decomposed, %.neg
  %609 = zext i32 %add.i.i.i127.i.i.i.i to i64
  %arrayidx1.i.i.i128.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %609
  %610 = load double, double addrspace(4)* %arrayidx1.i.i.i128.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i129.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.0, %610
  %cmp26.i.i.i130.i.i.i.i = icmp slt i32 %603, 1021
  br i1 %cmp26.i.i.i130.i.i.i.i, label %do.body.i.i.i142.i.i.i.i, label %do.body40.i.i.i153.i.i.i.i

do.body.i.i.i142.i.i.i.i:                         ; preds = %do.body.i.i.i142.i.i.i.i, %if.end23.i.i.i131.i.i.i.i
  %guess.i.i.i78.i.i.i.i.1 = phi double [ %mul24.i.i.i129.i.i.i.i, %if.end23.i.i.i131.i.i.i.i ], [ %mul35.i.i.i139.i.i.i.i, %do.body.i.i.i142.i.i.i.i ]
  %mul28.i.i.i132.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.1, %guess.i.i.i78.i.i.i.i.1
  %mul29.i.i.i133.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.1, %mul28.i.i.i132.i.i.i.i
  %add30.i.i.i134.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %mul29.i.i.i133.i.i.i.i
  %add31.i.i.i135.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add30.i.i.i134.i.i.i.i
  %add32.i.i.i136.i.i.i.i = fadd double %mul29.i.i.i133.i.i.i.i, %mul29.i.i.i133.i.i.i.i
  %add33.i.i.i137.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add32.i.i.i136.i.i.i.i
  %div34.i.i.i138.i.i.i.i = fdiv double %add31.i.i.i135.i.i.i.i, %add33.i.i.i137.i.i.i.i
  %mul35.i.i.i139.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.1, %div34.i.i.i138.i.i.i.i
  %sub36.i.i.i140.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i138.i.i.i.i
  %611 = tail call double @llvm.fabs.f64(double %sub36.i.i.i140.i.i.i.i) #3
  %cmp38.i.i.i141.i.i.i.i = fcmp ogt double %611, 0x3EC0000000000000
  br i1 %cmp38.i.i.i141.i.i.i.i, label %do.body.i.i.i142.i.i.i.i, label %if.end4.i.i.i.i.i.i.i

do.body40.i.i.i153.i.i.i.i:                       ; preds = %do.body40.i.i.i153.i.i.i.i, %if.end23.i.i.i131.i.i.i.i
  %guess.i.i.i78.i.i.i.i.2 = phi double [ %mul24.i.i.i129.i.i.i.i, %if.end23.i.i.i131.i.i.i.i ], [ %sub48.i.i.i150.i.i.i.i, %do.body40.i.i.i153.i.i.i.i ]
  %mul41.i.i.i143.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.2, %guess.i.i.i78.i.i.i.i.2
  %div42.i.i.i144.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %guess.i.i.i78.i.i.i.i.2
  %sub43.i.i.i145.i.i.i.i = fsub double %mul41.i.i.i143.i.i.i.i, %div42.i.i.i144.i.i.i.i
  %mul44.i.i.i146.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i147.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %mul41.i.i.i143.i.i.i.i
  %add46.i.i.i148.i.i.i.i = fadd double %mul44.i.i.i146.i.i.i.i, %div45.i.i.i147.i.i.i.i
  %div47.i.i.i149.i.i.i.i = fdiv double %sub43.i.i.i145.i.i.i.i, %add46.i.i.i148.i.i.i.i
  %sub48.i.i.i150.i.i.i.i = fsub double %guess.i.i.i78.i.i.i.i.2, %div47.i.i.i149.i.i.i.i
  %mul50.i.i.i151.i.i.i.i = fmul double %sub48.i.i.i150.i.i.i.i, 0x3EC0000000000000
  %612 = tail call double @llvm.fabs.f64(double %div47.i.i.i149.i.i.i.i) #3
  %cmp52.i.i.i152.i.i.i.i = fcmp olt double %mul50.i.i.i151.i.i.i.i, %612
  br i1 %cmp52.i.i.i152.i.i.i.i, label %do.body40.i.i.i153.i.i.i.i, label %if.end4.i.i.i.i.i.i.i

if.end4.i.i.i.i.i.i.i:                            ; preds = %do.body40.i.i.i153.i.i.i.i, %do.body.i.i.i142.i.i.i.i
  %guess.i.i.i78.i.i.i.i.3 = phi double [ %mul35.i.i.i139.i.i.i.i, %do.body.i.i.i142.i.i.i.i ], [ %sub48.i.i.i150.i.i.i.i, %do.body40.i.i.i153.i.i.i.i ]
  %613 = fneg double %guess.i.i.i78.i.i.i.i.3
  %614 = select i1 %cmp5.i.i.i91.i.i.i.i, double %613, double %guess.i.i.i78.i.i.i.i.3
  br i1 %cmp11.i.i.i110.i.i.i.i, label %if.then12.i.i.i32.i.i.i.i, label %if.else21.i.i.i44.i.i.i.i

if.then12.i.i.i32.i.i.i.i:                        ; preds = %if.end4.i.i.i.i.i.i.i
  %cmp13.i.i.i31.i.i.i.i = icmp sgt i32 %603, 2
  br i1 %cmp13.i.i.i31.i.i.i.i, label %if.then14.i.i.i37.i.i.i.i, label %if.else.i.i.i43.i.i.i.i

if.then14.i.i.i37.i.i.i.i:                        ; preds = %if.then12.i.i.i32.i.i.i.i
  %sh_prom.i.i.i33.i.i.i.i = zext i32 %div.i.i.i108.i.i.i.i to i64
  %shl.i.i.i34.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i33.i.i.i.i
  %conv.i.i.i35.i.i.i.i = uitofp i64 %shl.i.i.i34.i.i.i.i to double
  %mul.i.i.i36.i.i.i.i = fmul double %add23.i.i.i.i.i107.i.i.i.i, %conv.i.i.i35.i.i.i.i
  br label %if.end23.i.i.i50.i.i.i.i

if.else.i.i.i43.i.i.i.i:                          ; preds = %if.then12.i.i.i32.i.i.i.i
  %sh_prom16.i.i.i39.i.i.i.i = zext i32 %606 to i64
  %shl17.i.i.i40.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i39.i.i.i.i
  %conv18.i.i.i41.i.i.i.i = uitofp i64 %shl17.i.i.i40.i.i.i.i to double
  %div19.i.i.i42.i.i.i.i = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %conv18.i.i.i41.i.i.i.i
  br label %if.end23.i.i.i50.i.i.i.i

if.else21.i.i.i44.i.i.i.i:                        ; preds = %if.end4.i.i.i.i.i.i.i
  %615 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  br label %if.end23.i.i.i50.i.i.i.i

if.end23.i.i.i50.i.i.i.i:                         ; preds = %if.else21.i.i.i44.i.i.i.i, %if.else.i.i.i43.i.i.i.i, %if.then14.i.i.i37.i.i.i.i
  %guess.i.i.i10.i.i.i.i.0 = phi double [ %mul.i.i.i36.i.i.i.i, %if.then14.i.i.i37.i.i.i.i ], [ %div19.i.i.i42.i.i.i.i, %if.else.i.i.i43.i.i.i.i ], [ %615, %if.else21.i.i.i44.i.i.i.i ]
  %mul24.i.i.i48.i.i.i.i = fmul double %610, %guess.i.i.i10.i.i.i.i.0
  br i1 %cmp26.i.i.i130.i.i.i.i, label %do.body.i.i.i61.i.i.i.i, label %do.body40.i.i.i72.i.i.i.i

do.body.i.i.i61.i.i.i.i:                          ; preds = %do.body.i.i.i61.i.i.i.i, %if.end23.i.i.i50.i.i.i.i
  %guess.i.i.i10.i.i.i.i.1 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %mul35.i.i.i58.i.i.i.i, %do.body.i.i.i61.i.i.i.i ]
  %mul28.i.i.i51.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.1, %guess.i.i.i10.i.i.i.i.1
  %mul29.i.i.i52.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.1, %mul28.i.i.i51.i.i.i.i
  %add30.i.i.i53.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %mul29.i.i.i52.i.i.i.i
  %add31.i.i.i54.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add30.i.i.i53.i.i.i.i
  %add32.i.i.i55.i.i.i.i = fadd double %mul29.i.i.i52.i.i.i.i, %mul29.i.i.i52.i.i.i.i
  %add33.i.i.i56.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add32.i.i.i55.i.i.i.i
  %div34.i.i.i57.i.i.i.i = fdiv double %add31.i.i.i54.i.i.i.i, %add33.i.i.i56.i.i.i.i
  %mul35.i.i.i58.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.1, %div34.i.i.i57.i.i.i.i
  %sub36.i.i.i59.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i57.i.i.i.i
  %616 = tail call double @llvm.fabs.f64(double %sub36.i.i.i59.i.i.i.i) #3
  %cmp38.i.i.i60.i.i.i.i = fcmp ogt double %616, 0x3EC0000000000000
  br i1 %cmp38.i.i.i60.i.i.i.i, label %do.body.i.i.i61.i.i.i.i, label %if.end54.i.i.i.i.i.i.i

do.body40.i.i.i72.i.i.i.i:                        ; preds = %do.body40.i.i.i72.i.i.i.i, %if.end23.i.i.i50.i.i.i.i
  %guess.i.i.i10.i.i.i.i.2 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %sub48.i.i.i69.i.i.i.i, %do.body40.i.i.i72.i.i.i.i ]
  %mul41.i.i.i62.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.2, %guess.i.i.i10.i.i.i.i.2
  %div42.i.i.i63.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %guess.i.i.i10.i.i.i.i.2
  %sub43.i.i.i64.i.i.i.i = fsub double %mul41.i.i.i62.i.i.i.i, %div42.i.i.i63.i.i.i.i
  %mul44.i.i.i65.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i66.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %mul41.i.i.i62.i.i.i.i
  %add46.i.i.i67.i.i.i.i = fadd double %mul44.i.i.i65.i.i.i.i, %div45.i.i.i66.i.i.i.i
  %div47.i.i.i68.i.i.i.i = fdiv double %sub43.i.i.i64.i.i.i.i, %add46.i.i.i67.i.i.i.i
  %sub48.i.i.i69.i.i.i.i = fsub double %guess.i.i.i10.i.i.i.i.2, %div47.i.i.i68.i.i.i.i
  %mul50.i.i.i70.i.i.i.i = fmul double %sub48.i.i.i69.i.i.i.i, 0x3EC0000000000000
  %617 = tail call double @llvm.fabs.f64(double %div47.i.i.i68.i.i.i.i) #3
  %cmp52.i.i.i71.i.i.i.i = fcmp olt double %mul50.i.i.i70.i.i.i.i, %617
  br i1 %cmp52.i.i.i71.i.i.i.i, label %do.body40.i.i.i72.i.i.i.i, label %if.end54.i.i.i.i.i.i.i

if.end54.i.i.i.i.i.i.i:                           ; preds = %do.body40.i.i.i72.i.i.i.i, %do.body.i.i.i61.i.i.i.i
  %guess.i.i.i10.i.i.i.i.3 = phi double [ %mul35.i.i.i58.i.i.i.i, %do.body.i.i.i61.i.i.i.i ], [ %sub48.i.i.i69.i.i.i.i, %do.body40.i.i.i72.i.i.i.i ]
  %618 = fneg double %guess.i.i.i10.i.i.i.i.3
  %619 = select i1 %cmp5.i.i.i91.i.i.i.i, double %618, double %guess.i.i.i10.i.i.i.i.3
  br label %if.end7.i.i.i.i.i.i.i

if.end7.i.i.i.i.i.i.i:                            ; preds = %if.end54.i.i.i.i.i.i.i, %if.then73.i.i.i.i
  %retval.0.i.i.i156.i.i.i.i162 = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %614, %if.end54.i.i.i.i.i.i.i ]
  %retval.0.i.i.i.i.i.i.i = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %619, %if.end54.i.i.i.i.i.i.i ]
  %mul76.i.i.i.i = fmul double %retval.0.i.i.i156.i.i.i.i162, %retval.0.i.i.i.i.i.i.i
  %mul79.i.i.i.i = fmul double %mul76.i.i.i.i, 0x3FFD8639FDCB60EB
  %div80.i.i.i.i = fdiv double 1.000000e+00, %mul79.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

cond.false7.i.i.i:                                ; preds = %if.end14.i.i
  %decision.interval6 = fcmp ult double %arrayidx.val, 1.250000e-01
  br i1 %decision.interval6, label %if.else17.i.i.i.i, label %decision.dispatch5, !decision.condition_prefix !6

decision.dispatch5:                               ; preds = %cond.false7.i.i.i
  %decision.interval = fcmp ult double %arrayidx.val, 2.500000e-01
  %620 = fcmp ult double %arrayidx.val, 3.750000e-01
  %621 = select i1 %620, double -2.500000e-01, double -3.750000e-01
  %622 = select i1 %decision.interval, double -1.250000e-01, double %621
  %623 = select i1 %decision.interval, i1 poison, i1 %620
  %624 = fadd double %arrayidx.val, %622
  %625 = fmul double %624, %624
  br i1 %decision.interval, label %fusion.side3, label %fusion.side2

if.else17.i.i.i.i:                                ; preds = %cond.false7.i.i.i
  %626 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %arrayidx.val) #3
  %627 = add nsw i32 %626, -1
  %628 = tail call double @llvm.fabs.f64(double %arrayidx.val) #4
  %629 = fcmp oeq double %628, 0x7FF0000000000000
  %630 = select i1 %629, i32 2147483647, i32 %627
  %631 = fcmp oeq double %arrayidx.val, 0.000000e+00
  %632 = select i1 %631, i32 -2147483648, i32 %630
  %cmp106.i.i.i.i = icmp sgt i32 %632, -1025
  br i1 %cmp106.i.i.i.i, label %decision.dispatch2, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, !decision.condition_prefix !6

if.then20.i.i.i.i:                                ; preds = %decision.dispatch2
  %633 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 3) #3
  %634 = tail call double @llvm.amdgcn.frexp.mant.f64(double %633) #3
  %635 = fcmp olt double %634, 0x3FE5555555555555
  %636 = zext i1 %635 to i32
  %637 = tail call double @llvm.amdgcn.ldexp.f64(double %634, i32 %636) #3
  %638 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %633) #3
  %639 = sub nsw i32 %638, %636
  %640 = fadd double %637, -1.000000e+00
  %641 = fadd double %637, 1.000000e+00
  %642 = fsub double %641, %637
  %643 = fsub double %641, %642
  %644 = fsub double %637, %643
  %645 = fsub double 1.000000e+00, %642
  %646 = fadd double %645, %644
  %647 = tail call double @llvm.amdgcn.rcp.f64(double %641) #3
  %648 = fneg double %641
  %649 = tail call double @llvm.fma.f64(double %648, double %647, double 1.000000e+00) #3
  %650 = tail call double @llvm.fma.f64(double %649, double %647, double %647) #3
  %651 = tail call double @llvm.fma.f64(double %648, double %650, double 1.000000e+00) #3
  %652 = tail call double @llvm.fma.f64(double %651, double %650, double %650) #3
  %653 = fmul double %640, %652
  %654 = fmul double %641, %653
  %655 = fneg double %654
  %656 = tail call double @llvm.fma.f64(double %653, double %641, double %655) #3
  %657 = tail call double @llvm.fma.f64(double %653, double %646, double %656) #3
  %658 = fadd double %654, %657
  %659 = fsub double %658, %654
  %660 = fsub double %657, %659
  %661 = fsub double %640, %658
  %662 = fsub double %640, %661
  %663 = fsub double %662, %658
  %664 = fsub double %663, %660
  %665 = fadd double %661, %664
  %666 = fmul double %652, %665
  %667 = fadd double %653, %666
  %668 = fsub double %667, %653
  %669 = fsub double %666, %668
  %670 = fmul double %667, %667
  %671 = fneg double %670
  %672 = tail call double @llvm.fma.f64(double %667, double %667, double %671) #3
  %673 = fmul double %669, 2.000000e+00
  %674 = tail call double @llvm.fma.f64(double %667, double %673, double %672) #3
  %675 = tail call double @llvm.fma.f64(double %669, double %669, double %674) #3
  %676 = fadd double %670, %675
  %677 = fsub double %676, %670
  %678 = fsub double %675, %677
  %679 = tail call double @llvm.fma.f64(double %676, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %680 = tail call double @llvm.fma.f64(double %676, double %679, double 0x3FC7474DD7F4DF2E) #3
  %681 = tail call double @llvm.fma.f64(double %676, double %680, double 0x3FCC71C016291751) #3
  %682 = tail call double @llvm.fma.f64(double %676, double %681, double 0x3FD249249B27ACF1) #3
  %683 = tail call double @llvm.fma.f64(double %676, double %682, double 0x3FD99999998EF7B6) #3
  %684 = tail call double @llvm.fma.f64(double %676, double %683, double 0x3FE5555555555780) #3
  %685 = tail call double @llvm.amdgcn.ldexp.f64(double %667, i32 1) #3
  %686 = tail call double @llvm.amdgcn.ldexp.f64(double %669, i32 1) #3
  %687 = fmul double %667, %676
  %688 = fneg double %687
  %689 = tail call double @llvm.fma.f64(double %667, double %676, double %688) #3
  %690 = fmul double %669, %676
  %691 = tail call double @llvm.fma.f64(double %667, double %678, double %690) #3
  %692 = fadd double %689, %691
  %693 = fadd double %687, %692
  %694 = fsub double %693, %687
  %695 = fsub double %692, %694
  %696 = fmul double %693, %684
  %697 = fneg double %696
  %698 = tail call double @llvm.fma.f64(double %693, double %684, double %697) #3
  %699 = tail call double @llvm.fma.f64(double %695, double %684, double %698) #3
  %700 = fadd double %696, %699
  %701 = fsub double %700, %696
  %702 = fsub double %699, %701
  %703 = fadd double %685, %700
  %704 = fsub double %703, %685
  %705 = fsub double %703, %704
  %706 = fsub double %685, %705
  %707 = fsub double %700, %704
  %708 = fadd double %707, %706
  %709 = fadd double %686, %702
  %710 = fsub double %709, %686
  %711 = fsub double %709, %710
  %712 = fsub double %686, %711
  %713 = fsub double %702, %710
  %714 = fadd double %713, %712
  %715 = fadd double %709, %708
  %716 = fadd double %703, %715
  %717 = fsub double %716, %703
  %718 = fsub double %715, %717
  %719 = fadd double %714, %718
  %720 = fadd double %716, %719
  %721 = fsub double %720, %716
  %722 = fsub double %719, %721
  %723 = sitofp i32 %639 to double
  %724 = fmul double %720, 0x3FF71547652B82FE
  %725 = fneg double %724
  %726 = fmul double %720, 0x3C7777D0FFDA0D24
  %727 = insertelement <2 x double> undef, double %720, i32 0
  %728 = insertelement <2 x double> %727, double %722, i32 1
  %729 = insertelement <2 x double> undef, double %725, i32 0
  %730 = insertelement <2 x double> %729, double %726, i32 1
  %731 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %728, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %730) #3
  %732 = extractelement <2 x double> %731, i32 0
  %733 = extractelement <2 x double> %731, i32 1
  %734 = fadd double %732, %733
  %735 = fadd double %724, %734
  %736 = fsub double %735, %724
  %737 = fsub double %734, %736
  %738 = fadd double %735, %723
  %739 = fsub double %738, %723
  %740 = fsub double %739, %738
  %741 = fadd double %740, %723
  %742 = fsub double %735, %739
  %743 = fadd double %742, %741
  %744 = fadd double %737, %743
  %745 = fadd double %738, %744
  %746 = tail call double @llvm.fabs.f64(double %633) #4
  %747 = fcmp oeq double %746, 0x7FF0000000000000
  %748 = select i1 %747, double %633, double %745
  %749 = fcmp olt double %633, 0.000000e+00
  %750 = select i1 %749, double 0x7FF8000000000000, double %748
  %751 = fcmp oeq double %633, 0.000000e+00
  %752 = select i1 %751, double 0xFFF0000000000000, double %750
  %mul.i.i244.i.i.i.i = fmul double %752, %752
  %mul1.i.i245.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F1989D450BBA5CA
  %753 = fsub double 0xBFBD94CCEC41CB08, %mul1.i.i245.i.i.i.i
  %mul5.i.i247.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F7B3A00DD9C9429
  %754 = fsub double 0xBFE8DDD719DA7D3E, %mul5.i.i247.i.i.i.i
  %mul10.i.i249.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %753
  %mul12.i.i250.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %754
  %add15.i.i251.i.i.i.i = fadd double %mul10.i.i249.i.i.i.i, 0xC001974D2C397C76
  %add18.i.i252.i.i.i.i = fadd double %mul12.i.i250.i.i.i.i, 0xC001804F92FE2A82
  %755 = fmul double %752, %add15.i.i251.i.i.i.i
  %add23.i.i254.i.i.i.i = fsub double %add18.i.i252.i.i.i.i, %755
  %mul1.i.i234.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3EDBEC7AF5AC0D6F
  %add.i.i235.i.i.i.i = fadd double %mul1.i.i234.i.i.i.i, 0x3F98BA1DB321D0E9
  %mul5.i.i236.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F4ED662BB480251
  %add7.i.i237.i.i.i.i = fadd double %mul5.i.i236.i.i.i.i, 0x3FCBD444F5D4FCC2
  %mul10.i.i238.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %add.i.i235.i.i.i.i
  %mul12.i.i239.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %add7.i.i237.i.i.i.i
  %add15.i.i240.i.i.i.i = fadd double %mul10.i.i238.i.i.i.i, 0x3FE957680773BEB6
  %add18.i.i241.i.i.i.i = fadd double %mul12.i.i239.i.i.i.i, 1.000000e+00
  %756 = fmul double %752, %add15.i.i240.i.i.i.i
  %add23.i.i243.i.i.i.i = fsub double %add18.i.i241.i.i.i.i, %756
  %div26.i.i.i.i = fdiv double %add23.i.i254.i.i.i.i, %add23.i.i243.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

decision.dispatch2:                               ; preds = %if.else17.i.i.i.i
  %cmp19.i.i.i.i = icmp sgt i32 %632, -5
  br i1 %cmp19.i.i.i.i, label %if.then20.i.i.i.i, label %decision.dispatch1, !decision.merged_from !14, !decision.origin !15

decision.dispatch4:                               ; preds = %decision.dispatch1
  %cmp40.i.i.i.i = icmp sgt i32 %632, -17
  %merged.select = select i1 %cmp40.i.i.i.i, i32 -9, i32 -33
  %757 = icmp sgt i32 %632, %merged.select
  %merged.select36 = select i1 %cmp40.i.i.i.i, i32 4, i32 16
  %merged.select37 = select i1 %cmp40.i.i.i.i, i32 8, i32 32
  %758 = select i1 %757, i32 %merged.select36, i32 %merged.select37
  %759 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %758) #3
  %760 = tail call double @llvm.amdgcn.frexp.mant.f64(double %759) #3
  %761 = fcmp olt double %760, 0x3FE5555555555555
  %762 = zext i1 %761 to i32
  %763 = tail call double @llvm.amdgcn.ldexp.f64(double %760, i32 %762) #3
  %764 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %759) #3
  %765 = sub nsw i32 %764, %762
  %766 = fadd double %763, -1.000000e+00
  %767 = fadd double %763, 1.000000e+00
  %768 = fsub double %767, %763
  %769 = fsub double %767, %768
  %770 = fsub double %763, %769
  %771 = fsub double 1.000000e+00, %768
  %772 = fadd double %771, %770
  %773 = tail call double @llvm.amdgcn.rcp.f64(double %767) #3
  %774 = fneg double %767
  %775 = tail call double @llvm.fma.f64(double %774, double %773, double 1.000000e+00) #3
  %776 = tail call double @llvm.fma.f64(double %775, double %773, double %773) #3
  %777 = tail call double @llvm.fma.f64(double %774, double %776, double 1.000000e+00) #3
  %778 = tail call double @llvm.fma.f64(double %777, double %776, double %776) #3
  %779 = fmul double %766, %778
  %780 = fmul double %767, %779
  %781 = fneg double %780
  %782 = tail call double @llvm.fma.f64(double %779, double %767, double %781) #3
  %783 = tail call double @llvm.fma.f64(double %779, double %772, double %782) #3
  %784 = fadd double %780, %783
  %785 = fsub double %784, %780
  %786 = fsub double %783, %785
  %787 = fsub double %766, %784
  %788 = fsub double %766, %787
  %789 = fsub double %788, %784
  %790 = fsub double %789, %786
  %791 = fadd double %787, %790
  %792 = fmul double %778, %791
  %793 = fadd double %779, %792
  %794 = fsub double %793, %779
  %795 = fsub double %792, %794
  %796 = fmul double %793, %793
  %797 = fneg double %796
  %798 = tail call double @llvm.fma.f64(double %793, double %793, double %797) #3
  %799 = fmul double %795, 2.000000e+00
  %800 = tail call double @llvm.fma.f64(double %793, double %799, double %798) #3
  %801 = tail call double @llvm.fma.f64(double %795, double %795, double %800) #3
  %802 = fadd double %796, %801
  %803 = fsub double %802, %796
  %804 = fsub double %801, %803
  %805 = tail call double @llvm.fma.f64(double %802, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %806 = tail call double @llvm.fma.f64(double %802, double %805, double 0x3FC7474DD7F4DF2E) #3
  %807 = tail call double @llvm.fma.f64(double %802, double %806, double 0x3FCC71C016291751) #3
  %808 = tail call double @llvm.fma.f64(double %802, double %807, double 0x3FD249249B27ACF1) #3
  %809 = tail call double @llvm.fma.f64(double %802, double %808, double 0x3FD99999998EF7B6) #3
  %810 = tail call double @llvm.fma.f64(double %802, double %809, double 0x3FE5555555555780) #3
  %811 = tail call double @llvm.amdgcn.ldexp.f64(double %793, i32 1) #3
  %812 = tail call double @llvm.amdgcn.ldexp.f64(double %795, i32 1) #3
  %813 = fmul double %793, %802
  %814 = fneg double %813
  %815 = tail call double @llvm.fma.f64(double %793, double %802, double %814) #3
  %816 = fmul double %795, %802
  %817 = tail call double @llvm.fma.f64(double %793, double %804, double %816) #3
  %818 = fadd double %815, %817
  %819 = fadd double %813, %818
  %820 = fsub double %819, %813
  %821 = fsub double %818, %820
  %822 = fmul double %819, %810
  %823 = fneg double %822
  %824 = tail call double @llvm.fma.f64(double %819, double %810, double %823) #3
  %825 = tail call double @llvm.fma.f64(double %821, double %810, double %824) #3
  %826 = fadd double %822, %825
  %827 = fsub double %826, %822
  %828 = fsub double %825, %827
  %829 = fadd double %811, %826
  %830 = fsub double %829, %811
  %831 = fsub double %829, %830
  %832 = fsub double %811, %831
  %833 = fsub double %826, %830
  %834 = fadd double %833, %832
  %835 = fadd double %812, %828
  %836 = fsub double %835, %812
  %837 = fsub double %835, %836
  %838 = fsub double %812, %837
  %839 = fsub double %828, %836
  %840 = fadd double %839, %838
  %841 = fadd double %835, %834
  %842 = fadd double %829, %841
  %843 = fsub double %842, %829
  %844 = fsub double %841, %843
  %845 = fadd double %840, %844
  %846 = fadd double %842, %845
  %847 = fsub double %846, %842
  %848 = fsub double %845, %847
  %849 = fmul double %846, 0x3FF71547652B82FE
  %850 = fneg double %849
  %851 = fmul double %846, 0x3C7777D0FFDA0D24
  br i1 %757, label %merged.bb33, label %merged.bb34

decision.dispatch1:                               ; preds = %decision.dispatch2
  %cmp62.i.i.i.i = icmp sgt i32 %632, -65
  br i1 %cmp62.i.i.i.i, label %decision.dispatch4, label %decision.dispatch, !decision.merged_from !16, !decision.origin !17

decision.dispatch:                                ; preds = %decision.dispatch1
  %cmp84.i.i.i.i = icmp sgt i32 %632, -257
  %merged.select39 = select i1 %cmp84.i.i.i.i, i32 -129, i32 -513
  %852 = icmp sgt i32 %632, %merged.select39
  %merged.select40 = select i1 %cmp84.i.i.i.i, i32 64, i32 256
  %merged.select41 = select i1 %cmp84.i.i.i.i, i32 128, i32 512
  %853 = select i1 %852, i32 %merged.select40, i32 %merged.select41
  %854 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %853) #3
  %855 = tail call double @llvm.amdgcn.frexp.mant.f64(double %854) #3
  %856 = fcmp olt double %855, 0x3FE5555555555555
  %857 = zext i1 %856 to i32
  %858 = tail call double @llvm.amdgcn.ldexp.f64(double %855, i32 %857) #3
  %859 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %854) #3
  %860 = sub nsw i32 %859, %857
  %861 = fadd double %858, -1.000000e+00
  %862 = fadd double %858, 1.000000e+00
  %863 = fsub double %862, %858
  %864 = fsub double %862, %863
  %865 = fsub double %858, %864
  %866 = fsub double 1.000000e+00, %863
  %867 = fadd double %866, %865
  %868 = tail call double @llvm.amdgcn.rcp.f64(double %862) #3
  %869 = fneg double %862
  %870 = tail call double @llvm.fma.f64(double %869, double %868, double 1.000000e+00) #3
  %871 = tail call double @llvm.fma.f64(double %870, double %868, double %868) #3
  %872 = tail call double @llvm.fma.f64(double %869, double %871, double 1.000000e+00) #3
  %873 = tail call double @llvm.fma.f64(double %872, double %871, double %871) #3
  %874 = fmul double %861, %873
  %875 = fmul double %862, %874
  %876 = fneg double %875
  %877 = tail call double @llvm.fma.f64(double %874, double %862, double %876) #3
  %878 = tail call double @llvm.fma.f64(double %874, double %867, double %877) #3
  %879 = fadd double %875, %878
  %880 = fsub double %879, %875
  %881 = fsub double %878, %880
  %882 = fsub double %861, %879
  %883 = fsub double %861, %882
  %884 = fsub double %883, %879
  %885 = fsub double %884, %881
  %886 = fadd double %882, %885
  %887 = fmul double %873, %886
  %888 = fadd double %874, %887
  %889 = fsub double %888, %874
  %890 = fsub double %887, %889
  %891 = fmul double %888, %888
  %892 = fneg double %891
  %893 = tail call double @llvm.fma.f64(double %888, double %888, double %892) #3
  %894 = fmul double %890, 2.000000e+00
  %895 = tail call double @llvm.fma.f64(double %888, double %894, double %893) #3
  %896 = tail call double @llvm.fma.f64(double %890, double %890, double %895) #3
  %897 = fadd double %891, %896
  %898 = fsub double %897, %891
  %899 = fsub double %896, %898
  %900 = tail call double @llvm.fma.f64(double %897, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %901 = tail call double @llvm.fma.f64(double %897, double %900, double 0x3FC7474DD7F4DF2E) #3
  %902 = tail call double @llvm.fma.f64(double %897, double %901, double 0x3FCC71C016291751) #3
  %903 = tail call double @llvm.fma.f64(double %897, double %902, double 0x3FD249249B27ACF1) #3
  %904 = tail call double @llvm.fma.f64(double %897, double %903, double 0x3FD99999998EF7B6) #3
  %905 = tail call double @llvm.fma.f64(double %897, double %904, double 0x3FE5555555555780) #3
  %906 = tail call double @llvm.amdgcn.ldexp.f64(double %888, i32 1) #3
  %907 = tail call double @llvm.amdgcn.ldexp.f64(double %890, i32 1) #3
  %908 = fmul double %888, %897
  %909 = fneg double %908
  %910 = tail call double @llvm.fma.f64(double %888, double %897, double %909) #3
  %911 = fmul double %890, %897
  %912 = tail call double @llvm.fma.f64(double %888, double %899, double %911) #3
  %913 = fadd double %910, %912
  %914 = fadd double %908, %913
  %915 = fsub double %914, %908
  %916 = fsub double %913, %915
  %917 = fmul double %914, %905
  %918 = fneg double %917
  %919 = tail call double @llvm.fma.f64(double %914, double %905, double %918) #3
  %920 = tail call double @llvm.fma.f64(double %916, double %905, double %919) #3
  %921 = fadd double %917, %920
  %922 = fsub double %921, %917
  %923 = fsub double %920, %922
  %924 = fadd double %906, %921
  %925 = fsub double %924, %906
  %926 = fsub double %924, %925
  %927 = fsub double %906, %926
  %928 = fsub double %921, %925
  %929 = fadd double %928, %927
  %930 = fadd double %907, %923
  %931 = fsub double %930, %907
  %932 = fsub double %930, %931
  %933 = fsub double %907, %932
  %934 = fsub double %923, %931
  %935 = fadd double %934, %933
  %936 = fadd double %930, %929
  %937 = fadd double %924, %936
  %938 = fsub double %937, %924
  %939 = fsub double %936, %938
  %940 = fadd double %935, %939
  %941 = fadd double %937, %940
  %942 = fsub double %941, %937
  %943 = fsub double %940, %942
  %944 = fmul double %941, 0x3FF71547652B82FE
  %945 = fneg double %944
  %946 = fmul double %941, 0x3C7777D0FFDA0D24
  br i1 %852, label %merged.bb36, label %merged.bb37

fusion.side12:                                    ; preds = %decision.dispatch3
  %947 = fmul double %10, 0x3FF51F0306685285
  %948 = fsub double 0xBFEEB82FAA589934, %947
  %949 = fmul double %10, 0x3FEFDC5AEE1525E4
  %950 = fsub double 0x4043A793DEC20DEB, %949
  br label %fusion.common11

fusion.common11:                                  ; preds = %fusion.side12, %decision.dispatch3
  %951 = phi double [ 0x40354F2A1256B431, %decision.dispatch3 ], [ 0x4020675EC4F85A38, %fusion.side12 ]
  %952 = phi double [ 0x4063AA2F5D62DCD3, %decision.dispatch3 ], [ 0x403058D46A8EC004, %fusion.side12 ]
  %953 = phi double [ 0x407BA4300BFE5087, %decision.dispatch3 ], [ 0xC02E8C55CA7195EF, %fusion.side12 ]
  %954 = phi double [ 0xC083E59B9D34A0F1, %decision.dispatch3 ], [ 0x401A11C0BB0DC22E, %fusion.side12 ]
  %955 = phi double [ 0x406113A5A6902AC1, %decision.dispatch3 ], [ %948, %fusion.side12 ]
  %956 = phi double [ poison, %decision.dispatch3 ], [ %950, %fusion.side12 ]
  %957 = fmul double %10, %955
  %958 = fmul double %10, %956
  %959 = fadd double %957, %954
  %.op3 = fadd double %958, 0xC04B158FF790C730
  %960 = fmul double %10, 0x4071AEC837B9190D
  %961 = fsub double 0x406A5A0FD2D4B901, %960
  %fusion.paired18 = select i1 %cmp.i.i.i.i, double %961, double %.op3
  %962 = fmul double %10, %959
  %963 = fmul double %10, %fusion.paired18
  %964 = fadd double %962, %953
  %965 = fadd double %963, %952
  %966 = fmul double %10, %964
  %967 = fmul double %10, %965
  %968 = fadd double %966, %951
  %969 = fadd double %967, 1.000000e+00
  %970 = fmul double %9, %968
  %971 = fadd double %969, %970
  %972 = fdiv double %30, %971
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

fusion.side2:                                     ; preds = %decision.dispatch5
  %973 = select i1 %623, double 0x402A50B00A1E7B86, double 0x40132BDEE3243B58
  %974 = fmul double %625, %973
  %975 = select i1 %623, double 0xC03EAAFBAB179207, double 0xC0360FDD97954BA2
  %976 = fadd double %974, %975
  %977 = select i1 %623, double 0x403CBAD71AE3B29A, double 0x401CB5EDEDB31A3B
  %978 = fmul double %625, %977
  %979 = fadd double %978, 0xC017CB97C9E45E0D
  %980 = fsub double 0x4040A8BCD7811DE4, %978
  %981 = select i1 %623, double %980, double %979
  br label %fusion.common1

fusion.side3:                                     ; preds = %decision.dispatch5
  %982 = fmul double %625, 0x406D392CDE09E490
  %983 = fsub double 0x408C7AAA9D225E9A, %982
  %984 = fmul double %625, 0x408B6249334DA816
  %985 = fsub double 0x408C1B9BAF952B96, %984
  %986 = fmul double %625, %983
  %phi.bo = fadd double %986, 0xC05E9BCF5C362E51
  br label %fusion.common1

fusion.common1:                                   ; preds = %fusion.side3, %fusion.side2
  %987 = phi double [ 0x401B5545C0CB5BDA, %fusion.side2 ], [ 0xC0320C17B7F0ED52, %fusion.side3 ]
  %988 = phi double [ 0x3FF693D2420640AD, %fusion.side2 ], [ 0x404C078043CB129C, %fusion.side3 ]
  %989 = phi double [ %981, %fusion.side2 ], [ %phi.bo, %fusion.side3 ]
  %fusion.paired4 = phi double [ %976, %fusion.side2 ], [ %985, %fusion.side3 ]
  %990 = fmul double %625, %fusion.paired4
  %991 = fmul double %625, %989
  %992 = select i1 %623, double 0x402CB09090084637, double 0x4027FEF192CFFD80
  %993 = select i1 %623, double 0xC013B1AD6B90733F, double 0x3FF83BDAD25D5F48
  %994 = select i1 %decision.interval, double 0xC04249A2BD20D346, double %993
  %995 = fadd double %991, %994
  %996 = select i1 %623, double 0xBFFA1FFFE7A41296, double 0xBFF2C5AD0DCDC29A
  %.v.v = select i1 %decision.interval, double 0xC066A4A24A4E1713, double %992
  %.v = fadd double %990, %.v.v
  %997 = fmul double %625, %.v
  %998 = select i1 %decision.interval, double 0xC001804F92FE2A82, double %996
  %999 = fadd double %997, %998
  %1000 = fmul double %624, %995
  %1001 = fadd double %1000, %999
  %1002 = fmul double %625, 0x405E5232607614DB
  %1003 = fadd double %1002, 0xC0809E1D789AFFE5
  %1004 = fmul double %625, %988
  %1005 = fsub double %987, %1004
  %1006 = select i1 %623, double 0x40296F06194D60C2, double 0x40074E9A9F865729
  %1007 = select i1 %decision.interval, double %1003, double %1006
  %1008 = fmul double %625, %1007
  %1009 = select i1 %623, double 0xC030F25386AA802B, double 0xC016B372910B83AB
  %1010 = fmul double %625, %1005
  %1011 = select i1 %decision.interval, double 0x4071A64A34042F35, double %1009
  %1012 = fadd double %1008, %1011
  %1013 = select i1 %623, double 0x40199996D51EE9B7, double %1005
  %1014 = fmul double %625, %1013
  %1015 = fsub double 0x40034649FCCCF81F, %1014
  %.op4 = fadd double %1010, 0x405F12CC60181A8F
  %1016 = select i1 %decision.interval, double poison, double %1015
  %1017 = fmul double %625, %1012
  %.op5 = fadd double %1014, 0xC0138A29DF206C0B
  %1018 = select i1 %623, double 0x40158CEB587D3265, double 0x3FFC33F0B4C09D66
  %1019 = select i1 %decision.interval, double poison, double %.op5
  %1020 = select i1 %decision.interval, double 0x40332E0500972875, double %1018
  %1021 = fadd double %1017, %1020
  %1022 = select i1 %623, double %1016, double %1019
  %.v6 = select i1 %decision.interval, double %.op4, double %1022
  %1023 = fmul double %625, %.v6
  %1024 = fadd double %1023, 1.000000e+00
  %1025 = fmul double %624, %1021
  %1026 = fadd double %1025, %1024
  %1027 = fdiv double %1001, %1026
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i: ; preds = %merged.bb72, %merged.bb71, %fusion.common1, %fusion.common11, %if.then20.i.i.i.i, %if.else17.i.i.i.i, %if.end7.i.i.i.i.i.i.i, %if.else71.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i
  %retval.0.i.i.i = phi double [ %div20.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i ], [ %div34.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i ], [ %div48.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i ], [ %div62.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i ], [ %div70.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i ], [ 0x7FF0000000000000, %if.else71.i.i.i.i ], [ %div80.i.i.i.i, %if.end7.i.i.i.i.i.i.i ], [ 0xFFF0000000000000, %if.else17.i.i.i.i ], [ %div26.i.i.i.i, %if.then20.i.i.i.i ], [ %972, %fusion.common11 ], [ %1027, %fusion.common1 ], [ %1103, %merged.bb71 ], [ %1150, %merged.bb72 ]
  %add.i.i = fadd double %retval.0.i.i.i, 0.000000e+00
  br label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit

_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit: ; preds = %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, %lor.lhs.false2.i.i.i, %if.end8.i.i
  %retval.0.i.i = phi double [ 0x7FF8000000000000, %if.end8.i.i ], [ 0x7FF8000000000000, %lor.lhs.false2.i.i.i ], [ %add.i.i, %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i ]
  %arrayidx712 = getelementptr inbounds double, double addrspace(1)* %output.coerce, i64 %idxprom
  store double %retval.0.i.i, double addrspace(1)* %arrayidx712, align 8, !tbaa !8
  br label %if.end

if.end:                                           ; preds = %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, %entry
  ret void

merged.bb33:                                      ; preds = %decision.dispatch4
  %1028 = insertelement <2 x double> undef, double %846, i32 0
  %1029 = insertelement <2 x double> %1028, double %848, i32 1
  %1030 = insertelement <2 x double> undef, double %850, i32 0
  %1031 = insertelement <2 x double> %1030, double %851, i32 1
  %1032 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1029, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1031) #3
  %1033 = extractelement <2 x double> %1032, i32 0
  %1034 = extractelement <2 x double> %1032, i32 1
  br label %merged.bb70

merged.bb34:                                      ; preds = %decision.dispatch4
  %1035 = insertelement <2 x double> undef, double %846, i32 0
  %1036 = insertelement <2 x double> %1035, double %848, i32 1
  %1037 = insertelement <2 x double> undef, double %850, i32 0
  %1038 = insertelement <2 x double> %1037, double %851, i32 1
  %1039 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1036, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1038) #3
  %1040 = extractelement <2 x double> %1039, i32 0
  %1041 = extractelement <2 x double> %1039, i32 1
  br label %merged.bb70

merged.bb36:                                      ; preds = %decision.dispatch
  %1042 = insertelement <2 x double> undef, double %941, i32 0
  %1043 = insertelement <2 x double> %1042, double %943, i32 1
  %1044 = insertelement <2 x double> undef, double %945, i32 0
  %1045 = insertelement <2 x double> %1044, double %946, i32 1
  %1046 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1043, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1045) #3
  %1047 = extractelement <2 x double> %1046, i32 0
  %1048 = extractelement <2 x double> %1046, i32 1
  br label %merged.bb70

merged.bb37:                                      ; preds = %decision.dispatch
  %1049 = insertelement <2 x double> undef, double %941, i32 0
  %1050 = insertelement <2 x double> %1049, double %943, i32 1
  %1051 = insertelement <2 x double> undef, double %945, i32 0
  %1052 = insertelement <2 x double> %1051, double %946, i32 1
  %1053 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1050, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1052) #3
  %1054 = extractelement <2 x double> %1053, i32 0
  %1055 = extractelement <2 x double> %1053, i32 1
  br label %merged.bb70

merged.bb70:                                      ; preds = %merged.bb37, %merged.bb36, %merged.bb34, %merged.bb33
  %merged.select99 = phi double [ 0x3FE7235AE26E3A60, %merged.bb33 ], [ 0x3FD6E5B7AB236028, %merged.bb34 ], [ 0x3FA66506CA3FCEB3, %merged.bb36 ], [ 0x3F964BEF3074CF28, %merged.bb37 ]
  %merged.select98 = phi double [ 0x3FC92E7DCCD1B70C, %merged.bb33 ], [ 0x3FA8A45F1AE4ADBE, %merged.bb34 ], [ 0x3F478C82425FFDCE, %merged.bb36 ], [ 0x3F275783E6F9B4DA, %merged.bb37 ]
  %merged.select97 = phi double [ 0x3F999857B526C821, %merged.bb33 ], [ 0x3F68BF137C253BD1, %merged.bb34 ], [ 0x3ED71590B83839D8, %merged.bb36 ], [ 0x3EA6C7746378848A, %merged.bb37 ]
  %merged.select96 = phi double [ 0x3F0330822740ADF9, %merged.bb33 ], [ 0x3EB20E304F6E5BCE, %merged.bb34 ], [ 0x3DC001D96C7E2C9D, %merged.bb36 ], [ 0x3D6F4FAB0C90F842, %merged.bb37 ]
  %merged.select95 = phi double [ 0x3F586FC94B9EAD30, %merged.bb33 ], [ 0x3F1751EF5755C229, %merged.bb34 ], [ 0x3E553724D72BE5C7, %merged.bb36 ], [ 0x3E14D76BE5BA042B, %merged.bb37 ]
  %merged.select94 = phi double [ 0x3E9090FBB4B042AE, %merged.bb33 ], [ 0x3E2EB2F3F6504F32, %merged.bb34 ], [ 0x3D0A81E9CB6A1EA5, %merged.bb36 ], [ 0x3CA9D032740CF69A, %merged.bb37 ]
  %merged.select93 = phi double [ 0xC004C929A952DE48, %merged.bb33 ], [ 0xC00D636ADAEC3C05, %merged.bb34 ], [ 0xC0207852FA1731C0, %merged.bb36 ], [ 0xC024F817DD06EE79, %merged.bb37 ]
  %merged.select92 = phi double [ 0xC001F1CD6A03BCAA, %merged.bb33 ], [ 0xBFF8595CA25899FD, %merged.bb34 ], [ 0xBFD9F6368DFEFDDF, %merged.bb36 ], [ 0xBFD06A8AF4A3FC55, %merged.bb37 ]
  %merged.select91 = phi double [ 0xBFE78F054AC7A90B, %merged.bb33 ], [ 0xBFCED54905311121, %merged.bb34 ], [ 0xBF7F5FDEC6827012, %merged.bb36 ], [ 0xBF63B612102F3C24, %merged.bb37 ]
  %merged.select90 = phi double [ 0xBFBD7935AC58B5B5, %merged.bb33 ], [ 0xBF92AE2345C460A0, %merged.bb34 ], [ 0xBF1232A95F4E8466, %merged.bb36 ], [ 0xBEE6B9C7BCE39403, %merged.bb37 ]
  %merged.select89 = phi double [ 0xBF81F96D17A7115B, %merged.bb33 ], [ 0xBF4625660A41D7B1, %merged.bb34 ], [ 0xBE94B8A80FB81310, %merged.bb36 ], [ 0xBE59BA2A0439E4A9, %merged.bb37 ]
  %merged.select88 = phi double [ 0x3ECBFD524C94F258, %merged.bb33 ], [ 0x3E70731CF2A765F0, %merged.bb34 ], [ 0x3D5CB3C39661DD79, %merged.bb36 ], [ 0x3D01A287ED1019B8, %merged.bb37 ]
  %merged.select87 = phi double [ 0xBF336C13BBA203F3, %merged.bb33 ], [ 0xBEE755F1646665DB, %merged.bb34 ], [ 0xBE050B1B8007F8FF, %merged.bb36 ], [ 0xBDB9FC7E20BD04CC, %merged.bb37 ]
  %merged.select86 = phi double [ 0x3E32022ABCFF5DE7, %merged.bb33 ], [ 0x3DC4C8BD76453064, %merged.bb34 ], [ 0x3C819FA1E5E36C20, %merged.bb36 ], [ 0x3C158FD8B3C1B0C0, %merged.bb37 ]
  %merged.select124 = phi double [ 0x3FC6B0CE3157BCB1, %merged.bb33 ], [ 0x3FB68627D1A51CB5, %merged.bb34 ], [ 0x3F86397D81A61D6E, %merged.bb36 ], [ 0x3F762C8C65771E78, %merged.bb37 ]
  %merged.select123 = phi double [ 0x3F882FD20DA34F30, %merged.bb33 ], [ 0x3F67D3564F778B21, %merged.bb34 ], [ 0x3F0730EC426E6E84, %merged.bb36 ], [ 0x3EE71602E8EA99F3, %merged.bb37 ]
  %merged.select122 = phi double [ 0x3F380B62C1407B15, %merged.bb33 ], [ 0x3F077F4625619D43, %merged.bb34 ], [ 0x3E768F19E4302EF3, %merged.bb36 ], [ 0x3E46680C94743FD9, %merged.bb37 ]
  %merged.select121 = phi double [ 0x3E6129D961D79065, %merged.bb33 ], [ 0x3E107ECF99D6009A, %merged.bb34 ], [ 0x3D1ED0326F0CBDDC, %merged.bb36 ], [ 0x3CCE78F4A7F13C7D, %merged.bb37 ]
  %merged.select120 = phi double [ 0x3ED66AFC954DE682, %merged.bb33 ], [ 0x3E95BA568EDD3BFB, %merged.bb34 ], [ 0x3DD49301DA58AEFA, %merged.bb36 ], [ 0x3D9463E48A976F97, %merged.bb37 ]
  %merged.select119 = phi double [ 0x3DCCD7C812F40049, %merged.bb33 ], [ 0x3D6B7BD497A2CD17, %merged.bb34 ], [ 0x3C495387D39D2504, %merged.bb36 ], [ 0x3BE8FEBB5A4047D7, %merged.bb37 ]
  %merged.select118 = phi double [ 0xC013B000D66B8269, %merged.bb33 ], [ 0xC019A861C808DCFC, %merged.bb34 ], [ 0xC02A92BAF87A7B72, %merged.bb36 ], [ 0xC030CB31255FFA09, %merged.bb37 ]
  %merged.select117 = phi double [ 0xBFEFD66AE54A0BCB, %merged.bb33 ], [ 0xBFE46D859460DB51, %merged.bb34 ], [ 0xBFC4B5F131A679CC, %merged.bb36 ], [ 0xBFBA19EDB555D8AD, %merged.bb37 ]
  %merged.select116 = phi double [ 0xBFB3B5B6F694BB9E, %merged.bb33 ], [ 0xBF98ED20B1D6A6D8, %merged.bb34 ], [ 0xBF48C2CA21FD14A5, %merged.bb36 ], [ 0xBF2F1E266EB4C824, %merged.bb37 ]
  %merged.select115 = phi double [ 0xBF676495E4B7EAAA, %merged.bb33 ], [ 0xBF3D2E78945F9AC6, %merged.bb34 ], [ 0xBEBC6E261AE99633, %merged.bb36 ], [ 0xBE91D0F7FEBA5A35, %merged.bb37 ]
  %merged.select114 = phi double [ 0xBF0B3634004E0F5C, %merged.bb33 ], [ 0xBED0C1E92AD969EF, %merged.bb34 ], [ 0xBE2007A65CA14E38, %merged.bb36 ], [ 0xBDE40A018263D493, %merged.bb37 ]
  %merged.select113 = phi double [ 0x3E1390C28573DB0F, %merged.bb33 ], [ 0x3DB79116B58241AA, %merged.bb34 ], [ 0x3CA5D280D4B5A285, %merged.bb36 ], [ 0x3C4B275AC5F91B68, %merged.bb37 ]
  %merged.select112 = phi double [ 0xBE9C2F1FFD2FFECD, %merged.bb33 ], [ 0xBE512769C01EA7C5, %merged.bb34 ], [ 0xBD7021DF3392EE60, %merged.bb36 ], [ 0xBD241E51766A91FB, %merged.bb37 ]
  %merged.select111 = phi double [ 0x3D5866A3E6D0F156, %merged.bb33 ], [ 0x3CED1FCD2AD8841F, %merged.bb34 ], [ 0x3BAA9A26E0297ED8, %merged.bb36 ], [ 0x3B408480D3491A50, %merged.bb37 ]
  %merged.select107 = phi double [ %759, %merged.bb33 ], [ %759, %merged.bb34 ], [ %854, %merged.bb36 ], [ %854, %merged.bb37 ]
  %merged.select104.in = phi i32 [ %765, %merged.bb33 ], [ %765, %merged.bb34 ], [ %860, %merged.bb36 ], [ %860, %merged.bb37 ]
  %merged.select102 = phi double [ %849, %merged.bb33 ], [ %849, %merged.bb34 ], [ %944, %merged.bb36 ], [ %944, %merged.bb37 ]
  %merged.select101 = phi double [ %1034, %merged.bb33 ], [ %1041, %merged.bb34 ], [ %1048, %merged.bb36 ], [ %1055, %merged.bb37 ]
  %merged.select100 = phi double [ %1033, %merged.bb33 ], [ %1040, %merged.bb34 ], [ %1047, %merged.bb36 ], [ %1054, %merged.bb37 ]
  %1056 = phi i1 [ %cmp40.i.i.i.i, %merged.bb33 ], [ %cmp40.i.i.i.i, %merged.bb34 ], [ %cmp84.i.i.i.i, %merged.bb36 ], [ %cmp84.i.i.i.i, %merged.bb37 ]
  %merged.select104 = sitofp i32 %merged.select104.in to double
  br i1 %1056, label %merged.bb71, label %merged.bb72

merged.bb71:                                      ; preds = %merged.bb70
  %1057 = fadd double %merged.select100, %merged.select101
  %1058 = fadd double %merged.select102, %1057
  %1059 = fsub double %1058, %merged.select102
  %1060 = fsub double %1057, %1059
  %1061 = fadd double %1058, %merged.select104
  %1062 = fsub double %1061, %merged.select104
  %1063 = fsub double %1062, %1061
  %1064 = fadd double %1063, %merged.select104
  %1065 = fsub double %1058, %1062
  %1066 = fadd double %1065, %1064
  %1067 = fadd double %1060, %1066
  %1068 = fadd double %1061, %1067
  %1069 = tail call double @llvm.fabs.f64(double %merged.select107) #4
  %1070 = fcmp oeq double %1069, 0x7FF0000000000000
  %1071 = select i1 %1070, double %merged.select107, double %1068
  %1072 = fcmp olt double %merged.select107, 0.000000e+00
  %1073 = select i1 %1072, double 0x7FF8000000000000, double %1071
  %1074 = fcmp oeq double %merged.select107, 0.000000e+00
  %1075 = select i1 %1074, double 0xFFF0000000000000, double %1073
  %1076 = fmul double %1075, %1075
  %1077 = fmul double %1076, %merged.select86
  %1078 = fsub double %merged.select87, %1077
  %1079 = fmul double %1076, %merged.select88
  %1080 = fsub double %merged.select89, %1079
  %1081 = fmul double %1076, %1078
  %1082 = fmul double %1076, %1080
  %1083 = fadd double %1081, %merged.select90
  %1084 = fadd double %1082, %merged.select91
  %1085 = fmul double %1076, %1083
  %1086 = fmul double %1076, %1084
  %1087 = fadd double %1085, %merged.select92
  %1088 = fadd double %1086, %merged.select93
  %1089 = fmul double %1075, %1087
  %1090 = fsub double %1088, %1089
  %1091 = fmul double %1076, %merged.select94
  %1092 = fadd double %1091, %merged.select95
  %1093 = fmul double %1076, %merged.select96
  %1094 = fadd double %1093, %merged.select97
  %1095 = fmul double %1076, %1092
  %1096 = fmul double %1076, %1094
  %1097 = fadd double %1095, %merged.select98
  %1098 = fadd double %1096, %merged.select99
  %1099 = fmul double %1076, %1097
  %1100 = fadd double %1099, 1.000000e+00
  %1101 = fmul double %1075, %1098
  %1102 = fsub double %1100, %1101
  %1103 = fdiv double %1090, %1102
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

merged.bb72:                                      ; preds = %merged.bb70
  %1104 = fadd double %merged.select100, %merged.select101
  %1105 = fadd double %merged.select102, %1104
  %1106 = fsub double %1105, %merged.select102
  %1107 = fsub double %1104, %1106
  %1108 = fadd double %1105, %merged.select104
  %1109 = fsub double %1108, %merged.select104
  %1110 = fsub double %1109, %1108
  %1111 = fadd double %1110, %merged.select104
  %1112 = fsub double %1105, %1109
  %1113 = fadd double %1112, %1111
  %1114 = fadd double %1107, %1113
  %1115 = fadd double %1108, %1114
  %1116 = tail call double @llvm.fabs.f64(double %merged.select107) #4
  %1117 = fcmp oeq double %1116, 0x7FF0000000000000
  %1118 = select i1 %1117, double %merged.select107, double %1115
  %1119 = fcmp olt double %merged.select107, 0.000000e+00
  %1120 = select i1 %1119, double 0x7FF8000000000000, double %1118
  %1121 = fcmp oeq double %merged.select107, 0.000000e+00
  %1122 = select i1 %1121, double 0xFFF0000000000000, double %1120
  %1123 = fmul double %1122, %1122
  %1124 = fmul double %1123, %merged.select111
  %1125 = fsub double %merged.select112, %1124
  %1126 = fmul double %1123, %merged.select113
  %1127 = fsub double %merged.select114, %1126
  %1128 = fmul double %1123, %1125
  %1129 = fmul double %1123, %1127
  %1130 = fadd double %1128, %merged.select115
  %1131 = fadd double %1129, %merged.select116
  %1132 = fmul double %1123, %1130
  %1133 = fmul double %1123, %1131
  %1134 = fadd double %1132, %merged.select117
  %1135 = fadd double %1133, %merged.select118
  %1136 = fmul double %1122, %1134
  %1137 = fsub double %1135, %1136
  %1138 = fmul double %1123, %merged.select119
  %1139 = fadd double %1138, %merged.select120
  %1140 = fmul double %1123, %merged.select121
  %1141 = fadd double %1140, %merged.select122
  %1142 = fmul double %1123, %1139
  %1143 = fmul double %1123, %1141
  %1144 = fadd double %1142, %merged.select123
  %1145 = fadd double %1143, %merged.select124
  %1146 = fmul double %1123, %1144
  %1147 = fadd double %1146, 1.000000e+00
  %1148 = fmul double %1122, %1145
  %1149 = fsub double %1147, %1148
  %1150 = fdiv double %1137, %1149
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.frexp.exp.i32.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.frexp.mant.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i1 @llvm.amdgcn.class.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.ldexp.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rcp.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fma.v2f64(<2 x double>, <2 x double>, <2 x double>) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.abs.i32(i32, i1 immarg) #1

attributes #0 = { nofree norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="128" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }
attributes #4 = { nounwind readnone }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/charitha22/cgo22ae-darm-code.git e9bc0540325ad9806313d34e84fc901496fd8be6)"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i16 1, i16 1025}
!6 = !{}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = !{!"evaluate:%decision.dispatch6", !"evaluate:%if.else.i.i.i512.i.i.i.i"}
!13 = !{!"merge(evaluate:%decision.dispatch6,evaluate:%if.else.i.i.i512.i.i.i.i)"}
!14 = !{!"evaluate:%if.then20.i.i.i.i", !"evaluate:%decision.dispatch4", !"evaluate:%decision.dispatch"}
!15 = !{!"merge(evaluate:%if.then20.i.i.i.i,merge(evaluate:%decision.dispatch4,evaluate:%decision.dispatch))"}
!16 = !{!"evaluate:%decision.dispatch4", !"evaluate:%decision.dispatch"}
!17 = !{!"merge(evaluate:%decision.dispatch4,evaluate:%decision.dispatch)"}
