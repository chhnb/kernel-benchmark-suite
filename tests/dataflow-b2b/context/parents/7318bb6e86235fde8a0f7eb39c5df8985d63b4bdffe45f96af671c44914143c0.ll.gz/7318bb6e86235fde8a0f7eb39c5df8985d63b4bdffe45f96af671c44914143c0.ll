; ModuleID = '/data/home/chh/kernel-benchmark-suite-dataflow-b2b/build/dataflow-corpus/step7/MapAiry/anchor/trial-298/fused.ll'
source_filename = "/home/chh/kernel-benchmark-suite/cases/boost-mapairy/source/kernel.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

@_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 0x3FE428A2F98D728B, double 0x3FE965FEA53D6E3D, double 1.000000e+00, double 0x3FF428A2F98D728B, double 0x3FF965FEA53D6E3D], align 16

; Function Attrs: nofree norecurse nounwind
define protected amdgpu_kernel void @evaluate(double addrspace(1)* nocapture readonly %input.coerce, double addrspace(1)* nocapture %output.coerce, i32 %n) local_unnamed_addr #0 {
entry:
  %0 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %1 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %2 = getelementptr i8, i8 addrspace(4)* %1, i64 4
  %3 = bitcast i8 addrspace(4)* %2 to i16 addrspace(4)*
  %4 = load i16, i16 addrspace(4)* %3, align 4, !range !5, !invariant.load !6
  %5 = zext i16 %4 to i32
  %6 = mul i32 %0, %5
  %7 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !7
  %add = add i32 %6, %7
  %cmp = icmp slt i32 %add, %n
  br i1 %cmp, label %if.end8.i.i, label %if.end

if.end8.i.i:                                      ; preds = %entry
  %idxprom = sext i32 %add to i64
  %arrayidx11 = getelementptr inbounds double, double addrspace(1)* %input.coerce, i64 %idxprom
  %arrayidx.val = load double, double addrspace(1)* %arrayidx11, align 8, !tbaa !8
  %cmp.i3.i.i = fcmp olt double %arrayidx.val, 0.000000e+00
  %cmp1.i.i.i = fcmp ogt double %arrayidx.val, 1.000000e+00
  %or.cond.i.i.i = or i1 %cmp.i3.i.i, %cmp1.i.i.i
  br i1 %or.cond.i.i.i, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %lor.lhs.false2.i.i.i

lor.lhs.false2.i.i.i:                             ; preds = %if.end8.i.i
  %cmp.i.i.i.i.i = fcmp uno double %arrayidx.val, 0.000000e+00
  %cmp.i3.i.i.i.i = fcmp ogt double %arrayidx.val, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i4.i.i = fcmp olt double %arrayidx.val, 0xFFEFFFFFFFFFFFFF
  %lnot.i.i.i.i.not = or i1 %cmp.i3.i.i.i.i, %cmp1.i.i.i4.i.i
  %brmerge = or i1 %cmp.i.i.i.i.i, %lnot.i.i.i.i.not
  br i1 %brmerge, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %if.end14.i.i

if.end14.i.i:                                     ; preds = %lor.lhs.false2.i.i.i
  %cmp.i.i.i = fcmp ogt double %arrayidx.val, 5.000000e-01
  br i1 %cmp.i.i.i, label %if.then.i.i.i, label %cond.false7.i.i.i

if.then.i.i.i:                                    ; preds = %if.end14.i.i
  %sub.i.i.i = fsub double 1.000000e+00, %arrayidx.val
  %decision.interval4 = fcmp ult double %sub.i.i.i, 1.250000e-01
  br i1 %decision.interval4, label %if.else9.i.i.i.i, label %decision.dispatch3, !decision.condition_prefix !6

decision.dispatch3:                               ; preds = %if.then.i.i.i
  %cmp.i.i.i.i = fcmp ult double %sub.i.i.i, 2.500000e-01
  %8 = select i1 %cmp.i.i.i.i, double -1.250000e-01, double -2.500000e-01
  %9 = fadd double %sub.i.i.i, %8
  %10 = fmul double %9, %9
  %11 = fmul double %10, 0x409819CEF5B4E6C7
  %12 = fadd double %11, 0xC096FC492E087B38
  %13 = select i1 %cmp.i.i.i.i, double 0x4051B7FD7FEEB259, double 0x404567B47A5D8CA4
  %14 = fmul double %10, %13
  %15 = select i1 %cmp.i.i.i.i, double 0xC07E56261CB553E9, double 0x405E69E51891A050
  %16 = fsub double %15, %14
  %17 = fmul double %10, 0x4050AAC38C60A1E3
  %18 = fsub double 0x40548E4AE13E33D8, %17
  %19 = fmul double %10, %16
  %20 = select i1 %cmp.i.i.i.i, double %12, double %18
  %21 = fmul double %10, %20
  %.op = fadd double %19, 0xC04860792DC1D02E
  %22 = select i1 %cmp.i.i.i.i, double 0x4036AD73494335DA, double 0xC0407FAA65922A12
  %23 = fadd double %21, %22
  %24 = fmul double %10, %.op
  %.op1 = fadd double %19, 0x4034FFCB850049DF
  %25 = fmul double %10, %23
  %.op2 = fadd double %24, 0xC005F196AB7EF904
  %26 = select i1 %cmp.i.i.i.i, double 0x3FFB3E8B8B7EC8F9, double 0x3FDED118296B2018
  %27 = fadd double %25, %26
  %28 = select i1 %cmp.i.i.i.i, double %.op1, double %.op2
  %29 = fmul double %9, %28
  %30 = fadd double %27, %29
  br i1 %cmp.i.i.i.i, label %fusion.common11, label %fusion.side12

if.else9.i.i.i.i:                                 ; preds = %if.then.i.i.i
  %31 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %sub.i.i.i) #3
  %32 = add nsw i32 %31, -1
  %33 = fcmp uno double %sub.i.i.i, 0.000000e+00
  %34 = tail call double @llvm.fabs.f64(double %sub.i.i.i) #4
  %35 = fcmp oeq double %34, 0x7FF0000000000000
  %36 = or i1 %33, %35
  %37 = select i1 %36, i32 2147483647, i32 %32
  %38 = fcmp oeq double %sub.i.i.i, 0.000000e+00
  %39 = select i1 %38, i32 -2147483648, i32 %37
  %cmp11.i.i.i.i = icmp sgt i32 %39, -5
  br i1 %cmp11.i.i.i.i, label %if.then12.i.i.i.i, label %if.else21.i.i.i.i

if.then12.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %40 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 3) #3
  %41 = tail call double @llvm.amdgcn.frexp.mant.f64(double %40) #3
  %42 = fcmp olt double %41, 0x3FE5555555555555
  %43 = zext i1 %42 to i32
  %44 = tail call double @llvm.amdgcn.ldexp.f64(double %41, i32 %43) #3
  %45 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %40) #3
  %46 = sub nsw i32 %45, %43
  %47 = fadd double %44, -1.000000e+00
  %48 = fadd double %44, 1.000000e+00
  %49 = fsub double %48, %44
  %50 = fsub double %48, %49
  %51 = fsub double %44, %50
  %52 = fsub double 1.000000e+00, %49
  %53 = fadd double %52, %51
  %54 = tail call double @llvm.amdgcn.rcp.f64(double %48) #3
  %55 = fneg double %48
  %56 = tail call double @llvm.fma.f64(double %55, double %54, double 1.000000e+00) #3
  %57 = tail call double @llvm.fma.f64(double %56, double %54, double %54) #3
  %58 = tail call double @llvm.fma.f64(double %55, double %57, double 1.000000e+00) #3
  %59 = tail call double @llvm.fma.f64(double %58, double %57, double %57) #3
  %60 = fmul double %47, %59
  %61 = fmul double %48, %60
  %62 = fneg double %61
  %63 = tail call double @llvm.fma.f64(double %60, double %48, double %62) #3
  %64 = tail call double @llvm.fma.f64(double %60, double %53, double %63) #3
  %65 = fadd double %61, %64
  %66 = fsub double %65, %61
  %67 = fsub double %64, %66
  %68 = fsub double %47, %65
  %69 = fsub double %47, %68
  %70 = fsub double %69, %65
  %71 = fsub double %70, %67
  %72 = fadd double %68, %71
  %73 = fmul double %59, %72
  %74 = fadd double %60, %73
  %75 = fsub double %74, %60
  %76 = fsub double %73, %75
  %77 = fmul double %74, %74
  %78 = fneg double %77
  %79 = tail call double @llvm.fma.f64(double %74, double %74, double %78) #3
  %80 = fmul double %76, 2.000000e+00
  %81 = tail call double @llvm.fma.f64(double %74, double %80, double %79) #3
  %82 = tail call double @llvm.fma.f64(double %76, double %76, double %81) #3
  %83 = fadd double %77, %82
  %84 = fsub double %83, %77
  %85 = fsub double %82, %84
  %86 = tail call double @llvm.fma.f64(double %83, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %87 = tail call double @llvm.fma.f64(double %83, double %86, double 0x3FC7474DD7F4DF2E) #3
  %88 = tail call double @llvm.fma.f64(double %83, double %87, double 0x3FCC71C016291751) #3
  %89 = tail call double @llvm.fma.f64(double %83, double %88, double 0x3FD249249B27ACF1) #3
  %90 = tail call double @llvm.fma.f64(double %83, double %89, double 0x3FD99999998EF7B6) #3
  %91 = tail call double @llvm.fma.f64(double %83, double %90, double 0x3FE5555555555780) #3
  %92 = tail call double @llvm.amdgcn.ldexp.f64(double %74, i32 1) #3
  %93 = tail call double @llvm.amdgcn.ldexp.f64(double %76, i32 1) #3
  %94 = fmul double %74, %83
  %95 = fneg double %94
  %96 = tail call double @llvm.fma.f64(double %74, double %83, double %95) #3
  %97 = fmul double %76, %83
  %98 = tail call double @llvm.fma.f64(double %74, double %85, double %97) #3
  %99 = fadd double %96, %98
  %100 = fadd double %94, %99
  %101 = fsub double %100, %94
  %102 = fsub double %99, %101
  %103 = fmul double %100, %91
  %104 = fneg double %103
  %105 = tail call double @llvm.fma.f64(double %100, double %91, double %104) #3
  %106 = tail call double @llvm.fma.f64(double %102, double %91, double %105) #3
  %107 = fadd double %103, %106
  %108 = fsub double %107, %103
  %109 = fsub double %106, %108
  %110 = fadd double %92, %107
  %111 = fsub double %110, %92
  %112 = fsub double %110, %111
  %113 = fsub double %92, %112
  %114 = fsub double %107, %111
  %115 = fadd double %114, %113
  %116 = fadd double %93, %109
  %117 = fsub double %116, %93
  %118 = fsub double %116, %117
  %119 = fsub double %93, %118
  %120 = fsub double %109, %117
  %121 = fadd double %120, %119
  %122 = fadd double %116, %115
  %123 = fadd double %110, %122
  %124 = fsub double %123, %110
  %125 = fsub double %122, %124
  %126 = fadd double %121, %125
  %127 = fadd double %123, %126
  %128 = fsub double %127, %123
  %129 = fsub double %126, %128
  %130 = sitofp i32 %46 to double
  %131 = fmul double %127, 0x3FF71547652B82FE
  %132 = fneg double %131
  %133 = fmul double %127, 0x3C7777D0FFDA0D24
  %134 = insertelement <2 x double> undef, double %127, i32 0
  %135 = insertelement <2 x double> %134, double %129, i32 1
  %136 = insertelement <2 x double> undef, double %132, i32 0
  %137 = insertelement <2 x double> %136, double %133, i32 1
  %138 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %135, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %137) #3
  %139 = extractelement <2 x double> %138, i32 0
  %140 = extractelement <2 x double> %138, i32 1
  %141 = fadd double %139, %140
  %142 = fadd double %131, %141
  %143 = fsub double %142, %131
  %144 = fsub double %141, %143
  %145 = fadd double %142, %130
  %146 = fsub double %145, %130
  %147 = fsub double %146, %145
  %148 = fadd double %147, %130
  %149 = fsub double %142, %146
  %150 = fadd double %149, %148
  %151 = fadd double %144, %150
  %152 = fadd double %145, %151
  %153 = tail call double @llvm.fabs.f64(double %40) #4
  %154 = fcmp oeq double %153, 0x7FF0000000000000
  %155 = select i1 %154, double %40, double %152
  %156 = fcmp olt double %40, 0.000000e+00
  %157 = select i1 %156, double 0x7FF8000000000000, double %155
  %158 = fcmp oeq double %40, 0.000000e+00
  %159 = select i1 %158, double 0xFFF0000000000000, double %157
  %mul.i.i682.i.i.i.i = fmul double %159, %159
  %mul1.i.i683.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3ED3E1F985CBB733
  %add.i.i684.i.i.i.i = fadd double %mul1.i.i683.i.i.i.i, 0x3F385DA443F57737
  %mul5.i.i685.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F24E9382EAABDBB
  %add7.i.i686.i.i.i.i = fadd double %mul5.i.i685.i.i.i.i, 0x3F77E2A342AA4E3B
  %mul10.i.i687.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i684.i.i.i.i
  %mul12.i.i688.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i686.i.i.i.i
  %add15.i.i689.i.i.i.i = fadd double %mul10.i.i687.i.i.i.i, 0x3F9808F2B640E69B
  %add18.i.i690.i.i.i.i = fadd double %mul12.i.i688.i.i.i.i, 0x3F9DD5C523A6CF6D
  %mul20.i.i691.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i689.i.i.i.i
  %mul22.i.i692.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i690.i.i.i.i
  %add25.i.i693.i.i.i.i = fadd double %mul20.i.i691.i.i.i.i, 0x3FD3E6D375851610
  %add28.i.i694.i.i.i.i = fadd double %mul22.i.i692.i.i.i.i, 0x3FDB3E8B8B7EC8FA
  %160 = fmul double %159, %add25.i.i693.i.i.i.i
  %add33.i.i696.i.i.i.i = fsub double %add28.i.i694.i.i.i.i, %160
  %mul1.i.i668.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3EF03AD80F271435
  %add.i.i669.i.i.i.i = fadd double %mul1.i.i668.i.i.i.i, 0x3F577B23357A1929
  %mul5.i.i670.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F27C5B13F4BAFF2
  %add7.i.i671.i.i.i.i = fadd double %mul5.i.i670.i.i.i.i, 0x3F825620F70E4E86
  %mul10.i.i672.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i669.i.i.i.i
  %mul12.i.i673.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i671.i.i.i.i
  %add15.i.i674.i.i.i.i = fadd double %mul10.i.i672.i.i.i.i, 0x3FA38976FFA62DF3
  %add18.i.i675.i.i.i.i = fadd double %mul12.i.i673.i.i.i.i, 0x3FBACD3553111974
  %mul20.i.i676.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i674.i.i.i.i
  %mul22.i.i677.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i675.i.i.i.i
  %add25.i.i678.i.i.i.i = fadd double %mul20.i.i676.i.i.i.i, 0x3FDA8C1A7A09CF75
  %add28.i.i679.i.i.i.i = fadd double %mul22.i.i677.i.i.i.i, 1.000000e+00
  %161 = fmul double %159, %add25.i.i678.i.i.i.i
  %add33.i.i681.i.i.i.i = fsub double %add28.i.i679.i.i.i.i, %161
  %mul.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i590.i.i.i.i = fcmp ogt double %mul.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i591.i.i.i.i = fcmp oeq double %mul.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i592.i.i.i.i = or i1 %cmp.i.i.i.i590.i.i.i.i, %cmp.i.i.i591.i.i.i.i
  br i1 %or.cond.i.i.i592.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end.i.i.i594.i.i.i.i

if.end.i.i.i594.i.i.i.i:                          ; preds = %if.then12.i.i.i.i
  %cmp.i.i.i.i.i593.i.i.i.i = fcmp uno double %mul.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i593.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end7.i.i.i620.i.i.i.i

if.end7.i.i.i620.i.i.i.i:                         ; preds = %if.end.i.i.i594.i.i.i.i
  %162 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul.i.i.i.i) #3
  %163 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul.i.i.i.i) #3
  %164 = tail call i1 @llvm.amdgcn.class.f64(double %mul.i.i.i.i, i32 519) #3
  %165 = select i1 %164, i32 0, i32 %162
  %166 = select i1 %164, double %mul.i.i.i.i, double %163
  %mul.i.i.i.i.i606.i.i.i.i = fmul double %166, %166
  %mul1.i.i.i.i.i607.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i608.i.i.i.i = fadd double %mul1.i.i.i.i.i607.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i609.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FE479D17050CA47
  %167 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i609.i.i.i.i
  %mul10.i.i.i.i.i611.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %add.i.i.i.i.i608.i.i.i.i
  %mul12.i.i.i.i.i612.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %167
  %add15.i.i.i.i.i613.i.i.i.i = fadd double %mul10.i.i.i.i.i611.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i614.i.i.i.i = fadd double %mul12.i.i.i.i.i612.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i615.i.i.i.i = fmul double %166, %add15.i.i.i.i.i613.i.i.i.i
  %add23.i.i.i.i.i616.i.i.i.i = fadd double %add18.i.i.i.i.i614.i.i.i.i, %mul20.i.i.i.i.i615.i.i.i.i
  %.frozen = freeze i32 %165
  %div.i.i.i617.i.i.i.i = sdiv i32 %.frozen, 3
  %168 = call i32 @llvm.abs.i32(i32 %div.i.i.i617.i.i.i.i, i1 true)
  %cmp11.i.i.i619.i.i.i.i = icmp ugt i32 %168, 63
  %cmp13.i.i.i621.i.i.i.i = icmp sgt i32 %165, 2
  %decision.take = or i1 %cmp11.i.i.i619.i.i.i.i, %cmp13.i.i.i621.i.i.i.i
  %169 = sub nsw i32 0, %div.i.i.i617.i.i.i.i
  %fusion.paired.v = select i1 %decision.take, i32 %div.i.i.i617.i.i.i.i, i32 %169
  %fusion.paired = zext i32 %fusion.paired.v to i64
  %170 = shl nuw i64 1, %fusion.paired
  %171 = uitofp i64 %170 to double
  br i1 %decision.take, label %fusion.side4, label %fusion.side5

fusion.side4:                                     ; preds = %if.end7.i.i.i620.i.i.i.i
  %172 = fmul double %add23.i.i.i.i.i616.i.i.i.i, %171
  %173 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i616.i.i.i.i, i32 %div.i.i.i617.i.i.i.i) #3
  %174 = select i1 %cmp11.i.i.i619.i.i.i.i, double %173, double %172
  br label %if.end23.i.i.i640.i.i.i.i

fusion.side5:                                     ; preds = %if.end7.i.i.i620.i.i.i.i
  %175 = fdiv double %add23.i.i.i.i.i616.i.i.i.i, %171
  br label %if.end23.i.i.i640.i.i.i.i

if.end23.i.i.i640.i.i.i.i:                        ; preds = %fusion.side5, %fusion.side4
  %guess.i.i.i589.i.i.i.i.0 = phi double [ %174, %fusion.side4 ], [ %175, %fusion.side5 ]
  %.neg6 = mul nsw i32 %div.i.i.i617.i.i.i.i, -3
  %rem.i.i.i635.i.i.i.i.decomposed = add i32 %.frozen, 2
  %add.i.i.i636.i.i.i.i = add i32 %rem.i.i.i635.i.i.i.i.decomposed, %.neg6
  %176 = zext i32 %add.i.i.i636.i.i.i.i to i64
  %arrayidx1.i.i.i637.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %176
  %177 = load double, double addrspace(4)* %arrayidx1.i.i.i637.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i638.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.0, %177
  %cmp26.i.i.i639.i.i.i.i = icmp slt i32 %165, 1021
  br i1 %cmp26.i.i.i639.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i

do.body.i.i.i651.i.i.i.i:                         ; preds = %do.body.i.i.i651.i.i.i.i, %if.end23.i.i.i640.i.i.i.i
  %guess.i.i.i589.i.i.i.i.1 = phi double [ %mul24.i.i.i638.i.i.i.i, %if.end23.i.i.i640.i.i.i.i ], [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ]
  %mul28.i.i.i641.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %guess.i.i.i589.i.i.i.i.1
  %mul29.i.i.i642.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %mul28.i.i.i641.i.i.i.i
  %add30.i.i.i643.i.i.i.i = fadd double %mul.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add31.i.i.i644.i.i.i.i = fadd double %mul.i.i.i.i, %add30.i.i.i643.i.i.i.i
  %add32.i.i.i645.i.i.i.i = fadd double %mul29.i.i.i642.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add33.i.i.i646.i.i.i.i = fadd double %mul.i.i.i.i, %add32.i.i.i645.i.i.i.i
  %div34.i.i.i647.i.i.i.i = fdiv double %add31.i.i.i644.i.i.i.i, %add33.i.i.i646.i.i.i.i
  %mul35.i.i.i648.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %div34.i.i.i647.i.i.i.i
  %sub36.i.i.i649.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i647.i.i.i.i
  %178 = tail call double @llvm.fabs.f64(double %sub36.i.i.i649.i.i.i.i) #3
  %cmp38.i.i.i650.i.i.i.i = fcmp ogt double %178, 0x3EC0000000000000
  br i1 %cmp38.i.i.i650.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

do.body40.i.i.i662.i.i.i.i:                       ; preds = %do.body40.i.i.i662.i.i.i.i, %if.end23.i.i.i640.i.i.i.i
  %guess.i.i.i589.i.i.i.i.2 = phi double [ %mul24.i.i.i638.i.i.i.i, %if.end23.i.i.i640.i.i.i.i ], [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ]
  %mul41.i.i.i652.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, %guess.i.i.i589.i.i.i.i.2
  %div42.i.i.i653.i.i.i.i = fdiv double %mul.i.i.i.i, %guess.i.i.i589.i.i.i.i.2
  %sub43.i.i.i654.i.i.i.i = fsub double %mul41.i.i.i652.i.i.i.i, %div42.i.i.i653.i.i.i.i
  %mul44.i.i.i655.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i656.i.i.i.i = fdiv double %mul.i.i.i.i, %mul41.i.i.i652.i.i.i.i
  %add46.i.i.i657.i.i.i.i = fadd double %mul44.i.i.i655.i.i.i.i, %div45.i.i.i656.i.i.i.i
  %div47.i.i.i658.i.i.i.i = fdiv double %sub43.i.i.i654.i.i.i.i, %add46.i.i.i657.i.i.i.i
  %sub48.i.i.i659.i.i.i.i = fsub double %guess.i.i.i589.i.i.i.i.2, %div47.i.i.i658.i.i.i.i
  %mul50.i.i.i660.i.i.i.i = fmul double %sub48.i.i.i659.i.i.i.i, 0x3EC0000000000000
  %179 = tail call double @llvm.fabs.f64(double %div47.i.i.i658.i.i.i.i) #3
  %cmp52.i.i.i661.i.i.i.i = fcmp olt double %mul50.i.i.i660.i.i.i.i, %179
  br i1 %cmp52.i.i.i661.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i: ; preds = %do.body40.i.i.i662.i.i.i.i, %do.body.i.i.i651.i.i.i.i, %if.end.i.i.i594.i.i.i.i, %if.then12.i.i.i.i
  %retval.0.i.i.i665.i.i.i.i = phi double [ %mul.i.i.i.i, %if.then12.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i594.i.i.i.i ], [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ], [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ]
  %mul19.i.i.i.i = fmul double %add33.i.i681.i.i.i.i, %retval.0.i.i.i665.i.i.i.i
  %div20.i.i.i.i = fdiv double %add33.i.i696.i.i.i.i, %mul19.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else21.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %cmp23.i.i.i.i = icmp sgt i32 %39, -9
  br i1 %cmp23.i.i.i.i, label %if.then24.i.i.i.i, label %if.else35.i.i.i.i

if.then24.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %180 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 4) #3
  %181 = tail call double @llvm.amdgcn.frexp.mant.f64(double %180) #3
  %182 = fcmp olt double %181, 0x3FE5555555555555
  %183 = zext i1 %182 to i32
  %184 = tail call double @llvm.amdgcn.ldexp.f64(double %181, i32 %183) #3
  %185 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %180) #3
  %186 = sub nsw i32 %185, %183
  %187 = fadd double %184, -1.000000e+00
  %188 = fadd double %184, 1.000000e+00
  %189 = fsub double %188, %184
  %190 = fsub double %188, %189
  %191 = fsub double %184, %190
  %192 = fsub double 1.000000e+00, %189
  %193 = fadd double %192, %191
  %194 = tail call double @llvm.amdgcn.rcp.f64(double %188) #3
  %195 = fneg double %188
  %196 = tail call double @llvm.fma.f64(double %195, double %194, double 1.000000e+00) #3
  %197 = tail call double @llvm.fma.f64(double %196, double %194, double %194) #3
  %198 = tail call double @llvm.fma.f64(double %195, double %197, double 1.000000e+00) #3
  %199 = tail call double @llvm.fma.f64(double %198, double %197, double %197) #3
  %200 = fmul double %187, %199
  %201 = fmul double %188, %200
  %202 = fneg double %201
  %203 = tail call double @llvm.fma.f64(double %200, double %188, double %202) #3
  %204 = tail call double @llvm.fma.f64(double %200, double %193, double %203) #3
  %205 = fadd double %201, %204
  %206 = fsub double %205, %201
  %207 = fsub double %204, %206
  %208 = fsub double %187, %205
  %209 = fsub double %187, %208
  %210 = fsub double %209, %205
  %211 = fsub double %210, %207
  %212 = fadd double %208, %211
  %213 = fmul double %199, %212
  %214 = fadd double %200, %213
  %215 = fsub double %214, %200
  %216 = fsub double %213, %215
  %217 = fmul double %214, %214
  %218 = fneg double %217
  %219 = tail call double @llvm.fma.f64(double %214, double %214, double %218) #3
  %220 = fmul double %216, 2.000000e+00
  %221 = tail call double @llvm.fma.f64(double %214, double %220, double %219) #3
  %222 = tail call double @llvm.fma.f64(double %216, double %216, double %221) #3
  %223 = fadd double %217, %222
  %224 = fsub double %223, %217
  %225 = fsub double %222, %224
  %226 = tail call double @llvm.fma.f64(double %223, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %227 = tail call double @llvm.fma.f64(double %223, double %226, double 0x3FC7474DD7F4DF2E) #3
  %228 = tail call double @llvm.fma.f64(double %223, double %227, double 0x3FCC71C016291751) #3
  %229 = tail call double @llvm.fma.f64(double %223, double %228, double 0x3FD249249B27ACF1) #3
  %230 = tail call double @llvm.fma.f64(double %223, double %229, double 0x3FD99999998EF7B6) #3
  %231 = tail call double @llvm.fma.f64(double %223, double %230, double 0x3FE5555555555780) #3
  %232 = tail call double @llvm.amdgcn.ldexp.f64(double %214, i32 1) #3
  %233 = tail call double @llvm.amdgcn.ldexp.f64(double %216, i32 1) #3
  %234 = fmul double %214, %223
  %235 = fneg double %234
  %236 = tail call double @llvm.fma.f64(double %214, double %223, double %235) #3
  %237 = fmul double %216, %223
  %238 = tail call double @llvm.fma.f64(double %214, double %225, double %237) #3
  %239 = fadd double %236, %238
  %240 = fadd double %234, %239
  %241 = fsub double %240, %234
  %242 = fsub double %239, %241
  %243 = fmul double %240, %231
  %244 = fneg double %243
  %245 = tail call double @llvm.fma.f64(double %240, double %231, double %244) #3
  %246 = tail call double @llvm.fma.f64(double %242, double %231, double %245) #3
  %247 = fadd double %243, %246
  %248 = fsub double %247, %243
  %249 = fsub double %246, %248
  %250 = fadd double %232, %247
  %251 = fsub double %250, %232
  %252 = fsub double %250, %251
  %253 = fsub double %232, %252
  %254 = fsub double %247, %251
  %255 = fadd double %254, %253
  %256 = fadd double %233, %249
  %257 = fsub double %256, %233
  %258 = fsub double %256, %257
  %259 = fsub double %233, %258
  %260 = fsub double %249, %257
  %261 = fadd double %260, %259
  %262 = fadd double %256, %255
  %263 = fadd double %250, %262
  %264 = fsub double %263, %250
  %265 = fsub double %262, %264
  %266 = fadd double %261, %265
  %267 = fadd double %263, %266
  %268 = fsub double %267, %263
  %269 = fsub double %266, %268
  %270 = sitofp i32 %186 to double
  %271 = fmul double %267, 0x3FF71547652B82FE
  %272 = fneg double %271
  %273 = fmul double %267, 0x3C7777D0FFDA0D24
  %274 = insertelement <2 x double> undef, double %267, i32 0
  %275 = insertelement <2 x double> %274, double %269, i32 1
  %276 = insertelement <2 x double> undef, double %272, i32 0
  %277 = insertelement <2 x double> %276, double %273, i32 1
  %278 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %275, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %277) #3
  %279 = extractelement <2 x double> %278, i32 0
  %280 = extractelement <2 x double> %278, i32 1
  %281 = fadd double %279, %280
  %282 = fadd double %271, %281
  %283 = fsub double %282, %271
  %284 = fsub double %281, %283
  %285 = fadd double %282, %270
  %286 = fsub double %285, %270
  %287 = fsub double %286, %285
  %288 = fadd double %287, %270
  %289 = fsub double %282, %286
  %290 = fadd double %289, %288
  %291 = fadd double %284, %290
  %292 = fadd double %285, %291
  %293 = tail call double @llvm.fabs.f64(double %180) #4
  %294 = fcmp oeq double %293, 0x7FF0000000000000
  %295 = select i1 %294, double %180, double %292
  %296 = fcmp olt double %180, 0.000000e+00
  %297 = select i1 %296, double 0x7FF8000000000000, double %295
  %298 = fcmp oeq double %180, 0.000000e+00
  %299 = select i1 %298, double 0xFFF0000000000000, double %297
  %mul.i.i565.i.i.i.i = fmul double %299, %299
  %mul1.i.i566.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3E919A5BE1262808
  %add.i.i567.i.i.i.i = fadd double %mul1.i.i566.i.i.i.i, 0x3F07A5175B4661FC
  %mul5.i.i568.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3ED3058F91E15D9E
  %add7.i.i569.i.i.i.i = fadd double %mul5.i.i568.i.i.i.i, 0x3F360A6A52B6CEE1
  %mul10.i.i570.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i567.i.i.i.i
  %mul12.i.i571.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i569.i.i.i.i
  %add15.i.i572.i.i.i.i = fadd double %mul10.i.i570.i.i.i.i, 0x3F5C5B8FA36BAEC3
  %add18.i.i573.i.i.i.i = fadd double %mul12.i.i571.i.i.i.i, 0x3F80EDCAE3A5BFEE
  %mul20.i.i574.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i572.i.i.i.i
  %mul22.i.i575.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i573.i.i.i.i
  %add25.i.i576.i.i.i.i = fadd double %mul20.i.i574.i.i.i.i, 0x3F9A5E78F653B833
  %add28.i.i577.i.i.i.i = fadd double %mul22.i.i575.i.i.i.i, 0x3FB5AC2080A26513
  %mul30.i.i578.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i576.i.i.i.i
  %mul32.i.i579.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i577.i.i.i.i
  %add35.i.i580.i.i.i.i = fadd double %mul30.i.i578.i.i.i.i, 0x3FC65686F7A4EE22
  %add38.i.i581.i.i.i.i = fadd double %mul32.i.i579.i.i.i.i, 0x3FD3F40EF6582604
  %mul40.i.i582.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i580.i.i.i.i
  %add43.i.i583.i.i.i.i = fadd double %mul40.i.i582.i.i.i.i, 0x3FE03C236600AD0B
  %300 = fmul double %299, %add38.i.i581.i.i.i.i
  %add48.i.i585.i.i.i.i = fsub double %add43.i.i583.i.i.i.i, %300
  %mul1.i.i547.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EA0457562E8B20F
  %add.i.i548.i.i.i.i = fadd double %mul1.i.i547.i.i.i.i, 0x3F16154BBE28AEB9
  %mul5.i.i549.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EE174949F46ED05
  %add7.i.i550.i.i.i.i = fadd double %mul5.i.i549.i.i.i.i, 0x3F43E3B25F7FFBED
  %mul10.i.i551.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i548.i.i.i.i
  %mul12.i.i552.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i550.i.i.i.i
  %add15.i.i553.i.i.i.i = fadd double %mul10.i.i551.i.i.i.i, 0x3F6B2284D418EE28
  %add18.i.i554.i.i.i.i = fadd double %mul12.i.i552.i.i.i.i, 0x3F8DC663E91E38DD
  %mul20.i.i555.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i553.i.i.i.i
  %mul22.i.i556.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i554.i.i.i.i
  %add25.i.i557.i.i.i.i = fadd double %mul20.i.i555.i.i.i.i, 0x3FA9F261B3019817
  %add28.i.i558.i.i.i.i = fadd double %mul22.i.i556.i.i.i.i, 0x3FC29CC24A62017B
  %mul30.i.i559.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i557.i.i.i.i
  %mul32.i.i560.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i558.i.i.i.i
  %add35.i.i561.i.i.i.i = fadd double %mul30.i.i559.i.i.i.i, 0x3FD660DD0F65AD11
  %add38.i.i562.i.i.i.i = fadd double %mul32.i.i560.i.i.i.i, 0x3FE0E738E979F959
  %mul40.i.i563.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i561.i.i.i.i
  %add43.i.i564.i.i.i.i = fadd double %mul40.i.i563.i.i.i.i, 1.000000e+00
  %301 = fmul double %299, %add38.i.i562.i.i.i.i
  %add48.i.i.i.i.i.i = fsub double %add43.i.i564.i.i.i.i, %301
  %mul31.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i469.i.i.i.i = fcmp ogt double %mul31.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i470.i.i.i.i = fcmp oeq double %mul31.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i471.i.i.i.i = or i1 %cmp.i.i.i.i469.i.i.i.i, %cmp.i.i.i470.i.i.i.i
  br i1 %or.cond.i.i.i471.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end.i.i.i473.i.i.i.i

if.end.i.i.i473.i.i.i.i:                          ; preds = %if.then24.i.i.i.i
  %cmp.i.i.i.i.i472.i.i.i.i = fcmp uno double %mul31.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i472.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end7.i.i.i499.i.i.i.i

if.end7.i.i.i499.i.i.i.i:                         ; preds = %if.end.i.i.i473.i.i.i.i
  %302 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul31.i.i.i.i) #3
  %303 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul31.i.i.i.i) #3
  %304 = tail call i1 @llvm.amdgcn.class.f64(double %mul31.i.i.i.i, i32 519) #3
  %305 = select i1 %304, i32 0, i32 %302
  %306 = select i1 %304, double %mul31.i.i.i.i, double %303
  %mul.i.i.i.i.i485.i.i.i.i = fmul double %306, %306
  %mul1.i.i.i.i.i486.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i487.i.i.i.i = fadd double %mul1.i.i.i.i.i486.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i488.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FE479D17050CA47
  %307 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i488.i.i.i.i
  %mul10.i.i.i.i.i490.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %add.i.i.i.i.i487.i.i.i.i
  %mul12.i.i.i.i.i491.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %307
  %add15.i.i.i.i.i492.i.i.i.i = fadd double %mul10.i.i.i.i.i490.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i493.i.i.i.i = fadd double %mul12.i.i.i.i.i491.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i494.i.i.i.i = fmul double %306, %add15.i.i.i.i.i492.i.i.i.i
  %add23.i.i.i.i.i495.i.i.i.i = fadd double %add18.i.i.i.i.i493.i.i.i.i, %mul20.i.i.i.i.i494.i.i.i.i
  %.frozen209 = freeze i32 %305
  %div.i.i.i496.i.i.i.i = sdiv i32 %.frozen209, 3
  %308 = call i32 @llvm.abs.i32(i32 %div.i.i.i496.i.i.i.i, i1 true)
  %cmp11.i.i.i498.i.i.i.i = icmp ugt i32 %308, 63
  %cmp13.i.i.i500.i.i.i.i = icmp sgt i32 %305, 2
  %decision.take1 = or i1 %cmp11.i.i.i498.i.i.i.i, %cmp13.i.i.i500.i.i.i.i
  %309 = sub nsw i32 0, %div.i.i.i496.i.i.i.i
  %fusion.paired2.v = select i1 %decision.take1, i32 %div.i.i.i496.i.i.i.i, i32 %309
  %fusion.paired2 = zext i32 %fusion.paired2.v to i64
  %310 = shl nuw i64 1, %fusion.paired2
  %311 = uitofp i64 %310 to double
  br i1 %decision.take1, label %fusion.side6, label %fusion.side7

fusion.side6:                                     ; preds = %if.end7.i.i.i499.i.i.i.i
  %312 = fmul double %add23.i.i.i.i.i495.i.i.i.i, %311
  %313 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i495.i.i.i.i, i32 %div.i.i.i496.i.i.i.i) #3
  %314 = select i1 %cmp11.i.i.i498.i.i.i.i, double %313, double %312
  br label %if.end23.i.i.i519.i.i.i.i

fusion.side7:                                     ; preds = %if.end7.i.i.i499.i.i.i.i
  %315 = fdiv double %add23.i.i.i.i.i495.i.i.i.i, %311
  br label %if.end23.i.i.i519.i.i.i.i

if.end23.i.i.i519.i.i.i.i:                        ; preds = %fusion.side7, %fusion.side6
  %guess.i.i.i468.i.i.i.i.0 = phi double [ %314, %fusion.side6 ], [ %315, %fusion.side7 ]
  %.neg5 = mul nsw i32 %div.i.i.i496.i.i.i.i, -3
  %rem.i.i.i514.i.i.i.i.decomposed = add i32 %.frozen209, 2
  %add.i.i.i515.i.i.i.i = add i32 %rem.i.i.i514.i.i.i.i.decomposed, %.neg5
  %316 = zext i32 %add.i.i.i515.i.i.i.i to i64
  %arrayidx1.i.i.i516.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %316
  %317 = load double, double addrspace(4)* %arrayidx1.i.i.i516.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i517.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.0, %317
  %cmp26.i.i.i518.i.i.i.i = icmp slt i32 %305, 1021
  br i1 %cmp26.i.i.i518.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i

do.body.i.i.i530.i.i.i.i:                         ; preds = %do.body.i.i.i530.i.i.i.i, %if.end23.i.i.i519.i.i.i.i
  %guess.i.i.i468.i.i.i.i.1 = phi double [ %mul24.i.i.i517.i.i.i.i, %if.end23.i.i.i519.i.i.i.i ], [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ]
  %mul28.i.i.i520.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %guess.i.i.i468.i.i.i.i.1
  %mul29.i.i.i521.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %mul28.i.i.i520.i.i.i.i
  %add30.i.i.i522.i.i.i.i = fadd double %mul31.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add31.i.i.i523.i.i.i.i = fadd double %mul31.i.i.i.i, %add30.i.i.i522.i.i.i.i
  %add32.i.i.i524.i.i.i.i = fadd double %mul29.i.i.i521.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add33.i.i.i525.i.i.i.i = fadd double %mul31.i.i.i.i, %add32.i.i.i524.i.i.i.i
  %div34.i.i.i526.i.i.i.i = fdiv double %add31.i.i.i523.i.i.i.i, %add33.i.i.i525.i.i.i.i
  %mul35.i.i.i527.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %div34.i.i.i526.i.i.i.i
  %sub36.i.i.i528.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i526.i.i.i.i
  %318 = tail call double @llvm.fabs.f64(double %sub36.i.i.i528.i.i.i.i) #3
  %cmp38.i.i.i529.i.i.i.i = fcmp ogt double %318, 0x3EC0000000000000
  br i1 %cmp38.i.i.i529.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

do.body40.i.i.i541.i.i.i.i:                       ; preds = %do.body40.i.i.i541.i.i.i.i, %if.end23.i.i.i519.i.i.i.i
  %guess.i.i.i468.i.i.i.i.2 = phi double [ %mul24.i.i.i517.i.i.i.i, %if.end23.i.i.i519.i.i.i.i ], [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ]
  %mul41.i.i.i531.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, %guess.i.i.i468.i.i.i.i.2
  %div42.i.i.i532.i.i.i.i = fdiv double %mul31.i.i.i.i, %guess.i.i.i468.i.i.i.i.2
  %sub43.i.i.i533.i.i.i.i = fsub double %mul41.i.i.i531.i.i.i.i, %div42.i.i.i532.i.i.i.i
  %mul44.i.i.i534.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i535.i.i.i.i = fdiv double %mul31.i.i.i.i, %mul41.i.i.i531.i.i.i.i
  %add46.i.i.i536.i.i.i.i = fadd double %mul44.i.i.i534.i.i.i.i, %div45.i.i.i535.i.i.i.i
  %div47.i.i.i537.i.i.i.i = fdiv double %sub43.i.i.i533.i.i.i.i, %add46.i.i.i536.i.i.i.i
  %sub48.i.i.i538.i.i.i.i = fsub double %guess.i.i.i468.i.i.i.i.2, %div47.i.i.i537.i.i.i.i
  %mul50.i.i.i539.i.i.i.i = fmul double %sub48.i.i.i538.i.i.i.i, 0x3EC0000000000000
  %319 = tail call double @llvm.fabs.f64(double %div47.i.i.i537.i.i.i.i) #3
  %cmp52.i.i.i540.i.i.i.i = fcmp olt double %mul50.i.i.i539.i.i.i.i, %319
  br i1 %cmp52.i.i.i540.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i: ; preds = %do.body40.i.i.i541.i.i.i.i, %do.body.i.i.i530.i.i.i.i, %if.end.i.i.i473.i.i.i.i, %if.then24.i.i.i.i
  %retval.0.i.i.i544.i.i.i.i = phi double [ %mul31.i.i.i.i, %if.then24.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i473.i.i.i.i ], [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ], [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ]
  %mul33.i.i.i.i = fmul double %add48.i.i.i.i.i.i, %retval.0.i.i.i544.i.i.i.i
  %div34.i.i.i.i = fdiv double %add48.i.i585.i.i.i.i, %mul33.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else35.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %cmp37.i.i.i.i = icmp sgt i32 %39, -17
  br i1 %cmp37.i.i.i.i, label %if.then38.i.i.i.i, label %if.else49.i.i.i.i

if.then38.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %320 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 8) #3
  %321 = tail call double @llvm.amdgcn.frexp.mant.f64(double %320) #3
  %322 = fcmp olt double %321, 0x3FE5555555555555
  %323 = zext i1 %322 to i32
  %324 = tail call double @llvm.amdgcn.ldexp.f64(double %321, i32 %323) #3
  %325 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %320) #3
  %326 = sub nsw i32 %325, %323
  %327 = fadd double %324, -1.000000e+00
  %328 = fadd double %324, 1.000000e+00
  %329 = fsub double %328, %324
  %330 = fsub double %328, %329
  %331 = fsub double %324, %330
  %332 = fsub double 1.000000e+00, %329
  %333 = fadd double %332, %331
  %334 = tail call double @llvm.amdgcn.rcp.f64(double %328) #3
  %335 = fneg double %328
  %336 = tail call double @llvm.fma.f64(double %335, double %334, double 1.000000e+00) #3
  %337 = tail call double @llvm.fma.f64(double %336, double %334, double %334) #3
  %338 = tail call double @llvm.fma.f64(double %335, double %337, double 1.000000e+00) #3
  %339 = tail call double @llvm.fma.f64(double %338, double %337, double %337) #3
  %340 = fmul double %327, %339
  %341 = fmul double %328, %340
  %342 = fneg double %341
  %343 = tail call double @llvm.fma.f64(double %340, double %328, double %342) #3
  %344 = tail call double @llvm.fma.f64(double %340, double %333, double %343) #3
  %345 = fadd double %341, %344
  %346 = fsub double %345, %341
  %347 = fsub double %344, %346
  %348 = fsub double %327, %345
  %349 = fsub double %327, %348
  %350 = fsub double %349, %345
  %351 = fsub double %350, %347
  %352 = fadd double %348, %351
  %353 = fmul double %339, %352
  %354 = fadd double %340, %353
  %355 = fsub double %354, %340
  %356 = fsub double %353, %355
  %357 = fmul double %354, %354
  %358 = fneg double %357
  %359 = tail call double @llvm.fma.f64(double %354, double %354, double %358) #3
  %360 = fmul double %356, 2.000000e+00
  %361 = tail call double @llvm.fma.f64(double %354, double %360, double %359) #3
  %362 = tail call double @llvm.fma.f64(double %356, double %356, double %361) #3
  %363 = fadd double %357, %362
  %364 = fsub double %363, %357
  %365 = fsub double %362, %364
  %366 = tail call double @llvm.fma.f64(double %363, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %367 = tail call double @llvm.fma.f64(double %363, double %366, double 0x3FC7474DD7F4DF2E) #3
  %368 = tail call double @llvm.fma.f64(double %363, double %367, double 0x3FCC71C016291751) #3
  %369 = tail call double @llvm.fma.f64(double %363, double %368, double 0x3FD249249B27ACF1) #3
  %370 = tail call double @llvm.fma.f64(double %363, double %369, double 0x3FD99999998EF7B6) #3
  %371 = tail call double @llvm.fma.f64(double %363, double %370, double 0x3FE5555555555780) #3
  %372 = tail call double @llvm.amdgcn.ldexp.f64(double %354, i32 1) #3
  %373 = tail call double @llvm.amdgcn.ldexp.f64(double %356, i32 1) #3
  %374 = fmul double %354, %363
  %375 = fneg double %374
  %376 = tail call double @llvm.fma.f64(double %354, double %363, double %375) #3
  %377 = fmul double %356, %363
  %378 = tail call double @llvm.fma.f64(double %354, double %365, double %377) #3
  %379 = fadd double %376, %378
  %380 = fadd double %374, %379
  %381 = fsub double %380, %374
  %382 = fsub double %379, %381
  %383 = fmul double %380, %371
  %384 = fneg double %383
  %385 = tail call double @llvm.fma.f64(double %380, double %371, double %384) #3
  %386 = tail call double @llvm.fma.f64(double %382, double %371, double %385) #3
  %387 = fadd double %383, %386
  %388 = fsub double %387, %383
  %389 = fsub double %386, %388
  %390 = fadd double %372, %387
  %391 = fsub double %390, %372
  %392 = fsub double %390, %391
  %393 = fsub double %372, %392
  %394 = fsub double %387, %391
  %395 = fadd double %394, %393
  %396 = fadd double %373, %389
  %397 = fsub double %396, %373
  %398 = fsub double %396, %397
  %399 = fsub double %373, %398
  %400 = fsub double %389, %397
  %401 = fadd double %400, %399
  %402 = fadd double %396, %395
  %403 = fadd double %390, %402
  %404 = fsub double %403, %390
  %405 = fsub double %402, %404
  %406 = fadd double %401, %405
  %407 = fadd double %403, %406
  %408 = fsub double %407, %403
  %409 = fsub double %406, %408
  %410 = sitofp i32 %326 to double
  %411 = fmul double %407, 0x3FF71547652B82FE
  %412 = fneg double %411
  %413 = fmul double %407, 0x3C7777D0FFDA0D24
  %414 = insertelement <2 x double> undef, double %407, i32 0
  %415 = insertelement <2 x double> %414, double %409, i32 1
  %416 = insertelement <2 x double> undef, double %412, i32 0
  %417 = insertelement <2 x double> %416, double %413, i32 1
  %418 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %415, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %417) #3
  %419 = extractelement <2 x double> %418, i32 0
  %420 = extractelement <2 x double> %418, i32 1
  %421 = fadd double %419, %420
  %422 = fadd double %411, %421
  %423 = fsub double %422, %411
  %424 = fsub double %421, %423
  %425 = fadd double %422, %410
  %426 = fsub double %425, %410
  %427 = fsub double %426, %425
  %428 = fadd double %427, %410
  %429 = fsub double %422, %426
  %430 = fadd double %429, %428
  %431 = fadd double %424, %430
  %432 = fadd double %425, %431
  %433 = tail call double @llvm.fabs.f64(double %320) #4
  %434 = fcmp oeq double %433, 0x7FF0000000000000
  %435 = select i1 %434, double %320, double %432
  %436 = fcmp olt double %320, 0.000000e+00
  %437 = select i1 %436, double 0x7FF8000000000000, double %435
  %438 = fcmp oeq double %320, 0.000000e+00
  %439 = select i1 %438, double 0xFFF0000000000000, double %437
  %mul.i.i450.i.i.i.i = fmul double %439, %439
  %mul1.i.i451.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3D1C49F35743D651
  %add.i.i452.i.i.i.i = fadd double %mul1.i.i451.i.i.i.i, 0x3EC5BDF8ABE0C4D2
  %mul5.i.i453.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E74DE722017F09B
  %add7.i.i454.i.i.i.i = fadd double %mul5.i.i453.i.i.i.i, 0x3F08B20867234AE0
  %mul10.i.i455.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i452.i.i.i.i
  %mul12.i.i456.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i454.i.i.i.i
  %add15.i.i457.i.i.i.i = fadd double %mul10.i.i455.i.i.i.i, 0x3F43291C59111954
  %add18.i.i458.i.i.i.i = fadd double %mul12.i.i456.i.i.i.i, 0x3F7555F81DC90AE6
  %mul20.i.i459.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i457.i.i.i.i
  %mul22.i.i460.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i458.i.i.i.i
  %add25.i.i461.i.i.i.i = fadd double %mul20.i.i459.i.i.i.i, 0x3FA118409603E368
  %add28.i.i462.i.i.i.i = fadd double %mul22.i.i460.i.i.i.i, 0x3FC2F812CF93403D
  %mul30.i.i463.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i461.i.i.i.i
  %mul32.i.i.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add28.i.i462.i.i.i.i
  %add35.i.i.i.i.i.i = fadd double %mul30.i.i463.i.i.i.i, 0x3FDA4ECF31EE23E1
  %add38.i.i464.i.i.i.i = fadd double %mul32.i.i.i.i.i.i, 0x3FE15637BD9C1C6C
  %440 = fmul double %439, %add35.i.i.i.i.i.i
  %add43.i.i.i.i.i.i = fsub double %add38.i.i464.i.i.i.i, %440
  %mul1.i.i434.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E834146FFF39045
  %add.i.i435.i.i.i.i = fadd double %mul1.i.i434.i.i.i.i, 0x3F16C942D4A0C545
  %mul5.i.i436.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3ED40F287F6755C5
  %add7.i.i437.i.i.i.i = fadd double %mul5.i.i436.i.i.i.i, 0x3F51AD434F5D94BA
  %mul10.i.i438.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i435.i.i.i.i
  %mul12.i.i439.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i437.i.i.i.i
  %add15.i.i440.i.i.i.i = fadd double %mul10.i.i438.i.i.i.i, 0x3F83AFF5A756295F
  %add18.i.i441.i.i.i.i = fadd double %mul12.i.i439.i.i.i.i, 0x3FAF8A313C5B71D0
  %mul20.i.i442.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i440.i.i.i.i
  %mul22.i.i443.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i441.i.i.i.i
  %add25.i.i444.i.i.i.i = fadd double %mul20.i.i442.i.i.i.i, 0x3FD1813788B6276A
  %add28.i.i445.i.i.i.i = fadd double %mul22.i.i443.i.i.i.i, 0x3FE84455F48DB67F
  %mul30.i.i446.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i444.i.i.i.i
  %add33.i.i447.i.i.i.i = fadd double %mul30.i.i446.i.i.i.i, 1.000000e+00
  %441 = fmul double %439, %add28.i.i445.i.i.i.i
  %add38.i.i449.i.i.i.i = fsub double %add33.i.i447.i.i.i.i, %441
  %mul45.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i356.i.i.i.i = fcmp ogt double %mul45.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i357.i.i.i.i = fcmp oeq double %mul45.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i358.i.i.i.i = or i1 %cmp.i.i.i.i356.i.i.i.i, %cmp.i.i.i357.i.i.i.i
  br i1 %or.cond.i.i.i358.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end.i.i.i360.i.i.i.i

if.end.i.i.i360.i.i.i.i:                          ; preds = %if.then38.i.i.i.i
  %cmp.i.i.i.i.i359.i.i.i.i = fcmp uno double %mul45.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i359.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end7.i.i.i386.i.i.i.i

if.end7.i.i.i386.i.i.i.i:                         ; preds = %if.end.i.i.i360.i.i.i.i
  %442 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul45.i.i.i.i) #3
  %443 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul45.i.i.i.i) #3
  %444 = tail call i1 @llvm.amdgcn.class.f64(double %mul45.i.i.i.i, i32 519) #3
  %445 = select i1 %444, i32 0, i32 %442
  %446 = select i1 %444, double %mul45.i.i.i.i, double %443
  %mul.i.i.i.i.i372.i.i.i.i = fmul double %446, %446
  %mul1.i.i.i.i.i373.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i374.i.i.i.i = fadd double %mul1.i.i.i.i.i373.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i375.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FE479D17050CA47
  %447 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i375.i.i.i.i
  %mul10.i.i.i.i.i377.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %add.i.i.i.i.i374.i.i.i.i
  %mul12.i.i.i.i.i378.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %447
  %add15.i.i.i.i.i379.i.i.i.i = fadd double %mul10.i.i.i.i.i377.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i380.i.i.i.i = fadd double %mul12.i.i.i.i.i378.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i381.i.i.i.i = fmul double %446, %add15.i.i.i.i.i379.i.i.i.i
  %add23.i.i.i.i.i382.i.i.i.i = fadd double %add18.i.i.i.i.i380.i.i.i.i, %mul20.i.i.i.i.i381.i.i.i.i
  %.frozen210 = freeze i32 %445
  %div.i.i.i383.i.i.i.i = sdiv i32 %.frozen210, 3
  %448 = call i32 @llvm.abs.i32(i32 %div.i.i.i383.i.i.i.i, i1 true)
  %cmp11.i.i.i385.i.i.i.i = icmp ugt i32 %448, 63
  %cmp13.i.i.i387.i.i.i.i = icmp sgt i32 %445, 2
  %decision.take2 = or i1 %cmp11.i.i.i385.i.i.i.i, %cmp13.i.i.i387.i.i.i.i
  %449 = sub nsw i32 0, %div.i.i.i383.i.i.i.i
  %fusion.paired3.v = select i1 %decision.take2, i32 %div.i.i.i383.i.i.i.i, i32 %449
  %fusion.paired3 = zext i32 %fusion.paired3.v to i64
  %450 = shl nuw i64 1, %fusion.paired3
  %451 = uitofp i64 %450 to double
  br i1 %decision.take2, label %fusion.side8, label %fusion.side9

fusion.side8:                                     ; preds = %if.end7.i.i.i386.i.i.i.i
  %452 = fmul double %add23.i.i.i.i.i382.i.i.i.i, %451
  %453 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i382.i.i.i.i, i32 %div.i.i.i383.i.i.i.i) #3
  %454 = select i1 %cmp11.i.i.i385.i.i.i.i, double %453, double %452
  br label %if.end23.i.i.i406.i.i.i.i

fusion.side9:                                     ; preds = %if.end7.i.i.i386.i.i.i.i
  %455 = fdiv double %add23.i.i.i.i.i382.i.i.i.i, %451
  br label %if.end23.i.i.i406.i.i.i.i

if.end23.i.i.i406.i.i.i.i:                        ; preds = %fusion.side9, %fusion.side8
  %guess.i.i.i355.i.i.i.i.0 = phi double [ %454, %fusion.side8 ], [ %455, %fusion.side9 ]
  %.neg4 = mul nsw i32 %div.i.i.i383.i.i.i.i, -3
  %rem.i.i.i401.i.i.i.i.decomposed = add i32 %.frozen210, 2
  %add.i.i.i402.i.i.i.i = add i32 %rem.i.i.i401.i.i.i.i.decomposed, %.neg4
  %456 = zext i32 %add.i.i.i402.i.i.i.i to i64
  %arrayidx1.i.i.i403.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %456
  %457 = load double, double addrspace(4)* %arrayidx1.i.i.i403.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i404.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.0, %457
  %cmp26.i.i.i405.i.i.i.i = icmp slt i32 %445, 1021
  br i1 %cmp26.i.i.i405.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i

do.body.i.i.i417.i.i.i.i:                         ; preds = %do.body.i.i.i417.i.i.i.i, %if.end23.i.i.i406.i.i.i.i
  %guess.i.i.i355.i.i.i.i.1 = phi double [ %mul24.i.i.i404.i.i.i.i, %if.end23.i.i.i406.i.i.i.i ], [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ]
  %mul28.i.i.i407.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %guess.i.i.i355.i.i.i.i.1
  %mul29.i.i.i408.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %mul28.i.i.i407.i.i.i.i
  %add30.i.i.i409.i.i.i.i = fadd double %mul45.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add31.i.i.i410.i.i.i.i = fadd double %mul45.i.i.i.i, %add30.i.i.i409.i.i.i.i
  %add32.i.i.i411.i.i.i.i = fadd double %mul29.i.i.i408.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add33.i.i.i412.i.i.i.i = fadd double %mul45.i.i.i.i, %add32.i.i.i411.i.i.i.i
  %div34.i.i.i413.i.i.i.i = fdiv double %add31.i.i.i410.i.i.i.i, %add33.i.i.i412.i.i.i.i
  %mul35.i.i.i414.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %div34.i.i.i413.i.i.i.i
  %sub36.i.i.i415.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i413.i.i.i.i
  %458 = tail call double @llvm.fabs.f64(double %sub36.i.i.i415.i.i.i.i) #3
  %cmp38.i.i.i416.i.i.i.i = fcmp ogt double %458, 0x3EC0000000000000
  br i1 %cmp38.i.i.i416.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

do.body40.i.i.i428.i.i.i.i:                       ; preds = %do.body40.i.i.i428.i.i.i.i, %if.end23.i.i.i406.i.i.i.i
  %guess.i.i.i355.i.i.i.i.2 = phi double [ %mul24.i.i.i404.i.i.i.i, %if.end23.i.i.i406.i.i.i.i ], [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ]
  %mul41.i.i.i418.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, %guess.i.i.i355.i.i.i.i.2
  %div42.i.i.i419.i.i.i.i = fdiv double %mul45.i.i.i.i, %guess.i.i.i355.i.i.i.i.2
  %sub43.i.i.i420.i.i.i.i = fsub double %mul41.i.i.i418.i.i.i.i, %div42.i.i.i419.i.i.i.i
  %mul44.i.i.i421.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i422.i.i.i.i = fdiv double %mul45.i.i.i.i, %mul41.i.i.i418.i.i.i.i
  %add46.i.i.i423.i.i.i.i = fadd double %mul44.i.i.i421.i.i.i.i, %div45.i.i.i422.i.i.i.i
  %div47.i.i.i424.i.i.i.i = fdiv double %sub43.i.i.i420.i.i.i.i, %add46.i.i.i423.i.i.i.i
  %sub48.i.i.i425.i.i.i.i = fsub double %guess.i.i.i355.i.i.i.i.2, %div47.i.i.i424.i.i.i.i
  %mul50.i.i.i426.i.i.i.i = fmul double %sub48.i.i.i425.i.i.i.i, 0x3EC0000000000000
  %459 = tail call double @llvm.fabs.f64(double %div47.i.i.i424.i.i.i.i) #3
  %cmp52.i.i.i427.i.i.i.i = fcmp olt double %mul50.i.i.i426.i.i.i.i, %459
  br i1 %cmp52.i.i.i427.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i: ; preds = %do.body40.i.i.i428.i.i.i.i, %do.body.i.i.i417.i.i.i.i, %if.end.i.i.i360.i.i.i.i, %if.then38.i.i.i.i
  %retval.0.i.i.i431.i.i.i.i = phi double [ %mul45.i.i.i.i, %if.then38.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i360.i.i.i.i ], [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ], [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ]
  %mul47.i.i.i.i = fmul double %add38.i.i449.i.i.i.i, %retval.0.i.i.i431.i.i.i.i
  %div48.i.i.i.i = fdiv double %add43.i.i.i.i.i.i, %mul47.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else49.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %cmp51.i.i.i.i = icmp sgt i32 %39, -33
  br i1 %cmp51.i.i.i.i, label %if.then52.i.i.i.i, label %if.else63.i.i.i.i

if.then52.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %460 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 16) #3
  %461 = tail call double @llvm.amdgcn.frexp.mant.f64(double %460) #3
  %462 = fcmp olt double %461, 0x3FE5555555555555
  %463 = zext i1 %462 to i32
  %464 = tail call double @llvm.amdgcn.ldexp.f64(double %461, i32 %463) #3
  %465 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %460) #3
  %466 = sub nsw i32 %465, %463
  %467 = fadd double %464, -1.000000e+00
  %468 = fadd double %464, 1.000000e+00
  %469 = fsub double %468, %464
  %470 = fsub double %468, %469
  %471 = fsub double %464, %470
  %472 = fsub double 1.000000e+00, %469
  %473 = fadd double %472, %471
  %474 = tail call double @llvm.amdgcn.rcp.f64(double %468) #3
  %475 = fneg double %468
  %476 = tail call double @llvm.fma.f64(double %475, double %474, double 1.000000e+00) #3
  %477 = tail call double @llvm.fma.f64(double %476, double %474, double %474) #3
  %478 = tail call double @llvm.fma.f64(double %475, double %477, double 1.000000e+00) #3
  %479 = tail call double @llvm.fma.f64(double %478, double %477, double %477) #3
  %480 = fmul double %467, %479
  %481 = fmul double %468, %480
  %482 = fneg double %481
  %483 = tail call double @llvm.fma.f64(double %480, double %468, double %482) #3
  %484 = tail call double @llvm.fma.f64(double %480, double %473, double %483) #3
  %485 = fadd double %481, %484
  %486 = fsub double %485, %481
  %487 = fsub double %484, %486
  %488 = fsub double %467, %485
  %489 = fsub double %467, %488
  %490 = fsub double %489, %485
  %491 = fsub double %490, %487
  %492 = fadd double %488, %491
  %493 = fmul double %479, %492
  %494 = fadd double %480, %493
  %495 = fsub double %494, %480
  %496 = fsub double %493, %495
  %497 = fmul double %494, %494
  %498 = fneg double %497
  %499 = tail call double @llvm.fma.f64(double %494, double %494, double %498) #3
  %500 = fmul double %496, 2.000000e+00
  %501 = tail call double @llvm.fma.f64(double %494, double %500, double %499) #3
  %502 = tail call double @llvm.fma.f64(double %496, double %496, double %501) #3
  %503 = fadd double %497, %502
  %504 = fsub double %503, %497
  %505 = fsub double %502, %504
  %506 = tail call double @llvm.fma.f64(double %503, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %507 = tail call double @llvm.fma.f64(double %503, double %506, double 0x3FC7474DD7F4DF2E) #3
  %508 = tail call double @llvm.fma.f64(double %503, double %507, double 0x3FCC71C016291751) #3
  %509 = tail call double @llvm.fma.f64(double %503, double %508, double 0x3FD249249B27ACF1) #3
  %510 = tail call double @llvm.fma.f64(double %503, double %509, double 0x3FD99999998EF7B6) #3
  %511 = tail call double @llvm.fma.f64(double %503, double %510, double 0x3FE5555555555780) #3
  %512 = tail call double @llvm.amdgcn.ldexp.f64(double %494, i32 1) #3
  %513 = tail call double @llvm.amdgcn.ldexp.f64(double %496, i32 1) #3
  %514 = fmul double %494, %503
  %515 = fneg double %514
  %516 = tail call double @llvm.fma.f64(double %494, double %503, double %515) #3
  %517 = fmul double %496, %503
  %518 = tail call double @llvm.fma.f64(double %494, double %505, double %517) #3
  %519 = fadd double %516, %518
  %520 = fadd double %514, %519
  %521 = fsub double %520, %514
  %522 = fsub double %519, %521
  %523 = fmul double %520, %511
  %524 = fneg double %523
  %525 = tail call double @llvm.fma.f64(double %520, double %511, double %524) #3
  %526 = tail call double @llvm.fma.f64(double %522, double %511, double %525) #3
  %527 = fadd double %523, %526
  %528 = fsub double %527, %523
  %529 = fsub double %526, %528
  %530 = fadd double %512, %527
  %531 = fsub double %530, %512
  %532 = fsub double %530, %531
  %533 = fsub double %512, %532
  %534 = fsub double %527, %531
  %535 = fadd double %534, %533
  %536 = fadd double %513, %529
  %537 = fsub double %536, %513
  %538 = fsub double %536, %537
  %539 = fsub double %513, %538
  %540 = fsub double %529, %537
  %541 = fadd double %540, %539
  %542 = fadd double %536, %535
  %543 = fadd double %530, %542
  %544 = fsub double %543, %530
  %545 = fsub double %542, %544
  %546 = fadd double %541, %545
  %547 = fadd double %543, %546
  %548 = fsub double %547, %543
  %549 = fsub double %546, %548
  %550 = sitofp i32 %466 to double
  %551 = fmul double %547, 0x3FF71547652B82FE
  %552 = fneg double %551
  %553 = fmul double %547, 0x3C7777D0FFDA0D24
  %554 = insertelement <2 x double> undef, double %547, i32 0
  %555 = insertelement <2 x double> %554, double %549, i32 1
  %556 = insertelement <2 x double> undef, double %552, i32 0
  %557 = insertelement <2 x double> %556, double %553, i32 1
  %558 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %555, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %557) #3
  %559 = extractelement <2 x double> %558, i32 0
  %560 = extractelement <2 x double> %558, i32 1
  %561 = fadd double %559, %560
  %562 = fadd double %551, %561
  %563 = fsub double %562, %551
  %564 = fsub double %561, %563
  %565 = fadd double %562, %550
  %566 = fsub double %565, %550
  %567 = fsub double %566, %565
  %568 = fadd double %567, %550
  %569 = fsub double %562, %566
  %570 = fadd double %569, %568
  %571 = fadd double %564, %570
  %572 = fadd double %565, %571
  %573 = tail call double @llvm.fabs.f64(double %460) #4
  %574 = fcmp oeq double %573, 0x7FF0000000000000
  %575 = select i1 %574, double %460, double %572
  %576 = fcmp olt double %460, 0.000000e+00
  %577 = select i1 %576, double 0x7FF8000000000000, double %575
  %578 = fcmp oeq double %460, 0.000000e+00
  %579 = select i1 %578, double 0xFFF0000000000000, double %577
  %mul.i.i335.i.i.i.i = fmul double %579, %579
  %mul1.i.i336.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EBF7344DBF5E403
  %add.i.i337.i.i.i.i = fadd double %mul1.i.i336.i.i.i.i, 0x3F2CFF1E2D54E4E7
  %mul5.i.i338.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EEF8CF23CAED047
  %add7.i.i339.i.i.i.i = fadd double %mul5.i.i338.i.i.i.i, 0x3F5CF8F0FF9B6F59
  %mul10.i.i340.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i337.i.i.i.i
  %mul12.i.i341.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i339.i.i.i.i
  %add15.i.i342.i.i.i.i = fadd double %mul10.i.i340.i.i.i.i, 0x3F8857AD74D33625
  %add18.i.i343.i.i.i.i = fadd double %mul12.i.i341.i.i.i.i, 0x3FAE52179C3AEDE6
  %mul20.i.i344.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i342.i.i.i.i
  %mul22.i.i345.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i343.i.i.i.i
  %add25.i.i346.i.i.i.i = fadd double %mul20.i.i344.i.i.i.i, 0x3FCB21A22303D8FC
  %add28.i.i347.i.i.i.i = fadd double %mul22.i.i345.i.i.i.i, 0x3FDF29CE00A8804B
  %mul30.i.i348.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i346.i.i.i.i
  %add33.i.i349.i.i.i.i = fadd double %mul30.i.i348.i.i.i.i, 0x3FE15775564555E5
  %580 = fmul double %579, %add28.i.i347.i.i.i.i
  %add38.i.i351.i.i.i.i = fsub double %add33.i.i349.i.i.i.i, %580
  %mul1.i.i321.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3ECD04621671DBCE
  %add.i.i322.i.i.i.i = fadd double %mul1.i.i321.i.i.i.i, 0x3F3AC0D433DC2A4E
  %mul5.i.i323.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EFD1C12EAA62BE9
  %add7.i.i324.i.i.i.i = fadd double %mul5.i.i323.i.i.i.i, 0x3F6ABB215A001E96
  %mul10.i.i325.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i322.i.i.i.i
  %mul12.i.i326.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i324.i.i.i.i
  %add15.i.i327.i.i.i.i = fadd double %mul10.i.i325.i.i.i.i, 0x3F967590758A1B1A
  %add18.i.i328.i.i.i.i = fadd double %mul12.i.i326.i.i.i.i, 0x3FBBF9941AE7DFDE
  %mul20.i.i329.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i327.i.i.i.i
  %mul22.i.i330.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i328.i.i.i.i
  %add25.i.i331.i.i.i.i = fadd double %mul20.i.i329.i.i.i.i, 0x3FD90848F242167F
  %add28.i.i332.i.i.i.i = fadd double %mul22.i.i330.i.i.i.i, 0x3FECC09A37BCEE76
  %mul30.i.i333.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i331.i.i.i.i
  %add33.i.i334.i.i.i.i = fadd double %mul30.i.i333.i.i.i.i, 1.000000e+00
  %581 = fmul double %579, %add28.i.i332.i.i.i.i
  %add38.i.i.i.i.i.i = fsub double %add33.i.i334.i.i.i.i, %581
  %mul59.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i243.i.i.i.i = fcmp ogt double %mul59.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i244.i.i.i.i = fcmp oeq double %mul59.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i245.i.i.i.i = or i1 %cmp.i.i.i.i243.i.i.i.i, %cmp.i.i.i244.i.i.i.i
  br i1 %or.cond.i.i.i245.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end.i.i.i247.i.i.i.i

if.end.i.i.i247.i.i.i.i:                          ; preds = %if.then52.i.i.i.i
  %cmp.i.i.i.i.i246.i.i.i.i = fcmp uno double %mul59.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i246.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end7.i.i.i273.i.i.i.i

if.end7.i.i.i273.i.i.i.i:                         ; preds = %if.end.i.i.i247.i.i.i.i
  %582 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul59.i.i.i.i) #3
  %583 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul59.i.i.i.i) #3
  %584 = tail call i1 @llvm.amdgcn.class.f64(double %mul59.i.i.i.i, i32 519) #3
  %585 = select i1 %584, i32 0, i32 %582
  %586 = select i1 %584, double %mul59.i.i.i.i, double %583
  %mul.i.i.i.i.i259.i.i.i.i = fmul double %586, %586
  %mul1.i.i.i.i.i260.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i261.i.i.i.i = fadd double %mul1.i.i.i.i.i260.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i262.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FE479D17050CA47
  %587 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i262.i.i.i.i
  %mul10.i.i.i.i.i264.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %add.i.i.i.i.i261.i.i.i.i
  %mul12.i.i.i.i.i265.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %587
  %add15.i.i.i.i.i266.i.i.i.i = fadd double %mul10.i.i.i.i.i264.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i267.i.i.i.i = fadd double %mul12.i.i.i.i.i265.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i268.i.i.i.i = fmul double %586, %add15.i.i.i.i.i266.i.i.i.i
  %add23.i.i.i.i.i269.i.i.i.i = fadd double %add18.i.i.i.i.i267.i.i.i.i, %mul20.i.i.i.i.i268.i.i.i.i
  %.frozen211 = freeze i32 %585
  %div.i.i.i270.i.i.i.i = sdiv i32 %.frozen211, 3
  %588 = call i32 @llvm.abs.i32(i32 %div.i.i.i270.i.i.i.i, i1 true)
  %cmp11.i.i.i272.i.i.i.i = icmp ugt i32 %588, 63
  %cmp13.i.i.i274.i.i.i.i = icmp sgt i32 %585, 2
  %decision.take3 = or i1 %cmp11.i.i.i272.i.i.i.i, %cmp13.i.i.i274.i.i.i.i
  %589 = sub nsw i32 0, %div.i.i.i270.i.i.i.i
  %fusion.paired5.v = select i1 %decision.take3, i32 %div.i.i.i270.i.i.i.i, i32 %589
  %fusion.paired5 = zext i32 %fusion.paired5.v to i64
  %590 = shl nuw i64 1, %fusion.paired5
  %591 = uitofp i64 %590 to double
  br i1 %decision.take3, label %fusion.side10, label %fusion.side11

fusion.side10:                                    ; preds = %if.end7.i.i.i273.i.i.i.i
  %592 = fmul double %add23.i.i.i.i.i269.i.i.i.i, %591
  %593 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i269.i.i.i.i, i32 %div.i.i.i270.i.i.i.i) #3
  %594 = select i1 %cmp11.i.i.i272.i.i.i.i, double %593, double %592
  br label %if.end23.i.i.i293.i.i.i.i

fusion.side11:                                    ; preds = %if.end7.i.i.i273.i.i.i.i
  %595 = fdiv double %add23.i.i.i.i.i269.i.i.i.i, %591
  br label %if.end23.i.i.i293.i.i.i.i

if.end23.i.i.i293.i.i.i.i:                        ; preds = %fusion.side11, %fusion.side10
  %guess.i.i.i242.i.i.i.i.0 = phi double [ %594, %fusion.side10 ], [ %595, %fusion.side11 ]
  %.neg3 = mul nsw i32 %div.i.i.i270.i.i.i.i, -3
  %rem.i.i.i288.i.i.i.i.decomposed = add i32 %.frozen211, 2
  %add.i.i.i289.i.i.i.i = add i32 %rem.i.i.i288.i.i.i.i.decomposed, %.neg3
  %596 = zext i32 %add.i.i.i289.i.i.i.i to i64
  %arrayidx1.i.i.i290.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %596
  %597 = load double, double addrspace(4)* %arrayidx1.i.i.i290.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i291.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.0, %597
  %cmp26.i.i.i292.i.i.i.i = icmp slt i32 %585, 1021
  br i1 %cmp26.i.i.i292.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i

do.body.i.i.i304.i.i.i.i:                         ; preds = %do.body.i.i.i304.i.i.i.i, %if.end23.i.i.i293.i.i.i.i
  %guess.i.i.i242.i.i.i.i.1 = phi double [ %mul24.i.i.i291.i.i.i.i, %if.end23.i.i.i293.i.i.i.i ], [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ]
  %mul28.i.i.i294.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %guess.i.i.i242.i.i.i.i.1
  %mul29.i.i.i295.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %mul28.i.i.i294.i.i.i.i
  %add30.i.i.i296.i.i.i.i = fadd double %mul59.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add31.i.i.i297.i.i.i.i = fadd double %mul59.i.i.i.i, %add30.i.i.i296.i.i.i.i
  %add32.i.i.i298.i.i.i.i = fadd double %mul29.i.i.i295.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add33.i.i.i299.i.i.i.i = fadd double %mul59.i.i.i.i, %add32.i.i.i298.i.i.i.i
  %div34.i.i.i300.i.i.i.i = fdiv double %add31.i.i.i297.i.i.i.i, %add33.i.i.i299.i.i.i.i
  %mul35.i.i.i301.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %div34.i.i.i300.i.i.i.i
  %sub36.i.i.i302.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i300.i.i.i.i
  %598 = tail call double @llvm.fabs.f64(double %sub36.i.i.i302.i.i.i.i) #3
  %cmp38.i.i.i303.i.i.i.i = fcmp ogt double %598, 0x3EC0000000000000
  br i1 %cmp38.i.i.i303.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

do.body40.i.i.i315.i.i.i.i:                       ; preds = %do.body40.i.i.i315.i.i.i.i, %if.end23.i.i.i293.i.i.i.i
  %guess.i.i.i242.i.i.i.i.2 = phi double [ %mul24.i.i.i291.i.i.i.i, %if.end23.i.i.i293.i.i.i.i ], [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ]
  %mul41.i.i.i305.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, %guess.i.i.i242.i.i.i.i.2
  %div42.i.i.i306.i.i.i.i = fdiv double %mul59.i.i.i.i, %guess.i.i.i242.i.i.i.i.2
  %sub43.i.i.i307.i.i.i.i = fsub double %mul41.i.i.i305.i.i.i.i, %div42.i.i.i306.i.i.i.i
  %mul44.i.i.i308.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i309.i.i.i.i = fdiv double %mul59.i.i.i.i, %mul41.i.i.i305.i.i.i.i
  %add46.i.i.i310.i.i.i.i = fadd double %mul44.i.i.i308.i.i.i.i, %div45.i.i.i309.i.i.i.i
  %div47.i.i.i311.i.i.i.i = fdiv double %sub43.i.i.i307.i.i.i.i, %add46.i.i.i310.i.i.i.i
  %sub48.i.i.i312.i.i.i.i = fsub double %guess.i.i.i242.i.i.i.i.2, %div47.i.i.i311.i.i.i.i
  %mul50.i.i.i313.i.i.i.i = fmul double %sub48.i.i.i312.i.i.i.i, 0x3EC0000000000000
  %599 = tail call double @llvm.fabs.f64(double %div47.i.i.i311.i.i.i.i) #3
  %cmp52.i.i.i314.i.i.i.i = fcmp olt double %mul50.i.i.i313.i.i.i.i, %599
  br i1 %cmp52.i.i.i314.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i: ; preds = %do.body40.i.i.i315.i.i.i.i, %do.body.i.i.i304.i.i.i.i, %if.end.i.i.i247.i.i.i.i, %if.then52.i.i.i.i
  %retval.0.i.i.i318.i.i.i.i = phi double [ %mul59.i.i.i.i, %if.then52.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i247.i.i.i.i ], [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ], [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ]
  %mul61.i.i.i.i = fmul double %add38.i.i.i.i.i.i, %retval.0.i.i.i318.i.i.i.i
  %div62.i.i.i.i = fdiv double %add38.i.i351.i.i.i.i, %mul61.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else63.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %mul64.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp1.i.i.i.i.i = fcmp oge double %mul64.i.i.i.i, 0x10000000000000
  %cmp2.i.i.i.i.i = fcmp ole double %mul64.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %600 = and i1 %cmp1.i.i.i.i.i, %cmp2.i.i.i.i.i
  br i1 %600, label %if.then66.i.i.i.i, label %if.else71.i.i.i.i

if.then66.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %mul68.i.i.i.i = fmul double %mul64.i.i.i.i, 0x401921FB54442D18
  %cmp.i.i.i.i162.i.i.i.i = fcmp ogt double %mul68.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i163.i.i.i.i = fcmp oeq double %mul68.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i164.i.i.i.i = or i1 %cmp.i.i.i.i162.i.i.i.i, %cmp.i.i.i163.i.i.i.i
  br i1 %or.cond.i.i.i164.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end.i.i.i166.i.i.i.i

if.end.i.i.i166.i.i.i.i:                          ; preds = %if.then66.i.i.i.i
  %cmp.i.i.i.i.i165.i.i.i.i = fcmp uno double %mul68.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i165.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end7.i.i.i192.i.i.i.i

if.end7.i.i.i192.i.i.i.i:                         ; preds = %if.end.i.i.i166.i.i.i.i
  %601 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul68.i.i.i.i) #3
  %602 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul68.i.i.i.i) #3
  %603 = tail call i1 @llvm.amdgcn.class.f64(double %mul68.i.i.i.i, i32 519) #3
  %604 = select i1 %603, i32 0, i32 %601
  %605 = select i1 %603, double %mul68.i.i.i.i, double %602
  %mul.i.i.i.i.i178.i.i.i.i = fmul double %605, %605
  %mul1.i.i.i.i.i179.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i180.i.i.i.i = fadd double %mul1.i.i.i.i.i179.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i181.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FE479D17050CA47
  %606 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i181.i.i.i.i
  %mul10.i.i.i.i.i183.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %add.i.i.i.i.i180.i.i.i.i
  %mul12.i.i.i.i.i184.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %606
  %add15.i.i.i.i.i185.i.i.i.i = fadd double %mul10.i.i.i.i.i183.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i186.i.i.i.i = fadd double %mul12.i.i.i.i.i184.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i187.i.i.i.i = fmul double %605, %add15.i.i.i.i.i185.i.i.i.i
  %add23.i.i.i.i.i188.i.i.i.i = fadd double %add18.i.i.i.i.i186.i.i.i.i, %mul20.i.i.i.i.i187.i.i.i.i
  %.frozen212 = freeze i32 %604
  %div.i.i.i189.i.i.i.i = sdiv i32 %.frozen212, 3
  %607 = call i32 @llvm.abs.i32(i32 %div.i.i.i189.i.i.i.i, i1 true)
  %cmp11.i.i.i191.i.i.i.i = icmp ugt i32 %607, 63
  %cmp13.i.i.i193.i.i.i.i = icmp sgt i32 %604, 2
  %decision.take4 = or i1 %cmp11.i.i.i191.i.i.i.i, %cmp13.i.i.i193.i.i.i.i
  %608 = sub nsw i32 0, %div.i.i.i189.i.i.i.i
  %fusion.paired6.v = select i1 %decision.take4, i32 %div.i.i.i189.i.i.i.i, i32 %608
  %fusion.paired6 = zext i32 %fusion.paired6.v to i64
  %609 = shl nuw i64 1, %fusion.paired6
  %610 = uitofp i64 %609 to double
  br i1 %decision.take4, label %fusion.side13, label %fusion.side14, !decision.merged_from !12, !decision.origin !13

fusion.side13:                                    ; preds = %if.end7.i.i.i192.i.i.i.i
  %611 = fmul double %add23.i.i.i.i.i188.i.i.i.i, %610
  %612 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i188.i.i.i.i, i32 %div.i.i.i189.i.i.i.i) #3
  %613 = select i1 %cmp11.i.i.i191.i.i.i.i, double %612, double %611
  br label %if.end23.i.i.i212.i.i.i.i.pair.join

fusion.side14:                                    ; preds = %if.end7.i.i.i192.i.i.i.i
  %614 = fdiv double %add23.i.i.i.i.i188.i.i.i.i, %610
  br label %if.end23.i.i.i212.i.i.i.i.pair.join

if.end23.i.i.i212.i.i.i.i.pair.join:              ; preds = %fusion.side14, %fusion.side13
  %guess.i.i.i161.i.i.i.i.0.ph = phi double [ %614, %fusion.side14 ], [ %613, %fusion.side13 ]
  br label %if.end23.i.i.i212.i.i.i.i

if.end23.i.i.i212.i.i.i.i:                        ; preds = %if.end23.i.i.i212.i.i.i.i.pair.join
  %.neg2 = mul nsw i32 %div.i.i.i189.i.i.i.i, -3
  %rem.i.i.i207.i.i.i.i.decomposed = add i32 %.frozen212, 2
  %add.i.i.i208.i.i.i.i = add i32 %rem.i.i.i207.i.i.i.i.decomposed, %.neg2
  %615 = zext i32 %add.i.i.i208.i.i.i.i to i64
  %arrayidx1.i.i.i209.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %615
  %616 = load double, double addrspace(4)* %arrayidx1.i.i.i209.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i210.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.0.ph, %616
  %cmp26.i.i.i211.i.i.i.i = icmp slt i32 %604, 1021
  br i1 %cmp26.i.i.i211.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i

do.body.i.i.i223.i.i.i.i:                         ; preds = %do.body.i.i.i223.i.i.i.i, %if.end23.i.i.i212.i.i.i.i
  %guess.i.i.i161.i.i.i.i.1 = phi double [ %mul24.i.i.i210.i.i.i.i, %if.end23.i.i.i212.i.i.i.i ], [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ]
  %mul28.i.i.i213.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %guess.i.i.i161.i.i.i.i.1
  %mul29.i.i.i214.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %mul28.i.i.i213.i.i.i.i
  %add30.i.i.i215.i.i.i.i = fadd double %mul68.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add31.i.i.i216.i.i.i.i = fadd double %mul68.i.i.i.i, %add30.i.i.i215.i.i.i.i
  %add32.i.i.i217.i.i.i.i = fadd double %mul29.i.i.i214.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add33.i.i.i218.i.i.i.i = fadd double %mul68.i.i.i.i, %add32.i.i.i217.i.i.i.i
  %div34.i.i.i219.i.i.i.i = fdiv double %add31.i.i.i216.i.i.i.i, %add33.i.i.i218.i.i.i.i
  %mul35.i.i.i220.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %div34.i.i.i219.i.i.i.i
  %sub36.i.i.i221.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i219.i.i.i.i
  %617 = tail call double @llvm.fabs.f64(double %sub36.i.i.i221.i.i.i.i) #3
  %cmp38.i.i.i222.i.i.i.i = fcmp ogt double %617, 0x3EC0000000000000
  br i1 %cmp38.i.i.i222.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

do.body40.i.i.i234.i.i.i.i:                       ; preds = %do.body40.i.i.i234.i.i.i.i, %if.end23.i.i.i212.i.i.i.i
  %guess.i.i.i161.i.i.i.i.2 = phi double [ %mul24.i.i.i210.i.i.i.i, %if.end23.i.i.i212.i.i.i.i ], [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ]
  %mul41.i.i.i224.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, %guess.i.i.i161.i.i.i.i.2
  %div42.i.i.i225.i.i.i.i = fdiv double %mul68.i.i.i.i, %guess.i.i.i161.i.i.i.i.2
  %sub43.i.i.i226.i.i.i.i = fsub double %mul41.i.i.i224.i.i.i.i, %div42.i.i.i225.i.i.i.i
  %mul44.i.i.i227.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i228.i.i.i.i = fdiv double %mul68.i.i.i.i, %mul41.i.i.i224.i.i.i.i
  %add46.i.i.i229.i.i.i.i = fadd double %mul44.i.i.i227.i.i.i.i, %div45.i.i.i228.i.i.i.i
  %div47.i.i.i230.i.i.i.i = fdiv double %sub43.i.i.i226.i.i.i.i, %add46.i.i.i229.i.i.i.i
  %sub48.i.i.i231.i.i.i.i = fsub double %guess.i.i.i161.i.i.i.i.2, %div47.i.i.i230.i.i.i.i
  %mul50.i.i.i232.i.i.i.i = fmul double %sub48.i.i.i231.i.i.i.i, 0x3EC0000000000000
  %618 = tail call double @llvm.fabs.f64(double %div47.i.i.i230.i.i.i.i) #3
  %cmp52.i.i.i233.i.i.i.i = fcmp olt double %mul50.i.i.i232.i.i.i.i, %618
  br i1 %cmp52.i.i.i233.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i: ; preds = %do.body40.i.i.i234.i.i.i.i, %do.body.i.i.i223.i.i.i.i, %if.end.i.i.i166.i.i.i.i, %if.then66.i.i.i.i
  %retval.0.i.i.i237.i.i.i.i = phi double [ %mul68.i.i.i.i, %if.then66.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i166.i.i.i.i ], [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ], [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ]
  %div70.i.i.i.i = fdiv double 1.000000e+00, %retval.0.i.i.i237.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else71.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %cmp72.i.i.i.i = fcmp ogt double %sub.i.i.i, 0.000000e+00
  br i1 %cmp72.i.i.i.i, label %if.then73.i.i.i.i, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.then73.i.i.i.i:                                ; preds = %if.else71.i.i.i.i
  %cmp.i.i.i.i79.i.i.i.i = fcmp ogt double %sub.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i.i80.i.i.i.i = fcmp olt double %sub.i.i.i, 0xFFEFFFFFFFFFFFFF
  %619 = or i1 %cmp.i.i.i.i79.i.i.i.i, %cmp1.i.i.i.i80.i.i.i.i
  %or.cond.i.i.i82.i.i.i.i = or i1 %38, %619
  %brmerge170 = or i1 %33, %or.cond.i.i.i82.i.i.i.i
  %sub.i.i.i.mux = select i1 %or.cond.i.i.i82.i.i.i.i, double %sub.i.i.i, double 0x7FF8000000000000
  br i1 %brmerge170, label %if.end7.i.i.i.i.i.i.i, label %if.end4.i.i.i92.i.i.i.i

if.end4.i.i.i92.i.i.i.i:                          ; preds = %if.then73.i.i.i.i
  %cmp5.i.i.i91.i.i.i.i = fcmp olt double %sub.i.i.i, 0.000000e+00
  %fneg.i.i.i93.i.i.i.i = fneg double %sub.i.i.i
  %z.addr.i.i.i76.i.i.i.i.0 = select i1 %cmp5.i.i.i91.i.i.i.i, double %fneg.i.i.i93.i.i.i.i, double %sub.i.i.i
  %620 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %621 = tail call double @llvm.amdgcn.frexp.mant.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %622 = tail call i1 @llvm.amdgcn.class.f64(double %z.addr.i.i.i76.i.i.i.i.0, i32 519) #3
  %623 = select i1 %622, i32 0, i32 %620
  %624 = select i1 %622, double %z.addr.i.i.i76.i.i.i.i.0, double %621
  %mul.i.i.i.i.i97.i.i.i.i = fmul double %624, %624
  %mul1.i.i.i.i.i98.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i99.i.i.i.i = fadd double %mul1.i.i.i.i.i98.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i100.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FE479D17050CA47
  %625 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i100.i.i.i.i
  %mul10.i.i.i.i.i102.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %add.i.i.i.i.i99.i.i.i.i
  %mul12.i.i.i.i.i103.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %625
  %add15.i.i.i.i.i104.i.i.i.i = fadd double %mul10.i.i.i.i.i102.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i105.i.i.i.i = fadd double %mul12.i.i.i.i.i103.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i106.i.i.i.i = fmul double %624, %add15.i.i.i.i.i104.i.i.i.i
  %add23.i.i.i.i.i107.i.i.i.i = fadd double %add18.i.i.i.i.i105.i.i.i.i, %mul20.i.i.i.i.i106.i.i.i.i
  %.frozen213 = freeze i32 %623
  %div.i.i.i108.i.i.i.i = sdiv i32 %.frozen213, 3
  %626 = sub nsw i32 0, %div.i.i.i108.i.i.i.i
  %627 = call i32 @llvm.abs.i32(i32 %div.i.i.i108.i.i.i.i, i1 true)
  %cmp11.i.i.i110.i.i.i.i = icmp ult i32 %627, 64
  %decision.left = xor i1 %cmp11.i.i.i110.i.i.i.i, true
  %cmp13.i.i.i112.i.i.i.i = icmp sgt i32 %623, 2
  %decision.take5 = or i1 %cmp13.i.i.i112.i.i.i.i, %decision.left
  %sh_prom.i.i.i114.i.i.i.i = zext i32 %div.i.i.i108.i.i.i.i to i64
  %shl.i.i.i115.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i114.i.i.i.i
  %conv.i.i.i116.i.i.i.i = uitofp i64 %shl.i.i.i115.i.i.i.i to double
  %mul.i.i.i117.i.i.i.i = fmul double %add23.i.i.i.i.i107.i.i.i.i, %conv.i.i.i116.i.i.i.i
  %628 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  %guess.i.i.i78.i.i.i.i.0.ph = select i1 %cmp11.i.i.i110.i.i.i.i, double %mul.i.i.i117.i.i.i.i, double %628
  %sh_prom16.i.i.i120.i.i.i.i = zext i32 %626 to i64
  %shl17.i.i.i121.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i120.i.i.i.i
  %conv18.i.i.i122.i.i.i.i = uitofp i64 %shl17.i.i.i121.i.i.i.i to double
  %div19.i.i.i123.i.i.i.i = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %conv18.i.i.i122.i.i.i.i
  %629 = select i1 %decision.take5, double %guess.i.i.i78.i.i.i.i.0.ph, double %div19.i.i.i123.i.i.i.i
  %.neg = mul nsw i32 %div.i.i.i108.i.i.i.i, -3
  %rem.i.i.i126.i.i.i.i.decomposed = add i32 %.frozen213, 2
  %add.i.i.i127.i.i.i.i = add i32 %rem.i.i.i126.i.i.i.i.decomposed, %.neg
  %630 = zext i32 %add.i.i.i127.i.i.i.i to i64
  %arrayidx1.i.i.i128.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %630
  %631 = load double, double addrspace(4)* %arrayidx1.i.i.i128.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i129.i.i.i.i = fmul double %629, %631
  %cmp26.i.i.i130.i.i.i.i = icmp slt i32 %623, 1021
  br label %merged.bb

if.then12.i.i.i32.i.i.i.i:                        ; preds = %merged.bb5
  br i1 %cmp13.i.i.i112.i.i.i.i, label %if.end23.i.i.i50.i.i.i.i, label %if.else.i.i.i43.i.i.i.i

if.else.i.i.i43.i.i.i.i:                          ; preds = %if.then12.i.i.i32.i.i.i.i
  br label %if.end23.i.i.i50.i.i.i.i

if.end23.i.i.i50.i.i.i.i:                         ; preds = %merged.bb5, %if.else.i.i.i43.i.i.i.i, %if.then12.i.i.i32.i.i.i.i
  %guess.i.i.i10.i.i.i.i.0 = phi double [ %mul.i.i.i117.i.i.i.i, %if.then12.i.i.i32.i.i.i.i ], [ %div19.i.i.i123.i.i.i.i, %if.else.i.i.i43.i.i.i.i ], [ %628, %merged.bb5 ]
  %mul24.i.i.i48.i.i.i.i = fmul double %631, %guess.i.i.i10.i.i.i.i.0
  br label %merged.bb6

if.end7.i.i.i.i.i.i.i:                            ; preds = %merged.bb7, %if.then73.i.i.i.i
  %retval.0.i.i.i156.i.i.i.i162 = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %1006, %merged.bb7 ]
  %retval.0.i.i.i.i.i.i.i = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %1028, %merged.bb7 ]
  %mul76.i.i.i.i = fmul double %retval.0.i.i.i156.i.i.i.i162, %retval.0.i.i.i.i.i.i.i
  %mul79.i.i.i.i = fmul double %mul76.i.i.i.i, 0x3FFD8639FDCB60EB
  %div80.i.i.i.i = fdiv double 1.000000e+00, %mul79.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

cond.false7.i.i.i:                                ; preds = %if.end14.i.i
  %decision.interval6 = fcmp ult double %arrayidx.val, 1.250000e-01
  br i1 %decision.interval6, label %if.else17.i.i.i.i, label %decision.dispatch5, !decision.condition_prefix !6

decision.dispatch5:                               ; preds = %cond.false7.i.i.i
  %decision.interval = fcmp ult double %arrayidx.val, 2.500000e-01
  %632 = fcmp ult double %arrayidx.val, 3.750000e-01
  %633 = select i1 %632, double -2.500000e-01, double -3.750000e-01
  %634 = select i1 %decision.interval, double -1.250000e-01, double %633
  %635 = select i1 %decision.interval, i1 poison, i1 %632
  %636 = fadd double %arrayidx.val, %634
  %637 = fmul double %636, %636
  %638 = select i1 %635, double 0x402A50B00A1E7B86, double 0x40132BDEE3243B58
  %639 = select i1 %decision.interval, double 0x406D392CDE09E490, double %638
  %640 = fmul double %637, %639
  %641 = fsub double 0x408C7AAA9D225E9A, %640
  %642 = select i1 %635, double 0xC03EAAFBAB179207, double 0xC0360FDD97954BA2
  %643 = fadd double %640, %642
  %644 = select i1 %635, double 0x403CBAD71AE3B29A, double 0x401CB5EDEDB31A3B
  %645 = select i1 %decision.interval, double 0x408B6249334DA816, double %644
  %646 = fmul double %637, %645
  %647 = fadd double %646, 0xC017CB97C9E45E0D
  %648 = select i1 %decision.interval, double 0x408C1B9BAF952B96, double 0x4040A8BCD7811DE4
  %649 = fsub double %648, %646
  %650 = fmul double %637, %641
  %phi.bo = fadd double %650, 0xC05E9BCF5C362E51
  %651 = select i1 %635, double %649, double %647
  %652 = select i1 %decision.interval, double 0xC0320C17B7F0ED52, double 0x401B5545C0CB5BDA
  %653 = select i1 %decision.interval, double 0x404C078043CB129C, double 0x3FF693D2420640AD
  %654 = select i1 %decision.interval, double %phi.bo, double %651
  %655 = select i1 %decision.interval, double %649, double %643
  %656 = fmul double %637, %655
  %657 = fmul double %637, %654
  %658 = select i1 %635, double 0x402CB09090084637, double 0x4027FEF192CFFD80
  %659 = select i1 %635, double 0xC013B1AD6B90733F, double 0x3FF83BDAD25D5F48
  %660 = select i1 %decision.interval, double 0xC04249A2BD20D346, double %659
  %661 = fadd double %657, %660
  %662 = select i1 %635, double 0xBFFA1FFFE7A41296, double 0xBFF2C5AD0DCDC29A
  %.v.v = select i1 %decision.interval, double 0xC066A4A24A4E1713, double %658
  %.v = fadd double %656, %.v.v
  %663 = fmul double %637, %.v
  %664 = select i1 %decision.interval, double 0xC001804F92FE2A82, double %662
  %665 = fadd double %663, %664
  %666 = fmul double %636, %661
  %667 = fadd double %666, %665
  %668 = fmul double %637, 0x405E5232607614DB
  %669 = fadd double %668, 0xC0809E1D789AFFE5
  %670 = fmul double %637, %653
  %671 = fsub double %652, %670
  %672 = select i1 %635, double 0x40296F06194D60C2, double 0x40074E9A9F865729
  %673 = select i1 %decision.interval, double %669, double %672
  %674 = fmul double %637, %673
  %675 = select i1 %635, double 0xC030F25386AA802B, double 0xC016B372910B83AB
  %676 = fmul double %637, %671
  %677 = select i1 %decision.interval, double 0x4071A64A34042F35, double %675
  %678 = fadd double %674, %677
  %679 = select i1 %635, double 0x40199996D51EE9B7, double %671
  %680 = fmul double %637, %679
  %681 = fsub double 0x40034649FCCCF81F, %680
  %.op4 = fadd double %676, 0x405F12CC60181A8F
  %682 = select i1 %decision.interval, double poison, double %681
  %683 = fmul double %637, %678
  %.op5 = fadd double %680, 0xC0138A29DF206C0B
  %684 = select i1 %635, double 0x40158CEB587D3265, double 0x3FFC33F0B4C09D66
  %685 = select i1 %decision.interval, double poison, double %.op5
  %686 = select i1 %decision.interval, double 0x40332E0500972875, double %684
  %687 = fadd double %683, %686
  %688 = select i1 %635, double %682, double %685
  %.v6 = select i1 %decision.interval, double %.op4, double %688
  %689 = fmul double %637, %.v6
  %690 = fadd double %689, 1.000000e+00
  %691 = fmul double %636, %687
  %692 = fadd double %691, %690
  %693 = fdiv double %667, %692
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else17.i.i.i.i:                                ; preds = %cond.false7.i.i.i
  %694 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %arrayidx.val) #3
  %695 = add nsw i32 %694, -1
  %696 = tail call double @llvm.fabs.f64(double %arrayidx.val) #4
  %697 = fcmp oeq double %696, 0x7FF0000000000000
  %698 = select i1 %697, i32 2147483647, i32 %695
  %699 = fcmp oeq double %arrayidx.val, 0.000000e+00
  %700 = select i1 %699, i32 -2147483648, i32 %698
  %cmp106.i.i.i.i = icmp sgt i32 %700, -1025
  br i1 %cmp106.i.i.i.i, label %decision.dispatch2, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, !decision.condition_prefix !6

decision.dispatch2:                               ; preds = %if.else17.i.i.i.i
  %cmp19.i.i.i.i = icmp sgt i32 %700, -5
  br i1 %cmp19.i.i.i.i, label %fusion.common, label %fusion.side

fusion.side:                                      ; preds = %decision.dispatch2
  %701 = icmp sgt i32 %700, -65
  %702 = select i1 %701, i32 -17, i32 -257
  %703 = icmp sgt i32 %700, %702
  %704 = select i1 %701, i32 -9, i32 -129
  %705 = select i1 %701, i32 -33, i32 -513
  %706 = select i1 %703, i32 %704, i32 %705
  %707 = icmp sgt i32 %700, %706
  %708 = select i1 %701, i32 4, i32 64
  %709 = select i1 %701, i32 16, i32 256
  %710 = select i1 %703, i32 %708, i32 %709
  %711 = select i1 %701, i32 8, i32 128
  %712 = select i1 %701, i32 32, i32 512
  %713 = select i1 %703, i32 %711, i32 %712
  %714 = select i1 %707, i32 %710, i32 %713
  br label %fusion.common

fusion.common:                                    ; preds = %fusion.side, %decision.dispatch2
  %715 = phi i32 [ 3, %decision.dispatch2 ], [ %714, %fusion.side ]
  %716 = phi i1 [ poison, %decision.dispatch2 ], [ %701, %fusion.side ]
  %717 = phi i1 [ poison, %decision.dispatch2 ], [ %703, %fusion.side ]
  %718 = phi i1 [ poison, %decision.dispatch2 ], [ %707, %fusion.side ]
  %719 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %715) #3
  %720 = tail call double @llvm.amdgcn.frexp.mant.f64(double %719) #3
  %721 = fcmp olt double %720, 0x3FE5555555555555
  %722 = zext i1 %721 to i32
  %723 = tail call double @llvm.amdgcn.ldexp.f64(double %720, i32 %722) #3
  %724 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %719) #3
  %725 = sub nsw i32 %724, %722
  %726 = fadd double %723, -1.000000e+00
  %727 = fadd double %723, 1.000000e+00
  %728 = fsub double %727, %723
  %729 = fsub double %727, %728
  %730 = fsub double %723, %729
  %731 = fsub double 1.000000e+00, %728
  %732 = fadd double %731, %730
  %733 = tail call double @llvm.amdgcn.rcp.f64(double %727) #3
  %734 = fneg double %727
  %735 = tail call double @llvm.fma.f64(double %734, double %733, double 1.000000e+00) #3
  %736 = tail call double @llvm.fma.f64(double %735, double %733, double %733) #3
  %737 = tail call double @llvm.fma.f64(double %734, double %736, double 1.000000e+00) #3
  %738 = tail call double @llvm.fma.f64(double %737, double %736, double %736) #3
  %739 = fmul double %726, %738
  %740 = fmul double %727, %739
  %741 = fneg double %740
  %742 = tail call double @llvm.fma.f64(double %739, double %727, double %741) #3
  %743 = tail call double @llvm.fma.f64(double %739, double %732, double %742) #3
  %744 = fadd double %740, %743
  %745 = fsub double %744, %740
  %746 = fsub double %743, %745
  %747 = fsub double %726, %744
  %748 = fsub double %726, %747
  %749 = fsub double %748, %744
  %750 = fsub double %749, %746
  %751 = fadd double %747, %750
  %752 = fmul double %738, %751
  %753 = fadd double %739, %752
  %754 = fsub double %753, %739
  %755 = fsub double %752, %754
  %756 = fmul double %753, %753
  %757 = fneg double %756
  %758 = tail call double @llvm.fma.f64(double %753, double %753, double %757) #3
  %759 = fmul double %755, 2.000000e+00
  %760 = tail call double @llvm.fma.f64(double %753, double %759, double %758) #3
  %761 = tail call double @llvm.fma.f64(double %755, double %755, double %760) #3
  %762 = fadd double %756, %761
  %763 = fsub double %762, %756
  %764 = fsub double %761, %763
  %765 = tail call double @llvm.fma.f64(double %762, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %766 = tail call double @llvm.fma.f64(double %762, double %765, double 0x3FC7474DD7F4DF2E) #3
  %767 = tail call double @llvm.fma.f64(double %762, double %766, double 0x3FCC71C016291751) #3
  %768 = tail call double @llvm.fma.f64(double %762, double %767, double 0x3FD249249B27ACF1) #3
  %769 = tail call double @llvm.fma.f64(double %762, double %768, double 0x3FD99999998EF7B6) #3
  %770 = tail call double @llvm.fma.f64(double %762, double %769, double 0x3FE5555555555780) #3
  %771 = tail call double @llvm.amdgcn.ldexp.f64(double %753, i32 1) #3
  %772 = tail call double @llvm.amdgcn.ldexp.f64(double %755, i32 1) #3
  %773 = fmul double %753, %762
  %774 = fneg double %773
  %775 = tail call double @llvm.fma.f64(double %753, double %762, double %774) #3
  %776 = fmul double %755, %762
  %777 = tail call double @llvm.fma.f64(double %753, double %764, double %776) #3
  %778 = fadd double %775, %777
  %779 = fadd double %773, %778
  %780 = fsub double %779, %773
  %781 = fsub double %778, %780
  %782 = fmul double %779, %770
  %783 = fneg double %782
  %784 = tail call double @llvm.fma.f64(double %779, double %770, double %783) #3
  %785 = tail call double @llvm.fma.f64(double %781, double %770, double %784) #3
  %786 = fadd double %782, %785
  %787 = fsub double %786, %782
  %788 = fsub double %785, %787
  %789 = fadd double %771, %786
  %790 = fsub double %789, %771
  %791 = fsub double %789, %790
  %792 = fsub double %771, %791
  %793 = fsub double %786, %790
  %794 = fadd double %793, %792
  %795 = fadd double %772, %788
  %796 = fsub double %795, %772
  %797 = fsub double %795, %796
  %798 = fsub double %772, %797
  %799 = fsub double %788, %796
  %800 = fadd double %799, %798
  %801 = fadd double %795, %794
  %802 = fadd double %789, %801
  %803 = fsub double %802, %789
  %804 = fsub double %801, %803
  %805 = fadd double %800, %804
  %806 = fadd double %802, %805
  %807 = fsub double %806, %802
  %808 = fsub double %805, %807
  %809 = sitofp i32 %725 to double
  %810 = select i1 %cmp19.i.i.i.i, double %809, double poison
  %811 = fmul double %806, 0x3FF71547652B82FE
  %812 = fneg double %811
  %813 = fmul double %806, 0x3C7777D0FFDA0D24
  br i1 %cmp19.i.i.i.i, label %fusion.side15, label %fusion.common3

fusion.side15:                                    ; preds = %fusion.common
  %814 = insertelement <2 x double> undef, double %806, i32 0
  %815 = insertelement <2 x double> %814, double %808, i32 1
  %816 = insertelement <2 x double> undef, double %812, i32 0
  %817 = insertelement <2 x double> %816, double %813, i32 1
  %818 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %815, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %817) #3
  %819 = extractelement <2 x double> %818, i32 0
  %820 = extractelement <2 x double> %818, i32 1
  %821 = fadd double %819, %820
  %822 = fadd double %811, %821
  %823 = fsub double %822, %811
  %824 = fsub double %821, %823
  %825 = fadd double %822, %810
  %826 = fsub double %825, %810
  %827 = fsub double %826, %825
  %828 = fadd double %827, %810
  %829 = fsub double %822, %826
  %830 = fadd double %829, %828
  %831 = fadd double %824, %830
  %832 = fadd double %825, %831
  %833 = tail call double @llvm.fabs.f64(double %719) #4
  %834 = fcmp oeq double %833, 0x7FF0000000000000
  %835 = select i1 %834, double %719, double %832
  %836 = fcmp olt double %719, 0.000000e+00
  %837 = select i1 %836, double 0x7FF8000000000000, double %835
  %838 = fcmp oeq double %719, 0.000000e+00
  %839 = select i1 %838, double 0xFFF0000000000000, double %837
  %840 = fmul double %839, %839
  %841 = fmul double %840, 0x3F1989D450BBA5CA
  %842 = fsub double 0xBFBD94CCEC41CB08, %841
  %843 = fmul double %840, 0x3F7B3A00DD9C9429
  %844 = fsub double 0xBFE8DDD719DA7D3E, %843
  %845 = fmul double %840, %842
  %846 = fmul double %840, %844
  %847 = fadd double %845, 0xC001974D2C397C76
  %848 = fadd double %846, 0xC001804F92FE2A82
  %849 = fmul double %839, %847
  %850 = fsub double %848, %849
  %851 = fmul double %840, 0x3EDBEC7AF5AC0D6F
  %852 = fadd double %851, 0x3F98BA1DB321D0E9
  %853 = fmul double %840, 0x3F4ED662BB480251
  %854 = fadd double %853, 0x3FCBD444F5D4FCC2
  %855 = fmul double %840, %852
  %856 = fmul double %840, %854
  %857 = fadd double %855, 0x3FE957680773BEB6
  %858 = fadd double %856, 1.000000e+00
  %859 = fmul double %839, %857
  %860 = fsub double %858, %859
  %861 = fdiv double %850, %860
  br label %fusion.common3

fusion.common3:                                   ; preds = %fusion.side15, %fusion.common
  %862 = phi double [ poison, %fusion.common ], [ %861, %fusion.side15 ]
  br i1 %cmp19.i.i.i.i, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, label %decision.dispatch1

decision.dispatch1:                               ; preds = %fusion.common3
  %863 = insertelement <2 x double> undef, double %806, i32 0
  %864 = insertelement <2 x double> %863, double %808, i32 1
  %865 = insertelement <2 x double> undef, double %812, i32 0
  %866 = insertelement <2 x double> %865, double %813, i32 1
  %867 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %864, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %866) #3
  %868 = extractelement <2 x double> %867, i32 0
  %869 = extractelement <2 x double> %867, i32 1
  %870 = select i1 %718, double 0x3D5866A3E6D0F156, double 0x3CED1FCD2AD8841F
  %871 = select i1 %718, double 0xBE9C2F1FFD2FFECD, double 0xBE512769C01EA7C5
  %872 = select i1 %718, double 0x3E1390C28573DB0F, double 0x3DB79116B58241AA
  %873 = select i1 %718, double 0xBF0B3634004E0F5C, double 0xBED0C1E92AD969EF
  %874 = select i1 %718, double 0xBF676495E4B7EAAA, double 0xBF3D2E78945F9AC6
  %875 = select i1 %718, double 0xBFB3B5B6F694BB9E, double 0xBF98ED20B1D6A6D8
  %876 = select i1 %718, double 0xBFEFD66AE54A0BCB, double 0xBFE46D859460DB51
  %877 = select i1 %718, double 0xC013B000D66B8269, double 0xC019A861C808DCFC
  %878 = select i1 %718, double 0x3DCCD7C812F40049, double 0x3D6B7BD497A2CD17
  %879 = select i1 %718, double 0x3ED66AFC954DE682, double 0x3E95BA568EDD3BFB
  %880 = select i1 %718, double 0x3E6129D961D79065, double 0x3E107ECF99D6009A
  %881 = select i1 %718, double 0x3F380B62C1407B15, double 0x3F077F4625619D43
  %882 = select i1 %718, double 0x3F882FD20DA34F30, double 0x3F67D3564F778B21
  %883 = select i1 %718, double 0x3FC6B0CE3157BCB1, double 0x3FB68627D1A51CB5
  %884 = select i1 %718, double 0x3E32022ABCFF5DE7, double 0x3DC4C8BD76453064
  %885 = select i1 %718, double 0xBF336C13BBA203F3, double 0xBEE755F1646665DB
  %886 = select i1 %718, double 0x3ECBFD524C94F258, double 0x3E70731CF2A765F0
  %887 = select i1 %718, double 0xBF81F96D17A7115B, double 0xBF4625660A41D7B1
  %888 = select i1 %718, double 0xBFBD7935AC58B5B5, double 0xBF92AE2345C460A0
  %889 = select i1 %718, double 0xBFE78F054AC7A90B, double 0xBFCED54905311121
  %890 = select i1 %718, double 0xC001F1CD6A03BCAA, double 0xBFF8595CA25899FD
  %891 = select i1 %718, double 0xC004C929A952DE48, double 0xC00D636ADAEC3C05
  %892 = select i1 %718, double 0x3E9090FBB4B042AE, double 0x3E2EB2F3F6504F32
  %893 = select i1 %718, double 0x3F586FC94B9EAD30, double 0x3F1751EF5755C229
  %894 = select i1 %718, double 0x3F0330822740ADF9, double 0x3EB20E304F6E5BCE
  %895 = select i1 %718, double 0x3F999857B526C821, double 0x3F68BF137C253BD1
  %896 = select i1 %718, double 0x3FC92E7DCCD1B70C, double 0x3FA8A45F1AE4ADBE
  %897 = select i1 %718, double 0x3FE7235AE26E3A60, double 0x3FD6E5B7AB236028
  br i1 %716, label %merged.bb70, label %merged.branch.split83

fusion.side12:                                    ; preds = %decision.dispatch3
  %898 = fmul double %10, 0x3FF51F0306685285
  %899 = fsub double 0xBFEEB82FAA589934, %898
  %900 = fmul double %10, 0x3FEFDC5AEE1525E4
  %901 = fsub double 0x4043A793DEC20DEB, %900
  br label %fusion.common11

fusion.common11:                                  ; preds = %fusion.side12, %decision.dispatch3
  %902 = phi double [ 0x40354F2A1256B431, %decision.dispatch3 ], [ 0x4020675EC4F85A38, %fusion.side12 ]
  %903 = phi double [ 0x4063AA2F5D62DCD3, %decision.dispatch3 ], [ 0x403058D46A8EC004, %fusion.side12 ]
  %904 = phi double [ 0x407BA4300BFE5087, %decision.dispatch3 ], [ 0xC02E8C55CA7195EF, %fusion.side12 ]
  %905 = phi double [ 0xC083E59B9D34A0F1, %decision.dispatch3 ], [ 0x401A11C0BB0DC22E, %fusion.side12 ]
  %906 = phi double [ 0x406113A5A6902AC1, %decision.dispatch3 ], [ %899, %fusion.side12 ]
  %907 = phi double [ poison, %decision.dispatch3 ], [ %901, %fusion.side12 ]
  %908 = fmul double %10, %906
  %909 = fmul double %10, %907
  %910 = fadd double %908, %905
  %.op3 = fadd double %909, 0xC04B158FF790C730
  %911 = fmul double %10, 0x4071AEC837B9190D
  %912 = fsub double 0x406A5A0FD2D4B901, %911
  %fusion.paired18 = select i1 %cmp.i.i.i.i, double %912, double %.op3
  %913 = fmul double %10, %910
  %914 = fmul double %10, %fusion.paired18
  %915 = fadd double %913, %904
  %916 = fadd double %914, %903
  %917 = fmul double %10, %915
  %918 = fmul double %10, %916
  %919 = fadd double %917, %902
  %920 = fadd double %918, 1.000000e+00
  %921 = fmul double %9, %919
  %922 = fadd double %920, %921
  %923 = fdiv double %30, %922
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i: ; preds = %merged.bb70, %fusion.common11, %fusion.common3, %if.else17.i.i.i.i, %decision.dispatch5, %if.end7.i.i.i.i.i.i.i, %if.else71.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i
  %retval.0.i.i.i = phi double [ %div20.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i ], [ %div34.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i ], [ %div48.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i ], [ %div62.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i ], [ %div70.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i ], [ 0x7FF0000000000000, %if.else71.i.i.i.i ], [ %div80.i.i.i.i, %if.end7.i.i.i.i.i.i.i ], [ %693, %decision.dispatch5 ], [ 0xFFF0000000000000, %if.else17.i.i.i.i ], [ %862, %fusion.common3 ], [ %923, %fusion.common11 ], [ %984, %merged.bb70 ]
  %add.i.i = fadd double %retval.0.i.i.i, 0.000000e+00
  br label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit

_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit: ; preds = %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, %lor.lhs.false2.i.i.i, %if.end8.i.i
  %retval.0.i.i = phi double [ 0x7FF8000000000000, %if.end8.i.i ], [ 0x7FF8000000000000, %lor.lhs.false2.i.i.i ], [ %add.i.i, %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i ]
  %arrayidx712 = getelementptr inbounds double, double addrspace(1)* %output.coerce, i64 %idxprom
  store double %retval.0.i.i, double addrspace(1)* %arrayidx712, align 8, !tbaa !8
  br label %if.end

if.end:                                           ; preds = %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, %entry
  ret void

merged.bb70:                                      ; preds = %merged.branch.split83, %decision.dispatch1
  %merged.select99 = phi double [ %897, %decision.dispatch1 ], [ %1029, %merged.branch.split83 ]
  %merged.select98 = phi double [ %896, %decision.dispatch1 ], [ %1030, %merged.branch.split83 ]
  %merged.select97 = phi double [ %895, %decision.dispatch1 ], [ %1031, %merged.branch.split83 ]
  %merged.select96 = phi double [ %894, %decision.dispatch1 ], [ %1032, %merged.branch.split83 ]
  %merged.select95 = phi double [ %893, %decision.dispatch1 ], [ %1033, %merged.branch.split83 ]
  %merged.select94 = phi double [ %892, %decision.dispatch1 ], [ %1034, %merged.branch.split83 ]
  %merged.select93 = phi double [ %891, %decision.dispatch1 ], [ %1035, %merged.branch.split83 ]
  %merged.select92 = phi double [ %890, %decision.dispatch1 ], [ %1036, %merged.branch.split83 ]
  %merged.select91 = phi double [ %889, %decision.dispatch1 ], [ %1037, %merged.branch.split83 ]
  %merged.select90 = phi double [ %888, %decision.dispatch1 ], [ %1038, %merged.branch.split83 ]
  %merged.select89 = phi double [ %887, %decision.dispatch1 ], [ %1039, %merged.branch.split83 ]
  %merged.select88 = phi double [ %886, %decision.dispatch1 ], [ %1040, %merged.branch.split83 ]
  %merged.select87 = phi double [ %885, %decision.dispatch1 ], [ %1041, %merged.branch.split83 ]
  %merged.select86 = phi double [ %884, %decision.dispatch1 ], [ %1042, %merged.branch.split83 ]
  %merged.select124 = phi double [ %883, %decision.dispatch1 ], [ %1043, %merged.branch.split83 ]
  %merged.select123 = phi double [ %882, %decision.dispatch1 ], [ %1044, %merged.branch.split83 ]
  %merged.select122 = phi double [ %881, %decision.dispatch1 ], [ %1045, %merged.branch.split83 ]
  %merged.select121 = phi double [ %880, %decision.dispatch1 ], [ %1046, %merged.branch.split83 ]
  %merged.select120 = phi double [ %879, %decision.dispatch1 ], [ %1047, %merged.branch.split83 ]
  %merged.select119 = phi double [ %878, %decision.dispatch1 ], [ %1048, %merged.branch.split83 ]
  %merged.select118 = phi double [ %877, %decision.dispatch1 ], [ %1049, %merged.branch.split83 ]
  %merged.select117 = phi double [ %876, %decision.dispatch1 ], [ %1050, %merged.branch.split83 ]
  %merged.select116 = phi double [ %875, %decision.dispatch1 ], [ %1051, %merged.branch.split83 ]
  %merged.select115 = phi double [ %874, %decision.dispatch1 ], [ %1052, %merged.branch.split83 ]
  %merged.select114 = phi double [ %873, %decision.dispatch1 ], [ %1053, %merged.branch.split83 ]
  %merged.select113 = phi double [ %872, %decision.dispatch1 ], [ %1054, %merged.branch.split83 ]
  %merged.select112 = phi double [ %871, %decision.dispatch1 ], [ %1055, %merged.branch.split83 ]
  %merged.select111 = phi double [ %870, %decision.dispatch1 ], [ %1056, %merged.branch.split83 ]
  %924 = fadd double %868, %869
  %925 = fadd double %811, %924
  %926 = fsub double %925, %811
  %927 = fsub double %924, %926
  %928 = fadd double %925, %809
  %929 = fsub double %928, %809
  %930 = fsub double %929, %928
  %931 = fadd double %930, %809
  %932 = fsub double %925, %929
  %933 = fadd double %932, %931
  %934 = fadd double %927, %933
  %935 = fadd double %928, %934
  %936 = tail call double @llvm.fabs.f64(double %719) #4
  %937 = fcmp oeq double %936, 0x7FF0000000000000
  %938 = select i1 %937, double %719, double %935
  %939 = fcmp olt double %719, 0.000000e+00
  %940 = select i1 %939, double 0x7FF8000000000000, double %938
  %941 = fcmp oeq double %719, 0.000000e+00
  %942 = select i1 %941, double 0xFFF0000000000000, double %940
  %943 = fmul double %942, %942
  %944 = select i1 %717, double %merged.select86, double %merged.select111
  %945 = fmul double %943, %944
  %946 = select i1 %717, double %merged.select87, double %merged.select112
  %947 = fsub double %946, %945
  %948 = select i1 %717, double %merged.select88, double %merged.select113
  %949 = fmul double %943, %948
  %950 = select i1 %717, double %merged.select89, double %merged.select114
  %951 = fsub double %950, %949
  %952 = fmul double %943, %947
  %953 = fmul double %943, %951
  %954 = select i1 %717, double %merged.select90, double %merged.select115
  %955 = fadd double %952, %954
  %956 = select i1 %717, double %merged.select91, double %merged.select116
  %957 = fadd double %953, %956
  %958 = fmul double %943, %955
  %959 = fmul double %943, %957
  %960 = select i1 %717, double %merged.select92, double %merged.select117
  %961 = fadd double %958, %960
  %962 = select i1 %717, double %merged.select93, double %merged.select118
  %963 = fadd double %959, %962
  %964 = fmul double %942, %961
  %965 = fsub double %963, %964
  %966 = select i1 %717, double %merged.select94, double %merged.select119
  %967 = fmul double %943, %966
  %968 = select i1 %717, double %merged.select95, double %merged.select120
  %969 = fadd double %967, %968
  %970 = select i1 %717, double %merged.select96, double %merged.select121
  %971 = fmul double %943, %970
  %972 = select i1 %717, double %merged.select97, double %merged.select122
  %973 = fadd double %971, %972
  %974 = fmul double %943, %969
  %975 = fmul double %943, %973
  %976 = select i1 %717, double %merged.select98, double %merged.select123
  %977 = fadd double %974, %976
  %978 = select i1 %717, double %merged.select99, double %merged.select124
  %979 = fadd double %975, %978
  %980 = fmul double %943, %977
  %981 = fadd double %980, 1.000000e+00
  %982 = fmul double %942, %979
  %983 = fsub double %981, %982
  %984 = fdiv double %965, %983
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

merged.bb:                                        ; preds = %predication.join, %if.end4.i.i.i92.i.i.i.i
  %985 = phi double [ %mul24.i.i.i129.i.i.i.i, %if.end4.i.i.i92.i.i.i.i ], [ %1000, %predication.join ]
  %986 = phi double [ %mul24.i.i.i129.i.i.i.i, %if.end4.i.i.i92.i.i.i.i ], [ %999, %predication.join ]
  %merged.select6 = select i1 %cmp26.i.i.i130.i.i.i.i, double %985, double %986
  %987 = fmul double %merged.select6, %merged.select6
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.tail, label %predication.split

predication.split:                                ; preds = %merged.bb
  %988 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %986
  %989 = fsub double %987, %988
  br label %predication.tail

predication.tail:                                 ; preds = %predication.split, %merged.bb
  %merged.select9 = phi double [ %987, %merged.bb ], [ 2.000000e+00, %predication.split ]
  %990 = phi double [ undef, %merged.bb ], [ %989, %predication.split ]
  %991 = fmul double %merged.select6, %merged.select9
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.first, label %predication.second

predication.first:                                ; preds = %predication.tail
  %992 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %991
  %993 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %992
  %994 = fadd double %991, %991
  br label %predication.join

predication.second:                               ; preds = %predication.tail
  %995 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %987
  br label %predication.join

predication.join:                                 ; preds = %predication.second, %predication.first
  %merged.select12 = phi double [ %993, %predication.first ], [ %990, %predication.second ]
  %merged.select10 = phi double [ %z.addr.i.i.i76.i.i.i.i.0, %predication.first ], [ %991, %predication.second ]
  %guard.result = phi double [ %994, %predication.first ], [ %995, %predication.second ]
  %996 = fadd double %merged.select10, %guard.result
  %997 = fdiv double %merged.select12, %996
  %998 = fsub double %986, %997
  %999 = select i1 %cmp26.i.i.i130.i.i.i.i, double undef, double %998
  %merged.select13 = select i1 %cmp26.i.i.i130.i.i.i.i, double %985, double %998
  %merged.select14 = select i1 %cmp26.i.i.i130.i.i.i.i, double %997, double 0x3EC0000000000000
  %1000 = fmul double %merged.select13, %merged.select14
  %1001 = fsub double 1.000000e+00, %997
  %merged.select15 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1001, double %997
  %1002 = tail call double @llvm.fabs.f64(double %merged.select15) #3
  %1003 = fcmp ogt double %1002, 0x3EC0000000000000
  %1004 = fcmp olt double %1000, %1002
  %guard.result28 = select i1 %cmp26.i.i.i130.i.i.i.i, i1 %1003, i1 %1004
  br i1 %guard.result28, label %merged.bb, label %merged.bb5

merged.bb5:                                       ; preds = %predication.join
  %guess.i.i.i78.i.i.i.i.3 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1000, double %998
  %1005 = fneg double %guess.i.i.i78.i.i.i.i.3
  %1006 = select i1 %cmp5.i.i.i91.i.i.i.i, double %1005, double %guess.i.i.i78.i.i.i.i.3
  br i1 %cmp11.i.i.i110.i.i.i.i, label %if.then12.i.i.i32.i.i.i.i, label %if.end23.i.i.i50.i.i.i.i

merged.bb6:                                       ; preds = %predication.join29, %if.end23.i.i.i50.i.i.i.i
  %1007 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %1022, %predication.join29 ]
  %1008 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %1021, %predication.join29 ]
  %merged.select8 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1007, double %1008
  %1009 = fmul double %merged.select8, %merged.select8
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.tail26, label %predication.split25

predication.split25:                              ; preds = %merged.bb6
  %1010 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %1008
  %1011 = fsub double %1009, %1010
  br label %predication.tail26

predication.tail26:                               ; preds = %predication.split25, %merged.bb6
  %merged.select17 = phi double [ %1009, %merged.bb6 ], [ 2.000000e+00, %predication.split25 ]
  %1012 = phi double [ undef, %merged.bb6 ], [ %1011, %predication.split25 ]
  %1013 = fmul double %merged.select8, %merged.select17
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.first27, label %predication.second28

predication.first27:                              ; preds = %predication.tail26
  %1014 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %1013
  %1015 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %1014
  %1016 = fadd double %1013, %1013
  br label %predication.join29

predication.second28:                             ; preds = %predication.tail26
  %1017 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %1009
  br label %predication.join29

predication.join29:                               ; preds = %predication.second28, %predication.first27
  %merged.select20 = phi double [ %1015, %predication.first27 ], [ %1012, %predication.second28 ]
  %merged.select18 = phi double [ %z.addr.i.i.i76.i.i.i.i.0, %predication.first27 ], [ %1013, %predication.second28 ]
  %guard.result32 = phi double [ %1016, %predication.first27 ], [ %1017, %predication.second28 ]
  %1018 = fadd double %merged.select18, %guard.result32
  %1019 = fdiv double %merged.select20, %1018
  %1020 = fsub double %1008, %1019
  %1021 = select i1 %cmp26.i.i.i130.i.i.i.i, double undef, double %1020
  %merged.select21 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1007, double %1020
  %merged.select22 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1019, double 0x3EC0000000000000
  %1022 = fmul double %merged.select21, %merged.select22
  %1023 = fsub double 1.000000e+00, %1019
  %merged.select23 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1023, double %1019
  %1024 = tail call double @llvm.fabs.f64(double %merged.select23) #3
  %1025 = fcmp ogt double %1024, 0x3EC0000000000000
  %1026 = fcmp olt double %1022, %1024
  %guard.result42 = select i1 %cmp26.i.i.i130.i.i.i.i, i1 %1025, i1 %1026
  br i1 %guard.result42, label %merged.bb6, label %merged.bb7

merged.bb7:                                       ; preds = %predication.join29
  %guess.i.i.i10.i.i.i.i.3 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1022, double %1020
  %1027 = fneg double %guess.i.i.i10.i.i.i.i.3
  %1028 = select i1 %cmp5.i.i.i91.i.i.i.i, double %1027, double %guess.i.i.i10.i.i.i.i.3
  br label %if.end7.i.i.i.i.i.i.i

merged.branch.split83:                            ; preds = %decision.dispatch1
  %1029 = select i1 %718, double 0x3FA66506CA3FCEB3, double 0x3F964BEF3074CF28
  %1030 = select i1 %718, double 0x3F478C82425FFDCE, double 0x3F275783E6F9B4DA
  %1031 = select i1 %718, double 0x3ED71590B83839D8, double 0x3EA6C7746378848A
  %1032 = select i1 %718, double 0x3DC001D96C7E2C9D, double 0x3D6F4FAB0C90F842
  %1033 = select i1 %718, double 0x3E553724D72BE5C7, double 0x3E14D76BE5BA042B
  %1034 = select i1 %718, double 0x3D0A81E9CB6A1EA5, double 0x3CA9D032740CF69A
  %1035 = select i1 %718, double 0xC0207852FA1731C0, double 0xC024F817DD06EE79
  %1036 = select i1 %718, double 0xBFD9F6368DFEFDDF, double 0xBFD06A8AF4A3FC55
  %1037 = select i1 %718, double 0xBF7F5FDEC6827012, double 0xBF63B612102F3C24
  %1038 = select i1 %718, double 0xBF1232A95F4E8466, double 0xBEE6B9C7BCE39403
  %1039 = select i1 %718, double 0xBE94B8A80FB81310, double 0xBE59BA2A0439E4A9
  %1040 = select i1 %718, double 0x3D5CB3C39661DD79, double 0x3D01A287ED1019B8
  %1041 = select i1 %718, double 0xBE050B1B8007F8FF, double 0xBDB9FC7E20BD04CC
  %1042 = select i1 %718, double 0x3C819FA1E5E36C20, double 0x3C158FD8B3C1B0C0
  %1043 = select i1 %718, double 0x3F86397D81A61D6E, double 0x3F762C8C65771E78
  %1044 = select i1 %718, double 0x3F0730EC426E6E84, double 0x3EE71602E8EA99F3
  %1045 = select i1 %718, double 0x3E768F19E4302EF3, double 0x3E46680C94743FD9
  %1046 = select i1 %718, double 0x3D1ED0326F0CBDDC, double 0x3CCE78F4A7F13C7D
  %1047 = select i1 %718, double 0x3DD49301DA58AEFA, double 0x3D9463E48A976F97
  %1048 = select i1 %718, double 0x3C495387D39D2504, double 0x3BE8FEBB5A4047D7
  %1049 = select i1 %718, double 0xC02A92BAF87A7B72, double 0xC030CB31255FFA09
  %1050 = select i1 %718, double 0xBFC4B5F131A679CC, double 0xBFBA19EDB555D8AD
  %1051 = select i1 %718, double 0xBF48C2CA21FD14A5, double 0xBF2F1E266EB4C824
  %1052 = select i1 %718, double 0xBEBC6E261AE99633, double 0xBE91D0F7FEBA5A35
  %1053 = select i1 %718, double 0xBE2007A65CA14E38, double 0xBDE40A018263D493
  %1054 = select i1 %718, double 0x3CA5D280D4B5A285, double 0x3C4B275AC5F91B68
  %1055 = select i1 %718, double 0xBD7021DF3392EE60, double 0xBD241E51766A91FB
  %1056 = select i1 %718, double 0x3BAA9A26E0297ED8, double 0x3B408480D3491A50
  br label %merged.bb70
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.frexp.exp.i32.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.frexp.mant.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i1 @llvm.amdgcn.class.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.ldexp.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rcp.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fma.v2f64(<2 x double>, <2 x double>, <2 x double>) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.abs.i32(i32, i1 immarg) #1

attributes #0 = { nofree norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="128" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }
attributes #4 = { nounwind readnone }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/charitha22/cgo22ae-darm-code.git e9bc0540325ad9806313d34e84fc901496fd8be6)"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i16 1, i16 1025}
!6 = !{}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = !{!"evaluate:%fusion.side13", !"evaluate:%fusion.side14"}
!13 = !{!"merge(evaluate:%fusion.side13,evaluate:%fusion.side14)"}
