; ModuleID = '/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-repro.XpJFTn/DCT8/compat.ll'
source_filename = "/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-benchmarks/benchmarks/DCT/dctq.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y" = type { i8 }

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1yE = comdat any

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1yE = comdat any

@Q = protected local_unnamed_addr addrspace(4) externally_initialized global [256 x i16] [i16 32, i16 33, i16 51, i16 81, i16 66, i16 39, i16 34, i16 17, i16 33, i16 36, i16 48, i16 47, i16 28, i16 23, i16 12, i16 12, i16 51, i16 48, i16 47, i16 28, i16 23, i16 12, i16 12, i16 12, i16 81, i16 47, i16 28, i16 23, i16 12, i16 12, i16 12, i16 12, i16 66, i16 28, i16 23, i16 12, i16 12, i16 12, i16 12, i16 12, i16 39, i16 23, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 34, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 17, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 32, i16 33, i16 51, i16 81, i16 66, i16 39, i16 34, i16 17, i16 33, i16 36, i16 48, i16 47, i16 28, i16 23, i16 12, i16 12, i16 51, i16 48, i16 47, i16 28, i16 23, i16 12, i16 12, i16 12, i16 81, i16 47, i16 28, i16 23, i16 12, i16 12, i16 12, i16 12, i16 66, i16 28, i16 23, i16 12, i16 12, i16 12, i16 12, i16 12, i16 39, i16 23, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 34, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 17, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 32, i16 33, i16 51, i16 81, i16 66, i16 39, i16 34, i16 17, i16 33, i16 36, i16 48, i16 47, i16 28, i16 23, i16 12, i16 12, i16 51, i16 48, i16 47, i16 28, i16 23, i16 12, i16 12, i16 12, i16 81, i16 47, i16 28, i16 23, i16 12, i16 12, i16 12, i16 12, i16 66, i16 28, i16 23, i16 12, i16 12, i16 12, i16 12, i16 12, i16 39, i16 23, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 34, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 17, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 32, i16 33, i16 51, i16 81, i16 66, i16 39, i16 34, i16 17, i16 33, i16 36, i16 48, i16 47, i16 28, i16 23, i16 12, i16 12, i16 51, i16 48, i16 47, i16 28, i16 23, i16 12, i16 12, i16 12, i16 81, i16 47, i16 28, i16 23, i16 12, i16 12, i16 12, i16 12, i16 66, i16 28, i16 23, i16 12, i16 12, i16 12, i16 12, i16 12, i16 39, i16 23, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 34, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 17, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12, i16 12], align 16
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1yE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1yE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y" undef, comdat, align 1

; Function Attrs: convergent norecurse nounwind willreturn
define protected amdgpu_kernel void @_Z27CUDAkernelQuantizationShortPsi(i16 addrspace(1)* nocapture %0, i32 %1) local_unnamed_addr #0 {
  %3 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %4 = tail call i32 @llvm.amdgcn.workgroup.id.y() #3
  %5 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %6 = tail call i32 @llvm.amdgcn.workitem.id.y() #3, !range !5
  %7 = shl nsw i32 %4, 3
  %8 = add nsw i32 %7, %6
  %9 = mul nsw i32 %8, %1
  %10 = shl nsw i32 %3, 3
  %11 = add nsw i32 %10, %5
  %12 = add nsw i32 %11, %9
  %13 = sext i32 %12 to i64
  %14 = getelementptr inbounds i16, i16 addrspace(1)* %0, i64 %13
  %15 = load i16, i16 addrspace(1)* %14, align 2, !tbaa !6
  %16 = shl nuw nsw i32 %6, 3
  %17 = add nuw nsw i32 %16, %5
  %18 = zext i32 %17 to i64
  %19 = getelementptr inbounds [256 x i16], [256 x i16] addrspace(4)* @Q, i64 0, i64 %18
  %20 = load i16, i16 addrspace(4)* %19, align 2, !tbaa !6
  %21 = icmp slt i16 %15, 0
  %22 = sext i16 %20 to i32
  %23 = ashr i16 %20, 1
  br i1 %21, label %24, label %31

24:                                               ; preds = %2
  %25 = sub i16 %23, %15
  %26 = sext i16 %25 to i32
  %27 = sdiv i32 %26, %22
  %28 = shl i32 %27, 16
  %29 = ashr exact i32 %28, 16
  %30 = sub nsw i32 0, %29
  br label %35

31:                                               ; preds = %2
  %32 = add i16 %23, %15
  %33 = sext i16 %32 to i32
  %34 = sdiv i32 %33, %22
  br label %35

35:                                               ; preds = %31, %24
  %36 = phi i32 [ %30, %24 ], [ %34, %31 ]
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %37 = trunc i32 %36 to i16
  %38 = mul i16 %20, %37
  store i16 %38, i16 addrspace(1)* %14, align 2, !tbaa !6
  ret void
}

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.y() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.y() #2

attributes #0 = { convergent norecurse nounwind willreturn "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { convergent nounwind willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i32 0, i32 1024}
!6 = !{!7, !7, i64 0}
!7 = !{!"short", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C++ TBAA"}
