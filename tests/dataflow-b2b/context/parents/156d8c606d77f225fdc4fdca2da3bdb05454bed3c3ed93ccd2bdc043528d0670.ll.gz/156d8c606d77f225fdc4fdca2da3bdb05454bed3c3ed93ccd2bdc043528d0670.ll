; ModuleID = '/data/home/chh/kernel-benchmark-suite-dataflow-b2b/build/dataflow-corpus/step7/MapAiry/anchor/trial-175/fused.ll'
source_filename = "/home/chh/kernel-benchmark-suite/cases/boost-mapairy/source/kernel.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

@_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 0x3FE428A2F98D728B, double 0x3FE965FEA53D6E3D, double 1.000000e+00, double 0x3FF428A2F98D728B, double 0x3FF965FEA53D6E3D], align 16

; Function Attrs: nofree norecurse nounwind
define protected amdgpu_kernel void @evaluate(double addrspace(1)* nocapture readonly %input.coerce, double addrspace(1)* nocapture %output.coerce, i32 %n) local_unnamed_addr #0 {
entry:
  %0 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %1 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %2 = getelementptr i8, i8 addrspace(4)* %1, i64 4
  %3 = bitcast i8 addrspace(4)* %2 to i16 addrspace(4)*
  %4 = load i16, i16 addrspace(4)* %3, align 4, !range !5, !invariant.load !6
  %5 = zext i16 %4 to i32
  %6 = mul i32 %0, %5
  %7 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !7
  %add = add i32 %6, %7
  %cmp = icmp slt i32 %add, %n
  br i1 %cmp, label %if.end8.i.i, label %if.end

if.end8.i.i:                                      ; preds = %entry
  %idxprom = sext i32 %add to i64
  %arrayidx11 = getelementptr inbounds double, double addrspace(1)* %input.coerce, i64 %idxprom
  %arrayidx.val = load double, double addrspace(1)* %arrayidx11, align 8, !tbaa !8
  %cmp.i3.i.i = fcmp olt double %arrayidx.val, 0.000000e+00
  %cmp1.i.i.i = fcmp ogt double %arrayidx.val, 1.000000e+00
  %or.cond.i.i.i = or i1 %cmp.i3.i.i, %cmp1.i.i.i
  br i1 %or.cond.i.i.i, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %lor.lhs.false2.i.i.i

lor.lhs.false2.i.i.i:                             ; preds = %if.end8.i.i
  %cmp.i.i.i.i.i = fcmp uno double %arrayidx.val, 0.000000e+00
  %cmp.i3.i.i.i.i = fcmp ogt double %arrayidx.val, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i4.i.i = fcmp olt double %arrayidx.val, 0xFFEFFFFFFFFFFFFF
  %lnot.i.i.i.i.not = or i1 %cmp.i3.i.i.i.i, %cmp1.i.i.i4.i.i
  %brmerge = or i1 %cmp.i.i.i.i.i, %lnot.i.i.i.i.not
  br i1 %brmerge, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %if.end14.i.i

if.end14.i.i:                                     ; preds = %lor.lhs.false2.i.i.i
  %cmp.i.i.i = fcmp ogt double %arrayidx.val, 5.000000e-01
  br i1 %cmp.i.i.i, label %if.then.i.i.i, label %cond.false7.i.i.i

if.then.i.i.i:                                    ; preds = %if.end14.i.i
  %sub.i.i.i = fsub double 1.000000e+00, %arrayidx.val
  %decision.interval4 = fcmp ult double %sub.i.i.i, 1.250000e-01
  br i1 %decision.interval4, label %if.else9.i.i.i.i, label %decision.dispatch3, !decision.condition_prefix !6

decision.dispatch3:                               ; preds = %if.then.i.i.i
  %cmp.i.i.i.i = fcmp ult double %sub.i.i.i, 2.500000e-01
  %8 = select i1 %cmp.i.i.i.i, double -1.250000e-01, double -2.500000e-01
  %9 = fadd double %sub.i.i.i, %8
  %10 = fmul double %9, %9
  %11 = fmul double %10, 0x409819CEF5B4E6C7
  %12 = fadd double %11, 0xC096FC492E087B38
  %13 = select i1 %cmp.i.i.i.i, double 0x4051B7FD7FEEB259, double 0x404567B47A5D8CA4
  %14 = fmul double %10, %13
  %15 = select i1 %cmp.i.i.i.i, double 0xC07E56261CB553E9, double 0x405E69E51891A050
  %16 = fsub double %15, %14
  %17 = fmul double %10, 0x4050AAC38C60A1E3
  %18 = fsub double 0x40548E4AE13E33D8, %17
  %19 = fmul double %10, %16
  %20 = select i1 %cmp.i.i.i.i, double %12, double %18
  %21 = fmul double %10, %20
  %.op = fadd double %19, 0xC04860792DC1D02E
  %22 = select i1 %cmp.i.i.i.i, double 0x4036AD73494335DA, double 0xC0407FAA65922A12
  %23 = fadd double %21, %22
  %24 = fmul double %10, %.op
  %.op1 = fadd double %19, 0x4034FFCB850049DF
  %25 = fmul double %10, %23
  %.op2 = fadd double %24, 0xC005F196AB7EF904
  %26 = select i1 %cmp.i.i.i.i, double 0x3FFB3E8B8B7EC8F9, double 0x3FDED118296B2018
  %27 = fadd double %25, %26
  %28 = select i1 %cmp.i.i.i.i, double %.op1, double %.op2
  %29 = fmul double %9, %28
  %30 = fadd double %27, %29
  br i1 %cmp.i.i.i.i, label %fusion.common11, label %fusion.side12

if.else9.i.i.i.i:                                 ; preds = %if.then.i.i.i
  %31 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %sub.i.i.i) #3
  %32 = add nsw i32 %31, -1
  %33 = fcmp uno double %sub.i.i.i, 0.000000e+00
  %34 = tail call double @llvm.fabs.f64(double %sub.i.i.i) #4
  %35 = fcmp oeq double %34, 0x7FF0000000000000
  %36 = or i1 %33, %35
  %37 = select i1 %36, i32 2147483647, i32 %32
  %38 = fcmp oeq double %sub.i.i.i, 0.000000e+00
  %39 = select i1 %38, i32 -2147483648, i32 %37
  %cmp11.i.i.i.i = icmp sgt i32 %39, -5
  br i1 %cmp11.i.i.i.i, label %if.then12.i.i.i.i, label %if.else21.i.i.i.i

if.then12.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %40 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 3) #3
  %41 = tail call double @llvm.amdgcn.frexp.mant.f64(double %40) #3
  %42 = fcmp olt double %41, 0x3FE5555555555555
  %43 = zext i1 %42 to i32
  %44 = tail call double @llvm.amdgcn.ldexp.f64(double %41, i32 %43) #3
  %45 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %40) #3
  %46 = sub nsw i32 %45, %43
  %47 = fadd double %44, -1.000000e+00
  %48 = fadd double %44, 1.000000e+00
  %49 = fsub double %48, %44
  %50 = fsub double %48, %49
  %51 = fsub double %44, %50
  %52 = fsub double 1.000000e+00, %49
  %53 = fadd double %52, %51
  %54 = tail call double @llvm.amdgcn.rcp.f64(double %48) #3
  %55 = fneg double %48
  %56 = tail call double @llvm.fma.f64(double %55, double %54, double 1.000000e+00) #3
  %57 = tail call double @llvm.fma.f64(double %56, double %54, double %54) #3
  %58 = tail call double @llvm.fma.f64(double %55, double %57, double 1.000000e+00) #3
  %59 = tail call double @llvm.fma.f64(double %58, double %57, double %57) #3
  %60 = fmul double %47, %59
  %61 = fmul double %48, %60
  %62 = fneg double %61
  %63 = tail call double @llvm.fma.f64(double %60, double %48, double %62) #3
  %64 = tail call double @llvm.fma.f64(double %60, double %53, double %63) #3
  %65 = fadd double %61, %64
  %66 = fsub double %65, %61
  %67 = fsub double %64, %66
  %68 = fsub double %47, %65
  %69 = fsub double %47, %68
  %70 = fsub double %69, %65
  %71 = fsub double %70, %67
  %72 = fadd double %68, %71
  %73 = fmul double %59, %72
  %74 = fadd double %60, %73
  %75 = fsub double %74, %60
  %76 = fsub double %73, %75
  %77 = fmul double %74, %74
  %78 = fneg double %77
  %79 = tail call double @llvm.fma.f64(double %74, double %74, double %78) #3
  %80 = fmul double %76, 2.000000e+00
  %81 = tail call double @llvm.fma.f64(double %74, double %80, double %79) #3
  %82 = tail call double @llvm.fma.f64(double %76, double %76, double %81) #3
  %83 = fadd double %77, %82
  %84 = fsub double %83, %77
  %85 = fsub double %82, %84
  %86 = tail call double @llvm.fma.f64(double %83, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %87 = tail call double @llvm.fma.f64(double %83, double %86, double 0x3FC7474DD7F4DF2E) #3
  %88 = tail call double @llvm.fma.f64(double %83, double %87, double 0x3FCC71C016291751) #3
  %89 = tail call double @llvm.fma.f64(double %83, double %88, double 0x3FD249249B27ACF1) #3
  %90 = tail call double @llvm.fma.f64(double %83, double %89, double 0x3FD99999998EF7B6) #3
  %91 = tail call double @llvm.fma.f64(double %83, double %90, double 0x3FE5555555555780) #3
  %92 = tail call double @llvm.amdgcn.ldexp.f64(double %74, i32 1) #3
  %93 = tail call double @llvm.amdgcn.ldexp.f64(double %76, i32 1) #3
  %94 = fmul double %74, %83
  %95 = fneg double %94
  %96 = tail call double @llvm.fma.f64(double %74, double %83, double %95) #3
  %97 = fmul double %76, %83
  %98 = tail call double @llvm.fma.f64(double %74, double %85, double %97) #3
  %99 = fadd double %96, %98
  %100 = fadd double %94, %99
  %101 = fsub double %100, %94
  %102 = fsub double %99, %101
  %103 = fmul double %100, %91
  %104 = fneg double %103
  %105 = tail call double @llvm.fma.f64(double %100, double %91, double %104) #3
  %106 = tail call double @llvm.fma.f64(double %102, double %91, double %105) #3
  %107 = fadd double %103, %106
  %108 = fsub double %107, %103
  %109 = fsub double %106, %108
  %110 = fadd double %92, %107
  %111 = fsub double %110, %92
  %112 = fsub double %110, %111
  %113 = fsub double %92, %112
  %114 = fsub double %107, %111
  %115 = fadd double %114, %113
  %116 = fadd double %93, %109
  %117 = fsub double %116, %93
  %118 = fsub double %116, %117
  %119 = fsub double %93, %118
  %120 = fsub double %109, %117
  %121 = fadd double %120, %119
  %122 = fadd double %116, %115
  %123 = fadd double %110, %122
  %124 = fsub double %123, %110
  %125 = fsub double %122, %124
  %126 = fadd double %121, %125
  %127 = fadd double %123, %126
  %128 = fsub double %127, %123
  %129 = fsub double %126, %128
  %130 = sitofp i32 %46 to double
  %131 = fmul double %127, 0x3FF71547652B82FE
  %132 = fneg double %131
  %133 = fmul double %127, 0x3C7777D0FFDA0D24
  %134 = insertelement <2 x double> undef, double %127, i32 0
  %135 = insertelement <2 x double> %134, double %129, i32 1
  %136 = insertelement <2 x double> undef, double %132, i32 0
  %137 = insertelement <2 x double> %136, double %133, i32 1
  %138 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %135, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %137) #3
  %139 = extractelement <2 x double> %138, i32 0
  %140 = extractelement <2 x double> %138, i32 1
  %141 = fadd double %139, %140
  %142 = fadd double %131, %141
  %143 = fsub double %142, %131
  %144 = fsub double %141, %143
  %145 = fadd double %142, %130
  %146 = fsub double %145, %130
  %147 = fsub double %146, %145
  %148 = fadd double %147, %130
  %149 = fsub double %142, %146
  %150 = fadd double %149, %148
  %151 = fadd double %144, %150
  %152 = fadd double %145, %151
  %153 = tail call double @llvm.fabs.f64(double %40) #4
  %154 = fcmp oeq double %153, 0x7FF0000000000000
  %155 = select i1 %154, double %40, double %152
  %156 = fcmp olt double %40, 0.000000e+00
  %157 = select i1 %156, double 0x7FF8000000000000, double %155
  %158 = fcmp oeq double %40, 0.000000e+00
  %159 = select i1 %158, double 0xFFF0000000000000, double %157
  %mul.i.i682.i.i.i.i = fmul double %159, %159
  %mul1.i.i683.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3ED3E1F985CBB733
  %add.i.i684.i.i.i.i = fadd double %mul1.i.i683.i.i.i.i, 0x3F385DA443F57737
  %mul5.i.i685.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F24E9382EAABDBB
  %add7.i.i686.i.i.i.i = fadd double %mul5.i.i685.i.i.i.i, 0x3F77E2A342AA4E3B
  %mul10.i.i687.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i684.i.i.i.i
  %mul12.i.i688.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i686.i.i.i.i
  %add15.i.i689.i.i.i.i = fadd double %mul10.i.i687.i.i.i.i, 0x3F9808F2B640E69B
  %add18.i.i690.i.i.i.i = fadd double %mul12.i.i688.i.i.i.i, 0x3F9DD5C523A6CF6D
  %mul20.i.i691.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i689.i.i.i.i
  %mul22.i.i692.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i690.i.i.i.i
  %add25.i.i693.i.i.i.i = fadd double %mul20.i.i691.i.i.i.i, 0x3FD3E6D375851610
  %add28.i.i694.i.i.i.i = fadd double %mul22.i.i692.i.i.i.i, 0x3FDB3E8B8B7EC8FA
  %160 = fmul double %159, %add25.i.i693.i.i.i.i
  %add33.i.i696.i.i.i.i = fsub double %add28.i.i694.i.i.i.i, %160
  %mul1.i.i668.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3EF03AD80F271435
  %add.i.i669.i.i.i.i = fadd double %mul1.i.i668.i.i.i.i, 0x3F577B23357A1929
  %mul5.i.i670.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F27C5B13F4BAFF2
  %add7.i.i671.i.i.i.i = fadd double %mul5.i.i670.i.i.i.i, 0x3F825620F70E4E86
  %mul10.i.i672.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i669.i.i.i.i
  %mul12.i.i673.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i671.i.i.i.i
  %add15.i.i674.i.i.i.i = fadd double %mul10.i.i672.i.i.i.i, 0x3FA38976FFA62DF3
  %add18.i.i675.i.i.i.i = fadd double %mul12.i.i673.i.i.i.i, 0x3FBACD3553111974
  %mul20.i.i676.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i674.i.i.i.i
  %mul22.i.i677.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i675.i.i.i.i
  %add25.i.i678.i.i.i.i = fadd double %mul20.i.i676.i.i.i.i, 0x3FDA8C1A7A09CF75
  %add28.i.i679.i.i.i.i = fadd double %mul22.i.i677.i.i.i.i, 1.000000e+00
  %161 = fmul double %159, %add25.i.i678.i.i.i.i
  %add33.i.i681.i.i.i.i = fsub double %add28.i.i679.i.i.i.i, %161
  %mul.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i590.i.i.i.i = fcmp ogt double %mul.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i591.i.i.i.i = fcmp oeq double %mul.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i592.i.i.i.i = or i1 %cmp.i.i.i.i590.i.i.i.i, %cmp.i.i.i591.i.i.i.i
  br i1 %or.cond.i.i.i592.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end.i.i.i594.i.i.i.i

if.end.i.i.i594.i.i.i.i:                          ; preds = %if.then12.i.i.i.i
  %cmp.i.i.i.i.i593.i.i.i.i = fcmp uno double %mul.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i593.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end7.i.i.i620.i.i.i.i

if.end7.i.i.i620.i.i.i.i:                         ; preds = %if.end.i.i.i594.i.i.i.i
  %162 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul.i.i.i.i) #3
  %163 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul.i.i.i.i) #3
  %164 = tail call i1 @llvm.amdgcn.class.f64(double %mul.i.i.i.i, i32 519) #3
  %165 = select i1 %164, i32 0, i32 %162
  %166 = select i1 %164, double %mul.i.i.i.i, double %163
  %mul.i.i.i.i.i606.i.i.i.i = fmul double %166, %166
  %mul1.i.i.i.i.i607.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i608.i.i.i.i = fadd double %mul1.i.i.i.i.i607.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i609.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FE479D17050CA47
  %167 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i609.i.i.i.i
  %mul10.i.i.i.i.i611.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %add.i.i.i.i.i608.i.i.i.i
  %mul12.i.i.i.i.i612.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %167
  %add15.i.i.i.i.i613.i.i.i.i = fadd double %mul10.i.i.i.i.i611.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i614.i.i.i.i = fadd double %mul12.i.i.i.i.i612.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i615.i.i.i.i = fmul double %166, %add15.i.i.i.i.i613.i.i.i.i
  %add23.i.i.i.i.i616.i.i.i.i = fadd double %add18.i.i.i.i.i614.i.i.i.i, %mul20.i.i.i.i.i615.i.i.i.i
  %.frozen = freeze i32 %165
  %div.i.i.i617.i.i.i.i = sdiv i32 %.frozen, 3
  %168 = call i32 @llvm.abs.i32(i32 %div.i.i.i617.i.i.i.i, i1 true)
  %cmp11.i.i.i619.i.i.i.i = icmp ugt i32 %168, 63
  %cmp13.i.i.i621.i.i.i.i = icmp sgt i32 %165, 2
  %decision.take = or i1 %cmp11.i.i.i619.i.i.i.i, %cmp13.i.i.i621.i.i.i.i
  %169 = sub nsw i32 0, %div.i.i.i617.i.i.i.i
  %fusion.paired.v = select i1 %decision.take, i32 %div.i.i.i617.i.i.i.i, i32 %169
  %fusion.paired = zext i32 %fusion.paired.v to i64
  %170 = shl nuw i64 1, %fusion.paired
  %171 = uitofp i64 %170 to double
  br i1 %decision.take, label %fusion.side4, label %fusion.side5

fusion.side4:                                     ; preds = %if.end7.i.i.i620.i.i.i.i
  %172 = fmul double %add23.i.i.i.i.i616.i.i.i.i, %171
  %173 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i616.i.i.i.i, i32 %div.i.i.i617.i.i.i.i) #3
  %174 = select i1 %cmp11.i.i.i619.i.i.i.i, double %173, double %172
  br label %if.end23.i.i.i640.i.i.i.i

fusion.side5:                                     ; preds = %if.end7.i.i.i620.i.i.i.i
  %175 = fdiv double %add23.i.i.i.i.i616.i.i.i.i, %171
  br label %if.end23.i.i.i640.i.i.i.i

if.end23.i.i.i640.i.i.i.i:                        ; preds = %fusion.side5, %fusion.side4
  %guess.i.i.i589.i.i.i.i.0 = phi double [ %174, %fusion.side4 ], [ %175, %fusion.side5 ]
  %.neg6 = mul nsw i32 %div.i.i.i617.i.i.i.i, -3
  %rem.i.i.i635.i.i.i.i.decomposed = add i32 %.frozen, 2
  %add.i.i.i636.i.i.i.i = add i32 %rem.i.i.i635.i.i.i.i.decomposed, %.neg6
  %176 = zext i32 %add.i.i.i636.i.i.i.i to i64
  %arrayidx1.i.i.i637.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %176
  %177 = load double, double addrspace(4)* %arrayidx1.i.i.i637.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i638.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.0, %177
  %cmp26.i.i.i639.i.i.i.i = icmp slt i32 %165, 1021
  br i1 %cmp26.i.i.i639.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i

do.body.i.i.i651.i.i.i.i:                         ; preds = %do.body.i.i.i651.i.i.i.i, %if.end23.i.i.i640.i.i.i.i
  %guess.i.i.i589.i.i.i.i.1 = phi double [ %mul24.i.i.i638.i.i.i.i, %if.end23.i.i.i640.i.i.i.i ], [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ]
  %mul28.i.i.i641.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %guess.i.i.i589.i.i.i.i.1
  %mul29.i.i.i642.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %mul28.i.i.i641.i.i.i.i
  %add30.i.i.i643.i.i.i.i = fadd double %mul.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add31.i.i.i644.i.i.i.i = fadd double %mul.i.i.i.i, %add30.i.i.i643.i.i.i.i
  %add32.i.i.i645.i.i.i.i = fadd double %mul29.i.i.i642.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add33.i.i.i646.i.i.i.i = fadd double %mul.i.i.i.i, %add32.i.i.i645.i.i.i.i
  %div34.i.i.i647.i.i.i.i = fdiv double %add31.i.i.i644.i.i.i.i, %add33.i.i.i646.i.i.i.i
  %mul35.i.i.i648.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %div34.i.i.i647.i.i.i.i
  %sub36.i.i.i649.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i647.i.i.i.i
  %178 = tail call double @llvm.fabs.f64(double %sub36.i.i.i649.i.i.i.i) #3
  %cmp38.i.i.i650.i.i.i.i = fcmp ogt double %178, 0x3EC0000000000000
  br i1 %cmp38.i.i.i650.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

do.body40.i.i.i662.i.i.i.i:                       ; preds = %do.body40.i.i.i662.i.i.i.i, %if.end23.i.i.i640.i.i.i.i
  %guess.i.i.i589.i.i.i.i.2 = phi double [ %mul24.i.i.i638.i.i.i.i, %if.end23.i.i.i640.i.i.i.i ], [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ]
  %mul41.i.i.i652.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, %guess.i.i.i589.i.i.i.i.2
  %div42.i.i.i653.i.i.i.i = fdiv double %mul.i.i.i.i, %guess.i.i.i589.i.i.i.i.2
  %sub43.i.i.i654.i.i.i.i = fsub double %mul41.i.i.i652.i.i.i.i, %div42.i.i.i653.i.i.i.i
  %mul44.i.i.i655.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i656.i.i.i.i = fdiv double %mul.i.i.i.i, %mul41.i.i.i652.i.i.i.i
  %add46.i.i.i657.i.i.i.i = fadd double %mul44.i.i.i655.i.i.i.i, %div45.i.i.i656.i.i.i.i
  %div47.i.i.i658.i.i.i.i = fdiv double %sub43.i.i.i654.i.i.i.i, %add46.i.i.i657.i.i.i.i
  %sub48.i.i.i659.i.i.i.i = fsub double %guess.i.i.i589.i.i.i.i.2, %div47.i.i.i658.i.i.i.i
  %mul50.i.i.i660.i.i.i.i = fmul double %sub48.i.i.i659.i.i.i.i, 0x3EC0000000000000
  %179 = tail call double @llvm.fabs.f64(double %div47.i.i.i658.i.i.i.i) #3
  %cmp52.i.i.i661.i.i.i.i = fcmp olt double %mul50.i.i.i660.i.i.i.i, %179
  br i1 %cmp52.i.i.i661.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i: ; preds = %do.body40.i.i.i662.i.i.i.i, %do.body.i.i.i651.i.i.i.i, %if.end.i.i.i594.i.i.i.i, %if.then12.i.i.i.i
  %retval.0.i.i.i665.i.i.i.i = phi double [ %mul.i.i.i.i, %if.then12.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i594.i.i.i.i ], [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ], [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ]
  %mul19.i.i.i.i = fmul double %add33.i.i681.i.i.i.i, %retval.0.i.i.i665.i.i.i.i
  %div20.i.i.i.i = fdiv double %add33.i.i696.i.i.i.i, %mul19.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else21.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %cmp23.i.i.i.i = icmp sgt i32 %39, -9
  br i1 %cmp23.i.i.i.i, label %if.then24.i.i.i.i, label %if.else35.i.i.i.i

if.then24.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %180 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 4) #3
  %181 = tail call double @llvm.amdgcn.frexp.mant.f64(double %180) #3
  %182 = fcmp olt double %181, 0x3FE5555555555555
  %183 = zext i1 %182 to i32
  %184 = tail call double @llvm.amdgcn.ldexp.f64(double %181, i32 %183) #3
  %185 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %180) #3
  %186 = sub nsw i32 %185, %183
  %187 = fadd double %184, -1.000000e+00
  %188 = fadd double %184, 1.000000e+00
  %189 = fsub double %188, %184
  %190 = fsub double %188, %189
  %191 = fsub double %184, %190
  %192 = fsub double 1.000000e+00, %189
  %193 = fadd double %192, %191
  %194 = tail call double @llvm.amdgcn.rcp.f64(double %188) #3
  %195 = fneg double %188
  %196 = tail call double @llvm.fma.f64(double %195, double %194, double 1.000000e+00) #3
  %197 = tail call double @llvm.fma.f64(double %196, double %194, double %194) #3
  %198 = tail call double @llvm.fma.f64(double %195, double %197, double 1.000000e+00) #3
  %199 = tail call double @llvm.fma.f64(double %198, double %197, double %197) #3
  %200 = fmul double %187, %199
  %201 = fmul double %188, %200
  %202 = fneg double %201
  %203 = tail call double @llvm.fma.f64(double %200, double %188, double %202) #3
  %204 = tail call double @llvm.fma.f64(double %200, double %193, double %203) #3
  %205 = fadd double %201, %204
  %206 = fsub double %205, %201
  %207 = fsub double %204, %206
  %208 = fsub double %187, %205
  %209 = fsub double %187, %208
  %210 = fsub double %209, %205
  %211 = fsub double %210, %207
  %212 = fadd double %208, %211
  %213 = fmul double %199, %212
  %214 = fadd double %200, %213
  %215 = fsub double %214, %200
  %216 = fsub double %213, %215
  %217 = fmul double %214, %214
  %218 = fneg double %217
  %219 = tail call double @llvm.fma.f64(double %214, double %214, double %218) #3
  %220 = fmul double %216, 2.000000e+00
  %221 = tail call double @llvm.fma.f64(double %214, double %220, double %219) #3
  %222 = tail call double @llvm.fma.f64(double %216, double %216, double %221) #3
  %223 = fadd double %217, %222
  %224 = fsub double %223, %217
  %225 = fsub double %222, %224
  %226 = tail call double @llvm.fma.f64(double %223, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %227 = tail call double @llvm.fma.f64(double %223, double %226, double 0x3FC7474DD7F4DF2E) #3
  %228 = tail call double @llvm.fma.f64(double %223, double %227, double 0x3FCC71C016291751) #3
  %229 = tail call double @llvm.fma.f64(double %223, double %228, double 0x3FD249249B27ACF1) #3
  %230 = tail call double @llvm.fma.f64(double %223, double %229, double 0x3FD99999998EF7B6) #3
  %231 = tail call double @llvm.fma.f64(double %223, double %230, double 0x3FE5555555555780) #3
  %232 = tail call double @llvm.amdgcn.ldexp.f64(double %214, i32 1) #3
  %233 = tail call double @llvm.amdgcn.ldexp.f64(double %216, i32 1) #3
  %234 = fmul double %214, %223
  %235 = fneg double %234
  %236 = tail call double @llvm.fma.f64(double %214, double %223, double %235) #3
  %237 = fmul double %216, %223
  %238 = tail call double @llvm.fma.f64(double %214, double %225, double %237) #3
  %239 = fadd double %236, %238
  %240 = fadd double %234, %239
  %241 = fsub double %240, %234
  %242 = fsub double %239, %241
  %243 = fmul double %240, %231
  %244 = fneg double %243
  %245 = tail call double @llvm.fma.f64(double %240, double %231, double %244) #3
  %246 = tail call double @llvm.fma.f64(double %242, double %231, double %245) #3
  %247 = fadd double %243, %246
  %248 = fsub double %247, %243
  %249 = fsub double %246, %248
  %250 = fadd double %232, %247
  %251 = fsub double %250, %232
  %252 = fsub double %250, %251
  %253 = fsub double %232, %252
  %254 = fsub double %247, %251
  %255 = fadd double %254, %253
  %256 = fadd double %233, %249
  %257 = fsub double %256, %233
  %258 = fsub double %256, %257
  %259 = fsub double %233, %258
  %260 = fsub double %249, %257
  %261 = fadd double %260, %259
  %262 = fadd double %256, %255
  %263 = fadd double %250, %262
  %264 = fsub double %263, %250
  %265 = fsub double %262, %264
  %266 = fadd double %261, %265
  %267 = fadd double %263, %266
  %268 = fsub double %267, %263
  %269 = fsub double %266, %268
  %270 = sitofp i32 %186 to double
  %271 = fmul double %267, 0x3FF71547652B82FE
  %272 = fneg double %271
  %273 = fmul double %267, 0x3C7777D0FFDA0D24
  %274 = insertelement <2 x double> undef, double %267, i32 0
  %275 = insertelement <2 x double> %274, double %269, i32 1
  %276 = insertelement <2 x double> undef, double %272, i32 0
  %277 = insertelement <2 x double> %276, double %273, i32 1
  %278 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %275, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %277) #3
  %279 = extractelement <2 x double> %278, i32 0
  %280 = extractelement <2 x double> %278, i32 1
  %281 = fadd double %279, %280
  %282 = fadd double %271, %281
  %283 = fsub double %282, %271
  %284 = fsub double %281, %283
  %285 = fadd double %282, %270
  %286 = fsub double %285, %270
  %287 = fsub double %286, %285
  %288 = fadd double %287, %270
  %289 = fsub double %282, %286
  %290 = fadd double %289, %288
  %291 = fadd double %284, %290
  %292 = fadd double %285, %291
  %293 = tail call double @llvm.fabs.f64(double %180) #4
  %294 = fcmp oeq double %293, 0x7FF0000000000000
  %295 = select i1 %294, double %180, double %292
  %296 = fcmp olt double %180, 0.000000e+00
  %297 = select i1 %296, double 0x7FF8000000000000, double %295
  %298 = fcmp oeq double %180, 0.000000e+00
  %299 = select i1 %298, double 0xFFF0000000000000, double %297
  %mul.i.i565.i.i.i.i = fmul double %299, %299
  %mul1.i.i566.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3E919A5BE1262808
  %add.i.i567.i.i.i.i = fadd double %mul1.i.i566.i.i.i.i, 0x3F07A5175B4661FC
  %mul5.i.i568.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3ED3058F91E15D9E
  %add7.i.i569.i.i.i.i = fadd double %mul5.i.i568.i.i.i.i, 0x3F360A6A52B6CEE1
  %mul10.i.i570.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i567.i.i.i.i
  %mul12.i.i571.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i569.i.i.i.i
  %add15.i.i572.i.i.i.i = fadd double %mul10.i.i570.i.i.i.i, 0x3F5C5B8FA36BAEC3
  %add18.i.i573.i.i.i.i = fadd double %mul12.i.i571.i.i.i.i, 0x3F80EDCAE3A5BFEE
  %mul20.i.i574.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i572.i.i.i.i
  %mul22.i.i575.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i573.i.i.i.i
  %add25.i.i576.i.i.i.i = fadd double %mul20.i.i574.i.i.i.i, 0x3F9A5E78F653B833
  %add28.i.i577.i.i.i.i = fadd double %mul22.i.i575.i.i.i.i, 0x3FB5AC2080A26513
  %mul30.i.i578.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i576.i.i.i.i
  %mul32.i.i579.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i577.i.i.i.i
  %add35.i.i580.i.i.i.i = fadd double %mul30.i.i578.i.i.i.i, 0x3FC65686F7A4EE22
  %add38.i.i581.i.i.i.i = fadd double %mul32.i.i579.i.i.i.i, 0x3FD3F40EF6582604
  %mul40.i.i582.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i580.i.i.i.i
  %add43.i.i583.i.i.i.i = fadd double %mul40.i.i582.i.i.i.i, 0x3FE03C236600AD0B
  %300 = fmul double %299, %add38.i.i581.i.i.i.i
  %add48.i.i585.i.i.i.i = fsub double %add43.i.i583.i.i.i.i, %300
  %mul1.i.i547.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EA0457562E8B20F
  %add.i.i548.i.i.i.i = fadd double %mul1.i.i547.i.i.i.i, 0x3F16154BBE28AEB9
  %mul5.i.i549.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EE174949F46ED05
  %add7.i.i550.i.i.i.i = fadd double %mul5.i.i549.i.i.i.i, 0x3F43E3B25F7FFBED
  %mul10.i.i551.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i548.i.i.i.i
  %mul12.i.i552.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i550.i.i.i.i
  %add15.i.i553.i.i.i.i = fadd double %mul10.i.i551.i.i.i.i, 0x3F6B2284D418EE28
  %add18.i.i554.i.i.i.i = fadd double %mul12.i.i552.i.i.i.i, 0x3F8DC663E91E38DD
  %mul20.i.i555.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i553.i.i.i.i
  %mul22.i.i556.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i554.i.i.i.i
  %add25.i.i557.i.i.i.i = fadd double %mul20.i.i555.i.i.i.i, 0x3FA9F261B3019817
  %add28.i.i558.i.i.i.i = fadd double %mul22.i.i556.i.i.i.i, 0x3FC29CC24A62017B
  %mul30.i.i559.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i557.i.i.i.i
  %mul32.i.i560.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i558.i.i.i.i
  %add35.i.i561.i.i.i.i = fadd double %mul30.i.i559.i.i.i.i, 0x3FD660DD0F65AD11
  %add38.i.i562.i.i.i.i = fadd double %mul32.i.i560.i.i.i.i, 0x3FE0E738E979F959
  %mul40.i.i563.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i561.i.i.i.i
  %add43.i.i564.i.i.i.i = fadd double %mul40.i.i563.i.i.i.i, 1.000000e+00
  %301 = fmul double %299, %add38.i.i562.i.i.i.i
  %add48.i.i.i.i.i.i = fsub double %add43.i.i564.i.i.i.i, %301
  %mul31.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i469.i.i.i.i = fcmp ogt double %mul31.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i470.i.i.i.i = fcmp oeq double %mul31.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i471.i.i.i.i = or i1 %cmp.i.i.i.i469.i.i.i.i, %cmp.i.i.i470.i.i.i.i
  br i1 %or.cond.i.i.i471.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end.i.i.i473.i.i.i.i

if.end.i.i.i473.i.i.i.i:                          ; preds = %if.then24.i.i.i.i
  %cmp.i.i.i.i.i472.i.i.i.i = fcmp uno double %mul31.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i472.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end7.i.i.i499.i.i.i.i

if.end7.i.i.i499.i.i.i.i:                         ; preds = %if.end.i.i.i473.i.i.i.i
  %302 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul31.i.i.i.i) #3
  %303 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul31.i.i.i.i) #3
  %304 = tail call i1 @llvm.amdgcn.class.f64(double %mul31.i.i.i.i, i32 519) #3
  %305 = select i1 %304, i32 0, i32 %302
  %306 = select i1 %304, double %mul31.i.i.i.i, double %303
  %mul.i.i.i.i.i485.i.i.i.i = fmul double %306, %306
  %mul1.i.i.i.i.i486.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i487.i.i.i.i = fadd double %mul1.i.i.i.i.i486.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i488.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FE479D17050CA47
  %307 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i488.i.i.i.i
  %mul10.i.i.i.i.i490.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %add.i.i.i.i.i487.i.i.i.i
  %mul12.i.i.i.i.i491.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %307
  %add15.i.i.i.i.i492.i.i.i.i = fadd double %mul10.i.i.i.i.i490.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i493.i.i.i.i = fadd double %mul12.i.i.i.i.i491.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i494.i.i.i.i = fmul double %306, %add15.i.i.i.i.i492.i.i.i.i
  %add23.i.i.i.i.i495.i.i.i.i = fadd double %add18.i.i.i.i.i493.i.i.i.i, %mul20.i.i.i.i.i494.i.i.i.i
  %.frozen209 = freeze i32 %305
  %div.i.i.i496.i.i.i.i = sdiv i32 %.frozen209, 3
  %308 = call i32 @llvm.abs.i32(i32 %div.i.i.i496.i.i.i.i, i1 true)
  %cmp11.i.i.i498.i.i.i.i = icmp ugt i32 %308, 63
  %cmp13.i.i.i500.i.i.i.i = icmp sgt i32 %305, 2
  %decision.take1 = or i1 %cmp11.i.i.i498.i.i.i.i, %cmp13.i.i.i500.i.i.i.i
  %309 = sub nsw i32 0, %div.i.i.i496.i.i.i.i
  %fusion.paired2.v = select i1 %decision.take1, i32 %div.i.i.i496.i.i.i.i, i32 %309
  %fusion.paired2 = zext i32 %fusion.paired2.v to i64
  %310 = shl nuw i64 1, %fusion.paired2
  %311 = uitofp i64 %310 to double
  br i1 %decision.take1, label %fusion.side6, label %fusion.side7

fusion.side6:                                     ; preds = %if.end7.i.i.i499.i.i.i.i
  %312 = fmul double %add23.i.i.i.i.i495.i.i.i.i, %311
  %313 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i495.i.i.i.i, i32 %div.i.i.i496.i.i.i.i) #3
  %314 = select i1 %cmp11.i.i.i498.i.i.i.i, double %313, double %312
  br label %if.end23.i.i.i519.i.i.i.i

fusion.side7:                                     ; preds = %if.end7.i.i.i499.i.i.i.i
  %315 = fdiv double %add23.i.i.i.i.i495.i.i.i.i, %311
  br label %if.end23.i.i.i519.i.i.i.i

if.end23.i.i.i519.i.i.i.i:                        ; preds = %fusion.side7, %fusion.side6
  %guess.i.i.i468.i.i.i.i.0 = phi double [ %314, %fusion.side6 ], [ %315, %fusion.side7 ]
  %.neg5 = mul nsw i32 %div.i.i.i496.i.i.i.i, -3
  %rem.i.i.i514.i.i.i.i.decomposed = add i32 %.frozen209, 2
  %add.i.i.i515.i.i.i.i = add i32 %rem.i.i.i514.i.i.i.i.decomposed, %.neg5
  %316 = zext i32 %add.i.i.i515.i.i.i.i to i64
  %arrayidx1.i.i.i516.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %316
  %317 = load double, double addrspace(4)* %arrayidx1.i.i.i516.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i517.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.0, %317
  %cmp26.i.i.i518.i.i.i.i = icmp slt i32 %305, 1021
  br i1 %cmp26.i.i.i518.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i

do.body.i.i.i530.i.i.i.i:                         ; preds = %do.body.i.i.i530.i.i.i.i, %if.end23.i.i.i519.i.i.i.i
  %guess.i.i.i468.i.i.i.i.1 = phi double [ %mul24.i.i.i517.i.i.i.i, %if.end23.i.i.i519.i.i.i.i ], [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ]
  %mul28.i.i.i520.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %guess.i.i.i468.i.i.i.i.1
  %mul29.i.i.i521.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %mul28.i.i.i520.i.i.i.i
  %add30.i.i.i522.i.i.i.i = fadd double %mul31.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add31.i.i.i523.i.i.i.i = fadd double %mul31.i.i.i.i, %add30.i.i.i522.i.i.i.i
  %add32.i.i.i524.i.i.i.i = fadd double %mul29.i.i.i521.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add33.i.i.i525.i.i.i.i = fadd double %mul31.i.i.i.i, %add32.i.i.i524.i.i.i.i
  %div34.i.i.i526.i.i.i.i = fdiv double %add31.i.i.i523.i.i.i.i, %add33.i.i.i525.i.i.i.i
  %mul35.i.i.i527.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %div34.i.i.i526.i.i.i.i
  %sub36.i.i.i528.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i526.i.i.i.i
  %318 = tail call double @llvm.fabs.f64(double %sub36.i.i.i528.i.i.i.i) #3
  %cmp38.i.i.i529.i.i.i.i = fcmp ogt double %318, 0x3EC0000000000000
  br i1 %cmp38.i.i.i529.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

do.body40.i.i.i541.i.i.i.i:                       ; preds = %do.body40.i.i.i541.i.i.i.i, %if.end23.i.i.i519.i.i.i.i
  %guess.i.i.i468.i.i.i.i.2 = phi double [ %mul24.i.i.i517.i.i.i.i, %if.end23.i.i.i519.i.i.i.i ], [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ]
  %mul41.i.i.i531.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, %guess.i.i.i468.i.i.i.i.2
  %div42.i.i.i532.i.i.i.i = fdiv double %mul31.i.i.i.i, %guess.i.i.i468.i.i.i.i.2
  %sub43.i.i.i533.i.i.i.i = fsub double %mul41.i.i.i531.i.i.i.i, %div42.i.i.i532.i.i.i.i
  %mul44.i.i.i534.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i535.i.i.i.i = fdiv double %mul31.i.i.i.i, %mul41.i.i.i531.i.i.i.i
  %add46.i.i.i536.i.i.i.i = fadd double %mul44.i.i.i534.i.i.i.i, %div45.i.i.i535.i.i.i.i
  %div47.i.i.i537.i.i.i.i = fdiv double %sub43.i.i.i533.i.i.i.i, %add46.i.i.i536.i.i.i.i
  %sub48.i.i.i538.i.i.i.i = fsub double %guess.i.i.i468.i.i.i.i.2, %div47.i.i.i537.i.i.i.i
  %mul50.i.i.i539.i.i.i.i = fmul double %sub48.i.i.i538.i.i.i.i, 0x3EC0000000000000
  %319 = tail call double @llvm.fabs.f64(double %div47.i.i.i537.i.i.i.i) #3
  %cmp52.i.i.i540.i.i.i.i = fcmp olt double %mul50.i.i.i539.i.i.i.i, %319
  br i1 %cmp52.i.i.i540.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i: ; preds = %do.body40.i.i.i541.i.i.i.i, %do.body.i.i.i530.i.i.i.i, %if.end.i.i.i473.i.i.i.i, %if.then24.i.i.i.i
  %retval.0.i.i.i544.i.i.i.i = phi double [ %mul31.i.i.i.i, %if.then24.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i473.i.i.i.i ], [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ], [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ]
  %mul33.i.i.i.i = fmul double %add48.i.i.i.i.i.i, %retval.0.i.i.i544.i.i.i.i
  %div34.i.i.i.i = fdiv double %add48.i.i585.i.i.i.i, %mul33.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else35.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %cmp37.i.i.i.i = icmp sgt i32 %39, -17
  br i1 %cmp37.i.i.i.i, label %if.then38.i.i.i.i, label %if.else49.i.i.i.i

if.then38.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %320 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 8) #3
  %321 = tail call double @llvm.amdgcn.frexp.mant.f64(double %320) #3
  %322 = fcmp olt double %321, 0x3FE5555555555555
  %323 = zext i1 %322 to i32
  %324 = tail call double @llvm.amdgcn.ldexp.f64(double %321, i32 %323) #3
  %325 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %320) #3
  %326 = sub nsw i32 %325, %323
  %327 = fadd double %324, -1.000000e+00
  %328 = fadd double %324, 1.000000e+00
  %329 = fsub double %328, %324
  %330 = fsub double %328, %329
  %331 = fsub double %324, %330
  %332 = fsub double 1.000000e+00, %329
  %333 = fadd double %332, %331
  %334 = tail call double @llvm.amdgcn.rcp.f64(double %328) #3
  %335 = fneg double %328
  %336 = tail call double @llvm.fma.f64(double %335, double %334, double 1.000000e+00) #3
  %337 = tail call double @llvm.fma.f64(double %336, double %334, double %334) #3
  %338 = tail call double @llvm.fma.f64(double %335, double %337, double 1.000000e+00) #3
  %339 = tail call double @llvm.fma.f64(double %338, double %337, double %337) #3
  %340 = fmul double %327, %339
  %341 = fmul double %328, %340
  %342 = fneg double %341
  %343 = tail call double @llvm.fma.f64(double %340, double %328, double %342) #3
  %344 = tail call double @llvm.fma.f64(double %340, double %333, double %343) #3
  %345 = fadd double %341, %344
  %346 = fsub double %345, %341
  %347 = fsub double %344, %346
  %348 = fsub double %327, %345
  %349 = fsub double %327, %348
  %350 = fsub double %349, %345
  %351 = fsub double %350, %347
  %352 = fadd double %348, %351
  %353 = fmul double %339, %352
  %354 = fadd double %340, %353
  %355 = fsub double %354, %340
  %356 = fsub double %353, %355
  %357 = fmul double %354, %354
  %358 = fneg double %357
  %359 = tail call double @llvm.fma.f64(double %354, double %354, double %358) #3
  %360 = fmul double %356, 2.000000e+00
  %361 = tail call double @llvm.fma.f64(double %354, double %360, double %359) #3
  %362 = tail call double @llvm.fma.f64(double %356, double %356, double %361) #3
  %363 = fadd double %357, %362
  %364 = fsub double %363, %357
  %365 = fsub double %362, %364
  %366 = tail call double @llvm.fma.f64(double %363, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %367 = tail call double @llvm.fma.f64(double %363, double %366, double 0x3FC7474DD7F4DF2E) #3
  %368 = tail call double @llvm.fma.f64(double %363, double %367, double 0x3FCC71C016291751) #3
  %369 = tail call double @llvm.fma.f64(double %363, double %368, double 0x3FD249249B27ACF1) #3
  %370 = tail call double @llvm.fma.f64(double %363, double %369, double 0x3FD99999998EF7B6) #3
  %371 = tail call double @llvm.fma.f64(double %363, double %370, double 0x3FE5555555555780) #3
  %372 = tail call double @llvm.amdgcn.ldexp.f64(double %354, i32 1) #3
  %373 = tail call double @llvm.amdgcn.ldexp.f64(double %356, i32 1) #3
  %374 = fmul double %354, %363
  %375 = fneg double %374
  %376 = tail call double @llvm.fma.f64(double %354, double %363, double %375) #3
  %377 = fmul double %356, %363
  %378 = tail call double @llvm.fma.f64(double %354, double %365, double %377) #3
  %379 = fadd double %376, %378
  %380 = fadd double %374, %379
  %381 = fsub double %380, %374
  %382 = fsub double %379, %381
  %383 = fmul double %380, %371
  %384 = fneg double %383
  %385 = tail call double @llvm.fma.f64(double %380, double %371, double %384) #3
  %386 = tail call double @llvm.fma.f64(double %382, double %371, double %385) #3
  %387 = fadd double %383, %386
  %388 = fsub double %387, %383
  %389 = fsub double %386, %388
  %390 = fadd double %372, %387
  %391 = fsub double %390, %372
  %392 = fsub double %390, %391
  %393 = fsub double %372, %392
  %394 = fsub double %387, %391
  %395 = fadd double %394, %393
  %396 = fadd double %373, %389
  %397 = fsub double %396, %373
  %398 = fsub double %396, %397
  %399 = fsub double %373, %398
  %400 = fsub double %389, %397
  %401 = fadd double %400, %399
  %402 = fadd double %396, %395
  %403 = fadd double %390, %402
  %404 = fsub double %403, %390
  %405 = fsub double %402, %404
  %406 = fadd double %401, %405
  %407 = fadd double %403, %406
  %408 = fsub double %407, %403
  %409 = fsub double %406, %408
  %410 = sitofp i32 %326 to double
  %411 = fmul double %407, 0x3FF71547652B82FE
  %412 = fneg double %411
  %413 = fmul double %407, 0x3C7777D0FFDA0D24
  %414 = insertelement <2 x double> undef, double %407, i32 0
  %415 = insertelement <2 x double> %414, double %409, i32 1
  %416 = insertelement <2 x double> undef, double %412, i32 0
  %417 = insertelement <2 x double> %416, double %413, i32 1
  %418 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %415, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %417) #3
  %419 = extractelement <2 x double> %418, i32 0
  %420 = extractelement <2 x double> %418, i32 1
  %421 = fadd double %419, %420
  %422 = fadd double %411, %421
  %423 = fsub double %422, %411
  %424 = fsub double %421, %423
  %425 = fadd double %422, %410
  %426 = fsub double %425, %410
  %427 = fsub double %426, %425
  %428 = fadd double %427, %410
  %429 = fsub double %422, %426
  %430 = fadd double %429, %428
  %431 = fadd double %424, %430
  %432 = fadd double %425, %431
  %433 = tail call double @llvm.fabs.f64(double %320) #4
  %434 = fcmp oeq double %433, 0x7FF0000000000000
  %435 = select i1 %434, double %320, double %432
  %436 = fcmp olt double %320, 0.000000e+00
  %437 = select i1 %436, double 0x7FF8000000000000, double %435
  %438 = fcmp oeq double %320, 0.000000e+00
  %439 = select i1 %438, double 0xFFF0000000000000, double %437
  %mul.i.i450.i.i.i.i = fmul double %439, %439
  %mul1.i.i451.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3D1C49F35743D651
  %add.i.i452.i.i.i.i = fadd double %mul1.i.i451.i.i.i.i, 0x3EC5BDF8ABE0C4D2
  %mul5.i.i453.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E74DE722017F09B
  %add7.i.i454.i.i.i.i = fadd double %mul5.i.i453.i.i.i.i, 0x3F08B20867234AE0
  %mul10.i.i455.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i452.i.i.i.i
  %mul12.i.i456.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i454.i.i.i.i
  %add15.i.i457.i.i.i.i = fadd double %mul10.i.i455.i.i.i.i, 0x3F43291C59111954
  %add18.i.i458.i.i.i.i = fadd double %mul12.i.i456.i.i.i.i, 0x3F7555F81DC90AE6
  %mul20.i.i459.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i457.i.i.i.i
  %mul22.i.i460.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i458.i.i.i.i
  %add25.i.i461.i.i.i.i = fadd double %mul20.i.i459.i.i.i.i, 0x3FA118409603E368
  %add28.i.i462.i.i.i.i = fadd double %mul22.i.i460.i.i.i.i, 0x3FC2F812CF93403D
  %mul30.i.i463.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i461.i.i.i.i
  %mul32.i.i.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add28.i.i462.i.i.i.i
  %add35.i.i.i.i.i.i = fadd double %mul30.i.i463.i.i.i.i, 0x3FDA4ECF31EE23E1
  %add38.i.i464.i.i.i.i = fadd double %mul32.i.i.i.i.i.i, 0x3FE15637BD9C1C6C
  %440 = fmul double %439, %add35.i.i.i.i.i.i
  %add43.i.i.i.i.i.i = fsub double %add38.i.i464.i.i.i.i, %440
  %mul1.i.i434.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E834146FFF39045
  %add.i.i435.i.i.i.i = fadd double %mul1.i.i434.i.i.i.i, 0x3F16C942D4A0C545
  %mul5.i.i436.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3ED40F287F6755C5
  %add7.i.i437.i.i.i.i = fadd double %mul5.i.i436.i.i.i.i, 0x3F51AD434F5D94BA
  %mul10.i.i438.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i435.i.i.i.i
  %mul12.i.i439.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i437.i.i.i.i
  %add15.i.i440.i.i.i.i = fadd double %mul10.i.i438.i.i.i.i, 0x3F83AFF5A756295F
  %add18.i.i441.i.i.i.i = fadd double %mul12.i.i439.i.i.i.i, 0x3FAF8A313C5B71D0
  %mul20.i.i442.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i440.i.i.i.i
  %mul22.i.i443.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i441.i.i.i.i
  %add25.i.i444.i.i.i.i = fadd double %mul20.i.i442.i.i.i.i, 0x3FD1813788B6276A
  %add28.i.i445.i.i.i.i = fadd double %mul22.i.i443.i.i.i.i, 0x3FE84455F48DB67F
  %mul30.i.i446.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i444.i.i.i.i
  %add33.i.i447.i.i.i.i = fadd double %mul30.i.i446.i.i.i.i, 1.000000e+00
  %441 = fmul double %439, %add28.i.i445.i.i.i.i
  %add38.i.i449.i.i.i.i = fsub double %add33.i.i447.i.i.i.i, %441
  %mul45.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i356.i.i.i.i = fcmp ogt double %mul45.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i357.i.i.i.i = fcmp oeq double %mul45.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i358.i.i.i.i = or i1 %cmp.i.i.i.i356.i.i.i.i, %cmp.i.i.i357.i.i.i.i
  br i1 %or.cond.i.i.i358.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end.i.i.i360.i.i.i.i

if.end.i.i.i360.i.i.i.i:                          ; preds = %if.then38.i.i.i.i
  %cmp.i.i.i.i.i359.i.i.i.i = fcmp uno double %mul45.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i359.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end7.i.i.i386.i.i.i.i

if.end7.i.i.i386.i.i.i.i:                         ; preds = %if.end.i.i.i360.i.i.i.i
  %442 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul45.i.i.i.i) #3
  %443 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul45.i.i.i.i) #3
  %444 = tail call i1 @llvm.amdgcn.class.f64(double %mul45.i.i.i.i, i32 519) #3
  %445 = select i1 %444, i32 0, i32 %442
  %446 = select i1 %444, double %mul45.i.i.i.i, double %443
  %mul.i.i.i.i.i372.i.i.i.i = fmul double %446, %446
  %mul1.i.i.i.i.i373.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i374.i.i.i.i = fadd double %mul1.i.i.i.i.i373.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i375.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FE479D17050CA47
  %447 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i375.i.i.i.i
  %mul10.i.i.i.i.i377.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %add.i.i.i.i.i374.i.i.i.i
  %mul12.i.i.i.i.i378.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %447
  %add15.i.i.i.i.i379.i.i.i.i = fadd double %mul10.i.i.i.i.i377.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i380.i.i.i.i = fadd double %mul12.i.i.i.i.i378.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i381.i.i.i.i = fmul double %446, %add15.i.i.i.i.i379.i.i.i.i
  %add23.i.i.i.i.i382.i.i.i.i = fadd double %add18.i.i.i.i.i380.i.i.i.i, %mul20.i.i.i.i.i381.i.i.i.i
  %.frozen210 = freeze i32 %445
  %div.i.i.i383.i.i.i.i = sdiv i32 %.frozen210, 3
  %448 = call i32 @llvm.abs.i32(i32 %div.i.i.i383.i.i.i.i, i1 true)
  %cmp11.i.i.i385.i.i.i.i = icmp ugt i32 %448, 63
  %cmp13.i.i.i387.i.i.i.i = icmp sgt i32 %445, 2
  %decision.take2 = or i1 %cmp11.i.i.i385.i.i.i.i, %cmp13.i.i.i387.i.i.i.i
  %449 = sub nsw i32 0, %div.i.i.i383.i.i.i.i
  %fusion.paired3.v = select i1 %decision.take2, i32 %div.i.i.i383.i.i.i.i, i32 %449
  %fusion.paired3 = zext i32 %fusion.paired3.v to i64
  %450 = shl nuw i64 1, %fusion.paired3
  %451 = uitofp i64 %450 to double
  br i1 %decision.take2, label %fusion.side8, label %fusion.side9

fusion.side8:                                     ; preds = %if.end7.i.i.i386.i.i.i.i
  %452 = fmul double %add23.i.i.i.i.i382.i.i.i.i, %451
  %453 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i382.i.i.i.i, i32 %div.i.i.i383.i.i.i.i) #3
  %454 = select i1 %cmp11.i.i.i385.i.i.i.i, double %453, double %452
  br label %if.end23.i.i.i406.i.i.i.i

fusion.side9:                                     ; preds = %if.end7.i.i.i386.i.i.i.i
  %455 = fdiv double %add23.i.i.i.i.i382.i.i.i.i, %451
  br label %if.end23.i.i.i406.i.i.i.i

if.end23.i.i.i406.i.i.i.i:                        ; preds = %fusion.side9, %fusion.side8
  %guess.i.i.i355.i.i.i.i.0 = phi double [ %454, %fusion.side8 ], [ %455, %fusion.side9 ]
  %.neg4 = mul nsw i32 %div.i.i.i383.i.i.i.i, -3
  %rem.i.i.i401.i.i.i.i.decomposed = add i32 %.frozen210, 2
  %add.i.i.i402.i.i.i.i = add i32 %rem.i.i.i401.i.i.i.i.decomposed, %.neg4
  %456 = zext i32 %add.i.i.i402.i.i.i.i to i64
  %arrayidx1.i.i.i403.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %456
  %457 = load double, double addrspace(4)* %arrayidx1.i.i.i403.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i404.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.0, %457
  %cmp26.i.i.i405.i.i.i.i = icmp slt i32 %445, 1021
  br i1 %cmp26.i.i.i405.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i

do.body.i.i.i417.i.i.i.i:                         ; preds = %do.body.i.i.i417.i.i.i.i, %if.end23.i.i.i406.i.i.i.i
  %guess.i.i.i355.i.i.i.i.1 = phi double [ %mul24.i.i.i404.i.i.i.i, %if.end23.i.i.i406.i.i.i.i ], [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ]
  %mul28.i.i.i407.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %guess.i.i.i355.i.i.i.i.1
  %mul29.i.i.i408.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %mul28.i.i.i407.i.i.i.i
  %add30.i.i.i409.i.i.i.i = fadd double %mul45.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add31.i.i.i410.i.i.i.i = fadd double %mul45.i.i.i.i, %add30.i.i.i409.i.i.i.i
  %add32.i.i.i411.i.i.i.i = fadd double %mul29.i.i.i408.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add33.i.i.i412.i.i.i.i = fadd double %mul45.i.i.i.i, %add32.i.i.i411.i.i.i.i
  %div34.i.i.i413.i.i.i.i = fdiv double %add31.i.i.i410.i.i.i.i, %add33.i.i.i412.i.i.i.i
  %mul35.i.i.i414.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %div34.i.i.i413.i.i.i.i
  %sub36.i.i.i415.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i413.i.i.i.i
  %458 = tail call double @llvm.fabs.f64(double %sub36.i.i.i415.i.i.i.i) #3
  %cmp38.i.i.i416.i.i.i.i = fcmp ogt double %458, 0x3EC0000000000000
  br i1 %cmp38.i.i.i416.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

do.body40.i.i.i428.i.i.i.i:                       ; preds = %do.body40.i.i.i428.i.i.i.i, %if.end23.i.i.i406.i.i.i.i
  %guess.i.i.i355.i.i.i.i.2 = phi double [ %mul24.i.i.i404.i.i.i.i, %if.end23.i.i.i406.i.i.i.i ], [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ]
  %mul41.i.i.i418.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, %guess.i.i.i355.i.i.i.i.2
  %div42.i.i.i419.i.i.i.i = fdiv double %mul45.i.i.i.i, %guess.i.i.i355.i.i.i.i.2
  %sub43.i.i.i420.i.i.i.i = fsub double %mul41.i.i.i418.i.i.i.i, %div42.i.i.i419.i.i.i.i
  %mul44.i.i.i421.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i422.i.i.i.i = fdiv double %mul45.i.i.i.i, %mul41.i.i.i418.i.i.i.i
  %add46.i.i.i423.i.i.i.i = fadd double %mul44.i.i.i421.i.i.i.i, %div45.i.i.i422.i.i.i.i
  %div47.i.i.i424.i.i.i.i = fdiv double %sub43.i.i.i420.i.i.i.i, %add46.i.i.i423.i.i.i.i
  %sub48.i.i.i425.i.i.i.i = fsub double %guess.i.i.i355.i.i.i.i.2, %div47.i.i.i424.i.i.i.i
  %mul50.i.i.i426.i.i.i.i = fmul double %sub48.i.i.i425.i.i.i.i, 0x3EC0000000000000
  %459 = tail call double @llvm.fabs.f64(double %div47.i.i.i424.i.i.i.i) #3
  %cmp52.i.i.i427.i.i.i.i = fcmp olt double %mul50.i.i.i426.i.i.i.i, %459
  br i1 %cmp52.i.i.i427.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i: ; preds = %do.body40.i.i.i428.i.i.i.i, %do.body.i.i.i417.i.i.i.i, %if.end.i.i.i360.i.i.i.i, %if.then38.i.i.i.i
  %retval.0.i.i.i431.i.i.i.i = phi double [ %mul45.i.i.i.i, %if.then38.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i360.i.i.i.i ], [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ], [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ]
  %mul47.i.i.i.i = fmul double %add38.i.i449.i.i.i.i, %retval.0.i.i.i431.i.i.i.i
  %div48.i.i.i.i = fdiv double %add43.i.i.i.i.i.i, %mul47.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else49.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %cmp51.i.i.i.i = icmp sgt i32 %39, -33
  br i1 %cmp51.i.i.i.i, label %if.then52.i.i.i.i, label %if.else63.i.i.i.i

if.then52.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %460 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 16) #3
  %461 = tail call double @llvm.amdgcn.frexp.mant.f64(double %460) #3
  %462 = fcmp olt double %461, 0x3FE5555555555555
  %463 = zext i1 %462 to i32
  %464 = tail call double @llvm.amdgcn.ldexp.f64(double %461, i32 %463) #3
  %465 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %460) #3
  %466 = sub nsw i32 %465, %463
  %467 = fadd double %464, -1.000000e+00
  %468 = fadd double %464, 1.000000e+00
  %469 = fsub double %468, %464
  %470 = fsub double %468, %469
  %471 = fsub double %464, %470
  %472 = fsub double 1.000000e+00, %469
  %473 = fadd double %472, %471
  %474 = tail call double @llvm.amdgcn.rcp.f64(double %468) #3
  %475 = fneg double %468
  %476 = tail call double @llvm.fma.f64(double %475, double %474, double 1.000000e+00) #3
  %477 = tail call double @llvm.fma.f64(double %476, double %474, double %474) #3
  %478 = tail call double @llvm.fma.f64(double %475, double %477, double 1.000000e+00) #3
  %479 = tail call double @llvm.fma.f64(double %478, double %477, double %477) #3
  %480 = fmul double %467, %479
  %481 = fmul double %468, %480
  %482 = fneg double %481
  %483 = tail call double @llvm.fma.f64(double %480, double %468, double %482) #3
  %484 = tail call double @llvm.fma.f64(double %480, double %473, double %483) #3
  %485 = fadd double %481, %484
  %486 = fsub double %485, %481
  %487 = fsub double %484, %486
  %488 = fsub double %467, %485
  %489 = fsub double %467, %488
  %490 = fsub double %489, %485
  %491 = fsub double %490, %487
  %492 = fadd double %488, %491
  %493 = fmul double %479, %492
  %494 = fadd double %480, %493
  %495 = fsub double %494, %480
  %496 = fsub double %493, %495
  %497 = fmul double %494, %494
  %498 = fneg double %497
  %499 = tail call double @llvm.fma.f64(double %494, double %494, double %498) #3
  %500 = fmul double %496, 2.000000e+00
  %501 = tail call double @llvm.fma.f64(double %494, double %500, double %499) #3
  %502 = tail call double @llvm.fma.f64(double %496, double %496, double %501) #3
  %503 = fadd double %497, %502
  %504 = fsub double %503, %497
  %505 = fsub double %502, %504
  %506 = tail call double @llvm.fma.f64(double %503, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %507 = tail call double @llvm.fma.f64(double %503, double %506, double 0x3FC7474DD7F4DF2E) #3
  %508 = tail call double @llvm.fma.f64(double %503, double %507, double 0x3FCC71C016291751) #3
  %509 = tail call double @llvm.fma.f64(double %503, double %508, double 0x3FD249249B27ACF1) #3
  %510 = tail call double @llvm.fma.f64(double %503, double %509, double 0x3FD99999998EF7B6) #3
  %511 = tail call double @llvm.fma.f64(double %503, double %510, double 0x3FE5555555555780) #3
  %512 = tail call double @llvm.amdgcn.ldexp.f64(double %494, i32 1) #3
  %513 = tail call double @llvm.amdgcn.ldexp.f64(double %496, i32 1) #3
  %514 = fmul double %494, %503
  %515 = fneg double %514
  %516 = tail call double @llvm.fma.f64(double %494, double %503, double %515) #3
  %517 = fmul double %496, %503
  %518 = tail call double @llvm.fma.f64(double %494, double %505, double %517) #3
  %519 = fadd double %516, %518
  %520 = fadd double %514, %519
  %521 = fsub double %520, %514
  %522 = fsub double %519, %521
  %523 = fmul double %520, %511
  %524 = fneg double %523
  %525 = tail call double @llvm.fma.f64(double %520, double %511, double %524) #3
  %526 = tail call double @llvm.fma.f64(double %522, double %511, double %525) #3
  %527 = fadd double %523, %526
  %528 = fsub double %527, %523
  %529 = fsub double %526, %528
  %530 = fadd double %512, %527
  %531 = fsub double %530, %512
  %532 = fsub double %530, %531
  %533 = fsub double %512, %532
  %534 = fsub double %527, %531
  %535 = fadd double %534, %533
  %536 = fadd double %513, %529
  %537 = fsub double %536, %513
  %538 = fsub double %536, %537
  %539 = fsub double %513, %538
  %540 = fsub double %529, %537
  %541 = fadd double %540, %539
  %542 = fadd double %536, %535
  %543 = fadd double %530, %542
  %544 = fsub double %543, %530
  %545 = fsub double %542, %544
  %546 = fadd double %541, %545
  %547 = fadd double %543, %546
  %548 = fsub double %547, %543
  %549 = fsub double %546, %548
  %550 = sitofp i32 %466 to double
  %551 = fmul double %547, 0x3FF71547652B82FE
  %552 = fneg double %551
  %553 = fmul double %547, 0x3C7777D0FFDA0D24
  %554 = insertelement <2 x double> undef, double %547, i32 0
  %555 = insertelement <2 x double> %554, double %549, i32 1
  %556 = insertelement <2 x double> undef, double %552, i32 0
  %557 = insertelement <2 x double> %556, double %553, i32 1
  %558 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %555, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %557) #3
  %559 = extractelement <2 x double> %558, i32 0
  %560 = extractelement <2 x double> %558, i32 1
  %561 = fadd double %559, %560
  %562 = fadd double %551, %561
  %563 = fsub double %562, %551
  %564 = fsub double %561, %563
  %565 = fadd double %562, %550
  %566 = fsub double %565, %550
  %567 = fsub double %566, %565
  %568 = fadd double %567, %550
  %569 = fsub double %562, %566
  %570 = fadd double %569, %568
  %571 = fadd double %564, %570
  %572 = fadd double %565, %571
  %573 = tail call double @llvm.fabs.f64(double %460) #4
  %574 = fcmp oeq double %573, 0x7FF0000000000000
  %575 = select i1 %574, double %460, double %572
  %576 = fcmp olt double %460, 0.000000e+00
  %577 = select i1 %576, double 0x7FF8000000000000, double %575
  %578 = fcmp oeq double %460, 0.000000e+00
  %579 = select i1 %578, double 0xFFF0000000000000, double %577
  %mul.i.i335.i.i.i.i = fmul double %579, %579
  %mul1.i.i336.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EBF7344DBF5E403
  %add.i.i337.i.i.i.i = fadd double %mul1.i.i336.i.i.i.i, 0x3F2CFF1E2D54E4E7
  %mul5.i.i338.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EEF8CF23CAED047
  %add7.i.i339.i.i.i.i = fadd double %mul5.i.i338.i.i.i.i, 0x3F5CF8F0FF9B6F59
  %mul10.i.i340.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i337.i.i.i.i
  %mul12.i.i341.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i339.i.i.i.i
  %add15.i.i342.i.i.i.i = fadd double %mul10.i.i340.i.i.i.i, 0x3F8857AD74D33625
  %add18.i.i343.i.i.i.i = fadd double %mul12.i.i341.i.i.i.i, 0x3FAE52179C3AEDE6
  %mul20.i.i344.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i342.i.i.i.i
  %mul22.i.i345.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i343.i.i.i.i
  %add25.i.i346.i.i.i.i = fadd double %mul20.i.i344.i.i.i.i, 0x3FCB21A22303D8FC
  %add28.i.i347.i.i.i.i = fadd double %mul22.i.i345.i.i.i.i, 0x3FDF29CE00A8804B
  %mul30.i.i348.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i346.i.i.i.i
  %add33.i.i349.i.i.i.i = fadd double %mul30.i.i348.i.i.i.i, 0x3FE15775564555E5
  %580 = fmul double %579, %add28.i.i347.i.i.i.i
  %add38.i.i351.i.i.i.i = fsub double %add33.i.i349.i.i.i.i, %580
  %mul1.i.i321.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3ECD04621671DBCE
  %add.i.i322.i.i.i.i = fadd double %mul1.i.i321.i.i.i.i, 0x3F3AC0D433DC2A4E
  %mul5.i.i323.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EFD1C12EAA62BE9
  %add7.i.i324.i.i.i.i = fadd double %mul5.i.i323.i.i.i.i, 0x3F6ABB215A001E96
  %mul10.i.i325.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i322.i.i.i.i
  %mul12.i.i326.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i324.i.i.i.i
  %add15.i.i327.i.i.i.i = fadd double %mul10.i.i325.i.i.i.i, 0x3F967590758A1B1A
  %add18.i.i328.i.i.i.i = fadd double %mul12.i.i326.i.i.i.i, 0x3FBBF9941AE7DFDE
  %mul20.i.i329.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i327.i.i.i.i
  %mul22.i.i330.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i328.i.i.i.i
  %add25.i.i331.i.i.i.i = fadd double %mul20.i.i329.i.i.i.i, 0x3FD90848F242167F
  %add28.i.i332.i.i.i.i = fadd double %mul22.i.i330.i.i.i.i, 0x3FECC09A37BCEE76
  %mul30.i.i333.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i331.i.i.i.i
  %add33.i.i334.i.i.i.i = fadd double %mul30.i.i333.i.i.i.i, 1.000000e+00
  %581 = fmul double %579, %add28.i.i332.i.i.i.i
  %add38.i.i.i.i.i.i = fsub double %add33.i.i334.i.i.i.i, %581
  %mul59.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i243.i.i.i.i = fcmp ogt double %mul59.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i244.i.i.i.i = fcmp oeq double %mul59.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i245.i.i.i.i = or i1 %cmp.i.i.i.i243.i.i.i.i, %cmp.i.i.i244.i.i.i.i
  br i1 %or.cond.i.i.i245.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end.i.i.i247.i.i.i.i

if.end.i.i.i247.i.i.i.i:                          ; preds = %if.then52.i.i.i.i
  %cmp.i.i.i.i.i246.i.i.i.i = fcmp uno double %mul59.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i246.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end7.i.i.i273.i.i.i.i

if.end7.i.i.i273.i.i.i.i:                         ; preds = %if.end.i.i.i247.i.i.i.i
  %582 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul59.i.i.i.i) #3
  %583 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul59.i.i.i.i) #3
  %584 = tail call i1 @llvm.amdgcn.class.f64(double %mul59.i.i.i.i, i32 519) #3
  %585 = select i1 %584, i32 0, i32 %582
  %586 = select i1 %584, double %mul59.i.i.i.i, double %583
  %mul.i.i.i.i.i259.i.i.i.i = fmul double %586, %586
  %mul1.i.i.i.i.i260.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i261.i.i.i.i = fadd double %mul1.i.i.i.i.i260.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i262.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FE479D17050CA47
  %587 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i262.i.i.i.i
  %mul10.i.i.i.i.i264.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %add.i.i.i.i.i261.i.i.i.i
  %mul12.i.i.i.i.i265.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %587
  %add15.i.i.i.i.i266.i.i.i.i = fadd double %mul10.i.i.i.i.i264.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i267.i.i.i.i = fadd double %mul12.i.i.i.i.i265.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i268.i.i.i.i = fmul double %586, %add15.i.i.i.i.i266.i.i.i.i
  %add23.i.i.i.i.i269.i.i.i.i = fadd double %add18.i.i.i.i.i267.i.i.i.i, %mul20.i.i.i.i.i268.i.i.i.i
  %.frozen211 = freeze i32 %585
  %div.i.i.i270.i.i.i.i = sdiv i32 %.frozen211, 3
  %588 = call i32 @llvm.abs.i32(i32 %div.i.i.i270.i.i.i.i, i1 true)
  %cmp11.i.i.i272.i.i.i.i = icmp ugt i32 %588, 63
  %cmp13.i.i.i274.i.i.i.i = icmp sgt i32 %585, 2
  %decision.take3 = or i1 %cmp11.i.i.i272.i.i.i.i, %cmp13.i.i.i274.i.i.i.i
  %589 = sub nsw i32 0, %div.i.i.i270.i.i.i.i
  %fusion.paired5.v = select i1 %decision.take3, i32 %div.i.i.i270.i.i.i.i, i32 %589
  %fusion.paired5 = zext i32 %fusion.paired5.v to i64
  %590 = shl nuw i64 1, %fusion.paired5
  %591 = uitofp i64 %590 to double
  br i1 %decision.take3, label %fusion.side10, label %fusion.side11

fusion.side10:                                    ; preds = %if.end7.i.i.i273.i.i.i.i
  %592 = fmul double %add23.i.i.i.i.i269.i.i.i.i, %591
  %593 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i269.i.i.i.i, i32 %div.i.i.i270.i.i.i.i) #3
  %594 = select i1 %cmp11.i.i.i272.i.i.i.i, double %593, double %592
  br label %if.end23.i.i.i293.i.i.i.i

fusion.side11:                                    ; preds = %if.end7.i.i.i273.i.i.i.i
  %595 = fdiv double %add23.i.i.i.i.i269.i.i.i.i, %591
  br label %if.end23.i.i.i293.i.i.i.i

if.end23.i.i.i293.i.i.i.i:                        ; preds = %fusion.side11, %fusion.side10
  %guess.i.i.i242.i.i.i.i.0 = phi double [ %594, %fusion.side10 ], [ %595, %fusion.side11 ]
  %.neg3 = mul nsw i32 %div.i.i.i270.i.i.i.i, -3
  %rem.i.i.i288.i.i.i.i.decomposed = add i32 %.frozen211, 2
  %add.i.i.i289.i.i.i.i = add i32 %rem.i.i.i288.i.i.i.i.decomposed, %.neg3
  %596 = zext i32 %add.i.i.i289.i.i.i.i to i64
  %arrayidx1.i.i.i290.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %596
  %597 = load double, double addrspace(4)* %arrayidx1.i.i.i290.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i291.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.0, %597
  %cmp26.i.i.i292.i.i.i.i = icmp slt i32 %585, 1021
  br i1 %cmp26.i.i.i292.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i

do.body.i.i.i304.i.i.i.i:                         ; preds = %do.body.i.i.i304.i.i.i.i, %if.end23.i.i.i293.i.i.i.i
  %guess.i.i.i242.i.i.i.i.1 = phi double [ %mul24.i.i.i291.i.i.i.i, %if.end23.i.i.i293.i.i.i.i ], [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ]
  %mul28.i.i.i294.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %guess.i.i.i242.i.i.i.i.1
  %mul29.i.i.i295.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %mul28.i.i.i294.i.i.i.i
  %add30.i.i.i296.i.i.i.i = fadd double %mul59.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add31.i.i.i297.i.i.i.i = fadd double %mul59.i.i.i.i, %add30.i.i.i296.i.i.i.i
  %add32.i.i.i298.i.i.i.i = fadd double %mul29.i.i.i295.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add33.i.i.i299.i.i.i.i = fadd double %mul59.i.i.i.i, %add32.i.i.i298.i.i.i.i
  %div34.i.i.i300.i.i.i.i = fdiv double %add31.i.i.i297.i.i.i.i, %add33.i.i.i299.i.i.i.i
  %mul35.i.i.i301.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %div34.i.i.i300.i.i.i.i
  %sub36.i.i.i302.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i300.i.i.i.i
  %598 = tail call double @llvm.fabs.f64(double %sub36.i.i.i302.i.i.i.i) #3
  %cmp38.i.i.i303.i.i.i.i = fcmp ogt double %598, 0x3EC0000000000000
  br i1 %cmp38.i.i.i303.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

do.body40.i.i.i315.i.i.i.i:                       ; preds = %do.body40.i.i.i315.i.i.i.i, %if.end23.i.i.i293.i.i.i.i
  %guess.i.i.i242.i.i.i.i.2 = phi double [ %mul24.i.i.i291.i.i.i.i, %if.end23.i.i.i293.i.i.i.i ], [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ]
  %mul41.i.i.i305.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, %guess.i.i.i242.i.i.i.i.2
  %div42.i.i.i306.i.i.i.i = fdiv double %mul59.i.i.i.i, %guess.i.i.i242.i.i.i.i.2
  %sub43.i.i.i307.i.i.i.i = fsub double %mul41.i.i.i305.i.i.i.i, %div42.i.i.i306.i.i.i.i
  %mul44.i.i.i308.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i309.i.i.i.i = fdiv double %mul59.i.i.i.i, %mul41.i.i.i305.i.i.i.i
  %add46.i.i.i310.i.i.i.i = fadd double %mul44.i.i.i308.i.i.i.i, %div45.i.i.i309.i.i.i.i
  %div47.i.i.i311.i.i.i.i = fdiv double %sub43.i.i.i307.i.i.i.i, %add46.i.i.i310.i.i.i.i
  %sub48.i.i.i312.i.i.i.i = fsub double %guess.i.i.i242.i.i.i.i.2, %div47.i.i.i311.i.i.i.i
  %mul50.i.i.i313.i.i.i.i = fmul double %sub48.i.i.i312.i.i.i.i, 0x3EC0000000000000
  %599 = tail call double @llvm.fabs.f64(double %div47.i.i.i311.i.i.i.i) #3
  %cmp52.i.i.i314.i.i.i.i = fcmp olt double %mul50.i.i.i313.i.i.i.i, %599
  br i1 %cmp52.i.i.i314.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i: ; preds = %do.body40.i.i.i315.i.i.i.i, %do.body.i.i.i304.i.i.i.i, %if.end.i.i.i247.i.i.i.i, %if.then52.i.i.i.i
  %retval.0.i.i.i318.i.i.i.i = phi double [ %mul59.i.i.i.i, %if.then52.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i247.i.i.i.i ], [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ], [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ]
  %mul61.i.i.i.i = fmul double %add38.i.i.i.i.i.i, %retval.0.i.i.i318.i.i.i.i
  %div62.i.i.i.i = fdiv double %add38.i.i351.i.i.i.i, %mul61.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else63.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %mul64.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp1.i.i.i.i.i = fcmp oge double %mul64.i.i.i.i, 0x10000000000000
  %cmp2.i.i.i.i.i = fcmp ole double %mul64.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %600 = and i1 %cmp1.i.i.i.i.i, %cmp2.i.i.i.i.i
  br i1 %600, label %if.then66.i.i.i.i, label %if.else71.i.i.i.i

if.then66.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %mul68.i.i.i.i = fmul double %mul64.i.i.i.i, 0x401921FB54442D18
  %cmp.i.i.i.i162.i.i.i.i = fcmp ogt double %mul68.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i163.i.i.i.i = fcmp oeq double %mul68.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i164.i.i.i.i = or i1 %cmp.i.i.i.i162.i.i.i.i, %cmp.i.i.i163.i.i.i.i
  br i1 %or.cond.i.i.i164.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end.i.i.i166.i.i.i.i

if.end.i.i.i166.i.i.i.i:                          ; preds = %if.then66.i.i.i.i
  %cmp.i.i.i.i.i165.i.i.i.i = fcmp uno double %mul68.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i165.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end7.i.i.i192.i.i.i.i

if.end7.i.i.i192.i.i.i.i:                         ; preds = %if.end.i.i.i166.i.i.i.i
  %601 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul68.i.i.i.i) #3
  %602 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul68.i.i.i.i) #3
  %603 = tail call i1 @llvm.amdgcn.class.f64(double %mul68.i.i.i.i, i32 519) #3
  %604 = select i1 %603, i32 0, i32 %601
  %605 = select i1 %603, double %mul68.i.i.i.i, double %602
  %mul.i.i.i.i.i178.i.i.i.i = fmul double %605, %605
  %mul1.i.i.i.i.i179.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i180.i.i.i.i = fadd double %mul1.i.i.i.i.i179.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i181.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FE479D17050CA47
  %606 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i181.i.i.i.i
  %mul10.i.i.i.i.i183.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %add.i.i.i.i.i180.i.i.i.i
  %mul12.i.i.i.i.i184.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %606
  %add15.i.i.i.i.i185.i.i.i.i = fadd double %mul10.i.i.i.i.i183.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i186.i.i.i.i = fadd double %mul12.i.i.i.i.i184.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i187.i.i.i.i = fmul double %605, %add15.i.i.i.i.i185.i.i.i.i
  %add23.i.i.i.i.i188.i.i.i.i = fadd double %add18.i.i.i.i.i186.i.i.i.i, %mul20.i.i.i.i.i187.i.i.i.i
  %.frozen212 = freeze i32 %604
  %div.i.i.i189.i.i.i.i = sdiv i32 %.frozen212, 3
  %607 = call i32 @llvm.abs.i32(i32 %div.i.i.i189.i.i.i.i, i1 true)
  %cmp11.i.i.i191.i.i.i.i = icmp ugt i32 %607, 63
  %cmp13.i.i.i193.i.i.i.i = icmp sgt i32 %604, 2
  %decision.take4 = or i1 %cmp11.i.i.i191.i.i.i.i, %cmp13.i.i.i193.i.i.i.i
  %608 = sub nsw i32 0, %div.i.i.i189.i.i.i.i
  %fusion.paired6.v = select i1 %decision.take4, i32 %div.i.i.i189.i.i.i.i, i32 %608
  %fusion.paired6 = zext i32 %fusion.paired6.v to i64
  %609 = shl nuw i64 1, %fusion.paired6
  %610 = uitofp i64 %609 to double
  br i1 %decision.take4, label %fusion.side13, label %fusion.side14, !decision.merged_from !12, !decision.origin !13

fusion.side13:                                    ; preds = %if.end7.i.i.i192.i.i.i.i
  %611 = fmul double %add23.i.i.i.i.i188.i.i.i.i, %610
  %612 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i188.i.i.i.i, i32 %div.i.i.i189.i.i.i.i) #3
  %613 = select i1 %cmp11.i.i.i191.i.i.i.i, double %612, double %611
  br label %if.end23.i.i.i212.i.i.i.i.pair.join

fusion.side14:                                    ; preds = %if.end7.i.i.i192.i.i.i.i
  %614 = fdiv double %add23.i.i.i.i.i188.i.i.i.i, %610
  br label %if.end23.i.i.i212.i.i.i.i.pair.join

if.end23.i.i.i212.i.i.i.i.pair.join:              ; preds = %fusion.side14, %fusion.side13
  %guess.i.i.i161.i.i.i.i.0.ph = phi double [ %614, %fusion.side14 ], [ %613, %fusion.side13 ]
  br label %if.end23.i.i.i212.i.i.i.i

if.end23.i.i.i212.i.i.i.i:                        ; preds = %if.end23.i.i.i212.i.i.i.i.pair.join
  %.neg2 = mul nsw i32 %div.i.i.i189.i.i.i.i, -3
  %rem.i.i.i207.i.i.i.i.decomposed = add i32 %.frozen212, 2
  %add.i.i.i208.i.i.i.i = add i32 %rem.i.i.i207.i.i.i.i.decomposed, %.neg2
  %615 = zext i32 %add.i.i.i208.i.i.i.i to i64
  %arrayidx1.i.i.i209.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %615
  %616 = load double, double addrspace(4)* %arrayidx1.i.i.i209.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i210.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.0.ph, %616
  %cmp26.i.i.i211.i.i.i.i = icmp slt i32 %604, 1021
  br i1 %cmp26.i.i.i211.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i

do.body.i.i.i223.i.i.i.i:                         ; preds = %do.body.i.i.i223.i.i.i.i, %if.end23.i.i.i212.i.i.i.i
  %guess.i.i.i161.i.i.i.i.1 = phi double [ %mul24.i.i.i210.i.i.i.i, %if.end23.i.i.i212.i.i.i.i ], [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ]
  %mul28.i.i.i213.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %guess.i.i.i161.i.i.i.i.1
  %mul29.i.i.i214.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %mul28.i.i.i213.i.i.i.i
  %add30.i.i.i215.i.i.i.i = fadd double %mul68.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add31.i.i.i216.i.i.i.i = fadd double %mul68.i.i.i.i, %add30.i.i.i215.i.i.i.i
  %add32.i.i.i217.i.i.i.i = fadd double %mul29.i.i.i214.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add33.i.i.i218.i.i.i.i = fadd double %mul68.i.i.i.i, %add32.i.i.i217.i.i.i.i
  %div34.i.i.i219.i.i.i.i = fdiv double %add31.i.i.i216.i.i.i.i, %add33.i.i.i218.i.i.i.i
  %mul35.i.i.i220.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %div34.i.i.i219.i.i.i.i
  %sub36.i.i.i221.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i219.i.i.i.i
  %617 = tail call double @llvm.fabs.f64(double %sub36.i.i.i221.i.i.i.i) #3
  %cmp38.i.i.i222.i.i.i.i = fcmp ogt double %617, 0x3EC0000000000000
  br i1 %cmp38.i.i.i222.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

do.body40.i.i.i234.i.i.i.i:                       ; preds = %do.body40.i.i.i234.i.i.i.i, %if.end23.i.i.i212.i.i.i.i
  %guess.i.i.i161.i.i.i.i.2 = phi double [ %mul24.i.i.i210.i.i.i.i, %if.end23.i.i.i212.i.i.i.i ], [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ]
  %mul41.i.i.i224.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, %guess.i.i.i161.i.i.i.i.2
  %div42.i.i.i225.i.i.i.i = fdiv double %mul68.i.i.i.i, %guess.i.i.i161.i.i.i.i.2
  %sub43.i.i.i226.i.i.i.i = fsub double %mul41.i.i.i224.i.i.i.i, %div42.i.i.i225.i.i.i.i
  %mul44.i.i.i227.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i228.i.i.i.i = fdiv double %mul68.i.i.i.i, %mul41.i.i.i224.i.i.i.i
  %add46.i.i.i229.i.i.i.i = fadd double %mul44.i.i.i227.i.i.i.i, %div45.i.i.i228.i.i.i.i
  %div47.i.i.i230.i.i.i.i = fdiv double %sub43.i.i.i226.i.i.i.i, %add46.i.i.i229.i.i.i.i
  %sub48.i.i.i231.i.i.i.i = fsub double %guess.i.i.i161.i.i.i.i.2, %div47.i.i.i230.i.i.i.i
  %mul50.i.i.i232.i.i.i.i = fmul double %sub48.i.i.i231.i.i.i.i, 0x3EC0000000000000
  %618 = tail call double @llvm.fabs.f64(double %div47.i.i.i230.i.i.i.i) #3
  %cmp52.i.i.i233.i.i.i.i = fcmp olt double %mul50.i.i.i232.i.i.i.i, %618
  br i1 %cmp52.i.i.i233.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i: ; preds = %do.body40.i.i.i234.i.i.i.i, %do.body.i.i.i223.i.i.i.i, %if.end.i.i.i166.i.i.i.i, %if.then66.i.i.i.i
  %retval.0.i.i.i237.i.i.i.i = phi double [ %mul68.i.i.i.i, %if.then66.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i166.i.i.i.i ], [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ], [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ]
  %div70.i.i.i.i = fdiv double 1.000000e+00, %retval.0.i.i.i237.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else71.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %cmp72.i.i.i.i = fcmp ogt double %sub.i.i.i, 0.000000e+00
  br i1 %cmp72.i.i.i.i, label %if.then73.i.i.i.i, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.then73.i.i.i.i:                                ; preds = %if.else71.i.i.i.i
  %cmp.i.i.i.i79.i.i.i.i = fcmp ogt double %sub.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i.i80.i.i.i.i = fcmp olt double %sub.i.i.i, 0xFFEFFFFFFFFFFFFF
  %619 = or i1 %cmp.i.i.i.i79.i.i.i.i, %cmp1.i.i.i.i80.i.i.i.i
  %or.cond.i.i.i82.i.i.i.i = or i1 %38, %619
  %brmerge170 = or i1 %33, %or.cond.i.i.i82.i.i.i.i
  %sub.i.i.i.mux = select i1 %or.cond.i.i.i82.i.i.i.i, double %sub.i.i.i, double 0x7FF8000000000000
  br i1 %brmerge170, label %if.end7.i.i.i.i.i.i.i, label %if.end4.i.i.i92.i.i.i.i

if.end4.i.i.i92.i.i.i.i:                          ; preds = %if.then73.i.i.i.i
  %cmp5.i.i.i91.i.i.i.i = fcmp olt double %sub.i.i.i, 0.000000e+00
  %fneg.i.i.i93.i.i.i.i = fneg double %sub.i.i.i
  %z.addr.i.i.i76.i.i.i.i.0 = select i1 %cmp5.i.i.i91.i.i.i.i, double %fneg.i.i.i93.i.i.i.i, double %sub.i.i.i
  %620 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %621 = tail call double @llvm.amdgcn.frexp.mant.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %622 = tail call i1 @llvm.amdgcn.class.f64(double %z.addr.i.i.i76.i.i.i.i.0, i32 519) #3
  %623 = select i1 %622, i32 0, i32 %620
  %624 = select i1 %622, double %z.addr.i.i.i76.i.i.i.i.0, double %621
  %mul.i.i.i.i.i97.i.i.i.i = fmul double %624, %624
  %mul1.i.i.i.i.i98.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i99.i.i.i.i = fadd double %mul1.i.i.i.i.i98.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i100.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FE479D17050CA47
  %625 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i100.i.i.i.i
  %mul10.i.i.i.i.i102.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %add.i.i.i.i.i99.i.i.i.i
  %mul12.i.i.i.i.i103.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %625
  %add15.i.i.i.i.i104.i.i.i.i = fadd double %mul10.i.i.i.i.i102.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i105.i.i.i.i = fadd double %mul12.i.i.i.i.i103.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i106.i.i.i.i = fmul double %624, %add15.i.i.i.i.i104.i.i.i.i
  %add23.i.i.i.i.i107.i.i.i.i = fadd double %add18.i.i.i.i.i105.i.i.i.i, %mul20.i.i.i.i.i106.i.i.i.i
  %.frozen213 = freeze i32 %623
  %div.i.i.i108.i.i.i.i = sdiv i32 %.frozen213, 3
  %626 = sub nsw i32 0, %div.i.i.i108.i.i.i.i
  %627 = call i32 @llvm.abs.i32(i32 %div.i.i.i108.i.i.i.i, i1 true)
  %cmp11.i.i.i110.i.i.i.i = icmp ult i32 %627, 64
  br i1 %cmp11.i.i.i110.i.i.i.i, label %if.then12.i.i.i113.i.i.i.i, label %if.else21.i.i.i125.i.i.i.i

if.then12.i.i.i113.i.i.i.i:                       ; preds = %if.end4.i.i.i92.i.i.i.i
  %cmp13.i.i.i112.i.i.i.i = icmp sgt i32 %623, 2
  br i1 %cmp13.i.i.i112.i.i.i.i, label %if.then14.i.i.i118.i.i.i.i, label %if.else.i.i.i124.i.i.i.i

if.then14.i.i.i118.i.i.i.i:                       ; preds = %if.then12.i.i.i113.i.i.i.i
  %sh_prom.i.i.i114.i.i.i.i = zext i32 %div.i.i.i108.i.i.i.i to i64
  %shl.i.i.i115.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i114.i.i.i.i
  %conv.i.i.i116.i.i.i.i = uitofp i64 %shl.i.i.i115.i.i.i.i to double
  %mul.i.i.i117.i.i.i.i = fmul double %add23.i.i.i.i.i107.i.i.i.i, %conv.i.i.i116.i.i.i.i
  br label %if.end23.i.i.i131.i.i.i.i

if.else.i.i.i124.i.i.i.i:                         ; preds = %if.then12.i.i.i113.i.i.i.i
  %sh_prom16.i.i.i120.i.i.i.i = zext i32 %626 to i64
  %shl17.i.i.i121.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i120.i.i.i.i
  %conv18.i.i.i122.i.i.i.i = uitofp i64 %shl17.i.i.i121.i.i.i.i to double
  %div19.i.i.i123.i.i.i.i = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %conv18.i.i.i122.i.i.i.i
  br label %if.end23.i.i.i131.i.i.i.i

if.else21.i.i.i125.i.i.i.i:                       ; preds = %if.end4.i.i.i92.i.i.i.i
  %628 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  br label %if.end23.i.i.i131.i.i.i.i

if.end23.i.i.i131.i.i.i.i:                        ; preds = %if.else21.i.i.i125.i.i.i.i, %if.else.i.i.i124.i.i.i.i, %if.then14.i.i.i118.i.i.i.i
  %guess.i.i.i78.i.i.i.i.0 = phi double [ %mul.i.i.i117.i.i.i.i, %if.then14.i.i.i118.i.i.i.i ], [ %div19.i.i.i123.i.i.i.i, %if.else.i.i.i124.i.i.i.i ], [ %628, %if.else21.i.i.i125.i.i.i.i ]
  %.neg = mul nsw i32 %div.i.i.i108.i.i.i.i, -3
  %rem.i.i.i126.i.i.i.i.decomposed = add i32 %.frozen213, 2
  %add.i.i.i127.i.i.i.i = add i32 %rem.i.i.i126.i.i.i.i.decomposed, %.neg
  %629 = zext i32 %add.i.i.i127.i.i.i.i to i64
  %arrayidx1.i.i.i128.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %629
  %630 = load double, double addrspace(4)* %arrayidx1.i.i.i128.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i129.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.0, %630
  %cmp26.i.i.i130.i.i.i.i = icmp slt i32 %623, 1021
  br i1 %cmp26.i.i.i130.i.i.i.i, label %do.body.i.i.i142.i.i.i.i, label %do.body40.i.i.i153.i.i.i.i

do.body.i.i.i142.i.i.i.i:                         ; preds = %do.body.i.i.i142.i.i.i.i, %if.end23.i.i.i131.i.i.i.i
  %guess.i.i.i78.i.i.i.i.1 = phi double [ %mul24.i.i.i129.i.i.i.i, %if.end23.i.i.i131.i.i.i.i ], [ %mul35.i.i.i139.i.i.i.i, %do.body.i.i.i142.i.i.i.i ]
  %mul28.i.i.i132.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.1, %guess.i.i.i78.i.i.i.i.1
  %mul29.i.i.i133.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.1, %mul28.i.i.i132.i.i.i.i
  %add30.i.i.i134.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %mul29.i.i.i133.i.i.i.i
  %add31.i.i.i135.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add30.i.i.i134.i.i.i.i
  %add32.i.i.i136.i.i.i.i = fadd double %mul29.i.i.i133.i.i.i.i, %mul29.i.i.i133.i.i.i.i
  %add33.i.i.i137.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add32.i.i.i136.i.i.i.i
  %div34.i.i.i138.i.i.i.i = fdiv double %add31.i.i.i135.i.i.i.i, %add33.i.i.i137.i.i.i.i
  %mul35.i.i.i139.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.1, %div34.i.i.i138.i.i.i.i
  %sub36.i.i.i140.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i138.i.i.i.i
  %631 = tail call double @llvm.fabs.f64(double %sub36.i.i.i140.i.i.i.i) #3
  %cmp38.i.i.i141.i.i.i.i = fcmp ogt double %631, 0x3EC0000000000000
  br i1 %cmp38.i.i.i141.i.i.i.i, label %do.body.i.i.i142.i.i.i.i, label %if.end4.i.i.i.i.i.i.i

do.body40.i.i.i153.i.i.i.i:                       ; preds = %do.body40.i.i.i153.i.i.i.i, %if.end23.i.i.i131.i.i.i.i
  %guess.i.i.i78.i.i.i.i.2 = phi double [ %mul24.i.i.i129.i.i.i.i, %if.end23.i.i.i131.i.i.i.i ], [ %sub48.i.i.i150.i.i.i.i, %do.body40.i.i.i153.i.i.i.i ]
  %mul41.i.i.i143.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.2, %guess.i.i.i78.i.i.i.i.2
  %div42.i.i.i144.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %guess.i.i.i78.i.i.i.i.2
  %sub43.i.i.i145.i.i.i.i = fsub double %mul41.i.i.i143.i.i.i.i, %div42.i.i.i144.i.i.i.i
  %mul44.i.i.i146.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i147.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %mul41.i.i.i143.i.i.i.i
  %add46.i.i.i148.i.i.i.i = fadd double %mul44.i.i.i146.i.i.i.i, %div45.i.i.i147.i.i.i.i
  %div47.i.i.i149.i.i.i.i = fdiv double %sub43.i.i.i145.i.i.i.i, %add46.i.i.i148.i.i.i.i
  %sub48.i.i.i150.i.i.i.i = fsub double %guess.i.i.i78.i.i.i.i.2, %div47.i.i.i149.i.i.i.i
  %mul50.i.i.i151.i.i.i.i = fmul double %sub48.i.i.i150.i.i.i.i, 0x3EC0000000000000
  %632 = tail call double @llvm.fabs.f64(double %div47.i.i.i149.i.i.i.i) #3
  %cmp52.i.i.i152.i.i.i.i = fcmp olt double %mul50.i.i.i151.i.i.i.i, %632
  br i1 %cmp52.i.i.i152.i.i.i.i, label %do.body40.i.i.i153.i.i.i.i, label %if.end4.i.i.i.i.i.i.i

if.end4.i.i.i.i.i.i.i:                            ; preds = %do.body40.i.i.i153.i.i.i.i, %do.body.i.i.i142.i.i.i.i
  %guess.i.i.i78.i.i.i.i.3 = phi double [ %mul35.i.i.i139.i.i.i.i, %do.body.i.i.i142.i.i.i.i ], [ %sub48.i.i.i150.i.i.i.i, %do.body40.i.i.i153.i.i.i.i ]
  %633 = fneg double %guess.i.i.i78.i.i.i.i.3
  %634 = select i1 %cmp5.i.i.i91.i.i.i.i, double %633, double %guess.i.i.i78.i.i.i.i.3
  br i1 %cmp11.i.i.i110.i.i.i.i, label %if.then12.i.i.i32.i.i.i.i, label %if.else21.i.i.i44.i.i.i.i

if.then12.i.i.i32.i.i.i.i:                        ; preds = %if.end4.i.i.i.i.i.i.i
  %cmp13.i.i.i31.i.i.i.i = icmp sgt i32 %623, 2
  br i1 %cmp13.i.i.i31.i.i.i.i, label %if.then14.i.i.i37.i.i.i.i, label %if.else.i.i.i43.i.i.i.i

if.then14.i.i.i37.i.i.i.i:                        ; preds = %if.then12.i.i.i32.i.i.i.i
  %sh_prom.i.i.i33.i.i.i.i = zext i32 %div.i.i.i108.i.i.i.i to i64
  %shl.i.i.i34.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i33.i.i.i.i
  %conv.i.i.i35.i.i.i.i = uitofp i64 %shl.i.i.i34.i.i.i.i to double
  %mul.i.i.i36.i.i.i.i = fmul double %add23.i.i.i.i.i107.i.i.i.i, %conv.i.i.i35.i.i.i.i
  br label %if.end23.i.i.i50.i.i.i.i

if.else.i.i.i43.i.i.i.i:                          ; preds = %if.then12.i.i.i32.i.i.i.i
  %sh_prom16.i.i.i39.i.i.i.i = zext i32 %626 to i64
  %shl17.i.i.i40.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i39.i.i.i.i
  %conv18.i.i.i41.i.i.i.i = uitofp i64 %shl17.i.i.i40.i.i.i.i to double
  %div19.i.i.i42.i.i.i.i = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %conv18.i.i.i41.i.i.i.i
  br label %if.end23.i.i.i50.i.i.i.i

if.else21.i.i.i44.i.i.i.i:                        ; preds = %if.end4.i.i.i.i.i.i.i
  %635 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  br label %if.end23.i.i.i50.i.i.i.i

if.end23.i.i.i50.i.i.i.i:                         ; preds = %if.else21.i.i.i44.i.i.i.i, %if.else.i.i.i43.i.i.i.i, %if.then14.i.i.i37.i.i.i.i
  %guess.i.i.i10.i.i.i.i.0 = phi double [ %mul.i.i.i36.i.i.i.i, %if.then14.i.i.i37.i.i.i.i ], [ %div19.i.i.i42.i.i.i.i, %if.else.i.i.i43.i.i.i.i ], [ %635, %if.else21.i.i.i44.i.i.i.i ]
  %mul24.i.i.i48.i.i.i.i = fmul double %630, %guess.i.i.i10.i.i.i.i.0
  br i1 %cmp26.i.i.i130.i.i.i.i, label %do.body.i.i.i61.i.i.i.i, label %do.body40.i.i.i72.i.i.i.i

do.body.i.i.i61.i.i.i.i:                          ; preds = %do.body.i.i.i61.i.i.i.i, %if.end23.i.i.i50.i.i.i.i
  %guess.i.i.i10.i.i.i.i.1 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %mul35.i.i.i58.i.i.i.i, %do.body.i.i.i61.i.i.i.i ]
  %mul28.i.i.i51.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.1, %guess.i.i.i10.i.i.i.i.1
  %mul29.i.i.i52.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.1, %mul28.i.i.i51.i.i.i.i
  %add30.i.i.i53.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %mul29.i.i.i52.i.i.i.i
  %add31.i.i.i54.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add30.i.i.i53.i.i.i.i
  %add32.i.i.i55.i.i.i.i = fadd double %mul29.i.i.i52.i.i.i.i, %mul29.i.i.i52.i.i.i.i
  %add33.i.i.i56.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add32.i.i.i55.i.i.i.i
  %div34.i.i.i57.i.i.i.i = fdiv double %add31.i.i.i54.i.i.i.i, %add33.i.i.i56.i.i.i.i
  %mul35.i.i.i58.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.1, %div34.i.i.i57.i.i.i.i
  %sub36.i.i.i59.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i57.i.i.i.i
  %636 = tail call double @llvm.fabs.f64(double %sub36.i.i.i59.i.i.i.i) #3
  %cmp38.i.i.i60.i.i.i.i = fcmp ogt double %636, 0x3EC0000000000000
  br i1 %cmp38.i.i.i60.i.i.i.i, label %do.body.i.i.i61.i.i.i.i, label %if.end54.i.i.i.i.i.i.i

do.body40.i.i.i72.i.i.i.i:                        ; preds = %do.body40.i.i.i72.i.i.i.i, %if.end23.i.i.i50.i.i.i.i
  %guess.i.i.i10.i.i.i.i.2 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %sub48.i.i.i69.i.i.i.i, %do.body40.i.i.i72.i.i.i.i ]
  %mul41.i.i.i62.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.2, %guess.i.i.i10.i.i.i.i.2
  %div42.i.i.i63.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %guess.i.i.i10.i.i.i.i.2
  %sub43.i.i.i64.i.i.i.i = fsub double %mul41.i.i.i62.i.i.i.i, %div42.i.i.i63.i.i.i.i
  %mul44.i.i.i65.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i66.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %mul41.i.i.i62.i.i.i.i
  %add46.i.i.i67.i.i.i.i = fadd double %mul44.i.i.i65.i.i.i.i, %div45.i.i.i66.i.i.i.i
  %div47.i.i.i68.i.i.i.i = fdiv double %sub43.i.i.i64.i.i.i.i, %add46.i.i.i67.i.i.i.i
  %sub48.i.i.i69.i.i.i.i = fsub double %guess.i.i.i10.i.i.i.i.2, %div47.i.i.i68.i.i.i.i
  %mul50.i.i.i70.i.i.i.i = fmul double %sub48.i.i.i69.i.i.i.i, 0x3EC0000000000000
  %637 = tail call double @llvm.fabs.f64(double %div47.i.i.i68.i.i.i.i) #3
  %cmp52.i.i.i71.i.i.i.i = fcmp olt double %mul50.i.i.i70.i.i.i.i, %637
  br i1 %cmp52.i.i.i71.i.i.i.i, label %do.body40.i.i.i72.i.i.i.i, label %if.end54.i.i.i.i.i.i.i

if.end54.i.i.i.i.i.i.i:                           ; preds = %do.body40.i.i.i72.i.i.i.i, %do.body.i.i.i61.i.i.i.i
  %guess.i.i.i10.i.i.i.i.3 = phi double [ %mul35.i.i.i58.i.i.i.i, %do.body.i.i.i61.i.i.i.i ], [ %sub48.i.i.i69.i.i.i.i, %do.body40.i.i.i72.i.i.i.i ]
  %638 = fneg double %guess.i.i.i10.i.i.i.i.3
  %639 = select i1 %cmp5.i.i.i91.i.i.i.i, double %638, double %guess.i.i.i10.i.i.i.i.3
  br label %if.end7.i.i.i.i.i.i.i

if.end7.i.i.i.i.i.i.i:                            ; preds = %if.end54.i.i.i.i.i.i.i, %if.then73.i.i.i.i
  %retval.0.i.i.i156.i.i.i.i162 = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %634, %if.end54.i.i.i.i.i.i.i ]
  %retval.0.i.i.i.i.i.i.i = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %639, %if.end54.i.i.i.i.i.i.i ]
  %mul76.i.i.i.i = fmul double %retval.0.i.i.i156.i.i.i.i162, %retval.0.i.i.i.i.i.i.i
  %mul79.i.i.i.i = fmul double %mul76.i.i.i.i, 0x3FFD8639FDCB60EB
  %div80.i.i.i.i = fdiv double 1.000000e+00, %mul79.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

cond.false7.i.i.i:                                ; preds = %if.end14.i.i
  %decision.interval6 = fcmp ult double %arrayidx.val, 1.250000e-01
  br i1 %decision.interval6, label %if.else17.i.i.i.i, label %decision.dispatch5, !decision.condition_prefix !6

decision.dispatch5:                               ; preds = %cond.false7.i.i.i
  %decision.interval = fcmp ult double %arrayidx.val, 2.500000e-01
  %640 = fcmp ult double %arrayidx.val, 3.750000e-01
  %641 = select i1 %640, double -2.500000e-01, double -3.750000e-01
  %642 = select i1 %decision.interval, double -1.250000e-01, double %641
  %643 = select i1 %decision.interval, i1 poison, i1 %640
  %644 = fadd double %arrayidx.val, %642
  %645 = fmul double %644, %644
  br i1 %decision.interval, label %fusion.side3, label %fusion.side2

if.else17.i.i.i.i:                                ; preds = %cond.false7.i.i.i
  %646 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %arrayidx.val) #3
  %647 = add nsw i32 %646, -1
  %648 = tail call double @llvm.fabs.f64(double %arrayidx.val) #4
  %649 = fcmp oeq double %648, 0x7FF0000000000000
  %650 = select i1 %649, i32 2147483647, i32 %647
  %651 = fcmp oeq double %arrayidx.val, 0.000000e+00
  %652 = select i1 %651, i32 -2147483648, i32 %650
  %cmp106.i.i.i.i = icmp sgt i32 %652, -1025
  br i1 %cmp106.i.i.i.i, label %decision.dispatch2, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, !decision.condition_prefix !6

if.then20.i.i.i.i:                                ; preds = %decision.dispatch2
  %653 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 3) #3
  %654 = tail call double @llvm.amdgcn.frexp.mant.f64(double %653) #3
  %655 = fcmp olt double %654, 0x3FE5555555555555
  %656 = zext i1 %655 to i32
  %657 = tail call double @llvm.amdgcn.ldexp.f64(double %654, i32 %656) #3
  %658 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %653) #3
  %659 = sub nsw i32 %658, %656
  %660 = fadd double %657, -1.000000e+00
  %661 = fadd double %657, 1.000000e+00
  %662 = fsub double %661, %657
  %663 = fsub double %661, %662
  %664 = fsub double %657, %663
  %665 = fsub double 1.000000e+00, %662
  %666 = fadd double %665, %664
  %667 = tail call double @llvm.amdgcn.rcp.f64(double %661) #3
  %668 = fneg double %661
  %669 = tail call double @llvm.fma.f64(double %668, double %667, double 1.000000e+00) #3
  %670 = tail call double @llvm.fma.f64(double %669, double %667, double %667) #3
  %671 = tail call double @llvm.fma.f64(double %668, double %670, double 1.000000e+00) #3
  %672 = tail call double @llvm.fma.f64(double %671, double %670, double %670) #3
  %673 = fmul double %660, %672
  %674 = fmul double %661, %673
  %675 = fneg double %674
  %676 = tail call double @llvm.fma.f64(double %673, double %661, double %675) #3
  %677 = tail call double @llvm.fma.f64(double %673, double %666, double %676) #3
  %678 = fadd double %674, %677
  %679 = fsub double %678, %674
  %680 = fsub double %677, %679
  %681 = fsub double %660, %678
  %682 = fsub double %660, %681
  %683 = fsub double %682, %678
  %684 = fsub double %683, %680
  %685 = fadd double %681, %684
  %686 = fmul double %672, %685
  %687 = fadd double %673, %686
  %688 = fsub double %687, %673
  %689 = fsub double %686, %688
  %690 = fmul double %687, %687
  %691 = fneg double %690
  %692 = tail call double @llvm.fma.f64(double %687, double %687, double %691) #3
  %693 = fmul double %689, 2.000000e+00
  %694 = tail call double @llvm.fma.f64(double %687, double %693, double %692) #3
  %695 = tail call double @llvm.fma.f64(double %689, double %689, double %694) #3
  %696 = fadd double %690, %695
  %697 = fsub double %696, %690
  %698 = fsub double %695, %697
  %699 = tail call double @llvm.fma.f64(double %696, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %700 = tail call double @llvm.fma.f64(double %696, double %699, double 0x3FC7474DD7F4DF2E) #3
  %701 = tail call double @llvm.fma.f64(double %696, double %700, double 0x3FCC71C016291751) #3
  %702 = tail call double @llvm.fma.f64(double %696, double %701, double 0x3FD249249B27ACF1) #3
  %703 = tail call double @llvm.fma.f64(double %696, double %702, double 0x3FD99999998EF7B6) #3
  %704 = tail call double @llvm.fma.f64(double %696, double %703, double 0x3FE5555555555780) #3
  %705 = tail call double @llvm.amdgcn.ldexp.f64(double %687, i32 1) #3
  %706 = tail call double @llvm.amdgcn.ldexp.f64(double %689, i32 1) #3
  %707 = fmul double %687, %696
  %708 = fneg double %707
  %709 = tail call double @llvm.fma.f64(double %687, double %696, double %708) #3
  %710 = fmul double %689, %696
  %711 = tail call double @llvm.fma.f64(double %687, double %698, double %710) #3
  %712 = fadd double %709, %711
  %713 = fadd double %707, %712
  %714 = fsub double %713, %707
  %715 = fsub double %712, %714
  %716 = fmul double %713, %704
  %717 = fneg double %716
  %718 = tail call double @llvm.fma.f64(double %713, double %704, double %717) #3
  %719 = tail call double @llvm.fma.f64(double %715, double %704, double %718) #3
  %720 = fadd double %716, %719
  %721 = fsub double %720, %716
  %722 = fsub double %719, %721
  %723 = fadd double %705, %720
  %724 = fsub double %723, %705
  %725 = fsub double %723, %724
  %726 = fsub double %705, %725
  %727 = fsub double %720, %724
  %728 = fadd double %727, %726
  %729 = fadd double %706, %722
  %730 = fsub double %729, %706
  %731 = fsub double %729, %730
  %732 = fsub double %706, %731
  %733 = fsub double %722, %730
  %734 = fadd double %733, %732
  %735 = fadd double %729, %728
  %736 = fadd double %723, %735
  %737 = fsub double %736, %723
  %738 = fsub double %735, %737
  %739 = fadd double %734, %738
  %740 = fadd double %736, %739
  %741 = fsub double %740, %736
  %742 = fsub double %739, %741
  %743 = sitofp i32 %659 to double
  %744 = fmul double %740, 0x3FF71547652B82FE
  %745 = fneg double %744
  %746 = fmul double %740, 0x3C7777D0FFDA0D24
  %747 = insertelement <2 x double> undef, double %740, i32 0
  %748 = insertelement <2 x double> %747, double %742, i32 1
  %749 = insertelement <2 x double> undef, double %745, i32 0
  %750 = insertelement <2 x double> %749, double %746, i32 1
  %751 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %748, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %750) #3
  %752 = extractelement <2 x double> %751, i32 0
  %753 = extractelement <2 x double> %751, i32 1
  %754 = fadd double %752, %753
  %755 = fadd double %744, %754
  %756 = fsub double %755, %744
  %757 = fsub double %754, %756
  %758 = fadd double %755, %743
  %759 = fsub double %758, %743
  %760 = fsub double %759, %758
  %761 = fadd double %760, %743
  %762 = fsub double %755, %759
  %763 = fadd double %762, %761
  %764 = fadd double %757, %763
  %765 = fadd double %758, %764
  %766 = tail call double @llvm.fabs.f64(double %653) #4
  %767 = fcmp oeq double %766, 0x7FF0000000000000
  %768 = select i1 %767, double %653, double %765
  %769 = fcmp olt double %653, 0.000000e+00
  %770 = select i1 %769, double 0x7FF8000000000000, double %768
  %771 = fcmp oeq double %653, 0.000000e+00
  %772 = select i1 %771, double 0xFFF0000000000000, double %770
  %mul.i.i244.i.i.i.i = fmul double %772, %772
  %mul1.i.i245.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F1989D450BBA5CA
  %773 = fsub double 0xBFBD94CCEC41CB08, %mul1.i.i245.i.i.i.i
  %mul5.i.i247.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F7B3A00DD9C9429
  %774 = fsub double 0xBFE8DDD719DA7D3E, %mul5.i.i247.i.i.i.i
  %mul10.i.i249.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %773
  %mul12.i.i250.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %774
  %add15.i.i251.i.i.i.i = fadd double %mul10.i.i249.i.i.i.i, 0xC001974D2C397C76
  %add18.i.i252.i.i.i.i = fadd double %mul12.i.i250.i.i.i.i, 0xC001804F92FE2A82
  %775 = fmul double %772, %add15.i.i251.i.i.i.i
  %add23.i.i254.i.i.i.i = fsub double %add18.i.i252.i.i.i.i, %775
  %mul1.i.i234.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3EDBEC7AF5AC0D6F
  %add.i.i235.i.i.i.i = fadd double %mul1.i.i234.i.i.i.i, 0x3F98BA1DB321D0E9
  %mul5.i.i236.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F4ED662BB480251
  %add7.i.i237.i.i.i.i = fadd double %mul5.i.i236.i.i.i.i, 0x3FCBD444F5D4FCC2
  %mul10.i.i238.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %add.i.i235.i.i.i.i
  %mul12.i.i239.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %add7.i.i237.i.i.i.i
  %add15.i.i240.i.i.i.i = fadd double %mul10.i.i238.i.i.i.i, 0x3FE957680773BEB6
  %add18.i.i241.i.i.i.i = fadd double %mul12.i.i239.i.i.i.i, 1.000000e+00
  %776 = fmul double %772, %add15.i.i240.i.i.i.i
  %add23.i.i243.i.i.i.i = fsub double %add18.i.i241.i.i.i.i, %776
  %div26.i.i.i.i = fdiv double %add23.i.i254.i.i.i.i, %add23.i.i243.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

decision.dispatch2:                               ; preds = %if.else17.i.i.i.i
  %cmp19.i.i.i.i = icmp sgt i32 %652, -5
  br i1 %cmp19.i.i.i.i, label %if.then20.i.i.i.i, label %decision.dispatch1, !decision.merged_from !14, !decision.origin !15

decision.dispatch4:                               ; preds = %decision.dispatch1
  %cmp40.i.i.i.i = icmp sgt i32 %652, -17
  %merged.select = select i1 %cmp40.i.i.i.i, i32 -9, i32 -33
  %777 = icmp sgt i32 %652, %merged.select
  %merged.select36 = select i1 %cmp40.i.i.i.i, i32 4, i32 16
  %merged.select37 = select i1 %cmp40.i.i.i.i, i32 8, i32 32
  %778 = select i1 %777, i32 %merged.select36, i32 %merged.select37
  %779 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %778) #3
  %780 = tail call double @llvm.amdgcn.frexp.mant.f64(double %779) #3
  %781 = fcmp olt double %780, 0x3FE5555555555555
  %782 = zext i1 %781 to i32
  %783 = tail call double @llvm.amdgcn.ldexp.f64(double %780, i32 %782) #3
  %784 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %779) #3
  %785 = sub nsw i32 %784, %782
  %786 = fadd double %783, -1.000000e+00
  %787 = fadd double %783, 1.000000e+00
  %788 = fsub double %787, %783
  %789 = fsub double %787, %788
  %790 = fsub double %783, %789
  %791 = fsub double 1.000000e+00, %788
  %792 = fadd double %791, %790
  %793 = tail call double @llvm.amdgcn.rcp.f64(double %787) #3
  %794 = fneg double %787
  %795 = tail call double @llvm.fma.f64(double %794, double %793, double 1.000000e+00) #3
  %796 = tail call double @llvm.fma.f64(double %795, double %793, double %793) #3
  %797 = tail call double @llvm.fma.f64(double %794, double %796, double 1.000000e+00) #3
  %798 = tail call double @llvm.fma.f64(double %797, double %796, double %796) #3
  %799 = fmul double %786, %798
  %800 = fmul double %787, %799
  %801 = fneg double %800
  %802 = tail call double @llvm.fma.f64(double %799, double %787, double %801) #3
  %803 = tail call double @llvm.fma.f64(double %799, double %792, double %802) #3
  %804 = fadd double %800, %803
  %805 = fsub double %804, %800
  %806 = fsub double %803, %805
  %807 = fsub double %786, %804
  %808 = fsub double %786, %807
  %809 = fsub double %808, %804
  %810 = fsub double %809, %806
  %811 = fadd double %807, %810
  %812 = fmul double %798, %811
  %813 = fadd double %799, %812
  %814 = fsub double %813, %799
  %815 = fsub double %812, %814
  %816 = fmul double %813, %813
  %817 = fneg double %816
  %818 = tail call double @llvm.fma.f64(double %813, double %813, double %817) #3
  %819 = fmul double %815, 2.000000e+00
  %820 = tail call double @llvm.fma.f64(double %813, double %819, double %818) #3
  %821 = tail call double @llvm.fma.f64(double %815, double %815, double %820) #3
  %822 = fadd double %816, %821
  %823 = fsub double %822, %816
  %824 = fsub double %821, %823
  %825 = tail call double @llvm.fma.f64(double %822, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %826 = tail call double @llvm.fma.f64(double %822, double %825, double 0x3FC7474DD7F4DF2E) #3
  %827 = tail call double @llvm.fma.f64(double %822, double %826, double 0x3FCC71C016291751) #3
  %828 = tail call double @llvm.fma.f64(double %822, double %827, double 0x3FD249249B27ACF1) #3
  %829 = tail call double @llvm.fma.f64(double %822, double %828, double 0x3FD99999998EF7B6) #3
  %830 = tail call double @llvm.fma.f64(double %822, double %829, double 0x3FE5555555555780) #3
  %831 = tail call double @llvm.amdgcn.ldexp.f64(double %813, i32 1) #3
  %832 = tail call double @llvm.amdgcn.ldexp.f64(double %815, i32 1) #3
  %833 = fmul double %813, %822
  %834 = fneg double %833
  %835 = tail call double @llvm.fma.f64(double %813, double %822, double %834) #3
  %836 = fmul double %815, %822
  %837 = tail call double @llvm.fma.f64(double %813, double %824, double %836) #3
  %838 = fadd double %835, %837
  %839 = fadd double %833, %838
  %840 = fsub double %839, %833
  %841 = fsub double %838, %840
  %842 = fmul double %839, %830
  %843 = fneg double %842
  %844 = tail call double @llvm.fma.f64(double %839, double %830, double %843) #3
  %845 = tail call double @llvm.fma.f64(double %841, double %830, double %844) #3
  %846 = fadd double %842, %845
  %847 = fsub double %846, %842
  %848 = fsub double %845, %847
  %849 = fadd double %831, %846
  %850 = fsub double %849, %831
  %851 = fsub double %849, %850
  %852 = fsub double %831, %851
  %853 = fsub double %846, %850
  %854 = fadd double %853, %852
  %855 = fadd double %832, %848
  %856 = fsub double %855, %832
  %857 = fsub double %855, %856
  %858 = fsub double %832, %857
  %859 = fsub double %848, %856
  %860 = fadd double %859, %858
  %861 = fadd double %855, %854
  %862 = fadd double %849, %861
  %863 = fsub double %862, %849
  %864 = fsub double %861, %863
  %865 = fadd double %860, %864
  %866 = fadd double %862, %865
  %867 = fsub double %866, %862
  %868 = fsub double %865, %867
  %869 = fmul double %866, 0x3FF71547652B82FE
  %870 = fneg double %869
  %871 = fmul double %866, 0x3C7777D0FFDA0D24
  br i1 %777, label %merged.bb33, label %merged.bb34

decision.dispatch1:                               ; preds = %decision.dispatch2
  %cmp62.i.i.i.i = icmp sgt i32 %652, -65
  br i1 %cmp62.i.i.i.i, label %decision.dispatch4, label %decision.dispatch, !decision.merged_from !16, !decision.origin !17

decision.dispatch:                                ; preds = %decision.dispatch1
  %cmp84.i.i.i.i = icmp sgt i32 %652, -257
  %merged.select39 = select i1 %cmp84.i.i.i.i, i32 -129, i32 -513
  %872 = icmp sgt i32 %652, %merged.select39
  %merged.select40 = select i1 %cmp84.i.i.i.i, i32 64, i32 256
  %merged.select41 = select i1 %cmp84.i.i.i.i, i32 128, i32 512
  %873 = select i1 %872, i32 %merged.select40, i32 %merged.select41
  %874 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %873) #3
  %875 = tail call double @llvm.amdgcn.frexp.mant.f64(double %874) #3
  %876 = fcmp olt double %875, 0x3FE5555555555555
  %877 = zext i1 %876 to i32
  %878 = tail call double @llvm.amdgcn.ldexp.f64(double %875, i32 %877) #3
  %879 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %874) #3
  %880 = sub nsw i32 %879, %877
  %881 = fadd double %878, -1.000000e+00
  %882 = fadd double %878, 1.000000e+00
  %883 = fsub double %882, %878
  %884 = fsub double %882, %883
  %885 = fsub double %878, %884
  %886 = fsub double 1.000000e+00, %883
  %887 = fadd double %886, %885
  %888 = tail call double @llvm.amdgcn.rcp.f64(double %882) #3
  %889 = fneg double %882
  %890 = tail call double @llvm.fma.f64(double %889, double %888, double 1.000000e+00) #3
  %891 = tail call double @llvm.fma.f64(double %890, double %888, double %888) #3
  %892 = tail call double @llvm.fma.f64(double %889, double %891, double 1.000000e+00) #3
  %893 = tail call double @llvm.fma.f64(double %892, double %891, double %891) #3
  %894 = fmul double %881, %893
  %895 = fmul double %882, %894
  %896 = fneg double %895
  %897 = tail call double @llvm.fma.f64(double %894, double %882, double %896) #3
  %898 = tail call double @llvm.fma.f64(double %894, double %887, double %897) #3
  %899 = fadd double %895, %898
  %900 = fsub double %899, %895
  %901 = fsub double %898, %900
  %902 = fsub double %881, %899
  %903 = fsub double %881, %902
  %904 = fsub double %903, %899
  %905 = fsub double %904, %901
  %906 = fadd double %902, %905
  %907 = fmul double %893, %906
  %908 = fadd double %894, %907
  %909 = fsub double %908, %894
  %910 = fsub double %907, %909
  %911 = fmul double %908, %908
  %912 = fneg double %911
  %913 = tail call double @llvm.fma.f64(double %908, double %908, double %912) #3
  %914 = fmul double %910, 2.000000e+00
  %915 = tail call double @llvm.fma.f64(double %908, double %914, double %913) #3
  %916 = tail call double @llvm.fma.f64(double %910, double %910, double %915) #3
  %917 = fadd double %911, %916
  %918 = fsub double %917, %911
  %919 = fsub double %916, %918
  %920 = tail call double @llvm.fma.f64(double %917, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %921 = tail call double @llvm.fma.f64(double %917, double %920, double 0x3FC7474DD7F4DF2E) #3
  %922 = tail call double @llvm.fma.f64(double %917, double %921, double 0x3FCC71C016291751) #3
  %923 = tail call double @llvm.fma.f64(double %917, double %922, double 0x3FD249249B27ACF1) #3
  %924 = tail call double @llvm.fma.f64(double %917, double %923, double 0x3FD99999998EF7B6) #3
  %925 = tail call double @llvm.fma.f64(double %917, double %924, double 0x3FE5555555555780) #3
  %926 = tail call double @llvm.amdgcn.ldexp.f64(double %908, i32 1) #3
  %927 = tail call double @llvm.amdgcn.ldexp.f64(double %910, i32 1) #3
  %928 = fmul double %908, %917
  %929 = fneg double %928
  %930 = tail call double @llvm.fma.f64(double %908, double %917, double %929) #3
  %931 = fmul double %910, %917
  %932 = tail call double @llvm.fma.f64(double %908, double %919, double %931) #3
  %933 = fadd double %930, %932
  %934 = fadd double %928, %933
  %935 = fsub double %934, %928
  %936 = fsub double %933, %935
  %937 = fmul double %934, %925
  %938 = fneg double %937
  %939 = tail call double @llvm.fma.f64(double %934, double %925, double %938) #3
  %940 = tail call double @llvm.fma.f64(double %936, double %925, double %939) #3
  %941 = fadd double %937, %940
  %942 = fsub double %941, %937
  %943 = fsub double %940, %942
  %944 = fadd double %926, %941
  %945 = fsub double %944, %926
  %946 = fsub double %944, %945
  %947 = fsub double %926, %946
  %948 = fsub double %941, %945
  %949 = fadd double %948, %947
  %950 = fadd double %927, %943
  %951 = fsub double %950, %927
  %952 = fsub double %950, %951
  %953 = fsub double %927, %952
  %954 = fsub double %943, %951
  %955 = fadd double %954, %953
  %956 = fadd double %950, %949
  %957 = fadd double %944, %956
  %958 = fsub double %957, %944
  %959 = fsub double %956, %958
  %960 = fadd double %955, %959
  %961 = fadd double %957, %960
  %962 = fsub double %961, %957
  %963 = fsub double %960, %962
  %964 = fmul double %961, 0x3FF71547652B82FE
  %965 = fneg double %964
  %966 = fmul double %961, 0x3C7777D0FFDA0D24
  br i1 %872, label %merged.bb36, label %merged.bb37

fusion.side12:                                    ; preds = %decision.dispatch3
  %967 = fmul double %10, 0x3FF51F0306685285
  %968 = fsub double 0xBFEEB82FAA589934, %967
  %969 = fmul double %10, 0x3FEFDC5AEE1525E4
  %970 = fsub double 0x4043A793DEC20DEB, %969
  br label %fusion.common11

fusion.common11:                                  ; preds = %fusion.side12, %decision.dispatch3
  %971 = phi double [ 0x40354F2A1256B431, %decision.dispatch3 ], [ 0x4020675EC4F85A38, %fusion.side12 ]
  %972 = phi double [ 0x4063AA2F5D62DCD3, %decision.dispatch3 ], [ 0x403058D46A8EC004, %fusion.side12 ]
  %973 = phi double [ 0x407BA4300BFE5087, %decision.dispatch3 ], [ 0xC02E8C55CA7195EF, %fusion.side12 ]
  %974 = phi double [ 0xC083E59B9D34A0F1, %decision.dispatch3 ], [ 0x401A11C0BB0DC22E, %fusion.side12 ]
  %975 = phi double [ 0x406113A5A6902AC1, %decision.dispatch3 ], [ %968, %fusion.side12 ]
  %976 = phi double [ poison, %decision.dispatch3 ], [ %970, %fusion.side12 ]
  %977 = fmul double %10, %975
  %978 = fmul double %10, %976
  %979 = fadd double %977, %974
  %.op3 = fadd double %978, 0xC04B158FF790C730
  %980 = fmul double %10, 0x4071AEC837B9190D
  %981 = fsub double 0x406A5A0FD2D4B901, %980
  %fusion.paired18 = select i1 %cmp.i.i.i.i, double %981, double %.op3
  %982 = fmul double %10, %979
  %983 = fmul double %10, %fusion.paired18
  %984 = fadd double %982, %973
  %985 = fadd double %983, %972
  %986 = fmul double %10, %984
  %987 = fmul double %10, %985
  %988 = fadd double %986, %971
  %989 = fadd double %987, 1.000000e+00
  %990 = fmul double %9, %988
  %991 = fadd double %989, %990
  %992 = fdiv double %30, %991
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

fusion.side2:                                     ; preds = %decision.dispatch5
  %993 = select i1 %643, double 0x402A50B00A1E7B86, double 0x40132BDEE3243B58
  %994 = fmul double %645, %993
  %995 = select i1 %643, double 0xC03EAAFBAB179207, double 0xC0360FDD97954BA2
  %996 = fadd double %994, %995
  %997 = select i1 %643, double 0x403CBAD71AE3B29A, double 0x401CB5EDEDB31A3B
  %998 = fmul double %645, %997
  %999 = fadd double %998, 0xC017CB97C9E45E0D
  %1000 = fsub double 0x4040A8BCD7811DE4, %998
  %1001 = select i1 %643, double %1000, double %999
  br label %fusion.common1

fusion.side3:                                     ; preds = %decision.dispatch5
  %1002 = fmul double %645, 0x406D392CDE09E490
  %1003 = fsub double 0x408C7AAA9D225E9A, %1002
  %1004 = fmul double %645, 0x408B6249334DA816
  %1005 = fsub double 0x408C1B9BAF952B96, %1004
  %1006 = fmul double %645, %1003
  %phi.bo = fadd double %1006, 0xC05E9BCF5C362E51
  br label %fusion.common1

fusion.common1:                                   ; preds = %fusion.side3, %fusion.side2
  %1007 = phi double [ 0x401B5545C0CB5BDA, %fusion.side2 ], [ 0xC0320C17B7F0ED52, %fusion.side3 ]
  %1008 = phi double [ 0x3FF693D2420640AD, %fusion.side2 ], [ 0x404C078043CB129C, %fusion.side3 ]
  %1009 = phi double [ %1001, %fusion.side2 ], [ %phi.bo, %fusion.side3 ]
  %fusion.paired4 = phi double [ %996, %fusion.side2 ], [ %1005, %fusion.side3 ]
  %1010 = fmul double %645, %fusion.paired4
  %1011 = fmul double %645, %1009
  %1012 = select i1 %643, double 0x402CB09090084637, double 0x4027FEF192CFFD80
  %1013 = select i1 %643, double 0xC013B1AD6B90733F, double 0x3FF83BDAD25D5F48
  %1014 = select i1 %decision.interval, double 0xC04249A2BD20D346, double %1013
  %1015 = fadd double %1011, %1014
  %1016 = select i1 %643, double 0xBFFA1FFFE7A41296, double 0xBFF2C5AD0DCDC29A
  %.v.v = select i1 %decision.interval, double 0xC066A4A24A4E1713, double %1012
  %.v = fadd double %1010, %.v.v
  %1017 = fmul double %645, %.v
  %1018 = select i1 %decision.interval, double 0xC001804F92FE2A82, double %1016
  %1019 = fadd double %1017, %1018
  %1020 = fmul double %644, %1015
  %1021 = fadd double %1020, %1019
  %1022 = fmul double %645, 0x405E5232607614DB
  %1023 = fadd double %1022, 0xC0809E1D789AFFE5
  %1024 = fmul double %645, %1008
  %1025 = fsub double %1007, %1024
  %1026 = select i1 %643, double 0x40296F06194D60C2, double 0x40074E9A9F865729
  %1027 = select i1 %decision.interval, double %1023, double %1026
  %1028 = fmul double %645, %1027
  %1029 = select i1 %643, double 0xC030F25386AA802B, double 0xC016B372910B83AB
  %1030 = fmul double %645, %1025
  %1031 = select i1 %decision.interval, double 0x4071A64A34042F35, double %1029
  %1032 = fadd double %1028, %1031
  %1033 = select i1 %643, double 0x40199996D51EE9B7, double %1025
  %1034 = fmul double %645, %1033
  %1035 = fsub double 0x40034649FCCCF81F, %1034
  %.op4 = fadd double %1030, 0x405F12CC60181A8F
  %1036 = select i1 %decision.interval, double poison, double %1035
  %1037 = fmul double %645, %1032
  %.op5 = fadd double %1034, 0xC0138A29DF206C0B
  %1038 = select i1 %643, double 0x40158CEB587D3265, double 0x3FFC33F0B4C09D66
  %1039 = select i1 %decision.interval, double poison, double %.op5
  %1040 = select i1 %decision.interval, double 0x40332E0500972875, double %1038
  %1041 = fadd double %1037, %1040
  %1042 = select i1 %643, double %1036, double %1039
  %.v6 = select i1 %decision.interval, double %.op4, double %1042
  %1043 = fmul double %645, %.v6
  %1044 = fadd double %1043, 1.000000e+00
  %1045 = fmul double %644, %1041
  %1046 = fadd double %1045, %1044
  %1047 = fdiv double %1021, %1046
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i: ; preds = %merged.bb72, %merged.bb71, %fusion.common1, %fusion.common11, %if.then20.i.i.i.i, %if.else17.i.i.i.i, %if.end7.i.i.i.i.i.i.i, %if.else71.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i
  %retval.0.i.i.i = phi double [ %div20.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i ], [ %div34.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i ], [ %div48.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i ], [ %div62.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i ], [ %div70.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i ], [ 0x7FF0000000000000, %if.else71.i.i.i.i ], [ %div80.i.i.i.i, %if.end7.i.i.i.i.i.i.i ], [ 0xFFF0000000000000, %if.else17.i.i.i.i ], [ %div26.i.i.i.i, %if.then20.i.i.i.i ], [ %992, %fusion.common11 ], [ %1047, %fusion.common1 ], [ %1123, %merged.bb71 ], [ %1170, %merged.bb72 ]
  %add.i.i = fadd double %retval.0.i.i.i, 0.000000e+00
  br label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit

_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit: ; preds = %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, %lor.lhs.false2.i.i.i, %if.end8.i.i
  %retval.0.i.i = phi double [ 0x7FF8000000000000, %if.end8.i.i ], [ 0x7FF8000000000000, %lor.lhs.false2.i.i.i ], [ %add.i.i, %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i ]
  %arrayidx712 = getelementptr inbounds double, double addrspace(1)* %output.coerce, i64 %idxprom
  store double %retval.0.i.i, double addrspace(1)* %arrayidx712, align 8, !tbaa !8
  br label %if.end

if.end:                                           ; preds = %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, %entry
  ret void

merged.bb33:                                      ; preds = %decision.dispatch4
  %1048 = insertelement <2 x double> undef, double %866, i32 0
  %1049 = insertelement <2 x double> %1048, double %868, i32 1
  %1050 = insertelement <2 x double> undef, double %870, i32 0
  %1051 = insertelement <2 x double> %1050, double %871, i32 1
  %1052 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1049, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1051) #3
  %1053 = extractelement <2 x double> %1052, i32 0
  %1054 = extractelement <2 x double> %1052, i32 1
  br label %merged.bb70

merged.bb34:                                      ; preds = %decision.dispatch4
  %1055 = insertelement <2 x double> undef, double %866, i32 0
  %1056 = insertelement <2 x double> %1055, double %868, i32 1
  %1057 = insertelement <2 x double> undef, double %870, i32 0
  %1058 = insertelement <2 x double> %1057, double %871, i32 1
  %1059 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1056, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1058) #3
  %1060 = extractelement <2 x double> %1059, i32 0
  %1061 = extractelement <2 x double> %1059, i32 1
  br label %merged.bb70

merged.bb36:                                      ; preds = %decision.dispatch
  %1062 = insertelement <2 x double> undef, double %961, i32 0
  %1063 = insertelement <2 x double> %1062, double %963, i32 1
  %1064 = insertelement <2 x double> undef, double %965, i32 0
  %1065 = insertelement <2 x double> %1064, double %966, i32 1
  %1066 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1063, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1065) #3
  %1067 = extractelement <2 x double> %1066, i32 0
  %1068 = extractelement <2 x double> %1066, i32 1
  br label %merged.bb70

merged.bb37:                                      ; preds = %decision.dispatch
  %1069 = insertelement <2 x double> undef, double %961, i32 0
  %1070 = insertelement <2 x double> %1069, double %963, i32 1
  %1071 = insertelement <2 x double> undef, double %965, i32 0
  %1072 = insertelement <2 x double> %1071, double %966, i32 1
  %1073 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1070, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1072) #3
  %1074 = extractelement <2 x double> %1073, i32 0
  %1075 = extractelement <2 x double> %1073, i32 1
  br label %merged.bb70

merged.bb70:                                      ; preds = %merged.bb37, %merged.bb36, %merged.bb34, %merged.bb33
  %merged.select99 = phi double [ 0x3FE7235AE26E3A60, %merged.bb33 ], [ 0x3FD6E5B7AB236028, %merged.bb34 ], [ 0x3FA66506CA3FCEB3, %merged.bb36 ], [ 0x3F964BEF3074CF28, %merged.bb37 ]
  %merged.select98 = phi double [ 0x3FC92E7DCCD1B70C, %merged.bb33 ], [ 0x3FA8A45F1AE4ADBE, %merged.bb34 ], [ 0x3F478C82425FFDCE, %merged.bb36 ], [ 0x3F275783E6F9B4DA, %merged.bb37 ]
  %merged.select97 = phi double [ 0x3F999857B526C821, %merged.bb33 ], [ 0x3F68BF137C253BD1, %merged.bb34 ], [ 0x3ED71590B83839D8, %merged.bb36 ], [ 0x3EA6C7746378848A, %merged.bb37 ]
  %merged.select96 = phi double [ 0x3F0330822740ADF9, %merged.bb33 ], [ 0x3EB20E304F6E5BCE, %merged.bb34 ], [ 0x3DC001D96C7E2C9D, %merged.bb36 ], [ 0x3D6F4FAB0C90F842, %merged.bb37 ]
  %merged.select95 = phi double [ 0x3F586FC94B9EAD30, %merged.bb33 ], [ 0x3F1751EF5755C229, %merged.bb34 ], [ 0x3E553724D72BE5C7, %merged.bb36 ], [ 0x3E14D76BE5BA042B, %merged.bb37 ]
  %merged.select94 = phi double [ 0x3E9090FBB4B042AE, %merged.bb33 ], [ 0x3E2EB2F3F6504F32, %merged.bb34 ], [ 0x3D0A81E9CB6A1EA5, %merged.bb36 ], [ 0x3CA9D032740CF69A, %merged.bb37 ]
  %merged.select93 = phi double [ 0xC004C929A952DE48, %merged.bb33 ], [ 0xC00D636ADAEC3C05, %merged.bb34 ], [ 0xC0207852FA1731C0, %merged.bb36 ], [ 0xC024F817DD06EE79, %merged.bb37 ]
  %merged.select92 = phi double [ 0xC001F1CD6A03BCAA, %merged.bb33 ], [ 0xBFF8595CA25899FD, %merged.bb34 ], [ 0xBFD9F6368DFEFDDF, %merged.bb36 ], [ 0xBFD06A8AF4A3FC55, %merged.bb37 ]
  %merged.select91 = phi double [ 0xBFE78F054AC7A90B, %merged.bb33 ], [ 0xBFCED54905311121, %merged.bb34 ], [ 0xBF7F5FDEC6827012, %merged.bb36 ], [ 0xBF63B612102F3C24, %merged.bb37 ]
  %merged.select90 = phi double [ 0xBFBD7935AC58B5B5, %merged.bb33 ], [ 0xBF92AE2345C460A0, %merged.bb34 ], [ 0xBF1232A95F4E8466, %merged.bb36 ], [ 0xBEE6B9C7BCE39403, %merged.bb37 ]
  %merged.select89 = phi double [ 0xBF81F96D17A7115B, %merged.bb33 ], [ 0xBF4625660A41D7B1, %merged.bb34 ], [ 0xBE94B8A80FB81310, %merged.bb36 ], [ 0xBE59BA2A0439E4A9, %merged.bb37 ]
  %merged.select88 = phi double [ 0x3ECBFD524C94F258, %merged.bb33 ], [ 0x3E70731CF2A765F0, %merged.bb34 ], [ 0x3D5CB3C39661DD79, %merged.bb36 ], [ 0x3D01A287ED1019B8, %merged.bb37 ]
  %merged.select87 = phi double [ 0xBF336C13BBA203F3, %merged.bb33 ], [ 0xBEE755F1646665DB, %merged.bb34 ], [ 0xBE050B1B8007F8FF, %merged.bb36 ], [ 0xBDB9FC7E20BD04CC, %merged.bb37 ]
  %merged.select86 = phi double [ 0x3E32022ABCFF5DE7, %merged.bb33 ], [ 0x3DC4C8BD76453064, %merged.bb34 ], [ 0x3C819FA1E5E36C20, %merged.bb36 ], [ 0x3C158FD8B3C1B0C0, %merged.bb37 ]
  %merged.select124 = phi double [ 0x3FC6B0CE3157BCB1, %merged.bb33 ], [ 0x3FB68627D1A51CB5, %merged.bb34 ], [ 0x3F86397D81A61D6E, %merged.bb36 ], [ 0x3F762C8C65771E78, %merged.bb37 ]
  %merged.select123 = phi double [ 0x3F882FD20DA34F30, %merged.bb33 ], [ 0x3F67D3564F778B21, %merged.bb34 ], [ 0x3F0730EC426E6E84, %merged.bb36 ], [ 0x3EE71602E8EA99F3, %merged.bb37 ]
  %merged.select122 = phi double [ 0x3F380B62C1407B15, %merged.bb33 ], [ 0x3F077F4625619D43, %merged.bb34 ], [ 0x3E768F19E4302EF3, %merged.bb36 ], [ 0x3E46680C94743FD9, %merged.bb37 ]
  %merged.select121 = phi double [ 0x3E6129D961D79065, %merged.bb33 ], [ 0x3E107ECF99D6009A, %merged.bb34 ], [ 0x3D1ED0326F0CBDDC, %merged.bb36 ], [ 0x3CCE78F4A7F13C7D, %merged.bb37 ]
  %merged.select120 = phi double [ 0x3ED66AFC954DE682, %merged.bb33 ], [ 0x3E95BA568EDD3BFB, %merged.bb34 ], [ 0x3DD49301DA58AEFA, %merged.bb36 ], [ 0x3D9463E48A976F97, %merged.bb37 ]
  %merged.select119 = phi double [ 0x3DCCD7C812F40049, %merged.bb33 ], [ 0x3D6B7BD497A2CD17, %merged.bb34 ], [ 0x3C495387D39D2504, %merged.bb36 ], [ 0x3BE8FEBB5A4047D7, %merged.bb37 ]
  %merged.select118 = phi double [ 0xC013B000D66B8269, %merged.bb33 ], [ 0xC019A861C808DCFC, %merged.bb34 ], [ 0xC02A92BAF87A7B72, %merged.bb36 ], [ 0xC030CB31255FFA09, %merged.bb37 ]
  %merged.select117 = phi double [ 0xBFEFD66AE54A0BCB, %merged.bb33 ], [ 0xBFE46D859460DB51, %merged.bb34 ], [ 0xBFC4B5F131A679CC, %merged.bb36 ], [ 0xBFBA19EDB555D8AD, %merged.bb37 ]
  %merged.select116 = phi double [ 0xBFB3B5B6F694BB9E, %merged.bb33 ], [ 0xBF98ED20B1D6A6D8, %merged.bb34 ], [ 0xBF48C2CA21FD14A5, %merged.bb36 ], [ 0xBF2F1E266EB4C824, %merged.bb37 ]
  %merged.select115 = phi double [ 0xBF676495E4B7EAAA, %merged.bb33 ], [ 0xBF3D2E78945F9AC6, %merged.bb34 ], [ 0xBEBC6E261AE99633, %merged.bb36 ], [ 0xBE91D0F7FEBA5A35, %merged.bb37 ]
  %merged.select114 = phi double [ 0xBF0B3634004E0F5C, %merged.bb33 ], [ 0xBED0C1E92AD969EF, %merged.bb34 ], [ 0xBE2007A65CA14E38, %merged.bb36 ], [ 0xBDE40A018263D493, %merged.bb37 ]
  %merged.select113 = phi double [ 0x3E1390C28573DB0F, %merged.bb33 ], [ 0x3DB79116B58241AA, %merged.bb34 ], [ 0x3CA5D280D4B5A285, %merged.bb36 ], [ 0x3C4B275AC5F91B68, %merged.bb37 ]
  %merged.select112 = phi double [ 0xBE9C2F1FFD2FFECD, %merged.bb33 ], [ 0xBE512769C01EA7C5, %merged.bb34 ], [ 0xBD7021DF3392EE60, %merged.bb36 ], [ 0xBD241E51766A91FB, %merged.bb37 ]
  %merged.select111 = phi double [ 0x3D5866A3E6D0F156, %merged.bb33 ], [ 0x3CED1FCD2AD8841F, %merged.bb34 ], [ 0x3BAA9A26E0297ED8, %merged.bb36 ], [ 0x3B408480D3491A50, %merged.bb37 ]
  %merged.select107 = phi double [ %779, %merged.bb33 ], [ %779, %merged.bb34 ], [ %874, %merged.bb36 ], [ %874, %merged.bb37 ]
  %merged.select104.in = phi i32 [ %785, %merged.bb33 ], [ %785, %merged.bb34 ], [ %880, %merged.bb36 ], [ %880, %merged.bb37 ]
  %merged.select102 = phi double [ %869, %merged.bb33 ], [ %869, %merged.bb34 ], [ %964, %merged.bb36 ], [ %964, %merged.bb37 ]
  %merged.select101 = phi double [ %1054, %merged.bb33 ], [ %1061, %merged.bb34 ], [ %1068, %merged.bb36 ], [ %1075, %merged.bb37 ]
  %merged.select100 = phi double [ %1053, %merged.bb33 ], [ %1060, %merged.bb34 ], [ %1067, %merged.bb36 ], [ %1074, %merged.bb37 ]
  %1076 = phi i1 [ %cmp40.i.i.i.i, %merged.bb33 ], [ %cmp40.i.i.i.i, %merged.bb34 ], [ %cmp84.i.i.i.i, %merged.bb36 ], [ %cmp84.i.i.i.i, %merged.bb37 ]
  %merged.select104 = sitofp i32 %merged.select104.in to double
  br i1 %1076, label %merged.bb71, label %merged.bb72

merged.bb71:                                      ; preds = %merged.bb70
  %1077 = fadd double %merged.select100, %merged.select101
  %1078 = fadd double %merged.select102, %1077
  %1079 = fsub double %1078, %merged.select102
  %1080 = fsub double %1077, %1079
  %1081 = fadd double %1078, %merged.select104
  %1082 = fsub double %1081, %merged.select104
  %1083 = fsub double %1082, %1081
  %1084 = fadd double %1083, %merged.select104
  %1085 = fsub double %1078, %1082
  %1086 = fadd double %1085, %1084
  %1087 = fadd double %1080, %1086
  %1088 = fadd double %1081, %1087
  %1089 = tail call double @llvm.fabs.f64(double %merged.select107) #4
  %1090 = fcmp oeq double %1089, 0x7FF0000000000000
  %1091 = select i1 %1090, double %merged.select107, double %1088
  %1092 = fcmp olt double %merged.select107, 0.000000e+00
  %1093 = select i1 %1092, double 0x7FF8000000000000, double %1091
  %1094 = fcmp oeq double %merged.select107, 0.000000e+00
  %1095 = select i1 %1094, double 0xFFF0000000000000, double %1093
  %1096 = fmul double %1095, %1095
  %1097 = fmul double %1096, %merged.select86
  %1098 = fsub double %merged.select87, %1097
  %1099 = fmul double %1096, %merged.select88
  %1100 = fsub double %merged.select89, %1099
  %1101 = fmul double %1096, %1098
  %1102 = fmul double %1096, %1100
  %1103 = fadd double %1101, %merged.select90
  %1104 = fadd double %1102, %merged.select91
  %1105 = fmul double %1096, %1103
  %1106 = fmul double %1096, %1104
  %1107 = fadd double %1105, %merged.select92
  %1108 = fadd double %1106, %merged.select93
  %1109 = fmul double %1095, %1107
  %1110 = fsub double %1108, %1109
  %1111 = fmul double %1096, %merged.select94
  %1112 = fadd double %1111, %merged.select95
  %1113 = fmul double %1096, %merged.select96
  %1114 = fadd double %1113, %merged.select97
  %1115 = fmul double %1096, %1112
  %1116 = fmul double %1096, %1114
  %1117 = fadd double %1115, %merged.select98
  %1118 = fadd double %1116, %merged.select99
  %1119 = fmul double %1096, %1117
  %1120 = fadd double %1119, 1.000000e+00
  %1121 = fmul double %1095, %1118
  %1122 = fsub double %1120, %1121
  %1123 = fdiv double %1110, %1122
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

merged.bb72:                                      ; preds = %merged.bb70
  %1124 = fadd double %merged.select100, %merged.select101
  %1125 = fadd double %merged.select102, %1124
  %1126 = fsub double %1125, %merged.select102
  %1127 = fsub double %1124, %1126
  %1128 = fadd double %1125, %merged.select104
  %1129 = fsub double %1128, %merged.select104
  %1130 = fsub double %1129, %1128
  %1131 = fadd double %1130, %merged.select104
  %1132 = fsub double %1125, %1129
  %1133 = fadd double %1132, %1131
  %1134 = fadd double %1127, %1133
  %1135 = fadd double %1128, %1134
  %1136 = tail call double @llvm.fabs.f64(double %merged.select107) #4
  %1137 = fcmp oeq double %1136, 0x7FF0000000000000
  %1138 = select i1 %1137, double %merged.select107, double %1135
  %1139 = fcmp olt double %merged.select107, 0.000000e+00
  %1140 = select i1 %1139, double 0x7FF8000000000000, double %1138
  %1141 = fcmp oeq double %merged.select107, 0.000000e+00
  %1142 = select i1 %1141, double 0xFFF0000000000000, double %1140
  %1143 = fmul double %1142, %1142
  %1144 = fmul double %1143, %merged.select111
  %1145 = fsub double %merged.select112, %1144
  %1146 = fmul double %1143, %merged.select113
  %1147 = fsub double %merged.select114, %1146
  %1148 = fmul double %1143, %1145
  %1149 = fmul double %1143, %1147
  %1150 = fadd double %1148, %merged.select115
  %1151 = fadd double %1149, %merged.select116
  %1152 = fmul double %1143, %1150
  %1153 = fmul double %1143, %1151
  %1154 = fadd double %1152, %merged.select117
  %1155 = fadd double %1153, %merged.select118
  %1156 = fmul double %1142, %1154
  %1157 = fsub double %1155, %1156
  %1158 = fmul double %1143, %merged.select119
  %1159 = fadd double %1158, %merged.select120
  %1160 = fmul double %1143, %merged.select121
  %1161 = fadd double %1160, %merged.select122
  %1162 = fmul double %1143, %1159
  %1163 = fmul double %1143, %1161
  %1164 = fadd double %1162, %merged.select123
  %1165 = fadd double %1163, %merged.select124
  %1166 = fmul double %1143, %1164
  %1167 = fadd double %1166, 1.000000e+00
  %1168 = fmul double %1142, %1165
  %1169 = fsub double %1167, %1168
  %1170 = fdiv double %1157, %1169
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.frexp.exp.i32.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.frexp.mant.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i1 @llvm.amdgcn.class.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.ldexp.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rcp.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fma.v2f64(<2 x double>, <2 x double>, <2 x double>) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.abs.i32(i32, i1 immarg) #1

attributes #0 = { nofree norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="128" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }
attributes #4 = { nounwind readnone }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/charitha22/cgo22ae-darm-code.git e9bc0540325ad9806313d34e84fc901496fd8be6)"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i16 1, i16 1025}
!6 = !{}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = !{!"evaluate:%fusion.side13", !"evaluate:%fusion.side14"}
!13 = !{!"merge(evaluate:%fusion.side13,evaluate:%fusion.side14)"}
!14 = !{!"evaluate:%if.then20.i.i.i.i", !"evaluate:%decision.dispatch4", !"evaluate:%decision.dispatch"}
!15 = !{!"merge(evaluate:%if.then20.i.i.i.i,merge(evaluate:%decision.dispatch4,evaluate:%decision.dispatch))"}
!16 = !{!"evaluate:%decision.dispatch4", !"evaluate:%decision.dispatch"}
!17 = !{!"merge(evaluate:%decision.dispatch4,evaluate:%decision.dispatch)"}
