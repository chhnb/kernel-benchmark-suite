; ModuleID = '/data/home/chh/kernel-benchmark-suite-dataflow-b2b/build/dataflow-corpus/step7/MapAiry/anchor/trial-70/fused.ll'
source_filename = "/home/chh/kernel-benchmark-suite/cases/boost-mapairy/source/kernel.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

@_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 0x3FE428A2F98D728B, double 0x3FE965FEA53D6E3D, double 1.000000e+00, double 0x3FF428A2F98D728B, double 0x3FF965FEA53D6E3D], align 16

; Function Attrs: nofree norecurse nounwind
define protected amdgpu_kernel void @evaluate(double addrspace(1)* nocapture readonly %input.coerce, double addrspace(1)* nocapture %output.coerce, i32 %n) local_unnamed_addr #0 {
entry:
  %0 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %1 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %2 = getelementptr i8, i8 addrspace(4)* %1, i64 4
  %3 = bitcast i8 addrspace(4)* %2 to i16 addrspace(4)*
  %4 = load i16, i16 addrspace(4)* %3, align 4, !range !5, !invariant.load !6
  %5 = zext i16 %4 to i32
  %6 = mul i32 %0, %5
  %7 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !7
  %add = add i32 %6, %7
  %cmp = icmp slt i32 %add, %n
  br i1 %cmp, label %if.end8.i.i, label %if.end

if.end8.i.i:                                      ; preds = %entry
  %idxprom = sext i32 %add to i64
  %arrayidx11 = getelementptr inbounds double, double addrspace(1)* %input.coerce, i64 %idxprom
  %arrayidx.val = load double, double addrspace(1)* %arrayidx11, align 8, !tbaa !8
  %cmp.i3.i.i = fcmp olt double %arrayidx.val, 0.000000e+00
  %cmp1.i.i.i = fcmp ogt double %arrayidx.val, 1.000000e+00
  %or.cond.i.i.i = or i1 %cmp.i3.i.i, %cmp1.i.i.i
  br i1 %or.cond.i.i.i, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %lor.lhs.false2.i.i.i

lor.lhs.false2.i.i.i:                             ; preds = %if.end8.i.i
  %cmp.i.i.i.i.i = fcmp uno double %arrayidx.val, 0.000000e+00
  %cmp.i3.i.i.i.i = fcmp ogt double %arrayidx.val, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i4.i.i = fcmp olt double %arrayidx.val, 0xFFEFFFFFFFFFFFFF
  %lnot.i.i.i.i.not = or i1 %cmp.i3.i.i.i.i, %cmp1.i.i.i4.i.i
  %brmerge = or i1 %cmp.i.i.i.i.i, %lnot.i.i.i.i.not
  br i1 %brmerge, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %if.end14.i.i

if.end14.i.i:                                     ; preds = %lor.lhs.false2.i.i.i
  %cmp.i.i.i = fcmp ogt double %arrayidx.val, 5.000000e-01
  br i1 %cmp.i.i.i, label %if.then.i.i.i, label %cond.false7.i.i.i

if.then.i.i.i:                                    ; preds = %if.end14.i.i
  %sub.i.i.i = fsub double 1.000000e+00, %arrayidx.val
  %cmp.i.i.i.i = fcmp ult double %sub.i.i.i, 2.500000e-01
  br i1 %cmp.i.i.i.i, label %if.else.i.i.i.i, label %if.then.i.i.i.i

if.then.i.i.i.i:                                  ; preds = %if.then.i.i.i
  %sub.i.i.i.i = fadd double %sub.i.i.i, -2.500000e-01
  %mul.i.i.i.i.i.i = fmul double %sub.i.i.i.i, %sub.i.i.i.i
  %mul1.i.i.i.i.i.i = fmul double %mul.i.i.i.i.i.i, 0x404567B47A5D8CA4
  %8 = fsub double 0x405E69E51891A050, %mul1.i.i.i.i.i.i
  %mul5.i.i.i.i.i.i = fmul double %mul.i.i.i.i.i.i, 0x4050AAC38C60A1E3
  %9 = fsub double 0x40548E4AE13E33D8, %mul5.i.i.i.i.i.i
  %mul10.i.i.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %8
  %mul12.i.i.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %9
  %add15.i.i.i.i.i.i = fadd double %mul10.i.i.i.i.i.i, 0xC04860792DC1D02E
  %add18.i.i.i.i.i.i = fadd double %mul12.i.i.i.i.i.i, 0xC0407FAA65922A12
  %mul20.i.i.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %add15.i.i.i.i.i.i
  %mul22.i.i.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %add18.i.i.i.i.i.i
  %add25.i.i.i.i.i.i = fadd double %mul20.i.i.i.i.i.i, 0xC005F196AB7EF904
  %add28.i.i.i.i.i.i = fadd double %mul22.i.i.i.i.i.i, 0x3FDED118296B2018
  %mul30.i.i.i.i.i.i = fmul double %sub.i.i.i.i, %add25.i.i.i.i.i.i
  %add33.i.i.i.i.i.i = fadd double %add28.i.i.i.i.i.i, %mul30.i.i.i.i.i.i
  %mul1.i.i724.i.i.i.i = fmul double %mul.i.i.i.i.i.i, 0x3FF51F0306685285
  %10 = fsub double 0xBFEEB82FAA589934, %mul1.i.i724.i.i.i.i
  %mul5.i.i726.i.i.i.i = fmul double %mul.i.i.i.i.i.i, 0x3FEFDC5AEE1525E4
  %11 = fsub double 0x4043A793DEC20DEB, %mul5.i.i726.i.i.i.i
  %mul10.i.i728.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %10
  %mul12.i.i729.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %11
  %add15.i.i730.i.i.i.i = fadd double %mul10.i.i728.i.i.i.i, 0x401A11C0BB0DC22E
  %add18.i.i731.i.i.i.i = fadd double %mul12.i.i729.i.i.i.i, 0xC04B158FF790C730
  %mul20.i.i732.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %add15.i.i730.i.i.i.i
  %mul22.i.i733.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %add18.i.i731.i.i.i.i
  %add25.i.i734.i.i.i.i = fadd double %mul20.i.i732.i.i.i.i, 0xC02E8C55CA7195EF
  %add28.i.i735.i.i.i.i = fadd double %mul22.i.i733.i.i.i.i, 0x403058D46A8EC004
  %mul30.i.i736.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %add25.i.i734.i.i.i.i
  %mul32.i.i737.i.i.i.i = fmul double %mul.i.i.i.i.i.i, %add28.i.i735.i.i.i.i
  %add35.i.i738.i.i.i.i = fadd double %mul30.i.i736.i.i.i.i, 0x4020675EC4F85A38
  %add38.i.i739.i.i.i.i = fadd double %mul32.i.i737.i.i.i.i, 1.000000e+00
  %mul40.i.i740.i.i.i.i = fmul double %sub.i.i.i.i, %add35.i.i738.i.i.i.i
  %add43.i.i741.i.i.i.i = fadd double %add38.i.i739.i.i.i.i, %mul40.i.i740.i.i.i.i
  %div.i.i.i.i = fdiv double %add33.i.i.i.i.i.i, %add43.i.i741.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else.i.i.i.i:                                  ; preds = %if.then.i.i.i
  %cmp2.i.i.i.i = fcmp ult double %sub.i.i.i, 1.250000e-01
  br i1 %cmp2.i.i.i.i, label %if.else9.i.i.i.i, label %if.then3.i.i.i.i

if.then3.i.i.i.i:                                 ; preds = %if.else.i.i.i.i
  %sub5.i.i.i.i = fadd double %sub.i.i.i, -1.250000e-01
  %mul.i.i712.i.i.i.i = fmul double %sub5.i.i.i.i, %sub5.i.i.i.i
  %mul1.i.i713.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, 0x409819CEF5B4E6C7
  %add.i.i714.i.i.i.i = fadd double %mul1.i.i713.i.i.i.i, 0xC096FC492E087B38
  %mul5.i.i715.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, 0x4051B7FD7FEEB259
  %12 = fsub double 0xC07E56261CB553E9, %mul5.i.i715.i.i.i.i
  %mul10.i.i717.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, %add.i.i714.i.i.i.i
  %mul12.i.i718.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, %12
  %add15.i.i719.i.i.i.i = fadd double %mul10.i.i717.i.i.i.i, 0x4036AD73494335DA
  %add18.i.i720.i.i.i.i = fadd double %mul12.i.i718.i.i.i.i, 0x4034FFCB850049DF
  %mul20.i.i721.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, %add15.i.i719.i.i.i.i
  %add23.i.i.i.i.i.i = fadd double %mul20.i.i721.i.i.i.i, 0x3FFB3E8B8B7EC8F9
  %mul25.i.i.i.i.i.i = fmul double %sub5.i.i.i.i, %add18.i.i720.i.i.i.i
  %add28.i.i722.i.i.i.i = fadd double %mul25.i.i.i.i.i.i, %add23.i.i.i.i.i.i
  %mul1.i.i698.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, 0x406113A5A6902AC1
  %add.i.i699.i.i.i.i = fadd double %mul1.i.i698.i.i.i.i, 0xC083E59B9D34A0F1
  %mul5.i.i700.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, 0x4071AEC837B9190D
  %13 = fsub double 0x406A5A0FD2D4B901, %mul5.i.i700.i.i.i.i
  %mul10.i.i702.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, %add.i.i699.i.i.i.i
  %mul12.i.i703.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, %13
  %add15.i.i704.i.i.i.i = fadd double %mul10.i.i702.i.i.i.i, 0x407BA4300BFE5087
  %add18.i.i705.i.i.i.i = fadd double %mul12.i.i703.i.i.i.i, 0x4063AA2F5D62DCD3
  %mul20.i.i706.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, %add15.i.i704.i.i.i.i
  %mul22.i.i707.i.i.i.i = fmul double %mul.i.i712.i.i.i.i, %add18.i.i705.i.i.i.i
  %add25.i.i708.i.i.i.i = fadd double %mul20.i.i706.i.i.i.i, 0x40354F2A1256B431
  %add28.i.i709.i.i.i.i = fadd double %mul22.i.i707.i.i.i.i, 1.000000e+00
  %mul30.i.i710.i.i.i.i = fmul double %sub5.i.i.i.i, %add25.i.i708.i.i.i.i
  %add33.i.i711.i.i.i.i = fadd double %add28.i.i709.i.i.i.i, %mul30.i.i710.i.i.i.i
  %div8.i.i.i.i = fdiv double %add28.i.i722.i.i.i.i, %add33.i.i711.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else9.i.i.i.i:                                 ; preds = %if.else.i.i.i.i
  %14 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %sub.i.i.i) #3
  %15 = add nsw i32 %14, -1
  %16 = fcmp uno double %sub.i.i.i, 0.000000e+00
  %17 = tail call double @llvm.fabs.f64(double %sub.i.i.i) #4
  %18 = fcmp oeq double %17, 0x7FF0000000000000
  %19 = or i1 %16, %18
  %20 = select i1 %19, i32 2147483647, i32 %15
  %21 = fcmp oeq double %sub.i.i.i, 0.000000e+00
  %22 = select i1 %21, i32 -2147483648, i32 %20
  %cmp11.i.i.i.i = icmp sgt i32 %22, -5
  br i1 %cmp11.i.i.i.i, label %if.then12.i.i.i.i, label %if.else21.i.i.i.i

if.then12.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %23 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 3) #3
  %24 = tail call double @llvm.amdgcn.frexp.mant.f64(double %23) #3
  %25 = fcmp olt double %24, 0x3FE5555555555555
  %26 = zext i1 %25 to i32
  %27 = tail call double @llvm.amdgcn.ldexp.f64(double %24, i32 %26) #3
  %28 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %23) #3
  %29 = sub nsw i32 %28, %26
  %30 = fadd double %27, -1.000000e+00
  %31 = fadd double %27, 1.000000e+00
  %32 = fsub double %31, %27
  %33 = fsub double %31, %32
  %34 = fsub double %27, %33
  %35 = fsub double 1.000000e+00, %32
  %36 = fadd double %35, %34
  %37 = tail call double @llvm.amdgcn.rcp.f64(double %31) #3
  %38 = fneg double %31
  %39 = tail call double @llvm.fma.f64(double %38, double %37, double 1.000000e+00) #3
  %40 = tail call double @llvm.fma.f64(double %39, double %37, double %37) #3
  %41 = tail call double @llvm.fma.f64(double %38, double %40, double 1.000000e+00) #3
  %42 = tail call double @llvm.fma.f64(double %41, double %40, double %40) #3
  %43 = fmul double %30, %42
  %44 = fmul double %31, %43
  %45 = fneg double %44
  %46 = tail call double @llvm.fma.f64(double %43, double %31, double %45) #3
  %47 = tail call double @llvm.fma.f64(double %43, double %36, double %46) #3
  %48 = fadd double %44, %47
  %49 = fsub double %48, %44
  %50 = fsub double %47, %49
  %51 = fsub double %30, %48
  %52 = fsub double %30, %51
  %53 = fsub double %52, %48
  %54 = fsub double %53, %50
  %55 = fadd double %51, %54
  %56 = fmul double %42, %55
  %57 = fadd double %43, %56
  %58 = fsub double %57, %43
  %59 = fsub double %56, %58
  %60 = fmul double %57, %57
  %61 = fneg double %60
  %62 = tail call double @llvm.fma.f64(double %57, double %57, double %61) #3
  %63 = fmul double %59, 2.000000e+00
  %64 = tail call double @llvm.fma.f64(double %57, double %63, double %62) #3
  %65 = tail call double @llvm.fma.f64(double %59, double %59, double %64) #3
  %66 = fadd double %60, %65
  %67 = fsub double %66, %60
  %68 = fsub double %65, %67
  %69 = tail call double @llvm.fma.f64(double %66, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %70 = tail call double @llvm.fma.f64(double %66, double %69, double 0x3FC7474DD7F4DF2E) #3
  %71 = tail call double @llvm.fma.f64(double %66, double %70, double 0x3FCC71C016291751) #3
  %72 = tail call double @llvm.fma.f64(double %66, double %71, double 0x3FD249249B27ACF1) #3
  %73 = tail call double @llvm.fma.f64(double %66, double %72, double 0x3FD99999998EF7B6) #3
  %74 = tail call double @llvm.fma.f64(double %66, double %73, double 0x3FE5555555555780) #3
  %75 = tail call double @llvm.amdgcn.ldexp.f64(double %57, i32 1) #3
  %76 = tail call double @llvm.amdgcn.ldexp.f64(double %59, i32 1) #3
  %77 = fmul double %57, %66
  %78 = fneg double %77
  %79 = tail call double @llvm.fma.f64(double %57, double %66, double %78) #3
  %80 = fmul double %59, %66
  %81 = tail call double @llvm.fma.f64(double %57, double %68, double %80) #3
  %82 = fadd double %79, %81
  %83 = fadd double %77, %82
  %84 = fsub double %83, %77
  %85 = fsub double %82, %84
  %86 = fmul double %83, %74
  %87 = fneg double %86
  %88 = tail call double @llvm.fma.f64(double %83, double %74, double %87) #3
  %89 = tail call double @llvm.fma.f64(double %85, double %74, double %88) #3
  %90 = fadd double %86, %89
  %91 = fsub double %90, %86
  %92 = fsub double %89, %91
  %93 = fadd double %75, %90
  %94 = fsub double %93, %75
  %95 = fsub double %93, %94
  %96 = fsub double %75, %95
  %97 = fsub double %90, %94
  %98 = fadd double %97, %96
  %99 = fadd double %76, %92
  %100 = fsub double %99, %76
  %101 = fsub double %99, %100
  %102 = fsub double %76, %101
  %103 = fsub double %92, %100
  %104 = fadd double %103, %102
  %105 = fadd double %99, %98
  %106 = fadd double %93, %105
  %107 = fsub double %106, %93
  %108 = fsub double %105, %107
  %109 = fadd double %104, %108
  %110 = fadd double %106, %109
  %111 = fsub double %110, %106
  %112 = fsub double %109, %111
  %113 = sitofp i32 %29 to double
  %114 = fmul double %110, 0x3FF71547652B82FE
  %115 = fneg double %114
  %116 = fmul double %110, 0x3C7777D0FFDA0D24
  %117 = insertelement <2 x double> undef, double %110, i32 0
  %118 = insertelement <2 x double> %117, double %112, i32 1
  %119 = insertelement <2 x double> undef, double %115, i32 0
  %120 = insertelement <2 x double> %119, double %116, i32 1
  %121 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %118, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %120) #3
  %122 = extractelement <2 x double> %121, i32 0
  %123 = extractelement <2 x double> %121, i32 1
  %124 = fadd double %122, %123
  %125 = fadd double %114, %124
  %126 = fsub double %125, %114
  %127 = fsub double %124, %126
  %128 = fadd double %125, %113
  %129 = fsub double %128, %113
  %130 = fsub double %129, %128
  %131 = fadd double %130, %113
  %132 = fsub double %125, %129
  %133 = fadd double %132, %131
  %134 = fadd double %127, %133
  %135 = fadd double %128, %134
  %136 = tail call double @llvm.fabs.f64(double %23) #4
  %137 = fcmp oeq double %136, 0x7FF0000000000000
  %138 = select i1 %137, double %23, double %135
  %139 = fcmp olt double %23, 0.000000e+00
  %140 = select i1 %139, double 0x7FF8000000000000, double %138
  %141 = fcmp oeq double %23, 0.000000e+00
  %142 = select i1 %141, double 0xFFF0000000000000, double %140
  %mul.i.i682.i.i.i.i = fmul double %142, %142
  %mul1.i.i683.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3ED3E1F985CBB733
  %add.i.i684.i.i.i.i = fadd double %mul1.i.i683.i.i.i.i, 0x3F385DA443F57737
  %mul5.i.i685.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F24E9382EAABDBB
  %add7.i.i686.i.i.i.i = fadd double %mul5.i.i685.i.i.i.i, 0x3F77E2A342AA4E3B
  %mul10.i.i687.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i684.i.i.i.i
  %mul12.i.i688.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i686.i.i.i.i
  %add15.i.i689.i.i.i.i = fadd double %mul10.i.i687.i.i.i.i, 0x3F9808F2B640E69B
  %add18.i.i690.i.i.i.i = fadd double %mul12.i.i688.i.i.i.i, 0x3F9DD5C523A6CF6D
  %mul20.i.i691.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i689.i.i.i.i
  %mul22.i.i692.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i690.i.i.i.i
  %add25.i.i693.i.i.i.i = fadd double %mul20.i.i691.i.i.i.i, 0x3FD3E6D375851610
  %add28.i.i694.i.i.i.i = fadd double %mul22.i.i692.i.i.i.i, 0x3FDB3E8B8B7EC8FA
  %143 = fmul double %142, %add25.i.i693.i.i.i.i
  %add33.i.i696.i.i.i.i = fsub double %add28.i.i694.i.i.i.i, %143
  %mul1.i.i668.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3EF03AD80F271435
  %add.i.i669.i.i.i.i = fadd double %mul1.i.i668.i.i.i.i, 0x3F577B23357A1929
  %mul5.i.i670.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F27C5B13F4BAFF2
  %add7.i.i671.i.i.i.i = fadd double %mul5.i.i670.i.i.i.i, 0x3F825620F70E4E86
  %mul10.i.i672.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i669.i.i.i.i
  %mul12.i.i673.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i671.i.i.i.i
  %add15.i.i674.i.i.i.i = fadd double %mul10.i.i672.i.i.i.i, 0x3FA38976FFA62DF3
  %add18.i.i675.i.i.i.i = fadd double %mul12.i.i673.i.i.i.i, 0x3FBACD3553111974
  %mul20.i.i676.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i674.i.i.i.i
  %mul22.i.i677.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i675.i.i.i.i
  %add25.i.i678.i.i.i.i = fadd double %mul20.i.i676.i.i.i.i, 0x3FDA8C1A7A09CF75
  %add28.i.i679.i.i.i.i = fadd double %mul22.i.i677.i.i.i.i, 1.000000e+00
  %144 = fmul double %142, %add25.i.i678.i.i.i.i
  %add33.i.i681.i.i.i.i = fsub double %add28.i.i679.i.i.i.i, %144
  %mul.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i590.i.i.i.i = fcmp ogt double %mul.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i591.i.i.i.i = fcmp oeq double %mul.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i592.i.i.i.i = or i1 %cmp.i.i.i.i590.i.i.i.i, %cmp.i.i.i591.i.i.i.i
  br i1 %or.cond.i.i.i592.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end.i.i.i594.i.i.i.i

if.end.i.i.i594.i.i.i.i:                          ; preds = %if.then12.i.i.i.i
  %cmp.i.i.i.i.i593.i.i.i.i = fcmp uno double %mul.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i593.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end7.i.i.i620.i.i.i.i

if.end7.i.i.i620.i.i.i.i:                         ; preds = %if.end.i.i.i594.i.i.i.i
  %145 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul.i.i.i.i) #3
  %146 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul.i.i.i.i) #3
  %147 = tail call i1 @llvm.amdgcn.class.f64(double %mul.i.i.i.i, i32 519) #3
  %148 = select i1 %147, i32 0, i32 %145
  %149 = select i1 %147, double %mul.i.i.i.i, double %146
  %mul.i.i.i.i.i606.i.i.i.i = fmul double %149, %149
  %mul1.i.i.i.i.i607.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i608.i.i.i.i = fadd double %mul1.i.i.i.i.i607.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i609.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FE479D17050CA47
  %150 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i609.i.i.i.i
  %mul10.i.i.i.i.i611.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %add.i.i.i.i.i608.i.i.i.i
  %mul12.i.i.i.i.i612.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %150
  %add15.i.i.i.i.i613.i.i.i.i = fadd double %mul10.i.i.i.i.i611.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i614.i.i.i.i = fadd double %mul12.i.i.i.i.i612.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i615.i.i.i.i = fmul double %149, %add15.i.i.i.i.i613.i.i.i.i
  %add23.i.i.i.i.i616.i.i.i.i = fadd double %add18.i.i.i.i.i614.i.i.i.i, %mul20.i.i.i.i.i615.i.i.i.i
  %.frozen = freeze i32 %148
  %div.i.i.i617.i.i.i.i = sdiv i32 %.frozen, 3
  %151 = sub nsw i32 0, %div.i.i.i617.i.i.i.i
  %152 = call i32 @llvm.abs.i32(i32 %div.i.i.i617.i.i.i.i, i1 true)
  %cmp11.i.i.i619.i.i.i.i = icmp ult i32 %152, 64
  br i1 %cmp11.i.i.i619.i.i.i.i, label %if.then12.i.i.i622.i.i.i.i, label %if.else21.i.i.i634.i.i.i.i

if.then12.i.i.i622.i.i.i.i:                       ; preds = %if.end7.i.i.i620.i.i.i.i
  %cmp13.i.i.i621.i.i.i.i = icmp sgt i32 %148, 2
  br i1 %cmp13.i.i.i621.i.i.i.i, label %if.then14.i.i.i627.i.i.i.i, label %if.else.i.i.i633.i.i.i.i

if.then14.i.i.i627.i.i.i.i:                       ; preds = %if.then12.i.i.i622.i.i.i.i
  %sh_prom.i.i.i623.i.i.i.i = zext i32 %div.i.i.i617.i.i.i.i to i64
  %shl.i.i.i624.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i623.i.i.i.i
  %conv.i.i.i625.i.i.i.i = uitofp i64 %shl.i.i.i624.i.i.i.i to double
  %mul.i.i.i626.i.i.i.i = fmul double %add23.i.i.i.i.i616.i.i.i.i, %conv.i.i.i625.i.i.i.i
  br label %if.end23.i.i.i640.i.i.i.i

if.else.i.i.i633.i.i.i.i:                         ; preds = %if.then12.i.i.i622.i.i.i.i
  %sh_prom16.i.i.i629.i.i.i.i = zext i32 %151 to i64
  %shl17.i.i.i630.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i629.i.i.i.i
  %conv18.i.i.i631.i.i.i.i = uitofp i64 %shl17.i.i.i630.i.i.i.i to double
  %div19.i.i.i632.i.i.i.i = fdiv double %add23.i.i.i.i.i616.i.i.i.i, %conv18.i.i.i631.i.i.i.i
  br label %if.end23.i.i.i640.i.i.i.i

if.else21.i.i.i634.i.i.i.i:                       ; preds = %if.end7.i.i.i620.i.i.i.i
  %153 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i616.i.i.i.i, i32 %div.i.i.i617.i.i.i.i) #3
  br label %if.end23.i.i.i640.i.i.i.i

if.end23.i.i.i640.i.i.i.i:                        ; preds = %if.else21.i.i.i634.i.i.i.i, %if.else.i.i.i633.i.i.i.i, %if.then14.i.i.i627.i.i.i.i
  %guess.i.i.i589.i.i.i.i.0 = phi double [ %mul.i.i.i626.i.i.i.i, %if.then14.i.i.i627.i.i.i.i ], [ %div19.i.i.i632.i.i.i.i, %if.else.i.i.i633.i.i.i.i ], [ %153, %if.else21.i.i.i634.i.i.i.i ]
  %.neg6 = mul nsw i32 %div.i.i.i617.i.i.i.i, -3
  %rem.i.i.i635.i.i.i.i.decomposed = add i32 %.frozen, 2
  %add.i.i.i636.i.i.i.i = add i32 %rem.i.i.i635.i.i.i.i.decomposed, %.neg6
  %154 = zext i32 %add.i.i.i636.i.i.i.i to i64
  %arrayidx1.i.i.i637.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %154
  %155 = load double, double addrspace(4)* %arrayidx1.i.i.i637.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i638.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.0, %155
  %cmp26.i.i.i639.i.i.i.i = icmp slt i32 %148, 1021
  br i1 %cmp26.i.i.i639.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i

do.body.i.i.i651.i.i.i.i:                         ; preds = %do.body.i.i.i651.i.i.i.i, %if.end23.i.i.i640.i.i.i.i
  %guess.i.i.i589.i.i.i.i.1 = phi double [ %mul24.i.i.i638.i.i.i.i, %if.end23.i.i.i640.i.i.i.i ], [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ]
  %mul28.i.i.i641.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %guess.i.i.i589.i.i.i.i.1
  %mul29.i.i.i642.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %mul28.i.i.i641.i.i.i.i
  %add30.i.i.i643.i.i.i.i = fadd double %mul.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add31.i.i.i644.i.i.i.i = fadd double %mul.i.i.i.i, %add30.i.i.i643.i.i.i.i
  %add32.i.i.i645.i.i.i.i = fadd double %mul29.i.i.i642.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add33.i.i.i646.i.i.i.i = fadd double %mul.i.i.i.i, %add32.i.i.i645.i.i.i.i
  %div34.i.i.i647.i.i.i.i = fdiv double %add31.i.i.i644.i.i.i.i, %add33.i.i.i646.i.i.i.i
  %mul35.i.i.i648.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %div34.i.i.i647.i.i.i.i
  %sub36.i.i.i649.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i647.i.i.i.i
  %156 = tail call double @llvm.fabs.f64(double %sub36.i.i.i649.i.i.i.i) #3
  %cmp38.i.i.i650.i.i.i.i = fcmp ogt double %156, 0x3EC0000000000000
  br i1 %cmp38.i.i.i650.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

do.body40.i.i.i662.i.i.i.i:                       ; preds = %do.body40.i.i.i662.i.i.i.i, %if.end23.i.i.i640.i.i.i.i
  %guess.i.i.i589.i.i.i.i.2 = phi double [ %mul24.i.i.i638.i.i.i.i, %if.end23.i.i.i640.i.i.i.i ], [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ]
  %mul41.i.i.i652.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, %guess.i.i.i589.i.i.i.i.2
  %div42.i.i.i653.i.i.i.i = fdiv double %mul.i.i.i.i, %guess.i.i.i589.i.i.i.i.2
  %sub43.i.i.i654.i.i.i.i = fsub double %mul41.i.i.i652.i.i.i.i, %div42.i.i.i653.i.i.i.i
  %mul44.i.i.i655.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i656.i.i.i.i = fdiv double %mul.i.i.i.i, %mul41.i.i.i652.i.i.i.i
  %add46.i.i.i657.i.i.i.i = fadd double %mul44.i.i.i655.i.i.i.i, %div45.i.i.i656.i.i.i.i
  %div47.i.i.i658.i.i.i.i = fdiv double %sub43.i.i.i654.i.i.i.i, %add46.i.i.i657.i.i.i.i
  %sub48.i.i.i659.i.i.i.i = fsub double %guess.i.i.i589.i.i.i.i.2, %div47.i.i.i658.i.i.i.i
  %mul50.i.i.i660.i.i.i.i = fmul double %sub48.i.i.i659.i.i.i.i, 0x3EC0000000000000
  %157 = tail call double @llvm.fabs.f64(double %div47.i.i.i658.i.i.i.i) #3
  %cmp52.i.i.i661.i.i.i.i = fcmp olt double %mul50.i.i.i660.i.i.i.i, %157
  br i1 %cmp52.i.i.i661.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i: ; preds = %do.body40.i.i.i662.i.i.i.i, %do.body.i.i.i651.i.i.i.i, %if.end.i.i.i594.i.i.i.i, %if.then12.i.i.i.i
  %retval.0.i.i.i665.i.i.i.i = phi double [ %mul.i.i.i.i, %if.then12.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i594.i.i.i.i ], [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ], [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ]
  %mul19.i.i.i.i = fmul double %add33.i.i681.i.i.i.i, %retval.0.i.i.i665.i.i.i.i
  %div20.i.i.i.i = fdiv double %add33.i.i696.i.i.i.i, %mul19.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else21.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %cmp23.i.i.i.i = icmp sgt i32 %22, -9
  br i1 %cmp23.i.i.i.i, label %if.then24.i.i.i.i, label %if.else35.i.i.i.i

if.then24.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %158 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 4) #3
  %159 = tail call double @llvm.amdgcn.frexp.mant.f64(double %158) #3
  %160 = fcmp olt double %159, 0x3FE5555555555555
  %161 = zext i1 %160 to i32
  %162 = tail call double @llvm.amdgcn.ldexp.f64(double %159, i32 %161) #3
  %163 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %158) #3
  %164 = sub nsw i32 %163, %161
  %165 = fadd double %162, -1.000000e+00
  %166 = fadd double %162, 1.000000e+00
  %167 = fsub double %166, %162
  %168 = fsub double %166, %167
  %169 = fsub double %162, %168
  %170 = fsub double 1.000000e+00, %167
  %171 = fadd double %170, %169
  %172 = tail call double @llvm.amdgcn.rcp.f64(double %166) #3
  %173 = fneg double %166
  %174 = tail call double @llvm.fma.f64(double %173, double %172, double 1.000000e+00) #3
  %175 = tail call double @llvm.fma.f64(double %174, double %172, double %172) #3
  %176 = tail call double @llvm.fma.f64(double %173, double %175, double 1.000000e+00) #3
  %177 = tail call double @llvm.fma.f64(double %176, double %175, double %175) #3
  %178 = fmul double %165, %177
  %179 = fmul double %166, %178
  %180 = fneg double %179
  %181 = tail call double @llvm.fma.f64(double %178, double %166, double %180) #3
  %182 = tail call double @llvm.fma.f64(double %178, double %171, double %181) #3
  %183 = fadd double %179, %182
  %184 = fsub double %183, %179
  %185 = fsub double %182, %184
  %186 = fsub double %165, %183
  %187 = fsub double %165, %186
  %188 = fsub double %187, %183
  %189 = fsub double %188, %185
  %190 = fadd double %186, %189
  %191 = fmul double %177, %190
  %192 = fadd double %178, %191
  %193 = fsub double %192, %178
  %194 = fsub double %191, %193
  %195 = fmul double %192, %192
  %196 = fneg double %195
  %197 = tail call double @llvm.fma.f64(double %192, double %192, double %196) #3
  %198 = fmul double %194, 2.000000e+00
  %199 = tail call double @llvm.fma.f64(double %192, double %198, double %197) #3
  %200 = tail call double @llvm.fma.f64(double %194, double %194, double %199) #3
  %201 = fadd double %195, %200
  %202 = fsub double %201, %195
  %203 = fsub double %200, %202
  %204 = tail call double @llvm.fma.f64(double %201, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %205 = tail call double @llvm.fma.f64(double %201, double %204, double 0x3FC7474DD7F4DF2E) #3
  %206 = tail call double @llvm.fma.f64(double %201, double %205, double 0x3FCC71C016291751) #3
  %207 = tail call double @llvm.fma.f64(double %201, double %206, double 0x3FD249249B27ACF1) #3
  %208 = tail call double @llvm.fma.f64(double %201, double %207, double 0x3FD99999998EF7B6) #3
  %209 = tail call double @llvm.fma.f64(double %201, double %208, double 0x3FE5555555555780) #3
  %210 = tail call double @llvm.amdgcn.ldexp.f64(double %192, i32 1) #3
  %211 = tail call double @llvm.amdgcn.ldexp.f64(double %194, i32 1) #3
  %212 = fmul double %192, %201
  %213 = fneg double %212
  %214 = tail call double @llvm.fma.f64(double %192, double %201, double %213) #3
  %215 = fmul double %194, %201
  %216 = tail call double @llvm.fma.f64(double %192, double %203, double %215) #3
  %217 = fadd double %214, %216
  %218 = fadd double %212, %217
  %219 = fsub double %218, %212
  %220 = fsub double %217, %219
  %221 = fmul double %218, %209
  %222 = fneg double %221
  %223 = tail call double @llvm.fma.f64(double %218, double %209, double %222) #3
  %224 = tail call double @llvm.fma.f64(double %220, double %209, double %223) #3
  %225 = fadd double %221, %224
  %226 = fsub double %225, %221
  %227 = fsub double %224, %226
  %228 = fadd double %210, %225
  %229 = fsub double %228, %210
  %230 = fsub double %228, %229
  %231 = fsub double %210, %230
  %232 = fsub double %225, %229
  %233 = fadd double %232, %231
  %234 = fadd double %211, %227
  %235 = fsub double %234, %211
  %236 = fsub double %234, %235
  %237 = fsub double %211, %236
  %238 = fsub double %227, %235
  %239 = fadd double %238, %237
  %240 = fadd double %234, %233
  %241 = fadd double %228, %240
  %242 = fsub double %241, %228
  %243 = fsub double %240, %242
  %244 = fadd double %239, %243
  %245 = fadd double %241, %244
  %246 = fsub double %245, %241
  %247 = fsub double %244, %246
  %248 = sitofp i32 %164 to double
  %249 = fmul double %245, 0x3FF71547652B82FE
  %250 = fneg double %249
  %251 = fmul double %245, 0x3C7777D0FFDA0D24
  %252 = insertelement <2 x double> undef, double %245, i32 0
  %253 = insertelement <2 x double> %252, double %247, i32 1
  %254 = insertelement <2 x double> undef, double %250, i32 0
  %255 = insertelement <2 x double> %254, double %251, i32 1
  %256 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %253, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %255) #3
  %257 = extractelement <2 x double> %256, i32 0
  %258 = extractelement <2 x double> %256, i32 1
  %259 = fadd double %257, %258
  %260 = fadd double %249, %259
  %261 = fsub double %260, %249
  %262 = fsub double %259, %261
  %263 = fadd double %260, %248
  %264 = fsub double %263, %248
  %265 = fsub double %264, %263
  %266 = fadd double %265, %248
  %267 = fsub double %260, %264
  %268 = fadd double %267, %266
  %269 = fadd double %262, %268
  %270 = fadd double %263, %269
  %271 = tail call double @llvm.fabs.f64(double %158) #4
  %272 = fcmp oeq double %271, 0x7FF0000000000000
  %273 = select i1 %272, double %158, double %270
  %274 = fcmp olt double %158, 0.000000e+00
  %275 = select i1 %274, double 0x7FF8000000000000, double %273
  %276 = fcmp oeq double %158, 0.000000e+00
  %277 = select i1 %276, double 0xFFF0000000000000, double %275
  %mul.i.i565.i.i.i.i = fmul double %277, %277
  %mul1.i.i566.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3E919A5BE1262808
  %add.i.i567.i.i.i.i = fadd double %mul1.i.i566.i.i.i.i, 0x3F07A5175B4661FC
  %mul5.i.i568.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3ED3058F91E15D9E
  %add7.i.i569.i.i.i.i = fadd double %mul5.i.i568.i.i.i.i, 0x3F360A6A52B6CEE1
  %mul10.i.i570.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i567.i.i.i.i
  %mul12.i.i571.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i569.i.i.i.i
  %add15.i.i572.i.i.i.i = fadd double %mul10.i.i570.i.i.i.i, 0x3F5C5B8FA36BAEC3
  %add18.i.i573.i.i.i.i = fadd double %mul12.i.i571.i.i.i.i, 0x3F80EDCAE3A5BFEE
  %mul20.i.i574.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i572.i.i.i.i
  %mul22.i.i575.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i573.i.i.i.i
  %add25.i.i576.i.i.i.i = fadd double %mul20.i.i574.i.i.i.i, 0x3F9A5E78F653B833
  %add28.i.i577.i.i.i.i = fadd double %mul22.i.i575.i.i.i.i, 0x3FB5AC2080A26513
  %mul30.i.i578.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i576.i.i.i.i
  %mul32.i.i579.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i577.i.i.i.i
  %add35.i.i580.i.i.i.i = fadd double %mul30.i.i578.i.i.i.i, 0x3FC65686F7A4EE22
  %add38.i.i581.i.i.i.i = fadd double %mul32.i.i579.i.i.i.i, 0x3FD3F40EF6582604
  %mul40.i.i582.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i580.i.i.i.i
  %add43.i.i583.i.i.i.i = fadd double %mul40.i.i582.i.i.i.i, 0x3FE03C236600AD0B
  %278 = fmul double %277, %add38.i.i581.i.i.i.i
  %add48.i.i585.i.i.i.i = fsub double %add43.i.i583.i.i.i.i, %278
  %mul1.i.i547.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EA0457562E8B20F
  %add.i.i548.i.i.i.i = fadd double %mul1.i.i547.i.i.i.i, 0x3F16154BBE28AEB9
  %mul5.i.i549.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EE174949F46ED05
  %add7.i.i550.i.i.i.i = fadd double %mul5.i.i549.i.i.i.i, 0x3F43E3B25F7FFBED
  %mul10.i.i551.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i548.i.i.i.i
  %mul12.i.i552.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i550.i.i.i.i
  %add15.i.i553.i.i.i.i = fadd double %mul10.i.i551.i.i.i.i, 0x3F6B2284D418EE28
  %add18.i.i554.i.i.i.i = fadd double %mul12.i.i552.i.i.i.i, 0x3F8DC663E91E38DD
  %mul20.i.i555.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i553.i.i.i.i
  %mul22.i.i556.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i554.i.i.i.i
  %add25.i.i557.i.i.i.i = fadd double %mul20.i.i555.i.i.i.i, 0x3FA9F261B3019817
  %add28.i.i558.i.i.i.i = fadd double %mul22.i.i556.i.i.i.i, 0x3FC29CC24A62017B
  %mul30.i.i559.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i557.i.i.i.i
  %mul32.i.i560.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i558.i.i.i.i
  %add35.i.i561.i.i.i.i = fadd double %mul30.i.i559.i.i.i.i, 0x3FD660DD0F65AD11
  %add38.i.i562.i.i.i.i = fadd double %mul32.i.i560.i.i.i.i, 0x3FE0E738E979F959
  %mul40.i.i563.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i561.i.i.i.i
  %add43.i.i564.i.i.i.i = fadd double %mul40.i.i563.i.i.i.i, 1.000000e+00
  %279 = fmul double %277, %add38.i.i562.i.i.i.i
  %add48.i.i.i.i.i.i = fsub double %add43.i.i564.i.i.i.i, %279
  %mul31.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i469.i.i.i.i = fcmp ogt double %mul31.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i470.i.i.i.i = fcmp oeq double %mul31.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i471.i.i.i.i = or i1 %cmp.i.i.i.i469.i.i.i.i, %cmp.i.i.i470.i.i.i.i
  br i1 %or.cond.i.i.i471.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end.i.i.i473.i.i.i.i

if.end.i.i.i473.i.i.i.i:                          ; preds = %if.then24.i.i.i.i
  %cmp.i.i.i.i.i472.i.i.i.i = fcmp uno double %mul31.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i472.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end7.i.i.i499.i.i.i.i

if.end7.i.i.i499.i.i.i.i:                         ; preds = %if.end.i.i.i473.i.i.i.i
  %280 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul31.i.i.i.i) #3
  %281 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul31.i.i.i.i) #3
  %282 = tail call i1 @llvm.amdgcn.class.f64(double %mul31.i.i.i.i, i32 519) #3
  %283 = select i1 %282, i32 0, i32 %280
  %284 = select i1 %282, double %mul31.i.i.i.i, double %281
  %mul.i.i.i.i.i485.i.i.i.i = fmul double %284, %284
  %mul1.i.i.i.i.i486.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i487.i.i.i.i = fadd double %mul1.i.i.i.i.i486.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i488.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FE479D17050CA47
  %285 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i488.i.i.i.i
  %mul10.i.i.i.i.i490.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %add.i.i.i.i.i487.i.i.i.i
  %mul12.i.i.i.i.i491.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %285
  %add15.i.i.i.i.i492.i.i.i.i = fadd double %mul10.i.i.i.i.i490.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i493.i.i.i.i = fadd double %mul12.i.i.i.i.i491.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i494.i.i.i.i = fmul double %284, %add15.i.i.i.i.i492.i.i.i.i
  %add23.i.i.i.i.i495.i.i.i.i = fadd double %add18.i.i.i.i.i493.i.i.i.i, %mul20.i.i.i.i.i494.i.i.i.i
  %.frozen209 = freeze i32 %283
  %div.i.i.i496.i.i.i.i = sdiv i32 %.frozen209, 3
  %286 = sub nsw i32 0, %div.i.i.i496.i.i.i.i
  %287 = call i32 @llvm.abs.i32(i32 %div.i.i.i496.i.i.i.i, i1 true)
  %cmp11.i.i.i498.i.i.i.i = icmp ult i32 %287, 64
  br i1 %cmp11.i.i.i498.i.i.i.i, label %if.then12.i.i.i501.i.i.i.i, label %if.else21.i.i.i513.i.i.i.i

if.then12.i.i.i501.i.i.i.i:                       ; preds = %if.end7.i.i.i499.i.i.i.i
  %cmp13.i.i.i500.i.i.i.i = icmp sgt i32 %283, 2
  br i1 %cmp13.i.i.i500.i.i.i.i, label %if.then14.i.i.i506.i.i.i.i, label %if.else.i.i.i512.i.i.i.i

if.then14.i.i.i506.i.i.i.i:                       ; preds = %if.then12.i.i.i501.i.i.i.i
  %sh_prom.i.i.i502.i.i.i.i = zext i32 %div.i.i.i496.i.i.i.i to i64
  %shl.i.i.i503.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i502.i.i.i.i
  %conv.i.i.i504.i.i.i.i = uitofp i64 %shl.i.i.i503.i.i.i.i to double
  %mul.i.i.i505.i.i.i.i = fmul double %add23.i.i.i.i.i495.i.i.i.i, %conv.i.i.i504.i.i.i.i
  br label %if.end23.i.i.i519.i.i.i.i

if.else.i.i.i512.i.i.i.i:                         ; preds = %if.then12.i.i.i501.i.i.i.i
  %sh_prom16.i.i.i508.i.i.i.i = zext i32 %286 to i64
  %shl17.i.i.i509.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i508.i.i.i.i
  %conv18.i.i.i510.i.i.i.i = uitofp i64 %shl17.i.i.i509.i.i.i.i to double
  %div19.i.i.i511.i.i.i.i = fdiv double %add23.i.i.i.i.i495.i.i.i.i, %conv18.i.i.i510.i.i.i.i
  br label %if.end23.i.i.i519.i.i.i.i

if.else21.i.i.i513.i.i.i.i:                       ; preds = %if.end7.i.i.i499.i.i.i.i
  %288 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i495.i.i.i.i, i32 %div.i.i.i496.i.i.i.i) #3
  br label %if.end23.i.i.i519.i.i.i.i

if.end23.i.i.i519.i.i.i.i:                        ; preds = %if.else21.i.i.i513.i.i.i.i, %if.else.i.i.i512.i.i.i.i, %if.then14.i.i.i506.i.i.i.i
  %guess.i.i.i468.i.i.i.i.0 = phi double [ %mul.i.i.i505.i.i.i.i, %if.then14.i.i.i506.i.i.i.i ], [ %div19.i.i.i511.i.i.i.i, %if.else.i.i.i512.i.i.i.i ], [ %288, %if.else21.i.i.i513.i.i.i.i ]
  %.neg5 = mul nsw i32 %div.i.i.i496.i.i.i.i, -3
  %rem.i.i.i514.i.i.i.i.decomposed = add i32 %.frozen209, 2
  %add.i.i.i515.i.i.i.i = add i32 %rem.i.i.i514.i.i.i.i.decomposed, %.neg5
  %289 = zext i32 %add.i.i.i515.i.i.i.i to i64
  %arrayidx1.i.i.i516.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %289
  %290 = load double, double addrspace(4)* %arrayidx1.i.i.i516.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i517.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.0, %290
  %cmp26.i.i.i518.i.i.i.i = icmp slt i32 %283, 1021
  br i1 %cmp26.i.i.i518.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i

do.body.i.i.i530.i.i.i.i:                         ; preds = %do.body.i.i.i530.i.i.i.i, %if.end23.i.i.i519.i.i.i.i
  %guess.i.i.i468.i.i.i.i.1 = phi double [ %mul24.i.i.i517.i.i.i.i, %if.end23.i.i.i519.i.i.i.i ], [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ]
  %mul28.i.i.i520.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %guess.i.i.i468.i.i.i.i.1
  %mul29.i.i.i521.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %mul28.i.i.i520.i.i.i.i
  %add30.i.i.i522.i.i.i.i = fadd double %mul31.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add31.i.i.i523.i.i.i.i = fadd double %mul31.i.i.i.i, %add30.i.i.i522.i.i.i.i
  %add32.i.i.i524.i.i.i.i = fadd double %mul29.i.i.i521.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add33.i.i.i525.i.i.i.i = fadd double %mul31.i.i.i.i, %add32.i.i.i524.i.i.i.i
  %div34.i.i.i526.i.i.i.i = fdiv double %add31.i.i.i523.i.i.i.i, %add33.i.i.i525.i.i.i.i
  %mul35.i.i.i527.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %div34.i.i.i526.i.i.i.i
  %sub36.i.i.i528.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i526.i.i.i.i
  %291 = tail call double @llvm.fabs.f64(double %sub36.i.i.i528.i.i.i.i) #3
  %cmp38.i.i.i529.i.i.i.i = fcmp ogt double %291, 0x3EC0000000000000
  br i1 %cmp38.i.i.i529.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

do.body40.i.i.i541.i.i.i.i:                       ; preds = %do.body40.i.i.i541.i.i.i.i, %if.end23.i.i.i519.i.i.i.i
  %guess.i.i.i468.i.i.i.i.2 = phi double [ %mul24.i.i.i517.i.i.i.i, %if.end23.i.i.i519.i.i.i.i ], [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ]
  %mul41.i.i.i531.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, %guess.i.i.i468.i.i.i.i.2
  %div42.i.i.i532.i.i.i.i = fdiv double %mul31.i.i.i.i, %guess.i.i.i468.i.i.i.i.2
  %sub43.i.i.i533.i.i.i.i = fsub double %mul41.i.i.i531.i.i.i.i, %div42.i.i.i532.i.i.i.i
  %mul44.i.i.i534.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i535.i.i.i.i = fdiv double %mul31.i.i.i.i, %mul41.i.i.i531.i.i.i.i
  %add46.i.i.i536.i.i.i.i = fadd double %mul44.i.i.i534.i.i.i.i, %div45.i.i.i535.i.i.i.i
  %div47.i.i.i537.i.i.i.i = fdiv double %sub43.i.i.i533.i.i.i.i, %add46.i.i.i536.i.i.i.i
  %sub48.i.i.i538.i.i.i.i = fsub double %guess.i.i.i468.i.i.i.i.2, %div47.i.i.i537.i.i.i.i
  %mul50.i.i.i539.i.i.i.i = fmul double %sub48.i.i.i538.i.i.i.i, 0x3EC0000000000000
  %292 = tail call double @llvm.fabs.f64(double %div47.i.i.i537.i.i.i.i) #3
  %cmp52.i.i.i540.i.i.i.i = fcmp olt double %mul50.i.i.i539.i.i.i.i, %292
  br i1 %cmp52.i.i.i540.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i: ; preds = %do.body40.i.i.i541.i.i.i.i, %do.body.i.i.i530.i.i.i.i, %if.end.i.i.i473.i.i.i.i, %if.then24.i.i.i.i
  %retval.0.i.i.i544.i.i.i.i = phi double [ %mul31.i.i.i.i, %if.then24.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i473.i.i.i.i ], [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ], [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ]
  %mul33.i.i.i.i = fmul double %add48.i.i.i.i.i.i, %retval.0.i.i.i544.i.i.i.i
  %div34.i.i.i.i = fdiv double %add48.i.i585.i.i.i.i, %mul33.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else35.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %cmp37.i.i.i.i = icmp sgt i32 %22, -17
  br i1 %cmp37.i.i.i.i, label %if.then38.i.i.i.i, label %if.else49.i.i.i.i

if.then38.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %293 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 8) #3
  %294 = tail call double @llvm.amdgcn.frexp.mant.f64(double %293) #3
  %295 = fcmp olt double %294, 0x3FE5555555555555
  %296 = zext i1 %295 to i32
  %297 = tail call double @llvm.amdgcn.ldexp.f64(double %294, i32 %296) #3
  %298 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %293) #3
  %299 = sub nsw i32 %298, %296
  %300 = fadd double %297, -1.000000e+00
  %301 = fadd double %297, 1.000000e+00
  %302 = fsub double %301, %297
  %303 = fsub double %301, %302
  %304 = fsub double %297, %303
  %305 = fsub double 1.000000e+00, %302
  %306 = fadd double %305, %304
  %307 = tail call double @llvm.amdgcn.rcp.f64(double %301) #3
  %308 = fneg double %301
  %309 = tail call double @llvm.fma.f64(double %308, double %307, double 1.000000e+00) #3
  %310 = tail call double @llvm.fma.f64(double %309, double %307, double %307) #3
  %311 = tail call double @llvm.fma.f64(double %308, double %310, double 1.000000e+00) #3
  %312 = tail call double @llvm.fma.f64(double %311, double %310, double %310) #3
  %313 = fmul double %300, %312
  %314 = fmul double %301, %313
  %315 = fneg double %314
  %316 = tail call double @llvm.fma.f64(double %313, double %301, double %315) #3
  %317 = tail call double @llvm.fma.f64(double %313, double %306, double %316) #3
  %318 = fadd double %314, %317
  %319 = fsub double %318, %314
  %320 = fsub double %317, %319
  %321 = fsub double %300, %318
  %322 = fsub double %300, %321
  %323 = fsub double %322, %318
  %324 = fsub double %323, %320
  %325 = fadd double %321, %324
  %326 = fmul double %312, %325
  %327 = fadd double %313, %326
  %328 = fsub double %327, %313
  %329 = fsub double %326, %328
  %330 = fmul double %327, %327
  %331 = fneg double %330
  %332 = tail call double @llvm.fma.f64(double %327, double %327, double %331) #3
  %333 = fmul double %329, 2.000000e+00
  %334 = tail call double @llvm.fma.f64(double %327, double %333, double %332) #3
  %335 = tail call double @llvm.fma.f64(double %329, double %329, double %334) #3
  %336 = fadd double %330, %335
  %337 = fsub double %336, %330
  %338 = fsub double %335, %337
  %339 = tail call double @llvm.fma.f64(double %336, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %340 = tail call double @llvm.fma.f64(double %336, double %339, double 0x3FC7474DD7F4DF2E) #3
  %341 = tail call double @llvm.fma.f64(double %336, double %340, double 0x3FCC71C016291751) #3
  %342 = tail call double @llvm.fma.f64(double %336, double %341, double 0x3FD249249B27ACF1) #3
  %343 = tail call double @llvm.fma.f64(double %336, double %342, double 0x3FD99999998EF7B6) #3
  %344 = tail call double @llvm.fma.f64(double %336, double %343, double 0x3FE5555555555780) #3
  %345 = tail call double @llvm.amdgcn.ldexp.f64(double %327, i32 1) #3
  %346 = tail call double @llvm.amdgcn.ldexp.f64(double %329, i32 1) #3
  %347 = fmul double %327, %336
  %348 = fneg double %347
  %349 = tail call double @llvm.fma.f64(double %327, double %336, double %348) #3
  %350 = fmul double %329, %336
  %351 = tail call double @llvm.fma.f64(double %327, double %338, double %350) #3
  %352 = fadd double %349, %351
  %353 = fadd double %347, %352
  %354 = fsub double %353, %347
  %355 = fsub double %352, %354
  %356 = fmul double %353, %344
  %357 = fneg double %356
  %358 = tail call double @llvm.fma.f64(double %353, double %344, double %357) #3
  %359 = tail call double @llvm.fma.f64(double %355, double %344, double %358) #3
  %360 = fadd double %356, %359
  %361 = fsub double %360, %356
  %362 = fsub double %359, %361
  %363 = fadd double %345, %360
  %364 = fsub double %363, %345
  %365 = fsub double %363, %364
  %366 = fsub double %345, %365
  %367 = fsub double %360, %364
  %368 = fadd double %367, %366
  %369 = fadd double %346, %362
  %370 = fsub double %369, %346
  %371 = fsub double %369, %370
  %372 = fsub double %346, %371
  %373 = fsub double %362, %370
  %374 = fadd double %373, %372
  %375 = fadd double %369, %368
  %376 = fadd double %363, %375
  %377 = fsub double %376, %363
  %378 = fsub double %375, %377
  %379 = fadd double %374, %378
  %380 = fadd double %376, %379
  %381 = fsub double %380, %376
  %382 = fsub double %379, %381
  %383 = sitofp i32 %299 to double
  %384 = fmul double %380, 0x3FF71547652B82FE
  %385 = fneg double %384
  %386 = fmul double %380, 0x3C7777D0FFDA0D24
  %387 = insertelement <2 x double> undef, double %380, i32 0
  %388 = insertelement <2 x double> %387, double %382, i32 1
  %389 = insertelement <2 x double> undef, double %385, i32 0
  %390 = insertelement <2 x double> %389, double %386, i32 1
  %391 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %388, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %390) #3
  %392 = extractelement <2 x double> %391, i32 0
  %393 = extractelement <2 x double> %391, i32 1
  %394 = fadd double %392, %393
  %395 = fadd double %384, %394
  %396 = fsub double %395, %384
  %397 = fsub double %394, %396
  %398 = fadd double %395, %383
  %399 = fsub double %398, %383
  %400 = fsub double %399, %398
  %401 = fadd double %400, %383
  %402 = fsub double %395, %399
  %403 = fadd double %402, %401
  %404 = fadd double %397, %403
  %405 = fadd double %398, %404
  %406 = tail call double @llvm.fabs.f64(double %293) #4
  %407 = fcmp oeq double %406, 0x7FF0000000000000
  %408 = select i1 %407, double %293, double %405
  %409 = fcmp olt double %293, 0.000000e+00
  %410 = select i1 %409, double 0x7FF8000000000000, double %408
  %411 = fcmp oeq double %293, 0.000000e+00
  %412 = select i1 %411, double 0xFFF0000000000000, double %410
  %mul.i.i450.i.i.i.i = fmul double %412, %412
  %mul1.i.i451.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3D1C49F35743D651
  %add.i.i452.i.i.i.i = fadd double %mul1.i.i451.i.i.i.i, 0x3EC5BDF8ABE0C4D2
  %mul5.i.i453.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E74DE722017F09B
  %add7.i.i454.i.i.i.i = fadd double %mul5.i.i453.i.i.i.i, 0x3F08B20867234AE0
  %mul10.i.i455.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i452.i.i.i.i
  %mul12.i.i456.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i454.i.i.i.i
  %add15.i.i457.i.i.i.i = fadd double %mul10.i.i455.i.i.i.i, 0x3F43291C59111954
  %add18.i.i458.i.i.i.i = fadd double %mul12.i.i456.i.i.i.i, 0x3F7555F81DC90AE6
  %mul20.i.i459.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i457.i.i.i.i
  %mul22.i.i460.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i458.i.i.i.i
  %add25.i.i461.i.i.i.i = fadd double %mul20.i.i459.i.i.i.i, 0x3FA118409603E368
  %add28.i.i462.i.i.i.i = fadd double %mul22.i.i460.i.i.i.i, 0x3FC2F812CF93403D
  %mul30.i.i463.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i461.i.i.i.i
  %mul32.i.i.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add28.i.i462.i.i.i.i
  %add35.i.i.i.i.i.i = fadd double %mul30.i.i463.i.i.i.i, 0x3FDA4ECF31EE23E1
  %add38.i.i464.i.i.i.i = fadd double %mul32.i.i.i.i.i.i, 0x3FE15637BD9C1C6C
  %413 = fmul double %412, %add35.i.i.i.i.i.i
  %add43.i.i.i.i.i.i = fsub double %add38.i.i464.i.i.i.i, %413
  %mul1.i.i434.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E834146FFF39045
  %add.i.i435.i.i.i.i = fadd double %mul1.i.i434.i.i.i.i, 0x3F16C942D4A0C545
  %mul5.i.i436.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3ED40F287F6755C5
  %add7.i.i437.i.i.i.i = fadd double %mul5.i.i436.i.i.i.i, 0x3F51AD434F5D94BA
  %mul10.i.i438.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i435.i.i.i.i
  %mul12.i.i439.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i437.i.i.i.i
  %add15.i.i440.i.i.i.i = fadd double %mul10.i.i438.i.i.i.i, 0x3F83AFF5A756295F
  %add18.i.i441.i.i.i.i = fadd double %mul12.i.i439.i.i.i.i, 0x3FAF8A313C5B71D0
  %mul20.i.i442.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i440.i.i.i.i
  %mul22.i.i443.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i441.i.i.i.i
  %add25.i.i444.i.i.i.i = fadd double %mul20.i.i442.i.i.i.i, 0x3FD1813788B6276A
  %add28.i.i445.i.i.i.i = fadd double %mul22.i.i443.i.i.i.i, 0x3FE84455F48DB67F
  %mul30.i.i446.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i444.i.i.i.i
  %add33.i.i447.i.i.i.i = fadd double %mul30.i.i446.i.i.i.i, 1.000000e+00
  %414 = fmul double %412, %add28.i.i445.i.i.i.i
  %add38.i.i449.i.i.i.i = fsub double %add33.i.i447.i.i.i.i, %414
  %mul45.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i356.i.i.i.i = fcmp ogt double %mul45.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i357.i.i.i.i = fcmp oeq double %mul45.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i358.i.i.i.i = or i1 %cmp.i.i.i.i356.i.i.i.i, %cmp.i.i.i357.i.i.i.i
  br i1 %or.cond.i.i.i358.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end.i.i.i360.i.i.i.i

if.end.i.i.i360.i.i.i.i:                          ; preds = %if.then38.i.i.i.i
  %cmp.i.i.i.i.i359.i.i.i.i = fcmp uno double %mul45.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i359.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end7.i.i.i386.i.i.i.i

if.end7.i.i.i386.i.i.i.i:                         ; preds = %if.end.i.i.i360.i.i.i.i
  %415 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul45.i.i.i.i) #3
  %416 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul45.i.i.i.i) #3
  %417 = tail call i1 @llvm.amdgcn.class.f64(double %mul45.i.i.i.i, i32 519) #3
  %418 = select i1 %417, i32 0, i32 %415
  %419 = select i1 %417, double %mul45.i.i.i.i, double %416
  %mul.i.i.i.i.i372.i.i.i.i = fmul double %419, %419
  %mul1.i.i.i.i.i373.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i374.i.i.i.i = fadd double %mul1.i.i.i.i.i373.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i375.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FE479D17050CA47
  %420 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i375.i.i.i.i
  %mul10.i.i.i.i.i377.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %add.i.i.i.i.i374.i.i.i.i
  %mul12.i.i.i.i.i378.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %420
  %add15.i.i.i.i.i379.i.i.i.i = fadd double %mul10.i.i.i.i.i377.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i380.i.i.i.i = fadd double %mul12.i.i.i.i.i378.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i381.i.i.i.i = fmul double %419, %add15.i.i.i.i.i379.i.i.i.i
  %add23.i.i.i.i.i382.i.i.i.i = fadd double %add18.i.i.i.i.i380.i.i.i.i, %mul20.i.i.i.i.i381.i.i.i.i
  %.frozen210 = freeze i32 %418
  %div.i.i.i383.i.i.i.i = sdiv i32 %.frozen210, 3
  %421 = sub nsw i32 0, %div.i.i.i383.i.i.i.i
  %422 = call i32 @llvm.abs.i32(i32 %div.i.i.i383.i.i.i.i, i1 true)
  %cmp11.i.i.i385.i.i.i.i = icmp ult i32 %422, 64
  br i1 %cmp11.i.i.i385.i.i.i.i, label %if.then12.i.i.i388.i.i.i.i, label %if.else21.i.i.i400.i.i.i.i

if.then12.i.i.i388.i.i.i.i:                       ; preds = %if.end7.i.i.i386.i.i.i.i
  %cmp13.i.i.i387.i.i.i.i = icmp sgt i32 %418, 2
  br i1 %cmp13.i.i.i387.i.i.i.i, label %if.then14.i.i.i393.i.i.i.i, label %if.else.i.i.i399.i.i.i.i

if.then14.i.i.i393.i.i.i.i:                       ; preds = %if.then12.i.i.i388.i.i.i.i
  %sh_prom.i.i.i389.i.i.i.i = zext i32 %div.i.i.i383.i.i.i.i to i64
  %shl.i.i.i390.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i389.i.i.i.i
  %conv.i.i.i391.i.i.i.i = uitofp i64 %shl.i.i.i390.i.i.i.i to double
  %mul.i.i.i392.i.i.i.i = fmul double %add23.i.i.i.i.i382.i.i.i.i, %conv.i.i.i391.i.i.i.i
  br label %if.end23.i.i.i406.i.i.i.i

if.else.i.i.i399.i.i.i.i:                         ; preds = %if.then12.i.i.i388.i.i.i.i
  %sh_prom16.i.i.i395.i.i.i.i = zext i32 %421 to i64
  %shl17.i.i.i396.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i395.i.i.i.i
  %conv18.i.i.i397.i.i.i.i = uitofp i64 %shl17.i.i.i396.i.i.i.i to double
  %div19.i.i.i398.i.i.i.i = fdiv double %add23.i.i.i.i.i382.i.i.i.i, %conv18.i.i.i397.i.i.i.i
  br label %if.end23.i.i.i406.i.i.i.i

if.else21.i.i.i400.i.i.i.i:                       ; preds = %if.end7.i.i.i386.i.i.i.i
  %423 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i382.i.i.i.i, i32 %div.i.i.i383.i.i.i.i) #3
  br label %if.end23.i.i.i406.i.i.i.i

if.end23.i.i.i406.i.i.i.i:                        ; preds = %if.else21.i.i.i400.i.i.i.i, %if.else.i.i.i399.i.i.i.i, %if.then14.i.i.i393.i.i.i.i
  %guess.i.i.i355.i.i.i.i.0 = phi double [ %mul.i.i.i392.i.i.i.i, %if.then14.i.i.i393.i.i.i.i ], [ %div19.i.i.i398.i.i.i.i, %if.else.i.i.i399.i.i.i.i ], [ %423, %if.else21.i.i.i400.i.i.i.i ]
  %.neg4 = mul nsw i32 %div.i.i.i383.i.i.i.i, -3
  %rem.i.i.i401.i.i.i.i.decomposed = add i32 %.frozen210, 2
  %add.i.i.i402.i.i.i.i = add i32 %rem.i.i.i401.i.i.i.i.decomposed, %.neg4
  %424 = zext i32 %add.i.i.i402.i.i.i.i to i64
  %arrayidx1.i.i.i403.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %424
  %425 = load double, double addrspace(4)* %arrayidx1.i.i.i403.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i404.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.0, %425
  %cmp26.i.i.i405.i.i.i.i = icmp slt i32 %418, 1021
  br i1 %cmp26.i.i.i405.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i

do.body.i.i.i417.i.i.i.i:                         ; preds = %do.body.i.i.i417.i.i.i.i, %if.end23.i.i.i406.i.i.i.i
  %guess.i.i.i355.i.i.i.i.1 = phi double [ %mul24.i.i.i404.i.i.i.i, %if.end23.i.i.i406.i.i.i.i ], [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ]
  %mul28.i.i.i407.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %guess.i.i.i355.i.i.i.i.1
  %mul29.i.i.i408.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %mul28.i.i.i407.i.i.i.i
  %add30.i.i.i409.i.i.i.i = fadd double %mul45.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add31.i.i.i410.i.i.i.i = fadd double %mul45.i.i.i.i, %add30.i.i.i409.i.i.i.i
  %add32.i.i.i411.i.i.i.i = fadd double %mul29.i.i.i408.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add33.i.i.i412.i.i.i.i = fadd double %mul45.i.i.i.i, %add32.i.i.i411.i.i.i.i
  %div34.i.i.i413.i.i.i.i = fdiv double %add31.i.i.i410.i.i.i.i, %add33.i.i.i412.i.i.i.i
  %mul35.i.i.i414.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %div34.i.i.i413.i.i.i.i
  %sub36.i.i.i415.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i413.i.i.i.i
  %426 = tail call double @llvm.fabs.f64(double %sub36.i.i.i415.i.i.i.i) #3
  %cmp38.i.i.i416.i.i.i.i = fcmp ogt double %426, 0x3EC0000000000000
  br i1 %cmp38.i.i.i416.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

do.body40.i.i.i428.i.i.i.i:                       ; preds = %do.body40.i.i.i428.i.i.i.i, %if.end23.i.i.i406.i.i.i.i
  %guess.i.i.i355.i.i.i.i.2 = phi double [ %mul24.i.i.i404.i.i.i.i, %if.end23.i.i.i406.i.i.i.i ], [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ]
  %mul41.i.i.i418.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, %guess.i.i.i355.i.i.i.i.2
  %div42.i.i.i419.i.i.i.i = fdiv double %mul45.i.i.i.i, %guess.i.i.i355.i.i.i.i.2
  %sub43.i.i.i420.i.i.i.i = fsub double %mul41.i.i.i418.i.i.i.i, %div42.i.i.i419.i.i.i.i
  %mul44.i.i.i421.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i422.i.i.i.i = fdiv double %mul45.i.i.i.i, %mul41.i.i.i418.i.i.i.i
  %add46.i.i.i423.i.i.i.i = fadd double %mul44.i.i.i421.i.i.i.i, %div45.i.i.i422.i.i.i.i
  %div47.i.i.i424.i.i.i.i = fdiv double %sub43.i.i.i420.i.i.i.i, %add46.i.i.i423.i.i.i.i
  %sub48.i.i.i425.i.i.i.i = fsub double %guess.i.i.i355.i.i.i.i.2, %div47.i.i.i424.i.i.i.i
  %mul50.i.i.i426.i.i.i.i = fmul double %sub48.i.i.i425.i.i.i.i, 0x3EC0000000000000
  %427 = tail call double @llvm.fabs.f64(double %div47.i.i.i424.i.i.i.i) #3
  %cmp52.i.i.i427.i.i.i.i = fcmp olt double %mul50.i.i.i426.i.i.i.i, %427
  br i1 %cmp52.i.i.i427.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i: ; preds = %do.body40.i.i.i428.i.i.i.i, %do.body.i.i.i417.i.i.i.i, %if.end.i.i.i360.i.i.i.i, %if.then38.i.i.i.i
  %retval.0.i.i.i431.i.i.i.i = phi double [ %mul45.i.i.i.i, %if.then38.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i360.i.i.i.i ], [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ], [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ]
  %mul47.i.i.i.i = fmul double %add38.i.i449.i.i.i.i, %retval.0.i.i.i431.i.i.i.i
  %div48.i.i.i.i = fdiv double %add43.i.i.i.i.i.i, %mul47.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else49.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %cmp51.i.i.i.i = icmp sgt i32 %22, -33
  br i1 %cmp51.i.i.i.i, label %if.then52.i.i.i.i, label %if.else63.i.i.i.i

if.then52.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %428 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 16) #3
  %429 = tail call double @llvm.amdgcn.frexp.mant.f64(double %428) #3
  %430 = fcmp olt double %429, 0x3FE5555555555555
  %431 = zext i1 %430 to i32
  %432 = tail call double @llvm.amdgcn.ldexp.f64(double %429, i32 %431) #3
  %433 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %428) #3
  %434 = sub nsw i32 %433, %431
  %435 = fadd double %432, -1.000000e+00
  %436 = fadd double %432, 1.000000e+00
  %437 = fsub double %436, %432
  %438 = fsub double %436, %437
  %439 = fsub double %432, %438
  %440 = fsub double 1.000000e+00, %437
  %441 = fadd double %440, %439
  %442 = tail call double @llvm.amdgcn.rcp.f64(double %436) #3
  %443 = fneg double %436
  %444 = tail call double @llvm.fma.f64(double %443, double %442, double 1.000000e+00) #3
  %445 = tail call double @llvm.fma.f64(double %444, double %442, double %442) #3
  %446 = tail call double @llvm.fma.f64(double %443, double %445, double 1.000000e+00) #3
  %447 = tail call double @llvm.fma.f64(double %446, double %445, double %445) #3
  %448 = fmul double %435, %447
  %449 = fmul double %436, %448
  %450 = fneg double %449
  %451 = tail call double @llvm.fma.f64(double %448, double %436, double %450) #3
  %452 = tail call double @llvm.fma.f64(double %448, double %441, double %451) #3
  %453 = fadd double %449, %452
  %454 = fsub double %453, %449
  %455 = fsub double %452, %454
  %456 = fsub double %435, %453
  %457 = fsub double %435, %456
  %458 = fsub double %457, %453
  %459 = fsub double %458, %455
  %460 = fadd double %456, %459
  %461 = fmul double %447, %460
  %462 = fadd double %448, %461
  %463 = fsub double %462, %448
  %464 = fsub double %461, %463
  %465 = fmul double %462, %462
  %466 = fneg double %465
  %467 = tail call double @llvm.fma.f64(double %462, double %462, double %466) #3
  %468 = fmul double %464, 2.000000e+00
  %469 = tail call double @llvm.fma.f64(double %462, double %468, double %467) #3
  %470 = tail call double @llvm.fma.f64(double %464, double %464, double %469) #3
  %471 = fadd double %465, %470
  %472 = fsub double %471, %465
  %473 = fsub double %470, %472
  %474 = tail call double @llvm.fma.f64(double %471, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %475 = tail call double @llvm.fma.f64(double %471, double %474, double 0x3FC7474DD7F4DF2E) #3
  %476 = tail call double @llvm.fma.f64(double %471, double %475, double 0x3FCC71C016291751) #3
  %477 = tail call double @llvm.fma.f64(double %471, double %476, double 0x3FD249249B27ACF1) #3
  %478 = tail call double @llvm.fma.f64(double %471, double %477, double 0x3FD99999998EF7B6) #3
  %479 = tail call double @llvm.fma.f64(double %471, double %478, double 0x3FE5555555555780) #3
  %480 = tail call double @llvm.amdgcn.ldexp.f64(double %462, i32 1) #3
  %481 = tail call double @llvm.amdgcn.ldexp.f64(double %464, i32 1) #3
  %482 = fmul double %462, %471
  %483 = fneg double %482
  %484 = tail call double @llvm.fma.f64(double %462, double %471, double %483) #3
  %485 = fmul double %464, %471
  %486 = tail call double @llvm.fma.f64(double %462, double %473, double %485) #3
  %487 = fadd double %484, %486
  %488 = fadd double %482, %487
  %489 = fsub double %488, %482
  %490 = fsub double %487, %489
  %491 = fmul double %488, %479
  %492 = fneg double %491
  %493 = tail call double @llvm.fma.f64(double %488, double %479, double %492) #3
  %494 = tail call double @llvm.fma.f64(double %490, double %479, double %493) #3
  %495 = fadd double %491, %494
  %496 = fsub double %495, %491
  %497 = fsub double %494, %496
  %498 = fadd double %480, %495
  %499 = fsub double %498, %480
  %500 = fsub double %498, %499
  %501 = fsub double %480, %500
  %502 = fsub double %495, %499
  %503 = fadd double %502, %501
  %504 = fadd double %481, %497
  %505 = fsub double %504, %481
  %506 = fsub double %504, %505
  %507 = fsub double %481, %506
  %508 = fsub double %497, %505
  %509 = fadd double %508, %507
  %510 = fadd double %504, %503
  %511 = fadd double %498, %510
  %512 = fsub double %511, %498
  %513 = fsub double %510, %512
  %514 = fadd double %509, %513
  %515 = fadd double %511, %514
  %516 = fsub double %515, %511
  %517 = fsub double %514, %516
  %518 = sitofp i32 %434 to double
  %519 = fmul double %515, 0x3FF71547652B82FE
  %520 = fneg double %519
  %521 = fmul double %515, 0x3C7777D0FFDA0D24
  %522 = insertelement <2 x double> undef, double %515, i32 0
  %523 = insertelement <2 x double> %522, double %517, i32 1
  %524 = insertelement <2 x double> undef, double %520, i32 0
  %525 = insertelement <2 x double> %524, double %521, i32 1
  %526 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %523, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %525) #3
  %527 = extractelement <2 x double> %526, i32 0
  %528 = extractelement <2 x double> %526, i32 1
  %529 = fadd double %527, %528
  %530 = fadd double %519, %529
  %531 = fsub double %530, %519
  %532 = fsub double %529, %531
  %533 = fadd double %530, %518
  %534 = fsub double %533, %518
  %535 = fsub double %534, %533
  %536 = fadd double %535, %518
  %537 = fsub double %530, %534
  %538 = fadd double %537, %536
  %539 = fadd double %532, %538
  %540 = fadd double %533, %539
  %541 = tail call double @llvm.fabs.f64(double %428) #4
  %542 = fcmp oeq double %541, 0x7FF0000000000000
  %543 = select i1 %542, double %428, double %540
  %544 = fcmp olt double %428, 0.000000e+00
  %545 = select i1 %544, double 0x7FF8000000000000, double %543
  %546 = fcmp oeq double %428, 0.000000e+00
  %547 = select i1 %546, double 0xFFF0000000000000, double %545
  %mul.i.i335.i.i.i.i = fmul double %547, %547
  %mul1.i.i336.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EBF7344DBF5E403
  %add.i.i337.i.i.i.i = fadd double %mul1.i.i336.i.i.i.i, 0x3F2CFF1E2D54E4E7
  %mul5.i.i338.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EEF8CF23CAED047
  %add7.i.i339.i.i.i.i = fadd double %mul5.i.i338.i.i.i.i, 0x3F5CF8F0FF9B6F59
  %mul10.i.i340.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i337.i.i.i.i
  %mul12.i.i341.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i339.i.i.i.i
  %add15.i.i342.i.i.i.i = fadd double %mul10.i.i340.i.i.i.i, 0x3F8857AD74D33625
  %add18.i.i343.i.i.i.i = fadd double %mul12.i.i341.i.i.i.i, 0x3FAE52179C3AEDE6
  %mul20.i.i344.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i342.i.i.i.i
  %mul22.i.i345.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i343.i.i.i.i
  %add25.i.i346.i.i.i.i = fadd double %mul20.i.i344.i.i.i.i, 0x3FCB21A22303D8FC
  %add28.i.i347.i.i.i.i = fadd double %mul22.i.i345.i.i.i.i, 0x3FDF29CE00A8804B
  %mul30.i.i348.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i346.i.i.i.i
  %add33.i.i349.i.i.i.i = fadd double %mul30.i.i348.i.i.i.i, 0x3FE15775564555E5
  %548 = fmul double %547, %add28.i.i347.i.i.i.i
  %add38.i.i351.i.i.i.i = fsub double %add33.i.i349.i.i.i.i, %548
  %mul1.i.i321.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3ECD04621671DBCE
  %add.i.i322.i.i.i.i = fadd double %mul1.i.i321.i.i.i.i, 0x3F3AC0D433DC2A4E
  %mul5.i.i323.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EFD1C12EAA62BE9
  %add7.i.i324.i.i.i.i = fadd double %mul5.i.i323.i.i.i.i, 0x3F6ABB215A001E96
  %mul10.i.i325.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i322.i.i.i.i
  %mul12.i.i326.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i324.i.i.i.i
  %add15.i.i327.i.i.i.i = fadd double %mul10.i.i325.i.i.i.i, 0x3F967590758A1B1A
  %add18.i.i328.i.i.i.i = fadd double %mul12.i.i326.i.i.i.i, 0x3FBBF9941AE7DFDE
  %mul20.i.i329.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i327.i.i.i.i
  %mul22.i.i330.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i328.i.i.i.i
  %add25.i.i331.i.i.i.i = fadd double %mul20.i.i329.i.i.i.i, 0x3FD90848F242167F
  %add28.i.i332.i.i.i.i = fadd double %mul22.i.i330.i.i.i.i, 0x3FECC09A37BCEE76
  %mul30.i.i333.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i331.i.i.i.i
  %add33.i.i334.i.i.i.i = fadd double %mul30.i.i333.i.i.i.i, 1.000000e+00
  %549 = fmul double %547, %add28.i.i332.i.i.i.i
  %add38.i.i.i.i.i.i = fsub double %add33.i.i334.i.i.i.i, %549
  %mul59.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i243.i.i.i.i = fcmp ogt double %mul59.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i244.i.i.i.i = fcmp oeq double %mul59.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i245.i.i.i.i = or i1 %cmp.i.i.i.i243.i.i.i.i, %cmp.i.i.i244.i.i.i.i
  br i1 %or.cond.i.i.i245.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end.i.i.i247.i.i.i.i

if.end.i.i.i247.i.i.i.i:                          ; preds = %if.then52.i.i.i.i
  %cmp.i.i.i.i.i246.i.i.i.i = fcmp uno double %mul59.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i246.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end7.i.i.i273.i.i.i.i

if.end7.i.i.i273.i.i.i.i:                         ; preds = %if.end.i.i.i247.i.i.i.i
  %550 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul59.i.i.i.i) #3
  %551 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul59.i.i.i.i) #3
  %552 = tail call i1 @llvm.amdgcn.class.f64(double %mul59.i.i.i.i, i32 519) #3
  %553 = select i1 %552, i32 0, i32 %550
  %554 = select i1 %552, double %mul59.i.i.i.i, double %551
  %mul.i.i.i.i.i259.i.i.i.i = fmul double %554, %554
  %mul1.i.i.i.i.i260.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i261.i.i.i.i = fadd double %mul1.i.i.i.i.i260.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i262.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FE479D17050CA47
  %555 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i262.i.i.i.i
  %mul10.i.i.i.i.i264.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %add.i.i.i.i.i261.i.i.i.i
  %mul12.i.i.i.i.i265.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %555
  %add15.i.i.i.i.i266.i.i.i.i = fadd double %mul10.i.i.i.i.i264.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i267.i.i.i.i = fadd double %mul12.i.i.i.i.i265.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i268.i.i.i.i = fmul double %554, %add15.i.i.i.i.i266.i.i.i.i
  %add23.i.i.i.i.i269.i.i.i.i = fadd double %add18.i.i.i.i.i267.i.i.i.i, %mul20.i.i.i.i.i268.i.i.i.i
  %.frozen211 = freeze i32 %553
  %div.i.i.i270.i.i.i.i = sdiv i32 %.frozen211, 3
  %556 = sub nsw i32 0, %div.i.i.i270.i.i.i.i
  %557 = call i32 @llvm.abs.i32(i32 %div.i.i.i270.i.i.i.i, i1 true)
  %cmp11.i.i.i272.i.i.i.i = icmp ult i32 %557, 64
  br i1 %cmp11.i.i.i272.i.i.i.i, label %if.then12.i.i.i275.i.i.i.i, label %if.else21.i.i.i287.i.i.i.i

if.then12.i.i.i275.i.i.i.i:                       ; preds = %if.end7.i.i.i273.i.i.i.i
  %cmp13.i.i.i274.i.i.i.i = icmp sgt i32 %553, 2
  br i1 %cmp13.i.i.i274.i.i.i.i, label %if.then14.i.i.i280.i.i.i.i, label %if.else.i.i.i286.i.i.i.i

if.then14.i.i.i280.i.i.i.i:                       ; preds = %if.then12.i.i.i275.i.i.i.i
  %sh_prom.i.i.i276.i.i.i.i = zext i32 %div.i.i.i270.i.i.i.i to i64
  %shl.i.i.i277.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i276.i.i.i.i
  %conv.i.i.i278.i.i.i.i = uitofp i64 %shl.i.i.i277.i.i.i.i to double
  %mul.i.i.i279.i.i.i.i = fmul double %add23.i.i.i.i.i269.i.i.i.i, %conv.i.i.i278.i.i.i.i
  br label %if.end23.i.i.i293.i.i.i.i

if.else.i.i.i286.i.i.i.i:                         ; preds = %if.then12.i.i.i275.i.i.i.i
  %sh_prom16.i.i.i282.i.i.i.i = zext i32 %556 to i64
  %shl17.i.i.i283.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i282.i.i.i.i
  %conv18.i.i.i284.i.i.i.i = uitofp i64 %shl17.i.i.i283.i.i.i.i to double
  %div19.i.i.i285.i.i.i.i = fdiv double %add23.i.i.i.i.i269.i.i.i.i, %conv18.i.i.i284.i.i.i.i
  br label %if.end23.i.i.i293.i.i.i.i

if.else21.i.i.i287.i.i.i.i:                       ; preds = %if.end7.i.i.i273.i.i.i.i
  %558 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i269.i.i.i.i, i32 %div.i.i.i270.i.i.i.i) #3
  br label %if.end23.i.i.i293.i.i.i.i

if.end23.i.i.i293.i.i.i.i:                        ; preds = %if.else21.i.i.i287.i.i.i.i, %if.else.i.i.i286.i.i.i.i, %if.then14.i.i.i280.i.i.i.i
  %guess.i.i.i242.i.i.i.i.0 = phi double [ %mul.i.i.i279.i.i.i.i, %if.then14.i.i.i280.i.i.i.i ], [ %div19.i.i.i285.i.i.i.i, %if.else.i.i.i286.i.i.i.i ], [ %558, %if.else21.i.i.i287.i.i.i.i ]
  %.neg3 = mul nsw i32 %div.i.i.i270.i.i.i.i, -3
  %rem.i.i.i288.i.i.i.i.decomposed = add i32 %.frozen211, 2
  %add.i.i.i289.i.i.i.i = add i32 %rem.i.i.i288.i.i.i.i.decomposed, %.neg3
  %559 = zext i32 %add.i.i.i289.i.i.i.i to i64
  %arrayidx1.i.i.i290.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %559
  %560 = load double, double addrspace(4)* %arrayidx1.i.i.i290.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i291.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.0, %560
  %cmp26.i.i.i292.i.i.i.i = icmp slt i32 %553, 1021
  br i1 %cmp26.i.i.i292.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i

do.body.i.i.i304.i.i.i.i:                         ; preds = %do.body.i.i.i304.i.i.i.i, %if.end23.i.i.i293.i.i.i.i
  %guess.i.i.i242.i.i.i.i.1 = phi double [ %mul24.i.i.i291.i.i.i.i, %if.end23.i.i.i293.i.i.i.i ], [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ]
  %mul28.i.i.i294.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %guess.i.i.i242.i.i.i.i.1
  %mul29.i.i.i295.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %mul28.i.i.i294.i.i.i.i
  %add30.i.i.i296.i.i.i.i = fadd double %mul59.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add31.i.i.i297.i.i.i.i = fadd double %mul59.i.i.i.i, %add30.i.i.i296.i.i.i.i
  %add32.i.i.i298.i.i.i.i = fadd double %mul29.i.i.i295.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add33.i.i.i299.i.i.i.i = fadd double %mul59.i.i.i.i, %add32.i.i.i298.i.i.i.i
  %div34.i.i.i300.i.i.i.i = fdiv double %add31.i.i.i297.i.i.i.i, %add33.i.i.i299.i.i.i.i
  %mul35.i.i.i301.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %div34.i.i.i300.i.i.i.i
  %sub36.i.i.i302.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i300.i.i.i.i
  %561 = tail call double @llvm.fabs.f64(double %sub36.i.i.i302.i.i.i.i) #3
  %cmp38.i.i.i303.i.i.i.i = fcmp ogt double %561, 0x3EC0000000000000
  br i1 %cmp38.i.i.i303.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

do.body40.i.i.i315.i.i.i.i:                       ; preds = %do.body40.i.i.i315.i.i.i.i, %if.end23.i.i.i293.i.i.i.i
  %guess.i.i.i242.i.i.i.i.2 = phi double [ %mul24.i.i.i291.i.i.i.i, %if.end23.i.i.i293.i.i.i.i ], [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ]
  %mul41.i.i.i305.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, %guess.i.i.i242.i.i.i.i.2
  %div42.i.i.i306.i.i.i.i = fdiv double %mul59.i.i.i.i, %guess.i.i.i242.i.i.i.i.2
  %sub43.i.i.i307.i.i.i.i = fsub double %mul41.i.i.i305.i.i.i.i, %div42.i.i.i306.i.i.i.i
  %mul44.i.i.i308.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i309.i.i.i.i = fdiv double %mul59.i.i.i.i, %mul41.i.i.i305.i.i.i.i
  %add46.i.i.i310.i.i.i.i = fadd double %mul44.i.i.i308.i.i.i.i, %div45.i.i.i309.i.i.i.i
  %div47.i.i.i311.i.i.i.i = fdiv double %sub43.i.i.i307.i.i.i.i, %add46.i.i.i310.i.i.i.i
  %sub48.i.i.i312.i.i.i.i = fsub double %guess.i.i.i242.i.i.i.i.2, %div47.i.i.i311.i.i.i.i
  %mul50.i.i.i313.i.i.i.i = fmul double %sub48.i.i.i312.i.i.i.i, 0x3EC0000000000000
  %562 = tail call double @llvm.fabs.f64(double %div47.i.i.i311.i.i.i.i) #3
  %cmp52.i.i.i314.i.i.i.i = fcmp olt double %mul50.i.i.i313.i.i.i.i, %562
  br i1 %cmp52.i.i.i314.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i: ; preds = %do.body40.i.i.i315.i.i.i.i, %do.body.i.i.i304.i.i.i.i, %if.end.i.i.i247.i.i.i.i, %if.then52.i.i.i.i
  %retval.0.i.i.i318.i.i.i.i = phi double [ %mul59.i.i.i.i, %if.then52.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i247.i.i.i.i ], [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ], [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ]
  %mul61.i.i.i.i = fmul double %add38.i.i.i.i.i.i, %retval.0.i.i.i318.i.i.i.i
  %div62.i.i.i.i = fdiv double %add38.i.i351.i.i.i.i, %mul61.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else63.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %mul64.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp1.i.i.i.i.i = fcmp oge double %mul64.i.i.i.i, 0x10000000000000
  %cmp2.i.i.i.i.i = fcmp ole double %mul64.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %563 = and i1 %cmp1.i.i.i.i.i, %cmp2.i.i.i.i.i
  br i1 %563, label %if.then66.i.i.i.i, label %if.else71.i.i.i.i

if.then66.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %mul68.i.i.i.i = fmul double %mul64.i.i.i.i, 0x401921FB54442D18
  %cmp.i.i.i.i162.i.i.i.i = fcmp ogt double %mul68.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i163.i.i.i.i = fcmp oeq double %mul68.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i164.i.i.i.i = or i1 %cmp.i.i.i.i162.i.i.i.i, %cmp.i.i.i163.i.i.i.i
  br i1 %or.cond.i.i.i164.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end.i.i.i166.i.i.i.i

if.end.i.i.i166.i.i.i.i:                          ; preds = %if.then66.i.i.i.i
  %cmp.i.i.i.i.i165.i.i.i.i = fcmp uno double %mul68.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i165.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end7.i.i.i192.i.i.i.i

if.end7.i.i.i192.i.i.i.i:                         ; preds = %if.end.i.i.i166.i.i.i.i
  %564 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul68.i.i.i.i) #3
  %565 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul68.i.i.i.i) #3
  %566 = tail call i1 @llvm.amdgcn.class.f64(double %mul68.i.i.i.i, i32 519) #3
  %567 = select i1 %566, i32 0, i32 %564
  %568 = select i1 %566, double %mul68.i.i.i.i, double %565
  %mul.i.i.i.i.i178.i.i.i.i = fmul double %568, %568
  %mul1.i.i.i.i.i179.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i180.i.i.i.i = fadd double %mul1.i.i.i.i.i179.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i181.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FE479D17050CA47
  %569 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i181.i.i.i.i
  %mul10.i.i.i.i.i183.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %add.i.i.i.i.i180.i.i.i.i
  %mul12.i.i.i.i.i184.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %569
  %add15.i.i.i.i.i185.i.i.i.i = fadd double %mul10.i.i.i.i.i183.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i186.i.i.i.i = fadd double %mul12.i.i.i.i.i184.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i187.i.i.i.i = fmul double %568, %add15.i.i.i.i.i185.i.i.i.i
  %add23.i.i.i.i.i188.i.i.i.i = fadd double %add18.i.i.i.i.i186.i.i.i.i, %mul20.i.i.i.i.i187.i.i.i.i
  %.frozen212 = freeze i32 %567
  %div.i.i.i189.i.i.i.i = sdiv i32 %.frozen212, 3
  %570 = sub nsw i32 0, %div.i.i.i189.i.i.i.i
  %571 = call i32 @llvm.abs.i32(i32 %div.i.i.i189.i.i.i.i, i1 true)
  %cmp11.i.i.i191.i.i.i.i = icmp ult i32 %571, 64
  br i1 %cmp11.i.i.i191.i.i.i.i, label %if.then12.i.i.i194.i.i.i.i, label %if.else21.i.i.i206.i.i.i.i

if.then12.i.i.i194.i.i.i.i:                       ; preds = %if.end7.i.i.i192.i.i.i.i
  %cmp13.i.i.i193.i.i.i.i = icmp sgt i32 %567, 2
  br i1 %cmp13.i.i.i193.i.i.i.i, label %if.then14.i.i.i199.i.i.i.i, label %if.else.i.i.i205.i.i.i.i

if.then14.i.i.i199.i.i.i.i:                       ; preds = %if.then12.i.i.i194.i.i.i.i
  %sh_prom.i.i.i195.i.i.i.i = zext i32 %div.i.i.i189.i.i.i.i to i64
  %shl.i.i.i196.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i195.i.i.i.i
  %conv.i.i.i197.i.i.i.i = uitofp i64 %shl.i.i.i196.i.i.i.i to double
  %mul.i.i.i198.i.i.i.i = fmul double %add23.i.i.i.i.i188.i.i.i.i, %conv.i.i.i197.i.i.i.i
  br label %if.end23.i.i.i212.i.i.i.i

if.else.i.i.i205.i.i.i.i:                         ; preds = %if.then12.i.i.i194.i.i.i.i
  %sh_prom16.i.i.i201.i.i.i.i = zext i32 %570 to i64
  %shl17.i.i.i202.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i201.i.i.i.i
  %conv18.i.i.i203.i.i.i.i = uitofp i64 %shl17.i.i.i202.i.i.i.i to double
  %div19.i.i.i204.i.i.i.i = fdiv double %add23.i.i.i.i.i188.i.i.i.i, %conv18.i.i.i203.i.i.i.i
  br label %if.end23.i.i.i212.i.i.i.i

if.else21.i.i.i206.i.i.i.i:                       ; preds = %if.end7.i.i.i192.i.i.i.i
  %572 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i188.i.i.i.i, i32 %div.i.i.i189.i.i.i.i) #3
  br label %if.end23.i.i.i212.i.i.i.i

if.end23.i.i.i212.i.i.i.i:                        ; preds = %if.else21.i.i.i206.i.i.i.i, %if.else.i.i.i205.i.i.i.i, %if.then14.i.i.i199.i.i.i.i
  %guess.i.i.i161.i.i.i.i.0 = phi double [ %mul.i.i.i198.i.i.i.i, %if.then14.i.i.i199.i.i.i.i ], [ %div19.i.i.i204.i.i.i.i, %if.else.i.i.i205.i.i.i.i ], [ %572, %if.else21.i.i.i206.i.i.i.i ]
  %.neg2 = mul nsw i32 %div.i.i.i189.i.i.i.i, -3
  %rem.i.i.i207.i.i.i.i.decomposed = add i32 %.frozen212, 2
  %add.i.i.i208.i.i.i.i = add i32 %rem.i.i.i207.i.i.i.i.decomposed, %.neg2
  %573 = zext i32 %add.i.i.i208.i.i.i.i to i64
  %arrayidx1.i.i.i209.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %573
  %574 = load double, double addrspace(4)* %arrayidx1.i.i.i209.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i210.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.0, %574
  %cmp26.i.i.i211.i.i.i.i = icmp slt i32 %567, 1021
  br i1 %cmp26.i.i.i211.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i

do.body.i.i.i223.i.i.i.i:                         ; preds = %do.body.i.i.i223.i.i.i.i, %if.end23.i.i.i212.i.i.i.i
  %guess.i.i.i161.i.i.i.i.1 = phi double [ %mul24.i.i.i210.i.i.i.i, %if.end23.i.i.i212.i.i.i.i ], [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ]
  %mul28.i.i.i213.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %guess.i.i.i161.i.i.i.i.1
  %mul29.i.i.i214.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %mul28.i.i.i213.i.i.i.i
  %add30.i.i.i215.i.i.i.i = fadd double %mul68.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add31.i.i.i216.i.i.i.i = fadd double %mul68.i.i.i.i, %add30.i.i.i215.i.i.i.i
  %add32.i.i.i217.i.i.i.i = fadd double %mul29.i.i.i214.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add33.i.i.i218.i.i.i.i = fadd double %mul68.i.i.i.i, %add32.i.i.i217.i.i.i.i
  %div34.i.i.i219.i.i.i.i = fdiv double %add31.i.i.i216.i.i.i.i, %add33.i.i.i218.i.i.i.i
  %mul35.i.i.i220.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %div34.i.i.i219.i.i.i.i
  %sub36.i.i.i221.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i219.i.i.i.i
  %575 = tail call double @llvm.fabs.f64(double %sub36.i.i.i221.i.i.i.i) #3
  %cmp38.i.i.i222.i.i.i.i = fcmp ogt double %575, 0x3EC0000000000000
  br i1 %cmp38.i.i.i222.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

do.body40.i.i.i234.i.i.i.i:                       ; preds = %do.body40.i.i.i234.i.i.i.i, %if.end23.i.i.i212.i.i.i.i
  %guess.i.i.i161.i.i.i.i.2 = phi double [ %mul24.i.i.i210.i.i.i.i, %if.end23.i.i.i212.i.i.i.i ], [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ]
  %mul41.i.i.i224.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, %guess.i.i.i161.i.i.i.i.2
  %div42.i.i.i225.i.i.i.i = fdiv double %mul68.i.i.i.i, %guess.i.i.i161.i.i.i.i.2
  %sub43.i.i.i226.i.i.i.i = fsub double %mul41.i.i.i224.i.i.i.i, %div42.i.i.i225.i.i.i.i
  %mul44.i.i.i227.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i228.i.i.i.i = fdiv double %mul68.i.i.i.i, %mul41.i.i.i224.i.i.i.i
  %add46.i.i.i229.i.i.i.i = fadd double %mul44.i.i.i227.i.i.i.i, %div45.i.i.i228.i.i.i.i
  %div47.i.i.i230.i.i.i.i = fdiv double %sub43.i.i.i226.i.i.i.i, %add46.i.i.i229.i.i.i.i
  %sub48.i.i.i231.i.i.i.i = fsub double %guess.i.i.i161.i.i.i.i.2, %div47.i.i.i230.i.i.i.i
  %mul50.i.i.i232.i.i.i.i = fmul double %sub48.i.i.i231.i.i.i.i, 0x3EC0000000000000
  %576 = tail call double @llvm.fabs.f64(double %div47.i.i.i230.i.i.i.i) #3
  %cmp52.i.i.i233.i.i.i.i = fcmp olt double %mul50.i.i.i232.i.i.i.i, %576
  br i1 %cmp52.i.i.i233.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i: ; preds = %do.body40.i.i.i234.i.i.i.i, %do.body.i.i.i223.i.i.i.i, %if.end.i.i.i166.i.i.i.i, %if.then66.i.i.i.i
  %retval.0.i.i.i237.i.i.i.i = phi double [ %mul68.i.i.i.i, %if.then66.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i166.i.i.i.i ], [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ], [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ]
  %div70.i.i.i.i = fdiv double 1.000000e+00, %retval.0.i.i.i237.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else71.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %cmp72.i.i.i.i = fcmp ogt double %sub.i.i.i, 0.000000e+00
  br i1 %cmp72.i.i.i.i, label %if.then73.i.i.i.i, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.then73.i.i.i.i:                                ; preds = %if.else71.i.i.i.i
  %cmp.i.i.i.i79.i.i.i.i = fcmp ogt double %sub.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i.i80.i.i.i.i = fcmp olt double %sub.i.i.i, 0xFFEFFFFFFFFFFFFF
  %577 = or i1 %cmp.i.i.i.i79.i.i.i.i, %cmp1.i.i.i.i80.i.i.i.i
  %or.cond.i.i.i82.i.i.i.i = or i1 %21, %577
  %brmerge170 = or i1 %16, %or.cond.i.i.i82.i.i.i.i
  %sub.i.i.i.mux = select i1 %or.cond.i.i.i82.i.i.i.i, double %sub.i.i.i, double 0x7FF8000000000000
  br i1 %brmerge170, label %if.end7.i.i.i.i.i.i.i, label %if.end4.i.i.i92.i.i.i.i

if.end4.i.i.i92.i.i.i.i:                          ; preds = %if.then73.i.i.i.i
  %cmp5.i.i.i91.i.i.i.i = fcmp olt double %sub.i.i.i, 0.000000e+00
  %fneg.i.i.i93.i.i.i.i = fneg double %sub.i.i.i
  %z.addr.i.i.i76.i.i.i.i.0 = select i1 %cmp5.i.i.i91.i.i.i.i, double %fneg.i.i.i93.i.i.i.i, double %sub.i.i.i
  %578 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %579 = tail call double @llvm.amdgcn.frexp.mant.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %580 = tail call i1 @llvm.amdgcn.class.f64(double %z.addr.i.i.i76.i.i.i.i.0, i32 519) #3
  %581 = select i1 %580, i32 0, i32 %578
  %582 = select i1 %580, double %z.addr.i.i.i76.i.i.i.i.0, double %579
  %mul.i.i.i.i.i97.i.i.i.i = fmul double %582, %582
  %mul1.i.i.i.i.i98.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i99.i.i.i.i = fadd double %mul1.i.i.i.i.i98.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i100.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FE479D17050CA47
  %583 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i100.i.i.i.i
  %mul10.i.i.i.i.i102.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %add.i.i.i.i.i99.i.i.i.i
  %mul12.i.i.i.i.i103.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %583
  %add15.i.i.i.i.i104.i.i.i.i = fadd double %mul10.i.i.i.i.i102.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i105.i.i.i.i = fadd double %mul12.i.i.i.i.i103.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i106.i.i.i.i = fmul double %582, %add15.i.i.i.i.i104.i.i.i.i
  %add23.i.i.i.i.i107.i.i.i.i = fadd double %add18.i.i.i.i.i105.i.i.i.i, %mul20.i.i.i.i.i106.i.i.i.i
  %.frozen213 = freeze i32 %581
  %div.i.i.i108.i.i.i.i = sdiv i32 %.frozen213, 3
  %584 = sub nsw i32 0, %div.i.i.i108.i.i.i.i
  %585 = call i32 @llvm.abs.i32(i32 %div.i.i.i108.i.i.i.i, i1 true)
  %cmp11.i.i.i110.i.i.i.i = icmp ult i32 %585, 64
  br i1 %cmp11.i.i.i110.i.i.i.i, label %if.then12.i.i.i113.i.i.i.i, label %if.else21.i.i.i125.i.i.i.i

if.then12.i.i.i113.i.i.i.i:                       ; preds = %if.end4.i.i.i92.i.i.i.i
  %cmp13.i.i.i112.i.i.i.i = icmp sgt i32 %581, 2
  br i1 %cmp13.i.i.i112.i.i.i.i, label %if.then14.i.i.i118.i.i.i.i, label %if.else.i.i.i124.i.i.i.i

if.then14.i.i.i118.i.i.i.i:                       ; preds = %if.then12.i.i.i113.i.i.i.i
  %sh_prom.i.i.i114.i.i.i.i = zext i32 %div.i.i.i108.i.i.i.i to i64
  %shl.i.i.i115.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i114.i.i.i.i
  %conv.i.i.i116.i.i.i.i = uitofp i64 %shl.i.i.i115.i.i.i.i to double
  %mul.i.i.i117.i.i.i.i = fmul double %add23.i.i.i.i.i107.i.i.i.i, %conv.i.i.i116.i.i.i.i
  br label %if.end23.i.i.i131.i.i.i.i

if.else.i.i.i124.i.i.i.i:                         ; preds = %if.then12.i.i.i113.i.i.i.i
  %sh_prom16.i.i.i120.i.i.i.i = zext i32 %584 to i64
  %shl17.i.i.i121.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i120.i.i.i.i
  %conv18.i.i.i122.i.i.i.i = uitofp i64 %shl17.i.i.i121.i.i.i.i to double
  %div19.i.i.i123.i.i.i.i = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %conv18.i.i.i122.i.i.i.i
  br label %if.end23.i.i.i131.i.i.i.i

if.else21.i.i.i125.i.i.i.i:                       ; preds = %if.end4.i.i.i92.i.i.i.i
  %586 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  br label %if.end23.i.i.i131.i.i.i.i

if.end23.i.i.i131.i.i.i.i:                        ; preds = %if.else21.i.i.i125.i.i.i.i, %if.else.i.i.i124.i.i.i.i, %if.then14.i.i.i118.i.i.i.i
  %guess.i.i.i78.i.i.i.i.0 = phi double [ %mul.i.i.i117.i.i.i.i, %if.then14.i.i.i118.i.i.i.i ], [ %div19.i.i.i123.i.i.i.i, %if.else.i.i.i124.i.i.i.i ], [ %586, %if.else21.i.i.i125.i.i.i.i ]
  %.neg = mul nsw i32 %div.i.i.i108.i.i.i.i, -3
  %rem.i.i.i126.i.i.i.i.decomposed = add i32 %.frozen213, 2
  %add.i.i.i127.i.i.i.i = add i32 %rem.i.i.i126.i.i.i.i.decomposed, %.neg
  %587 = zext i32 %add.i.i.i127.i.i.i.i to i64
  %arrayidx1.i.i.i128.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %587
  %588 = load double, double addrspace(4)* %arrayidx1.i.i.i128.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i129.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.0, %588
  %cmp26.i.i.i130.i.i.i.i = icmp slt i32 %581, 1021
  br i1 %cmp26.i.i.i130.i.i.i.i, label %do.body.i.i.i142.i.i.i.i, label %do.body40.i.i.i153.i.i.i.i

do.body.i.i.i142.i.i.i.i:                         ; preds = %do.body.i.i.i142.i.i.i.i, %if.end23.i.i.i131.i.i.i.i
  %guess.i.i.i78.i.i.i.i.1 = phi double [ %mul24.i.i.i129.i.i.i.i, %if.end23.i.i.i131.i.i.i.i ], [ %mul35.i.i.i139.i.i.i.i, %do.body.i.i.i142.i.i.i.i ]
  %mul28.i.i.i132.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.1, %guess.i.i.i78.i.i.i.i.1
  %mul29.i.i.i133.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.1, %mul28.i.i.i132.i.i.i.i
  %add30.i.i.i134.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %mul29.i.i.i133.i.i.i.i
  %add31.i.i.i135.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add30.i.i.i134.i.i.i.i
  %add32.i.i.i136.i.i.i.i = fadd double %mul29.i.i.i133.i.i.i.i, %mul29.i.i.i133.i.i.i.i
  %add33.i.i.i137.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add32.i.i.i136.i.i.i.i
  %div34.i.i.i138.i.i.i.i = fdiv double %add31.i.i.i135.i.i.i.i, %add33.i.i.i137.i.i.i.i
  %mul35.i.i.i139.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.1, %div34.i.i.i138.i.i.i.i
  %sub36.i.i.i140.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i138.i.i.i.i
  %589 = tail call double @llvm.fabs.f64(double %sub36.i.i.i140.i.i.i.i) #3
  %cmp38.i.i.i141.i.i.i.i = fcmp ogt double %589, 0x3EC0000000000000
  br i1 %cmp38.i.i.i141.i.i.i.i, label %do.body.i.i.i142.i.i.i.i, label %if.end4.i.i.i.i.i.i.i

do.body40.i.i.i153.i.i.i.i:                       ; preds = %do.body40.i.i.i153.i.i.i.i, %if.end23.i.i.i131.i.i.i.i
  %guess.i.i.i78.i.i.i.i.2 = phi double [ %mul24.i.i.i129.i.i.i.i, %if.end23.i.i.i131.i.i.i.i ], [ %sub48.i.i.i150.i.i.i.i, %do.body40.i.i.i153.i.i.i.i ]
  %mul41.i.i.i143.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.2, %guess.i.i.i78.i.i.i.i.2
  %div42.i.i.i144.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %guess.i.i.i78.i.i.i.i.2
  %sub43.i.i.i145.i.i.i.i = fsub double %mul41.i.i.i143.i.i.i.i, %div42.i.i.i144.i.i.i.i
  %mul44.i.i.i146.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i147.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %mul41.i.i.i143.i.i.i.i
  %add46.i.i.i148.i.i.i.i = fadd double %mul44.i.i.i146.i.i.i.i, %div45.i.i.i147.i.i.i.i
  %div47.i.i.i149.i.i.i.i = fdiv double %sub43.i.i.i145.i.i.i.i, %add46.i.i.i148.i.i.i.i
  %sub48.i.i.i150.i.i.i.i = fsub double %guess.i.i.i78.i.i.i.i.2, %div47.i.i.i149.i.i.i.i
  %mul50.i.i.i151.i.i.i.i = fmul double %sub48.i.i.i150.i.i.i.i, 0x3EC0000000000000
  %590 = tail call double @llvm.fabs.f64(double %div47.i.i.i149.i.i.i.i) #3
  %cmp52.i.i.i152.i.i.i.i = fcmp olt double %mul50.i.i.i151.i.i.i.i, %590
  br i1 %cmp52.i.i.i152.i.i.i.i, label %do.body40.i.i.i153.i.i.i.i, label %if.end4.i.i.i.i.i.i.i

if.end4.i.i.i.i.i.i.i:                            ; preds = %do.body40.i.i.i153.i.i.i.i, %do.body.i.i.i142.i.i.i.i
  %guess.i.i.i78.i.i.i.i.3 = phi double [ %mul35.i.i.i139.i.i.i.i, %do.body.i.i.i142.i.i.i.i ], [ %sub48.i.i.i150.i.i.i.i, %do.body40.i.i.i153.i.i.i.i ]
  %591 = fneg double %guess.i.i.i78.i.i.i.i.3
  %592 = select i1 %cmp5.i.i.i91.i.i.i.i, double %591, double %guess.i.i.i78.i.i.i.i.3
  br i1 %cmp11.i.i.i110.i.i.i.i, label %if.then12.i.i.i32.i.i.i.i, label %if.else21.i.i.i44.i.i.i.i

if.then12.i.i.i32.i.i.i.i:                        ; preds = %if.end4.i.i.i.i.i.i.i
  %cmp13.i.i.i31.i.i.i.i = icmp sgt i32 %581, 2
  br i1 %cmp13.i.i.i31.i.i.i.i, label %if.then14.i.i.i37.i.i.i.i, label %if.else.i.i.i43.i.i.i.i

if.then14.i.i.i37.i.i.i.i:                        ; preds = %if.then12.i.i.i32.i.i.i.i
  %sh_prom.i.i.i33.i.i.i.i = zext i32 %div.i.i.i108.i.i.i.i to i64
  %shl.i.i.i34.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i33.i.i.i.i
  %conv.i.i.i35.i.i.i.i = uitofp i64 %shl.i.i.i34.i.i.i.i to double
  %mul.i.i.i36.i.i.i.i = fmul double %add23.i.i.i.i.i107.i.i.i.i, %conv.i.i.i35.i.i.i.i
  br label %if.end23.i.i.i50.i.i.i.i

if.else.i.i.i43.i.i.i.i:                          ; preds = %if.then12.i.i.i32.i.i.i.i
  %sh_prom16.i.i.i39.i.i.i.i = zext i32 %584 to i64
  %shl17.i.i.i40.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i39.i.i.i.i
  %conv18.i.i.i41.i.i.i.i = uitofp i64 %shl17.i.i.i40.i.i.i.i to double
  %div19.i.i.i42.i.i.i.i = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %conv18.i.i.i41.i.i.i.i
  br label %if.end23.i.i.i50.i.i.i.i

if.else21.i.i.i44.i.i.i.i:                        ; preds = %if.end4.i.i.i.i.i.i.i
  %593 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  br label %if.end23.i.i.i50.i.i.i.i

if.end23.i.i.i50.i.i.i.i:                         ; preds = %if.else21.i.i.i44.i.i.i.i, %if.else.i.i.i43.i.i.i.i, %if.then14.i.i.i37.i.i.i.i
  %guess.i.i.i10.i.i.i.i.0 = phi double [ %mul.i.i.i36.i.i.i.i, %if.then14.i.i.i37.i.i.i.i ], [ %div19.i.i.i42.i.i.i.i, %if.else.i.i.i43.i.i.i.i ], [ %593, %if.else21.i.i.i44.i.i.i.i ]
  %mul24.i.i.i48.i.i.i.i = fmul double %588, %guess.i.i.i10.i.i.i.i.0
  br i1 %cmp26.i.i.i130.i.i.i.i, label %do.body.i.i.i61.i.i.i.i, label %do.body40.i.i.i72.i.i.i.i

do.body.i.i.i61.i.i.i.i:                          ; preds = %do.body.i.i.i61.i.i.i.i, %if.end23.i.i.i50.i.i.i.i
  %guess.i.i.i10.i.i.i.i.1 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %mul35.i.i.i58.i.i.i.i, %do.body.i.i.i61.i.i.i.i ]
  %mul28.i.i.i51.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.1, %guess.i.i.i10.i.i.i.i.1
  %mul29.i.i.i52.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.1, %mul28.i.i.i51.i.i.i.i
  %add30.i.i.i53.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %mul29.i.i.i52.i.i.i.i
  %add31.i.i.i54.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add30.i.i.i53.i.i.i.i
  %add32.i.i.i55.i.i.i.i = fadd double %mul29.i.i.i52.i.i.i.i, %mul29.i.i.i52.i.i.i.i
  %add33.i.i.i56.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add32.i.i.i55.i.i.i.i
  %div34.i.i.i57.i.i.i.i = fdiv double %add31.i.i.i54.i.i.i.i, %add33.i.i.i56.i.i.i.i
  %mul35.i.i.i58.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.1, %div34.i.i.i57.i.i.i.i
  %sub36.i.i.i59.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i57.i.i.i.i
  %594 = tail call double @llvm.fabs.f64(double %sub36.i.i.i59.i.i.i.i) #3
  %cmp38.i.i.i60.i.i.i.i = fcmp ogt double %594, 0x3EC0000000000000
  br i1 %cmp38.i.i.i60.i.i.i.i, label %do.body.i.i.i61.i.i.i.i, label %if.end54.i.i.i.i.i.i.i

do.body40.i.i.i72.i.i.i.i:                        ; preds = %do.body40.i.i.i72.i.i.i.i, %if.end23.i.i.i50.i.i.i.i
  %guess.i.i.i10.i.i.i.i.2 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %sub48.i.i.i69.i.i.i.i, %do.body40.i.i.i72.i.i.i.i ]
  %mul41.i.i.i62.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.2, %guess.i.i.i10.i.i.i.i.2
  %div42.i.i.i63.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %guess.i.i.i10.i.i.i.i.2
  %sub43.i.i.i64.i.i.i.i = fsub double %mul41.i.i.i62.i.i.i.i, %div42.i.i.i63.i.i.i.i
  %mul44.i.i.i65.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i66.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %mul41.i.i.i62.i.i.i.i
  %add46.i.i.i67.i.i.i.i = fadd double %mul44.i.i.i65.i.i.i.i, %div45.i.i.i66.i.i.i.i
  %div47.i.i.i68.i.i.i.i = fdiv double %sub43.i.i.i64.i.i.i.i, %add46.i.i.i67.i.i.i.i
  %sub48.i.i.i69.i.i.i.i = fsub double %guess.i.i.i10.i.i.i.i.2, %div47.i.i.i68.i.i.i.i
  %mul50.i.i.i70.i.i.i.i = fmul double %sub48.i.i.i69.i.i.i.i, 0x3EC0000000000000
  %595 = tail call double @llvm.fabs.f64(double %div47.i.i.i68.i.i.i.i) #3
  %cmp52.i.i.i71.i.i.i.i = fcmp olt double %mul50.i.i.i70.i.i.i.i, %595
  br i1 %cmp52.i.i.i71.i.i.i.i, label %do.body40.i.i.i72.i.i.i.i, label %if.end54.i.i.i.i.i.i.i

if.end54.i.i.i.i.i.i.i:                           ; preds = %do.body40.i.i.i72.i.i.i.i, %do.body.i.i.i61.i.i.i.i
  %guess.i.i.i10.i.i.i.i.3 = phi double [ %mul35.i.i.i58.i.i.i.i, %do.body.i.i.i61.i.i.i.i ], [ %sub48.i.i.i69.i.i.i.i, %do.body40.i.i.i72.i.i.i.i ]
  %596 = fneg double %guess.i.i.i10.i.i.i.i.3
  %597 = select i1 %cmp5.i.i.i91.i.i.i.i, double %596, double %guess.i.i.i10.i.i.i.i.3
  br label %if.end7.i.i.i.i.i.i.i

if.end7.i.i.i.i.i.i.i:                            ; preds = %if.end54.i.i.i.i.i.i.i, %if.then73.i.i.i.i
  %retval.0.i.i.i156.i.i.i.i162 = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %592, %if.end54.i.i.i.i.i.i.i ]
  %retval.0.i.i.i.i.i.i.i = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %597, %if.end54.i.i.i.i.i.i.i ]
  %mul76.i.i.i.i = fmul double %retval.0.i.i.i156.i.i.i.i162, %retval.0.i.i.i.i.i.i.i
  %mul79.i.i.i.i = fmul double %mul76.i.i.i.i, 0x3FFD8639FDCB60EB
  %div80.i.i.i.i = fdiv double 1.000000e+00, %mul79.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

cond.false7.i.i.i:                                ; preds = %if.end14.i.i
  %cmp.i4.i.i.i = fcmp ult double %arrayidx.val, 3.750000e-01
  br i1 %cmp.i4.i.i.i, label %if.else.i23.i.i.i, label %if.then.i21.i.i.i

if.then.i21.i.i.i:                                ; preds = %cond.false7.i.i.i
  %sub.i5.i.i.i = fadd double %arrayidx.val, -3.750000e-01
  %mul.i.i.i6.i.i.i = fmul double %sub.i5.i.i.i, %sub.i5.i.i.i
  %mul1.i.i.i7.i.i.i = fmul double %mul.i.i.i6.i.i.i, 0x40132BDEE3243B58
  %add.i.i.i8.i.i.i = fadd double %mul1.i.i.i7.i.i.i, 0xC0360FDD97954BA2
  %mul5.i.i.i9.i.i.i = fmul double %mul.i.i.i6.i.i.i, 0x401CB5EDEDB31A3B
  %add7.i.i.i10.i.i.i = fadd double %mul5.i.i.i9.i.i.i, 0xC017CB97C9E45E0D
  %mul10.i.i.i11.i.i.i = fmul double %mul.i.i.i6.i.i.i, %add.i.i.i8.i.i.i
  %mul12.i.i.i12.i.i.i = fmul double %mul.i.i.i6.i.i.i, %add7.i.i.i10.i.i.i
  %add15.i.i.i13.i.i.i = fadd double %mul10.i.i.i11.i.i.i, 0x4027FEF192CFFD80
  %add18.i.i.i14.i.i.i = fadd double %mul12.i.i.i12.i.i.i, 0x3FF83BDAD25D5F48
  %mul20.i.i.i15.i.i.i = fmul double %mul.i.i.i6.i.i.i, %add15.i.i.i13.i.i.i
  %add23.i.i.i16.i.i.i = fadd double %mul20.i.i.i15.i.i.i, 0xBFF2C5AD0DCDC29A
  %mul25.i.i.i17.i.i.i = fmul double %sub.i5.i.i.i, %add18.i.i.i14.i.i.i
  %add28.i.i.i18.i.i.i = fadd double %mul25.i.i.i17.i.i.i, %add23.i.i.i16.i.i.i
  %mul1.i.i310.i.i.i.i = fmul double %mul.i.i.i6.i.i.i, 0x3FF693D2420640AD
  %598 = fsub double 0x401B5545C0CB5BDA, %mul1.i.i310.i.i.i.i
  %mul5.i.i312.i.i.i.i = fmul double %mul.i.i.i6.i.i.i, 0x40074E9A9F865729
  %add7.i.i313.i.i.i.i = fadd double %mul5.i.i312.i.i.i.i, 0xC016B372910B83AB
  %mul10.i.i314.i.i.i.i = fmul double %mul.i.i.i6.i.i.i, %598
  %mul12.i.i315.i.i.i.i = fmul double %mul.i.i.i6.i.i.i, %add7.i.i313.i.i.i.i
  %add15.i.i316.i.i.i.i = fadd double %mul10.i.i314.i.i.i.i, 0xC0138A29DF206C0B
  %add18.i.i317.i.i.i.i = fadd double %mul12.i.i315.i.i.i.i, 0x3FFC33F0B4C09D66
  %mul20.i.i318.i.i.i.i = fmul double %mul.i.i.i6.i.i.i, %add15.i.i316.i.i.i.i
  %add23.i.i319.i.i.i.i = fadd double %mul20.i.i318.i.i.i.i, 1.000000e+00
  %mul25.i.i320.i.i.i.i = fmul double %sub.i5.i.i.i, %add18.i.i317.i.i.i.i
  %add28.i.i321.i.i.i.i = fadd double %mul25.i.i320.i.i.i.i, %add23.i.i319.i.i.i.i
  %div.i20.i.i.i = fdiv double %add28.i.i.i18.i.i.i, %add28.i.i321.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else.i23.i.i.i:                                ; preds = %cond.false7.i.i.i
  %cmp2.i22.i.i.i = fcmp ult double %arrayidx.val, 2.500000e-01
  br i1 %cmp2.i22.i.i.i, label %if.else9.i28.i.i.i, label %if.then3.i27.i.i.i

if.then3.i27.i.i.i:                               ; preds = %if.else.i23.i.i.i
  %sub5.i24.i.i.i = fadd double %arrayidx.val, -2.500000e-01
  %mul.i.i296.i.i.i.i = fmul double %sub5.i24.i.i.i, %sub5.i24.i.i.i
  %mul1.i.i297.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, 0x402A50B00A1E7B86
  %add.i.i298.i.i.i.i = fadd double %mul1.i.i297.i.i.i.i, 0xC03EAAFBAB179207
  %mul5.i.i299.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, 0x403CBAD71AE3B29A
  %599 = fsub double 0x4040A8BCD7811DE4, %mul5.i.i299.i.i.i.i
  %mul10.i.i301.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, %add.i.i298.i.i.i.i
  %mul12.i.i302.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, %599
  %add15.i.i303.i.i.i.i = fadd double %mul10.i.i301.i.i.i.i, 0x402CB09090084637
  %add18.i.i304.i.i.i.i = fadd double %mul12.i.i302.i.i.i.i, 0xC013B1AD6B90733F
  %mul20.i.i305.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, %add15.i.i303.i.i.i.i
  %add23.i.i306.i.i.i.i = fadd double %mul20.i.i305.i.i.i.i, 0xBFFA1FFFE7A41296
  %mul25.i.i307.i.i.i.i = fmul double %sub5.i24.i.i.i, %add18.i.i304.i.i.i.i
  %add28.i.i308.i.i.i.i = fadd double %mul25.i.i307.i.i.i.i, %add23.i.i306.i.i.i.i
  %mul1.i.i286.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, 0x40296F06194D60C2
  %add.i.i287.i.i.i.i = fadd double %mul1.i.i286.i.i.i.i, 0xC030F25386AA802B
  %mul5.i.i288.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, 0x40199996D51EE9B7
  %600 = fsub double 0x40034649FCCCF81F, %mul5.i.i288.i.i.i.i
  %mul10.i.i290.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, %add.i.i287.i.i.i.i
  %mul12.i.i291.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, %600
  %add15.i.i292.i.i.i.i = fadd double %mul10.i.i290.i.i.i.i, 0x40158CEB587D3265
  %add18.i.i293.i.i.i.i = fadd double %mul12.i.i291.i.i.i.i, 1.000000e+00
  %mul20.i.i294.i.i.i.i = fmul double %sub5.i24.i.i.i, %add15.i.i292.i.i.i.i
  %add23.i.i295.i.i.i.i = fadd double %add18.i.i293.i.i.i.i, %mul20.i.i294.i.i.i.i
  %div8.i26.i.i.i = fdiv double %add28.i.i308.i.i.i.i, %add23.i.i295.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else9.i28.i.i.i:                               ; preds = %if.else.i23.i.i.i
  %cmp10.i.i.i.i = fcmp ult double %arrayidx.val, 1.250000e-01
  %decision.left = xor i1 %cmp10.i.i.i.i, true
  br i1 %cmp10.i.i.i.i, label %if.else17.i.i.i.i, label %decision.gate, !decision.condition_prefix !6

if.then11.i.i.i.i:                                ; preds = %decision.dispatch
  %sub13.i.i.i.i = fadd double %arrayidx.val, -1.250000e-01
  %mul.i.i270.i.i.i.i = fmul double %sub13.i.i.i.i, %sub13.i.i.i.i
  %mul1.i.i271.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x406D392CDE09E490
  %601 = fsub double 0x408C7AAA9D225E9A, %mul1.i.i271.i.i.i.i
  %mul5.i.i273.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x408B6249334DA816
  %602 = fsub double 0x408C1B9BAF952B96, %mul5.i.i273.i.i.i.i
  %mul10.i.i275.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %601
  %mul12.i.i276.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %602
  %add15.i.i277.i.i.i.i = fadd double %mul10.i.i275.i.i.i.i, 0xC05E9BCF5C362E51
  %add18.i.i278.i.i.i.i = fadd double %mul12.i.i276.i.i.i.i, 0xC066A4A24A4E1713
  %mul20.i.i279.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add15.i.i277.i.i.i.i
  %mul22.i.i280.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add18.i.i278.i.i.i.i
  %add25.i.i281.i.i.i.i = fadd double %mul20.i.i279.i.i.i.i, 0xC04249A2BD20D346
  %add28.i.i282.i.i.i.i = fadd double %mul22.i.i280.i.i.i.i, 0xC001804F92FE2A82
  %mul30.i.i283.i.i.i.i = fmul double %sub13.i.i.i.i, %add25.i.i281.i.i.i.i
  %add33.i.i284.i.i.i.i = fadd double %add28.i.i282.i.i.i.i, %mul30.i.i283.i.i.i.i
  %mul1.i.i256.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x405E5232607614DB
  %add.i.i257.i.i.i.i = fadd double %mul1.i.i256.i.i.i.i, 0xC0809E1D789AFFE5
  %mul5.i.i258.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x404C078043CB129C
  %603 = fsub double 0xC0320C17B7F0ED52, %mul5.i.i258.i.i.i.i
  %mul10.i.i260.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add.i.i257.i.i.i.i
  %mul12.i.i261.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %603
  %add15.i.i262.i.i.i.i = fadd double %mul10.i.i260.i.i.i.i, 0x4071A64A34042F35
  %add18.i.i263.i.i.i.i = fadd double %mul12.i.i261.i.i.i.i, 0x405F12CC60181A8F
  %mul20.i.i264.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add15.i.i262.i.i.i.i
  %mul22.i.i265.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add18.i.i263.i.i.i.i
  %add25.i.i266.i.i.i.i = fadd double %mul20.i.i264.i.i.i.i, 0x40332E0500972875
  %add28.i.i267.i.i.i.i = fadd double %mul22.i.i265.i.i.i.i, 1.000000e+00
  %mul30.i.i268.i.i.i.i = fmul double %sub13.i.i.i.i, %add25.i.i266.i.i.i.i
  %add33.i.i269.i.i.i.i = fadd double %add28.i.i267.i.i.i.i, %mul30.i.i268.i.i.i.i
  %div16.i.i.i.i = fdiv double %add33.i.i284.i.i.i.i, %add33.i.i269.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i.pair.join

if.else17.i.i.i.i:                                ; preds = %if.else9.i28.i.i.i
  %604 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %arrayidx.val) #3
  %605 = add nsw i32 %604, -1
  %606 = tail call double @llvm.fabs.f64(double %arrayidx.val) #4
  %607 = fcmp oeq double %606, 0x7FF0000000000000
  %608 = select i1 %607, i32 2147483647, i32 %605
  %609 = fcmp oeq double %arrayidx.val, 0.000000e+00
  %610 = select i1 %609, i32 -2147483648, i32 %608
  %cmp19.i.i.i.i = icmp sgt i32 %610, -5
  br label %decision.gate

decision.gate:                                    ; preds = %if.else17.i.i.i.i, %if.else9.i28.i.i.i
  %decision.value = phi i32 [ undef, %if.else9.i28.i.i.i ], [ %610, %if.else17.i.i.i.i ]
  %decision.take = phi i1 [ true, %if.else9.i28.i.i.i ], [ %cmp19.i.i.i.i, %if.else17.i.i.i.i ]
  br i1 %decision.take, label %decision.dispatch, label %if.else27.i.i.i.i, !decision.short_gate !6

decision.dispatch:                                ; preds = %decision.gate
  br i1 %decision.left, label %if.then11.i.i.i.i, label %if.then20.i.i.i.i, !decision.merged_from !12, !decision.origin !13

if.then20.i.i.i.i:                                ; preds = %decision.dispatch
  %611 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 3) #3
  %612 = tail call double @llvm.amdgcn.frexp.mant.f64(double %611) #3
  %613 = fcmp olt double %612, 0x3FE5555555555555
  %614 = zext i1 %613 to i32
  %615 = tail call double @llvm.amdgcn.ldexp.f64(double %612, i32 %614) #3
  %616 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %611) #3
  %617 = sub nsw i32 %616, %614
  %618 = fadd double %615, -1.000000e+00
  %619 = fadd double %615, 1.000000e+00
  %620 = fsub double %619, %615
  %621 = fsub double %619, %620
  %622 = fsub double %615, %621
  %623 = fsub double 1.000000e+00, %620
  %624 = fadd double %623, %622
  %625 = tail call double @llvm.amdgcn.rcp.f64(double %619) #3
  %626 = fneg double %619
  %627 = tail call double @llvm.fma.f64(double %626, double %625, double 1.000000e+00) #3
  %628 = tail call double @llvm.fma.f64(double %627, double %625, double %625) #3
  %629 = tail call double @llvm.fma.f64(double %626, double %628, double 1.000000e+00) #3
  %630 = tail call double @llvm.fma.f64(double %629, double %628, double %628) #3
  %631 = fmul double %618, %630
  %632 = fmul double %619, %631
  %633 = fneg double %632
  %634 = tail call double @llvm.fma.f64(double %631, double %619, double %633) #3
  %635 = tail call double @llvm.fma.f64(double %631, double %624, double %634) #3
  %636 = fadd double %632, %635
  %637 = fsub double %636, %632
  %638 = fsub double %635, %637
  %639 = fsub double %618, %636
  %640 = fsub double %618, %639
  %641 = fsub double %640, %636
  %642 = fsub double %641, %638
  %643 = fadd double %639, %642
  %644 = fmul double %630, %643
  %645 = fadd double %631, %644
  %646 = fsub double %645, %631
  %647 = fsub double %644, %646
  %648 = fmul double %645, %645
  %649 = fneg double %648
  %650 = tail call double @llvm.fma.f64(double %645, double %645, double %649) #3
  %651 = fmul double %647, 2.000000e+00
  %652 = tail call double @llvm.fma.f64(double %645, double %651, double %650) #3
  %653 = tail call double @llvm.fma.f64(double %647, double %647, double %652) #3
  %654 = fadd double %648, %653
  %655 = fsub double %654, %648
  %656 = fsub double %653, %655
  %657 = tail call double @llvm.fma.f64(double %654, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %658 = tail call double @llvm.fma.f64(double %654, double %657, double 0x3FC7474DD7F4DF2E) #3
  %659 = tail call double @llvm.fma.f64(double %654, double %658, double 0x3FCC71C016291751) #3
  %660 = tail call double @llvm.fma.f64(double %654, double %659, double 0x3FD249249B27ACF1) #3
  %661 = tail call double @llvm.fma.f64(double %654, double %660, double 0x3FD99999998EF7B6) #3
  %662 = tail call double @llvm.fma.f64(double %654, double %661, double 0x3FE5555555555780) #3
  %663 = tail call double @llvm.amdgcn.ldexp.f64(double %645, i32 1) #3
  %664 = tail call double @llvm.amdgcn.ldexp.f64(double %647, i32 1) #3
  %665 = fmul double %645, %654
  %666 = fneg double %665
  %667 = tail call double @llvm.fma.f64(double %645, double %654, double %666) #3
  %668 = fmul double %647, %654
  %669 = tail call double @llvm.fma.f64(double %645, double %656, double %668) #3
  %670 = fadd double %667, %669
  %671 = fadd double %665, %670
  %672 = fsub double %671, %665
  %673 = fsub double %670, %672
  %674 = fmul double %671, %662
  %675 = fneg double %674
  %676 = tail call double @llvm.fma.f64(double %671, double %662, double %675) #3
  %677 = tail call double @llvm.fma.f64(double %673, double %662, double %676) #3
  %678 = fadd double %674, %677
  %679 = fsub double %678, %674
  %680 = fsub double %677, %679
  %681 = fadd double %663, %678
  %682 = fsub double %681, %663
  %683 = fsub double %681, %682
  %684 = fsub double %663, %683
  %685 = fsub double %678, %682
  %686 = fadd double %685, %684
  %687 = fadd double %664, %680
  %688 = fsub double %687, %664
  %689 = fsub double %687, %688
  %690 = fsub double %664, %689
  %691 = fsub double %680, %688
  %692 = fadd double %691, %690
  %693 = fadd double %687, %686
  %694 = fadd double %681, %693
  %695 = fsub double %694, %681
  %696 = fsub double %693, %695
  %697 = fadd double %692, %696
  %698 = fadd double %694, %697
  %699 = fsub double %698, %694
  %700 = fsub double %697, %699
  %701 = sitofp i32 %617 to double
  %702 = fmul double %698, 0x3FF71547652B82FE
  %703 = fneg double %702
  %704 = fmul double %698, 0x3C7777D0FFDA0D24
  %705 = insertelement <2 x double> undef, double %698, i32 0
  %706 = insertelement <2 x double> %705, double %700, i32 1
  %707 = insertelement <2 x double> undef, double %703, i32 0
  %708 = insertelement <2 x double> %707, double %704, i32 1
  %709 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %706, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %708) #3
  %710 = extractelement <2 x double> %709, i32 0
  %711 = extractelement <2 x double> %709, i32 1
  %712 = fadd double %710, %711
  %713 = fadd double %702, %712
  %714 = fsub double %713, %702
  %715 = fsub double %712, %714
  %716 = fadd double %713, %701
  %717 = fsub double %716, %701
  %718 = fsub double %717, %716
  %719 = fadd double %718, %701
  %720 = fsub double %713, %717
  %721 = fadd double %720, %719
  %722 = fadd double %715, %721
  %723 = fadd double %716, %722
  %724 = tail call double @llvm.fabs.f64(double %611) #4
  %725 = fcmp oeq double %724, 0x7FF0000000000000
  %726 = select i1 %725, double %611, double %723
  %727 = fcmp olt double %611, 0.000000e+00
  %728 = select i1 %727, double 0x7FF8000000000000, double %726
  %729 = fcmp oeq double %611, 0.000000e+00
  %730 = select i1 %729, double 0xFFF0000000000000, double %728
  %mul.i.i244.i.i.i.i = fmul double %730, %730
  %mul1.i.i245.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F1989D450BBA5CA
  %731 = fsub double 0xBFBD94CCEC41CB08, %mul1.i.i245.i.i.i.i
  %mul5.i.i247.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F7B3A00DD9C9429
  %732 = fsub double 0xBFE8DDD719DA7D3E, %mul5.i.i247.i.i.i.i
  %mul10.i.i249.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %731
  %mul12.i.i250.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %732
  %add15.i.i251.i.i.i.i = fadd double %mul10.i.i249.i.i.i.i, 0xC001974D2C397C76
  %add18.i.i252.i.i.i.i = fadd double %mul12.i.i250.i.i.i.i, 0xC001804F92FE2A82
  %733 = fmul double %730, %add15.i.i251.i.i.i.i
  %add23.i.i254.i.i.i.i = fsub double %add18.i.i252.i.i.i.i, %733
  %mul1.i.i234.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3EDBEC7AF5AC0D6F
  %add.i.i235.i.i.i.i = fadd double %mul1.i.i234.i.i.i.i, 0x3F98BA1DB321D0E9
  %mul5.i.i236.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F4ED662BB480251
  %add7.i.i237.i.i.i.i = fadd double %mul5.i.i236.i.i.i.i, 0x3FCBD444F5D4FCC2
  %mul10.i.i238.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %add.i.i235.i.i.i.i
  %mul12.i.i239.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %add7.i.i237.i.i.i.i
  %add15.i.i240.i.i.i.i = fadd double %mul10.i.i238.i.i.i.i, 0x3FE957680773BEB6
  %add18.i.i241.i.i.i.i = fadd double %mul12.i.i239.i.i.i.i, 1.000000e+00
  %734 = fmul double %730, %add15.i.i240.i.i.i.i
  %add23.i.i243.i.i.i.i = fsub double %add18.i.i241.i.i.i.i, %734
  %div26.i.i.i.i = fdiv double %add23.i.i254.i.i.i.i, %add23.i.i243.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i.pair.join

if.else27.i.i.i.i:                                ; preds = %decision.gate
  %cmp62.i.i.i.i = icmp sgt i32 %decision.value, -65
  br i1 %cmp62.i.i.i.i, label %decision.dispatch4, label %if.else71.i37.i.i.i, !decision.condition_prefix !6

decision.dispatch4:                               ; preds = %if.else27.i.i.i.i
  %cmp40.i.i.i.i = icmp sgt i32 %decision.value, -17
  %merged.select = select i1 %cmp40.i.i.i.i, i32 -9, i32 -33
  %735 = icmp sgt i32 %decision.value, %merged.select
  %merged.select36 = select i1 %cmp40.i.i.i.i, i32 4, i32 16
  %merged.select37 = select i1 %cmp40.i.i.i.i, i32 8, i32 32
  %736 = select i1 %735, i32 %merged.select36, i32 %merged.select37
  %737 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %736) #3
  %738 = tail call double @llvm.amdgcn.frexp.mant.f64(double %737) #3
  %739 = fcmp olt double %738, 0x3FE5555555555555
  %740 = zext i1 %739 to i32
  %741 = tail call double @llvm.amdgcn.ldexp.f64(double %738, i32 %740) #3
  %742 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %737) #3
  %743 = sub nsw i32 %742, %740
  %744 = fadd double %741, -1.000000e+00
  %745 = fadd double %741, 1.000000e+00
  %746 = fsub double %745, %741
  %747 = fsub double %745, %746
  %748 = fsub double %741, %747
  %749 = fsub double 1.000000e+00, %746
  %750 = fadd double %749, %748
  %751 = tail call double @llvm.amdgcn.rcp.f64(double %745) #3
  %752 = fneg double %745
  %753 = tail call double @llvm.fma.f64(double %752, double %751, double 1.000000e+00) #3
  %754 = tail call double @llvm.fma.f64(double %753, double %751, double %751) #3
  %755 = tail call double @llvm.fma.f64(double %752, double %754, double 1.000000e+00) #3
  %756 = tail call double @llvm.fma.f64(double %755, double %754, double %754) #3
  %757 = fmul double %744, %756
  %758 = fmul double %745, %757
  %759 = fneg double %758
  %760 = tail call double @llvm.fma.f64(double %757, double %745, double %759) #3
  %761 = tail call double @llvm.fma.f64(double %757, double %750, double %760) #3
  %762 = fadd double %758, %761
  %763 = fsub double %762, %758
  %764 = fsub double %761, %763
  %765 = fsub double %744, %762
  %766 = fsub double %744, %765
  %767 = fsub double %766, %762
  %768 = fsub double %767, %764
  %769 = fadd double %765, %768
  %770 = fmul double %756, %769
  %771 = fadd double %757, %770
  %772 = fsub double %771, %757
  %773 = fsub double %770, %772
  %774 = fmul double %771, %771
  %775 = fneg double %774
  %776 = tail call double @llvm.fma.f64(double %771, double %771, double %775) #3
  %777 = fmul double %773, 2.000000e+00
  %778 = tail call double @llvm.fma.f64(double %771, double %777, double %776) #3
  %779 = tail call double @llvm.fma.f64(double %773, double %773, double %778) #3
  %780 = fadd double %774, %779
  %781 = fsub double %780, %774
  %782 = fsub double %779, %781
  %783 = tail call double @llvm.fma.f64(double %780, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %784 = tail call double @llvm.fma.f64(double %780, double %783, double 0x3FC7474DD7F4DF2E) #3
  %785 = tail call double @llvm.fma.f64(double %780, double %784, double 0x3FCC71C016291751) #3
  %786 = tail call double @llvm.fma.f64(double %780, double %785, double 0x3FD249249B27ACF1) #3
  %787 = tail call double @llvm.fma.f64(double %780, double %786, double 0x3FD99999998EF7B6) #3
  %788 = tail call double @llvm.fma.f64(double %780, double %787, double 0x3FE5555555555780) #3
  %789 = tail call double @llvm.amdgcn.ldexp.f64(double %771, i32 1) #3
  %790 = tail call double @llvm.amdgcn.ldexp.f64(double %773, i32 1) #3
  %791 = fmul double %771, %780
  %792 = fneg double %791
  %793 = tail call double @llvm.fma.f64(double %771, double %780, double %792) #3
  %794 = fmul double %773, %780
  %795 = tail call double @llvm.fma.f64(double %771, double %782, double %794) #3
  %796 = fadd double %793, %795
  %797 = fadd double %791, %796
  %798 = fsub double %797, %791
  %799 = fsub double %796, %798
  %800 = fmul double %797, %788
  %801 = fneg double %800
  %802 = tail call double @llvm.fma.f64(double %797, double %788, double %801) #3
  %803 = tail call double @llvm.fma.f64(double %799, double %788, double %802) #3
  %804 = fadd double %800, %803
  %805 = fsub double %804, %800
  %806 = fsub double %803, %805
  %807 = fadd double %789, %804
  %808 = fsub double %807, %789
  %809 = fsub double %807, %808
  %810 = fsub double %789, %809
  %811 = fsub double %804, %808
  %812 = fadd double %811, %810
  %813 = fadd double %790, %806
  %814 = fsub double %813, %790
  %815 = fsub double %813, %814
  %816 = fsub double %790, %815
  %817 = fsub double %806, %814
  %818 = fadd double %817, %816
  %819 = fadd double %813, %812
  %820 = fadd double %807, %819
  %821 = fsub double %820, %807
  %822 = fsub double %819, %821
  %823 = fadd double %818, %822
  %824 = fadd double %820, %823
  %825 = fsub double %824, %820
  %826 = fsub double %823, %825
  %827 = sitofp i32 %743 to double
  %828 = fmul double %824, 0x3FF71547652B82FE
  %829 = fneg double %828
  %830 = fmul double %824, 0x3C7777D0FFDA0D24
  br i1 %735, label %merged.bb33, label %merged.bb34

if.else71.i37.i.i.i:                              ; preds = %if.else27.i.i.i.i
  %cmp84.i.i.i.i = icmp sgt i32 %decision.value, -257
  br i1 %cmp84.i.i.i.i, label %decision.dispatch2, label %if.else93.i.i.i.i, !decision.condition_prefix !6

decision.dispatch2:                               ; preds = %if.else71.i37.i.i.i
  %cmp73.i.i.i.i = icmp sgt i32 %decision.value, -129
  %831 = select i1 %cmp73.i.i.i.i, i32 64, i32 128
  %832 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %831) #3
  %833 = tail call double @llvm.amdgcn.frexp.mant.f64(double %832) #3
  %834 = fcmp olt double %833, 0x3FE5555555555555
  %835 = zext i1 %834 to i32
  %836 = tail call double @llvm.amdgcn.ldexp.f64(double %833, i32 %835) #3
  %837 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %832) #3
  %838 = sub nsw i32 %837, %835
  %839 = fadd double %836, -1.000000e+00
  %840 = fadd double %836, 1.000000e+00
  %841 = fsub double %840, %836
  %842 = fsub double %840, %841
  %843 = fsub double %836, %842
  %844 = fsub double 1.000000e+00, %841
  %845 = fadd double %844, %843
  %846 = tail call double @llvm.amdgcn.rcp.f64(double %840) #3
  %847 = fneg double %840
  %848 = tail call double @llvm.fma.f64(double %847, double %846, double 1.000000e+00) #3
  %849 = tail call double @llvm.fma.f64(double %848, double %846, double %846) #3
  %850 = tail call double @llvm.fma.f64(double %847, double %849, double 1.000000e+00) #3
  %851 = tail call double @llvm.fma.f64(double %850, double %849, double %849) #3
  %852 = fmul double %839, %851
  %853 = fmul double %840, %852
  %854 = fneg double %853
  %855 = tail call double @llvm.fma.f64(double %852, double %840, double %854) #3
  %856 = tail call double @llvm.fma.f64(double %852, double %845, double %855) #3
  %857 = fadd double %853, %856
  %858 = fsub double %857, %853
  %859 = fsub double %856, %858
  %860 = fsub double %839, %857
  %861 = fsub double %839, %860
  %862 = fsub double %861, %857
  %863 = fsub double %862, %859
  %864 = fadd double %860, %863
  %865 = fmul double %851, %864
  %866 = fadd double %852, %865
  %867 = fsub double %866, %852
  %868 = fsub double %865, %867
  %869 = fmul double %866, %866
  %870 = fneg double %869
  %871 = tail call double @llvm.fma.f64(double %866, double %866, double %870) #3
  %872 = fmul double %868, 2.000000e+00
  %873 = tail call double @llvm.fma.f64(double %866, double %872, double %871) #3
  %874 = tail call double @llvm.fma.f64(double %868, double %868, double %873) #3
  %875 = fadd double %869, %874
  %876 = fsub double %875, %869
  %877 = fsub double %874, %876
  %878 = tail call double @llvm.fma.f64(double %875, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %879 = tail call double @llvm.fma.f64(double %875, double %878, double 0x3FC7474DD7F4DF2E) #3
  %880 = tail call double @llvm.fma.f64(double %875, double %879, double 0x3FCC71C016291751) #3
  %881 = tail call double @llvm.fma.f64(double %875, double %880, double 0x3FD249249B27ACF1) #3
  %882 = tail call double @llvm.fma.f64(double %875, double %881, double 0x3FD99999998EF7B6) #3
  %883 = tail call double @llvm.fma.f64(double %875, double %882, double 0x3FE5555555555780) #3
  %884 = tail call double @llvm.amdgcn.ldexp.f64(double %866, i32 1) #3
  %885 = tail call double @llvm.amdgcn.ldexp.f64(double %868, i32 1) #3
  %886 = fmul double %866, %875
  %887 = fneg double %886
  %888 = tail call double @llvm.fma.f64(double %866, double %875, double %887) #3
  %889 = fmul double %868, %875
  %890 = tail call double @llvm.fma.f64(double %866, double %877, double %889) #3
  %891 = fadd double %888, %890
  %892 = fadd double %886, %891
  %893 = fsub double %892, %886
  %894 = fsub double %891, %893
  %895 = fmul double %892, %883
  %896 = fneg double %895
  %897 = tail call double @llvm.fma.f64(double %892, double %883, double %896) #3
  %898 = tail call double @llvm.fma.f64(double %894, double %883, double %897) #3
  %899 = fadd double %895, %898
  %900 = fsub double %899, %895
  %901 = fsub double %898, %900
  %902 = fadd double %884, %899
  %903 = fsub double %902, %884
  %904 = fsub double %902, %903
  %905 = fsub double %884, %904
  %906 = fsub double %899, %903
  %907 = fadd double %906, %905
  %908 = fadd double %885, %901
  %909 = fsub double %908, %885
  %910 = fsub double %908, %909
  %911 = fsub double %885, %910
  %912 = fsub double %901, %909
  %913 = fadd double %912, %911
  %914 = fadd double %908, %907
  %915 = fadd double %902, %914
  %916 = fsub double %915, %902
  %917 = fsub double %914, %916
  %918 = fadd double %913, %917
  %919 = fadd double %915, %918
  %920 = fsub double %919, %915
  %921 = fsub double %918, %920
  %922 = sitofp i32 %838 to double
  %923 = fmul double %919, 0x3FF71547652B82FE
  %924 = fneg double %923
  %925 = fmul double %919, 0x3C7777D0FFDA0D24
  br i1 %cmp73.i.i.i.i, label %fusion.side4, label %fusion.side5

if.else93.i.i.i.i:                                ; preds = %if.else71.i37.i.i.i
  %cmp106.i.i.i.i = icmp sgt i32 %decision.value, -1025
  br i1 %cmp106.i.i.i.i, label %decision.dispatch3, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, !decision.condition_prefix !6

decision.dispatch3:                               ; preds = %if.else93.i.i.i.i
  %cmp95.i.i.i.i = icmp sgt i32 %decision.value, -513
  %926 = select i1 %cmp95.i.i.i.i, i32 256, i32 512
  %927 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %926) #3
  %928 = tail call double @llvm.amdgcn.frexp.mant.f64(double %927) #3
  %929 = fcmp olt double %928, 0x3FE5555555555555
  %930 = zext i1 %929 to i32
  %931 = tail call double @llvm.amdgcn.ldexp.f64(double %928, i32 %930) #3
  %932 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %927) #3
  %933 = sub nsw i32 %932, %930
  %934 = fadd double %931, -1.000000e+00
  %935 = fadd double %931, 1.000000e+00
  %936 = fsub double %935, %931
  %937 = fsub double %935, %936
  %938 = fsub double %931, %937
  %939 = fsub double 1.000000e+00, %936
  %940 = fadd double %939, %938
  %941 = tail call double @llvm.amdgcn.rcp.f64(double %935) #3
  %942 = fneg double %935
  %943 = tail call double @llvm.fma.f64(double %942, double %941, double 1.000000e+00) #3
  %944 = tail call double @llvm.fma.f64(double %943, double %941, double %941) #3
  %945 = tail call double @llvm.fma.f64(double %942, double %944, double 1.000000e+00) #3
  %946 = tail call double @llvm.fma.f64(double %945, double %944, double %944) #3
  %947 = fmul double %934, %946
  %948 = fmul double %935, %947
  %949 = fneg double %948
  %950 = tail call double @llvm.fma.f64(double %947, double %935, double %949) #3
  %951 = tail call double @llvm.fma.f64(double %947, double %940, double %950) #3
  %952 = fadd double %948, %951
  %953 = fsub double %952, %948
  %954 = fsub double %951, %953
  %955 = fsub double %934, %952
  %956 = fsub double %934, %955
  %957 = fsub double %956, %952
  %958 = fsub double %957, %954
  %959 = fadd double %955, %958
  %960 = fmul double %946, %959
  %961 = fadd double %947, %960
  %962 = fsub double %961, %947
  %963 = fsub double %960, %962
  %964 = fmul double %961, %961
  %965 = fneg double %964
  %966 = tail call double @llvm.fma.f64(double %961, double %961, double %965) #3
  %967 = fmul double %963, 2.000000e+00
  %968 = tail call double @llvm.fma.f64(double %961, double %967, double %966) #3
  %969 = tail call double @llvm.fma.f64(double %963, double %963, double %968) #3
  %970 = fadd double %964, %969
  %971 = fsub double %970, %964
  %972 = fsub double %969, %971
  %973 = tail call double @llvm.fma.f64(double %970, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %974 = tail call double @llvm.fma.f64(double %970, double %973, double 0x3FC7474DD7F4DF2E) #3
  %975 = tail call double @llvm.fma.f64(double %970, double %974, double 0x3FCC71C016291751) #3
  %976 = tail call double @llvm.fma.f64(double %970, double %975, double 0x3FD249249B27ACF1) #3
  %977 = tail call double @llvm.fma.f64(double %970, double %976, double 0x3FD99999998EF7B6) #3
  %978 = tail call double @llvm.fma.f64(double %970, double %977, double 0x3FE5555555555780) #3
  %979 = tail call double @llvm.amdgcn.ldexp.f64(double %961, i32 1) #3
  %980 = tail call double @llvm.amdgcn.ldexp.f64(double %963, i32 1) #3
  %981 = fmul double %961, %970
  %982 = fneg double %981
  %983 = tail call double @llvm.fma.f64(double %961, double %970, double %982) #3
  %984 = fmul double %963, %970
  %985 = tail call double @llvm.fma.f64(double %961, double %972, double %984) #3
  %986 = fadd double %983, %985
  %987 = fadd double %981, %986
  %988 = fsub double %987, %981
  %989 = fsub double %986, %988
  %990 = fmul double %987, %978
  %991 = fneg double %990
  %992 = tail call double @llvm.fma.f64(double %987, double %978, double %991) #3
  %993 = tail call double @llvm.fma.f64(double %989, double %978, double %992) #3
  %994 = fadd double %990, %993
  %995 = fsub double %994, %990
  %996 = fsub double %993, %995
  %997 = fadd double %979, %994
  %998 = fsub double %997, %979
  %999 = fsub double %997, %998
  %1000 = fsub double %979, %999
  %1001 = fsub double %994, %998
  %1002 = fadd double %1001, %1000
  %1003 = fadd double %980, %996
  %1004 = fsub double %1003, %980
  %1005 = fsub double %1003, %1004
  %1006 = fsub double %980, %1005
  %1007 = fsub double %996, %1004
  %1008 = fadd double %1007, %1006
  %1009 = fadd double %1003, %1002
  %1010 = fadd double %997, %1009
  %1011 = fsub double %1010, %997
  %1012 = fsub double %1009, %1011
  %1013 = fadd double %1008, %1012
  %1014 = fadd double %1010, %1013
  %1015 = fsub double %1014, %1010
  %1016 = fsub double %1013, %1015
  %1017 = sitofp i32 %933 to double
  %1018 = fmul double %1014, 0x3FF71547652B82FE
  %1019 = fneg double %1018
  %1020 = fmul double %1014, 0x3C7777D0FFDA0D24
  br i1 %cmp95.i.i.i.i, label %fusion.side6, label %fusion.side7

fusion.side4:                                     ; preds = %decision.dispatch2
  %1021 = insertelement <2 x double> undef, double %919, i32 0
  %1022 = insertelement <2 x double> %1021, double %921, i32 1
  %1023 = insertelement <2 x double> undef, double %924, i32 0
  %1024 = insertelement <2 x double> %1023, double %925, i32 1
  %1025 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1022, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1024) #3
  %1026 = extractelement <2 x double> %1025, i32 0
  %1027 = extractelement <2 x double> %1025, i32 1
  br label %fusion.common2

fusion.side5:                                     ; preds = %decision.dispatch2
  %1028 = insertelement <2 x double> undef, double %919, i32 0
  %1029 = insertelement <2 x double> %1028, double %921, i32 1
  %1030 = insertelement <2 x double> undef, double %924, i32 0
  %1031 = insertelement <2 x double> %1030, double %925, i32 1
  %1032 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1029, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1031) #3
  %1033 = extractelement <2 x double> %1032, i32 0
  %1034 = extractelement <2 x double> %1032, i32 1
  br label %fusion.common2

fusion.common2:                                   ; preds = %fusion.side5, %fusion.side4
  %1035 = phi double [ 0x3FA66506CA3FCEB3, %fusion.side4 ], [ 0x3F964BEF3074CF28, %fusion.side5 ]
  %1036 = phi double [ 0x3F478C82425FFDCE, %fusion.side4 ], [ 0x3F275783E6F9B4DA, %fusion.side5 ]
  %1037 = phi double [ 0x3ED71590B83839D8, %fusion.side4 ], [ 0x3EA6C7746378848A, %fusion.side5 ]
  %1038 = phi double [ 0x3DC001D96C7E2C9D, %fusion.side4 ], [ 0x3D6F4FAB0C90F842, %fusion.side5 ]
  %1039 = phi double [ 0x3E553724D72BE5C7, %fusion.side4 ], [ 0x3E14D76BE5BA042B, %fusion.side5 ]
  %1040 = phi double [ 0x3D0A81E9CB6A1EA5, %fusion.side4 ], [ 0x3CA9D032740CF69A, %fusion.side5 ]
  %1041 = phi double [ 0xC0207852FA1731C0, %fusion.side4 ], [ 0xC024F817DD06EE79, %fusion.side5 ]
  %1042 = phi double [ 0xBFD9F6368DFEFDDF, %fusion.side4 ], [ 0xBFD06A8AF4A3FC55, %fusion.side5 ]
  %1043 = phi double [ 0xBF7F5FDEC6827012, %fusion.side4 ], [ 0xBF63B612102F3C24, %fusion.side5 ]
  %1044 = phi double [ 0xBF1232A95F4E8466, %fusion.side4 ], [ 0xBEE6B9C7BCE39403, %fusion.side5 ]
  %1045 = phi double [ 0xBE94B8A80FB81310, %fusion.side4 ], [ 0xBE59BA2A0439E4A9, %fusion.side5 ]
  %1046 = phi double [ 0x3D5CB3C39661DD79, %fusion.side4 ], [ 0x3D01A287ED1019B8, %fusion.side5 ]
  %1047 = phi double [ 0xBE050B1B8007F8FF, %fusion.side4 ], [ 0xBDB9FC7E20BD04CC, %fusion.side5 ]
  %1048 = phi double [ 0x3C819FA1E5E36C20, %fusion.side4 ], [ 0x3C158FD8B3C1B0C0, %fusion.side5 ]
  %fusion.paired6 = phi double [ %1026, %fusion.side4 ], [ %1033, %fusion.side5 ]
  %fusion.paired7 = phi double [ %1027, %fusion.side4 ], [ %1034, %fusion.side5 ]
  %1049 = fadd double %fusion.paired6, %fusion.paired7
  %1050 = fadd double %923, %1049
  %1051 = fsub double %1050, %923
  %1052 = fsub double %1049, %1051
  %1053 = fadd double %1050, %922
  %1054 = fsub double %1053, %922
  %1055 = fsub double %1054, %1053
  %1056 = fadd double %1055, %922
  %1057 = fsub double %1050, %1054
  %1058 = fadd double %1057, %1056
  %1059 = fadd double %1052, %1058
  %1060 = fadd double %1053, %1059
  %1061 = tail call double @llvm.fabs.f64(double %832) #4
  %1062 = fcmp oeq double %1061, 0x7FF0000000000000
  %1063 = select i1 %1062, double %832, double %1060
  %1064 = fcmp olt double %832, 0.000000e+00
  %1065 = select i1 %1064, double 0x7FF8000000000000, double %1063
  %1066 = fcmp oeq double %832, 0.000000e+00
  %1067 = select i1 %1066, double 0xFFF0000000000000, double %1065
  %1068 = fmul double %1067, %1067
  %1069 = fmul double %1068, %1048
  %1070 = fsub double %1047, %1069
  %1071 = fmul double %1068, %1046
  %1072 = fsub double %1045, %1071
  %1073 = fmul double %1068, %1070
  %1074 = fmul double %1068, %1072
  %1075 = fadd double %1073, %1044
  %1076 = fadd double %1074, %1043
  %1077 = fmul double %1068, %1075
  %1078 = fmul double %1068, %1076
  %1079 = fadd double %1077, %1042
  %1080 = fadd double %1078, %1041
  %1081 = fmul double %1067, %1079
  %1082 = fsub double %1080, %1081
  %1083 = fmul double %1068, %1040
  %1084 = fadd double %1083, %1039
  %1085 = fmul double %1068, %1038
  %1086 = fadd double %1085, %1037
  %1087 = fmul double %1068, %1084
  %1088 = fmul double %1068, %1086
  %1089 = fadd double %1087, %1036
  %1090 = fadd double %1088, %1035
  %1091 = fmul double %1068, %1089
  %1092 = fadd double %1091, 1.000000e+00
  %1093 = fmul double %1067, %1090
  %1094 = fsub double %1092, %1093
  %1095 = fdiv double %1082, %1094
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

fusion.side6:                                     ; preds = %decision.dispatch3
  %1096 = insertelement <2 x double> undef, double %1014, i32 0
  %1097 = insertelement <2 x double> %1096, double %1016, i32 1
  %1098 = insertelement <2 x double> undef, double %1019, i32 0
  %1099 = insertelement <2 x double> %1098, double %1020, i32 1
  %1100 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1097, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1099) #3
  %1101 = extractelement <2 x double> %1100, i32 0
  %1102 = extractelement <2 x double> %1100, i32 1
  br label %fusion.common3

fusion.side7:                                     ; preds = %decision.dispatch3
  %1103 = insertelement <2 x double> undef, double %1014, i32 0
  %1104 = insertelement <2 x double> %1103, double %1016, i32 1
  %1105 = insertelement <2 x double> undef, double %1019, i32 0
  %1106 = insertelement <2 x double> %1105, double %1020, i32 1
  %1107 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1104, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1106) #3
  %1108 = extractelement <2 x double> %1107, i32 0
  %1109 = extractelement <2 x double> %1107, i32 1
  br label %fusion.common3

fusion.common3:                                   ; preds = %fusion.side7, %fusion.side6
  %1110 = phi double [ 0x3F86397D81A61D6E, %fusion.side6 ], [ 0x3F762C8C65771E78, %fusion.side7 ]
  %1111 = phi double [ 0x3F0730EC426E6E84, %fusion.side6 ], [ 0x3EE71602E8EA99F3, %fusion.side7 ]
  %1112 = phi double [ 0x3E768F19E4302EF3, %fusion.side6 ], [ 0x3E46680C94743FD9, %fusion.side7 ]
  %1113 = phi double [ 0x3D1ED0326F0CBDDC, %fusion.side6 ], [ 0x3CCE78F4A7F13C7D, %fusion.side7 ]
  %1114 = phi double [ 0x3DD49301DA58AEFA, %fusion.side6 ], [ 0x3D9463E48A976F97, %fusion.side7 ]
  %1115 = phi double [ 0x3C495387D39D2504, %fusion.side6 ], [ 0x3BE8FEBB5A4047D7, %fusion.side7 ]
  %1116 = phi double [ 0xC02A92BAF87A7B72, %fusion.side6 ], [ 0xC030CB31255FFA09, %fusion.side7 ]
  %1117 = phi double [ 0xBFC4B5F131A679CC, %fusion.side6 ], [ 0xBFBA19EDB555D8AD, %fusion.side7 ]
  %1118 = phi double [ 0xBF48C2CA21FD14A5, %fusion.side6 ], [ 0xBF2F1E266EB4C824, %fusion.side7 ]
  %1119 = phi double [ 0xBEBC6E261AE99633, %fusion.side6 ], [ 0xBE91D0F7FEBA5A35, %fusion.side7 ]
  %1120 = phi double [ 0xBE2007A65CA14E38, %fusion.side6 ], [ 0xBDE40A018263D493, %fusion.side7 ]
  %1121 = phi double [ 0x3CA5D280D4B5A285, %fusion.side6 ], [ 0x3C4B275AC5F91B68, %fusion.side7 ]
  %1122 = phi double [ 0xBD7021DF3392EE60, %fusion.side6 ], [ 0xBD241E51766A91FB, %fusion.side7 ]
  %1123 = phi double [ 0x3BAA9A26E0297ED8, %fusion.side6 ], [ 0x3B408480D3491A50, %fusion.side7 ]
  %fusion.paired8 = phi double [ %1101, %fusion.side6 ], [ %1108, %fusion.side7 ]
  %fusion.paired9 = phi double [ %1102, %fusion.side6 ], [ %1109, %fusion.side7 ]
  %1124 = fadd double %fusion.paired8, %fusion.paired9
  %1125 = fadd double %1018, %1124
  %1126 = fsub double %1125, %1018
  %1127 = fsub double %1124, %1126
  %1128 = fadd double %1125, %1017
  %1129 = fsub double %1128, %1017
  %1130 = fsub double %1129, %1128
  %1131 = fadd double %1130, %1017
  %1132 = fsub double %1125, %1129
  %1133 = fadd double %1132, %1131
  %1134 = fadd double %1127, %1133
  %1135 = fadd double %1128, %1134
  %1136 = tail call double @llvm.fabs.f64(double %927) #4
  %1137 = fcmp oeq double %1136, 0x7FF0000000000000
  %1138 = select i1 %1137, double %927, double %1135
  %1139 = fcmp olt double %927, 0.000000e+00
  %1140 = select i1 %1139, double 0x7FF8000000000000, double %1138
  %1141 = fcmp oeq double %927, 0.000000e+00
  %1142 = select i1 %1141, double 0xFFF0000000000000, double %1140
  %1143 = fmul double %1142, %1142
  %1144 = fmul double %1143, %1123
  %1145 = fsub double %1122, %1144
  %1146 = fmul double %1143, %1121
  %1147 = fsub double %1120, %1146
  %1148 = fmul double %1143, %1145
  %1149 = fmul double %1143, %1147
  %1150 = fadd double %1148, %1119
  %1151 = fadd double %1149, %1118
  %1152 = fmul double %1143, %1150
  %1153 = fmul double %1143, %1151
  %1154 = fadd double %1152, %1117
  %1155 = fadd double %1153, %1116
  %1156 = fmul double %1142, %1154
  %1157 = fsub double %1155, %1156
  %1158 = fmul double %1143, %1115
  %1159 = fadd double %1158, %1114
  %1160 = fmul double %1143, %1113
  %1161 = fadd double %1160, %1112
  %1162 = fmul double %1143, %1159
  %1163 = fmul double %1143, %1161
  %1164 = fadd double %1162, %1111
  %1165 = fadd double %1163, %1110
  %1166 = fmul double %1143, %1164
  %1167 = fadd double %1166, 1.000000e+00
  %1168 = fmul double %1142, %1165
  %1169 = fsub double %1167, %1168
  %1170 = fdiv double %1157, %1169
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i.pair.join: ; preds = %if.then20.i.i.i.i, %if.then11.i.i.i.i
  %retval.0.i.i.i.ph = phi double [ %div26.i.i.i.i, %if.then20.i.i.i.i ], [ %div16.i.i.i.i, %if.then11.i.i.i.i ]
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i: ; preds = %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i.pair.join, %merged.branch.split38, %merged.branch.split, %fusion.common3, %fusion.common2, %if.else93.i.i.i.i, %if.then3.i27.i.i.i, %if.then.i21.i.i.i, %if.end7.i.i.i.i.i.i.i, %if.else71.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, %if.then3.i.i.i.i, %if.then.i.i.i.i
  %retval.0.i.i.i = phi double [ %div.i.i.i.i, %if.then.i.i.i.i ], [ %div8.i.i.i.i, %if.then3.i.i.i.i ], [ %div20.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i ], [ %div34.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i ], [ %div48.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i ], [ %div62.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i ], [ %div70.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i ], [ 0x7FF0000000000000, %if.else71.i.i.i.i ], [ %div80.i.i.i.i, %if.end7.i.i.i.i.i.i.i ], [ %div.i20.i.i.i, %if.then.i21.i.i.i ], [ %div8.i26.i.i.i, %if.then3.i27.i.i.i ], [ 0xFFF0000000000000, %if.else93.i.i.i.i ], [ %1095, %fusion.common2 ], [ %1170, %fusion.common3 ], [ %1261, %merged.branch.split ], [ %1308, %merged.branch.split38 ], [ %retval.0.i.i.i.ph, %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i.pair.join ]
  %add.i.i = fadd double %retval.0.i.i.i, 0.000000e+00
  br label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit

_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit: ; preds = %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, %lor.lhs.false2.i.i.i, %if.end8.i.i
  %retval.0.i.i = phi double [ 0x7FF8000000000000, %if.end8.i.i ], [ 0x7FF8000000000000, %lor.lhs.false2.i.i.i ], [ %add.i.i, %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i ]
  %arrayidx712 = getelementptr inbounds double, double addrspace(1)* %output.coerce, i64 %idxprom
  store double %retval.0.i.i, double addrspace(1)* %arrayidx712, align 8, !tbaa !8
  br label %if.end

if.end:                                           ; preds = %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, %entry
  ret void

merged.bb33:                                      ; preds = %decision.dispatch4
  %1171 = insertelement <2 x double> undef, double %824, i32 0
  %1172 = insertelement <2 x double> %1171, double %826, i32 1
  %1173 = insertelement <2 x double> undef, double %829, i32 0
  %1174 = insertelement <2 x double> %1173, double %830, i32 1
  %1175 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1172, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1174) #3
  %1176 = extractelement <2 x double> %1175, i32 0
  %1177 = extractelement <2 x double> %1175, i32 1
  br label %merged.bb35

merged.bb34:                                      ; preds = %decision.dispatch4
  %1178 = insertelement <2 x double> undef, double %824, i32 0
  %1179 = insertelement <2 x double> %1178, double %826, i32 1
  %1180 = insertelement <2 x double> undef, double %829, i32 0
  %1181 = insertelement <2 x double> %1180, double %830, i32 1
  %1182 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1179, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1181) #3
  %1183 = extractelement <2 x double> %1182, i32 0
  %1184 = extractelement <2 x double> %1182, i32 1
  br label %merged.bb35

merged.bb35:                                      ; preds = %merged.bb34, %merged.bb33
  %1185 = phi double [ %1177, %merged.bb33 ], [ %1184, %merged.bb34 ]
  %1186 = phi double [ %1176, %merged.bb33 ], [ %1183, %merged.bb34 ]
  %1187 = phi double [ 0x3E32022ABCFF5DE7, %merged.bb33 ], [ 0x3DC4C8BD76453064, %merged.bb34 ]
  %1188 = phi double [ 0xBF336C13BBA203F3, %merged.bb33 ], [ 0xBEE755F1646665DB, %merged.bb34 ]
  %1189 = phi double [ 0x3ECBFD524C94F258, %merged.bb33 ], [ 0x3E70731CF2A765F0, %merged.bb34 ]
  %1190 = phi double [ 0xBF81F96D17A7115B, %merged.bb33 ], [ 0xBF4625660A41D7B1, %merged.bb34 ]
  %1191 = phi double [ 0xBFBD7935AC58B5B5, %merged.bb33 ], [ 0xBF92AE2345C460A0, %merged.bb34 ]
  %1192 = phi double [ 0xBFE78F054AC7A90B, %merged.bb33 ], [ 0xBFCED54905311121, %merged.bb34 ]
  %1193 = phi double [ 0xC001F1CD6A03BCAA, %merged.bb33 ], [ 0xBFF8595CA25899FD, %merged.bb34 ]
  %1194 = phi double [ 0xC004C929A952DE48, %merged.bb33 ], [ 0xC00D636ADAEC3C05, %merged.bb34 ]
  %1195 = phi double [ 0x3E9090FBB4B042AE, %merged.bb33 ], [ 0x3E2EB2F3F6504F32, %merged.bb34 ]
  %1196 = phi double [ 0x3F586FC94B9EAD30, %merged.bb33 ], [ 0x3F1751EF5755C229, %merged.bb34 ]
  %1197 = phi double [ 0x3F0330822740ADF9, %merged.bb33 ], [ 0x3EB20E304F6E5BCE, %merged.bb34 ]
  %1198 = phi double [ 0x3F999857B526C821, %merged.bb33 ], [ 0x3F68BF137C253BD1, %merged.bb34 ]
  %1199 = phi double [ 0x3FC92E7DCCD1B70C, %merged.bb33 ], [ 0x3FA8A45F1AE4ADBE, %merged.bb34 ]
  %1200 = phi double [ 0x3FE7235AE26E3A60, %merged.bb33 ], [ 0x3FD6E5B7AB236028, %merged.bb34 ]
  %1201 = phi double [ 0x3D5866A3E6D0F156, %merged.bb33 ], [ 0x3CED1FCD2AD8841F, %merged.bb34 ]
  %1202 = phi double [ 0xBE9C2F1FFD2FFECD, %merged.bb33 ], [ 0xBE512769C01EA7C5, %merged.bb34 ]
  %1203 = phi double [ 0x3E1390C28573DB0F, %merged.bb33 ], [ 0x3DB79116B58241AA, %merged.bb34 ]
  %1204 = phi double [ 0xBF0B3634004E0F5C, %merged.bb33 ], [ 0xBED0C1E92AD969EF, %merged.bb34 ]
  %1205 = phi double [ 0xBF676495E4B7EAAA, %merged.bb33 ], [ 0xBF3D2E78945F9AC6, %merged.bb34 ]
  %1206 = phi double [ 0xBFB3B5B6F694BB9E, %merged.bb33 ], [ 0xBF98ED20B1D6A6D8, %merged.bb34 ]
  %1207 = phi double [ 0xBFEFD66AE54A0BCB, %merged.bb33 ], [ 0xBFE46D859460DB51, %merged.bb34 ]
  %1208 = phi double [ 0xC013B000D66B8269, %merged.bb33 ], [ 0xC019A861C808DCFC, %merged.bb34 ]
  %1209 = phi double [ 0x3DCCD7C812F40049, %merged.bb33 ], [ 0x3D6B7BD497A2CD17, %merged.bb34 ]
  %1210 = phi double [ 0x3ED66AFC954DE682, %merged.bb33 ], [ 0x3E95BA568EDD3BFB, %merged.bb34 ]
  %1211 = phi double [ 0x3E6129D961D79065, %merged.bb33 ], [ 0x3E107ECF99D6009A, %merged.bb34 ]
  %1212 = phi double [ 0x3F380B62C1407B15, %merged.bb33 ], [ 0x3F077F4625619D43, %merged.bb34 ]
  %1213 = phi double [ 0x3F882FD20DA34F30, %merged.bb33 ], [ 0x3F67D3564F778B21, %merged.bb34 ]
  %1214 = phi double [ 0x3FC6B0CE3157BCB1, %merged.bb33 ], [ 0x3FB68627D1A51CB5, %merged.bb34 ]
  br i1 %cmp40.i.i.i.i, label %merged.branch.split, label %merged.branch.split38

merged.branch.split:                              ; preds = %merged.bb35
  %1215 = fadd double %1186, %1185
  %1216 = fadd double %828, %1215
  %1217 = fsub double %1216, %828
  %1218 = fsub double %1215, %1217
  %1219 = fadd double %1216, %827
  %1220 = fsub double %1219, %827
  %1221 = fsub double %1220, %1219
  %1222 = fadd double %1221, %827
  %1223 = fsub double %1216, %1220
  %1224 = fadd double %1223, %1222
  %1225 = fadd double %1218, %1224
  %1226 = fadd double %1219, %1225
  %1227 = tail call double @llvm.fabs.f64(double %737) #4
  %1228 = fcmp oeq double %1227, 0x7FF0000000000000
  %1229 = select i1 %1228, double %737, double %1226
  %1230 = fcmp olt double %737, 0.000000e+00
  %1231 = select i1 %1230, double 0x7FF8000000000000, double %1229
  %1232 = fcmp oeq double %737, 0.000000e+00
  %1233 = select i1 %1232, double 0xFFF0000000000000, double %1231
  %1234 = fmul double %1233, %1233
  %1235 = fmul double %1234, %1187
  %1236 = fsub double %1188, %1235
  %1237 = fmul double %1234, %1189
  %1238 = fsub double %1190, %1237
  %1239 = fmul double %1234, %1236
  %1240 = fmul double %1234, %1238
  %1241 = fadd double %1239, %1191
  %1242 = fadd double %1240, %1192
  %1243 = fmul double %1234, %1241
  %1244 = fmul double %1234, %1242
  %1245 = fadd double %1243, %1193
  %1246 = fadd double %1244, %1194
  %1247 = fmul double %1233, %1245
  %1248 = fsub double %1246, %1247
  %1249 = fmul double %1234, %1195
  %1250 = fadd double %1249, %1196
  %1251 = fmul double %1234, %1197
  %1252 = fadd double %1251, %1198
  %1253 = fmul double %1234, %1250
  %1254 = fmul double %1234, %1252
  %1255 = fadd double %1253, %1199
  %1256 = fadd double %1254, %1200
  %1257 = fmul double %1234, %1255
  %1258 = fadd double %1257, 1.000000e+00
  %1259 = fmul double %1233, %1256
  %1260 = fsub double %1258, %1259
  %1261 = fdiv double %1248, %1260
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

merged.branch.split38:                            ; preds = %merged.bb35
  %1262 = fadd double %1186, %1185
  %1263 = fadd double %828, %1262
  %1264 = fsub double %1263, %828
  %1265 = fsub double %1262, %1264
  %1266 = fadd double %1263, %827
  %1267 = fsub double %1266, %827
  %1268 = fsub double %1267, %1266
  %1269 = fadd double %1268, %827
  %1270 = fsub double %1263, %1267
  %1271 = fadd double %1270, %1269
  %1272 = fadd double %1265, %1271
  %1273 = fadd double %1266, %1272
  %1274 = tail call double @llvm.fabs.f64(double %737) #4
  %1275 = fcmp oeq double %1274, 0x7FF0000000000000
  %1276 = select i1 %1275, double %737, double %1273
  %1277 = fcmp olt double %737, 0.000000e+00
  %1278 = select i1 %1277, double 0x7FF8000000000000, double %1276
  %1279 = fcmp oeq double %737, 0.000000e+00
  %1280 = select i1 %1279, double 0xFFF0000000000000, double %1278
  %1281 = fmul double %1280, %1280
  %1282 = fmul double %1281, %1201
  %1283 = fsub double %1202, %1282
  %1284 = fmul double %1281, %1203
  %1285 = fsub double %1204, %1284
  %1286 = fmul double %1281, %1283
  %1287 = fmul double %1281, %1285
  %1288 = fadd double %1286, %1205
  %1289 = fadd double %1287, %1206
  %1290 = fmul double %1281, %1288
  %1291 = fmul double %1281, %1289
  %1292 = fadd double %1290, %1207
  %1293 = fadd double %1291, %1208
  %1294 = fmul double %1280, %1292
  %1295 = fsub double %1293, %1294
  %1296 = fmul double %1281, %1209
  %1297 = fadd double %1296, %1210
  %1298 = fmul double %1281, %1211
  %1299 = fadd double %1298, %1212
  %1300 = fmul double %1281, %1297
  %1301 = fmul double %1281, %1299
  %1302 = fadd double %1300, %1213
  %1303 = fadd double %1301, %1214
  %1304 = fmul double %1281, %1302
  %1305 = fadd double %1304, 1.000000e+00
  %1306 = fmul double %1280, %1303
  %1307 = fsub double %1305, %1306
  %1308 = fdiv double %1295, %1307
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.frexp.exp.i32.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.frexp.mant.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i1 @llvm.amdgcn.class.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.ldexp.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rcp.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fma.v2f64(<2 x double>, <2 x double>, <2 x double>) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.abs.i32(i32, i1 immarg) #1

attributes #0 = { nofree norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="128" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }
attributes #4 = { nounwind readnone }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/charitha22/cgo22ae-darm-code.git e9bc0540325ad9806313d34e84fc901496fd8be6)"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i16 1, i16 1025}
!6 = !{}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = !{!"evaluate:%if.then11.i.i.i.i", !"evaluate:%if.then20.i.i.i.i"}
!13 = !{!"merge(evaluate:%if.then11.i.i.i.i,evaluate:%if.then20.i.i.i.i)"}
