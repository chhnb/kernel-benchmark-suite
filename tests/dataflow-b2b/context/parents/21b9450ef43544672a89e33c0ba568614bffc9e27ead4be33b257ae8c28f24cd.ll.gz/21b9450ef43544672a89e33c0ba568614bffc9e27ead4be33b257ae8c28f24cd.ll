; ModuleID = '/data/home/chh/kernel-benchmark-suite-dataflow-b2b/build/dataflow-corpus/step10c/final/MapAiry/anchor-unified/trial-109/fused.ll'
source_filename = "/home/chh/kernel-benchmark-suite/cases/boost-mapairy/source/kernel.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

@_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 0x3FE428A2F98D728B, double 0x3FE965FEA53D6E3D, double 1.000000e+00, double 0x3FF428A2F98D728B, double 0x3FF965FEA53D6E3D], align 16

; Function Attrs: nofree norecurse nounwind
define protected amdgpu_kernel void @evaluate(double addrspace(1)* nocapture readonly %input.coerce, double addrspace(1)* nocapture %output.coerce, i32 %n) local_unnamed_addr #0 {
entry:
  %0 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %1 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %2 = getelementptr i8, i8 addrspace(4)* %1, i64 4
  %3 = bitcast i8 addrspace(4)* %2 to i16 addrspace(4)*
  %4 = load i16, i16 addrspace(4)* %3, align 4, !range !5, !invariant.load !6
  %5 = zext i16 %4 to i32
  %6 = mul i32 %0, %5
  %7 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !7
  %add = add i32 %6, %7
  %cmp = icmp slt i32 %add, %n
  br i1 %cmp, label %if.end8.i.i, label %if.end

if.end8.i.i:                                      ; preds = %entry
  %idxprom = sext i32 %add to i64
  %arrayidx11 = getelementptr inbounds double, double addrspace(1)* %input.coerce, i64 %idxprom
  %arrayidx.val = load double, double addrspace(1)* %arrayidx11, align 8, !tbaa !8
  %cmp.i3.i.i = fcmp olt double %arrayidx.val, 0.000000e+00
  %cmp1.i.i.i = fcmp ogt double %arrayidx.val, 1.000000e+00
  %or.cond.i.i.i = or i1 %cmp.i3.i.i, %cmp1.i.i.i
  br i1 %or.cond.i.i.i, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %lor.lhs.false2.i.i.i

lor.lhs.false2.i.i.i:                             ; preds = %if.end8.i.i
  %cmp.i.i.i.i.i = fcmp uno double %arrayidx.val, 0.000000e+00
  %cmp.i3.i.i.i.i = fcmp ogt double %arrayidx.val, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i4.i.i = fcmp olt double %arrayidx.val, 0xFFEFFFFFFFFFFFFF
  %lnot.i.i.i.i.not = or i1 %cmp.i3.i.i.i.i, %cmp1.i.i.i4.i.i
  %brmerge = or i1 %cmp.i.i.i.i.i, %lnot.i.i.i.i.not
  br i1 %brmerge, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %if.end14.i.i

if.end14.i.i:                                     ; preds = %lor.lhs.false2.i.i.i
  %cmp.i.i.i = fcmp ogt double %arrayidx.val, 5.000000e-01
  br i1 %cmp.i.i.i, label %if.then.i.i.i, label %cond.false7.i.i.i

if.then.i.i.i:                                    ; preds = %if.end14.i.i
  %sub.i.i.i = fsub double 1.000000e+00, %arrayidx.val
  %decision.interval = fcmp ult double %sub.i.i.i, 1.250000e-01
  br i1 %decision.interval, label %if.else9.i.i.i.i, label %decision.dispatch2, !decision.condition_prefix !6

decision.dispatch2:                               ; preds = %if.then.i.i.i
  %cmp.i.i.i.i = fcmp oge double %sub.i.i.i, 2.500000e-01
  %8 = select i1 %cmp.i.i.i.i, double -2.500000e-01, double -1.250000e-01
  %9 = fadd double %sub.i.i.i, %8
  %10 = fmul double %9, %9
  %11 = select i1 %cmp.i.i.i.i, double 0x404567B47A5D8CA4, double 0x4051B7FD7FEEB259
  %12 = fmul double %10, %11
  %13 = select i1 %cmp.i.i.i.i, double 0x405E69E51891A050, double 0xC07E56261CB553E9
  %14 = fsub double %13, %12
  br i1 %cmp.i.i.i.i, label %dataflow1, label %dataflow2

if.else9.i.i.i.i:                                 ; preds = %if.then.i.i.i
  %15 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %sub.i.i.i) #3
  %16 = add nsw i32 %15, -1
  %17 = fcmp uno double %sub.i.i.i, 0.000000e+00
  %18 = tail call double @llvm.fabs.f64(double %sub.i.i.i) #4
  %19 = fcmp oeq double %18, 0x7FF0000000000000
  %20 = or i1 %17, %19
  %21 = select i1 %20, i32 2147483647, i32 %16
  %22 = fcmp oeq double %sub.i.i.i, 0.000000e+00
  %23 = select i1 %22, i32 -2147483648, i32 %21
  %cmp11.i.i.i.i = icmp sgt i32 %23, -5
  br i1 %cmp11.i.i.i.i, label %if.then12.i.i.i.i, label %if.else21.i.i.i.i

if.then12.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %24 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 3) #3
  %25 = tail call double @llvm.amdgcn.frexp.mant.f64(double %24) #3
  %26 = fcmp olt double %25, 0x3FE5555555555555
  %27 = zext i1 %26 to i32
  %28 = tail call double @llvm.amdgcn.ldexp.f64(double %25, i32 %27) #3
  %29 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %24) #3
  %30 = sub nsw i32 %29, %27
  %31 = fadd double %28, -1.000000e+00
  %32 = fadd double %28, 1.000000e+00
  %33 = fsub double %32, %28
  %34 = fsub double %32, %33
  %35 = fsub double %28, %34
  %36 = fsub double 1.000000e+00, %33
  %37 = fadd double %36, %35
  %38 = tail call double @llvm.amdgcn.rcp.f64(double %32) #3
  %39 = fneg double %32
  %40 = tail call double @llvm.fma.f64(double %39, double %38, double 1.000000e+00) #3
  %41 = tail call double @llvm.fma.f64(double %40, double %38, double %38) #3
  %42 = tail call double @llvm.fma.f64(double %39, double %41, double 1.000000e+00) #3
  %43 = tail call double @llvm.fma.f64(double %42, double %41, double %41) #3
  %44 = fmul double %31, %43
  %45 = fmul double %32, %44
  %46 = fneg double %45
  %47 = tail call double @llvm.fma.f64(double %44, double %32, double %46) #3
  %48 = tail call double @llvm.fma.f64(double %44, double %37, double %47) #3
  %49 = fadd double %45, %48
  %50 = fsub double %49, %45
  %51 = fsub double %48, %50
  %52 = fsub double %31, %49
  %53 = fsub double %31, %52
  %54 = fsub double %53, %49
  %55 = fsub double %54, %51
  %56 = fadd double %52, %55
  %57 = fmul double %43, %56
  %58 = fadd double %44, %57
  %59 = fsub double %58, %44
  %60 = fsub double %57, %59
  %61 = fmul double %58, %58
  %62 = fneg double %61
  %63 = tail call double @llvm.fma.f64(double %58, double %58, double %62) #3
  %64 = fmul double %60, 2.000000e+00
  %65 = tail call double @llvm.fma.f64(double %58, double %64, double %63) #3
  %66 = tail call double @llvm.fma.f64(double %60, double %60, double %65) #3
  %67 = fadd double %61, %66
  %68 = fsub double %67, %61
  %69 = fsub double %66, %68
  %70 = tail call double @llvm.fma.f64(double %67, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %71 = tail call double @llvm.fma.f64(double %67, double %70, double 0x3FC7474DD7F4DF2E) #3
  %72 = tail call double @llvm.fma.f64(double %67, double %71, double 0x3FCC71C016291751) #3
  %73 = tail call double @llvm.fma.f64(double %67, double %72, double 0x3FD249249B27ACF1) #3
  %74 = tail call double @llvm.fma.f64(double %67, double %73, double 0x3FD99999998EF7B6) #3
  %75 = tail call double @llvm.fma.f64(double %67, double %74, double 0x3FE5555555555780) #3
  %76 = tail call double @llvm.amdgcn.ldexp.f64(double %58, i32 1) #3
  %77 = tail call double @llvm.amdgcn.ldexp.f64(double %60, i32 1) #3
  %78 = fmul double %58, %67
  %79 = fneg double %78
  %80 = tail call double @llvm.fma.f64(double %58, double %67, double %79) #3
  %81 = fmul double %60, %67
  %82 = tail call double @llvm.fma.f64(double %58, double %69, double %81) #3
  %83 = fadd double %80, %82
  %84 = fadd double %78, %83
  %85 = fsub double %84, %78
  %86 = fsub double %83, %85
  %87 = fmul double %84, %75
  %88 = fneg double %87
  %89 = tail call double @llvm.fma.f64(double %84, double %75, double %88) #3
  %90 = tail call double @llvm.fma.f64(double %86, double %75, double %89) #3
  %91 = fadd double %87, %90
  %92 = fsub double %91, %87
  %93 = fsub double %90, %92
  %94 = fadd double %76, %91
  %95 = fsub double %94, %76
  %96 = fsub double %94, %95
  %97 = fsub double %76, %96
  %98 = fsub double %91, %95
  %99 = fadd double %98, %97
  %100 = fadd double %77, %93
  %101 = fsub double %100, %77
  %102 = fsub double %100, %101
  %103 = fsub double %77, %102
  %104 = fsub double %93, %101
  %105 = fadd double %104, %103
  %106 = fadd double %100, %99
  %107 = fadd double %94, %106
  %108 = fsub double %107, %94
  %109 = fsub double %106, %108
  %110 = fadd double %105, %109
  %111 = fadd double %107, %110
  %112 = fsub double %111, %107
  %113 = fsub double %110, %112
  %114 = sitofp i32 %30 to double
  %115 = fmul double %111, 0x3FF71547652B82FE
  %116 = fneg double %115
  %117 = fmul double %111, 0x3C7777D0FFDA0D24
  %118 = insertelement <2 x double> undef, double %111, i32 0
  %119 = insertelement <2 x double> %118, double %113, i32 1
  %120 = insertelement <2 x double> undef, double %116, i32 0
  %121 = insertelement <2 x double> %120, double %117, i32 1
  %122 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %119, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %121) #3
  %123 = extractelement <2 x double> %122, i32 0
  %124 = extractelement <2 x double> %122, i32 1
  %125 = fadd double %123, %124
  %126 = fadd double %115, %125
  %127 = fsub double %126, %115
  %128 = fsub double %125, %127
  %129 = fadd double %126, %114
  %130 = fsub double %129, %114
  %131 = fsub double %130, %129
  %132 = fadd double %131, %114
  %133 = fsub double %126, %130
  %134 = fadd double %133, %132
  %135 = fadd double %128, %134
  %136 = fadd double %129, %135
  %137 = tail call double @llvm.fabs.f64(double %24) #4
  %138 = fcmp oeq double %137, 0x7FF0000000000000
  %139 = select i1 %138, double %24, double %136
  %140 = fcmp olt double %24, 0.000000e+00
  %141 = select i1 %140, double 0x7FF8000000000000, double %139
  %142 = fcmp oeq double %24, 0.000000e+00
  %143 = select i1 %142, double 0xFFF0000000000000, double %141
  %mul.i.i682.i.i.i.i = fmul double %143, %143
  %mul1.i.i683.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3ED3E1F985CBB733
  %add.i.i684.i.i.i.i = fadd double %mul1.i.i683.i.i.i.i, 0x3F385DA443F57737
  %mul5.i.i685.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F24E9382EAABDBB
  %add7.i.i686.i.i.i.i = fadd double %mul5.i.i685.i.i.i.i, 0x3F77E2A342AA4E3B
  %mul10.i.i687.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i684.i.i.i.i
  %mul12.i.i688.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i686.i.i.i.i
  %add15.i.i689.i.i.i.i = fadd double %mul10.i.i687.i.i.i.i, 0x3F9808F2B640E69B
  %add18.i.i690.i.i.i.i = fadd double %mul12.i.i688.i.i.i.i, 0x3F9DD5C523A6CF6D
  %mul20.i.i691.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i689.i.i.i.i
  %mul22.i.i692.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i690.i.i.i.i
  %add25.i.i693.i.i.i.i = fadd double %mul20.i.i691.i.i.i.i, 0x3FD3E6D375851610
  %add28.i.i694.i.i.i.i = fadd double %mul22.i.i692.i.i.i.i, 0x3FDB3E8B8B7EC8FA
  %144 = fmul double %143, %add25.i.i693.i.i.i.i
  %add33.i.i696.i.i.i.i = fsub double %add28.i.i694.i.i.i.i, %144
  %mul1.i.i668.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3EF03AD80F271435
  %add.i.i669.i.i.i.i = fadd double %mul1.i.i668.i.i.i.i, 0x3F577B23357A1929
  %mul5.i.i670.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F27C5B13F4BAFF2
  %add7.i.i671.i.i.i.i = fadd double %mul5.i.i670.i.i.i.i, 0x3F825620F70E4E86
  %mul10.i.i672.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i669.i.i.i.i
  %mul12.i.i673.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i671.i.i.i.i
  %add15.i.i674.i.i.i.i = fadd double %mul10.i.i672.i.i.i.i, 0x3FA38976FFA62DF3
  %add18.i.i675.i.i.i.i = fadd double %mul12.i.i673.i.i.i.i, 0x3FBACD3553111974
  %mul20.i.i676.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i674.i.i.i.i
  %mul22.i.i677.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i675.i.i.i.i
  %add25.i.i678.i.i.i.i = fadd double %mul20.i.i676.i.i.i.i, 0x3FDA8C1A7A09CF75
  %add28.i.i679.i.i.i.i = fadd double %mul22.i.i677.i.i.i.i, 1.000000e+00
  %145 = fmul double %143, %add25.i.i678.i.i.i.i
  %add33.i.i681.i.i.i.i = fsub double %add28.i.i679.i.i.i.i, %145
  %mul.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i590.i.i.i.i = fcmp ogt double %mul.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i591.i.i.i.i = fcmp oeq double %mul.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i592.i.i.i.i = or i1 %cmp.i.i.i.i590.i.i.i.i, %cmp.i.i.i591.i.i.i.i
  br i1 %or.cond.i.i.i592.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end.i.i.i594.i.i.i.i

if.end.i.i.i594.i.i.i.i:                          ; preds = %if.then12.i.i.i.i
  %cmp.i.i.i.i.i593.i.i.i.i = fcmp uno double %mul.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i593.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end7.i.i.i620.i.i.i.i

if.end7.i.i.i620.i.i.i.i:                         ; preds = %if.end.i.i.i594.i.i.i.i
  %146 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul.i.i.i.i) #3
  %147 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul.i.i.i.i) #3
  %148 = tail call i1 @llvm.amdgcn.class.f64(double %mul.i.i.i.i, i32 519) #3
  %149 = select i1 %148, i32 0, i32 %146
  %150 = select i1 %148, double %mul.i.i.i.i, double %147
  %mul.i.i.i.i.i606.i.i.i.i = fmul double %150, %150
  %mul1.i.i.i.i.i607.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i608.i.i.i.i = fadd double %mul1.i.i.i.i.i607.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i609.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FE479D17050CA47
  %151 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i609.i.i.i.i
  %mul10.i.i.i.i.i611.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %add.i.i.i.i.i608.i.i.i.i
  %mul12.i.i.i.i.i612.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %151
  %add15.i.i.i.i.i613.i.i.i.i = fadd double %mul10.i.i.i.i.i611.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i614.i.i.i.i = fadd double %mul12.i.i.i.i.i612.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i615.i.i.i.i = fmul double %150, %add15.i.i.i.i.i613.i.i.i.i
  %add23.i.i.i.i.i616.i.i.i.i = fadd double %add18.i.i.i.i.i614.i.i.i.i, %mul20.i.i.i.i.i615.i.i.i.i
  %.frozen = freeze i32 %149
  %div.i.i.i617.i.i.i.i = sdiv i32 %.frozen, 3
  %152 = sub nsw i32 0, %div.i.i.i617.i.i.i.i
  %153 = call i32 @llvm.abs.i32(i32 %div.i.i.i617.i.i.i.i, i1 true)
  %cmp11.i.i.i619.i.i.i.i = icmp ult i32 %153, 64
  br i1 %cmp11.i.i.i619.i.i.i.i, label %if.then12.i.i.i622.i.i.i.i, label %if.else21.i.i.i634.i.i.i.i

if.then12.i.i.i622.i.i.i.i:                       ; preds = %if.end7.i.i.i620.i.i.i.i
  %cmp13.i.i.i621.i.i.i.i = icmp sgt i32 %149, 2
  br i1 %cmp13.i.i.i621.i.i.i.i, label %if.then14.i.i.i627.i.i.i.i, label %if.else.i.i.i633.i.i.i.i

if.then14.i.i.i627.i.i.i.i:                       ; preds = %if.then12.i.i.i622.i.i.i.i
  %sh_prom.i.i.i623.i.i.i.i = zext i32 %div.i.i.i617.i.i.i.i to i64
  %shl.i.i.i624.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i623.i.i.i.i
  %conv.i.i.i625.i.i.i.i = uitofp i64 %shl.i.i.i624.i.i.i.i to double
  %mul.i.i.i626.i.i.i.i = fmul double %add23.i.i.i.i.i616.i.i.i.i, %conv.i.i.i625.i.i.i.i
  br label %if.end23.i.i.i640.i.i.i.i

if.else.i.i.i633.i.i.i.i:                         ; preds = %if.then12.i.i.i622.i.i.i.i
  %sh_prom16.i.i.i629.i.i.i.i = zext i32 %152 to i64
  %shl17.i.i.i630.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i629.i.i.i.i
  %conv18.i.i.i631.i.i.i.i = uitofp i64 %shl17.i.i.i630.i.i.i.i to double
  %div19.i.i.i632.i.i.i.i = fdiv double %add23.i.i.i.i.i616.i.i.i.i, %conv18.i.i.i631.i.i.i.i
  br label %if.end23.i.i.i640.i.i.i.i

if.else21.i.i.i634.i.i.i.i:                       ; preds = %if.end7.i.i.i620.i.i.i.i
  %154 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i616.i.i.i.i, i32 %div.i.i.i617.i.i.i.i) #3
  br label %if.end23.i.i.i640.i.i.i.i

if.end23.i.i.i640.i.i.i.i:                        ; preds = %if.else21.i.i.i634.i.i.i.i, %if.else.i.i.i633.i.i.i.i, %if.then14.i.i.i627.i.i.i.i
  %guess.i.i.i589.i.i.i.i.0 = phi double [ %mul.i.i.i626.i.i.i.i, %if.then14.i.i.i627.i.i.i.i ], [ %div19.i.i.i632.i.i.i.i, %if.else.i.i.i633.i.i.i.i ], [ %154, %if.else21.i.i.i634.i.i.i.i ]
  %.neg6 = mul nsw i32 %div.i.i.i617.i.i.i.i, -3
  %rem.i.i.i635.i.i.i.i.decomposed = add i32 %.frozen, 2
  %add.i.i.i636.i.i.i.i = add i32 %rem.i.i.i635.i.i.i.i.decomposed, %.neg6
  %155 = zext i32 %add.i.i.i636.i.i.i.i to i64
  %arrayidx1.i.i.i637.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %155
  %156 = load double, double addrspace(4)* %arrayidx1.i.i.i637.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i638.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.0, %156
  %cmp26.i.i.i639.i.i.i.i = icmp slt i32 %149, 1021
  br i1 %cmp26.i.i.i639.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i

do.body.i.i.i651.i.i.i.i:                         ; preds = %do.body.i.i.i651.i.i.i.i, %if.end23.i.i.i640.i.i.i.i
  %guess.i.i.i589.i.i.i.i.1 = phi double [ %mul24.i.i.i638.i.i.i.i, %if.end23.i.i.i640.i.i.i.i ], [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ]
  %mul28.i.i.i641.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %guess.i.i.i589.i.i.i.i.1
  %mul29.i.i.i642.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %mul28.i.i.i641.i.i.i.i
  %add30.i.i.i643.i.i.i.i = fadd double %mul.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add31.i.i.i644.i.i.i.i = fadd double %mul.i.i.i.i, %add30.i.i.i643.i.i.i.i
  %add32.i.i.i645.i.i.i.i = fadd double %mul29.i.i.i642.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add33.i.i.i646.i.i.i.i = fadd double %mul.i.i.i.i, %add32.i.i.i645.i.i.i.i
  %div34.i.i.i647.i.i.i.i = fdiv double %add31.i.i.i644.i.i.i.i, %add33.i.i.i646.i.i.i.i
  %mul35.i.i.i648.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %div34.i.i.i647.i.i.i.i
  %sub36.i.i.i649.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i647.i.i.i.i
  %157 = tail call double @llvm.fabs.f64(double %sub36.i.i.i649.i.i.i.i) #3
  %cmp38.i.i.i650.i.i.i.i = fcmp ogt double %157, 0x3EC0000000000000
  br i1 %cmp38.i.i.i650.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

do.body40.i.i.i662.i.i.i.i:                       ; preds = %do.body40.i.i.i662.i.i.i.i, %if.end23.i.i.i640.i.i.i.i
  %guess.i.i.i589.i.i.i.i.2 = phi double [ %mul24.i.i.i638.i.i.i.i, %if.end23.i.i.i640.i.i.i.i ], [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ]
  %mul41.i.i.i652.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, %guess.i.i.i589.i.i.i.i.2
  %div42.i.i.i653.i.i.i.i = fdiv double %mul.i.i.i.i, %guess.i.i.i589.i.i.i.i.2
  %sub43.i.i.i654.i.i.i.i = fsub double %mul41.i.i.i652.i.i.i.i, %div42.i.i.i653.i.i.i.i
  %mul44.i.i.i655.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i656.i.i.i.i = fdiv double %mul.i.i.i.i, %mul41.i.i.i652.i.i.i.i
  %add46.i.i.i657.i.i.i.i = fadd double %mul44.i.i.i655.i.i.i.i, %div45.i.i.i656.i.i.i.i
  %div47.i.i.i658.i.i.i.i = fdiv double %sub43.i.i.i654.i.i.i.i, %add46.i.i.i657.i.i.i.i
  %sub48.i.i.i659.i.i.i.i = fsub double %guess.i.i.i589.i.i.i.i.2, %div47.i.i.i658.i.i.i.i
  %mul50.i.i.i660.i.i.i.i = fmul double %sub48.i.i.i659.i.i.i.i, 0x3EC0000000000000
  %158 = tail call double @llvm.fabs.f64(double %div47.i.i.i658.i.i.i.i) #3
  %cmp52.i.i.i661.i.i.i.i = fcmp olt double %mul50.i.i.i660.i.i.i.i, %158
  br i1 %cmp52.i.i.i661.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i: ; preds = %do.body40.i.i.i662.i.i.i.i, %do.body.i.i.i651.i.i.i.i, %if.end.i.i.i594.i.i.i.i, %if.then12.i.i.i.i
  %retval.0.i.i.i665.i.i.i.i = phi double [ %mul.i.i.i.i, %if.then12.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i594.i.i.i.i ], [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ], [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ]
  %mul19.i.i.i.i = fmul double %add33.i.i681.i.i.i.i, %retval.0.i.i.i665.i.i.i.i
  %div20.i.i.i.i = fdiv double %add33.i.i696.i.i.i.i, %mul19.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else21.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %cmp23.i.i.i.i = icmp sgt i32 %23, -9
  br i1 %cmp23.i.i.i.i, label %if.then24.i.i.i.i, label %if.else35.i.i.i.i

if.then24.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %159 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 4) #3
  %160 = tail call double @llvm.amdgcn.frexp.mant.f64(double %159) #3
  %161 = fcmp olt double %160, 0x3FE5555555555555
  %162 = zext i1 %161 to i32
  %163 = tail call double @llvm.amdgcn.ldexp.f64(double %160, i32 %162) #3
  %164 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %159) #3
  %165 = sub nsw i32 %164, %162
  %166 = fadd double %163, -1.000000e+00
  %167 = fadd double %163, 1.000000e+00
  %168 = fsub double %167, %163
  %169 = fsub double %167, %168
  %170 = fsub double %163, %169
  %171 = fsub double 1.000000e+00, %168
  %172 = fadd double %171, %170
  %173 = tail call double @llvm.amdgcn.rcp.f64(double %167) #3
  %174 = fneg double %167
  %175 = tail call double @llvm.fma.f64(double %174, double %173, double 1.000000e+00) #3
  %176 = tail call double @llvm.fma.f64(double %175, double %173, double %173) #3
  %177 = tail call double @llvm.fma.f64(double %174, double %176, double 1.000000e+00) #3
  %178 = tail call double @llvm.fma.f64(double %177, double %176, double %176) #3
  %179 = fmul double %166, %178
  %180 = fmul double %167, %179
  %181 = fneg double %180
  %182 = tail call double @llvm.fma.f64(double %179, double %167, double %181) #3
  %183 = tail call double @llvm.fma.f64(double %179, double %172, double %182) #3
  %184 = fadd double %180, %183
  %185 = fsub double %184, %180
  %186 = fsub double %183, %185
  %187 = fsub double %166, %184
  %188 = fsub double %166, %187
  %189 = fsub double %188, %184
  %190 = fsub double %189, %186
  %191 = fadd double %187, %190
  %192 = fmul double %178, %191
  %193 = fadd double %179, %192
  %194 = fsub double %193, %179
  %195 = fsub double %192, %194
  %196 = fmul double %193, %193
  %197 = fneg double %196
  %198 = tail call double @llvm.fma.f64(double %193, double %193, double %197) #3
  %199 = fmul double %195, 2.000000e+00
  %200 = tail call double @llvm.fma.f64(double %193, double %199, double %198) #3
  %201 = tail call double @llvm.fma.f64(double %195, double %195, double %200) #3
  %202 = fadd double %196, %201
  %203 = fsub double %202, %196
  %204 = fsub double %201, %203
  %205 = tail call double @llvm.fma.f64(double %202, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %206 = tail call double @llvm.fma.f64(double %202, double %205, double 0x3FC7474DD7F4DF2E) #3
  %207 = tail call double @llvm.fma.f64(double %202, double %206, double 0x3FCC71C016291751) #3
  %208 = tail call double @llvm.fma.f64(double %202, double %207, double 0x3FD249249B27ACF1) #3
  %209 = tail call double @llvm.fma.f64(double %202, double %208, double 0x3FD99999998EF7B6) #3
  %210 = tail call double @llvm.fma.f64(double %202, double %209, double 0x3FE5555555555780) #3
  %211 = tail call double @llvm.amdgcn.ldexp.f64(double %193, i32 1) #3
  %212 = tail call double @llvm.amdgcn.ldexp.f64(double %195, i32 1) #3
  %213 = fmul double %193, %202
  %214 = fneg double %213
  %215 = tail call double @llvm.fma.f64(double %193, double %202, double %214) #3
  %216 = fmul double %195, %202
  %217 = tail call double @llvm.fma.f64(double %193, double %204, double %216) #3
  %218 = fadd double %215, %217
  %219 = fadd double %213, %218
  %220 = fsub double %219, %213
  %221 = fsub double %218, %220
  %222 = fmul double %219, %210
  %223 = fneg double %222
  %224 = tail call double @llvm.fma.f64(double %219, double %210, double %223) #3
  %225 = tail call double @llvm.fma.f64(double %221, double %210, double %224) #3
  %226 = fadd double %222, %225
  %227 = fsub double %226, %222
  %228 = fsub double %225, %227
  %229 = fadd double %211, %226
  %230 = fsub double %229, %211
  %231 = fsub double %229, %230
  %232 = fsub double %211, %231
  %233 = fsub double %226, %230
  %234 = fadd double %233, %232
  %235 = fadd double %212, %228
  %236 = fsub double %235, %212
  %237 = fsub double %235, %236
  %238 = fsub double %212, %237
  %239 = fsub double %228, %236
  %240 = fadd double %239, %238
  %241 = fadd double %235, %234
  %242 = fadd double %229, %241
  %243 = fsub double %242, %229
  %244 = fsub double %241, %243
  %245 = fadd double %240, %244
  %246 = fadd double %242, %245
  %247 = fsub double %246, %242
  %248 = fsub double %245, %247
  %249 = sitofp i32 %165 to double
  %250 = fmul double %246, 0x3FF71547652B82FE
  %251 = fneg double %250
  %252 = fmul double %246, 0x3C7777D0FFDA0D24
  %253 = insertelement <2 x double> undef, double %246, i32 0
  %254 = insertelement <2 x double> %253, double %248, i32 1
  %255 = insertelement <2 x double> undef, double %251, i32 0
  %256 = insertelement <2 x double> %255, double %252, i32 1
  %257 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %254, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %256) #3
  %258 = extractelement <2 x double> %257, i32 0
  %259 = extractelement <2 x double> %257, i32 1
  %260 = fadd double %258, %259
  %261 = fadd double %250, %260
  %262 = fsub double %261, %250
  %263 = fsub double %260, %262
  %264 = fadd double %261, %249
  %265 = fsub double %264, %249
  %266 = fsub double %265, %264
  %267 = fadd double %266, %249
  %268 = fsub double %261, %265
  %269 = fadd double %268, %267
  %270 = fadd double %263, %269
  %271 = fadd double %264, %270
  %272 = tail call double @llvm.fabs.f64(double %159) #4
  %273 = fcmp oeq double %272, 0x7FF0000000000000
  %274 = select i1 %273, double %159, double %271
  %275 = fcmp olt double %159, 0.000000e+00
  %276 = select i1 %275, double 0x7FF8000000000000, double %274
  %277 = fcmp oeq double %159, 0.000000e+00
  %278 = select i1 %277, double 0xFFF0000000000000, double %276
  %mul.i.i565.i.i.i.i = fmul double %278, %278
  %mul1.i.i566.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3E919A5BE1262808
  %add.i.i567.i.i.i.i = fadd double %mul1.i.i566.i.i.i.i, 0x3F07A5175B4661FC
  %mul5.i.i568.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3ED3058F91E15D9E
  %add7.i.i569.i.i.i.i = fadd double %mul5.i.i568.i.i.i.i, 0x3F360A6A52B6CEE1
  %mul10.i.i570.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i567.i.i.i.i
  %mul12.i.i571.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i569.i.i.i.i
  %add15.i.i572.i.i.i.i = fadd double %mul10.i.i570.i.i.i.i, 0x3F5C5B8FA36BAEC3
  %add18.i.i573.i.i.i.i = fadd double %mul12.i.i571.i.i.i.i, 0x3F80EDCAE3A5BFEE
  %mul20.i.i574.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i572.i.i.i.i
  %mul22.i.i575.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i573.i.i.i.i
  %add25.i.i576.i.i.i.i = fadd double %mul20.i.i574.i.i.i.i, 0x3F9A5E78F653B833
  %add28.i.i577.i.i.i.i = fadd double %mul22.i.i575.i.i.i.i, 0x3FB5AC2080A26513
  %mul30.i.i578.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i576.i.i.i.i
  %mul32.i.i579.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i577.i.i.i.i
  %add35.i.i580.i.i.i.i = fadd double %mul30.i.i578.i.i.i.i, 0x3FC65686F7A4EE22
  %add38.i.i581.i.i.i.i = fadd double %mul32.i.i579.i.i.i.i, 0x3FD3F40EF6582604
  %mul40.i.i582.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i580.i.i.i.i
  %add43.i.i583.i.i.i.i = fadd double %mul40.i.i582.i.i.i.i, 0x3FE03C236600AD0B
  %279 = fmul double %278, %add38.i.i581.i.i.i.i
  %add48.i.i585.i.i.i.i = fsub double %add43.i.i583.i.i.i.i, %279
  %mul1.i.i547.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EA0457562E8B20F
  %add.i.i548.i.i.i.i = fadd double %mul1.i.i547.i.i.i.i, 0x3F16154BBE28AEB9
  %mul5.i.i549.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EE174949F46ED05
  %add7.i.i550.i.i.i.i = fadd double %mul5.i.i549.i.i.i.i, 0x3F43E3B25F7FFBED
  %mul10.i.i551.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i548.i.i.i.i
  %mul12.i.i552.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i550.i.i.i.i
  %add15.i.i553.i.i.i.i = fadd double %mul10.i.i551.i.i.i.i, 0x3F6B2284D418EE28
  %add18.i.i554.i.i.i.i = fadd double %mul12.i.i552.i.i.i.i, 0x3F8DC663E91E38DD
  %mul20.i.i555.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i553.i.i.i.i
  %mul22.i.i556.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i554.i.i.i.i
  %add25.i.i557.i.i.i.i = fadd double %mul20.i.i555.i.i.i.i, 0x3FA9F261B3019817
  %add28.i.i558.i.i.i.i = fadd double %mul22.i.i556.i.i.i.i, 0x3FC29CC24A62017B
  %mul30.i.i559.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i557.i.i.i.i
  %mul32.i.i560.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i558.i.i.i.i
  %add35.i.i561.i.i.i.i = fadd double %mul30.i.i559.i.i.i.i, 0x3FD660DD0F65AD11
  %add38.i.i562.i.i.i.i = fadd double %mul32.i.i560.i.i.i.i, 0x3FE0E738E979F959
  %mul40.i.i563.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i561.i.i.i.i
  %add43.i.i564.i.i.i.i = fadd double %mul40.i.i563.i.i.i.i, 1.000000e+00
  %280 = fmul double %278, %add38.i.i562.i.i.i.i
  %add48.i.i.i.i.i.i = fsub double %add43.i.i564.i.i.i.i, %280
  %mul31.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i469.i.i.i.i = fcmp ogt double %mul31.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i470.i.i.i.i = fcmp oeq double %mul31.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i471.i.i.i.i = or i1 %cmp.i.i.i.i469.i.i.i.i, %cmp.i.i.i470.i.i.i.i
  br i1 %or.cond.i.i.i471.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end.i.i.i473.i.i.i.i

if.end.i.i.i473.i.i.i.i:                          ; preds = %if.then24.i.i.i.i
  %cmp.i.i.i.i.i472.i.i.i.i = fcmp uno double %mul31.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i472.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end7.i.i.i499.i.i.i.i

if.end7.i.i.i499.i.i.i.i:                         ; preds = %if.end.i.i.i473.i.i.i.i
  %281 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul31.i.i.i.i) #3
  %282 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul31.i.i.i.i) #3
  %283 = tail call i1 @llvm.amdgcn.class.f64(double %mul31.i.i.i.i, i32 519) #3
  %284 = select i1 %283, i32 0, i32 %281
  %285 = select i1 %283, double %mul31.i.i.i.i, double %282
  %mul.i.i.i.i.i485.i.i.i.i = fmul double %285, %285
  %mul1.i.i.i.i.i486.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i487.i.i.i.i = fadd double %mul1.i.i.i.i.i486.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i488.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FE479D17050CA47
  %286 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i488.i.i.i.i
  %mul10.i.i.i.i.i490.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %add.i.i.i.i.i487.i.i.i.i
  %mul12.i.i.i.i.i491.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %286
  %add15.i.i.i.i.i492.i.i.i.i = fadd double %mul10.i.i.i.i.i490.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i493.i.i.i.i = fadd double %mul12.i.i.i.i.i491.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i494.i.i.i.i = fmul double %285, %add15.i.i.i.i.i492.i.i.i.i
  %add23.i.i.i.i.i495.i.i.i.i = fadd double %add18.i.i.i.i.i493.i.i.i.i, %mul20.i.i.i.i.i494.i.i.i.i
  %.frozen209 = freeze i32 %284
  %div.i.i.i496.i.i.i.i = sdiv i32 %.frozen209, 3
  %287 = sub nsw i32 0, %div.i.i.i496.i.i.i.i
  %288 = call i32 @llvm.abs.i32(i32 %div.i.i.i496.i.i.i.i, i1 true)
  %cmp11.i.i.i498.i.i.i.i = icmp ult i32 %288, 64
  br i1 %cmp11.i.i.i498.i.i.i.i, label %if.then12.i.i.i501.i.i.i.i, label %if.else21.i.i.i513.i.i.i.i

if.then12.i.i.i501.i.i.i.i:                       ; preds = %if.end7.i.i.i499.i.i.i.i
  %cmp13.i.i.i500.i.i.i.i = icmp sgt i32 %284, 2
  br i1 %cmp13.i.i.i500.i.i.i.i, label %if.then14.i.i.i506.i.i.i.i, label %if.else.i.i.i512.i.i.i.i

if.then14.i.i.i506.i.i.i.i:                       ; preds = %if.then12.i.i.i501.i.i.i.i
  %sh_prom.i.i.i502.i.i.i.i = zext i32 %div.i.i.i496.i.i.i.i to i64
  %shl.i.i.i503.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i502.i.i.i.i
  %conv.i.i.i504.i.i.i.i = uitofp i64 %shl.i.i.i503.i.i.i.i to double
  %mul.i.i.i505.i.i.i.i = fmul double %add23.i.i.i.i.i495.i.i.i.i, %conv.i.i.i504.i.i.i.i
  br label %if.end23.i.i.i519.i.i.i.i

if.else.i.i.i512.i.i.i.i:                         ; preds = %if.then12.i.i.i501.i.i.i.i
  %sh_prom16.i.i.i508.i.i.i.i = zext i32 %287 to i64
  %shl17.i.i.i509.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i508.i.i.i.i
  %conv18.i.i.i510.i.i.i.i = uitofp i64 %shl17.i.i.i509.i.i.i.i to double
  %div19.i.i.i511.i.i.i.i = fdiv double %add23.i.i.i.i.i495.i.i.i.i, %conv18.i.i.i510.i.i.i.i
  br label %if.end23.i.i.i519.i.i.i.i

if.else21.i.i.i513.i.i.i.i:                       ; preds = %if.end7.i.i.i499.i.i.i.i
  %289 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i495.i.i.i.i, i32 %div.i.i.i496.i.i.i.i) #3
  br label %if.end23.i.i.i519.i.i.i.i

if.end23.i.i.i519.i.i.i.i:                        ; preds = %if.else21.i.i.i513.i.i.i.i, %if.else.i.i.i512.i.i.i.i, %if.then14.i.i.i506.i.i.i.i
  %guess.i.i.i468.i.i.i.i.0 = phi double [ %mul.i.i.i505.i.i.i.i, %if.then14.i.i.i506.i.i.i.i ], [ %div19.i.i.i511.i.i.i.i, %if.else.i.i.i512.i.i.i.i ], [ %289, %if.else21.i.i.i513.i.i.i.i ]
  %.neg5 = mul nsw i32 %div.i.i.i496.i.i.i.i, -3
  %rem.i.i.i514.i.i.i.i.decomposed = add i32 %.frozen209, 2
  %add.i.i.i515.i.i.i.i = add i32 %rem.i.i.i514.i.i.i.i.decomposed, %.neg5
  %290 = zext i32 %add.i.i.i515.i.i.i.i to i64
  %arrayidx1.i.i.i516.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %290
  %291 = load double, double addrspace(4)* %arrayidx1.i.i.i516.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i517.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.0, %291
  %cmp26.i.i.i518.i.i.i.i = icmp slt i32 %284, 1021
  br i1 %cmp26.i.i.i518.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i

do.body.i.i.i530.i.i.i.i:                         ; preds = %do.body.i.i.i530.i.i.i.i, %if.end23.i.i.i519.i.i.i.i
  %guess.i.i.i468.i.i.i.i.1 = phi double [ %mul24.i.i.i517.i.i.i.i, %if.end23.i.i.i519.i.i.i.i ], [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ]
  %mul28.i.i.i520.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %guess.i.i.i468.i.i.i.i.1
  %mul29.i.i.i521.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %mul28.i.i.i520.i.i.i.i
  %add30.i.i.i522.i.i.i.i = fadd double %mul31.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add31.i.i.i523.i.i.i.i = fadd double %mul31.i.i.i.i, %add30.i.i.i522.i.i.i.i
  %add32.i.i.i524.i.i.i.i = fadd double %mul29.i.i.i521.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add33.i.i.i525.i.i.i.i = fadd double %mul31.i.i.i.i, %add32.i.i.i524.i.i.i.i
  %div34.i.i.i526.i.i.i.i = fdiv double %add31.i.i.i523.i.i.i.i, %add33.i.i.i525.i.i.i.i
  %mul35.i.i.i527.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %div34.i.i.i526.i.i.i.i
  %sub36.i.i.i528.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i526.i.i.i.i
  %292 = tail call double @llvm.fabs.f64(double %sub36.i.i.i528.i.i.i.i) #3
  %cmp38.i.i.i529.i.i.i.i = fcmp ogt double %292, 0x3EC0000000000000
  br i1 %cmp38.i.i.i529.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

do.body40.i.i.i541.i.i.i.i:                       ; preds = %do.body40.i.i.i541.i.i.i.i, %if.end23.i.i.i519.i.i.i.i
  %guess.i.i.i468.i.i.i.i.2 = phi double [ %mul24.i.i.i517.i.i.i.i, %if.end23.i.i.i519.i.i.i.i ], [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ]
  %mul41.i.i.i531.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, %guess.i.i.i468.i.i.i.i.2
  %div42.i.i.i532.i.i.i.i = fdiv double %mul31.i.i.i.i, %guess.i.i.i468.i.i.i.i.2
  %sub43.i.i.i533.i.i.i.i = fsub double %mul41.i.i.i531.i.i.i.i, %div42.i.i.i532.i.i.i.i
  %mul44.i.i.i534.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i535.i.i.i.i = fdiv double %mul31.i.i.i.i, %mul41.i.i.i531.i.i.i.i
  %add46.i.i.i536.i.i.i.i = fadd double %mul44.i.i.i534.i.i.i.i, %div45.i.i.i535.i.i.i.i
  %div47.i.i.i537.i.i.i.i = fdiv double %sub43.i.i.i533.i.i.i.i, %add46.i.i.i536.i.i.i.i
  %sub48.i.i.i538.i.i.i.i = fsub double %guess.i.i.i468.i.i.i.i.2, %div47.i.i.i537.i.i.i.i
  %mul50.i.i.i539.i.i.i.i = fmul double %sub48.i.i.i538.i.i.i.i, 0x3EC0000000000000
  %293 = tail call double @llvm.fabs.f64(double %div47.i.i.i537.i.i.i.i) #3
  %cmp52.i.i.i540.i.i.i.i = fcmp olt double %mul50.i.i.i539.i.i.i.i, %293
  br i1 %cmp52.i.i.i540.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i: ; preds = %do.body40.i.i.i541.i.i.i.i, %do.body.i.i.i530.i.i.i.i, %if.end.i.i.i473.i.i.i.i, %if.then24.i.i.i.i
  %retval.0.i.i.i544.i.i.i.i = phi double [ %mul31.i.i.i.i, %if.then24.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i473.i.i.i.i ], [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ], [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ]
  %mul33.i.i.i.i = fmul double %add48.i.i.i.i.i.i, %retval.0.i.i.i544.i.i.i.i
  %div34.i.i.i.i = fdiv double %add48.i.i585.i.i.i.i, %mul33.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else35.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %cmp37.i.i.i.i = icmp sgt i32 %23, -17
  br i1 %cmp37.i.i.i.i, label %if.then38.i.i.i.i, label %if.else49.i.i.i.i

if.then38.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %294 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 8) #3
  %295 = tail call double @llvm.amdgcn.frexp.mant.f64(double %294) #3
  %296 = fcmp olt double %295, 0x3FE5555555555555
  %297 = zext i1 %296 to i32
  %298 = tail call double @llvm.amdgcn.ldexp.f64(double %295, i32 %297) #3
  %299 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %294) #3
  %300 = sub nsw i32 %299, %297
  %301 = fadd double %298, -1.000000e+00
  %302 = fadd double %298, 1.000000e+00
  %303 = fsub double %302, %298
  %304 = fsub double %302, %303
  %305 = fsub double %298, %304
  %306 = fsub double 1.000000e+00, %303
  %307 = fadd double %306, %305
  %308 = tail call double @llvm.amdgcn.rcp.f64(double %302) #3
  %309 = fneg double %302
  %310 = tail call double @llvm.fma.f64(double %309, double %308, double 1.000000e+00) #3
  %311 = tail call double @llvm.fma.f64(double %310, double %308, double %308) #3
  %312 = tail call double @llvm.fma.f64(double %309, double %311, double 1.000000e+00) #3
  %313 = tail call double @llvm.fma.f64(double %312, double %311, double %311) #3
  %314 = fmul double %301, %313
  %315 = fmul double %302, %314
  %316 = fneg double %315
  %317 = tail call double @llvm.fma.f64(double %314, double %302, double %316) #3
  %318 = tail call double @llvm.fma.f64(double %314, double %307, double %317) #3
  %319 = fadd double %315, %318
  %320 = fsub double %319, %315
  %321 = fsub double %318, %320
  %322 = fsub double %301, %319
  %323 = fsub double %301, %322
  %324 = fsub double %323, %319
  %325 = fsub double %324, %321
  %326 = fadd double %322, %325
  %327 = fmul double %313, %326
  %328 = fadd double %314, %327
  %329 = fsub double %328, %314
  %330 = fsub double %327, %329
  %331 = fmul double %328, %328
  %332 = fneg double %331
  %333 = tail call double @llvm.fma.f64(double %328, double %328, double %332) #3
  %334 = fmul double %330, 2.000000e+00
  %335 = tail call double @llvm.fma.f64(double %328, double %334, double %333) #3
  %336 = tail call double @llvm.fma.f64(double %330, double %330, double %335) #3
  %337 = fadd double %331, %336
  %338 = fsub double %337, %331
  %339 = fsub double %336, %338
  %340 = tail call double @llvm.fma.f64(double %337, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %341 = tail call double @llvm.fma.f64(double %337, double %340, double 0x3FC7474DD7F4DF2E) #3
  %342 = tail call double @llvm.fma.f64(double %337, double %341, double 0x3FCC71C016291751) #3
  %343 = tail call double @llvm.fma.f64(double %337, double %342, double 0x3FD249249B27ACF1) #3
  %344 = tail call double @llvm.fma.f64(double %337, double %343, double 0x3FD99999998EF7B6) #3
  %345 = tail call double @llvm.fma.f64(double %337, double %344, double 0x3FE5555555555780) #3
  %346 = tail call double @llvm.amdgcn.ldexp.f64(double %328, i32 1) #3
  %347 = tail call double @llvm.amdgcn.ldexp.f64(double %330, i32 1) #3
  %348 = fmul double %328, %337
  %349 = fneg double %348
  %350 = tail call double @llvm.fma.f64(double %328, double %337, double %349) #3
  %351 = fmul double %330, %337
  %352 = tail call double @llvm.fma.f64(double %328, double %339, double %351) #3
  %353 = fadd double %350, %352
  %354 = fadd double %348, %353
  %355 = fsub double %354, %348
  %356 = fsub double %353, %355
  %357 = fmul double %354, %345
  %358 = fneg double %357
  %359 = tail call double @llvm.fma.f64(double %354, double %345, double %358) #3
  %360 = tail call double @llvm.fma.f64(double %356, double %345, double %359) #3
  %361 = fadd double %357, %360
  %362 = fsub double %361, %357
  %363 = fsub double %360, %362
  %364 = fadd double %346, %361
  %365 = fsub double %364, %346
  %366 = fsub double %364, %365
  %367 = fsub double %346, %366
  %368 = fsub double %361, %365
  %369 = fadd double %368, %367
  %370 = fadd double %347, %363
  %371 = fsub double %370, %347
  %372 = fsub double %370, %371
  %373 = fsub double %347, %372
  %374 = fsub double %363, %371
  %375 = fadd double %374, %373
  %376 = fadd double %370, %369
  %377 = fadd double %364, %376
  %378 = fsub double %377, %364
  %379 = fsub double %376, %378
  %380 = fadd double %375, %379
  %381 = fadd double %377, %380
  %382 = fsub double %381, %377
  %383 = fsub double %380, %382
  %384 = sitofp i32 %300 to double
  %385 = fmul double %381, 0x3FF71547652B82FE
  %386 = fneg double %385
  %387 = fmul double %381, 0x3C7777D0FFDA0D24
  %388 = insertelement <2 x double> undef, double %381, i32 0
  %389 = insertelement <2 x double> %388, double %383, i32 1
  %390 = insertelement <2 x double> undef, double %386, i32 0
  %391 = insertelement <2 x double> %390, double %387, i32 1
  %392 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %389, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %391) #3
  %393 = extractelement <2 x double> %392, i32 0
  %394 = extractelement <2 x double> %392, i32 1
  %395 = fadd double %393, %394
  %396 = fadd double %385, %395
  %397 = fsub double %396, %385
  %398 = fsub double %395, %397
  %399 = fadd double %396, %384
  %400 = fsub double %399, %384
  %401 = fsub double %400, %399
  %402 = fadd double %401, %384
  %403 = fsub double %396, %400
  %404 = fadd double %403, %402
  %405 = fadd double %398, %404
  %406 = fadd double %399, %405
  %407 = tail call double @llvm.fabs.f64(double %294) #4
  %408 = fcmp oeq double %407, 0x7FF0000000000000
  %409 = select i1 %408, double %294, double %406
  %410 = fcmp olt double %294, 0.000000e+00
  %411 = select i1 %410, double 0x7FF8000000000000, double %409
  %412 = fcmp oeq double %294, 0.000000e+00
  %413 = select i1 %412, double 0xFFF0000000000000, double %411
  %mul.i.i450.i.i.i.i = fmul double %413, %413
  %mul1.i.i451.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3D1C49F35743D651
  %add.i.i452.i.i.i.i = fadd double %mul1.i.i451.i.i.i.i, 0x3EC5BDF8ABE0C4D2
  %mul5.i.i453.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E74DE722017F09B
  %add7.i.i454.i.i.i.i = fadd double %mul5.i.i453.i.i.i.i, 0x3F08B20867234AE0
  %mul10.i.i455.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i452.i.i.i.i
  %mul12.i.i456.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i454.i.i.i.i
  %add15.i.i457.i.i.i.i = fadd double %mul10.i.i455.i.i.i.i, 0x3F43291C59111954
  %add18.i.i458.i.i.i.i = fadd double %mul12.i.i456.i.i.i.i, 0x3F7555F81DC90AE6
  %mul20.i.i459.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i457.i.i.i.i
  %mul22.i.i460.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i458.i.i.i.i
  %add25.i.i461.i.i.i.i = fadd double %mul20.i.i459.i.i.i.i, 0x3FA118409603E368
  %add28.i.i462.i.i.i.i = fadd double %mul22.i.i460.i.i.i.i, 0x3FC2F812CF93403D
  %mul30.i.i463.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i461.i.i.i.i
  %mul32.i.i.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add28.i.i462.i.i.i.i
  %add35.i.i.i.i.i.i = fadd double %mul30.i.i463.i.i.i.i, 0x3FDA4ECF31EE23E1
  %add38.i.i464.i.i.i.i = fadd double %mul32.i.i.i.i.i.i, 0x3FE15637BD9C1C6C
  %414 = fmul double %413, %add35.i.i.i.i.i.i
  %add43.i.i.i.i.i.i = fsub double %add38.i.i464.i.i.i.i, %414
  %mul1.i.i434.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E834146FFF39045
  %add.i.i435.i.i.i.i = fadd double %mul1.i.i434.i.i.i.i, 0x3F16C942D4A0C545
  %mul5.i.i436.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3ED40F287F6755C5
  %add7.i.i437.i.i.i.i = fadd double %mul5.i.i436.i.i.i.i, 0x3F51AD434F5D94BA
  %mul10.i.i438.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i435.i.i.i.i
  %mul12.i.i439.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i437.i.i.i.i
  %add15.i.i440.i.i.i.i = fadd double %mul10.i.i438.i.i.i.i, 0x3F83AFF5A756295F
  %add18.i.i441.i.i.i.i = fadd double %mul12.i.i439.i.i.i.i, 0x3FAF8A313C5B71D0
  %mul20.i.i442.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i440.i.i.i.i
  %mul22.i.i443.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i441.i.i.i.i
  %add25.i.i444.i.i.i.i = fadd double %mul20.i.i442.i.i.i.i, 0x3FD1813788B6276A
  %add28.i.i445.i.i.i.i = fadd double %mul22.i.i443.i.i.i.i, 0x3FE84455F48DB67F
  %mul30.i.i446.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i444.i.i.i.i
  %add33.i.i447.i.i.i.i = fadd double %mul30.i.i446.i.i.i.i, 1.000000e+00
  %415 = fmul double %413, %add28.i.i445.i.i.i.i
  %add38.i.i449.i.i.i.i = fsub double %add33.i.i447.i.i.i.i, %415
  %mul45.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i356.i.i.i.i = fcmp ogt double %mul45.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i357.i.i.i.i = fcmp oeq double %mul45.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i358.i.i.i.i = or i1 %cmp.i.i.i.i356.i.i.i.i, %cmp.i.i.i357.i.i.i.i
  br i1 %or.cond.i.i.i358.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end.i.i.i360.i.i.i.i

if.end.i.i.i360.i.i.i.i:                          ; preds = %if.then38.i.i.i.i
  %cmp.i.i.i.i.i359.i.i.i.i = fcmp uno double %mul45.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i359.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end7.i.i.i386.i.i.i.i

if.end7.i.i.i386.i.i.i.i:                         ; preds = %if.end.i.i.i360.i.i.i.i
  %416 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul45.i.i.i.i) #3
  %417 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul45.i.i.i.i) #3
  %418 = tail call i1 @llvm.amdgcn.class.f64(double %mul45.i.i.i.i, i32 519) #3
  %419 = select i1 %418, i32 0, i32 %416
  %420 = select i1 %418, double %mul45.i.i.i.i, double %417
  %mul.i.i.i.i.i372.i.i.i.i = fmul double %420, %420
  %mul1.i.i.i.i.i373.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i374.i.i.i.i = fadd double %mul1.i.i.i.i.i373.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i375.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FE479D17050CA47
  %421 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i375.i.i.i.i
  %mul10.i.i.i.i.i377.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %add.i.i.i.i.i374.i.i.i.i
  %mul12.i.i.i.i.i378.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %421
  %add15.i.i.i.i.i379.i.i.i.i = fadd double %mul10.i.i.i.i.i377.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i380.i.i.i.i = fadd double %mul12.i.i.i.i.i378.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i381.i.i.i.i = fmul double %420, %add15.i.i.i.i.i379.i.i.i.i
  %add23.i.i.i.i.i382.i.i.i.i = fadd double %add18.i.i.i.i.i380.i.i.i.i, %mul20.i.i.i.i.i381.i.i.i.i
  %.frozen210 = freeze i32 %419
  %div.i.i.i383.i.i.i.i = sdiv i32 %.frozen210, 3
  %422 = sub nsw i32 0, %div.i.i.i383.i.i.i.i
  %423 = call i32 @llvm.abs.i32(i32 %div.i.i.i383.i.i.i.i, i1 true)
  %cmp11.i.i.i385.i.i.i.i = icmp ult i32 %423, 64
  br i1 %cmp11.i.i.i385.i.i.i.i, label %if.then12.i.i.i388.i.i.i.i, label %if.else21.i.i.i400.i.i.i.i

if.then12.i.i.i388.i.i.i.i:                       ; preds = %if.end7.i.i.i386.i.i.i.i
  %cmp13.i.i.i387.i.i.i.i = icmp sgt i32 %419, 2
  br i1 %cmp13.i.i.i387.i.i.i.i, label %if.then14.i.i.i393.i.i.i.i, label %if.else.i.i.i399.i.i.i.i

if.then14.i.i.i393.i.i.i.i:                       ; preds = %if.then12.i.i.i388.i.i.i.i
  %sh_prom.i.i.i389.i.i.i.i = zext i32 %div.i.i.i383.i.i.i.i to i64
  %shl.i.i.i390.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i389.i.i.i.i
  %conv.i.i.i391.i.i.i.i = uitofp i64 %shl.i.i.i390.i.i.i.i to double
  %mul.i.i.i392.i.i.i.i = fmul double %add23.i.i.i.i.i382.i.i.i.i, %conv.i.i.i391.i.i.i.i
  br label %if.end23.i.i.i406.i.i.i.i

if.else.i.i.i399.i.i.i.i:                         ; preds = %if.then12.i.i.i388.i.i.i.i
  %sh_prom16.i.i.i395.i.i.i.i = zext i32 %422 to i64
  %shl17.i.i.i396.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i395.i.i.i.i
  %conv18.i.i.i397.i.i.i.i = uitofp i64 %shl17.i.i.i396.i.i.i.i to double
  %div19.i.i.i398.i.i.i.i = fdiv double %add23.i.i.i.i.i382.i.i.i.i, %conv18.i.i.i397.i.i.i.i
  br label %if.end23.i.i.i406.i.i.i.i

if.else21.i.i.i400.i.i.i.i:                       ; preds = %if.end7.i.i.i386.i.i.i.i
  %424 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i382.i.i.i.i, i32 %div.i.i.i383.i.i.i.i) #3
  br label %if.end23.i.i.i406.i.i.i.i

if.end23.i.i.i406.i.i.i.i:                        ; preds = %if.else21.i.i.i400.i.i.i.i, %if.else.i.i.i399.i.i.i.i, %if.then14.i.i.i393.i.i.i.i
  %guess.i.i.i355.i.i.i.i.0 = phi double [ %mul.i.i.i392.i.i.i.i, %if.then14.i.i.i393.i.i.i.i ], [ %div19.i.i.i398.i.i.i.i, %if.else.i.i.i399.i.i.i.i ], [ %424, %if.else21.i.i.i400.i.i.i.i ]
  %.neg4 = mul nsw i32 %div.i.i.i383.i.i.i.i, -3
  %rem.i.i.i401.i.i.i.i.decomposed = add i32 %.frozen210, 2
  %add.i.i.i402.i.i.i.i = add i32 %rem.i.i.i401.i.i.i.i.decomposed, %.neg4
  %425 = zext i32 %add.i.i.i402.i.i.i.i to i64
  %arrayidx1.i.i.i403.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %425
  %426 = load double, double addrspace(4)* %arrayidx1.i.i.i403.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i404.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.0, %426
  %cmp26.i.i.i405.i.i.i.i = icmp slt i32 %419, 1021
  br i1 %cmp26.i.i.i405.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i

do.body.i.i.i417.i.i.i.i:                         ; preds = %do.body.i.i.i417.i.i.i.i, %if.end23.i.i.i406.i.i.i.i
  %guess.i.i.i355.i.i.i.i.1 = phi double [ %mul24.i.i.i404.i.i.i.i, %if.end23.i.i.i406.i.i.i.i ], [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ]
  %mul28.i.i.i407.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %guess.i.i.i355.i.i.i.i.1
  %mul29.i.i.i408.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %mul28.i.i.i407.i.i.i.i
  %add30.i.i.i409.i.i.i.i = fadd double %mul45.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add31.i.i.i410.i.i.i.i = fadd double %mul45.i.i.i.i, %add30.i.i.i409.i.i.i.i
  %add32.i.i.i411.i.i.i.i = fadd double %mul29.i.i.i408.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add33.i.i.i412.i.i.i.i = fadd double %mul45.i.i.i.i, %add32.i.i.i411.i.i.i.i
  %div34.i.i.i413.i.i.i.i = fdiv double %add31.i.i.i410.i.i.i.i, %add33.i.i.i412.i.i.i.i
  %mul35.i.i.i414.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %div34.i.i.i413.i.i.i.i
  %sub36.i.i.i415.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i413.i.i.i.i
  %427 = tail call double @llvm.fabs.f64(double %sub36.i.i.i415.i.i.i.i) #3
  %cmp38.i.i.i416.i.i.i.i = fcmp ogt double %427, 0x3EC0000000000000
  br i1 %cmp38.i.i.i416.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

do.body40.i.i.i428.i.i.i.i:                       ; preds = %do.body40.i.i.i428.i.i.i.i, %if.end23.i.i.i406.i.i.i.i
  %guess.i.i.i355.i.i.i.i.2 = phi double [ %mul24.i.i.i404.i.i.i.i, %if.end23.i.i.i406.i.i.i.i ], [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ]
  %mul41.i.i.i418.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, %guess.i.i.i355.i.i.i.i.2
  %div42.i.i.i419.i.i.i.i = fdiv double %mul45.i.i.i.i, %guess.i.i.i355.i.i.i.i.2
  %sub43.i.i.i420.i.i.i.i = fsub double %mul41.i.i.i418.i.i.i.i, %div42.i.i.i419.i.i.i.i
  %mul44.i.i.i421.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i422.i.i.i.i = fdiv double %mul45.i.i.i.i, %mul41.i.i.i418.i.i.i.i
  %add46.i.i.i423.i.i.i.i = fadd double %mul44.i.i.i421.i.i.i.i, %div45.i.i.i422.i.i.i.i
  %div47.i.i.i424.i.i.i.i = fdiv double %sub43.i.i.i420.i.i.i.i, %add46.i.i.i423.i.i.i.i
  %sub48.i.i.i425.i.i.i.i = fsub double %guess.i.i.i355.i.i.i.i.2, %div47.i.i.i424.i.i.i.i
  %mul50.i.i.i426.i.i.i.i = fmul double %sub48.i.i.i425.i.i.i.i, 0x3EC0000000000000
  %428 = tail call double @llvm.fabs.f64(double %div47.i.i.i424.i.i.i.i) #3
  %cmp52.i.i.i427.i.i.i.i = fcmp olt double %mul50.i.i.i426.i.i.i.i, %428
  br i1 %cmp52.i.i.i427.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i: ; preds = %do.body40.i.i.i428.i.i.i.i, %do.body.i.i.i417.i.i.i.i, %if.end.i.i.i360.i.i.i.i, %if.then38.i.i.i.i
  %retval.0.i.i.i431.i.i.i.i = phi double [ %mul45.i.i.i.i, %if.then38.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i360.i.i.i.i ], [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ], [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ]
  %mul47.i.i.i.i = fmul double %add38.i.i449.i.i.i.i, %retval.0.i.i.i431.i.i.i.i
  %div48.i.i.i.i = fdiv double %add43.i.i.i.i.i.i, %mul47.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else49.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %cmp51.i.i.i.i = icmp sgt i32 %23, -33
  br i1 %cmp51.i.i.i.i, label %if.then52.i.i.i.i, label %if.else63.i.i.i.i

if.then52.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %429 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 16) #3
  %430 = tail call double @llvm.amdgcn.frexp.mant.f64(double %429) #3
  %431 = fcmp olt double %430, 0x3FE5555555555555
  %432 = zext i1 %431 to i32
  %433 = tail call double @llvm.amdgcn.ldexp.f64(double %430, i32 %432) #3
  %434 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %429) #3
  %435 = sub nsw i32 %434, %432
  %436 = fadd double %433, -1.000000e+00
  %437 = fadd double %433, 1.000000e+00
  %438 = fsub double %437, %433
  %439 = fsub double %437, %438
  %440 = fsub double %433, %439
  %441 = fsub double 1.000000e+00, %438
  %442 = fadd double %441, %440
  %443 = tail call double @llvm.amdgcn.rcp.f64(double %437) #3
  %444 = fneg double %437
  %445 = tail call double @llvm.fma.f64(double %444, double %443, double 1.000000e+00) #3
  %446 = tail call double @llvm.fma.f64(double %445, double %443, double %443) #3
  %447 = tail call double @llvm.fma.f64(double %444, double %446, double 1.000000e+00) #3
  %448 = tail call double @llvm.fma.f64(double %447, double %446, double %446) #3
  %449 = fmul double %436, %448
  %450 = fmul double %437, %449
  %451 = fneg double %450
  %452 = tail call double @llvm.fma.f64(double %449, double %437, double %451) #3
  %453 = tail call double @llvm.fma.f64(double %449, double %442, double %452) #3
  %454 = fadd double %450, %453
  %455 = fsub double %454, %450
  %456 = fsub double %453, %455
  %457 = fsub double %436, %454
  %458 = fsub double %436, %457
  %459 = fsub double %458, %454
  %460 = fsub double %459, %456
  %461 = fadd double %457, %460
  %462 = fmul double %448, %461
  %463 = fadd double %449, %462
  %464 = fsub double %463, %449
  %465 = fsub double %462, %464
  %466 = fmul double %463, %463
  %467 = fneg double %466
  %468 = tail call double @llvm.fma.f64(double %463, double %463, double %467) #3
  %469 = fmul double %465, 2.000000e+00
  %470 = tail call double @llvm.fma.f64(double %463, double %469, double %468) #3
  %471 = tail call double @llvm.fma.f64(double %465, double %465, double %470) #3
  %472 = fadd double %466, %471
  %473 = fsub double %472, %466
  %474 = fsub double %471, %473
  %475 = tail call double @llvm.fma.f64(double %472, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %476 = tail call double @llvm.fma.f64(double %472, double %475, double 0x3FC7474DD7F4DF2E) #3
  %477 = tail call double @llvm.fma.f64(double %472, double %476, double 0x3FCC71C016291751) #3
  %478 = tail call double @llvm.fma.f64(double %472, double %477, double 0x3FD249249B27ACF1) #3
  %479 = tail call double @llvm.fma.f64(double %472, double %478, double 0x3FD99999998EF7B6) #3
  %480 = tail call double @llvm.fma.f64(double %472, double %479, double 0x3FE5555555555780) #3
  %481 = tail call double @llvm.amdgcn.ldexp.f64(double %463, i32 1) #3
  %482 = tail call double @llvm.amdgcn.ldexp.f64(double %465, i32 1) #3
  %483 = fmul double %463, %472
  %484 = fneg double %483
  %485 = tail call double @llvm.fma.f64(double %463, double %472, double %484) #3
  %486 = fmul double %465, %472
  %487 = tail call double @llvm.fma.f64(double %463, double %474, double %486) #3
  %488 = fadd double %485, %487
  %489 = fadd double %483, %488
  %490 = fsub double %489, %483
  %491 = fsub double %488, %490
  %492 = fmul double %489, %480
  %493 = fneg double %492
  %494 = tail call double @llvm.fma.f64(double %489, double %480, double %493) #3
  %495 = tail call double @llvm.fma.f64(double %491, double %480, double %494) #3
  %496 = fadd double %492, %495
  %497 = fsub double %496, %492
  %498 = fsub double %495, %497
  %499 = fadd double %481, %496
  %500 = fsub double %499, %481
  %501 = fsub double %499, %500
  %502 = fsub double %481, %501
  %503 = fsub double %496, %500
  %504 = fadd double %503, %502
  %505 = fadd double %482, %498
  %506 = fsub double %505, %482
  %507 = fsub double %505, %506
  %508 = fsub double %482, %507
  %509 = fsub double %498, %506
  %510 = fadd double %509, %508
  %511 = fadd double %505, %504
  %512 = fadd double %499, %511
  %513 = fsub double %512, %499
  %514 = fsub double %511, %513
  %515 = fadd double %510, %514
  %516 = fadd double %512, %515
  %517 = fsub double %516, %512
  %518 = fsub double %515, %517
  %519 = sitofp i32 %435 to double
  %520 = fmul double %516, 0x3FF71547652B82FE
  %521 = fneg double %520
  %522 = fmul double %516, 0x3C7777D0FFDA0D24
  %523 = insertelement <2 x double> undef, double %516, i32 0
  %524 = insertelement <2 x double> %523, double %518, i32 1
  %525 = insertelement <2 x double> undef, double %521, i32 0
  %526 = insertelement <2 x double> %525, double %522, i32 1
  %527 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %524, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %526) #3
  %528 = extractelement <2 x double> %527, i32 0
  %529 = extractelement <2 x double> %527, i32 1
  %530 = fadd double %528, %529
  %531 = fadd double %520, %530
  %532 = fsub double %531, %520
  %533 = fsub double %530, %532
  %534 = fadd double %531, %519
  %535 = fsub double %534, %519
  %536 = fsub double %535, %534
  %537 = fadd double %536, %519
  %538 = fsub double %531, %535
  %539 = fadd double %538, %537
  %540 = fadd double %533, %539
  %541 = fadd double %534, %540
  %542 = tail call double @llvm.fabs.f64(double %429) #4
  %543 = fcmp oeq double %542, 0x7FF0000000000000
  %544 = select i1 %543, double %429, double %541
  %545 = fcmp olt double %429, 0.000000e+00
  %546 = select i1 %545, double 0x7FF8000000000000, double %544
  %547 = fcmp oeq double %429, 0.000000e+00
  %548 = select i1 %547, double 0xFFF0000000000000, double %546
  %mul.i.i335.i.i.i.i = fmul double %548, %548
  %mul1.i.i336.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EBF7344DBF5E403
  %add.i.i337.i.i.i.i = fadd double %mul1.i.i336.i.i.i.i, 0x3F2CFF1E2D54E4E7
  %mul5.i.i338.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EEF8CF23CAED047
  %add7.i.i339.i.i.i.i = fadd double %mul5.i.i338.i.i.i.i, 0x3F5CF8F0FF9B6F59
  %mul10.i.i340.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i337.i.i.i.i
  %mul12.i.i341.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i339.i.i.i.i
  %add15.i.i342.i.i.i.i = fadd double %mul10.i.i340.i.i.i.i, 0x3F8857AD74D33625
  %add18.i.i343.i.i.i.i = fadd double %mul12.i.i341.i.i.i.i, 0x3FAE52179C3AEDE6
  %mul20.i.i344.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i342.i.i.i.i
  %mul22.i.i345.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i343.i.i.i.i
  %add25.i.i346.i.i.i.i = fadd double %mul20.i.i344.i.i.i.i, 0x3FCB21A22303D8FC
  %add28.i.i347.i.i.i.i = fadd double %mul22.i.i345.i.i.i.i, 0x3FDF29CE00A8804B
  %mul30.i.i348.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i346.i.i.i.i
  %add33.i.i349.i.i.i.i = fadd double %mul30.i.i348.i.i.i.i, 0x3FE15775564555E5
  %549 = fmul double %548, %add28.i.i347.i.i.i.i
  %add38.i.i351.i.i.i.i = fsub double %add33.i.i349.i.i.i.i, %549
  %mul1.i.i321.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3ECD04621671DBCE
  %add.i.i322.i.i.i.i = fadd double %mul1.i.i321.i.i.i.i, 0x3F3AC0D433DC2A4E
  %mul5.i.i323.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EFD1C12EAA62BE9
  %add7.i.i324.i.i.i.i = fadd double %mul5.i.i323.i.i.i.i, 0x3F6ABB215A001E96
  %mul10.i.i325.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i322.i.i.i.i
  %mul12.i.i326.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i324.i.i.i.i
  %add15.i.i327.i.i.i.i = fadd double %mul10.i.i325.i.i.i.i, 0x3F967590758A1B1A
  %add18.i.i328.i.i.i.i = fadd double %mul12.i.i326.i.i.i.i, 0x3FBBF9941AE7DFDE
  %mul20.i.i329.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i327.i.i.i.i
  %mul22.i.i330.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i328.i.i.i.i
  %add25.i.i331.i.i.i.i = fadd double %mul20.i.i329.i.i.i.i, 0x3FD90848F242167F
  %add28.i.i332.i.i.i.i = fadd double %mul22.i.i330.i.i.i.i, 0x3FECC09A37BCEE76
  %mul30.i.i333.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i331.i.i.i.i
  %add33.i.i334.i.i.i.i = fadd double %mul30.i.i333.i.i.i.i, 1.000000e+00
  %550 = fmul double %548, %add28.i.i332.i.i.i.i
  %add38.i.i.i.i.i.i = fsub double %add33.i.i334.i.i.i.i, %550
  %mul59.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i243.i.i.i.i = fcmp ogt double %mul59.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i244.i.i.i.i = fcmp oeq double %mul59.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i245.i.i.i.i = or i1 %cmp.i.i.i.i243.i.i.i.i, %cmp.i.i.i244.i.i.i.i
  br i1 %or.cond.i.i.i245.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end.i.i.i247.i.i.i.i

if.end.i.i.i247.i.i.i.i:                          ; preds = %if.then52.i.i.i.i
  %cmp.i.i.i.i.i246.i.i.i.i = fcmp uno double %mul59.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i246.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end7.i.i.i273.i.i.i.i

if.end7.i.i.i273.i.i.i.i:                         ; preds = %if.end.i.i.i247.i.i.i.i
  %551 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul59.i.i.i.i) #3
  %552 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul59.i.i.i.i) #3
  %553 = tail call i1 @llvm.amdgcn.class.f64(double %mul59.i.i.i.i, i32 519) #3
  %554 = select i1 %553, i32 0, i32 %551
  %555 = select i1 %553, double %mul59.i.i.i.i, double %552
  %mul.i.i.i.i.i259.i.i.i.i = fmul double %555, %555
  %mul1.i.i.i.i.i260.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i261.i.i.i.i = fadd double %mul1.i.i.i.i.i260.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i262.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FE479D17050CA47
  %556 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i262.i.i.i.i
  %mul10.i.i.i.i.i264.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %add.i.i.i.i.i261.i.i.i.i
  %mul12.i.i.i.i.i265.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %556
  %add15.i.i.i.i.i266.i.i.i.i = fadd double %mul10.i.i.i.i.i264.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i267.i.i.i.i = fadd double %mul12.i.i.i.i.i265.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i268.i.i.i.i = fmul double %555, %add15.i.i.i.i.i266.i.i.i.i
  %add23.i.i.i.i.i269.i.i.i.i = fadd double %add18.i.i.i.i.i267.i.i.i.i, %mul20.i.i.i.i.i268.i.i.i.i
  %.frozen211 = freeze i32 %554
  %div.i.i.i270.i.i.i.i = sdiv i32 %.frozen211, 3
  %557 = sub nsw i32 0, %div.i.i.i270.i.i.i.i
  %558 = call i32 @llvm.abs.i32(i32 %div.i.i.i270.i.i.i.i, i1 true)
  %cmp11.i.i.i272.i.i.i.i = icmp ult i32 %558, 64
  br i1 %cmp11.i.i.i272.i.i.i.i, label %if.then12.i.i.i275.i.i.i.i, label %if.else21.i.i.i287.i.i.i.i

if.then12.i.i.i275.i.i.i.i:                       ; preds = %if.end7.i.i.i273.i.i.i.i
  %cmp13.i.i.i274.i.i.i.i = icmp sgt i32 %554, 2
  br i1 %cmp13.i.i.i274.i.i.i.i, label %if.then14.i.i.i280.i.i.i.i, label %if.else.i.i.i286.i.i.i.i

if.then14.i.i.i280.i.i.i.i:                       ; preds = %if.then12.i.i.i275.i.i.i.i
  %sh_prom.i.i.i276.i.i.i.i = zext i32 %div.i.i.i270.i.i.i.i to i64
  %shl.i.i.i277.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i276.i.i.i.i
  %conv.i.i.i278.i.i.i.i = uitofp i64 %shl.i.i.i277.i.i.i.i to double
  %mul.i.i.i279.i.i.i.i = fmul double %add23.i.i.i.i.i269.i.i.i.i, %conv.i.i.i278.i.i.i.i
  br label %if.end23.i.i.i293.i.i.i.i

if.else.i.i.i286.i.i.i.i:                         ; preds = %if.then12.i.i.i275.i.i.i.i
  %sh_prom16.i.i.i282.i.i.i.i = zext i32 %557 to i64
  %shl17.i.i.i283.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i282.i.i.i.i
  %conv18.i.i.i284.i.i.i.i = uitofp i64 %shl17.i.i.i283.i.i.i.i to double
  %div19.i.i.i285.i.i.i.i = fdiv double %add23.i.i.i.i.i269.i.i.i.i, %conv18.i.i.i284.i.i.i.i
  br label %if.end23.i.i.i293.i.i.i.i

if.else21.i.i.i287.i.i.i.i:                       ; preds = %if.end7.i.i.i273.i.i.i.i
  %559 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i269.i.i.i.i, i32 %div.i.i.i270.i.i.i.i) #3
  br label %if.end23.i.i.i293.i.i.i.i

if.end23.i.i.i293.i.i.i.i:                        ; preds = %if.else21.i.i.i287.i.i.i.i, %if.else.i.i.i286.i.i.i.i, %if.then14.i.i.i280.i.i.i.i
  %guess.i.i.i242.i.i.i.i.0 = phi double [ %mul.i.i.i279.i.i.i.i, %if.then14.i.i.i280.i.i.i.i ], [ %div19.i.i.i285.i.i.i.i, %if.else.i.i.i286.i.i.i.i ], [ %559, %if.else21.i.i.i287.i.i.i.i ]
  %.neg3 = mul nsw i32 %div.i.i.i270.i.i.i.i, -3
  %rem.i.i.i288.i.i.i.i.decomposed = add i32 %.frozen211, 2
  %add.i.i.i289.i.i.i.i = add i32 %rem.i.i.i288.i.i.i.i.decomposed, %.neg3
  %560 = zext i32 %add.i.i.i289.i.i.i.i to i64
  %arrayidx1.i.i.i290.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %560
  %561 = load double, double addrspace(4)* %arrayidx1.i.i.i290.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i291.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.0, %561
  %cmp26.i.i.i292.i.i.i.i = icmp slt i32 %554, 1021
  br i1 %cmp26.i.i.i292.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i

do.body.i.i.i304.i.i.i.i:                         ; preds = %do.body.i.i.i304.i.i.i.i, %if.end23.i.i.i293.i.i.i.i
  %guess.i.i.i242.i.i.i.i.1 = phi double [ %mul24.i.i.i291.i.i.i.i, %if.end23.i.i.i293.i.i.i.i ], [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ]
  %mul28.i.i.i294.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %guess.i.i.i242.i.i.i.i.1
  %mul29.i.i.i295.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %mul28.i.i.i294.i.i.i.i
  %add30.i.i.i296.i.i.i.i = fadd double %mul59.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add31.i.i.i297.i.i.i.i = fadd double %mul59.i.i.i.i, %add30.i.i.i296.i.i.i.i
  %add32.i.i.i298.i.i.i.i = fadd double %mul29.i.i.i295.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add33.i.i.i299.i.i.i.i = fadd double %mul59.i.i.i.i, %add32.i.i.i298.i.i.i.i
  %div34.i.i.i300.i.i.i.i = fdiv double %add31.i.i.i297.i.i.i.i, %add33.i.i.i299.i.i.i.i
  %mul35.i.i.i301.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %div34.i.i.i300.i.i.i.i
  %sub36.i.i.i302.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i300.i.i.i.i
  %562 = tail call double @llvm.fabs.f64(double %sub36.i.i.i302.i.i.i.i) #3
  %cmp38.i.i.i303.i.i.i.i = fcmp ogt double %562, 0x3EC0000000000000
  br i1 %cmp38.i.i.i303.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

do.body40.i.i.i315.i.i.i.i:                       ; preds = %do.body40.i.i.i315.i.i.i.i, %if.end23.i.i.i293.i.i.i.i
  %guess.i.i.i242.i.i.i.i.2 = phi double [ %mul24.i.i.i291.i.i.i.i, %if.end23.i.i.i293.i.i.i.i ], [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ]
  %mul41.i.i.i305.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, %guess.i.i.i242.i.i.i.i.2
  %div42.i.i.i306.i.i.i.i = fdiv double %mul59.i.i.i.i, %guess.i.i.i242.i.i.i.i.2
  %sub43.i.i.i307.i.i.i.i = fsub double %mul41.i.i.i305.i.i.i.i, %div42.i.i.i306.i.i.i.i
  %mul44.i.i.i308.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i309.i.i.i.i = fdiv double %mul59.i.i.i.i, %mul41.i.i.i305.i.i.i.i
  %add46.i.i.i310.i.i.i.i = fadd double %mul44.i.i.i308.i.i.i.i, %div45.i.i.i309.i.i.i.i
  %div47.i.i.i311.i.i.i.i = fdiv double %sub43.i.i.i307.i.i.i.i, %add46.i.i.i310.i.i.i.i
  %sub48.i.i.i312.i.i.i.i = fsub double %guess.i.i.i242.i.i.i.i.2, %div47.i.i.i311.i.i.i.i
  %mul50.i.i.i313.i.i.i.i = fmul double %sub48.i.i.i312.i.i.i.i, 0x3EC0000000000000
  %563 = tail call double @llvm.fabs.f64(double %div47.i.i.i311.i.i.i.i) #3
  %cmp52.i.i.i314.i.i.i.i = fcmp olt double %mul50.i.i.i313.i.i.i.i, %563
  br i1 %cmp52.i.i.i314.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i: ; preds = %do.body40.i.i.i315.i.i.i.i, %do.body.i.i.i304.i.i.i.i, %if.end.i.i.i247.i.i.i.i, %if.then52.i.i.i.i
  %retval.0.i.i.i318.i.i.i.i = phi double [ %mul59.i.i.i.i, %if.then52.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i247.i.i.i.i ], [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ], [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ]
  %mul61.i.i.i.i = fmul double %add38.i.i.i.i.i.i, %retval.0.i.i.i318.i.i.i.i
  %div62.i.i.i.i = fdiv double %add38.i.i351.i.i.i.i, %mul61.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else63.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %mul64.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp1.i.i.i.i.i = fcmp oge double %mul64.i.i.i.i, 0x10000000000000
  %cmp2.i.i.i.i.i = fcmp ole double %mul64.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %564 = and i1 %cmp1.i.i.i.i.i, %cmp2.i.i.i.i.i
  br i1 %564, label %if.then66.i.i.i.i, label %if.else71.i.i.i.i

if.then66.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %mul68.i.i.i.i = fmul double %mul64.i.i.i.i, 0x401921FB54442D18
  %cmp.i.i.i.i162.i.i.i.i = fcmp ogt double %mul68.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i163.i.i.i.i = fcmp oeq double %mul68.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i164.i.i.i.i = or i1 %cmp.i.i.i.i162.i.i.i.i, %cmp.i.i.i163.i.i.i.i
  br i1 %or.cond.i.i.i164.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end.i.i.i166.i.i.i.i

if.end.i.i.i166.i.i.i.i:                          ; preds = %if.then66.i.i.i.i
  %cmp.i.i.i.i.i165.i.i.i.i = fcmp uno double %mul68.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i165.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end7.i.i.i192.i.i.i.i

if.end7.i.i.i192.i.i.i.i:                         ; preds = %if.end.i.i.i166.i.i.i.i
  %565 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul68.i.i.i.i) #3
  %566 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul68.i.i.i.i) #3
  %567 = tail call i1 @llvm.amdgcn.class.f64(double %mul68.i.i.i.i, i32 519) #3
  %568 = select i1 %567, i32 0, i32 %565
  %569 = select i1 %567, double %mul68.i.i.i.i, double %566
  %mul.i.i.i.i.i178.i.i.i.i = fmul double %569, %569
  %mul1.i.i.i.i.i179.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i180.i.i.i.i = fadd double %mul1.i.i.i.i.i179.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i181.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FE479D17050CA47
  %570 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i181.i.i.i.i
  %mul10.i.i.i.i.i183.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %add.i.i.i.i.i180.i.i.i.i
  %mul12.i.i.i.i.i184.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %570
  %add15.i.i.i.i.i185.i.i.i.i = fadd double %mul10.i.i.i.i.i183.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i186.i.i.i.i = fadd double %mul12.i.i.i.i.i184.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i187.i.i.i.i = fmul double %569, %add15.i.i.i.i.i185.i.i.i.i
  %add23.i.i.i.i.i188.i.i.i.i = fadd double %add18.i.i.i.i.i186.i.i.i.i, %mul20.i.i.i.i.i187.i.i.i.i
  %.frozen212 = freeze i32 %568
  %div.i.i.i189.i.i.i.i = sdiv i32 %.frozen212, 3
  %571 = sub nsw i32 0, %div.i.i.i189.i.i.i.i
  %572 = call i32 @llvm.abs.i32(i32 %div.i.i.i189.i.i.i.i, i1 true)
  %cmp11.i.i.i191.i.i.i.i = icmp ult i32 %572, 64
  br i1 %cmp11.i.i.i191.i.i.i.i, label %if.then12.i.i.i194.i.i.i.i, label %if.else21.i.i.i206.i.i.i.i

if.then12.i.i.i194.i.i.i.i:                       ; preds = %if.end7.i.i.i192.i.i.i.i
  %cmp13.i.i.i193.i.i.i.i = icmp sgt i32 %568, 2
  br i1 %cmp13.i.i.i193.i.i.i.i, label %if.then14.i.i.i199.i.i.i.i, label %if.else.i.i.i205.i.i.i.i

if.then14.i.i.i199.i.i.i.i:                       ; preds = %if.then12.i.i.i194.i.i.i.i
  %sh_prom.i.i.i195.i.i.i.i = zext i32 %div.i.i.i189.i.i.i.i to i64
  %shl.i.i.i196.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i195.i.i.i.i
  %conv.i.i.i197.i.i.i.i = uitofp i64 %shl.i.i.i196.i.i.i.i to double
  %mul.i.i.i198.i.i.i.i = fmul double %add23.i.i.i.i.i188.i.i.i.i, %conv.i.i.i197.i.i.i.i
  br label %if.end23.i.i.i212.i.i.i.i

if.else.i.i.i205.i.i.i.i:                         ; preds = %if.then12.i.i.i194.i.i.i.i
  %sh_prom16.i.i.i201.i.i.i.i = zext i32 %571 to i64
  %shl17.i.i.i202.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i201.i.i.i.i
  %conv18.i.i.i203.i.i.i.i = uitofp i64 %shl17.i.i.i202.i.i.i.i to double
  %div19.i.i.i204.i.i.i.i = fdiv double %add23.i.i.i.i.i188.i.i.i.i, %conv18.i.i.i203.i.i.i.i
  br label %if.end23.i.i.i212.i.i.i.i

if.else21.i.i.i206.i.i.i.i:                       ; preds = %if.end7.i.i.i192.i.i.i.i
  %573 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i188.i.i.i.i, i32 %div.i.i.i189.i.i.i.i) #3
  br label %if.end23.i.i.i212.i.i.i.i

if.end23.i.i.i212.i.i.i.i:                        ; preds = %if.else21.i.i.i206.i.i.i.i, %if.else.i.i.i205.i.i.i.i, %if.then14.i.i.i199.i.i.i.i
  %guess.i.i.i161.i.i.i.i.0 = phi double [ %mul.i.i.i198.i.i.i.i, %if.then14.i.i.i199.i.i.i.i ], [ %div19.i.i.i204.i.i.i.i, %if.else.i.i.i205.i.i.i.i ], [ %573, %if.else21.i.i.i206.i.i.i.i ]
  %.neg2 = mul nsw i32 %div.i.i.i189.i.i.i.i, -3
  %rem.i.i.i207.i.i.i.i.decomposed = add i32 %.frozen212, 2
  %add.i.i.i208.i.i.i.i = add i32 %rem.i.i.i207.i.i.i.i.decomposed, %.neg2
  %574 = zext i32 %add.i.i.i208.i.i.i.i to i64
  %arrayidx1.i.i.i209.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %574
  %575 = load double, double addrspace(4)* %arrayidx1.i.i.i209.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i210.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.0, %575
  %cmp26.i.i.i211.i.i.i.i = icmp slt i32 %568, 1021
  br i1 %cmp26.i.i.i211.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i

do.body.i.i.i223.i.i.i.i:                         ; preds = %do.body.i.i.i223.i.i.i.i, %if.end23.i.i.i212.i.i.i.i
  %guess.i.i.i161.i.i.i.i.1 = phi double [ %mul24.i.i.i210.i.i.i.i, %if.end23.i.i.i212.i.i.i.i ], [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ]
  %mul28.i.i.i213.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %guess.i.i.i161.i.i.i.i.1
  %mul29.i.i.i214.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %mul28.i.i.i213.i.i.i.i
  %add30.i.i.i215.i.i.i.i = fadd double %mul68.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add31.i.i.i216.i.i.i.i = fadd double %mul68.i.i.i.i, %add30.i.i.i215.i.i.i.i
  %add32.i.i.i217.i.i.i.i = fadd double %mul29.i.i.i214.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add33.i.i.i218.i.i.i.i = fadd double %mul68.i.i.i.i, %add32.i.i.i217.i.i.i.i
  %div34.i.i.i219.i.i.i.i = fdiv double %add31.i.i.i216.i.i.i.i, %add33.i.i.i218.i.i.i.i
  %mul35.i.i.i220.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %div34.i.i.i219.i.i.i.i
  %sub36.i.i.i221.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i219.i.i.i.i
  %576 = tail call double @llvm.fabs.f64(double %sub36.i.i.i221.i.i.i.i) #3
  %cmp38.i.i.i222.i.i.i.i = fcmp ogt double %576, 0x3EC0000000000000
  br i1 %cmp38.i.i.i222.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

do.body40.i.i.i234.i.i.i.i:                       ; preds = %do.body40.i.i.i234.i.i.i.i, %if.end23.i.i.i212.i.i.i.i
  %guess.i.i.i161.i.i.i.i.2 = phi double [ %mul24.i.i.i210.i.i.i.i, %if.end23.i.i.i212.i.i.i.i ], [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ]
  %mul41.i.i.i224.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, %guess.i.i.i161.i.i.i.i.2
  %div42.i.i.i225.i.i.i.i = fdiv double %mul68.i.i.i.i, %guess.i.i.i161.i.i.i.i.2
  %sub43.i.i.i226.i.i.i.i = fsub double %mul41.i.i.i224.i.i.i.i, %div42.i.i.i225.i.i.i.i
  %mul44.i.i.i227.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i228.i.i.i.i = fdiv double %mul68.i.i.i.i, %mul41.i.i.i224.i.i.i.i
  %add46.i.i.i229.i.i.i.i = fadd double %mul44.i.i.i227.i.i.i.i, %div45.i.i.i228.i.i.i.i
  %div47.i.i.i230.i.i.i.i = fdiv double %sub43.i.i.i226.i.i.i.i, %add46.i.i.i229.i.i.i.i
  %sub48.i.i.i231.i.i.i.i = fsub double %guess.i.i.i161.i.i.i.i.2, %div47.i.i.i230.i.i.i.i
  %mul50.i.i.i232.i.i.i.i = fmul double %sub48.i.i.i231.i.i.i.i, 0x3EC0000000000000
  %577 = tail call double @llvm.fabs.f64(double %div47.i.i.i230.i.i.i.i) #3
  %cmp52.i.i.i233.i.i.i.i = fcmp olt double %mul50.i.i.i232.i.i.i.i, %577
  br i1 %cmp52.i.i.i233.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i: ; preds = %do.body40.i.i.i234.i.i.i.i, %do.body.i.i.i223.i.i.i.i, %if.end.i.i.i166.i.i.i.i, %if.then66.i.i.i.i
  %retval.0.i.i.i237.i.i.i.i = phi double [ %mul68.i.i.i.i, %if.then66.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i166.i.i.i.i ], [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ], [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ]
  %div70.i.i.i.i = fdiv double 1.000000e+00, %retval.0.i.i.i237.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else71.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %cmp72.i.i.i.i = fcmp ogt double %sub.i.i.i, 0.000000e+00
  br i1 %cmp72.i.i.i.i, label %if.then73.i.i.i.i, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.then73.i.i.i.i:                                ; preds = %if.else71.i.i.i.i
  %cmp.i.i.i.i79.i.i.i.i = fcmp ogt double %sub.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i.i80.i.i.i.i = fcmp olt double %sub.i.i.i, 0xFFEFFFFFFFFFFFFF
  %578 = or i1 %cmp.i.i.i.i79.i.i.i.i, %cmp1.i.i.i.i80.i.i.i.i
  %or.cond.i.i.i82.i.i.i.i = or i1 %22, %578
  %brmerge170 = or i1 %17, %or.cond.i.i.i82.i.i.i.i
  %sub.i.i.i.mux = select i1 %or.cond.i.i.i82.i.i.i.i, double %sub.i.i.i, double 0x7FF8000000000000
  br i1 %brmerge170, label %if.end7.i.i.i.i.i.i.i, label %if.end4.i.i.i92.i.i.i.i

if.end4.i.i.i92.i.i.i.i:                          ; preds = %if.then73.i.i.i.i
  %cmp5.i.i.i91.i.i.i.i = fcmp olt double %sub.i.i.i, 0.000000e+00
  %fneg.i.i.i93.i.i.i.i = fneg double %sub.i.i.i
  %z.addr.i.i.i76.i.i.i.i.0 = select i1 %cmp5.i.i.i91.i.i.i.i, double %fneg.i.i.i93.i.i.i.i, double %sub.i.i.i
  %579 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %580 = tail call double @llvm.amdgcn.frexp.mant.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %581 = tail call i1 @llvm.amdgcn.class.f64(double %z.addr.i.i.i76.i.i.i.i.0, i32 519) #3
  %582 = select i1 %581, i32 0, i32 %579
  %583 = select i1 %581, double %z.addr.i.i.i76.i.i.i.i.0, double %580
  %mul.i.i.i.i.i97.i.i.i.i = fmul double %583, %583
  %mul1.i.i.i.i.i98.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i99.i.i.i.i = fadd double %mul1.i.i.i.i.i98.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i100.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FE479D17050CA47
  %584 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i100.i.i.i.i
  %mul10.i.i.i.i.i102.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %add.i.i.i.i.i99.i.i.i.i
  %mul12.i.i.i.i.i103.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %584
  %add15.i.i.i.i.i104.i.i.i.i = fadd double %mul10.i.i.i.i.i102.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i105.i.i.i.i = fadd double %mul12.i.i.i.i.i103.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i106.i.i.i.i = fmul double %583, %add15.i.i.i.i.i104.i.i.i.i
  %add23.i.i.i.i.i107.i.i.i.i = fadd double %add18.i.i.i.i.i105.i.i.i.i, %mul20.i.i.i.i.i106.i.i.i.i
  %.frozen213 = freeze i32 %582
  %div.i.i.i108.i.i.i.i = sdiv i32 %.frozen213, 3
  %585 = sub nsw i32 0, %div.i.i.i108.i.i.i.i
  %586 = call i32 @llvm.abs.i32(i32 %div.i.i.i108.i.i.i.i, i1 true)
  %cmp11.i.i.i110.i.i.i.i = icmp ult i32 %586, 64
  br i1 %cmp11.i.i.i110.i.i.i.i, label %if.then12.i.i.i113.i.i.i.i, label %if.else21.i.i.i125.i.i.i.i

if.then12.i.i.i113.i.i.i.i:                       ; preds = %if.end4.i.i.i92.i.i.i.i
  %cmp13.i.i.i112.i.i.i.i = icmp sgt i32 %582, 2
  br i1 %cmp13.i.i.i112.i.i.i.i, label %if.then14.i.i.i118.i.i.i.i, label %if.else.i.i.i124.i.i.i.i

if.then14.i.i.i118.i.i.i.i:                       ; preds = %if.then12.i.i.i113.i.i.i.i
  %sh_prom.i.i.i114.i.i.i.i = zext i32 %div.i.i.i108.i.i.i.i to i64
  %shl.i.i.i115.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i114.i.i.i.i
  %conv.i.i.i116.i.i.i.i = uitofp i64 %shl.i.i.i115.i.i.i.i to double
  %mul.i.i.i117.i.i.i.i = fmul double %add23.i.i.i.i.i107.i.i.i.i, %conv.i.i.i116.i.i.i.i
  br label %if.end23.i.i.i131.i.i.i.i

if.else.i.i.i124.i.i.i.i:                         ; preds = %if.then12.i.i.i113.i.i.i.i
  %sh_prom16.i.i.i120.i.i.i.i = zext i32 %585 to i64
  %shl17.i.i.i121.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i120.i.i.i.i
  %conv18.i.i.i122.i.i.i.i = uitofp i64 %shl17.i.i.i121.i.i.i.i to double
  %div19.i.i.i123.i.i.i.i = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %conv18.i.i.i122.i.i.i.i
  br label %if.end23.i.i.i131.i.i.i.i

if.else21.i.i.i125.i.i.i.i:                       ; preds = %if.end4.i.i.i92.i.i.i.i
  %587 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  br label %if.end23.i.i.i131.i.i.i.i

if.end23.i.i.i131.i.i.i.i:                        ; preds = %if.else21.i.i.i125.i.i.i.i, %if.else.i.i.i124.i.i.i.i, %if.then14.i.i.i118.i.i.i.i
  %guess.i.i.i78.i.i.i.i.0 = phi double [ %mul.i.i.i117.i.i.i.i, %if.then14.i.i.i118.i.i.i.i ], [ %div19.i.i.i123.i.i.i.i, %if.else.i.i.i124.i.i.i.i ], [ %587, %if.else21.i.i.i125.i.i.i.i ]
  %.neg = mul nsw i32 %div.i.i.i108.i.i.i.i, -3
  %rem.i.i.i126.i.i.i.i.decomposed = add i32 %.frozen213, 2
  %add.i.i.i127.i.i.i.i = add i32 %rem.i.i.i126.i.i.i.i.decomposed, %.neg
  %588 = zext i32 %add.i.i.i127.i.i.i.i to i64
  %arrayidx1.i.i.i128.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %588
  %589 = load double, double addrspace(4)* %arrayidx1.i.i.i128.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i129.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.0, %589
  %cmp26.i.i.i130.i.i.i.i = icmp slt i32 %582, 1021
  br i1 %cmp26.i.i.i130.i.i.i.i, label %do.body.i.i.i142.i.i.i.i, label %do.body40.i.i.i153.i.i.i.i

do.body.i.i.i142.i.i.i.i:                         ; preds = %do.body.i.i.i142.i.i.i.i, %if.end23.i.i.i131.i.i.i.i
  %guess.i.i.i78.i.i.i.i.1 = phi double [ %mul24.i.i.i129.i.i.i.i, %if.end23.i.i.i131.i.i.i.i ], [ %mul35.i.i.i139.i.i.i.i, %do.body.i.i.i142.i.i.i.i ]
  %mul28.i.i.i132.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.1, %guess.i.i.i78.i.i.i.i.1
  %mul29.i.i.i133.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.1, %mul28.i.i.i132.i.i.i.i
  %add30.i.i.i134.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %mul29.i.i.i133.i.i.i.i
  %add31.i.i.i135.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add30.i.i.i134.i.i.i.i
  %add32.i.i.i136.i.i.i.i = fadd double %mul29.i.i.i133.i.i.i.i, %mul29.i.i.i133.i.i.i.i
  %add33.i.i.i137.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add32.i.i.i136.i.i.i.i
  %div34.i.i.i138.i.i.i.i = fdiv double %add31.i.i.i135.i.i.i.i, %add33.i.i.i137.i.i.i.i
  %mul35.i.i.i139.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.1, %div34.i.i.i138.i.i.i.i
  %sub36.i.i.i140.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i138.i.i.i.i
  %590 = tail call double @llvm.fabs.f64(double %sub36.i.i.i140.i.i.i.i) #3
  %cmp38.i.i.i141.i.i.i.i = fcmp ogt double %590, 0x3EC0000000000000
  br i1 %cmp38.i.i.i141.i.i.i.i, label %do.body.i.i.i142.i.i.i.i, label %if.end4.i.i.i.i.i.i.i

do.body40.i.i.i153.i.i.i.i:                       ; preds = %do.body40.i.i.i153.i.i.i.i, %if.end23.i.i.i131.i.i.i.i
  %guess.i.i.i78.i.i.i.i.2 = phi double [ %mul24.i.i.i129.i.i.i.i, %if.end23.i.i.i131.i.i.i.i ], [ %sub48.i.i.i150.i.i.i.i, %do.body40.i.i.i153.i.i.i.i ]
  %mul41.i.i.i143.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.2, %guess.i.i.i78.i.i.i.i.2
  %div42.i.i.i144.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %guess.i.i.i78.i.i.i.i.2
  %sub43.i.i.i145.i.i.i.i = fsub double %mul41.i.i.i143.i.i.i.i, %div42.i.i.i144.i.i.i.i
  %mul44.i.i.i146.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i147.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %mul41.i.i.i143.i.i.i.i
  %add46.i.i.i148.i.i.i.i = fadd double %mul44.i.i.i146.i.i.i.i, %div45.i.i.i147.i.i.i.i
  %div47.i.i.i149.i.i.i.i = fdiv double %sub43.i.i.i145.i.i.i.i, %add46.i.i.i148.i.i.i.i
  %sub48.i.i.i150.i.i.i.i = fsub double %guess.i.i.i78.i.i.i.i.2, %div47.i.i.i149.i.i.i.i
  %mul50.i.i.i151.i.i.i.i = fmul double %sub48.i.i.i150.i.i.i.i, 0x3EC0000000000000
  %591 = tail call double @llvm.fabs.f64(double %div47.i.i.i149.i.i.i.i) #3
  %cmp52.i.i.i152.i.i.i.i = fcmp olt double %mul50.i.i.i151.i.i.i.i, %591
  br i1 %cmp52.i.i.i152.i.i.i.i, label %do.body40.i.i.i153.i.i.i.i, label %if.end4.i.i.i.i.i.i.i

if.end4.i.i.i.i.i.i.i:                            ; preds = %do.body40.i.i.i153.i.i.i.i, %do.body.i.i.i142.i.i.i.i
  %guess.i.i.i78.i.i.i.i.3 = phi double [ %mul35.i.i.i139.i.i.i.i, %do.body.i.i.i142.i.i.i.i ], [ %sub48.i.i.i150.i.i.i.i, %do.body40.i.i.i153.i.i.i.i ]
  %592 = fneg double %guess.i.i.i78.i.i.i.i.3
  %593 = select i1 %cmp5.i.i.i91.i.i.i.i, double %592, double %guess.i.i.i78.i.i.i.i.3
  br i1 %cmp11.i.i.i110.i.i.i.i, label %if.then12.i.i.i32.i.i.i.i, label %if.else21.i.i.i44.i.i.i.i

if.then12.i.i.i32.i.i.i.i:                        ; preds = %if.end4.i.i.i.i.i.i.i
  %cmp13.i.i.i31.i.i.i.i = icmp sgt i32 %582, 2
  br i1 %cmp13.i.i.i31.i.i.i.i, label %if.then14.i.i.i37.i.i.i.i, label %if.else.i.i.i43.i.i.i.i

if.then14.i.i.i37.i.i.i.i:                        ; preds = %if.then12.i.i.i32.i.i.i.i
  %sh_prom.i.i.i33.i.i.i.i = zext i32 %div.i.i.i108.i.i.i.i to i64
  %shl.i.i.i34.i.i.i.i = shl nuw i64 1, %sh_prom.i.i.i33.i.i.i.i
  %conv.i.i.i35.i.i.i.i = uitofp i64 %shl.i.i.i34.i.i.i.i to double
  %mul.i.i.i36.i.i.i.i = fmul double %add23.i.i.i.i.i107.i.i.i.i, %conv.i.i.i35.i.i.i.i
  br label %if.end23.i.i.i50.i.i.i.i

if.else.i.i.i43.i.i.i.i:                          ; preds = %if.then12.i.i.i32.i.i.i.i
  %sh_prom16.i.i.i39.i.i.i.i = zext i32 %585 to i64
  %shl17.i.i.i40.i.i.i.i = shl nuw i64 1, %sh_prom16.i.i.i39.i.i.i.i
  %conv18.i.i.i41.i.i.i.i = uitofp i64 %shl17.i.i.i40.i.i.i.i to double
  %div19.i.i.i42.i.i.i.i = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %conv18.i.i.i41.i.i.i.i
  br label %if.end23.i.i.i50.i.i.i.i

if.else21.i.i.i44.i.i.i.i:                        ; preds = %if.end4.i.i.i.i.i.i.i
  %594 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  br label %if.end23.i.i.i50.i.i.i.i

if.end23.i.i.i50.i.i.i.i:                         ; preds = %if.else21.i.i.i44.i.i.i.i, %if.else.i.i.i43.i.i.i.i, %if.then14.i.i.i37.i.i.i.i
  %guess.i.i.i10.i.i.i.i.0 = phi double [ %mul.i.i.i36.i.i.i.i, %if.then14.i.i.i37.i.i.i.i ], [ %div19.i.i.i42.i.i.i.i, %if.else.i.i.i43.i.i.i.i ], [ %594, %if.else21.i.i.i44.i.i.i.i ]
  %mul24.i.i.i48.i.i.i.i = fmul double %589, %guess.i.i.i10.i.i.i.i.0
  br i1 %cmp26.i.i.i130.i.i.i.i, label %do.body.i.i.i61.i.i.i.i, label %do.body40.i.i.i72.i.i.i.i

do.body.i.i.i61.i.i.i.i:                          ; preds = %do.body.i.i.i61.i.i.i.i, %if.end23.i.i.i50.i.i.i.i
  %guess.i.i.i10.i.i.i.i.1 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %mul35.i.i.i58.i.i.i.i, %do.body.i.i.i61.i.i.i.i ]
  %mul28.i.i.i51.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.1, %guess.i.i.i10.i.i.i.i.1
  %mul29.i.i.i52.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.1, %mul28.i.i.i51.i.i.i.i
  %add30.i.i.i53.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %mul29.i.i.i52.i.i.i.i
  %add31.i.i.i54.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add30.i.i.i53.i.i.i.i
  %add32.i.i.i55.i.i.i.i = fadd double %mul29.i.i.i52.i.i.i.i, %mul29.i.i.i52.i.i.i.i
  %add33.i.i.i56.i.i.i.i = fadd double %z.addr.i.i.i76.i.i.i.i.0, %add32.i.i.i55.i.i.i.i
  %div34.i.i.i57.i.i.i.i = fdiv double %add31.i.i.i54.i.i.i.i, %add33.i.i.i56.i.i.i.i
  %mul35.i.i.i58.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.1, %div34.i.i.i57.i.i.i.i
  %sub36.i.i.i59.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i57.i.i.i.i
  %595 = tail call double @llvm.fabs.f64(double %sub36.i.i.i59.i.i.i.i) #3
  %cmp38.i.i.i60.i.i.i.i = fcmp ogt double %595, 0x3EC0000000000000
  br i1 %cmp38.i.i.i60.i.i.i.i, label %do.body.i.i.i61.i.i.i.i, label %if.end54.i.i.i.i.i.i.i

do.body40.i.i.i72.i.i.i.i:                        ; preds = %do.body40.i.i.i72.i.i.i.i, %if.end23.i.i.i50.i.i.i.i
  %guess.i.i.i10.i.i.i.i.2 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %sub48.i.i.i69.i.i.i.i, %do.body40.i.i.i72.i.i.i.i ]
  %mul41.i.i.i62.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.2, %guess.i.i.i10.i.i.i.i.2
  %div42.i.i.i63.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %guess.i.i.i10.i.i.i.i.2
  %sub43.i.i.i64.i.i.i.i = fsub double %mul41.i.i.i62.i.i.i.i, %div42.i.i.i63.i.i.i.i
  %mul44.i.i.i65.i.i.i.i = fmul double %guess.i.i.i10.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i66.i.i.i.i = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %mul41.i.i.i62.i.i.i.i
  %add46.i.i.i67.i.i.i.i = fadd double %mul44.i.i.i65.i.i.i.i, %div45.i.i.i66.i.i.i.i
  %div47.i.i.i68.i.i.i.i = fdiv double %sub43.i.i.i64.i.i.i.i, %add46.i.i.i67.i.i.i.i
  %sub48.i.i.i69.i.i.i.i = fsub double %guess.i.i.i10.i.i.i.i.2, %div47.i.i.i68.i.i.i.i
  %mul50.i.i.i70.i.i.i.i = fmul double %sub48.i.i.i69.i.i.i.i, 0x3EC0000000000000
  %596 = tail call double @llvm.fabs.f64(double %div47.i.i.i68.i.i.i.i) #3
  %cmp52.i.i.i71.i.i.i.i = fcmp olt double %mul50.i.i.i70.i.i.i.i, %596
  br i1 %cmp52.i.i.i71.i.i.i.i, label %do.body40.i.i.i72.i.i.i.i, label %if.end54.i.i.i.i.i.i.i

if.end54.i.i.i.i.i.i.i:                           ; preds = %do.body40.i.i.i72.i.i.i.i, %do.body.i.i.i61.i.i.i.i
  %guess.i.i.i10.i.i.i.i.3 = phi double [ %mul35.i.i.i58.i.i.i.i, %do.body.i.i.i61.i.i.i.i ], [ %sub48.i.i.i69.i.i.i.i, %do.body40.i.i.i72.i.i.i.i ]
  %597 = fneg double %guess.i.i.i10.i.i.i.i.3
  %598 = select i1 %cmp5.i.i.i91.i.i.i.i, double %597, double %guess.i.i.i10.i.i.i.i.3
  br label %if.end7.i.i.i.i.i.i.i

if.end7.i.i.i.i.i.i.i:                            ; preds = %if.end54.i.i.i.i.i.i.i, %if.then73.i.i.i.i
  %retval.0.i.i.i156.i.i.i.i162 = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %593, %if.end54.i.i.i.i.i.i.i ]
  %retval.0.i.i.i.i.i.i.i = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %598, %if.end54.i.i.i.i.i.i.i ]
  %mul76.i.i.i.i = fmul double %retval.0.i.i.i156.i.i.i.i162, %retval.0.i.i.i.i.i.i.i
  %mul79.i.i.i.i = fmul double %mul76.i.i.i.i, 0x3FFD8639FDCB60EB
  %div80.i.i.i.i = fdiv double 1.000000e+00, %mul79.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

cond.false7.i.i.i:                                ; preds = %if.end14.i.i
  %decision.interval4 = fcmp oge double %arrayidx.val, 2.500000e-01
  br i1 %decision.interval4, label %decision.dispatch3, label %if.else9.i28.i.i.i, !decision.condition_prefix !6

if.then.i21.i.i.i:                                ; preds = %decision.dispatch3
  %sub.i5.i.i.i = fadd double %arrayidx.val, -3.750000e-01
  %mul.i.i.i6.i.i.i = fmul double %sub.i5.i.i.i, %sub.i5.i.i.i
  %mul1.i.i.i7.i.i.i = fmul double %mul.i.i.i6.i.i.i, 0x40132BDEE3243B58
  %add.i.i.i8.i.i.i = fadd double %mul1.i.i.i7.i.i.i, 0xC0360FDD97954BA2
  %mul5.i.i.i9.i.i.i = fmul double %mul.i.i.i6.i.i.i, 0x401CB5EDEDB31A3B
  %add7.i.i.i10.i.i.i = fadd double %mul5.i.i.i9.i.i.i, 0xC017CB97C9E45E0D
  %mul10.i.i.i11.i.i.i = fmul double %mul.i.i.i6.i.i.i, %add.i.i.i8.i.i.i
  %mul12.i.i.i12.i.i.i = fmul double %mul.i.i.i6.i.i.i, %add7.i.i.i10.i.i.i
  %add15.i.i.i13.i.i.i = fadd double %mul10.i.i.i11.i.i.i, 0x4027FEF192CFFD80
  %add18.i.i.i14.i.i.i = fadd double %mul12.i.i.i12.i.i.i, 0x3FF83BDAD25D5F48
  %mul20.i.i.i15.i.i.i = fmul double %mul.i.i.i6.i.i.i, %add15.i.i.i13.i.i.i
  %add23.i.i.i16.i.i.i = fadd double %mul20.i.i.i15.i.i.i, 0xBFF2C5AD0DCDC29A
  %mul25.i.i.i17.i.i.i = fmul double %sub.i5.i.i.i, %add18.i.i.i14.i.i.i
  %add28.i.i.i18.i.i.i = fadd double %mul25.i.i.i17.i.i.i, %add23.i.i.i16.i.i.i
  %mul1.i.i310.i.i.i.i = fmul double %mul.i.i.i6.i.i.i, 0x3FF693D2420640AD
  %599 = fsub double 0x401B5545C0CB5BDA, %mul1.i.i310.i.i.i.i
  %mul5.i.i312.i.i.i.i = fmul double %mul.i.i.i6.i.i.i, 0x40074E9A9F865729
  %add7.i.i313.i.i.i.i = fadd double %mul5.i.i312.i.i.i.i, 0xC016B372910B83AB
  %mul10.i.i314.i.i.i.i = fmul double %mul.i.i.i6.i.i.i, %599
  %mul12.i.i315.i.i.i.i = fmul double %mul.i.i.i6.i.i.i, %add7.i.i313.i.i.i.i
  %add15.i.i316.i.i.i.i = fadd double %mul10.i.i314.i.i.i.i, 0xC0138A29DF206C0B
  %add18.i.i317.i.i.i.i = fadd double %mul12.i.i315.i.i.i.i, 0x3FFC33F0B4C09D66
  %mul20.i.i318.i.i.i.i = fmul double %mul.i.i.i6.i.i.i, %add15.i.i316.i.i.i.i
  %add23.i.i319.i.i.i.i = fadd double %mul20.i.i318.i.i.i.i, 1.000000e+00
  %mul25.i.i320.i.i.i.i = fmul double %sub.i5.i.i.i, %add18.i.i317.i.i.i.i
  %add28.i.i321.i.i.i.i = fadd double %mul25.i.i320.i.i.i.i, %add23.i.i319.i.i.i.i
  %div.i20.i.i.i = fdiv double %add28.i.i.i18.i.i.i, %add28.i.i321.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i.pair.join

decision.dispatch3:                               ; preds = %cond.false7.i.i.i
  %cmp.i4.i.i.i = fcmp ult double %arrayidx.val, 3.750000e-01
  %decision.left = xor i1 %cmp.i4.i.i.i, true
  br i1 %decision.left, label %if.then.i21.i.i.i, label %if.then3.i27.i.i.i, !decision.merged_from !12, !decision.origin !13

if.then3.i27.i.i.i:                               ; preds = %decision.dispatch3
  %sub5.i24.i.i.i = fadd double %arrayidx.val, -2.500000e-01
  %mul.i.i296.i.i.i.i = fmul double %sub5.i24.i.i.i, %sub5.i24.i.i.i
  %mul1.i.i297.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, 0x402A50B00A1E7B86
  %add.i.i298.i.i.i.i = fadd double %mul1.i.i297.i.i.i.i, 0xC03EAAFBAB179207
  %mul5.i.i299.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, 0x403CBAD71AE3B29A
  %600 = fsub double 0x4040A8BCD7811DE4, %mul5.i.i299.i.i.i.i
  %mul10.i.i301.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, %add.i.i298.i.i.i.i
  %mul12.i.i302.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, %600
  %add15.i.i303.i.i.i.i = fadd double %mul10.i.i301.i.i.i.i, 0x402CB09090084637
  %add18.i.i304.i.i.i.i = fadd double %mul12.i.i302.i.i.i.i, 0xC013B1AD6B90733F
  %mul20.i.i305.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, %add15.i.i303.i.i.i.i
  %add23.i.i306.i.i.i.i = fadd double %mul20.i.i305.i.i.i.i, 0xBFFA1FFFE7A41296
  %mul25.i.i307.i.i.i.i = fmul double %sub5.i24.i.i.i, %add18.i.i304.i.i.i.i
  %add28.i.i308.i.i.i.i = fadd double %mul25.i.i307.i.i.i.i, %add23.i.i306.i.i.i.i
  %mul1.i.i286.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, 0x40296F06194D60C2
  %add.i.i287.i.i.i.i = fadd double %mul1.i.i286.i.i.i.i, 0xC030F25386AA802B
  %mul5.i.i288.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, 0x40199996D51EE9B7
  %601 = fsub double 0x40034649FCCCF81F, %mul5.i.i288.i.i.i.i
  %mul10.i.i290.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, %add.i.i287.i.i.i.i
  %mul12.i.i291.i.i.i.i = fmul double %mul.i.i296.i.i.i.i, %601
  %add15.i.i292.i.i.i.i = fadd double %mul10.i.i290.i.i.i.i, 0x40158CEB587D3265
  %add18.i.i293.i.i.i.i = fadd double %mul12.i.i291.i.i.i.i, 1.000000e+00
  %mul20.i.i294.i.i.i.i = fmul double %sub5.i24.i.i.i, %add15.i.i292.i.i.i.i
  %add23.i.i295.i.i.i.i = fadd double %add18.i.i293.i.i.i.i, %mul20.i.i294.i.i.i.i
  %div8.i26.i.i.i = fdiv double %add28.i.i308.i.i.i.i, %add23.i.i295.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i.pair.join

if.else9.i28.i.i.i:                               ; preds = %cond.false7.i.i.i
  %cmp10.i.i.i.i = fcmp ult double %arrayidx.val, 1.250000e-01
  br i1 %cmp10.i.i.i.i, label %if.else17.i.i.i.i, label %if.then11.i.i.i.i

if.then11.i.i.i.i:                                ; preds = %if.else9.i28.i.i.i
  %sub13.i.i.i.i = fadd double %arrayidx.val, -1.250000e-01
  %mul.i.i270.i.i.i.i = fmul double %sub13.i.i.i.i, %sub13.i.i.i.i
  %mul1.i.i271.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x406D392CDE09E490
  %602 = fsub double 0x408C7AAA9D225E9A, %mul1.i.i271.i.i.i.i
  %mul5.i.i273.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x408B6249334DA816
  %603 = fsub double 0x408C1B9BAF952B96, %mul5.i.i273.i.i.i.i
  %mul10.i.i275.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %602
  %mul12.i.i276.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %603
  %add15.i.i277.i.i.i.i = fadd double %mul10.i.i275.i.i.i.i, 0xC05E9BCF5C362E51
  %add18.i.i278.i.i.i.i = fadd double %mul12.i.i276.i.i.i.i, 0xC066A4A24A4E1713
  %mul20.i.i279.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add15.i.i277.i.i.i.i
  %mul22.i.i280.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add18.i.i278.i.i.i.i
  %add25.i.i281.i.i.i.i = fadd double %mul20.i.i279.i.i.i.i, 0xC04249A2BD20D346
  %add28.i.i282.i.i.i.i = fadd double %mul22.i.i280.i.i.i.i, 0xC001804F92FE2A82
  %mul30.i.i283.i.i.i.i = fmul double %sub13.i.i.i.i, %add25.i.i281.i.i.i.i
  %add33.i.i284.i.i.i.i = fadd double %add28.i.i282.i.i.i.i, %mul30.i.i283.i.i.i.i
  %mul1.i.i256.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x405E5232607614DB
  %add.i.i257.i.i.i.i = fadd double %mul1.i.i256.i.i.i.i, 0xC0809E1D789AFFE5
  %mul5.i.i258.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x404C078043CB129C
  %604 = fsub double 0xC0320C17B7F0ED52, %mul5.i.i258.i.i.i.i
  %mul10.i.i260.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add.i.i257.i.i.i.i
  %mul12.i.i261.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %604
  %add15.i.i262.i.i.i.i = fadd double %mul10.i.i260.i.i.i.i, 0x4071A64A34042F35
  %add18.i.i263.i.i.i.i = fadd double %mul12.i.i261.i.i.i.i, 0x405F12CC60181A8F
  %mul20.i.i264.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add15.i.i262.i.i.i.i
  %mul22.i.i265.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add18.i.i263.i.i.i.i
  %add25.i.i266.i.i.i.i = fadd double %mul20.i.i264.i.i.i.i, 0x40332E0500972875
  %add28.i.i267.i.i.i.i = fadd double %mul22.i.i265.i.i.i.i, 1.000000e+00
  %mul30.i.i268.i.i.i.i = fmul double %sub13.i.i.i.i, %add25.i.i266.i.i.i.i
  %add33.i.i269.i.i.i.i = fadd double %add28.i.i267.i.i.i.i, %mul30.i.i268.i.i.i.i
  %div16.i.i.i.i = fdiv double %add33.i.i284.i.i.i.i, %add33.i.i269.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else17.i.i.i.i:                                ; preds = %if.else9.i28.i.i.i
  %605 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %arrayidx.val) #3
  %606 = add nsw i32 %605, -1
  %607 = tail call double @llvm.fabs.f64(double %arrayidx.val) #4
  %608 = fcmp oeq double %607, 0x7FF0000000000000
  %609 = select i1 %608, i32 2147483647, i32 %606
  %610 = fcmp oeq double %arrayidx.val, 0.000000e+00
  %611 = select i1 %610, i32 -2147483648, i32 %609
  %cmp19.i.i.i.i = icmp sgt i32 %611, -5
  br i1 %cmp19.i.i.i.i, label %if.then20.i.i.i.i, label %if.else27.i.i.i.i

if.then20.i.i.i.i:                                ; preds = %if.else17.i.i.i.i
  %612 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 3) #3
  %613 = tail call double @llvm.amdgcn.frexp.mant.f64(double %612) #3
  %614 = fcmp olt double %613, 0x3FE5555555555555
  %615 = zext i1 %614 to i32
  %616 = tail call double @llvm.amdgcn.ldexp.f64(double %613, i32 %615) #3
  %617 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %612) #3
  %618 = sub nsw i32 %617, %615
  %619 = fadd double %616, -1.000000e+00
  %620 = fadd double %616, 1.000000e+00
  %621 = fsub double %620, %616
  %622 = fsub double %620, %621
  %623 = fsub double %616, %622
  %624 = fsub double 1.000000e+00, %621
  %625 = fadd double %624, %623
  %626 = tail call double @llvm.amdgcn.rcp.f64(double %620) #3
  %627 = fneg double %620
  %628 = tail call double @llvm.fma.f64(double %627, double %626, double 1.000000e+00) #3
  %629 = tail call double @llvm.fma.f64(double %628, double %626, double %626) #3
  %630 = tail call double @llvm.fma.f64(double %627, double %629, double 1.000000e+00) #3
  %631 = tail call double @llvm.fma.f64(double %630, double %629, double %629) #3
  %632 = fmul double %619, %631
  %633 = fmul double %620, %632
  %634 = fneg double %633
  %635 = tail call double @llvm.fma.f64(double %632, double %620, double %634) #3
  %636 = tail call double @llvm.fma.f64(double %632, double %625, double %635) #3
  %637 = fadd double %633, %636
  %638 = fsub double %637, %633
  %639 = fsub double %636, %638
  %640 = fsub double %619, %637
  %641 = fsub double %619, %640
  %642 = fsub double %641, %637
  %643 = fsub double %642, %639
  %644 = fadd double %640, %643
  %645 = fmul double %631, %644
  %646 = fadd double %632, %645
  %647 = fsub double %646, %632
  %648 = fsub double %645, %647
  %649 = fmul double %646, %646
  %650 = fneg double %649
  %651 = tail call double @llvm.fma.f64(double %646, double %646, double %650) #3
  %652 = fmul double %648, 2.000000e+00
  %653 = tail call double @llvm.fma.f64(double %646, double %652, double %651) #3
  %654 = tail call double @llvm.fma.f64(double %648, double %648, double %653) #3
  %655 = fadd double %649, %654
  %656 = fsub double %655, %649
  %657 = fsub double %654, %656
  %658 = tail call double @llvm.fma.f64(double %655, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %659 = tail call double @llvm.fma.f64(double %655, double %658, double 0x3FC7474DD7F4DF2E) #3
  %660 = tail call double @llvm.fma.f64(double %655, double %659, double 0x3FCC71C016291751) #3
  %661 = tail call double @llvm.fma.f64(double %655, double %660, double 0x3FD249249B27ACF1) #3
  %662 = tail call double @llvm.fma.f64(double %655, double %661, double 0x3FD99999998EF7B6) #3
  %663 = tail call double @llvm.fma.f64(double %655, double %662, double 0x3FE5555555555780) #3
  %664 = tail call double @llvm.amdgcn.ldexp.f64(double %646, i32 1) #3
  %665 = tail call double @llvm.amdgcn.ldexp.f64(double %648, i32 1) #3
  %666 = fmul double %646, %655
  %667 = fneg double %666
  %668 = tail call double @llvm.fma.f64(double %646, double %655, double %667) #3
  %669 = fmul double %648, %655
  %670 = tail call double @llvm.fma.f64(double %646, double %657, double %669) #3
  %671 = fadd double %668, %670
  %672 = fadd double %666, %671
  %673 = fsub double %672, %666
  %674 = fsub double %671, %673
  %675 = fmul double %672, %663
  %676 = fneg double %675
  %677 = tail call double @llvm.fma.f64(double %672, double %663, double %676) #3
  %678 = tail call double @llvm.fma.f64(double %674, double %663, double %677) #3
  %679 = fadd double %675, %678
  %680 = fsub double %679, %675
  %681 = fsub double %678, %680
  %682 = fadd double %664, %679
  %683 = fsub double %682, %664
  %684 = fsub double %682, %683
  %685 = fsub double %664, %684
  %686 = fsub double %679, %683
  %687 = fadd double %686, %685
  %688 = fadd double %665, %681
  %689 = fsub double %688, %665
  %690 = fsub double %688, %689
  %691 = fsub double %665, %690
  %692 = fsub double %681, %689
  %693 = fadd double %692, %691
  %694 = fadd double %688, %687
  %695 = fadd double %682, %694
  %696 = fsub double %695, %682
  %697 = fsub double %694, %696
  %698 = fadd double %693, %697
  %699 = fadd double %695, %698
  %700 = fsub double %699, %695
  %701 = fsub double %698, %700
  %702 = sitofp i32 %618 to double
  %703 = fmul double %699, 0x3FF71547652B82FE
  %704 = fneg double %703
  %705 = fmul double %699, 0x3C7777D0FFDA0D24
  %706 = insertelement <2 x double> undef, double %699, i32 0
  %707 = insertelement <2 x double> %706, double %701, i32 1
  %708 = insertelement <2 x double> undef, double %704, i32 0
  %709 = insertelement <2 x double> %708, double %705, i32 1
  %710 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %707, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %709) #3
  %711 = extractelement <2 x double> %710, i32 0
  %712 = extractelement <2 x double> %710, i32 1
  %713 = fadd double %711, %712
  %714 = fadd double %703, %713
  %715 = fsub double %714, %703
  %716 = fsub double %713, %715
  %717 = fadd double %714, %702
  %718 = fsub double %717, %702
  %719 = fsub double %718, %717
  %720 = fadd double %719, %702
  %721 = fsub double %714, %718
  %722 = fadd double %721, %720
  %723 = fadd double %716, %722
  %724 = fadd double %717, %723
  %725 = tail call double @llvm.fabs.f64(double %612) #4
  %726 = fcmp oeq double %725, 0x7FF0000000000000
  %727 = select i1 %726, double %612, double %724
  %728 = fcmp olt double %612, 0.000000e+00
  %729 = select i1 %728, double 0x7FF8000000000000, double %727
  %730 = fcmp oeq double %612, 0.000000e+00
  %731 = select i1 %730, double 0xFFF0000000000000, double %729
  %mul.i.i244.i.i.i.i = fmul double %731, %731
  %mul1.i.i245.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F1989D450BBA5CA
  %732 = fsub double 0xBFBD94CCEC41CB08, %mul1.i.i245.i.i.i.i
  %mul5.i.i247.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F7B3A00DD9C9429
  %733 = fsub double 0xBFE8DDD719DA7D3E, %mul5.i.i247.i.i.i.i
  %mul10.i.i249.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %732
  %mul12.i.i250.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %733
  %add15.i.i251.i.i.i.i = fadd double %mul10.i.i249.i.i.i.i, 0xC001974D2C397C76
  %add18.i.i252.i.i.i.i = fadd double %mul12.i.i250.i.i.i.i, 0xC001804F92FE2A82
  %734 = fmul double %731, %add15.i.i251.i.i.i.i
  %add23.i.i254.i.i.i.i = fsub double %add18.i.i252.i.i.i.i, %734
  %mul1.i.i234.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3EDBEC7AF5AC0D6F
  %add.i.i235.i.i.i.i = fadd double %mul1.i.i234.i.i.i.i, 0x3F98BA1DB321D0E9
  %mul5.i.i236.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F4ED662BB480251
  %add7.i.i237.i.i.i.i = fadd double %mul5.i.i236.i.i.i.i, 0x3FCBD444F5D4FCC2
  %mul10.i.i238.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %add.i.i235.i.i.i.i
  %mul12.i.i239.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %add7.i.i237.i.i.i.i
  %add15.i.i240.i.i.i.i = fadd double %mul10.i.i238.i.i.i.i, 0x3FE957680773BEB6
  %add18.i.i241.i.i.i.i = fadd double %mul12.i.i239.i.i.i.i, 1.000000e+00
  %735 = fmul double %731, %add15.i.i240.i.i.i.i
  %add23.i.i243.i.i.i.i = fsub double %add18.i.i241.i.i.i.i, %735
  %div26.i.i.i.i = fdiv double %add23.i.i254.i.i.i.i, %add23.i.i243.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else27.i.i.i.i:                                ; preds = %if.else17.i.i.i.i
  %cmp106.i.i.i.i = icmp sgt i32 %611, -1025
  br i1 %cmp106.i.i.i.i, label %decision.dispatch1, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, !decision.condition_prefix !6

decision.dispatch4:                               ; preds = %decision.dispatch1
  %cmp40.i.i.i.i = icmp sgt i32 %611, -17
  %merged.select = select i1 %cmp40.i.i.i.i, i32 -9, i32 -33
  %736 = icmp sgt i32 %611, %merged.select
  %merged.select36 = select i1 %cmp40.i.i.i.i, i32 4, i32 16
  %merged.select37 = select i1 %cmp40.i.i.i.i, i32 8, i32 32
  %737 = select i1 %736, i32 %merged.select36, i32 %merged.select37
  %738 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %737) #3
  %739 = tail call double @llvm.amdgcn.frexp.mant.f64(double %738) #3
  %740 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %738) #3
  %741 = tail call double @llvm.fabs.f64(double %738) #4
  %742 = fcmp olt double %739, 0x3FE5555555555555
  %743 = zext i1 %742 to i32
  %744 = tail call double @llvm.amdgcn.ldexp.f64(double %739, i32 %743) #3
  %745 = sub nsw i32 %740, %743
  %746 = fadd double %744, -1.000000e+00
  %747 = fadd double %744, 1.000000e+00
  %748 = fsub double %747, %744
  %749 = tail call double @llvm.amdgcn.rcp.f64(double %747) #3
  %750 = fneg double %747
  %751 = fsub double %747, %748
  %752 = fsub double 1.000000e+00, %748
  %753 = tail call double @llvm.fma.f64(double %750, double %749, double 1.000000e+00) #3
  %754 = fsub double %744, %751
  %755 = tail call double @llvm.fma.f64(double %753, double %749, double %749) #3
  %756 = fadd double %752, %754
  %757 = tail call double @llvm.fma.f64(double %750, double %755, double 1.000000e+00) #3
  %758 = tail call double @llvm.fma.f64(double %757, double %755, double %755) #3
  %759 = fmul double %746, %758
  %760 = fmul double %747, %759
  %761 = fneg double %760
  %762 = tail call double @llvm.fma.f64(double %759, double %747, double %761) #3
  %763 = tail call double @llvm.fma.f64(double %759, double %756, double %762) #3
  %764 = fadd double %760, %763
  %765 = fsub double %764, %760
  %766 = fsub double %746, %764
  %767 = fsub double %763, %765
  %768 = fsub double %746, %766
  %769 = fsub double %768, %764
  %770 = fsub double %769, %767
  %771 = fadd double %766, %770
  %772 = fmul double %758, %771
  %773 = fadd double %759, %772
  %774 = fsub double %773, %759
  %775 = fmul double %773, %773
  %776 = tail call double @llvm.amdgcn.ldexp.f64(double %773, i32 1) #3
  %777 = fsub double %772, %774
  %778 = fneg double %775
  %779 = fmul double %777, 2.000000e+00
  %780 = tail call double @llvm.amdgcn.ldexp.f64(double %777, i32 1) #3
  %781 = tail call double @llvm.fma.f64(double %773, double %773, double %778) #3
  %782 = tail call double @llvm.fma.f64(double %773, double %779, double %781) #3
  %783 = tail call double @llvm.fma.f64(double %777, double %777, double %782) #3
  %784 = fadd double %775, %783
  %785 = fsub double %784, %775
  %786 = tail call double @llvm.fma.f64(double %784, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %787 = fmul double %773, %784
  %788 = fmul double %777, %784
  %789 = fsub double %783, %785
  %790 = tail call double @llvm.fma.f64(double %784, double %786, double 0x3FC7474DD7F4DF2E) #3
  %791 = fneg double %787
  %792 = tail call double @llvm.fma.f64(double %773, double %789, double %788) #3
  %793 = tail call double @llvm.fma.f64(double %784, double %790, double 0x3FCC71C016291751) #3
  %794 = tail call double @llvm.fma.f64(double %773, double %784, double %791) #3
  %795 = tail call double @llvm.fma.f64(double %784, double %793, double 0x3FD249249B27ACF1) #3
  %796 = fadd double %794, %792
  %797 = tail call double @llvm.fma.f64(double %784, double %795, double 0x3FD99999998EF7B6) #3
  %798 = fadd double %787, %796
  %799 = tail call double @llvm.fma.f64(double %784, double %797, double 0x3FE5555555555780) #3
  %800 = fsub double %798, %787
  %801 = fmul double %798, %799
  %802 = fsub double %796, %800
  %803 = fneg double %801
  %804 = tail call double @llvm.fma.f64(double %798, double %799, double %803) #3
  %805 = tail call double @llvm.fma.f64(double %802, double %799, double %804) #3
  %806 = fadd double %801, %805
  %807 = fsub double %806, %801
  %808 = fadd double %776, %806
  %809 = fsub double %805, %807
  %810 = fsub double %808, %776
  %811 = fadd double %780, %809
  %812 = fsub double %808, %810
  %813 = fsub double %806, %810
  %814 = fsub double %811, %780
  %815 = fsub double %776, %812
  %816 = fsub double %811, %814
  %817 = fsub double %809, %814
  %818 = fadd double %813, %815
  %819 = fsub double %780, %816
  %820 = fadd double %811, %818
  %821 = fadd double %817, %819
  %822 = fadd double %808, %820
  %823 = fsub double %822, %808
  %824 = fsub double %820, %823
  %825 = fadd double %821, %824
  %826 = fadd double %822, %825
  %827 = fsub double %826, %822
  %828 = fmul double %826, 0x3FF71547652B82FE
  %829 = fmul double %826, 0x3C7777D0FFDA0D24
  %830 = fsub double %825, %827
  %831 = fneg double %828
  br i1 %736, label %merged.bb33, label %merged.bb34

decision.dispatch1:                               ; preds = %if.else27.i.i.i.i
  %cmp62.i.i.i.i = icmp sgt i32 %611, -65
  br i1 %cmp62.i.i.i.i, label %decision.dispatch4, label %decision.dispatch, !decision.merged_from !14, !decision.origin !15

decision.dispatch:                                ; preds = %decision.dispatch1
  %cmp84.i.i.i.i = icmp sgt i32 %611, -257
  %merged.select39 = select i1 %cmp84.i.i.i.i, i32 -129, i32 -513
  %832 = icmp sgt i32 %611, %merged.select39
  %merged.select40 = select i1 %cmp84.i.i.i.i, i32 64, i32 256
  %merged.select41 = select i1 %cmp84.i.i.i.i, i32 128, i32 512
  %833 = select i1 %832, i32 %merged.select40, i32 %merged.select41
  %834 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %833) #3
  %835 = tail call double @llvm.amdgcn.frexp.mant.f64(double %834) #3
  %836 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %834) #3
  %837 = tail call double @llvm.fabs.f64(double %834) #4
  %838 = fcmp olt double %835, 0x3FE5555555555555
  %839 = zext i1 %838 to i32
  %840 = tail call double @llvm.amdgcn.ldexp.f64(double %835, i32 %839) #3
  %841 = sub nsw i32 %836, %839
  %842 = fadd double %840, -1.000000e+00
  %843 = fadd double %840, 1.000000e+00
  %844 = fsub double %843, %840
  %845 = tail call double @llvm.amdgcn.rcp.f64(double %843) #3
  %846 = fneg double %843
  %847 = fsub double %843, %844
  %848 = fsub double 1.000000e+00, %844
  %849 = tail call double @llvm.fma.f64(double %846, double %845, double 1.000000e+00) #3
  %850 = fsub double %840, %847
  %851 = tail call double @llvm.fma.f64(double %849, double %845, double %845) #3
  %852 = fadd double %848, %850
  %853 = tail call double @llvm.fma.f64(double %846, double %851, double 1.000000e+00) #3
  %854 = tail call double @llvm.fma.f64(double %853, double %851, double %851) #3
  %855 = fmul double %842, %854
  %856 = fmul double %843, %855
  %857 = fneg double %856
  %858 = tail call double @llvm.fma.f64(double %855, double %843, double %857) #3
  %859 = tail call double @llvm.fma.f64(double %855, double %852, double %858) #3
  %860 = fadd double %856, %859
  %861 = fsub double %860, %856
  %862 = fsub double %842, %860
  %863 = fsub double %859, %861
  %864 = fsub double %842, %862
  %865 = fsub double %864, %860
  %866 = fsub double %865, %863
  %867 = fadd double %862, %866
  %868 = fmul double %854, %867
  %869 = fadd double %855, %868
  %870 = fsub double %869, %855
  %871 = fmul double %869, %869
  %872 = tail call double @llvm.amdgcn.ldexp.f64(double %869, i32 1) #3
  %873 = fsub double %868, %870
  %874 = fneg double %871
  %875 = fmul double %873, 2.000000e+00
  %876 = tail call double @llvm.amdgcn.ldexp.f64(double %873, i32 1) #3
  %877 = tail call double @llvm.fma.f64(double %869, double %869, double %874) #3
  %878 = tail call double @llvm.fma.f64(double %869, double %875, double %877) #3
  %879 = tail call double @llvm.fma.f64(double %873, double %873, double %878) #3
  %880 = fadd double %871, %879
  %881 = fsub double %880, %871
  %882 = tail call double @llvm.fma.f64(double %880, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %883 = fmul double %869, %880
  %884 = fmul double %873, %880
  %885 = fsub double %879, %881
  %886 = tail call double @llvm.fma.f64(double %880, double %882, double 0x3FC7474DD7F4DF2E) #3
  %887 = fneg double %883
  %888 = tail call double @llvm.fma.f64(double %869, double %885, double %884) #3
  %889 = tail call double @llvm.fma.f64(double %880, double %886, double 0x3FCC71C016291751) #3
  %890 = tail call double @llvm.fma.f64(double %869, double %880, double %887) #3
  %891 = tail call double @llvm.fma.f64(double %880, double %889, double 0x3FD249249B27ACF1) #3
  %892 = fadd double %890, %888
  %893 = tail call double @llvm.fma.f64(double %880, double %891, double 0x3FD99999998EF7B6) #3
  %894 = fadd double %883, %892
  %895 = tail call double @llvm.fma.f64(double %880, double %893, double 0x3FE5555555555780) #3
  %896 = fsub double %894, %883
  %897 = fmul double %894, %895
  %898 = fsub double %892, %896
  %899 = fneg double %897
  %900 = tail call double @llvm.fma.f64(double %894, double %895, double %899) #3
  %901 = tail call double @llvm.fma.f64(double %898, double %895, double %900) #3
  %902 = fadd double %897, %901
  %903 = fsub double %902, %897
  %904 = fadd double %872, %902
  %905 = fsub double %901, %903
  %906 = fsub double %904, %872
  %907 = fadd double %876, %905
  %908 = fsub double %904, %906
  %909 = fsub double %902, %906
  %910 = fsub double %907, %876
  %911 = fsub double %872, %908
  %912 = fsub double %907, %910
  %913 = fsub double %905, %910
  %914 = fadd double %909, %911
  %915 = fsub double %876, %912
  %916 = fadd double %907, %914
  %917 = fadd double %913, %915
  %918 = fadd double %904, %916
  %919 = fsub double %918, %904
  %920 = fsub double %916, %919
  %921 = fadd double %917, %920
  %922 = fadd double %918, %921
  %923 = fsub double %922, %918
  %924 = fmul double %922, 0x3FF71547652B82FE
  %925 = fmul double %922, 0x3C7777D0FFDA0D24
  %926 = fsub double %921, %923
  %927 = fneg double %924
  br i1 %832, label %merged.bb36, label %merged.bb37

dataflow1:                                        ; preds = %decision.dispatch2
  %928 = fmul double %10, 0x4050AAC38C60A1E3
  %929 = fmul double %10, 0x3FF51F0306685285
  %930 = fmul double %10, 0x3FEFDC5AEE1525E4
  %931 = fsub double 0x40548E4AE13E33D8, %928
  %932 = fsub double 0xBFEEB82FAA589934, %929
  %933 = fsub double 0x4043A793DEC20DEB, %930
  %934 = fmul double %10, %14
  %935 = fmul double %10, %933
  %936 = fadd double %934, 0xC04860792DC1D02E
  %937 = fadd double %935, 0xC04B158FF790C730
  %938 = fmul double %10, %936
  %939 = fadd double %938, 0xC005F196AB7EF904
  br label %dataflow3

dataflow2:                                        ; preds = %decision.dispatch2
  %940 = fmul double %10, 0x409819CEF5B4E6C7
  %941 = fmul double %10, 0x4071AEC837B9190D
  %942 = fadd double %940, 0xC096FC492E087B38
  %943 = fsub double 0x406A5A0FD2D4B901, %941
  %944 = fmul double %10, %14
  %945 = fadd double %944, 0x4034FFCB850049DF
  br label %dataflow3

dataflow3:                                        ; preds = %dataflow2, %dataflow1
  %946 = phi double [ 0x40354F2A1256B431, %dataflow2 ], [ 0x4020675EC4F85A38, %dataflow1 ]
  %947 = phi double [ 0x3FFB3E8B8B7EC8F9, %dataflow2 ], [ 0x3FDED118296B2018, %dataflow1 ]
  %948 = phi double [ 0x4063AA2F5D62DCD3, %dataflow2 ], [ 0x403058D46A8EC004, %dataflow1 ]
  %949 = phi double [ 0x407BA4300BFE5087, %dataflow2 ], [ 0xC02E8C55CA7195EF, %dataflow1 ]
  %950 = phi double [ 0x4036AD73494335DA, %dataflow2 ], [ 0xC0407FAA65922A12, %dataflow1 ]
  %951 = phi double [ 0xC083E59B9D34A0F1, %dataflow2 ], [ 0x401A11C0BB0DC22E, %dataflow1 ]
  %952 = phi double [ 0x406113A5A6902AC1, %dataflow2 ], [ %932, %dataflow1 ]
  %953 = phi double [ %942, %dataflow2 ], [ %931, %dataflow1 ]
  %954 = phi double [ %943, %dataflow2 ], [ %937, %dataflow1 ]
  %955 = phi double [ %945, %dataflow2 ], [ %939, %dataflow1 ]
  %956 = fmul double %10, %952
  %957 = fmul double %10, %953
  %958 = fadd double %956, %951
  %959 = fadd double %957, %950
  %960 = fmul double %10, %958
  %961 = fmul double %10, %954
  %962 = fmul double %10, %959
  %963 = fadd double %960, %949
  %964 = fadd double %961, %948
  %965 = fadd double %962, %947
  %966 = fmul double %9, %955
  %967 = fmul double %10, %963
  %968 = fmul double %10, %964
  %969 = fadd double %965, %966
  %970 = fadd double %967, %946
  %971 = fadd double %968, 1.000000e+00
  %972 = fmul double %9, %970
  %973 = fadd double %971, %972
  %974 = fdiv double %969, %973
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i.pair.join: ; preds = %if.then3.i27.i.i.i, %if.then.i21.i.i.i
  %retval.0.i.i.i.ph = phi double [ %div8.i26.i.i.i, %if.then3.i27.i.i.i ], [ %div.i20.i.i.i, %if.then.i21.i.i.i ]
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i: ; preds = %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i.pair.join, %merged.bb78, %merged.bb77, %dataflow3, %if.else27.i.i.i.i, %if.then20.i.i.i.i, %if.then11.i.i.i.i, %if.end7.i.i.i.i.i.i.i, %if.else71.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i
  %retval.0.i.i.i = phi double [ %div20.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i ], [ %div34.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i ], [ %div48.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i ], [ %div62.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i ], [ %div70.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i ], [ 0x7FF0000000000000, %if.else71.i.i.i.i ], [ %div80.i.i.i.i, %if.end7.i.i.i.i.i.i.i ], [ %div16.i.i.i.i, %if.then11.i.i.i.i ], [ %div26.i.i.i.i, %if.then20.i.i.i.i ], [ 0xFFF0000000000000, %if.else27.i.i.i.i ], [ %974, %dataflow3 ], [ %1046, %merged.bb77 ], [ %1089, %merged.bb78 ], [ %retval.0.i.i.i.ph, %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i.pair.join ]
  %add.i.i = fadd double %retval.0.i.i.i, 0.000000e+00
  br label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit

_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit: ; preds = %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, %lor.lhs.false2.i.i.i, %if.end8.i.i
  %retval.0.i.i = phi double [ 0x7FF8000000000000, %if.end8.i.i ], [ 0x7FF8000000000000, %lor.lhs.false2.i.i.i ], [ %add.i.i, %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i ]
  %arrayidx712 = getelementptr inbounds double, double addrspace(1)* %output.coerce, i64 %idxprom
  store double %retval.0.i.i, double addrspace(1)* %arrayidx712, align 8, !tbaa !8
  br label %if.end

if.end:                                           ; preds = %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, %entry
  ret void

merged.bb33:                                      ; preds = %decision.dispatch4
  %975 = insertelement <2 x double> undef, double %826, i32 0
  %976 = insertelement <2 x double> %975, double %830, i32 1
  %977 = insertelement <2 x double> undef, double %831, i32 0
  %978 = insertelement <2 x double> %977, double %829, i32 1
  %979 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %976, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %978) #3
  %980 = extractelement <2 x double> %979, i32 0
  %981 = extractelement <2 x double> %979, i32 1
  br label %merged.bb76

merged.bb34:                                      ; preds = %decision.dispatch4
  %982 = insertelement <2 x double> undef, double %826, i32 0
  %983 = insertelement <2 x double> %982, double %830, i32 1
  %984 = insertelement <2 x double> undef, double %831, i32 0
  %985 = insertelement <2 x double> %984, double %829, i32 1
  %986 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %983, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %985) #3
  %987 = extractelement <2 x double> %986, i32 0
  %988 = extractelement <2 x double> %986, i32 1
  br label %merged.bb76

merged.bb36:                                      ; preds = %decision.dispatch
  %989 = insertelement <2 x double> undef, double %922, i32 0
  %990 = insertelement <2 x double> %989, double %926, i32 1
  %991 = insertelement <2 x double> undef, double %927, i32 0
  %992 = insertelement <2 x double> %991, double %925, i32 1
  %993 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %990, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %992) #3
  %994 = extractelement <2 x double> %993, i32 0
  %995 = extractelement <2 x double> %993, i32 1
  br label %merged.bb76

merged.bb37:                                      ; preds = %decision.dispatch
  %996 = insertelement <2 x double> undef, double %922, i32 0
  %997 = insertelement <2 x double> %996, double %926, i32 1
  %998 = insertelement <2 x double> undef, double %927, i32 0
  %999 = insertelement <2 x double> %998, double %925, i32 1
  %1000 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %997, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %999) #3
  %1001 = extractelement <2 x double> %1000, i32 0
  %1002 = extractelement <2 x double> %1000, i32 1
  br label %merged.bb76

merged.bb76:                                      ; preds = %merged.bb37, %merged.bb36, %merged.bb34, %merged.bb33
  %merged.select105 = phi double [ 0xC004C929A952DE48, %merged.bb33 ], [ 0xC00D636ADAEC3C05, %merged.bb34 ], [ 0xC0207852FA1731C0, %merged.bb36 ], [ 0xC024F817DD06EE79, %merged.bb37 ]
  %merged.select104 = phi double [ 0xC001F1CD6A03BCAA, %merged.bb33 ], [ 0xBFF8595CA25899FD, %merged.bb34 ], [ 0xBFD9F6368DFEFDDF, %merged.bb36 ], [ 0xBFD06A8AF4A3FC55, %merged.bb37 ]
  %merged.select103 = phi double [ 0x3FE7235AE26E3A60, %merged.bb33 ], [ 0x3FD6E5B7AB236028, %merged.bb34 ], [ 0x3FA66506CA3FCEB3, %merged.bb36 ], [ 0x3F964BEF3074CF28, %merged.bb37 ]
  %merged.select102 = phi double [ 0x3FC92E7DCCD1B70C, %merged.bb33 ], [ 0x3FA8A45F1AE4ADBE, %merged.bb34 ], [ 0x3F478C82425FFDCE, %merged.bb36 ], [ 0x3F275783E6F9B4DA, %merged.bb37 ]
  %merged.select101 = phi double [ 0xBFE78F054AC7A90B, %merged.bb33 ], [ 0xBFCED54905311121, %merged.bb34 ], [ 0xBF7F5FDEC6827012, %merged.bb36 ], [ 0xBF63B612102F3C24, %merged.bb37 ]
  %merged.select100 = phi double [ 0xBFBD7935AC58B5B5, %merged.bb33 ], [ 0xBF92AE2345C460A0, %merged.bb34 ], [ 0xBF1232A95F4E8466, %merged.bb36 ], [ 0xBEE6B9C7BCE39403, %merged.bb37 ]
  %merged.select99 = phi double [ 0x3F999857B526C821, %merged.bb33 ], [ 0x3F68BF137C253BD1, %merged.bb34 ], [ 0x3ED71590B83839D8, %merged.bb36 ], [ 0x3EA6C7746378848A, %merged.bb37 ]
  %merged.select98 = phi double [ 0x3F586FC94B9EAD30, %merged.bb33 ], [ 0x3F1751EF5755C229, %merged.bb34 ], [ 0x3E553724D72BE5C7, %merged.bb36 ], [ 0x3E14D76BE5BA042B, %merged.bb37 ]
  %merged.select97 = phi double [ 0xBF81F96D17A7115B, %merged.bb33 ], [ 0xBF4625660A41D7B1, %merged.bb34 ], [ 0xBE94B8A80FB81310, %merged.bb36 ], [ 0xBE59BA2A0439E4A9, %merged.bb37 ]
  %merged.select96 = phi double [ 0xBF336C13BBA203F3, %merged.bb33 ], [ 0xBEE755F1646665DB, %merged.bb34 ], [ 0xBE050B1B8007F8FF, %merged.bb36 ], [ 0xBDB9FC7E20BD04CC, %merged.bb37 ]
  %merged.select95 = phi double [ 0x3F0330822740ADF9, %merged.bb33 ], [ 0x3EB20E304F6E5BCE, %merged.bb34 ], [ 0x3DC001D96C7E2C9D, %merged.bb36 ], [ 0x3D6F4FAB0C90F842, %merged.bb37 ]
  %merged.select94 = phi double [ 0x3E9090FBB4B042AE, %merged.bb33 ], [ 0x3E2EB2F3F6504F32, %merged.bb34 ], [ 0x3D0A81E9CB6A1EA5, %merged.bb36 ], [ 0x3CA9D032740CF69A, %merged.bb37 ]
  %merged.select93 = phi double [ 0x3ECBFD524C94F258, %merged.bb33 ], [ 0x3E70731CF2A765F0, %merged.bb34 ], [ 0x3D5CB3C39661DD79, %merged.bb36 ], [ 0x3D01A287ED1019B8, %merged.bb37 ]
  %merged.select92 = phi double [ 0x3E32022ABCFF5DE7, %merged.bb33 ], [ 0x3DC4C8BD76453064, %merged.bb34 ], [ 0x3C819FA1E5E36C20, %merged.bb36 ], [ 0x3C158FD8B3C1B0C0, %merged.bb37 ]
  %merged.select130 = phi double [ 0xC013B000D66B8269, %merged.bb33 ], [ 0xC019A861C808DCFC, %merged.bb34 ], [ 0xC02A92BAF87A7B72, %merged.bb36 ], [ 0xC030CB31255FFA09, %merged.bb37 ]
  %merged.select129 = phi double [ 0xBFEFD66AE54A0BCB, %merged.bb33 ], [ 0xBFE46D859460DB51, %merged.bb34 ], [ 0xBFC4B5F131A679CC, %merged.bb36 ], [ 0xBFBA19EDB555D8AD, %merged.bb37 ]
  %merged.select128 = phi double [ 0x3FC6B0CE3157BCB1, %merged.bb33 ], [ 0x3FB68627D1A51CB5, %merged.bb34 ], [ 0x3F86397D81A61D6E, %merged.bb36 ], [ 0x3F762C8C65771E78, %merged.bb37 ]
  %merged.select127 = phi double [ 0x3F882FD20DA34F30, %merged.bb33 ], [ 0x3F67D3564F778B21, %merged.bb34 ], [ 0x3F0730EC426E6E84, %merged.bb36 ], [ 0x3EE71602E8EA99F3, %merged.bb37 ]
  %merged.select126 = phi double [ 0xBFB3B5B6F694BB9E, %merged.bb33 ], [ 0xBF98ED20B1D6A6D8, %merged.bb34 ], [ 0xBF48C2CA21FD14A5, %merged.bb36 ], [ 0xBF2F1E266EB4C824, %merged.bb37 ]
  %merged.select125 = phi double [ 0xBF676495E4B7EAAA, %merged.bb33 ], [ 0xBF3D2E78945F9AC6, %merged.bb34 ], [ 0xBEBC6E261AE99633, %merged.bb36 ], [ 0xBE91D0F7FEBA5A35, %merged.bb37 ]
  %merged.select124 = phi double [ 0x3F380B62C1407B15, %merged.bb33 ], [ 0x3F077F4625619D43, %merged.bb34 ], [ 0x3E768F19E4302EF3, %merged.bb36 ], [ 0x3E46680C94743FD9, %merged.bb37 ]
  %merged.select123 = phi double [ 0x3ED66AFC954DE682, %merged.bb33 ], [ 0x3E95BA568EDD3BFB, %merged.bb34 ], [ 0x3DD49301DA58AEFA, %merged.bb36 ], [ 0x3D9463E48A976F97, %merged.bb37 ]
  %merged.select122 = phi double [ 0xBF0B3634004E0F5C, %merged.bb33 ], [ 0xBED0C1E92AD969EF, %merged.bb34 ], [ 0xBE2007A65CA14E38, %merged.bb36 ], [ 0xBDE40A018263D493, %merged.bb37 ]
  %merged.select121 = phi double [ 0xBE9C2F1FFD2FFECD, %merged.bb33 ], [ 0xBE512769C01EA7C5, %merged.bb34 ], [ 0xBD7021DF3392EE60, %merged.bb36 ], [ 0xBD241E51766A91FB, %merged.bb37 ]
  %merged.select120 = phi double [ 0x3E6129D961D79065, %merged.bb33 ], [ 0x3E107ECF99D6009A, %merged.bb34 ], [ 0x3D1ED0326F0CBDDC, %merged.bb36 ], [ 0x3CCE78F4A7F13C7D, %merged.bb37 ]
  %merged.select119 = phi double [ 0x3DCCD7C812F40049, %merged.bb33 ], [ 0x3D6B7BD497A2CD17, %merged.bb34 ], [ 0x3C495387D39D2504, %merged.bb36 ], [ 0x3BE8FEBB5A4047D7, %merged.bb37 ]
  %merged.select118 = phi double [ 0x3E1390C28573DB0F, %merged.bb33 ], [ 0x3DB79116B58241AA, %merged.bb34 ], [ 0x3CA5D280D4B5A285, %merged.bb36 ], [ 0x3C4B275AC5F91B68, %merged.bb37 ]
  %merged.select117 = phi double [ 0x3D5866A3E6D0F156, %merged.bb33 ], [ 0x3CED1FCD2AD8841F, %merged.bb34 ], [ 0x3BAA9A26E0297ED8, %merged.bb36 ], [ 0x3B408480D3491A50, %merged.bb37 ]
  %merged.select114 = phi double [ %738, %merged.bb33 ], [ %738, %merged.bb34 ], [ %834, %merged.bb36 ], [ %834, %merged.bb37 ]
  %merged.select113.in = phi double [ %741, %merged.bb33 ], [ %741, %merged.bb34 ], [ %837, %merged.bb36 ], [ %837, %merged.bb37 ]
  %merged.select110.in = phi i32 [ %745, %merged.bb33 ], [ %745, %merged.bb34 ], [ %841, %merged.bb36 ], [ %841, %merged.bb37 ]
  %merged.select108 = phi double [ %828, %merged.bb33 ], [ %828, %merged.bb34 ], [ %924, %merged.bb36 ], [ %924, %merged.bb37 ]
  %merged.select107 = phi double [ %981, %merged.bb33 ], [ %988, %merged.bb34 ], [ %995, %merged.bb36 ], [ %1002, %merged.bb37 ]
  %merged.select106 = phi double [ %980, %merged.bb33 ], [ %987, %merged.bb34 ], [ %994, %merged.bb36 ], [ %1001, %merged.bb37 ]
  %1003 = phi i1 [ %cmp40.i.i.i.i, %merged.bb33 ], [ %cmp40.i.i.i.i, %merged.bb34 ], [ %cmp84.i.i.i.i, %merged.bb36 ], [ %cmp84.i.i.i.i, %merged.bb37 ]
  %merged.select110 = sitofp i32 %merged.select110.in to double
  %merged.select113 = fcmp oeq double %merged.select113.in, 0x7FF0000000000000
  %merged.select115 = fcmp olt double %merged.select114, 0.000000e+00
  %merged.select116 = fcmp oeq double %merged.select114, 0.000000e+00
  br i1 %1003, label %merged.bb77, label %merged.bb78

merged.bb77:                                      ; preds = %merged.bb76
  %1004 = fadd double %merged.select106, %merged.select107
  %1005 = fadd double %merged.select108, %1004
  %1006 = fsub double %1005, %merged.select108
  %1007 = fadd double %1005, %merged.select110
  %1008 = fsub double %1004, %1006
  %1009 = fsub double %1007, %merged.select110
  %1010 = fsub double %1009, %1007
  %1011 = fsub double %1005, %1009
  %1012 = fadd double %1010, %merged.select110
  %1013 = fadd double %1011, %1012
  %1014 = fadd double %1008, %1013
  %1015 = fadd double %1007, %1014
  %1016 = select i1 %merged.select113, double %merged.select114, double %1015
  %1017 = select i1 %merged.select115, double 0x7FF8000000000000, double %1016
  %1018 = select i1 %merged.select116, double 0xFFF0000000000000, double %1017
  %1019 = fmul double %1018, %1018
  %1020 = fmul double %1019, %merged.select92
  %1021 = fmul double %1019, %merged.select93
  %1022 = fmul double %1019, %merged.select94
  %1023 = fmul double %1019, %merged.select95
  %1024 = fsub double %merged.select96, %1020
  %1025 = fsub double %merged.select97, %1021
  %1026 = fadd double %1022, %merged.select98
  %1027 = fadd double %1023, %merged.select99
  %1028 = fmul double %1019, %1024
  %1029 = fmul double %1019, %1025
  %1030 = fmul double %1019, %1026
  %1031 = fmul double %1019, %1027
  %1032 = fadd double %1028, %merged.select100
  %1033 = fadd double %1029, %merged.select101
  %1034 = fadd double %1030, %merged.select102
  %1035 = fadd double %1031, %merged.select103
  %1036 = fmul double %1019, %1032
  %1037 = fmul double %1019, %1033
  %1038 = fmul double %1019, %1034
  %1039 = fmul double %1018, %1035
  %1040 = fadd double %1036, %merged.select104
  %1041 = fadd double %1037, %merged.select105
  %1042 = fadd double %1038, 1.000000e+00
  %1043 = fmul double %1018, %1040
  %1044 = fsub double %1042, %1039
  %1045 = fsub double %1041, %1043
  %1046 = fdiv double %1045, %1044
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

merged.bb78:                                      ; preds = %merged.bb76
  %1047 = fadd double %merged.select106, %merged.select107
  %1048 = fadd double %merged.select108, %1047
  %1049 = fsub double %1048, %merged.select108
  %1050 = fadd double %1048, %merged.select110
  %1051 = fsub double %1047, %1049
  %1052 = fsub double %1050, %merged.select110
  %1053 = fsub double %1052, %1050
  %1054 = fsub double %1048, %1052
  %1055 = fadd double %1053, %merged.select110
  %1056 = fadd double %1054, %1055
  %1057 = fadd double %1051, %1056
  %1058 = fadd double %1050, %1057
  %1059 = select i1 %merged.select113, double %merged.select114, double %1058
  %1060 = select i1 %merged.select115, double 0x7FF8000000000000, double %1059
  %1061 = select i1 %merged.select116, double 0xFFF0000000000000, double %1060
  %1062 = fmul double %1061, %1061
  %1063 = fmul double %1062, %merged.select117
  %1064 = fmul double %1062, %merged.select118
  %1065 = fmul double %1062, %merged.select119
  %1066 = fmul double %1062, %merged.select120
  %1067 = fsub double %merged.select121, %1063
  %1068 = fsub double %merged.select122, %1064
  %1069 = fadd double %1065, %merged.select123
  %1070 = fadd double %1066, %merged.select124
  %1071 = fmul double %1062, %1067
  %1072 = fmul double %1062, %1068
  %1073 = fmul double %1062, %1069
  %1074 = fmul double %1062, %1070
  %1075 = fadd double %1071, %merged.select125
  %1076 = fadd double %1072, %merged.select126
  %1077 = fadd double %1073, %merged.select127
  %1078 = fadd double %1074, %merged.select128
  %1079 = fmul double %1062, %1075
  %1080 = fmul double %1062, %1076
  %1081 = fmul double %1062, %1077
  %1082 = fmul double %1061, %1078
  %1083 = fadd double %1079, %merged.select129
  %1084 = fadd double %1080, %merged.select130
  %1085 = fadd double %1081, 1.000000e+00
  %1086 = fmul double %1061, %1083
  %1087 = fsub double %1085, %1082
  %1088 = fsub double %1084, %1086
  %1089 = fdiv double %1088, %1087
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.frexp.exp.i32.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.frexp.mant.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i1 @llvm.amdgcn.class.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.ldexp.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rcp.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fma.v2f64(<2 x double>, <2 x double>, <2 x double>) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.abs.i32(i32, i1 immarg) #1

attributes #0 = { nofree norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="128" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }
attributes #4 = { nounwind readnone }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/charitha22/cgo22ae-darm-code.git e9bc0540325ad9806313d34e84fc901496fd8be6)"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i16 1, i16 1025}
!6 = !{}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = !{!"evaluate:%if.then.i21.i.i.i", !"evaluate:%if.then3.i27.i.i.i"}
!13 = !{!"merge(evaluate:%if.then.i21.i.i.i,evaluate:%if.then3.i27.i.i.i)"}
!14 = !{!"evaluate:%decision.dispatch4", !"evaluate:%decision.dispatch"}
!15 = !{!"merge(evaluate:%decision.dispatch4,evaluate:%decision.dispatch)"}
