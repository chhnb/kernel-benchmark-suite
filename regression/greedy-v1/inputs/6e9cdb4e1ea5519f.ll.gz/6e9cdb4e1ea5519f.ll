; ModuleID = '/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-repro.XpJFTn/LUD32/compat.ll'
source_filename = "/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-benchmarks/benchmarks/LUD/lud_kernel.hip.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

@_ZZ12lud_diagonalPfiiE6shadow = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16
@_ZZ13lud_perimeterPfiiE3dia = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16
@_ZZ13lud_perimeterPfiiE8peri_row = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16
@_ZZ13lud_perimeterPfiiE8peri_col = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16
@_ZZ12lud_internalPfiiE8peri_row = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16
@_ZZ12lud_internalPfiiE8peri_col = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z12lud_diagonalPfii(float addrspace(1)* nocapture %0, i32 %1, i32 %2) local_unnamed_addr #0 {
  %4 = mul nsw i32 %2, %1
  %5 = add nsw i32 %4, %2
  %6 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %7 = zext i32 %6 to i64
  %8 = sext i32 %5 to i64
  %9 = add nsw i64 %8, %7
  %10 = getelementptr inbounds float, float addrspace(1)* %0, i64 %9
  %11 = load float, float addrspace(1)* %10, align 4, !tbaa !6
  %12 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  store float %11, float addrspace(3)* %12, align 4, !tbaa !6
  %13 = add nsw i32 %5, %1
  %14 = sext i32 %13 to i64
  %15 = add nsw i64 %14, %7
  %16 = getelementptr inbounds float, float addrspace(1)* %0, i64 %15
  %17 = load float, float addrspace(1)* %16, align 4, !tbaa !6
  %18 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  store float %17, float addrspace(3)* %18, align 4, !tbaa !6
  %19 = add nsw i32 %13, %1
  %20 = sext i32 %19 to i64
  %21 = add nsw i64 %20, %7
  %22 = getelementptr inbounds float, float addrspace(1)* %0, i64 %21
  %23 = load float, float addrspace(1)* %22, align 4, !tbaa !6
  %24 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  store float %23, float addrspace(3)* %24, align 4, !tbaa !6
  %25 = add nsw i32 %19, %1
  %26 = sext i32 %25 to i64
  %27 = add nsw i64 %26, %7
  %28 = getelementptr inbounds float, float addrspace(1)* %0, i64 %27
  %29 = load float, float addrspace(1)* %28, align 4, !tbaa !6
  %30 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  store float %29, float addrspace(3)* %30, align 4, !tbaa !6
  %31 = add nsw i32 %25, %1
  %32 = sext i32 %31 to i64
  %33 = add nsw i64 %32, %7
  %34 = getelementptr inbounds float, float addrspace(1)* %0, i64 %33
  %35 = load float, float addrspace(1)* %34, align 4, !tbaa !6
  %36 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  store float %35, float addrspace(3)* %36, align 4, !tbaa !6
  %37 = add nsw i32 %31, %1
  %38 = sext i32 %37 to i64
  %39 = add nsw i64 %38, %7
  %40 = getelementptr inbounds float, float addrspace(1)* %0, i64 %39
  %41 = load float, float addrspace(1)* %40, align 4, !tbaa !6
  %42 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  store float %41, float addrspace(3)* %42, align 4, !tbaa !6
  %43 = add nsw i32 %37, %1
  %44 = sext i32 %43 to i64
  %45 = add nsw i64 %44, %7
  %46 = getelementptr inbounds float, float addrspace(1)* %0, i64 %45
  %47 = load float, float addrspace(1)* %46, align 4, !tbaa !6
  %48 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 %6
  store float %47, float addrspace(3)* %48, align 4, !tbaa !6
  %49 = add nsw i32 %43, %1
  %50 = sext i32 %49 to i64
  %51 = add nsw i64 %50, %7
  %52 = getelementptr inbounds float, float addrspace(1)* %0, i64 %51
  %53 = load float, float addrspace(1)* %52, align 4, !tbaa !6
  %54 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 %6
  store float %53, float addrspace(3)* %54, align 4, !tbaa !6
  %55 = add nsw i32 %49, %1
  %56 = sext i32 %55 to i64
  %57 = add nsw i64 %56, %7
  %58 = getelementptr inbounds float, float addrspace(1)* %0, i64 %57
  %59 = load float, float addrspace(1)* %58, align 4, !tbaa !6
  %60 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 %6
  store float %59, float addrspace(3)* %60, align 4, !tbaa !6
  %61 = add nsw i32 %55, %1
  %62 = sext i32 %61 to i64
  %63 = add nsw i64 %62, %7
  %64 = getelementptr inbounds float, float addrspace(1)* %0, i64 %63
  %65 = load float, float addrspace(1)* %64, align 4, !tbaa !6
  %66 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 %6
  store float %65, float addrspace(3)* %66, align 4, !tbaa !6
  %67 = add nsw i32 %61, %1
  %68 = sext i32 %67 to i64
  %69 = add nsw i64 %68, %7
  %70 = getelementptr inbounds float, float addrspace(1)* %0, i64 %69
  %71 = load float, float addrspace(1)* %70, align 4, !tbaa !6
  %72 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 %6
  store float %71, float addrspace(3)* %72, align 4, !tbaa !6
  %73 = add nsw i32 %67, %1
  %74 = sext i32 %73 to i64
  %75 = add nsw i64 %74, %7
  %76 = getelementptr inbounds float, float addrspace(1)* %0, i64 %75
  %77 = load float, float addrspace(1)* %76, align 4, !tbaa !6
  %78 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 %6
  store float %77, float addrspace(3)* %78, align 4, !tbaa !6
  %79 = add nsw i32 %73, %1
  %80 = sext i32 %79 to i64
  %81 = add nsw i64 %80, %7
  %82 = getelementptr inbounds float, float addrspace(1)* %0, i64 %81
  %83 = load float, float addrspace(1)* %82, align 4, !tbaa !6
  %84 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 %6
  store float %83, float addrspace(3)* %84, align 4, !tbaa !6
  %85 = add nsw i32 %79, %1
  %86 = sext i32 %85 to i64
  %87 = add nsw i64 %86, %7
  %88 = getelementptr inbounds float, float addrspace(1)* %0, i64 %87
  %89 = load float, float addrspace(1)* %88, align 4, !tbaa !6
  %90 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 %6
  store float %89, float addrspace(3)* %90, align 4, !tbaa !6
  %91 = add nsw i32 %85, %1
  %92 = sext i32 %91 to i64
  %93 = add nsw i64 %92, %7
  %94 = getelementptr inbounds float, float addrspace(1)* %0, i64 %93
  %95 = load float, float addrspace(1)* %94, align 4, !tbaa !6
  %96 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 %6
  store float %95, float addrspace(3)* %96, align 4, !tbaa !6
  %97 = add nsw i32 %91, %1
  %98 = sext i32 %97 to i64
  %99 = add nsw i64 %98, %7
  %100 = getelementptr inbounds float, float addrspace(1)* %0, i64 %99
  %101 = load float, float addrspace(1)* %100, align 4, !tbaa !6
  %102 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 %6
  store float %101, float addrspace(3)* %102, align 4, !tbaa !6
  %103 = add nsw i32 %97, %1
  %104 = sext i32 %103 to i64
  %105 = add nsw i64 %104, %7
  %106 = getelementptr inbounds float, float addrspace(1)* %0, i64 %105
  %107 = load float, float addrspace(1)* %106, align 4, !tbaa !6
  %108 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 16, i32 %6
  store float %107, float addrspace(3)* %108, align 4, !tbaa !6
  %109 = add nsw i32 %103, %1
  %110 = sext i32 %109 to i64
  %111 = add nsw i64 %110, %7
  %112 = getelementptr inbounds float, float addrspace(1)* %0, i64 %111
  %113 = load float, float addrspace(1)* %112, align 4, !tbaa !6
  %114 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 17, i32 %6
  store float %113, float addrspace(3)* %114, align 4, !tbaa !6
  %115 = add nsw i32 %109, %1
  %116 = sext i32 %115 to i64
  %117 = add nsw i64 %116, %7
  %118 = getelementptr inbounds float, float addrspace(1)* %0, i64 %117
  %119 = load float, float addrspace(1)* %118, align 4, !tbaa !6
  %120 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 18, i32 %6
  store float %119, float addrspace(3)* %120, align 4, !tbaa !6
  %121 = add nsw i32 %115, %1
  %122 = sext i32 %121 to i64
  %123 = add nsw i64 %122, %7
  %124 = getelementptr inbounds float, float addrspace(1)* %0, i64 %123
  %125 = load float, float addrspace(1)* %124, align 4, !tbaa !6
  %126 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 19, i32 %6
  store float %125, float addrspace(3)* %126, align 4, !tbaa !6
  %127 = add nsw i32 %121, %1
  %128 = sext i32 %127 to i64
  %129 = add nsw i64 %128, %7
  %130 = getelementptr inbounds float, float addrspace(1)* %0, i64 %129
  %131 = load float, float addrspace(1)* %130, align 4, !tbaa !6
  %132 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 20, i32 %6
  store float %131, float addrspace(3)* %132, align 4, !tbaa !6
  %133 = add nsw i32 %127, %1
  %134 = sext i32 %133 to i64
  %135 = add nsw i64 %134, %7
  %136 = getelementptr inbounds float, float addrspace(1)* %0, i64 %135
  %137 = load float, float addrspace(1)* %136, align 4, !tbaa !6
  %138 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 21, i32 %6
  store float %137, float addrspace(3)* %138, align 4, !tbaa !6
  %139 = add nsw i32 %133, %1
  %140 = sext i32 %139 to i64
  %141 = add nsw i64 %140, %7
  %142 = getelementptr inbounds float, float addrspace(1)* %0, i64 %141
  %143 = load float, float addrspace(1)* %142, align 4, !tbaa !6
  %144 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 22, i32 %6
  store float %143, float addrspace(3)* %144, align 4, !tbaa !6
  %145 = add nsw i32 %139, %1
  %146 = sext i32 %145 to i64
  %147 = add nsw i64 %146, %7
  %148 = getelementptr inbounds float, float addrspace(1)* %0, i64 %147
  %149 = load float, float addrspace(1)* %148, align 4, !tbaa !6
  %150 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 23, i32 %6
  store float %149, float addrspace(3)* %150, align 4, !tbaa !6
  %151 = add nsw i32 %145, %1
  %152 = sext i32 %151 to i64
  %153 = add nsw i64 %152, %7
  %154 = getelementptr inbounds float, float addrspace(1)* %0, i64 %153
  %155 = load float, float addrspace(1)* %154, align 4, !tbaa !6
  %156 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 24, i32 %6
  store float %155, float addrspace(3)* %156, align 4, !tbaa !6
  %157 = add nsw i32 %151, %1
  %158 = sext i32 %157 to i64
  %159 = add nsw i64 %158, %7
  %160 = getelementptr inbounds float, float addrspace(1)* %0, i64 %159
  %161 = load float, float addrspace(1)* %160, align 4, !tbaa !6
  %162 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 25, i32 %6
  store float %161, float addrspace(3)* %162, align 4, !tbaa !6
  %163 = add nsw i32 %157, %1
  %164 = sext i32 %163 to i64
  %165 = add nsw i64 %164, %7
  %166 = getelementptr inbounds float, float addrspace(1)* %0, i64 %165
  %167 = load float, float addrspace(1)* %166, align 4, !tbaa !6
  %168 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 26, i32 %6
  store float %167, float addrspace(3)* %168, align 4, !tbaa !6
  %169 = add nsw i32 %163, %1
  %170 = sext i32 %169 to i64
  %171 = add nsw i64 %170, %7
  %172 = getelementptr inbounds float, float addrspace(1)* %0, i64 %171
  %173 = load float, float addrspace(1)* %172, align 4, !tbaa !6
  %174 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 27, i32 %6
  store float %173, float addrspace(3)* %174, align 4, !tbaa !6
  %175 = add nsw i32 %169, %1
  %176 = sext i32 %175 to i64
  %177 = add nsw i64 %176, %7
  %178 = getelementptr inbounds float, float addrspace(1)* %0, i64 %177
  %179 = load float, float addrspace(1)* %178, align 4, !tbaa !6
  %180 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 28, i32 %6
  store float %179, float addrspace(3)* %180, align 4, !tbaa !6
  %181 = add nsw i32 %175, %1
  %182 = sext i32 %181 to i64
  %183 = add nsw i64 %182, %7
  %184 = getelementptr inbounds float, float addrspace(1)* %0, i64 %183
  %185 = load float, float addrspace(1)* %184, align 4, !tbaa !6
  %186 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 29, i32 %6
  store float %185, float addrspace(3)* %186, align 4, !tbaa !6
  %187 = add nsw i32 %181, %1
  %188 = sext i32 %187 to i64
  %189 = add nsw i64 %188, %7
  %190 = getelementptr inbounds float, float addrspace(1)* %0, i64 %189
  %191 = load float, float addrspace(1)* %190, align 4, !tbaa !6
  %192 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 30, i32 %6
  store float %191, float addrspace(3)* %192, align 4, !tbaa !6
  %193 = add nsw i32 %187, %1
  %194 = sext i32 %193 to i64
  %195 = add nsw i64 %194, %7
  %196 = getelementptr inbounds float, float addrspace(1)* %0, i64 %195
  %197 = load float, float addrspace(1)* %196, align 4, !tbaa !6
  %198 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 31, i32 %6
  store float %197, float addrspace(3)* %198, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %199 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  br label %200

200:                                              ; preds = %390, %3
  %201 = phi i32 [ 0, %3 ], [ %303, %390 ]
  %202 = add nuw i32 %201, 1
  %203 = add nsw i32 %201, -1
  %204 = icmp ugt i32 %6, %201
  br i1 %204, label %205, label %302

205:                                              ; preds = %200
  %206 = icmp eq i32 %201, 0
  br i1 %206, label %207, label %209

207:                                              ; preds = %205
  %208 = load float, float addrspace(3)* %199, align 16, !tbaa !6
  br label %296

209:                                              ; preds = %205
  %210 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 %201
  %211 = load float, float addrspace(3)* %210, align 4, !tbaa !6
  %212 = and i32 %201, 7
  %213 = icmp ult i32 %203, 7
  br i1 %213, label %278, label %214

214:                                              ; preds = %209
  %215 = and i32 %201, 2147483640
  br label %216

216:                                              ; preds = %216, %214
  %217 = phi float [ %211, %214 ], [ %274, %216 ]
  %218 = phi i32 [ 0, %214 ], [ %275, %216 ]
  %219 = phi i32 [ %215, %214 ], [ %276, %216 ]
  %220 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 %218
  %221 = load float, float addrspace(3)* %220, align 16, !tbaa !6
  %222 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %218, i32 %201
  %223 = load float, float addrspace(3)* %222, align 4, !tbaa !6
  %224 = fmul contract float %221, %223
  %225 = fsub contract float %217, %224
  store float %225, float addrspace(3)* %210, align 4, !tbaa !6
  %226 = or i32 %218, 1
  %227 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 %226
  %228 = load float, float addrspace(3)* %227, align 4, !tbaa !6
  %229 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %226, i32 %201
  %230 = load float, float addrspace(3)* %229, align 4, !tbaa !6
  %231 = fmul contract float %228, %230
  %232 = fsub contract float %225, %231
  store float %232, float addrspace(3)* %210, align 4, !tbaa !6
  %233 = or i32 %218, 2
  %234 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 %233
  %235 = load float, float addrspace(3)* %234, align 8, !tbaa !6
  %236 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %233, i32 %201
  %237 = load float, float addrspace(3)* %236, align 4, !tbaa !6
  %238 = fmul contract float %235, %237
  %239 = fsub contract float %232, %238
  store float %239, float addrspace(3)* %210, align 4, !tbaa !6
  %240 = or i32 %218, 3
  %241 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 %240
  %242 = load float, float addrspace(3)* %241, align 4, !tbaa !6
  %243 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %240, i32 %201
  %244 = load float, float addrspace(3)* %243, align 4, !tbaa !6
  %245 = fmul contract float %242, %244
  %246 = fsub contract float %239, %245
  store float %246, float addrspace(3)* %210, align 4, !tbaa !6
  %247 = or i32 %218, 4
  %248 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 %247
  %249 = load float, float addrspace(3)* %248, align 16, !tbaa !6
  %250 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %247, i32 %201
  %251 = load float, float addrspace(3)* %250, align 4, !tbaa !6
  %252 = fmul contract float %249, %251
  %253 = fsub contract float %246, %252
  store float %253, float addrspace(3)* %210, align 4, !tbaa !6
  %254 = or i32 %218, 5
  %255 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 %254
  %256 = load float, float addrspace(3)* %255, align 4, !tbaa !6
  %257 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %254, i32 %201
  %258 = load float, float addrspace(3)* %257, align 4, !tbaa !6
  %259 = fmul contract float %256, %258
  %260 = fsub contract float %253, %259
  store float %260, float addrspace(3)* %210, align 4, !tbaa !6
  %261 = or i32 %218, 6
  %262 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 %261
  %263 = load float, float addrspace(3)* %262, align 8, !tbaa !6
  %264 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %261, i32 %201
  %265 = load float, float addrspace(3)* %264, align 4, !tbaa !6
  %266 = fmul contract float %263, %265
  %267 = fsub contract float %260, %266
  store float %267, float addrspace(3)* %210, align 4, !tbaa !6
  %268 = or i32 %218, 7
  %269 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 %268
  %270 = load float, float addrspace(3)* %269, align 4, !tbaa !6
  %271 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %268, i32 %201
  %272 = load float, float addrspace(3)* %271, align 4, !tbaa !6
  %273 = fmul contract float %270, %272
  %274 = fsub contract float %267, %273
  store float %274, float addrspace(3)* %210, align 4, !tbaa !6
  %275 = add nuw nsw i32 %218, 8
  %276 = add i32 %219, -8
  %277 = icmp eq i32 %276, 0
  br i1 %277, label %278, label %216, !llvm.loop !10

278:                                              ; preds = %216, %209
  %279 = phi float [ undef, %209 ], [ %274, %216 ]
  %280 = phi float [ %211, %209 ], [ %274, %216 ]
  %281 = phi i32 [ 0, %209 ], [ %275, %216 ]
  %282 = icmp eq i32 %212, 0
  br i1 %282, label %296, label %283

283:                                              ; preds = %283, %278
  %284 = phi float [ %292, %283 ], [ %280, %278 ]
  %285 = phi i32 [ %293, %283 ], [ %281, %278 ]
  %286 = phi i32 [ %294, %283 ], [ %212, %278 ]
  %287 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 %285
  %288 = load float, float addrspace(3)* %287, align 4, !tbaa !6
  %289 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %285, i32 %201
  %290 = load float, float addrspace(3)* %289, align 4, !tbaa !6
  %291 = fmul contract float %288, %290
  %292 = fsub contract float %284, %291
  store float %292, float addrspace(3)* %210, align 4, !tbaa !6
  %293 = add nuw nsw i32 %285, 1
  %294 = add i32 %286, -1
  %295 = icmp eq i32 %294, 0
  br i1 %295, label %296, label %283, !llvm.loop !12

296:                                              ; preds = %283, %278, %207
  %297 = phi float [ %208, %207 ], [ %279, %278 ], [ %292, %283 ]
  %298 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %201, i32 %201
  %299 = load float, float addrspace(3)* %298, align 4, !tbaa !6
  %300 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 %201
  %301 = fdiv contract float %297, %299
  store float %301, float addrspace(3)* %300, align 4, !tbaa !6
  br label %302

302:                                              ; preds = %296, %200
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %303 = add nuw nsw i32 %201, 1
  br i1 %204, label %304, label %390

304:                                              ; preds = %302
  %305 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %303, i32 %6
  %306 = load float, float addrspace(3)* %305, align 4, !tbaa !6
  %307 = and i32 %202, 7
  %308 = icmp ult i32 %201, 7
  br i1 %308, label %373, label %309

309:                                              ; preds = %304
  %310 = and i32 %202, -8
  br label %311

311:                                              ; preds = %311, %309
  %312 = phi float [ %306, %309 ], [ %369, %311 ]
  %313 = phi i32 [ 0, %309 ], [ %370, %311 ]
  %314 = phi i32 [ %310, %309 ], [ %371, %311 ]
  %315 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %303, i32 %313
  %316 = load float, float addrspace(3)* %315, align 16, !tbaa !6
  %317 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %313, i32 %6
  %318 = load float, float addrspace(3)* %317, align 4, !tbaa !6
  %319 = fmul contract float %316, %318
  %320 = fsub contract float %312, %319
  store float %320, float addrspace(3)* %305, align 4, !tbaa !6
  %321 = or i32 %313, 1
  %322 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %303, i32 %321
  %323 = load float, float addrspace(3)* %322, align 4, !tbaa !6
  %324 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %321, i32 %6
  %325 = load float, float addrspace(3)* %324, align 4, !tbaa !6
  %326 = fmul contract float %323, %325
  %327 = fsub contract float %320, %326
  store float %327, float addrspace(3)* %305, align 4, !tbaa !6
  %328 = or i32 %313, 2
  %329 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %303, i32 %328
  %330 = load float, float addrspace(3)* %329, align 8, !tbaa !6
  %331 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %328, i32 %6
  %332 = load float, float addrspace(3)* %331, align 4, !tbaa !6
  %333 = fmul contract float %330, %332
  %334 = fsub contract float %327, %333
  store float %334, float addrspace(3)* %305, align 4, !tbaa !6
  %335 = or i32 %313, 3
  %336 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %303, i32 %335
  %337 = load float, float addrspace(3)* %336, align 4, !tbaa !6
  %338 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %335, i32 %6
  %339 = load float, float addrspace(3)* %338, align 4, !tbaa !6
  %340 = fmul contract float %337, %339
  %341 = fsub contract float %334, %340
  store float %341, float addrspace(3)* %305, align 4, !tbaa !6
  %342 = or i32 %313, 4
  %343 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %303, i32 %342
  %344 = load float, float addrspace(3)* %343, align 16, !tbaa !6
  %345 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %342, i32 %6
  %346 = load float, float addrspace(3)* %345, align 4, !tbaa !6
  %347 = fmul contract float %344, %346
  %348 = fsub contract float %341, %347
  store float %348, float addrspace(3)* %305, align 4, !tbaa !6
  %349 = or i32 %313, 5
  %350 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %303, i32 %349
  %351 = load float, float addrspace(3)* %350, align 4, !tbaa !6
  %352 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %349, i32 %6
  %353 = load float, float addrspace(3)* %352, align 4, !tbaa !6
  %354 = fmul contract float %351, %353
  %355 = fsub contract float %348, %354
  store float %355, float addrspace(3)* %305, align 4, !tbaa !6
  %356 = or i32 %313, 6
  %357 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %303, i32 %356
  %358 = load float, float addrspace(3)* %357, align 8, !tbaa !6
  %359 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %356, i32 %6
  %360 = load float, float addrspace(3)* %359, align 4, !tbaa !6
  %361 = fmul contract float %358, %360
  %362 = fsub contract float %355, %361
  store float %362, float addrspace(3)* %305, align 4, !tbaa !6
  %363 = or i32 %313, 7
  %364 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %303, i32 %363
  %365 = load float, float addrspace(3)* %364, align 4, !tbaa !6
  %366 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %363, i32 %6
  %367 = load float, float addrspace(3)* %366, align 4, !tbaa !6
  %368 = fmul contract float %365, %367
  %369 = fsub contract float %362, %368
  store float %369, float addrspace(3)* %305, align 4, !tbaa !6
  %370 = add nuw nsw i32 %313, 8
  %371 = add i32 %314, -8
  %372 = icmp eq i32 %371, 0
  br i1 %372, label %373, label %311, !llvm.loop !14

373:                                              ; preds = %311, %304
  %374 = phi float [ %306, %304 ], [ %369, %311 ]
  %375 = phi i32 [ 0, %304 ], [ %370, %311 ]
  %376 = icmp eq i32 %307, 0
  br i1 %376, label %390, label %377

377:                                              ; preds = %377, %373
  %378 = phi float [ %386, %377 ], [ %374, %373 ]
  %379 = phi i32 [ %387, %377 ], [ %375, %373 ]
  %380 = phi i32 [ %388, %377 ], [ %307, %373 ]
  %381 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %303, i32 %379
  %382 = load float, float addrspace(3)* %381, align 4, !tbaa !6
  %383 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %379, i32 %6
  %384 = load float, float addrspace(3)* %383, align 4, !tbaa !6
  %385 = fmul contract float %382, %384
  %386 = fsub contract float %378, %385
  store float %386, float addrspace(3)* %305, align 4, !tbaa !6
  %387 = add nuw nsw i32 %379, 1
  %388 = add i32 %380, -1
  %389 = icmp eq i32 %388, 0
  br i1 %389, label %390, label %377, !llvm.loop !15

390:                                              ; preds = %377, %373, %302
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %391 = icmp eq i32 %303, 31
  br i1 %391, label %392, label %200, !llvm.loop !16

392:                                              ; preds = %390
  %393 = add nsw i32 %2, 1
  %394 = mul nsw i32 %393, %1
  %395 = add nsw i32 %394, %2
  %396 = load float, float addrspace(3)* %18, align 4, !tbaa !6
  %397 = sext i32 %395 to i64
  %398 = add nsw i64 %397, %7
  %399 = getelementptr inbounds float, float addrspace(1)* %0, i64 %398
  store float %396, float addrspace(1)* %399, align 4, !tbaa !6
  %400 = add nsw i32 %395, %1
  %401 = load float, float addrspace(3)* %24, align 4, !tbaa !6
  %402 = sext i32 %400 to i64
  %403 = add nsw i64 %402, %7
  %404 = getelementptr inbounds float, float addrspace(1)* %0, i64 %403
  store float %401, float addrspace(1)* %404, align 4, !tbaa !6
  %405 = add nsw i32 %400, %1
  %406 = load float, float addrspace(3)* %30, align 4, !tbaa !6
  %407 = sext i32 %405 to i64
  %408 = add nsw i64 %407, %7
  %409 = getelementptr inbounds float, float addrspace(1)* %0, i64 %408
  store float %406, float addrspace(1)* %409, align 4, !tbaa !6
  %410 = add nsw i32 %405, %1
  %411 = load float, float addrspace(3)* %36, align 4, !tbaa !6
  %412 = sext i32 %410 to i64
  %413 = add nsw i64 %412, %7
  %414 = getelementptr inbounds float, float addrspace(1)* %0, i64 %413
  store float %411, float addrspace(1)* %414, align 4, !tbaa !6
  %415 = add nsw i32 %410, %1
  %416 = load float, float addrspace(3)* %42, align 4, !tbaa !6
  %417 = sext i32 %415 to i64
  %418 = add nsw i64 %417, %7
  %419 = getelementptr inbounds float, float addrspace(1)* %0, i64 %418
  store float %416, float addrspace(1)* %419, align 4, !tbaa !6
  %420 = add nsw i32 %415, %1
  %421 = load float, float addrspace(3)* %48, align 4, !tbaa !6
  %422 = sext i32 %420 to i64
  %423 = add nsw i64 %422, %7
  %424 = getelementptr inbounds float, float addrspace(1)* %0, i64 %423
  store float %421, float addrspace(1)* %424, align 4, !tbaa !6
  %425 = add nsw i32 %420, %1
  %426 = load float, float addrspace(3)* %54, align 4, !tbaa !6
  %427 = sext i32 %425 to i64
  %428 = add nsw i64 %427, %7
  %429 = getelementptr inbounds float, float addrspace(1)* %0, i64 %428
  store float %426, float addrspace(1)* %429, align 4, !tbaa !6
  %430 = add nsw i32 %425, %1
  %431 = load float, float addrspace(3)* %60, align 4, !tbaa !6
  %432 = sext i32 %430 to i64
  %433 = add nsw i64 %432, %7
  %434 = getelementptr inbounds float, float addrspace(1)* %0, i64 %433
  store float %431, float addrspace(1)* %434, align 4, !tbaa !6
  %435 = add nsw i32 %430, %1
  %436 = load float, float addrspace(3)* %66, align 4, !tbaa !6
  %437 = sext i32 %435 to i64
  %438 = add nsw i64 %437, %7
  %439 = getelementptr inbounds float, float addrspace(1)* %0, i64 %438
  store float %436, float addrspace(1)* %439, align 4, !tbaa !6
  %440 = add nsw i32 %435, %1
  %441 = load float, float addrspace(3)* %72, align 4, !tbaa !6
  %442 = sext i32 %440 to i64
  %443 = add nsw i64 %442, %7
  %444 = getelementptr inbounds float, float addrspace(1)* %0, i64 %443
  store float %441, float addrspace(1)* %444, align 4, !tbaa !6
  %445 = add nsw i32 %440, %1
  %446 = load float, float addrspace(3)* %78, align 4, !tbaa !6
  %447 = sext i32 %445 to i64
  %448 = add nsw i64 %447, %7
  %449 = getelementptr inbounds float, float addrspace(1)* %0, i64 %448
  store float %446, float addrspace(1)* %449, align 4, !tbaa !6
  %450 = add nsw i32 %445, %1
  %451 = load float, float addrspace(3)* %84, align 4, !tbaa !6
  %452 = sext i32 %450 to i64
  %453 = add nsw i64 %452, %7
  %454 = getelementptr inbounds float, float addrspace(1)* %0, i64 %453
  store float %451, float addrspace(1)* %454, align 4, !tbaa !6
  %455 = add nsw i32 %450, %1
  %456 = load float, float addrspace(3)* %90, align 4, !tbaa !6
  %457 = sext i32 %455 to i64
  %458 = add nsw i64 %457, %7
  %459 = getelementptr inbounds float, float addrspace(1)* %0, i64 %458
  store float %456, float addrspace(1)* %459, align 4, !tbaa !6
  %460 = add nsw i32 %455, %1
  %461 = load float, float addrspace(3)* %96, align 4, !tbaa !6
  %462 = sext i32 %460 to i64
  %463 = add nsw i64 %462, %7
  %464 = getelementptr inbounds float, float addrspace(1)* %0, i64 %463
  store float %461, float addrspace(1)* %464, align 4, !tbaa !6
  %465 = add nsw i32 %460, %1
  %466 = load float, float addrspace(3)* %102, align 4, !tbaa !6
  %467 = sext i32 %465 to i64
  %468 = add nsw i64 %467, %7
  %469 = getelementptr inbounds float, float addrspace(1)* %0, i64 %468
  store float %466, float addrspace(1)* %469, align 4, !tbaa !6
  %470 = add nsw i32 %465, %1
  %471 = load float, float addrspace(3)* %108, align 4, !tbaa !6
  %472 = sext i32 %470 to i64
  %473 = add nsw i64 %472, %7
  %474 = getelementptr inbounds float, float addrspace(1)* %0, i64 %473
  store float %471, float addrspace(1)* %474, align 4, !tbaa !6
  %475 = add nsw i32 %470, %1
  %476 = load float, float addrspace(3)* %114, align 4, !tbaa !6
  %477 = sext i32 %475 to i64
  %478 = add nsw i64 %477, %7
  %479 = getelementptr inbounds float, float addrspace(1)* %0, i64 %478
  store float %476, float addrspace(1)* %479, align 4, !tbaa !6
  %480 = add nsw i32 %475, %1
  %481 = load float, float addrspace(3)* %120, align 4, !tbaa !6
  %482 = sext i32 %480 to i64
  %483 = add nsw i64 %482, %7
  %484 = getelementptr inbounds float, float addrspace(1)* %0, i64 %483
  store float %481, float addrspace(1)* %484, align 4, !tbaa !6
  %485 = add nsw i32 %480, %1
  %486 = load float, float addrspace(3)* %126, align 4, !tbaa !6
  %487 = sext i32 %485 to i64
  %488 = add nsw i64 %487, %7
  %489 = getelementptr inbounds float, float addrspace(1)* %0, i64 %488
  store float %486, float addrspace(1)* %489, align 4, !tbaa !6
  %490 = add nsw i32 %485, %1
  %491 = load float, float addrspace(3)* %132, align 4, !tbaa !6
  %492 = sext i32 %490 to i64
  %493 = add nsw i64 %492, %7
  %494 = getelementptr inbounds float, float addrspace(1)* %0, i64 %493
  store float %491, float addrspace(1)* %494, align 4, !tbaa !6
  %495 = add nsw i32 %490, %1
  %496 = load float, float addrspace(3)* %138, align 4, !tbaa !6
  %497 = sext i32 %495 to i64
  %498 = add nsw i64 %497, %7
  %499 = getelementptr inbounds float, float addrspace(1)* %0, i64 %498
  store float %496, float addrspace(1)* %499, align 4, !tbaa !6
  %500 = add nsw i32 %495, %1
  %501 = load float, float addrspace(3)* %144, align 4, !tbaa !6
  %502 = sext i32 %500 to i64
  %503 = add nsw i64 %502, %7
  %504 = getelementptr inbounds float, float addrspace(1)* %0, i64 %503
  store float %501, float addrspace(1)* %504, align 4, !tbaa !6
  %505 = add nsw i32 %500, %1
  %506 = load float, float addrspace(3)* %150, align 4, !tbaa !6
  %507 = sext i32 %505 to i64
  %508 = add nsw i64 %507, %7
  %509 = getelementptr inbounds float, float addrspace(1)* %0, i64 %508
  store float %506, float addrspace(1)* %509, align 4, !tbaa !6
  %510 = add nsw i32 %505, %1
  %511 = load float, float addrspace(3)* %156, align 4, !tbaa !6
  %512 = sext i32 %510 to i64
  %513 = add nsw i64 %512, %7
  %514 = getelementptr inbounds float, float addrspace(1)* %0, i64 %513
  store float %511, float addrspace(1)* %514, align 4, !tbaa !6
  %515 = add nsw i32 %510, %1
  %516 = load float, float addrspace(3)* %162, align 4, !tbaa !6
  %517 = sext i32 %515 to i64
  %518 = add nsw i64 %517, %7
  %519 = getelementptr inbounds float, float addrspace(1)* %0, i64 %518
  store float %516, float addrspace(1)* %519, align 4, !tbaa !6
  %520 = add nsw i32 %515, %1
  %521 = load float, float addrspace(3)* %168, align 4, !tbaa !6
  %522 = sext i32 %520 to i64
  %523 = add nsw i64 %522, %7
  %524 = getelementptr inbounds float, float addrspace(1)* %0, i64 %523
  store float %521, float addrspace(1)* %524, align 4, !tbaa !6
  %525 = add nsw i32 %520, %1
  %526 = load float, float addrspace(3)* %174, align 4, !tbaa !6
  %527 = sext i32 %525 to i64
  %528 = add nsw i64 %527, %7
  %529 = getelementptr inbounds float, float addrspace(1)* %0, i64 %528
  store float %526, float addrspace(1)* %529, align 4, !tbaa !6
  %530 = add nsw i32 %525, %1
  %531 = load float, float addrspace(3)* %180, align 4, !tbaa !6
  %532 = sext i32 %530 to i64
  %533 = add nsw i64 %532, %7
  %534 = getelementptr inbounds float, float addrspace(1)* %0, i64 %533
  store float %531, float addrspace(1)* %534, align 4, !tbaa !6
  %535 = add nsw i32 %530, %1
  %536 = load float, float addrspace(3)* %186, align 4, !tbaa !6
  %537 = sext i32 %535 to i64
  %538 = add nsw i64 %537, %7
  %539 = getelementptr inbounds float, float addrspace(1)* %0, i64 %538
  store float %536, float addrspace(1)* %539, align 4, !tbaa !6
  %540 = add nsw i32 %535, %1
  %541 = load float, float addrspace(3)* %192, align 4, !tbaa !6
  %542 = sext i32 %540 to i64
  %543 = add nsw i64 %542, %7
  %544 = getelementptr inbounds float, float addrspace(1)* %0, i64 %543
  store float %541, float addrspace(1)* %544, align 4, !tbaa !6
  %545 = add nsw i32 %540, %1
  %546 = load float, float addrspace(3)* %198, align 4, !tbaa !6
  %547 = sext i32 %545 to i64
  %548 = add nsw i64 %547, %7
  %549 = getelementptr inbounds float, float addrspace(1)* %0, i64 %548
  store float %546, float addrspace(1)* %549, align 4, !tbaa !6
  ret void
}

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z13lud_perimeterPfii(float addrspace(1)* nocapture %0, i32 %1, i32 %2) local_unnamed_addr #0 {
  %4 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %5 = zext i32 %4 to i64
  %6 = icmp ult i32 %4, 32
  br i1 %6, label %7, label %284

7:                                                ; preds = %3
  %8 = mul nsw i32 %2, %1
  %9 = add nsw i32 %8, %2
  %10 = add nsw i32 %9, %4
  %11 = sext i32 %10 to i64
  %12 = getelementptr inbounds float, float addrspace(1)* %0, i64 %11
  %13 = load float, float addrspace(1)* %12, align 4, !tbaa !6
  %14 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 %4
  store float %13, float addrspace(3)* %14, align 4, !tbaa !6
  %15 = add nsw i32 %9, %1
  %16 = add nsw i32 %15, %4
  %17 = sext i32 %16 to i64
  %18 = getelementptr inbounds float, float addrspace(1)* %0, i64 %17
  %19 = load float, float addrspace(1)* %18, align 4, !tbaa !6
  %20 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 %4
  store float %19, float addrspace(3)* %20, align 4, !tbaa !6
  %21 = add nsw i32 %15, %1
  %22 = add nsw i32 %21, %4
  %23 = sext i32 %22 to i64
  %24 = getelementptr inbounds float, float addrspace(1)* %0, i64 %23
  %25 = load float, float addrspace(1)* %24, align 4, !tbaa !6
  %26 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 %4
  store float %25, float addrspace(3)* %26, align 4, !tbaa !6
  %27 = add nsw i32 %21, %1
  %28 = add nsw i32 %27, %4
  %29 = sext i32 %28 to i64
  %30 = getelementptr inbounds float, float addrspace(1)* %0, i64 %29
  %31 = load float, float addrspace(1)* %30, align 4, !tbaa !6
  %32 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 %4
  store float %31, float addrspace(3)* %32, align 4, !tbaa !6
  %33 = add nsw i32 %27, %1
  %34 = add nsw i32 %33, %4
  %35 = sext i32 %34 to i64
  %36 = getelementptr inbounds float, float addrspace(1)* %0, i64 %35
  %37 = load float, float addrspace(1)* %36, align 4, !tbaa !6
  %38 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 %4
  store float %37, float addrspace(3)* %38, align 4, !tbaa !6
  %39 = add nsw i32 %33, %1
  %40 = add nsw i32 %39, %4
  %41 = sext i32 %40 to i64
  %42 = getelementptr inbounds float, float addrspace(1)* %0, i64 %41
  %43 = load float, float addrspace(1)* %42, align 4, !tbaa !6
  %44 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 %4
  store float %43, float addrspace(3)* %44, align 4, !tbaa !6
  %45 = add nsw i32 %39, %1
  %46 = add nsw i32 %45, %4
  %47 = sext i32 %46 to i64
  %48 = getelementptr inbounds float, float addrspace(1)* %0, i64 %47
  %49 = load float, float addrspace(1)* %48, align 4, !tbaa !6
  %50 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 %4
  store float %49, float addrspace(3)* %50, align 4, !tbaa !6
  %51 = add nsw i32 %45, %1
  %52 = add nsw i32 %51, %4
  %53 = sext i32 %52 to i64
  %54 = getelementptr inbounds float, float addrspace(1)* %0, i64 %53
  %55 = load float, float addrspace(1)* %54, align 4, !tbaa !6
  %56 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 %4
  store float %55, float addrspace(3)* %56, align 4, !tbaa !6
  %57 = add nsw i32 %51, %1
  %58 = add nsw i32 %57, %4
  %59 = sext i32 %58 to i64
  %60 = getelementptr inbounds float, float addrspace(1)* %0, i64 %59
  %61 = load float, float addrspace(1)* %60, align 4, !tbaa !6
  %62 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 %4
  store float %61, float addrspace(3)* %62, align 4, !tbaa !6
  %63 = add nsw i32 %57, %1
  %64 = add nsw i32 %63, %4
  %65 = sext i32 %64 to i64
  %66 = getelementptr inbounds float, float addrspace(1)* %0, i64 %65
  %67 = load float, float addrspace(1)* %66, align 4, !tbaa !6
  %68 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 %4
  store float %67, float addrspace(3)* %68, align 4, !tbaa !6
  %69 = add nsw i32 %63, %1
  %70 = add nsw i32 %69, %4
  %71 = sext i32 %70 to i64
  %72 = getelementptr inbounds float, float addrspace(1)* %0, i64 %71
  %73 = load float, float addrspace(1)* %72, align 4, !tbaa !6
  %74 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 %4
  store float %73, float addrspace(3)* %74, align 4, !tbaa !6
  %75 = add nsw i32 %69, %1
  %76 = add nsw i32 %75, %4
  %77 = sext i32 %76 to i64
  %78 = getelementptr inbounds float, float addrspace(1)* %0, i64 %77
  %79 = load float, float addrspace(1)* %78, align 4, !tbaa !6
  %80 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 %4
  store float %79, float addrspace(3)* %80, align 4, !tbaa !6
  %81 = add nsw i32 %75, %1
  %82 = add nsw i32 %81, %4
  %83 = sext i32 %82 to i64
  %84 = getelementptr inbounds float, float addrspace(1)* %0, i64 %83
  %85 = load float, float addrspace(1)* %84, align 4, !tbaa !6
  %86 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 %4
  store float %85, float addrspace(3)* %86, align 4, !tbaa !6
  %87 = add nsw i32 %81, %1
  %88 = add nsw i32 %87, %4
  %89 = sext i32 %88 to i64
  %90 = getelementptr inbounds float, float addrspace(1)* %0, i64 %89
  %91 = load float, float addrspace(1)* %90, align 4, !tbaa !6
  %92 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 %4
  store float %91, float addrspace(3)* %92, align 4, !tbaa !6
  %93 = add nsw i32 %87, %1
  %94 = add nsw i32 %93, %4
  %95 = sext i32 %94 to i64
  %96 = getelementptr inbounds float, float addrspace(1)* %0, i64 %95
  %97 = load float, float addrspace(1)* %96, align 4, !tbaa !6
  %98 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 %4
  store float %97, float addrspace(3)* %98, align 4, !tbaa !6
  %99 = add nsw i32 %93, %1
  %100 = add nsw i32 %99, %4
  %101 = sext i32 %100 to i64
  %102 = getelementptr inbounds float, float addrspace(1)* %0, i64 %101
  %103 = load float, float addrspace(1)* %102, align 4, !tbaa !6
  %104 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 %4
  store float %103, float addrspace(3)* %104, align 4, !tbaa !6
  %105 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %106 = zext i32 %105 to i64
  %107 = shl nuw nsw i64 %106, 5
  %108 = add nuw nsw i64 %5, 32
  %109 = add nuw nsw i64 %108, %107
  %110 = sext i32 %9 to i64
  %111 = add nsw i64 %109, %110
  %112 = getelementptr inbounds float, float addrspace(1)* %0, i64 %111
  %113 = load float, float addrspace(1)* %112, align 4, !tbaa !6
  %114 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  store float %113, float addrspace(3)* %114, align 4, !tbaa !6
  %115 = sext i32 %15 to i64
  %116 = add nsw i64 %109, %115
  %117 = getelementptr inbounds float, float addrspace(1)* %0, i64 %116
  %118 = load float, float addrspace(1)* %117, align 4, !tbaa !6
  %119 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  store float %118, float addrspace(3)* %119, align 4, !tbaa !6
  %120 = sext i32 %21 to i64
  %121 = add nsw i64 %109, %120
  %122 = getelementptr inbounds float, float addrspace(1)* %0, i64 %121
  %123 = load float, float addrspace(1)* %122, align 4, !tbaa !6
  %124 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  store float %123, float addrspace(3)* %124, align 4, !tbaa !6
  %125 = sext i32 %27 to i64
  %126 = add nsw i64 %109, %125
  %127 = getelementptr inbounds float, float addrspace(1)* %0, i64 %126
  %128 = load float, float addrspace(1)* %127, align 4, !tbaa !6
  %129 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  store float %128, float addrspace(3)* %129, align 4, !tbaa !6
  %130 = sext i32 %33 to i64
  %131 = add nsw i64 %109, %130
  %132 = getelementptr inbounds float, float addrspace(1)* %0, i64 %131
  %133 = load float, float addrspace(1)* %132, align 4, !tbaa !6
  %134 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  store float %133, float addrspace(3)* %134, align 4, !tbaa !6
  %135 = sext i32 %39 to i64
  %136 = add nsw i64 %109, %135
  %137 = getelementptr inbounds float, float addrspace(1)* %0, i64 %136
  %138 = load float, float addrspace(1)* %137, align 4, !tbaa !6
  %139 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  store float %138, float addrspace(3)* %139, align 4, !tbaa !6
  %140 = sext i32 %45 to i64
  %141 = add nsw i64 %109, %140
  %142 = getelementptr inbounds float, float addrspace(1)* %0, i64 %141
  %143 = load float, float addrspace(1)* %142, align 4, !tbaa !6
  %144 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  store float %143, float addrspace(3)* %144, align 4, !tbaa !6
  %145 = sext i32 %51 to i64
  %146 = add nsw i64 %109, %145
  %147 = getelementptr inbounds float, float addrspace(1)* %0, i64 %146
  %148 = load float, float addrspace(1)* %147, align 4, !tbaa !6
  %149 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  store float %148, float addrspace(3)* %149, align 4, !tbaa !6
  %150 = sext i32 %57 to i64
  %151 = add nsw i64 %109, %150
  %152 = getelementptr inbounds float, float addrspace(1)* %0, i64 %151
  %153 = load float, float addrspace(1)* %152, align 4, !tbaa !6
  %154 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  store float %153, float addrspace(3)* %154, align 4, !tbaa !6
  %155 = sext i32 %63 to i64
  %156 = add nsw i64 %109, %155
  %157 = getelementptr inbounds float, float addrspace(1)* %0, i64 %156
  %158 = load float, float addrspace(1)* %157, align 4, !tbaa !6
  %159 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  store float %158, float addrspace(3)* %159, align 4, !tbaa !6
  %160 = sext i32 %69 to i64
  %161 = add nsw i64 %109, %160
  %162 = getelementptr inbounds float, float addrspace(1)* %0, i64 %161
  %163 = load float, float addrspace(1)* %162, align 4, !tbaa !6
  %164 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  store float %163, float addrspace(3)* %164, align 4, !tbaa !6
  %165 = sext i32 %75 to i64
  %166 = add nsw i64 %109, %165
  %167 = getelementptr inbounds float, float addrspace(1)* %0, i64 %166
  %168 = load float, float addrspace(1)* %167, align 4, !tbaa !6
  %169 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  store float %168, float addrspace(3)* %169, align 4, !tbaa !6
  %170 = sext i32 %81 to i64
  %171 = add nsw i64 %109, %170
  %172 = getelementptr inbounds float, float addrspace(1)* %0, i64 %171
  %173 = load float, float addrspace(1)* %172, align 4, !tbaa !6
  %174 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  store float %173, float addrspace(3)* %174, align 4, !tbaa !6
  %175 = sext i32 %87 to i64
  %176 = add nsw i64 %109, %175
  %177 = getelementptr inbounds float, float addrspace(1)* %0, i64 %176
  %178 = load float, float addrspace(1)* %177, align 4, !tbaa !6
  %179 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  store float %178, float addrspace(3)* %179, align 4, !tbaa !6
  %180 = sext i32 %93 to i64
  %181 = add nsw i64 %109, %180
  %182 = getelementptr inbounds float, float addrspace(1)* %0, i64 %181
  %183 = load float, float addrspace(1)* %182, align 4, !tbaa !6
  %184 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  store float %183, float addrspace(3)* %184, align 4, !tbaa !6
  %185 = sext i32 %99 to i64
  %186 = add nsw i64 %109, %185
  %187 = getelementptr inbounds float, float addrspace(1)* %0, i64 %186
  %188 = load float, float addrspace(1)* %187, align 4, !tbaa !6
  %189 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  store float %188, float addrspace(3)* %189, align 4, !tbaa !6
  %190 = add nsw i32 %99, %1
  %191 = sext i32 %190 to i64
  %192 = add nsw i64 %109, %191
  %193 = getelementptr inbounds float, float addrspace(1)* %0, i64 %192
  %194 = load float, float addrspace(1)* %193, align 4, !tbaa !6
  %195 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  store float %194, float addrspace(3)* %195, align 4, !tbaa !6
  %196 = add nsw i32 %190, %1
  %197 = sext i32 %196 to i64
  %198 = add nsw i64 %109, %197
  %199 = getelementptr inbounds float, float addrspace(1)* %0, i64 %198
  %200 = load float, float addrspace(1)* %199, align 4, !tbaa !6
  %201 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  store float %200, float addrspace(3)* %201, align 4, !tbaa !6
  %202 = add nsw i32 %196, %1
  %203 = sext i32 %202 to i64
  %204 = add nsw i64 %109, %203
  %205 = getelementptr inbounds float, float addrspace(1)* %0, i64 %204
  %206 = load float, float addrspace(1)* %205, align 4, !tbaa !6
  %207 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  store float %206, float addrspace(3)* %207, align 4, !tbaa !6
  %208 = add nsw i32 %202, %1
  %209 = sext i32 %208 to i64
  %210 = add nsw i64 %109, %209
  %211 = getelementptr inbounds float, float addrspace(1)* %0, i64 %210
  %212 = load float, float addrspace(1)* %211, align 4, !tbaa !6
  %213 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 19, i32 %4
  store float %212, float addrspace(3)* %213, align 4, !tbaa !6
  %214 = add nsw i32 %208, %1
  %215 = sext i32 %214 to i64
  %216 = add nsw i64 %109, %215
  %217 = getelementptr inbounds float, float addrspace(1)* %0, i64 %216
  %218 = load float, float addrspace(1)* %217, align 4, !tbaa !6
  %219 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 20, i32 %4
  store float %218, float addrspace(3)* %219, align 4, !tbaa !6
  %220 = add nsw i32 %214, %1
  %221 = sext i32 %220 to i64
  %222 = add nsw i64 %109, %221
  %223 = getelementptr inbounds float, float addrspace(1)* %0, i64 %222
  %224 = load float, float addrspace(1)* %223, align 4, !tbaa !6
  %225 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 21, i32 %4
  store float %224, float addrspace(3)* %225, align 4, !tbaa !6
  %226 = add nsw i32 %220, %1
  %227 = sext i32 %226 to i64
  %228 = add nsw i64 %109, %227
  %229 = getelementptr inbounds float, float addrspace(1)* %0, i64 %228
  %230 = load float, float addrspace(1)* %229, align 4, !tbaa !6
  %231 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 22, i32 %4
  store float %230, float addrspace(3)* %231, align 4, !tbaa !6
  %232 = add nsw i32 %226, %1
  %233 = sext i32 %232 to i64
  %234 = add nsw i64 %109, %233
  %235 = getelementptr inbounds float, float addrspace(1)* %0, i64 %234
  %236 = load float, float addrspace(1)* %235, align 4, !tbaa !6
  %237 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 23, i32 %4
  store float %236, float addrspace(3)* %237, align 4, !tbaa !6
  %238 = add nsw i32 %232, %1
  %239 = sext i32 %238 to i64
  %240 = add nsw i64 %109, %239
  %241 = getelementptr inbounds float, float addrspace(1)* %0, i64 %240
  %242 = load float, float addrspace(1)* %241, align 4, !tbaa !6
  %243 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 24, i32 %4
  store float %242, float addrspace(3)* %243, align 4, !tbaa !6
  %244 = add nsw i32 %238, %1
  %245 = sext i32 %244 to i64
  %246 = add nsw i64 %109, %245
  %247 = getelementptr inbounds float, float addrspace(1)* %0, i64 %246
  %248 = load float, float addrspace(1)* %247, align 4, !tbaa !6
  %249 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 25, i32 %4
  store float %248, float addrspace(3)* %249, align 4, !tbaa !6
  %250 = add nsw i32 %244, %1
  %251 = sext i32 %250 to i64
  %252 = add nsw i64 %109, %251
  %253 = getelementptr inbounds float, float addrspace(1)* %0, i64 %252
  %254 = load float, float addrspace(1)* %253, align 4, !tbaa !6
  %255 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 26, i32 %4
  store float %254, float addrspace(3)* %255, align 4, !tbaa !6
  %256 = add nsw i32 %250, %1
  %257 = sext i32 %256 to i64
  %258 = add nsw i64 %109, %257
  %259 = getelementptr inbounds float, float addrspace(1)* %0, i64 %258
  %260 = load float, float addrspace(1)* %259, align 4, !tbaa !6
  %261 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 27, i32 %4
  store float %260, float addrspace(3)* %261, align 4, !tbaa !6
  %262 = add nsw i32 %256, %1
  %263 = sext i32 %262 to i64
  %264 = add nsw i64 %109, %263
  %265 = getelementptr inbounds float, float addrspace(1)* %0, i64 %264
  %266 = load float, float addrspace(1)* %265, align 4, !tbaa !6
  %267 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 28, i32 %4
  store float %266, float addrspace(3)* %267, align 4, !tbaa !6
  %268 = add nsw i32 %262, %1
  %269 = sext i32 %268 to i64
  %270 = add nsw i64 %109, %269
  %271 = getelementptr inbounds float, float addrspace(1)* %0, i64 %270
  %272 = load float, float addrspace(1)* %271, align 4, !tbaa !6
  %273 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 29, i32 %4
  store float %272, float addrspace(3)* %273, align 4, !tbaa !6
  %274 = add nsw i32 %268, %1
  %275 = sext i32 %274 to i64
  %276 = add nsw i64 %109, %275
  %277 = getelementptr inbounds float, float addrspace(1)* %0, i64 %276
  %278 = load float, float addrspace(1)* %277, align 4, !tbaa !6
  %279 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 30, i32 %4
  store float %278, float addrspace(3)* %279, align 4, !tbaa !6
  %280 = add nsw i32 %274, %1
  %281 = sext i32 %280 to i64
  %282 = add nsw i64 %109, %281
  %283 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 31, i32 %4
  br label %579

284:                                              ; preds = %3
  %285 = add nsw i32 %4, -32
  %286 = add nsw i32 %2, 16
  %287 = mul nsw i32 %286, %1
  %288 = add nsw i32 %287, %2
  %289 = add nsw i32 %288, %285
  %290 = sext i32 %289 to i64
  %291 = getelementptr inbounds float, float addrspace(1)* %0, i64 %290
  %292 = load float, float addrspace(1)* %291, align 4, !tbaa !6
  %293 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 %285
  store float %292, float addrspace(3)* %293, align 4, !tbaa !6
  %294 = add nsw i32 %288, %1
  %295 = add nsw i32 %294, %285
  %296 = sext i32 %295 to i64
  %297 = getelementptr inbounds float, float addrspace(1)* %0, i64 %296
  %298 = load float, float addrspace(1)* %297, align 4, !tbaa !6
  %299 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 %285
  store float %298, float addrspace(3)* %299, align 4, !tbaa !6
  %300 = add nsw i32 %294, %1
  %301 = add nsw i32 %300, %285
  %302 = sext i32 %301 to i64
  %303 = getelementptr inbounds float, float addrspace(1)* %0, i64 %302
  %304 = load float, float addrspace(1)* %303, align 4, !tbaa !6
  %305 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 %285
  store float %304, float addrspace(3)* %305, align 4, !tbaa !6
  %306 = add nsw i32 %300, %1
  %307 = add nsw i32 %306, %285
  %308 = sext i32 %307 to i64
  %309 = getelementptr inbounds float, float addrspace(1)* %0, i64 %308
  %310 = load float, float addrspace(1)* %309, align 4, !tbaa !6
  %311 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 %285
  store float %310, float addrspace(3)* %311, align 4, !tbaa !6
  %312 = add nsw i32 %306, %1
  %313 = add nsw i32 %312, %285
  %314 = sext i32 %313 to i64
  %315 = getelementptr inbounds float, float addrspace(1)* %0, i64 %314
  %316 = load float, float addrspace(1)* %315, align 4, !tbaa !6
  %317 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 %285
  store float %316, float addrspace(3)* %317, align 4, !tbaa !6
  %318 = add nsw i32 %312, %1
  %319 = add nsw i32 %318, %285
  %320 = sext i32 %319 to i64
  %321 = getelementptr inbounds float, float addrspace(1)* %0, i64 %320
  %322 = load float, float addrspace(1)* %321, align 4, !tbaa !6
  %323 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 %285
  store float %322, float addrspace(3)* %323, align 4, !tbaa !6
  %324 = add nsw i32 %318, %1
  %325 = add nsw i32 %324, %285
  %326 = sext i32 %325 to i64
  %327 = getelementptr inbounds float, float addrspace(1)* %0, i64 %326
  %328 = load float, float addrspace(1)* %327, align 4, !tbaa !6
  %329 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 %285
  store float %328, float addrspace(3)* %329, align 4, !tbaa !6
  %330 = add nsw i32 %324, %1
  %331 = add nsw i32 %330, %285
  %332 = sext i32 %331 to i64
  %333 = getelementptr inbounds float, float addrspace(1)* %0, i64 %332
  %334 = load float, float addrspace(1)* %333, align 4, !tbaa !6
  %335 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 %285
  store float %334, float addrspace(3)* %335, align 4, !tbaa !6
  %336 = add nsw i32 %330, %1
  %337 = add nsw i32 %336, %285
  %338 = sext i32 %337 to i64
  %339 = getelementptr inbounds float, float addrspace(1)* %0, i64 %338
  %340 = load float, float addrspace(1)* %339, align 4, !tbaa !6
  %341 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 %285
  store float %340, float addrspace(3)* %341, align 4, !tbaa !6
  %342 = add nsw i32 %336, %1
  %343 = add nsw i32 %342, %285
  %344 = sext i32 %343 to i64
  %345 = getelementptr inbounds float, float addrspace(1)* %0, i64 %344
  %346 = load float, float addrspace(1)* %345, align 4, !tbaa !6
  %347 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 %285
  store float %346, float addrspace(3)* %347, align 4, !tbaa !6
  %348 = add nsw i32 %342, %1
  %349 = add nsw i32 %348, %285
  %350 = sext i32 %349 to i64
  %351 = getelementptr inbounds float, float addrspace(1)* %0, i64 %350
  %352 = load float, float addrspace(1)* %351, align 4, !tbaa !6
  %353 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 %285
  store float %352, float addrspace(3)* %353, align 4, !tbaa !6
  %354 = add nsw i32 %348, %1
  %355 = add nsw i32 %354, %285
  %356 = sext i32 %355 to i64
  %357 = getelementptr inbounds float, float addrspace(1)* %0, i64 %356
  %358 = load float, float addrspace(1)* %357, align 4, !tbaa !6
  %359 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 %285
  store float %358, float addrspace(3)* %359, align 4, !tbaa !6
  %360 = add nsw i32 %354, %1
  %361 = add nsw i32 %360, %285
  %362 = sext i32 %361 to i64
  %363 = getelementptr inbounds float, float addrspace(1)* %0, i64 %362
  %364 = load float, float addrspace(1)* %363, align 4, !tbaa !6
  %365 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 %285
  store float %364, float addrspace(3)* %365, align 4, !tbaa !6
  %366 = add nsw i32 %360, %1
  %367 = add nsw i32 %366, %285
  %368 = sext i32 %367 to i64
  %369 = getelementptr inbounds float, float addrspace(1)* %0, i64 %368
  %370 = load float, float addrspace(1)* %369, align 4, !tbaa !6
  %371 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 %285
  store float %370, float addrspace(3)* %371, align 4, !tbaa !6
  %372 = add nsw i32 %366, %1
  %373 = add nsw i32 %372, %285
  %374 = sext i32 %373 to i64
  %375 = getelementptr inbounds float, float addrspace(1)* %0, i64 %374
  %376 = load float, float addrspace(1)* %375, align 4, !tbaa !6
  %377 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 %285
  store float %376, float addrspace(3)* %377, align 4, !tbaa !6
  %378 = add nsw i32 %372, %1
  %379 = add nsw i32 %378, %285
  %380 = sext i32 %379 to i64
  %381 = getelementptr inbounds float, float addrspace(1)* %0, i64 %380
  %382 = load float, float addrspace(1)* %381, align 4, !tbaa !6
  %383 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 %285
  store float %382, float addrspace(3)* %383, align 4, !tbaa !6
  %384 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %385 = shl i32 %384, 5
  %386 = add i32 %2, 32
  %387 = add i32 %386, %385
  %388 = mul i32 %387, %1
  %389 = add i32 %388, %2
  %390 = add nsw i32 %389, %285
  %391 = sext i32 %390 to i64
  %392 = getelementptr inbounds float, float addrspace(1)* %0, i64 %391
  %393 = load float, float addrspace(1)* %392, align 4, !tbaa !6
  %394 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 0, i32 %285
  store float %393, float addrspace(3)* %394, align 4, !tbaa !6
  %395 = add nsw i32 %389, %1
  %396 = add nsw i32 %395, %285
  %397 = sext i32 %396 to i64
  %398 = getelementptr inbounds float, float addrspace(1)* %0, i64 %397
  %399 = load float, float addrspace(1)* %398, align 4, !tbaa !6
  %400 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 1, i32 %285
  store float %399, float addrspace(3)* %400, align 4, !tbaa !6
  %401 = add nsw i32 %395, %1
  %402 = add nsw i32 %401, %285
  %403 = sext i32 %402 to i64
  %404 = getelementptr inbounds float, float addrspace(1)* %0, i64 %403
  %405 = load float, float addrspace(1)* %404, align 4, !tbaa !6
  %406 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 2, i32 %285
  store float %405, float addrspace(3)* %406, align 4, !tbaa !6
  %407 = add nsw i32 %401, %1
  %408 = add nsw i32 %407, %285
  %409 = sext i32 %408 to i64
  %410 = getelementptr inbounds float, float addrspace(1)* %0, i64 %409
  %411 = load float, float addrspace(1)* %410, align 4, !tbaa !6
  %412 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 3, i32 %285
  store float %411, float addrspace(3)* %412, align 4, !tbaa !6
  %413 = add nsw i32 %407, %1
  %414 = add nsw i32 %413, %285
  %415 = sext i32 %414 to i64
  %416 = getelementptr inbounds float, float addrspace(1)* %0, i64 %415
  %417 = load float, float addrspace(1)* %416, align 4, !tbaa !6
  %418 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 4, i32 %285
  store float %417, float addrspace(3)* %418, align 4, !tbaa !6
  %419 = add nsw i32 %413, %1
  %420 = add nsw i32 %419, %285
  %421 = sext i32 %420 to i64
  %422 = getelementptr inbounds float, float addrspace(1)* %0, i64 %421
  %423 = load float, float addrspace(1)* %422, align 4, !tbaa !6
  %424 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 5, i32 %285
  store float %423, float addrspace(3)* %424, align 4, !tbaa !6
  %425 = add nsw i32 %419, %1
  %426 = add nsw i32 %425, %285
  %427 = sext i32 %426 to i64
  %428 = getelementptr inbounds float, float addrspace(1)* %0, i64 %427
  %429 = load float, float addrspace(1)* %428, align 4, !tbaa !6
  %430 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 6, i32 %285
  store float %429, float addrspace(3)* %430, align 4, !tbaa !6
  %431 = add nsw i32 %425, %1
  %432 = add nsw i32 %431, %285
  %433 = sext i32 %432 to i64
  %434 = getelementptr inbounds float, float addrspace(1)* %0, i64 %433
  %435 = load float, float addrspace(1)* %434, align 4, !tbaa !6
  %436 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 7, i32 %285
  store float %435, float addrspace(3)* %436, align 4, !tbaa !6
  %437 = add nsw i32 %431, %1
  %438 = add nsw i32 %437, %285
  %439 = sext i32 %438 to i64
  %440 = getelementptr inbounds float, float addrspace(1)* %0, i64 %439
  %441 = load float, float addrspace(1)* %440, align 4, !tbaa !6
  %442 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 8, i32 %285
  store float %441, float addrspace(3)* %442, align 4, !tbaa !6
  %443 = add nsw i32 %437, %1
  %444 = add nsw i32 %443, %285
  %445 = sext i32 %444 to i64
  %446 = getelementptr inbounds float, float addrspace(1)* %0, i64 %445
  %447 = load float, float addrspace(1)* %446, align 4, !tbaa !6
  %448 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 9, i32 %285
  store float %447, float addrspace(3)* %448, align 4, !tbaa !6
  %449 = add nsw i32 %443, %1
  %450 = add nsw i32 %449, %285
  %451 = sext i32 %450 to i64
  %452 = getelementptr inbounds float, float addrspace(1)* %0, i64 %451
  %453 = load float, float addrspace(1)* %452, align 4, !tbaa !6
  %454 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 10, i32 %285
  store float %453, float addrspace(3)* %454, align 4, !tbaa !6
  %455 = add nsw i32 %449, %1
  %456 = add nsw i32 %455, %285
  %457 = sext i32 %456 to i64
  %458 = getelementptr inbounds float, float addrspace(1)* %0, i64 %457
  %459 = load float, float addrspace(1)* %458, align 4, !tbaa !6
  %460 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 11, i32 %285
  store float %459, float addrspace(3)* %460, align 4, !tbaa !6
  %461 = add nsw i32 %455, %1
  %462 = add nsw i32 %461, %285
  %463 = sext i32 %462 to i64
  %464 = getelementptr inbounds float, float addrspace(1)* %0, i64 %463
  %465 = load float, float addrspace(1)* %464, align 4, !tbaa !6
  %466 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 12, i32 %285
  store float %465, float addrspace(3)* %466, align 4, !tbaa !6
  %467 = add nsw i32 %461, %1
  %468 = add nsw i32 %467, %285
  %469 = sext i32 %468 to i64
  %470 = getelementptr inbounds float, float addrspace(1)* %0, i64 %469
  %471 = load float, float addrspace(1)* %470, align 4, !tbaa !6
  %472 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 13, i32 %285
  store float %471, float addrspace(3)* %472, align 4, !tbaa !6
  %473 = add nsw i32 %467, %1
  %474 = add nsw i32 %473, %285
  %475 = sext i32 %474 to i64
  %476 = getelementptr inbounds float, float addrspace(1)* %0, i64 %475
  %477 = load float, float addrspace(1)* %476, align 4, !tbaa !6
  %478 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 14, i32 %285
  store float %477, float addrspace(3)* %478, align 4, !tbaa !6
  %479 = add nsw i32 %473, %1
  %480 = add nsw i32 %479, %285
  %481 = sext i32 %480 to i64
  %482 = getelementptr inbounds float, float addrspace(1)* %0, i64 %481
  %483 = load float, float addrspace(1)* %482, align 4, !tbaa !6
  %484 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 15, i32 %285
  store float %483, float addrspace(3)* %484, align 4, !tbaa !6
  %485 = add nsw i32 %479, %1
  %486 = add nsw i32 %485, %285
  %487 = sext i32 %486 to i64
  %488 = getelementptr inbounds float, float addrspace(1)* %0, i64 %487
  %489 = load float, float addrspace(1)* %488, align 4, !tbaa !6
  %490 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 16, i32 %285
  store float %489, float addrspace(3)* %490, align 4, !tbaa !6
  %491 = add nsw i32 %485, %1
  %492 = add nsw i32 %491, %285
  %493 = sext i32 %492 to i64
  %494 = getelementptr inbounds float, float addrspace(1)* %0, i64 %493
  %495 = load float, float addrspace(1)* %494, align 4, !tbaa !6
  %496 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 17, i32 %285
  store float %495, float addrspace(3)* %496, align 4, !tbaa !6
  %497 = add nsw i32 %491, %1
  %498 = add nsw i32 %497, %285
  %499 = sext i32 %498 to i64
  %500 = getelementptr inbounds float, float addrspace(1)* %0, i64 %499
  %501 = load float, float addrspace(1)* %500, align 4, !tbaa !6
  %502 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 18, i32 %285
  store float %501, float addrspace(3)* %502, align 4, !tbaa !6
  %503 = add nsw i32 %497, %1
  %504 = add nsw i32 %503, %285
  %505 = sext i32 %504 to i64
  %506 = getelementptr inbounds float, float addrspace(1)* %0, i64 %505
  %507 = load float, float addrspace(1)* %506, align 4, !tbaa !6
  %508 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 19, i32 %285
  store float %507, float addrspace(3)* %508, align 4, !tbaa !6
  %509 = add nsw i32 %503, %1
  %510 = add nsw i32 %509, %285
  %511 = sext i32 %510 to i64
  %512 = getelementptr inbounds float, float addrspace(1)* %0, i64 %511
  %513 = load float, float addrspace(1)* %512, align 4, !tbaa !6
  %514 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 20, i32 %285
  store float %513, float addrspace(3)* %514, align 4, !tbaa !6
  %515 = add nsw i32 %509, %1
  %516 = add nsw i32 %515, %285
  %517 = sext i32 %516 to i64
  %518 = getelementptr inbounds float, float addrspace(1)* %0, i64 %517
  %519 = load float, float addrspace(1)* %518, align 4, !tbaa !6
  %520 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 21, i32 %285
  store float %519, float addrspace(3)* %520, align 4, !tbaa !6
  %521 = add nsw i32 %515, %1
  %522 = add nsw i32 %521, %285
  %523 = sext i32 %522 to i64
  %524 = getelementptr inbounds float, float addrspace(1)* %0, i64 %523
  %525 = load float, float addrspace(1)* %524, align 4, !tbaa !6
  %526 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 22, i32 %285
  store float %525, float addrspace(3)* %526, align 4, !tbaa !6
  %527 = add nsw i32 %521, %1
  %528 = add nsw i32 %527, %285
  %529 = sext i32 %528 to i64
  %530 = getelementptr inbounds float, float addrspace(1)* %0, i64 %529
  %531 = load float, float addrspace(1)* %530, align 4, !tbaa !6
  %532 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 23, i32 %285
  store float %531, float addrspace(3)* %532, align 4, !tbaa !6
  %533 = add nsw i32 %527, %1
  %534 = add nsw i32 %533, %285
  %535 = sext i32 %534 to i64
  %536 = getelementptr inbounds float, float addrspace(1)* %0, i64 %535
  %537 = load float, float addrspace(1)* %536, align 4, !tbaa !6
  %538 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 24, i32 %285
  store float %537, float addrspace(3)* %538, align 4, !tbaa !6
  %539 = add nsw i32 %533, %1
  %540 = add nsw i32 %539, %285
  %541 = sext i32 %540 to i64
  %542 = getelementptr inbounds float, float addrspace(1)* %0, i64 %541
  %543 = load float, float addrspace(1)* %542, align 4, !tbaa !6
  %544 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 25, i32 %285
  store float %543, float addrspace(3)* %544, align 4, !tbaa !6
  %545 = add nsw i32 %539, %1
  %546 = add nsw i32 %545, %285
  %547 = sext i32 %546 to i64
  %548 = getelementptr inbounds float, float addrspace(1)* %0, i64 %547
  %549 = load float, float addrspace(1)* %548, align 4, !tbaa !6
  %550 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 26, i32 %285
  store float %549, float addrspace(3)* %550, align 4, !tbaa !6
  %551 = add nsw i32 %545, %1
  %552 = add nsw i32 %551, %285
  %553 = sext i32 %552 to i64
  %554 = getelementptr inbounds float, float addrspace(1)* %0, i64 %553
  %555 = load float, float addrspace(1)* %554, align 4, !tbaa !6
  %556 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 27, i32 %285
  store float %555, float addrspace(3)* %556, align 4, !tbaa !6
  %557 = add nsw i32 %551, %1
  %558 = add nsw i32 %557, %285
  %559 = sext i32 %558 to i64
  %560 = getelementptr inbounds float, float addrspace(1)* %0, i64 %559
  %561 = load float, float addrspace(1)* %560, align 4, !tbaa !6
  %562 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 28, i32 %285
  store float %561, float addrspace(3)* %562, align 4, !tbaa !6
  %563 = add nsw i32 %557, %1
  %564 = add nsw i32 %563, %285
  %565 = sext i32 %564 to i64
  %566 = getelementptr inbounds float, float addrspace(1)* %0, i64 %565
  %567 = load float, float addrspace(1)* %566, align 4, !tbaa !6
  %568 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 29, i32 %285
  store float %567, float addrspace(3)* %568, align 4, !tbaa !6
  %569 = add nsw i32 %563, %1
  %570 = add nsw i32 %569, %285
  %571 = sext i32 %570 to i64
  %572 = getelementptr inbounds float, float addrspace(1)* %0, i64 %571
  %573 = load float, float addrspace(1)* %572, align 4, !tbaa !6
  %574 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 30, i32 %285
  store float %573, float addrspace(3)* %574, align 4, !tbaa !6
  %575 = add nsw i32 %569, %1
  %576 = add nsw i32 %575, %285
  %577 = sext i32 %576 to i64
  %578 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 31, i32 %285
  br label %579

579:                                              ; preds = %284, %7
  %580 = phi float addrspace(3)* [ %578, %284 ], [ %283, %7 ]
  %581 = phi i64 [ %577, %284 ], [ %282, %7 ]
  %582 = getelementptr inbounds float, float addrspace(1)* %0, i64 %581
  %583 = load float, float addrspace(1)* %582, align 4, !tbaa !6
  store float %583, float addrspace(3)* %580, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %6, label %584, label %3127

584:                                              ; preds = %579
  %585 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %586 = load float, float addrspace(3)* %585, align 4, !tbaa !6
  %587 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 0), align 16, !tbaa !6
  %588 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %589 = load float, float addrspace(3)* %588, align 4, !tbaa !6
  %590 = fmul contract float %587, %589
  %591 = fsub contract float %586, %590
  store float %591, float addrspace(3)* %585, align 4, !tbaa !6
  %592 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %593 = load float, float addrspace(3)* %592, align 4, !tbaa !6
  %594 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 0), align 16, !tbaa !6
  %595 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %596 = load float, float addrspace(3)* %595, align 4, !tbaa !6
  %597 = fmul contract float %594, %596
  %598 = fsub contract float %593, %597
  store float %598, float addrspace(3)* %592, align 4, !tbaa !6
  %599 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 1), align 4, !tbaa !6
  %600 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %601 = load float, float addrspace(3)* %600, align 4, !tbaa !6
  %602 = fmul contract float %599, %601
  %603 = fsub contract float %598, %602
  store float %603, float addrspace(3)* %592, align 4, !tbaa !6
  %604 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %605 = load float, float addrspace(3)* %604, align 4, !tbaa !6
  %606 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 0), align 16, !tbaa !6
  %607 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %608 = load float, float addrspace(3)* %607, align 4, !tbaa !6
  %609 = fmul contract float %606, %608
  %610 = fsub contract float %605, %609
  store float %610, float addrspace(3)* %604, align 4, !tbaa !6
  %611 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 1), align 4, !tbaa !6
  %612 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %613 = load float, float addrspace(3)* %612, align 4, !tbaa !6
  %614 = fmul contract float %611, %613
  %615 = fsub contract float %610, %614
  store float %615, float addrspace(3)* %604, align 4, !tbaa !6
  %616 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 2), align 8, !tbaa !6
  %617 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %618 = load float, float addrspace(3)* %617, align 4, !tbaa !6
  %619 = fmul contract float %616, %618
  %620 = fsub contract float %615, %619
  store float %620, float addrspace(3)* %604, align 4, !tbaa !6
  %621 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %622 = load float, float addrspace(3)* %621, align 4, !tbaa !6
  %623 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 0), align 16, !tbaa !6
  %624 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %625 = load float, float addrspace(3)* %624, align 4, !tbaa !6
  %626 = fmul contract float %623, %625
  %627 = fsub contract float %622, %626
  store float %627, float addrspace(3)* %621, align 4, !tbaa !6
  %628 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 1), align 4, !tbaa !6
  %629 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %630 = load float, float addrspace(3)* %629, align 4, !tbaa !6
  %631 = fmul contract float %628, %630
  %632 = fsub contract float %627, %631
  store float %632, float addrspace(3)* %621, align 4, !tbaa !6
  %633 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 2), align 8, !tbaa !6
  %634 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %635 = load float, float addrspace(3)* %634, align 4, !tbaa !6
  %636 = fmul contract float %633, %635
  %637 = fsub contract float %632, %636
  store float %637, float addrspace(3)* %621, align 4, !tbaa !6
  %638 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 3), align 4, !tbaa !6
  %639 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %640 = load float, float addrspace(3)* %639, align 4, !tbaa !6
  %641 = fmul contract float %638, %640
  %642 = fsub contract float %637, %641
  store float %642, float addrspace(3)* %621, align 4, !tbaa !6
  %643 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %644 = load float, float addrspace(3)* %643, align 4, !tbaa !6
  %645 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 0), align 16, !tbaa !6
  %646 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %647 = load float, float addrspace(3)* %646, align 4, !tbaa !6
  %648 = fmul contract float %645, %647
  %649 = fsub contract float %644, %648
  store float %649, float addrspace(3)* %643, align 4, !tbaa !6
  %650 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 1), align 4, !tbaa !6
  %651 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %652 = load float, float addrspace(3)* %651, align 4, !tbaa !6
  %653 = fmul contract float %650, %652
  %654 = fsub contract float %649, %653
  store float %654, float addrspace(3)* %643, align 4, !tbaa !6
  %655 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 2), align 8, !tbaa !6
  %656 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %657 = load float, float addrspace(3)* %656, align 4, !tbaa !6
  %658 = fmul contract float %655, %657
  %659 = fsub contract float %654, %658
  store float %659, float addrspace(3)* %643, align 4, !tbaa !6
  %660 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 3), align 4, !tbaa !6
  %661 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %662 = load float, float addrspace(3)* %661, align 4, !tbaa !6
  %663 = fmul contract float %660, %662
  %664 = fsub contract float %659, %663
  store float %664, float addrspace(3)* %643, align 4, !tbaa !6
  %665 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 4), align 16, !tbaa !6
  %666 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %667 = load float, float addrspace(3)* %666, align 4, !tbaa !6
  %668 = fmul contract float %665, %667
  %669 = fsub contract float %664, %668
  store float %669, float addrspace(3)* %643, align 4, !tbaa !6
  %670 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %671 = load float, float addrspace(3)* %670, align 4, !tbaa !6
  %672 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 0), align 16, !tbaa !6
  %673 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %674 = load float, float addrspace(3)* %673, align 4, !tbaa !6
  %675 = fmul contract float %672, %674
  %676 = fsub contract float %671, %675
  store float %676, float addrspace(3)* %670, align 4, !tbaa !6
  %677 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 1), align 4, !tbaa !6
  %678 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %679 = load float, float addrspace(3)* %678, align 4, !tbaa !6
  %680 = fmul contract float %677, %679
  %681 = fsub contract float %676, %680
  store float %681, float addrspace(3)* %670, align 4, !tbaa !6
  %682 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 2), align 8, !tbaa !6
  %683 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %684 = load float, float addrspace(3)* %683, align 4, !tbaa !6
  %685 = fmul contract float %682, %684
  %686 = fsub contract float %681, %685
  store float %686, float addrspace(3)* %670, align 4, !tbaa !6
  %687 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 3), align 4, !tbaa !6
  %688 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %689 = load float, float addrspace(3)* %688, align 4, !tbaa !6
  %690 = fmul contract float %687, %689
  %691 = fsub contract float %686, %690
  store float %691, float addrspace(3)* %670, align 4, !tbaa !6
  %692 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 4), align 16, !tbaa !6
  %693 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %694 = load float, float addrspace(3)* %693, align 4, !tbaa !6
  %695 = fmul contract float %692, %694
  %696 = fsub contract float %691, %695
  store float %696, float addrspace(3)* %670, align 4, !tbaa !6
  %697 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 5), align 4, !tbaa !6
  %698 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %699 = load float, float addrspace(3)* %698, align 4, !tbaa !6
  %700 = fmul contract float %697, %699
  %701 = fsub contract float %696, %700
  store float %701, float addrspace(3)* %670, align 4, !tbaa !6
  %702 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %703 = load float, float addrspace(3)* %702, align 4, !tbaa !6
  %704 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 0), align 16, !tbaa !6
  %705 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %706 = load float, float addrspace(3)* %705, align 4, !tbaa !6
  %707 = fmul contract float %704, %706
  %708 = fsub contract float %703, %707
  store float %708, float addrspace(3)* %702, align 4, !tbaa !6
  %709 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 1), align 4, !tbaa !6
  %710 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %711 = load float, float addrspace(3)* %710, align 4, !tbaa !6
  %712 = fmul contract float %709, %711
  %713 = fsub contract float %708, %712
  store float %713, float addrspace(3)* %702, align 4, !tbaa !6
  %714 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 2), align 8, !tbaa !6
  %715 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %716 = load float, float addrspace(3)* %715, align 4, !tbaa !6
  %717 = fmul contract float %714, %716
  %718 = fsub contract float %713, %717
  store float %718, float addrspace(3)* %702, align 4, !tbaa !6
  %719 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 3), align 4, !tbaa !6
  %720 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %721 = load float, float addrspace(3)* %720, align 4, !tbaa !6
  %722 = fmul contract float %719, %721
  %723 = fsub contract float %718, %722
  store float %723, float addrspace(3)* %702, align 4, !tbaa !6
  %724 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 4), align 16, !tbaa !6
  %725 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %726 = load float, float addrspace(3)* %725, align 4, !tbaa !6
  %727 = fmul contract float %724, %726
  %728 = fsub contract float %723, %727
  store float %728, float addrspace(3)* %702, align 4, !tbaa !6
  %729 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 5), align 4, !tbaa !6
  %730 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %731 = load float, float addrspace(3)* %730, align 4, !tbaa !6
  %732 = fmul contract float %729, %731
  %733 = fsub contract float %728, %732
  store float %733, float addrspace(3)* %702, align 4, !tbaa !6
  %734 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 6), align 8, !tbaa !6
  %735 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %736 = load float, float addrspace(3)* %735, align 4, !tbaa !6
  %737 = fmul contract float %734, %736
  %738 = fsub contract float %733, %737
  store float %738, float addrspace(3)* %702, align 4, !tbaa !6
  %739 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %740 = load float, float addrspace(3)* %739, align 4, !tbaa !6
  %741 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 0), align 16, !tbaa !6
  %742 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %743 = load float, float addrspace(3)* %742, align 4, !tbaa !6
  %744 = fmul contract float %741, %743
  %745 = fsub contract float %740, %744
  store float %745, float addrspace(3)* %739, align 4, !tbaa !6
  %746 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 1), align 4, !tbaa !6
  %747 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %748 = load float, float addrspace(3)* %747, align 4, !tbaa !6
  %749 = fmul contract float %746, %748
  %750 = fsub contract float %745, %749
  store float %750, float addrspace(3)* %739, align 4, !tbaa !6
  %751 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 2), align 8, !tbaa !6
  %752 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %753 = load float, float addrspace(3)* %752, align 4, !tbaa !6
  %754 = fmul contract float %751, %753
  %755 = fsub contract float %750, %754
  store float %755, float addrspace(3)* %739, align 4, !tbaa !6
  %756 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 3), align 4, !tbaa !6
  %757 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %758 = load float, float addrspace(3)* %757, align 4, !tbaa !6
  %759 = fmul contract float %756, %758
  %760 = fsub contract float %755, %759
  store float %760, float addrspace(3)* %739, align 4, !tbaa !6
  %761 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 4), align 16, !tbaa !6
  %762 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %763 = load float, float addrspace(3)* %762, align 4, !tbaa !6
  %764 = fmul contract float %761, %763
  %765 = fsub contract float %760, %764
  store float %765, float addrspace(3)* %739, align 4, !tbaa !6
  %766 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 5), align 4, !tbaa !6
  %767 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %768 = load float, float addrspace(3)* %767, align 4, !tbaa !6
  %769 = fmul contract float %766, %768
  %770 = fsub contract float %765, %769
  store float %770, float addrspace(3)* %739, align 4, !tbaa !6
  %771 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 6), align 8, !tbaa !6
  %772 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %773 = load float, float addrspace(3)* %772, align 4, !tbaa !6
  %774 = fmul contract float %771, %773
  %775 = fsub contract float %770, %774
  store float %775, float addrspace(3)* %739, align 4, !tbaa !6
  %776 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 7), align 4, !tbaa !6
  %777 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %778 = load float, float addrspace(3)* %777, align 4, !tbaa !6
  %779 = fmul contract float %776, %778
  %780 = fsub contract float %775, %779
  store float %780, float addrspace(3)* %739, align 4, !tbaa !6
  %781 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %782 = load float, float addrspace(3)* %781, align 4, !tbaa !6
  %783 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 0), align 16, !tbaa !6
  %784 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %785 = load float, float addrspace(3)* %784, align 4, !tbaa !6
  %786 = fmul contract float %783, %785
  %787 = fsub contract float %782, %786
  store float %787, float addrspace(3)* %781, align 4, !tbaa !6
  %788 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 1), align 4, !tbaa !6
  %789 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %790 = load float, float addrspace(3)* %789, align 4, !tbaa !6
  %791 = fmul contract float %788, %790
  %792 = fsub contract float %787, %791
  store float %792, float addrspace(3)* %781, align 4, !tbaa !6
  %793 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 2), align 8, !tbaa !6
  %794 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %795 = load float, float addrspace(3)* %794, align 4, !tbaa !6
  %796 = fmul contract float %793, %795
  %797 = fsub contract float %792, %796
  store float %797, float addrspace(3)* %781, align 4, !tbaa !6
  %798 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 3), align 4, !tbaa !6
  %799 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %800 = load float, float addrspace(3)* %799, align 4, !tbaa !6
  %801 = fmul contract float %798, %800
  %802 = fsub contract float %797, %801
  store float %802, float addrspace(3)* %781, align 4, !tbaa !6
  %803 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 4), align 16, !tbaa !6
  %804 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %805 = load float, float addrspace(3)* %804, align 4, !tbaa !6
  %806 = fmul contract float %803, %805
  %807 = fsub contract float %802, %806
  store float %807, float addrspace(3)* %781, align 4, !tbaa !6
  %808 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 5), align 4, !tbaa !6
  %809 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %810 = load float, float addrspace(3)* %809, align 4, !tbaa !6
  %811 = fmul contract float %808, %810
  %812 = fsub contract float %807, %811
  store float %812, float addrspace(3)* %781, align 4, !tbaa !6
  %813 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 6), align 8, !tbaa !6
  %814 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %815 = load float, float addrspace(3)* %814, align 4, !tbaa !6
  %816 = fmul contract float %813, %815
  %817 = fsub contract float %812, %816
  store float %817, float addrspace(3)* %781, align 4, !tbaa !6
  %818 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 7), align 4, !tbaa !6
  %819 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %820 = load float, float addrspace(3)* %819, align 4, !tbaa !6
  %821 = fmul contract float %818, %820
  %822 = fsub contract float %817, %821
  store float %822, float addrspace(3)* %781, align 4, !tbaa !6
  %823 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 8), align 16, !tbaa !6
  %824 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %825 = load float, float addrspace(3)* %824, align 4, !tbaa !6
  %826 = fmul contract float %823, %825
  %827 = fsub contract float %822, %826
  store float %827, float addrspace(3)* %781, align 4, !tbaa !6
  %828 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %829 = load float, float addrspace(3)* %828, align 4, !tbaa !6
  %830 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 0), align 16, !tbaa !6
  %831 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %832 = load float, float addrspace(3)* %831, align 4, !tbaa !6
  %833 = fmul contract float %830, %832
  %834 = fsub contract float %829, %833
  store float %834, float addrspace(3)* %828, align 4, !tbaa !6
  %835 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 1), align 4, !tbaa !6
  %836 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %837 = load float, float addrspace(3)* %836, align 4, !tbaa !6
  %838 = fmul contract float %835, %837
  %839 = fsub contract float %834, %838
  store float %839, float addrspace(3)* %828, align 4, !tbaa !6
  %840 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 2), align 8, !tbaa !6
  %841 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %842 = load float, float addrspace(3)* %841, align 4, !tbaa !6
  %843 = fmul contract float %840, %842
  %844 = fsub contract float %839, %843
  store float %844, float addrspace(3)* %828, align 4, !tbaa !6
  %845 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 3), align 4, !tbaa !6
  %846 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %847 = load float, float addrspace(3)* %846, align 4, !tbaa !6
  %848 = fmul contract float %845, %847
  %849 = fsub contract float %844, %848
  store float %849, float addrspace(3)* %828, align 4, !tbaa !6
  %850 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 4), align 16, !tbaa !6
  %851 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %852 = load float, float addrspace(3)* %851, align 4, !tbaa !6
  %853 = fmul contract float %850, %852
  %854 = fsub contract float %849, %853
  store float %854, float addrspace(3)* %828, align 4, !tbaa !6
  %855 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 5), align 4, !tbaa !6
  %856 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %857 = load float, float addrspace(3)* %856, align 4, !tbaa !6
  %858 = fmul contract float %855, %857
  %859 = fsub contract float %854, %858
  store float %859, float addrspace(3)* %828, align 4, !tbaa !6
  %860 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 6), align 8, !tbaa !6
  %861 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %862 = load float, float addrspace(3)* %861, align 4, !tbaa !6
  %863 = fmul contract float %860, %862
  %864 = fsub contract float %859, %863
  store float %864, float addrspace(3)* %828, align 4, !tbaa !6
  %865 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 7), align 4, !tbaa !6
  %866 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %867 = load float, float addrspace(3)* %866, align 4, !tbaa !6
  %868 = fmul contract float %865, %867
  %869 = fsub contract float %864, %868
  store float %869, float addrspace(3)* %828, align 4, !tbaa !6
  %870 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 8), align 16, !tbaa !6
  %871 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %872 = load float, float addrspace(3)* %871, align 4, !tbaa !6
  %873 = fmul contract float %870, %872
  %874 = fsub contract float %869, %873
  store float %874, float addrspace(3)* %828, align 4, !tbaa !6
  %875 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 9), align 4, !tbaa !6
  %876 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %877 = load float, float addrspace(3)* %876, align 4, !tbaa !6
  %878 = fmul contract float %875, %877
  %879 = fsub contract float %874, %878
  store float %879, float addrspace(3)* %828, align 4, !tbaa !6
  %880 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %881 = load float, float addrspace(3)* %880, align 4, !tbaa !6
  %882 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 0), align 16, !tbaa !6
  %883 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %884 = load float, float addrspace(3)* %883, align 4, !tbaa !6
  %885 = fmul contract float %882, %884
  %886 = fsub contract float %881, %885
  store float %886, float addrspace(3)* %880, align 4, !tbaa !6
  %887 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 1), align 4, !tbaa !6
  %888 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %889 = load float, float addrspace(3)* %888, align 4, !tbaa !6
  %890 = fmul contract float %887, %889
  %891 = fsub contract float %886, %890
  store float %891, float addrspace(3)* %880, align 4, !tbaa !6
  %892 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 2), align 8, !tbaa !6
  %893 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %894 = load float, float addrspace(3)* %893, align 4, !tbaa !6
  %895 = fmul contract float %892, %894
  %896 = fsub contract float %891, %895
  store float %896, float addrspace(3)* %880, align 4, !tbaa !6
  %897 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 3), align 4, !tbaa !6
  %898 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %899 = load float, float addrspace(3)* %898, align 4, !tbaa !6
  %900 = fmul contract float %897, %899
  %901 = fsub contract float %896, %900
  store float %901, float addrspace(3)* %880, align 4, !tbaa !6
  %902 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 4), align 16, !tbaa !6
  %903 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %904 = load float, float addrspace(3)* %903, align 4, !tbaa !6
  %905 = fmul contract float %902, %904
  %906 = fsub contract float %901, %905
  store float %906, float addrspace(3)* %880, align 4, !tbaa !6
  %907 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 5), align 4, !tbaa !6
  %908 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %909 = load float, float addrspace(3)* %908, align 4, !tbaa !6
  %910 = fmul contract float %907, %909
  %911 = fsub contract float %906, %910
  store float %911, float addrspace(3)* %880, align 4, !tbaa !6
  %912 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 6), align 8, !tbaa !6
  %913 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %914 = load float, float addrspace(3)* %913, align 4, !tbaa !6
  %915 = fmul contract float %912, %914
  %916 = fsub contract float %911, %915
  store float %916, float addrspace(3)* %880, align 4, !tbaa !6
  %917 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 7), align 4, !tbaa !6
  %918 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %919 = load float, float addrspace(3)* %918, align 4, !tbaa !6
  %920 = fmul contract float %917, %919
  %921 = fsub contract float %916, %920
  store float %921, float addrspace(3)* %880, align 4, !tbaa !6
  %922 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 8), align 16, !tbaa !6
  %923 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %924 = load float, float addrspace(3)* %923, align 4, !tbaa !6
  %925 = fmul contract float %922, %924
  %926 = fsub contract float %921, %925
  store float %926, float addrspace(3)* %880, align 4, !tbaa !6
  %927 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 9), align 4, !tbaa !6
  %928 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %929 = load float, float addrspace(3)* %928, align 4, !tbaa !6
  %930 = fmul contract float %927, %929
  %931 = fsub contract float %926, %930
  store float %931, float addrspace(3)* %880, align 4, !tbaa !6
  %932 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 10), align 8, !tbaa !6
  %933 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %934 = load float, float addrspace(3)* %933, align 4, !tbaa !6
  %935 = fmul contract float %932, %934
  %936 = fsub contract float %931, %935
  store float %936, float addrspace(3)* %880, align 4, !tbaa !6
  %937 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %938 = load float, float addrspace(3)* %937, align 4, !tbaa !6
  %939 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 0), align 16, !tbaa !6
  %940 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %941 = load float, float addrspace(3)* %940, align 4, !tbaa !6
  %942 = fmul contract float %939, %941
  %943 = fsub contract float %938, %942
  store float %943, float addrspace(3)* %937, align 4, !tbaa !6
  %944 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 1), align 4, !tbaa !6
  %945 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %946 = load float, float addrspace(3)* %945, align 4, !tbaa !6
  %947 = fmul contract float %944, %946
  %948 = fsub contract float %943, %947
  store float %948, float addrspace(3)* %937, align 4, !tbaa !6
  %949 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 2), align 8, !tbaa !6
  %950 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %951 = load float, float addrspace(3)* %950, align 4, !tbaa !6
  %952 = fmul contract float %949, %951
  %953 = fsub contract float %948, %952
  store float %953, float addrspace(3)* %937, align 4, !tbaa !6
  %954 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 3), align 4, !tbaa !6
  %955 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %956 = load float, float addrspace(3)* %955, align 4, !tbaa !6
  %957 = fmul contract float %954, %956
  %958 = fsub contract float %953, %957
  store float %958, float addrspace(3)* %937, align 4, !tbaa !6
  %959 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 4), align 16, !tbaa !6
  %960 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %961 = load float, float addrspace(3)* %960, align 4, !tbaa !6
  %962 = fmul contract float %959, %961
  %963 = fsub contract float %958, %962
  store float %963, float addrspace(3)* %937, align 4, !tbaa !6
  %964 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 5), align 4, !tbaa !6
  %965 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %966 = load float, float addrspace(3)* %965, align 4, !tbaa !6
  %967 = fmul contract float %964, %966
  %968 = fsub contract float %963, %967
  store float %968, float addrspace(3)* %937, align 4, !tbaa !6
  %969 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 6), align 8, !tbaa !6
  %970 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %971 = load float, float addrspace(3)* %970, align 4, !tbaa !6
  %972 = fmul contract float %969, %971
  %973 = fsub contract float %968, %972
  store float %973, float addrspace(3)* %937, align 4, !tbaa !6
  %974 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 7), align 4, !tbaa !6
  %975 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %976 = load float, float addrspace(3)* %975, align 4, !tbaa !6
  %977 = fmul contract float %974, %976
  %978 = fsub contract float %973, %977
  store float %978, float addrspace(3)* %937, align 4, !tbaa !6
  %979 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 8), align 16, !tbaa !6
  %980 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %981 = load float, float addrspace(3)* %980, align 4, !tbaa !6
  %982 = fmul contract float %979, %981
  %983 = fsub contract float %978, %982
  store float %983, float addrspace(3)* %937, align 4, !tbaa !6
  %984 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 9), align 4, !tbaa !6
  %985 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %986 = load float, float addrspace(3)* %985, align 4, !tbaa !6
  %987 = fmul contract float %984, %986
  %988 = fsub contract float %983, %987
  store float %988, float addrspace(3)* %937, align 4, !tbaa !6
  %989 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 10), align 8, !tbaa !6
  %990 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %991 = load float, float addrspace(3)* %990, align 4, !tbaa !6
  %992 = fmul contract float %989, %991
  %993 = fsub contract float %988, %992
  store float %993, float addrspace(3)* %937, align 4, !tbaa !6
  %994 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 11), align 4, !tbaa !6
  %995 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %996 = load float, float addrspace(3)* %995, align 4, !tbaa !6
  %997 = fmul contract float %994, %996
  %998 = fsub contract float %993, %997
  store float %998, float addrspace(3)* %937, align 4, !tbaa !6
  %999 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %1000 = load float, float addrspace(3)* %999, align 4, !tbaa !6
  %1001 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 0), align 16, !tbaa !6
  %1002 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %1003 = load float, float addrspace(3)* %1002, align 4, !tbaa !6
  %1004 = fmul contract float %1001, %1003
  %1005 = fsub contract float %1000, %1004
  store float %1005, float addrspace(3)* %999, align 4, !tbaa !6
  %1006 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 1), align 4, !tbaa !6
  %1007 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %1008 = load float, float addrspace(3)* %1007, align 4, !tbaa !6
  %1009 = fmul contract float %1006, %1008
  %1010 = fsub contract float %1005, %1009
  store float %1010, float addrspace(3)* %999, align 4, !tbaa !6
  %1011 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 2), align 8, !tbaa !6
  %1012 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %1013 = load float, float addrspace(3)* %1012, align 4, !tbaa !6
  %1014 = fmul contract float %1011, %1013
  %1015 = fsub contract float %1010, %1014
  store float %1015, float addrspace(3)* %999, align 4, !tbaa !6
  %1016 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 3), align 4, !tbaa !6
  %1017 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %1018 = load float, float addrspace(3)* %1017, align 4, !tbaa !6
  %1019 = fmul contract float %1016, %1018
  %1020 = fsub contract float %1015, %1019
  store float %1020, float addrspace(3)* %999, align 4, !tbaa !6
  %1021 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 4), align 16, !tbaa !6
  %1022 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %1023 = load float, float addrspace(3)* %1022, align 4, !tbaa !6
  %1024 = fmul contract float %1021, %1023
  %1025 = fsub contract float %1020, %1024
  store float %1025, float addrspace(3)* %999, align 4, !tbaa !6
  %1026 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 5), align 4, !tbaa !6
  %1027 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %1028 = load float, float addrspace(3)* %1027, align 4, !tbaa !6
  %1029 = fmul contract float %1026, %1028
  %1030 = fsub contract float %1025, %1029
  store float %1030, float addrspace(3)* %999, align 4, !tbaa !6
  %1031 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 6), align 8, !tbaa !6
  %1032 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %1033 = load float, float addrspace(3)* %1032, align 4, !tbaa !6
  %1034 = fmul contract float %1031, %1033
  %1035 = fsub contract float %1030, %1034
  store float %1035, float addrspace(3)* %999, align 4, !tbaa !6
  %1036 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 7), align 4, !tbaa !6
  %1037 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %1038 = load float, float addrspace(3)* %1037, align 4, !tbaa !6
  %1039 = fmul contract float %1036, %1038
  %1040 = fsub contract float %1035, %1039
  store float %1040, float addrspace(3)* %999, align 4, !tbaa !6
  %1041 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 8), align 16, !tbaa !6
  %1042 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %1043 = load float, float addrspace(3)* %1042, align 4, !tbaa !6
  %1044 = fmul contract float %1041, %1043
  %1045 = fsub contract float %1040, %1044
  store float %1045, float addrspace(3)* %999, align 4, !tbaa !6
  %1046 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 9), align 4, !tbaa !6
  %1047 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %1048 = load float, float addrspace(3)* %1047, align 4, !tbaa !6
  %1049 = fmul contract float %1046, %1048
  %1050 = fsub contract float %1045, %1049
  store float %1050, float addrspace(3)* %999, align 4, !tbaa !6
  %1051 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 10), align 8, !tbaa !6
  %1052 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %1053 = load float, float addrspace(3)* %1052, align 4, !tbaa !6
  %1054 = fmul contract float %1051, %1053
  %1055 = fsub contract float %1050, %1054
  store float %1055, float addrspace(3)* %999, align 4, !tbaa !6
  %1056 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 11), align 4, !tbaa !6
  %1057 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %1058 = load float, float addrspace(3)* %1057, align 4, !tbaa !6
  %1059 = fmul contract float %1056, %1058
  %1060 = fsub contract float %1055, %1059
  store float %1060, float addrspace(3)* %999, align 4, !tbaa !6
  %1061 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 12), align 16, !tbaa !6
  %1062 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %1063 = load float, float addrspace(3)* %1062, align 4, !tbaa !6
  %1064 = fmul contract float %1061, %1063
  %1065 = fsub contract float %1060, %1064
  store float %1065, float addrspace(3)* %999, align 4, !tbaa !6
  %1066 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %1067 = load float, float addrspace(3)* %1066, align 4, !tbaa !6
  %1068 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 0), align 16, !tbaa !6
  %1069 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %1070 = load float, float addrspace(3)* %1069, align 4, !tbaa !6
  %1071 = fmul contract float %1068, %1070
  %1072 = fsub contract float %1067, %1071
  store float %1072, float addrspace(3)* %1066, align 4, !tbaa !6
  %1073 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 1), align 4, !tbaa !6
  %1074 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %1075 = load float, float addrspace(3)* %1074, align 4, !tbaa !6
  %1076 = fmul contract float %1073, %1075
  %1077 = fsub contract float %1072, %1076
  store float %1077, float addrspace(3)* %1066, align 4, !tbaa !6
  %1078 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 2), align 8, !tbaa !6
  %1079 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %1080 = load float, float addrspace(3)* %1079, align 4, !tbaa !6
  %1081 = fmul contract float %1078, %1080
  %1082 = fsub contract float %1077, %1081
  store float %1082, float addrspace(3)* %1066, align 4, !tbaa !6
  %1083 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 3), align 4, !tbaa !6
  %1084 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %1085 = load float, float addrspace(3)* %1084, align 4, !tbaa !6
  %1086 = fmul contract float %1083, %1085
  %1087 = fsub contract float %1082, %1086
  store float %1087, float addrspace(3)* %1066, align 4, !tbaa !6
  %1088 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 4), align 16, !tbaa !6
  %1089 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %1090 = load float, float addrspace(3)* %1089, align 4, !tbaa !6
  %1091 = fmul contract float %1088, %1090
  %1092 = fsub contract float %1087, %1091
  store float %1092, float addrspace(3)* %1066, align 4, !tbaa !6
  %1093 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 5), align 4, !tbaa !6
  %1094 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %1095 = load float, float addrspace(3)* %1094, align 4, !tbaa !6
  %1096 = fmul contract float %1093, %1095
  %1097 = fsub contract float %1092, %1096
  store float %1097, float addrspace(3)* %1066, align 4, !tbaa !6
  %1098 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 6), align 8, !tbaa !6
  %1099 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %1100 = load float, float addrspace(3)* %1099, align 4, !tbaa !6
  %1101 = fmul contract float %1098, %1100
  %1102 = fsub contract float %1097, %1101
  store float %1102, float addrspace(3)* %1066, align 4, !tbaa !6
  %1103 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 7), align 4, !tbaa !6
  %1104 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %1105 = load float, float addrspace(3)* %1104, align 4, !tbaa !6
  %1106 = fmul contract float %1103, %1105
  %1107 = fsub contract float %1102, %1106
  store float %1107, float addrspace(3)* %1066, align 4, !tbaa !6
  %1108 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 8), align 16, !tbaa !6
  %1109 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %1110 = load float, float addrspace(3)* %1109, align 4, !tbaa !6
  %1111 = fmul contract float %1108, %1110
  %1112 = fsub contract float %1107, %1111
  store float %1112, float addrspace(3)* %1066, align 4, !tbaa !6
  %1113 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 9), align 4, !tbaa !6
  %1114 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %1115 = load float, float addrspace(3)* %1114, align 4, !tbaa !6
  %1116 = fmul contract float %1113, %1115
  %1117 = fsub contract float %1112, %1116
  store float %1117, float addrspace(3)* %1066, align 4, !tbaa !6
  %1118 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 10), align 8, !tbaa !6
  %1119 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %1120 = load float, float addrspace(3)* %1119, align 4, !tbaa !6
  %1121 = fmul contract float %1118, %1120
  %1122 = fsub contract float %1117, %1121
  store float %1122, float addrspace(3)* %1066, align 4, !tbaa !6
  %1123 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 11), align 4, !tbaa !6
  %1124 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %1125 = load float, float addrspace(3)* %1124, align 4, !tbaa !6
  %1126 = fmul contract float %1123, %1125
  %1127 = fsub contract float %1122, %1126
  store float %1127, float addrspace(3)* %1066, align 4, !tbaa !6
  %1128 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 12), align 16, !tbaa !6
  %1129 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %1130 = load float, float addrspace(3)* %1129, align 4, !tbaa !6
  %1131 = fmul contract float %1128, %1130
  %1132 = fsub contract float %1127, %1131
  store float %1132, float addrspace(3)* %1066, align 4, !tbaa !6
  %1133 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 13), align 4, !tbaa !6
  %1134 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %1135 = load float, float addrspace(3)* %1134, align 4, !tbaa !6
  %1136 = fmul contract float %1133, %1135
  %1137 = fsub contract float %1132, %1136
  store float %1137, float addrspace(3)* %1066, align 4, !tbaa !6
  %1138 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %1139 = load float, float addrspace(3)* %1138, align 4, !tbaa !6
  %1140 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 0), align 16, !tbaa !6
  %1141 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %1142 = load float, float addrspace(3)* %1141, align 4, !tbaa !6
  %1143 = fmul contract float %1140, %1142
  %1144 = fsub contract float %1139, %1143
  store float %1144, float addrspace(3)* %1138, align 4, !tbaa !6
  %1145 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 1), align 4, !tbaa !6
  %1146 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %1147 = load float, float addrspace(3)* %1146, align 4, !tbaa !6
  %1148 = fmul contract float %1145, %1147
  %1149 = fsub contract float %1144, %1148
  store float %1149, float addrspace(3)* %1138, align 4, !tbaa !6
  %1150 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 2), align 8, !tbaa !6
  %1151 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %1152 = load float, float addrspace(3)* %1151, align 4, !tbaa !6
  %1153 = fmul contract float %1150, %1152
  %1154 = fsub contract float %1149, %1153
  store float %1154, float addrspace(3)* %1138, align 4, !tbaa !6
  %1155 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 3), align 4, !tbaa !6
  %1156 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %1157 = load float, float addrspace(3)* %1156, align 4, !tbaa !6
  %1158 = fmul contract float %1155, %1157
  %1159 = fsub contract float %1154, %1158
  store float %1159, float addrspace(3)* %1138, align 4, !tbaa !6
  %1160 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 4), align 16, !tbaa !6
  %1161 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %1162 = load float, float addrspace(3)* %1161, align 4, !tbaa !6
  %1163 = fmul contract float %1160, %1162
  %1164 = fsub contract float %1159, %1163
  store float %1164, float addrspace(3)* %1138, align 4, !tbaa !6
  %1165 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 5), align 4, !tbaa !6
  %1166 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %1167 = load float, float addrspace(3)* %1166, align 4, !tbaa !6
  %1168 = fmul contract float %1165, %1167
  %1169 = fsub contract float %1164, %1168
  store float %1169, float addrspace(3)* %1138, align 4, !tbaa !6
  %1170 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 6), align 8, !tbaa !6
  %1171 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %1172 = load float, float addrspace(3)* %1171, align 4, !tbaa !6
  %1173 = fmul contract float %1170, %1172
  %1174 = fsub contract float %1169, %1173
  store float %1174, float addrspace(3)* %1138, align 4, !tbaa !6
  %1175 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 7), align 4, !tbaa !6
  %1176 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %1177 = load float, float addrspace(3)* %1176, align 4, !tbaa !6
  %1178 = fmul contract float %1175, %1177
  %1179 = fsub contract float %1174, %1178
  store float %1179, float addrspace(3)* %1138, align 4, !tbaa !6
  %1180 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 8), align 16, !tbaa !6
  %1181 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %1182 = load float, float addrspace(3)* %1181, align 4, !tbaa !6
  %1183 = fmul contract float %1180, %1182
  %1184 = fsub contract float %1179, %1183
  store float %1184, float addrspace(3)* %1138, align 4, !tbaa !6
  %1185 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 9), align 4, !tbaa !6
  %1186 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %1187 = load float, float addrspace(3)* %1186, align 4, !tbaa !6
  %1188 = fmul contract float %1185, %1187
  %1189 = fsub contract float %1184, %1188
  store float %1189, float addrspace(3)* %1138, align 4, !tbaa !6
  %1190 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 10), align 8, !tbaa !6
  %1191 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %1192 = load float, float addrspace(3)* %1191, align 4, !tbaa !6
  %1193 = fmul contract float %1190, %1192
  %1194 = fsub contract float %1189, %1193
  store float %1194, float addrspace(3)* %1138, align 4, !tbaa !6
  %1195 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 11), align 4, !tbaa !6
  %1196 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %1197 = load float, float addrspace(3)* %1196, align 4, !tbaa !6
  %1198 = fmul contract float %1195, %1197
  %1199 = fsub contract float %1194, %1198
  store float %1199, float addrspace(3)* %1138, align 4, !tbaa !6
  %1200 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 12), align 16, !tbaa !6
  %1201 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %1202 = load float, float addrspace(3)* %1201, align 4, !tbaa !6
  %1203 = fmul contract float %1200, %1202
  %1204 = fsub contract float %1199, %1203
  store float %1204, float addrspace(3)* %1138, align 4, !tbaa !6
  %1205 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 13), align 4, !tbaa !6
  %1206 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %1207 = load float, float addrspace(3)* %1206, align 4, !tbaa !6
  %1208 = fmul contract float %1205, %1207
  %1209 = fsub contract float %1204, %1208
  store float %1209, float addrspace(3)* %1138, align 4, !tbaa !6
  %1210 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 14), align 8, !tbaa !6
  %1211 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %1212 = load float, float addrspace(3)* %1211, align 4, !tbaa !6
  %1213 = fmul contract float %1210, %1212
  %1214 = fsub contract float %1209, %1213
  store float %1214, float addrspace(3)* %1138, align 4, !tbaa !6
  %1215 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %1216 = load float, float addrspace(3)* %1215, align 4, !tbaa !6
  %1217 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 0), align 16, !tbaa !6
  %1218 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %1219 = load float, float addrspace(3)* %1218, align 4, !tbaa !6
  %1220 = fmul contract float %1217, %1219
  %1221 = fsub contract float %1216, %1220
  store float %1221, float addrspace(3)* %1215, align 4, !tbaa !6
  %1222 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 1), align 4, !tbaa !6
  %1223 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %1224 = load float, float addrspace(3)* %1223, align 4, !tbaa !6
  %1225 = fmul contract float %1222, %1224
  %1226 = fsub contract float %1221, %1225
  store float %1226, float addrspace(3)* %1215, align 4, !tbaa !6
  %1227 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 2), align 8, !tbaa !6
  %1228 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %1229 = load float, float addrspace(3)* %1228, align 4, !tbaa !6
  %1230 = fmul contract float %1227, %1229
  %1231 = fsub contract float %1226, %1230
  store float %1231, float addrspace(3)* %1215, align 4, !tbaa !6
  %1232 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 3), align 4, !tbaa !6
  %1233 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %1234 = load float, float addrspace(3)* %1233, align 4, !tbaa !6
  %1235 = fmul contract float %1232, %1234
  %1236 = fsub contract float %1231, %1235
  store float %1236, float addrspace(3)* %1215, align 4, !tbaa !6
  %1237 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 4), align 16, !tbaa !6
  %1238 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %1239 = load float, float addrspace(3)* %1238, align 4, !tbaa !6
  %1240 = fmul contract float %1237, %1239
  %1241 = fsub contract float %1236, %1240
  store float %1241, float addrspace(3)* %1215, align 4, !tbaa !6
  %1242 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 5), align 4, !tbaa !6
  %1243 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %1244 = load float, float addrspace(3)* %1243, align 4, !tbaa !6
  %1245 = fmul contract float %1242, %1244
  %1246 = fsub contract float %1241, %1245
  store float %1246, float addrspace(3)* %1215, align 4, !tbaa !6
  %1247 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 6), align 8, !tbaa !6
  %1248 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %1249 = load float, float addrspace(3)* %1248, align 4, !tbaa !6
  %1250 = fmul contract float %1247, %1249
  %1251 = fsub contract float %1246, %1250
  store float %1251, float addrspace(3)* %1215, align 4, !tbaa !6
  %1252 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 7), align 4, !tbaa !6
  %1253 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %1254 = load float, float addrspace(3)* %1253, align 4, !tbaa !6
  %1255 = fmul contract float %1252, %1254
  %1256 = fsub contract float %1251, %1255
  store float %1256, float addrspace(3)* %1215, align 4, !tbaa !6
  %1257 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 8), align 16, !tbaa !6
  %1258 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %1259 = load float, float addrspace(3)* %1258, align 4, !tbaa !6
  %1260 = fmul contract float %1257, %1259
  %1261 = fsub contract float %1256, %1260
  store float %1261, float addrspace(3)* %1215, align 4, !tbaa !6
  %1262 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 9), align 4, !tbaa !6
  %1263 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %1264 = load float, float addrspace(3)* %1263, align 4, !tbaa !6
  %1265 = fmul contract float %1262, %1264
  %1266 = fsub contract float %1261, %1265
  store float %1266, float addrspace(3)* %1215, align 4, !tbaa !6
  %1267 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 10), align 8, !tbaa !6
  %1268 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %1269 = load float, float addrspace(3)* %1268, align 4, !tbaa !6
  %1270 = fmul contract float %1267, %1269
  %1271 = fsub contract float %1266, %1270
  store float %1271, float addrspace(3)* %1215, align 4, !tbaa !6
  %1272 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 11), align 4, !tbaa !6
  %1273 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %1274 = load float, float addrspace(3)* %1273, align 4, !tbaa !6
  %1275 = fmul contract float %1272, %1274
  %1276 = fsub contract float %1271, %1275
  store float %1276, float addrspace(3)* %1215, align 4, !tbaa !6
  %1277 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 12), align 16, !tbaa !6
  %1278 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %1279 = load float, float addrspace(3)* %1278, align 4, !tbaa !6
  %1280 = fmul contract float %1277, %1279
  %1281 = fsub contract float %1276, %1280
  store float %1281, float addrspace(3)* %1215, align 4, !tbaa !6
  %1282 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 13), align 4, !tbaa !6
  %1283 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %1284 = load float, float addrspace(3)* %1283, align 4, !tbaa !6
  %1285 = fmul contract float %1282, %1284
  %1286 = fsub contract float %1281, %1285
  store float %1286, float addrspace(3)* %1215, align 4, !tbaa !6
  %1287 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 14), align 8, !tbaa !6
  %1288 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %1289 = load float, float addrspace(3)* %1288, align 4, !tbaa !6
  %1290 = fmul contract float %1287, %1289
  %1291 = fsub contract float %1286, %1290
  store float %1291, float addrspace(3)* %1215, align 4, !tbaa !6
  %1292 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 15), align 4, !tbaa !6
  %1293 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %1294 = load float, float addrspace(3)* %1293, align 4, !tbaa !6
  %1295 = fmul contract float %1292, %1294
  %1296 = fsub contract float %1291, %1295
  store float %1296, float addrspace(3)* %1215, align 4, !tbaa !6
  %1297 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %1298 = load float, float addrspace(3)* %1297, align 4, !tbaa !6
  %1299 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 0), align 16, !tbaa !6
  %1300 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %1301 = load float, float addrspace(3)* %1300, align 4, !tbaa !6
  %1302 = fmul contract float %1299, %1301
  %1303 = fsub contract float %1298, %1302
  store float %1303, float addrspace(3)* %1297, align 4, !tbaa !6
  %1304 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 1), align 4, !tbaa !6
  %1305 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %1306 = load float, float addrspace(3)* %1305, align 4, !tbaa !6
  %1307 = fmul contract float %1304, %1306
  %1308 = fsub contract float %1303, %1307
  store float %1308, float addrspace(3)* %1297, align 4, !tbaa !6
  %1309 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 2), align 8, !tbaa !6
  %1310 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %1311 = load float, float addrspace(3)* %1310, align 4, !tbaa !6
  %1312 = fmul contract float %1309, %1311
  %1313 = fsub contract float %1308, %1312
  store float %1313, float addrspace(3)* %1297, align 4, !tbaa !6
  %1314 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 3), align 4, !tbaa !6
  %1315 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %1316 = load float, float addrspace(3)* %1315, align 4, !tbaa !6
  %1317 = fmul contract float %1314, %1316
  %1318 = fsub contract float %1313, %1317
  store float %1318, float addrspace(3)* %1297, align 4, !tbaa !6
  %1319 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 4), align 16, !tbaa !6
  %1320 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %1321 = load float, float addrspace(3)* %1320, align 4, !tbaa !6
  %1322 = fmul contract float %1319, %1321
  %1323 = fsub contract float %1318, %1322
  store float %1323, float addrspace(3)* %1297, align 4, !tbaa !6
  %1324 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 5), align 4, !tbaa !6
  %1325 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %1326 = load float, float addrspace(3)* %1325, align 4, !tbaa !6
  %1327 = fmul contract float %1324, %1326
  %1328 = fsub contract float %1323, %1327
  store float %1328, float addrspace(3)* %1297, align 4, !tbaa !6
  %1329 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 6), align 8, !tbaa !6
  %1330 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %1331 = load float, float addrspace(3)* %1330, align 4, !tbaa !6
  %1332 = fmul contract float %1329, %1331
  %1333 = fsub contract float %1328, %1332
  store float %1333, float addrspace(3)* %1297, align 4, !tbaa !6
  %1334 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 7), align 4, !tbaa !6
  %1335 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %1336 = load float, float addrspace(3)* %1335, align 4, !tbaa !6
  %1337 = fmul contract float %1334, %1336
  %1338 = fsub contract float %1333, %1337
  store float %1338, float addrspace(3)* %1297, align 4, !tbaa !6
  %1339 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 8), align 16, !tbaa !6
  %1340 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %1341 = load float, float addrspace(3)* %1340, align 4, !tbaa !6
  %1342 = fmul contract float %1339, %1341
  %1343 = fsub contract float %1338, %1342
  store float %1343, float addrspace(3)* %1297, align 4, !tbaa !6
  %1344 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 9), align 4, !tbaa !6
  %1345 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %1346 = load float, float addrspace(3)* %1345, align 4, !tbaa !6
  %1347 = fmul contract float %1344, %1346
  %1348 = fsub contract float %1343, %1347
  store float %1348, float addrspace(3)* %1297, align 4, !tbaa !6
  %1349 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 10), align 8, !tbaa !6
  %1350 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %1351 = load float, float addrspace(3)* %1350, align 4, !tbaa !6
  %1352 = fmul contract float %1349, %1351
  %1353 = fsub contract float %1348, %1352
  store float %1353, float addrspace(3)* %1297, align 4, !tbaa !6
  %1354 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 11), align 4, !tbaa !6
  %1355 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %1356 = load float, float addrspace(3)* %1355, align 4, !tbaa !6
  %1357 = fmul contract float %1354, %1356
  %1358 = fsub contract float %1353, %1357
  store float %1358, float addrspace(3)* %1297, align 4, !tbaa !6
  %1359 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 12), align 16, !tbaa !6
  %1360 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %1361 = load float, float addrspace(3)* %1360, align 4, !tbaa !6
  %1362 = fmul contract float %1359, %1361
  %1363 = fsub contract float %1358, %1362
  store float %1363, float addrspace(3)* %1297, align 4, !tbaa !6
  %1364 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 13), align 4, !tbaa !6
  %1365 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %1366 = load float, float addrspace(3)* %1365, align 4, !tbaa !6
  %1367 = fmul contract float %1364, %1366
  %1368 = fsub contract float %1363, %1367
  store float %1368, float addrspace(3)* %1297, align 4, !tbaa !6
  %1369 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 14), align 8, !tbaa !6
  %1370 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %1371 = load float, float addrspace(3)* %1370, align 4, !tbaa !6
  %1372 = fmul contract float %1369, %1371
  %1373 = fsub contract float %1368, %1372
  store float %1373, float addrspace(3)* %1297, align 4, !tbaa !6
  %1374 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 15), align 4, !tbaa !6
  %1375 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %1376 = load float, float addrspace(3)* %1375, align 4, !tbaa !6
  %1377 = fmul contract float %1374, %1376
  %1378 = fsub contract float %1373, %1377
  store float %1378, float addrspace(3)* %1297, align 4, !tbaa !6
  %1379 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 16), align 16, !tbaa !6
  %1380 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %1381 = load float, float addrspace(3)* %1380, align 4, !tbaa !6
  %1382 = fmul contract float %1379, %1381
  %1383 = fsub contract float %1378, %1382
  store float %1383, float addrspace(3)* %1297, align 4, !tbaa !6
  %1384 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  %1385 = load float, float addrspace(3)* %1384, align 4, !tbaa !6
  %1386 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 0), align 16, !tbaa !6
  %1387 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %1388 = load float, float addrspace(3)* %1387, align 4, !tbaa !6
  %1389 = fmul contract float %1386, %1388
  %1390 = fsub contract float %1385, %1389
  store float %1390, float addrspace(3)* %1384, align 4, !tbaa !6
  %1391 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 1), align 4, !tbaa !6
  %1392 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %1393 = load float, float addrspace(3)* %1392, align 4, !tbaa !6
  %1394 = fmul contract float %1391, %1393
  %1395 = fsub contract float %1390, %1394
  store float %1395, float addrspace(3)* %1384, align 4, !tbaa !6
  %1396 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 2), align 8, !tbaa !6
  %1397 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %1398 = load float, float addrspace(3)* %1397, align 4, !tbaa !6
  %1399 = fmul contract float %1396, %1398
  %1400 = fsub contract float %1395, %1399
  store float %1400, float addrspace(3)* %1384, align 4, !tbaa !6
  %1401 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 3), align 4, !tbaa !6
  %1402 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %1403 = load float, float addrspace(3)* %1402, align 4, !tbaa !6
  %1404 = fmul contract float %1401, %1403
  %1405 = fsub contract float %1400, %1404
  store float %1405, float addrspace(3)* %1384, align 4, !tbaa !6
  %1406 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 4), align 16, !tbaa !6
  %1407 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %1408 = load float, float addrspace(3)* %1407, align 4, !tbaa !6
  %1409 = fmul contract float %1406, %1408
  %1410 = fsub contract float %1405, %1409
  store float %1410, float addrspace(3)* %1384, align 4, !tbaa !6
  %1411 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 5), align 4, !tbaa !6
  %1412 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %1413 = load float, float addrspace(3)* %1412, align 4, !tbaa !6
  %1414 = fmul contract float %1411, %1413
  %1415 = fsub contract float %1410, %1414
  store float %1415, float addrspace(3)* %1384, align 4, !tbaa !6
  %1416 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 6), align 8, !tbaa !6
  %1417 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %1418 = load float, float addrspace(3)* %1417, align 4, !tbaa !6
  %1419 = fmul contract float %1416, %1418
  %1420 = fsub contract float %1415, %1419
  store float %1420, float addrspace(3)* %1384, align 4, !tbaa !6
  %1421 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 7), align 4, !tbaa !6
  %1422 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %1423 = load float, float addrspace(3)* %1422, align 4, !tbaa !6
  %1424 = fmul contract float %1421, %1423
  %1425 = fsub contract float %1420, %1424
  store float %1425, float addrspace(3)* %1384, align 4, !tbaa !6
  %1426 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 8), align 16, !tbaa !6
  %1427 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %1428 = load float, float addrspace(3)* %1427, align 4, !tbaa !6
  %1429 = fmul contract float %1426, %1428
  %1430 = fsub contract float %1425, %1429
  store float %1430, float addrspace(3)* %1384, align 4, !tbaa !6
  %1431 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 9), align 4, !tbaa !6
  %1432 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %1433 = load float, float addrspace(3)* %1432, align 4, !tbaa !6
  %1434 = fmul contract float %1431, %1433
  %1435 = fsub contract float %1430, %1434
  store float %1435, float addrspace(3)* %1384, align 4, !tbaa !6
  %1436 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 10), align 8, !tbaa !6
  %1437 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %1438 = load float, float addrspace(3)* %1437, align 4, !tbaa !6
  %1439 = fmul contract float %1436, %1438
  %1440 = fsub contract float %1435, %1439
  store float %1440, float addrspace(3)* %1384, align 4, !tbaa !6
  %1441 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 11), align 4, !tbaa !6
  %1442 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %1443 = load float, float addrspace(3)* %1442, align 4, !tbaa !6
  %1444 = fmul contract float %1441, %1443
  %1445 = fsub contract float %1440, %1444
  store float %1445, float addrspace(3)* %1384, align 4, !tbaa !6
  %1446 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 12), align 16, !tbaa !6
  %1447 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %1448 = load float, float addrspace(3)* %1447, align 4, !tbaa !6
  %1449 = fmul contract float %1446, %1448
  %1450 = fsub contract float %1445, %1449
  store float %1450, float addrspace(3)* %1384, align 4, !tbaa !6
  %1451 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 13), align 4, !tbaa !6
  %1452 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %1453 = load float, float addrspace(3)* %1452, align 4, !tbaa !6
  %1454 = fmul contract float %1451, %1453
  %1455 = fsub contract float %1450, %1454
  store float %1455, float addrspace(3)* %1384, align 4, !tbaa !6
  %1456 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 14), align 8, !tbaa !6
  %1457 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %1458 = load float, float addrspace(3)* %1457, align 4, !tbaa !6
  %1459 = fmul contract float %1456, %1458
  %1460 = fsub contract float %1455, %1459
  store float %1460, float addrspace(3)* %1384, align 4, !tbaa !6
  %1461 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 15), align 4, !tbaa !6
  %1462 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %1463 = load float, float addrspace(3)* %1462, align 4, !tbaa !6
  %1464 = fmul contract float %1461, %1463
  %1465 = fsub contract float %1460, %1464
  store float %1465, float addrspace(3)* %1384, align 4, !tbaa !6
  %1466 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 16), align 16, !tbaa !6
  %1467 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %1468 = load float, float addrspace(3)* %1467, align 4, !tbaa !6
  %1469 = fmul contract float %1466, %1468
  %1470 = fsub contract float %1465, %1469
  store float %1470, float addrspace(3)* %1384, align 4, !tbaa !6
  %1471 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 17), align 4, !tbaa !6
  %1472 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %1473 = load float, float addrspace(3)* %1472, align 4, !tbaa !6
  %1474 = fmul contract float %1471, %1473
  %1475 = fsub contract float %1470, %1474
  store float %1475, float addrspace(3)* %1384, align 4, !tbaa !6
  %1476 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 19, i32 %4
  %1477 = load float, float addrspace(3)* %1476, align 4, !tbaa !6
  %1478 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 0), align 16, !tbaa !6
  %1479 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %1480 = load float, float addrspace(3)* %1479, align 4, !tbaa !6
  %1481 = fmul contract float %1478, %1480
  %1482 = fsub contract float %1477, %1481
  store float %1482, float addrspace(3)* %1476, align 4, !tbaa !6
  %1483 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 1), align 4, !tbaa !6
  %1484 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %1485 = load float, float addrspace(3)* %1484, align 4, !tbaa !6
  %1486 = fmul contract float %1483, %1485
  %1487 = fsub contract float %1482, %1486
  store float %1487, float addrspace(3)* %1476, align 4, !tbaa !6
  %1488 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 2), align 8, !tbaa !6
  %1489 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %1490 = load float, float addrspace(3)* %1489, align 4, !tbaa !6
  %1491 = fmul contract float %1488, %1490
  %1492 = fsub contract float %1487, %1491
  store float %1492, float addrspace(3)* %1476, align 4, !tbaa !6
  %1493 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 3), align 4, !tbaa !6
  %1494 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %1495 = load float, float addrspace(3)* %1494, align 4, !tbaa !6
  %1496 = fmul contract float %1493, %1495
  %1497 = fsub contract float %1492, %1496
  store float %1497, float addrspace(3)* %1476, align 4, !tbaa !6
  %1498 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 4), align 16, !tbaa !6
  %1499 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %1500 = load float, float addrspace(3)* %1499, align 4, !tbaa !6
  %1501 = fmul contract float %1498, %1500
  %1502 = fsub contract float %1497, %1501
  store float %1502, float addrspace(3)* %1476, align 4, !tbaa !6
  %1503 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 5), align 4, !tbaa !6
  %1504 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %1505 = load float, float addrspace(3)* %1504, align 4, !tbaa !6
  %1506 = fmul contract float %1503, %1505
  %1507 = fsub contract float %1502, %1506
  store float %1507, float addrspace(3)* %1476, align 4, !tbaa !6
  %1508 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 6), align 8, !tbaa !6
  %1509 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %1510 = load float, float addrspace(3)* %1509, align 4, !tbaa !6
  %1511 = fmul contract float %1508, %1510
  %1512 = fsub contract float %1507, %1511
  store float %1512, float addrspace(3)* %1476, align 4, !tbaa !6
  %1513 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 7), align 4, !tbaa !6
  %1514 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %1515 = load float, float addrspace(3)* %1514, align 4, !tbaa !6
  %1516 = fmul contract float %1513, %1515
  %1517 = fsub contract float %1512, %1516
  store float %1517, float addrspace(3)* %1476, align 4, !tbaa !6
  %1518 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 8), align 16, !tbaa !6
  %1519 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %1520 = load float, float addrspace(3)* %1519, align 4, !tbaa !6
  %1521 = fmul contract float %1518, %1520
  %1522 = fsub contract float %1517, %1521
  store float %1522, float addrspace(3)* %1476, align 4, !tbaa !6
  %1523 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 9), align 4, !tbaa !6
  %1524 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %1525 = load float, float addrspace(3)* %1524, align 4, !tbaa !6
  %1526 = fmul contract float %1523, %1525
  %1527 = fsub contract float %1522, %1526
  store float %1527, float addrspace(3)* %1476, align 4, !tbaa !6
  %1528 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 10), align 8, !tbaa !6
  %1529 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %1530 = load float, float addrspace(3)* %1529, align 4, !tbaa !6
  %1531 = fmul contract float %1528, %1530
  %1532 = fsub contract float %1527, %1531
  store float %1532, float addrspace(3)* %1476, align 4, !tbaa !6
  %1533 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 11), align 4, !tbaa !6
  %1534 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %1535 = load float, float addrspace(3)* %1534, align 4, !tbaa !6
  %1536 = fmul contract float %1533, %1535
  %1537 = fsub contract float %1532, %1536
  store float %1537, float addrspace(3)* %1476, align 4, !tbaa !6
  %1538 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 12), align 16, !tbaa !6
  %1539 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %1540 = load float, float addrspace(3)* %1539, align 4, !tbaa !6
  %1541 = fmul contract float %1538, %1540
  %1542 = fsub contract float %1537, %1541
  store float %1542, float addrspace(3)* %1476, align 4, !tbaa !6
  %1543 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 13), align 4, !tbaa !6
  %1544 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %1545 = load float, float addrspace(3)* %1544, align 4, !tbaa !6
  %1546 = fmul contract float %1543, %1545
  %1547 = fsub contract float %1542, %1546
  store float %1547, float addrspace(3)* %1476, align 4, !tbaa !6
  %1548 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 14), align 8, !tbaa !6
  %1549 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %1550 = load float, float addrspace(3)* %1549, align 4, !tbaa !6
  %1551 = fmul contract float %1548, %1550
  %1552 = fsub contract float %1547, %1551
  store float %1552, float addrspace(3)* %1476, align 4, !tbaa !6
  %1553 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 15), align 4, !tbaa !6
  %1554 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %1555 = load float, float addrspace(3)* %1554, align 4, !tbaa !6
  %1556 = fmul contract float %1553, %1555
  %1557 = fsub contract float %1552, %1556
  store float %1557, float addrspace(3)* %1476, align 4, !tbaa !6
  %1558 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 16), align 16, !tbaa !6
  %1559 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %1560 = load float, float addrspace(3)* %1559, align 4, !tbaa !6
  %1561 = fmul contract float %1558, %1560
  %1562 = fsub contract float %1557, %1561
  store float %1562, float addrspace(3)* %1476, align 4, !tbaa !6
  %1563 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 17), align 4, !tbaa !6
  %1564 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %1565 = load float, float addrspace(3)* %1564, align 4, !tbaa !6
  %1566 = fmul contract float %1563, %1565
  %1567 = fsub contract float %1562, %1566
  store float %1567, float addrspace(3)* %1476, align 4, !tbaa !6
  %1568 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 18), align 8, !tbaa !6
  %1569 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  %1570 = load float, float addrspace(3)* %1569, align 4, !tbaa !6
  %1571 = fmul contract float %1568, %1570
  %1572 = fsub contract float %1567, %1571
  store float %1572, float addrspace(3)* %1476, align 4, !tbaa !6
  %1573 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 20, i32 %4
  %1574 = load float, float addrspace(3)* %1573, align 4, !tbaa !6
  %1575 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 0), align 16, !tbaa !6
  %1576 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %1577 = load float, float addrspace(3)* %1576, align 4, !tbaa !6
  %1578 = fmul contract float %1575, %1577
  %1579 = fsub contract float %1574, %1578
  store float %1579, float addrspace(3)* %1573, align 4, !tbaa !6
  %1580 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 1), align 4, !tbaa !6
  %1581 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %1582 = load float, float addrspace(3)* %1581, align 4, !tbaa !6
  %1583 = fmul contract float %1580, %1582
  %1584 = fsub contract float %1579, %1583
  store float %1584, float addrspace(3)* %1573, align 4, !tbaa !6
  %1585 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 2), align 8, !tbaa !6
  %1586 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %1587 = load float, float addrspace(3)* %1586, align 4, !tbaa !6
  %1588 = fmul contract float %1585, %1587
  %1589 = fsub contract float %1584, %1588
  store float %1589, float addrspace(3)* %1573, align 4, !tbaa !6
  %1590 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 3), align 4, !tbaa !6
  %1591 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %1592 = load float, float addrspace(3)* %1591, align 4, !tbaa !6
  %1593 = fmul contract float %1590, %1592
  %1594 = fsub contract float %1589, %1593
  store float %1594, float addrspace(3)* %1573, align 4, !tbaa !6
  %1595 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 4), align 16, !tbaa !6
  %1596 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %1597 = load float, float addrspace(3)* %1596, align 4, !tbaa !6
  %1598 = fmul contract float %1595, %1597
  %1599 = fsub contract float %1594, %1598
  store float %1599, float addrspace(3)* %1573, align 4, !tbaa !6
  %1600 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 5), align 4, !tbaa !6
  %1601 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %1602 = load float, float addrspace(3)* %1601, align 4, !tbaa !6
  %1603 = fmul contract float %1600, %1602
  %1604 = fsub contract float %1599, %1603
  store float %1604, float addrspace(3)* %1573, align 4, !tbaa !6
  %1605 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 6), align 8, !tbaa !6
  %1606 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %1607 = load float, float addrspace(3)* %1606, align 4, !tbaa !6
  %1608 = fmul contract float %1605, %1607
  %1609 = fsub contract float %1604, %1608
  store float %1609, float addrspace(3)* %1573, align 4, !tbaa !6
  %1610 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 7), align 4, !tbaa !6
  %1611 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %1612 = load float, float addrspace(3)* %1611, align 4, !tbaa !6
  %1613 = fmul contract float %1610, %1612
  %1614 = fsub contract float %1609, %1613
  store float %1614, float addrspace(3)* %1573, align 4, !tbaa !6
  %1615 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 8), align 16, !tbaa !6
  %1616 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %1617 = load float, float addrspace(3)* %1616, align 4, !tbaa !6
  %1618 = fmul contract float %1615, %1617
  %1619 = fsub contract float %1614, %1618
  store float %1619, float addrspace(3)* %1573, align 4, !tbaa !6
  %1620 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 9), align 4, !tbaa !6
  %1621 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %1622 = load float, float addrspace(3)* %1621, align 4, !tbaa !6
  %1623 = fmul contract float %1620, %1622
  %1624 = fsub contract float %1619, %1623
  store float %1624, float addrspace(3)* %1573, align 4, !tbaa !6
  %1625 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 10), align 8, !tbaa !6
  %1626 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %1627 = load float, float addrspace(3)* %1626, align 4, !tbaa !6
  %1628 = fmul contract float %1625, %1627
  %1629 = fsub contract float %1624, %1628
  store float %1629, float addrspace(3)* %1573, align 4, !tbaa !6
  %1630 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 11), align 4, !tbaa !6
  %1631 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %1632 = load float, float addrspace(3)* %1631, align 4, !tbaa !6
  %1633 = fmul contract float %1630, %1632
  %1634 = fsub contract float %1629, %1633
  store float %1634, float addrspace(3)* %1573, align 4, !tbaa !6
  %1635 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 12), align 16, !tbaa !6
  %1636 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %1637 = load float, float addrspace(3)* %1636, align 4, !tbaa !6
  %1638 = fmul contract float %1635, %1637
  %1639 = fsub contract float %1634, %1638
  store float %1639, float addrspace(3)* %1573, align 4, !tbaa !6
  %1640 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 13), align 4, !tbaa !6
  %1641 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %1642 = load float, float addrspace(3)* %1641, align 4, !tbaa !6
  %1643 = fmul contract float %1640, %1642
  %1644 = fsub contract float %1639, %1643
  store float %1644, float addrspace(3)* %1573, align 4, !tbaa !6
  %1645 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 14), align 8, !tbaa !6
  %1646 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %1647 = load float, float addrspace(3)* %1646, align 4, !tbaa !6
  %1648 = fmul contract float %1645, %1647
  %1649 = fsub contract float %1644, %1648
  store float %1649, float addrspace(3)* %1573, align 4, !tbaa !6
  %1650 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 15), align 4, !tbaa !6
  %1651 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %1652 = load float, float addrspace(3)* %1651, align 4, !tbaa !6
  %1653 = fmul contract float %1650, %1652
  %1654 = fsub contract float %1649, %1653
  store float %1654, float addrspace(3)* %1573, align 4, !tbaa !6
  %1655 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 16), align 16, !tbaa !6
  %1656 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %1657 = load float, float addrspace(3)* %1656, align 4, !tbaa !6
  %1658 = fmul contract float %1655, %1657
  %1659 = fsub contract float %1654, %1658
  store float %1659, float addrspace(3)* %1573, align 4, !tbaa !6
  %1660 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 17), align 4, !tbaa !6
  %1661 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %1662 = load float, float addrspace(3)* %1661, align 4, !tbaa !6
  %1663 = fmul contract float %1660, %1662
  %1664 = fsub contract float %1659, %1663
  store float %1664, float addrspace(3)* %1573, align 4, !tbaa !6
  %1665 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 18), align 8, !tbaa !6
  %1666 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  %1667 = load float, float addrspace(3)* %1666, align 4, !tbaa !6
  %1668 = fmul contract float %1665, %1667
  %1669 = fsub contract float %1664, %1668
  store float %1669, float addrspace(3)* %1573, align 4, !tbaa !6
  %1670 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 19), align 4, !tbaa !6
  %1671 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 19, i32 %4
  %1672 = load float, float addrspace(3)* %1671, align 4, !tbaa !6
  %1673 = fmul contract float %1670, %1672
  %1674 = fsub contract float %1669, %1673
  store float %1674, float addrspace(3)* %1573, align 4, !tbaa !6
  %1675 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 21, i32 %4
  %1676 = load float, float addrspace(3)* %1675, align 4, !tbaa !6
  %1677 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 0), align 16, !tbaa !6
  %1678 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %1679 = load float, float addrspace(3)* %1678, align 4, !tbaa !6
  %1680 = fmul contract float %1677, %1679
  %1681 = fsub contract float %1676, %1680
  store float %1681, float addrspace(3)* %1675, align 4, !tbaa !6
  %1682 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 1), align 4, !tbaa !6
  %1683 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %1684 = load float, float addrspace(3)* %1683, align 4, !tbaa !6
  %1685 = fmul contract float %1682, %1684
  %1686 = fsub contract float %1681, %1685
  store float %1686, float addrspace(3)* %1675, align 4, !tbaa !6
  %1687 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 2), align 8, !tbaa !6
  %1688 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %1689 = load float, float addrspace(3)* %1688, align 4, !tbaa !6
  %1690 = fmul contract float %1687, %1689
  %1691 = fsub contract float %1686, %1690
  store float %1691, float addrspace(3)* %1675, align 4, !tbaa !6
  %1692 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 3), align 4, !tbaa !6
  %1693 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %1694 = load float, float addrspace(3)* %1693, align 4, !tbaa !6
  %1695 = fmul contract float %1692, %1694
  %1696 = fsub contract float %1691, %1695
  store float %1696, float addrspace(3)* %1675, align 4, !tbaa !6
  %1697 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 4), align 16, !tbaa !6
  %1698 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %1699 = load float, float addrspace(3)* %1698, align 4, !tbaa !6
  %1700 = fmul contract float %1697, %1699
  %1701 = fsub contract float %1696, %1700
  store float %1701, float addrspace(3)* %1675, align 4, !tbaa !6
  %1702 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 5), align 4, !tbaa !6
  %1703 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %1704 = load float, float addrspace(3)* %1703, align 4, !tbaa !6
  %1705 = fmul contract float %1702, %1704
  %1706 = fsub contract float %1701, %1705
  store float %1706, float addrspace(3)* %1675, align 4, !tbaa !6
  %1707 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 6), align 8, !tbaa !6
  %1708 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %1709 = load float, float addrspace(3)* %1708, align 4, !tbaa !6
  %1710 = fmul contract float %1707, %1709
  %1711 = fsub contract float %1706, %1710
  store float %1711, float addrspace(3)* %1675, align 4, !tbaa !6
  %1712 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 7), align 4, !tbaa !6
  %1713 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %1714 = load float, float addrspace(3)* %1713, align 4, !tbaa !6
  %1715 = fmul contract float %1712, %1714
  %1716 = fsub contract float %1711, %1715
  store float %1716, float addrspace(3)* %1675, align 4, !tbaa !6
  %1717 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 8), align 16, !tbaa !6
  %1718 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %1719 = load float, float addrspace(3)* %1718, align 4, !tbaa !6
  %1720 = fmul contract float %1717, %1719
  %1721 = fsub contract float %1716, %1720
  store float %1721, float addrspace(3)* %1675, align 4, !tbaa !6
  %1722 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 9), align 4, !tbaa !6
  %1723 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %1724 = load float, float addrspace(3)* %1723, align 4, !tbaa !6
  %1725 = fmul contract float %1722, %1724
  %1726 = fsub contract float %1721, %1725
  store float %1726, float addrspace(3)* %1675, align 4, !tbaa !6
  %1727 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 10), align 8, !tbaa !6
  %1728 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %1729 = load float, float addrspace(3)* %1728, align 4, !tbaa !6
  %1730 = fmul contract float %1727, %1729
  %1731 = fsub contract float %1726, %1730
  store float %1731, float addrspace(3)* %1675, align 4, !tbaa !6
  %1732 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 11), align 4, !tbaa !6
  %1733 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %1734 = load float, float addrspace(3)* %1733, align 4, !tbaa !6
  %1735 = fmul contract float %1732, %1734
  %1736 = fsub contract float %1731, %1735
  store float %1736, float addrspace(3)* %1675, align 4, !tbaa !6
  %1737 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 12), align 16, !tbaa !6
  %1738 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %1739 = load float, float addrspace(3)* %1738, align 4, !tbaa !6
  %1740 = fmul contract float %1737, %1739
  %1741 = fsub contract float %1736, %1740
  store float %1741, float addrspace(3)* %1675, align 4, !tbaa !6
  %1742 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 13), align 4, !tbaa !6
  %1743 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %1744 = load float, float addrspace(3)* %1743, align 4, !tbaa !6
  %1745 = fmul contract float %1742, %1744
  %1746 = fsub contract float %1741, %1745
  store float %1746, float addrspace(3)* %1675, align 4, !tbaa !6
  %1747 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 14), align 8, !tbaa !6
  %1748 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %1749 = load float, float addrspace(3)* %1748, align 4, !tbaa !6
  %1750 = fmul contract float %1747, %1749
  %1751 = fsub contract float %1746, %1750
  store float %1751, float addrspace(3)* %1675, align 4, !tbaa !6
  %1752 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 15), align 4, !tbaa !6
  %1753 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %1754 = load float, float addrspace(3)* %1753, align 4, !tbaa !6
  %1755 = fmul contract float %1752, %1754
  %1756 = fsub contract float %1751, %1755
  store float %1756, float addrspace(3)* %1675, align 4, !tbaa !6
  %1757 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 16), align 16, !tbaa !6
  %1758 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %1759 = load float, float addrspace(3)* %1758, align 4, !tbaa !6
  %1760 = fmul contract float %1757, %1759
  %1761 = fsub contract float %1756, %1760
  store float %1761, float addrspace(3)* %1675, align 4, !tbaa !6
  %1762 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 17), align 4, !tbaa !6
  %1763 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %1764 = load float, float addrspace(3)* %1763, align 4, !tbaa !6
  %1765 = fmul contract float %1762, %1764
  %1766 = fsub contract float %1761, %1765
  store float %1766, float addrspace(3)* %1675, align 4, !tbaa !6
  %1767 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 18), align 8, !tbaa !6
  %1768 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  %1769 = load float, float addrspace(3)* %1768, align 4, !tbaa !6
  %1770 = fmul contract float %1767, %1769
  %1771 = fsub contract float %1766, %1770
  store float %1771, float addrspace(3)* %1675, align 4, !tbaa !6
  %1772 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 19), align 4, !tbaa !6
  %1773 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 19, i32 %4
  %1774 = load float, float addrspace(3)* %1773, align 4, !tbaa !6
  %1775 = fmul contract float %1772, %1774
  %1776 = fsub contract float %1771, %1775
  store float %1776, float addrspace(3)* %1675, align 4, !tbaa !6
  %1777 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 20), align 16, !tbaa !6
  %1778 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 20, i32 %4
  %1779 = load float, float addrspace(3)* %1778, align 4, !tbaa !6
  %1780 = fmul contract float %1777, %1779
  %1781 = fsub contract float %1776, %1780
  store float %1781, float addrspace(3)* %1675, align 4, !tbaa !6
  %1782 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 22, i32 %4
  %1783 = load float, float addrspace(3)* %1782, align 4, !tbaa !6
  %1784 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 0), align 16, !tbaa !6
  %1785 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %1786 = load float, float addrspace(3)* %1785, align 4, !tbaa !6
  %1787 = fmul contract float %1784, %1786
  %1788 = fsub contract float %1783, %1787
  store float %1788, float addrspace(3)* %1782, align 4, !tbaa !6
  %1789 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 1), align 4, !tbaa !6
  %1790 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %1791 = load float, float addrspace(3)* %1790, align 4, !tbaa !6
  %1792 = fmul contract float %1789, %1791
  %1793 = fsub contract float %1788, %1792
  store float %1793, float addrspace(3)* %1782, align 4, !tbaa !6
  %1794 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 2), align 8, !tbaa !6
  %1795 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %1796 = load float, float addrspace(3)* %1795, align 4, !tbaa !6
  %1797 = fmul contract float %1794, %1796
  %1798 = fsub contract float %1793, %1797
  store float %1798, float addrspace(3)* %1782, align 4, !tbaa !6
  %1799 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 3), align 4, !tbaa !6
  %1800 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %1801 = load float, float addrspace(3)* %1800, align 4, !tbaa !6
  %1802 = fmul contract float %1799, %1801
  %1803 = fsub contract float %1798, %1802
  store float %1803, float addrspace(3)* %1782, align 4, !tbaa !6
  %1804 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 4), align 16, !tbaa !6
  %1805 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %1806 = load float, float addrspace(3)* %1805, align 4, !tbaa !6
  %1807 = fmul contract float %1804, %1806
  %1808 = fsub contract float %1803, %1807
  store float %1808, float addrspace(3)* %1782, align 4, !tbaa !6
  %1809 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 5), align 4, !tbaa !6
  %1810 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %1811 = load float, float addrspace(3)* %1810, align 4, !tbaa !6
  %1812 = fmul contract float %1809, %1811
  %1813 = fsub contract float %1808, %1812
  store float %1813, float addrspace(3)* %1782, align 4, !tbaa !6
  %1814 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 6), align 8, !tbaa !6
  %1815 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %1816 = load float, float addrspace(3)* %1815, align 4, !tbaa !6
  %1817 = fmul contract float %1814, %1816
  %1818 = fsub contract float %1813, %1817
  store float %1818, float addrspace(3)* %1782, align 4, !tbaa !6
  %1819 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 7), align 4, !tbaa !6
  %1820 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %1821 = load float, float addrspace(3)* %1820, align 4, !tbaa !6
  %1822 = fmul contract float %1819, %1821
  %1823 = fsub contract float %1818, %1822
  store float %1823, float addrspace(3)* %1782, align 4, !tbaa !6
  %1824 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 8), align 16, !tbaa !6
  %1825 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %1826 = load float, float addrspace(3)* %1825, align 4, !tbaa !6
  %1827 = fmul contract float %1824, %1826
  %1828 = fsub contract float %1823, %1827
  store float %1828, float addrspace(3)* %1782, align 4, !tbaa !6
  %1829 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 9), align 4, !tbaa !6
  %1830 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %1831 = load float, float addrspace(3)* %1830, align 4, !tbaa !6
  %1832 = fmul contract float %1829, %1831
  %1833 = fsub contract float %1828, %1832
  store float %1833, float addrspace(3)* %1782, align 4, !tbaa !6
  %1834 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 10), align 8, !tbaa !6
  %1835 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %1836 = load float, float addrspace(3)* %1835, align 4, !tbaa !6
  %1837 = fmul contract float %1834, %1836
  %1838 = fsub contract float %1833, %1837
  store float %1838, float addrspace(3)* %1782, align 4, !tbaa !6
  %1839 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 11), align 4, !tbaa !6
  %1840 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %1841 = load float, float addrspace(3)* %1840, align 4, !tbaa !6
  %1842 = fmul contract float %1839, %1841
  %1843 = fsub contract float %1838, %1842
  store float %1843, float addrspace(3)* %1782, align 4, !tbaa !6
  %1844 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 12), align 16, !tbaa !6
  %1845 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %1846 = load float, float addrspace(3)* %1845, align 4, !tbaa !6
  %1847 = fmul contract float %1844, %1846
  %1848 = fsub contract float %1843, %1847
  store float %1848, float addrspace(3)* %1782, align 4, !tbaa !6
  %1849 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 13), align 4, !tbaa !6
  %1850 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %1851 = load float, float addrspace(3)* %1850, align 4, !tbaa !6
  %1852 = fmul contract float %1849, %1851
  %1853 = fsub contract float %1848, %1852
  store float %1853, float addrspace(3)* %1782, align 4, !tbaa !6
  %1854 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 14), align 8, !tbaa !6
  %1855 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %1856 = load float, float addrspace(3)* %1855, align 4, !tbaa !6
  %1857 = fmul contract float %1854, %1856
  %1858 = fsub contract float %1853, %1857
  store float %1858, float addrspace(3)* %1782, align 4, !tbaa !6
  %1859 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 15), align 4, !tbaa !6
  %1860 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %1861 = load float, float addrspace(3)* %1860, align 4, !tbaa !6
  %1862 = fmul contract float %1859, %1861
  %1863 = fsub contract float %1858, %1862
  store float %1863, float addrspace(3)* %1782, align 4, !tbaa !6
  %1864 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 16), align 16, !tbaa !6
  %1865 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %1866 = load float, float addrspace(3)* %1865, align 4, !tbaa !6
  %1867 = fmul contract float %1864, %1866
  %1868 = fsub contract float %1863, %1867
  store float %1868, float addrspace(3)* %1782, align 4, !tbaa !6
  %1869 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 17), align 4, !tbaa !6
  %1870 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %1871 = load float, float addrspace(3)* %1870, align 4, !tbaa !6
  %1872 = fmul contract float %1869, %1871
  %1873 = fsub contract float %1868, %1872
  store float %1873, float addrspace(3)* %1782, align 4, !tbaa !6
  %1874 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 18), align 8, !tbaa !6
  %1875 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  %1876 = load float, float addrspace(3)* %1875, align 4, !tbaa !6
  %1877 = fmul contract float %1874, %1876
  %1878 = fsub contract float %1873, %1877
  store float %1878, float addrspace(3)* %1782, align 4, !tbaa !6
  %1879 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 19), align 4, !tbaa !6
  %1880 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 19, i32 %4
  %1881 = load float, float addrspace(3)* %1880, align 4, !tbaa !6
  %1882 = fmul contract float %1879, %1881
  %1883 = fsub contract float %1878, %1882
  store float %1883, float addrspace(3)* %1782, align 4, !tbaa !6
  %1884 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 20), align 16, !tbaa !6
  %1885 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 20, i32 %4
  %1886 = load float, float addrspace(3)* %1885, align 4, !tbaa !6
  %1887 = fmul contract float %1884, %1886
  %1888 = fsub contract float %1883, %1887
  store float %1888, float addrspace(3)* %1782, align 4, !tbaa !6
  %1889 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 21), align 4, !tbaa !6
  %1890 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 21, i32 %4
  %1891 = load float, float addrspace(3)* %1890, align 4, !tbaa !6
  %1892 = fmul contract float %1889, %1891
  %1893 = fsub contract float %1888, %1892
  store float %1893, float addrspace(3)* %1782, align 4, !tbaa !6
  %1894 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 23, i32 %4
  %1895 = load float, float addrspace(3)* %1894, align 4, !tbaa !6
  %1896 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 0), align 16, !tbaa !6
  %1897 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %1898 = load float, float addrspace(3)* %1897, align 4, !tbaa !6
  %1899 = fmul contract float %1896, %1898
  %1900 = fsub contract float %1895, %1899
  store float %1900, float addrspace(3)* %1894, align 4, !tbaa !6
  %1901 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 1), align 4, !tbaa !6
  %1902 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %1903 = load float, float addrspace(3)* %1902, align 4, !tbaa !6
  %1904 = fmul contract float %1901, %1903
  %1905 = fsub contract float %1900, %1904
  store float %1905, float addrspace(3)* %1894, align 4, !tbaa !6
  %1906 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 2), align 8, !tbaa !6
  %1907 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %1908 = load float, float addrspace(3)* %1907, align 4, !tbaa !6
  %1909 = fmul contract float %1906, %1908
  %1910 = fsub contract float %1905, %1909
  store float %1910, float addrspace(3)* %1894, align 4, !tbaa !6
  %1911 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 3), align 4, !tbaa !6
  %1912 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %1913 = load float, float addrspace(3)* %1912, align 4, !tbaa !6
  %1914 = fmul contract float %1911, %1913
  %1915 = fsub contract float %1910, %1914
  store float %1915, float addrspace(3)* %1894, align 4, !tbaa !6
  %1916 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 4), align 16, !tbaa !6
  %1917 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %1918 = load float, float addrspace(3)* %1917, align 4, !tbaa !6
  %1919 = fmul contract float %1916, %1918
  %1920 = fsub contract float %1915, %1919
  store float %1920, float addrspace(3)* %1894, align 4, !tbaa !6
  %1921 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 5), align 4, !tbaa !6
  %1922 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %1923 = load float, float addrspace(3)* %1922, align 4, !tbaa !6
  %1924 = fmul contract float %1921, %1923
  %1925 = fsub contract float %1920, %1924
  store float %1925, float addrspace(3)* %1894, align 4, !tbaa !6
  %1926 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 6), align 8, !tbaa !6
  %1927 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %1928 = load float, float addrspace(3)* %1927, align 4, !tbaa !6
  %1929 = fmul contract float %1926, %1928
  %1930 = fsub contract float %1925, %1929
  store float %1930, float addrspace(3)* %1894, align 4, !tbaa !6
  %1931 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 7), align 4, !tbaa !6
  %1932 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %1933 = load float, float addrspace(3)* %1932, align 4, !tbaa !6
  %1934 = fmul contract float %1931, %1933
  %1935 = fsub contract float %1930, %1934
  store float %1935, float addrspace(3)* %1894, align 4, !tbaa !6
  %1936 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 8), align 16, !tbaa !6
  %1937 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %1938 = load float, float addrspace(3)* %1937, align 4, !tbaa !6
  %1939 = fmul contract float %1936, %1938
  %1940 = fsub contract float %1935, %1939
  store float %1940, float addrspace(3)* %1894, align 4, !tbaa !6
  %1941 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 9), align 4, !tbaa !6
  %1942 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %1943 = load float, float addrspace(3)* %1942, align 4, !tbaa !6
  %1944 = fmul contract float %1941, %1943
  %1945 = fsub contract float %1940, %1944
  store float %1945, float addrspace(3)* %1894, align 4, !tbaa !6
  %1946 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 10), align 8, !tbaa !6
  %1947 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %1948 = load float, float addrspace(3)* %1947, align 4, !tbaa !6
  %1949 = fmul contract float %1946, %1948
  %1950 = fsub contract float %1945, %1949
  store float %1950, float addrspace(3)* %1894, align 4, !tbaa !6
  %1951 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 11), align 4, !tbaa !6
  %1952 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %1953 = load float, float addrspace(3)* %1952, align 4, !tbaa !6
  %1954 = fmul contract float %1951, %1953
  %1955 = fsub contract float %1950, %1954
  store float %1955, float addrspace(3)* %1894, align 4, !tbaa !6
  %1956 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 12), align 16, !tbaa !6
  %1957 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %1958 = load float, float addrspace(3)* %1957, align 4, !tbaa !6
  %1959 = fmul contract float %1956, %1958
  %1960 = fsub contract float %1955, %1959
  store float %1960, float addrspace(3)* %1894, align 4, !tbaa !6
  %1961 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 13), align 4, !tbaa !6
  %1962 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %1963 = load float, float addrspace(3)* %1962, align 4, !tbaa !6
  %1964 = fmul contract float %1961, %1963
  %1965 = fsub contract float %1960, %1964
  store float %1965, float addrspace(3)* %1894, align 4, !tbaa !6
  %1966 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 14), align 8, !tbaa !6
  %1967 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %1968 = load float, float addrspace(3)* %1967, align 4, !tbaa !6
  %1969 = fmul contract float %1966, %1968
  %1970 = fsub contract float %1965, %1969
  store float %1970, float addrspace(3)* %1894, align 4, !tbaa !6
  %1971 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 15), align 4, !tbaa !6
  %1972 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %1973 = load float, float addrspace(3)* %1972, align 4, !tbaa !6
  %1974 = fmul contract float %1971, %1973
  %1975 = fsub contract float %1970, %1974
  store float %1975, float addrspace(3)* %1894, align 4, !tbaa !6
  %1976 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 16), align 16, !tbaa !6
  %1977 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %1978 = load float, float addrspace(3)* %1977, align 4, !tbaa !6
  %1979 = fmul contract float %1976, %1978
  %1980 = fsub contract float %1975, %1979
  store float %1980, float addrspace(3)* %1894, align 4, !tbaa !6
  %1981 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 17), align 4, !tbaa !6
  %1982 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %1983 = load float, float addrspace(3)* %1982, align 4, !tbaa !6
  %1984 = fmul contract float %1981, %1983
  %1985 = fsub contract float %1980, %1984
  store float %1985, float addrspace(3)* %1894, align 4, !tbaa !6
  %1986 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 18), align 8, !tbaa !6
  %1987 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  %1988 = load float, float addrspace(3)* %1987, align 4, !tbaa !6
  %1989 = fmul contract float %1986, %1988
  %1990 = fsub contract float %1985, %1989
  store float %1990, float addrspace(3)* %1894, align 4, !tbaa !6
  %1991 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 19), align 4, !tbaa !6
  %1992 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 19, i32 %4
  %1993 = load float, float addrspace(3)* %1992, align 4, !tbaa !6
  %1994 = fmul contract float %1991, %1993
  %1995 = fsub contract float %1990, %1994
  store float %1995, float addrspace(3)* %1894, align 4, !tbaa !6
  %1996 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 20), align 16, !tbaa !6
  %1997 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 20, i32 %4
  %1998 = load float, float addrspace(3)* %1997, align 4, !tbaa !6
  %1999 = fmul contract float %1996, %1998
  %2000 = fsub contract float %1995, %1999
  store float %2000, float addrspace(3)* %1894, align 4, !tbaa !6
  %2001 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 21), align 4, !tbaa !6
  %2002 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 21, i32 %4
  %2003 = load float, float addrspace(3)* %2002, align 4, !tbaa !6
  %2004 = fmul contract float %2001, %2003
  %2005 = fsub contract float %2000, %2004
  store float %2005, float addrspace(3)* %1894, align 4, !tbaa !6
  %2006 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 22), align 8, !tbaa !6
  %2007 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 22, i32 %4
  %2008 = load float, float addrspace(3)* %2007, align 4, !tbaa !6
  %2009 = fmul contract float %2006, %2008
  %2010 = fsub contract float %2005, %2009
  store float %2010, float addrspace(3)* %1894, align 4, !tbaa !6
  %2011 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 24, i32 %4
  %2012 = load float, float addrspace(3)* %2011, align 4, !tbaa !6
  %2013 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 0), align 16, !tbaa !6
  %2014 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %2015 = load float, float addrspace(3)* %2014, align 4, !tbaa !6
  %2016 = fmul contract float %2013, %2015
  %2017 = fsub contract float %2012, %2016
  store float %2017, float addrspace(3)* %2011, align 4, !tbaa !6
  %2018 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 1), align 4, !tbaa !6
  %2019 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %2020 = load float, float addrspace(3)* %2019, align 4, !tbaa !6
  %2021 = fmul contract float %2018, %2020
  %2022 = fsub contract float %2017, %2021
  store float %2022, float addrspace(3)* %2011, align 4, !tbaa !6
  %2023 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 2), align 8, !tbaa !6
  %2024 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %2025 = load float, float addrspace(3)* %2024, align 4, !tbaa !6
  %2026 = fmul contract float %2023, %2025
  %2027 = fsub contract float %2022, %2026
  store float %2027, float addrspace(3)* %2011, align 4, !tbaa !6
  %2028 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 3), align 4, !tbaa !6
  %2029 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %2030 = load float, float addrspace(3)* %2029, align 4, !tbaa !6
  %2031 = fmul contract float %2028, %2030
  %2032 = fsub contract float %2027, %2031
  store float %2032, float addrspace(3)* %2011, align 4, !tbaa !6
  %2033 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 4), align 16, !tbaa !6
  %2034 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %2035 = load float, float addrspace(3)* %2034, align 4, !tbaa !6
  %2036 = fmul contract float %2033, %2035
  %2037 = fsub contract float %2032, %2036
  store float %2037, float addrspace(3)* %2011, align 4, !tbaa !6
  %2038 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 5), align 4, !tbaa !6
  %2039 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %2040 = load float, float addrspace(3)* %2039, align 4, !tbaa !6
  %2041 = fmul contract float %2038, %2040
  %2042 = fsub contract float %2037, %2041
  store float %2042, float addrspace(3)* %2011, align 4, !tbaa !6
  %2043 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 6), align 8, !tbaa !6
  %2044 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %2045 = load float, float addrspace(3)* %2044, align 4, !tbaa !6
  %2046 = fmul contract float %2043, %2045
  %2047 = fsub contract float %2042, %2046
  store float %2047, float addrspace(3)* %2011, align 4, !tbaa !6
  %2048 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 7), align 4, !tbaa !6
  %2049 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %2050 = load float, float addrspace(3)* %2049, align 4, !tbaa !6
  %2051 = fmul contract float %2048, %2050
  %2052 = fsub contract float %2047, %2051
  store float %2052, float addrspace(3)* %2011, align 4, !tbaa !6
  %2053 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 8), align 16, !tbaa !6
  %2054 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %2055 = load float, float addrspace(3)* %2054, align 4, !tbaa !6
  %2056 = fmul contract float %2053, %2055
  %2057 = fsub contract float %2052, %2056
  store float %2057, float addrspace(3)* %2011, align 4, !tbaa !6
  %2058 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 9), align 4, !tbaa !6
  %2059 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %2060 = load float, float addrspace(3)* %2059, align 4, !tbaa !6
  %2061 = fmul contract float %2058, %2060
  %2062 = fsub contract float %2057, %2061
  store float %2062, float addrspace(3)* %2011, align 4, !tbaa !6
  %2063 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 10), align 8, !tbaa !6
  %2064 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %2065 = load float, float addrspace(3)* %2064, align 4, !tbaa !6
  %2066 = fmul contract float %2063, %2065
  %2067 = fsub contract float %2062, %2066
  store float %2067, float addrspace(3)* %2011, align 4, !tbaa !6
  %2068 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 11), align 4, !tbaa !6
  %2069 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %2070 = load float, float addrspace(3)* %2069, align 4, !tbaa !6
  %2071 = fmul contract float %2068, %2070
  %2072 = fsub contract float %2067, %2071
  store float %2072, float addrspace(3)* %2011, align 4, !tbaa !6
  %2073 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 12), align 16, !tbaa !6
  %2074 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %2075 = load float, float addrspace(3)* %2074, align 4, !tbaa !6
  %2076 = fmul contract float %2073, %2075
  %2077 = fsub contract float %2072, %2076
  store float %2077, float addrspace(3)* %2011, align 4, !tbaa !6
  %2078 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 13), align 4, !tbaa !6
  %2079 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %2080 = load float, float addrspace(3)* %2079, align 4, !tbaa !6
  %2081 = fmul contract float %2078, %2080
  %2082 = fsub contract float %2077, %2081
  store float %2082, float addrspace(3)* %2011, align 4, !tbaa !6
  %2083 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 14), align 8, !tbaa !6
  %2084 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %2085 = load float, float addrspace(3)* %2084, align 4, !tbaa !6
  %2086 = fmul contract float %2083, %2085
  %2087 = fsub contract float %2082, %2086
  store float %2087, float addrspace(3)* %2011, align 4, !tbaa !6
  %2088 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 15), align 4, !tbaa !6
  %2089 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %2090 = load float, float addrspace(3)* %2089, align 4, !tbaa !6
  %2091 = fmul contract float %2088, %2090
  %2092 = fsub contract float %2087, %2091
  store float %2092, float addrspace(3)* %2011, align 4, !tbaa !6
  %2093 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 16), align 16, !tbaa !6
  %2094 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %2095 = load float, float addrspace(3)* %2094, align 4, !tbaa !6
  %2096 = fmul contract float %2093, %2095
  %2097 = fsub contract float %2092, %2096
  store float %2097, float addrspace(3)* %2011, align 4, !tbaa !6
  %2098 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 17), align 4, !tbaa !6
  %2099 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %2100 = load float, float addrspace(3)* %2099, align 4, !tbaa !6
  %2101 = fmul contract float %2098, %2100
  %2102 = fsub contract float %2097, %2101
  store float %2102, float addrspace(3)* %2011, align 4, !tbaa !6
  %2103 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 18), align 8, !tbaa !6
  %2104 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  %2105 = load float, float addrspace(3)* %2104, align 4, !tbaa !6
  %2106 = fmul contract float %2103, %2105
  %2107 = fsub contract float %2102, %2106
  store float %2107, float addrspace(3)* %2011, align 4, !tbaa !6
  %2108 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 19), align 4, !tbaa !6
  %2109 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 19, i32 %4
  %2110 = load float, float addrspace(3)* %2109, align 4, !tbaa !6
  %2111 = fmul contract float %2108, %2110
  %2112 = fsub contract float %2107, %2111
  store float %2112, float addrspace(3)* %2011, align 4, !tbaa !6
  %2113 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 20), align 16, !tbaa !6
  %2114 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 20, i32 %4
  %2115 = load float, float addrspace(3)* %2114, align 4, !tbaa !6
  %2116 = fmul contract float %2113, %2115
  %2117 = fsub contract float %2112, %2116
  store float %2117, float addrspace(3)* %2011, align 4, !tbaa !6
  %2118 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 21), align 4, !tbaa !6
  %2119 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 21, i32 %4
  %2120 = load float, float addrspace(3)* %2119, align 4, !tbaa !6
  %2121 = fmul contract float %2118, %2120
  %2122 = fsub contract float %2117, %2121
  store float %2122, float addrspace(3)* %2011, align 4, !tbaa !6
  %2123 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 22), align 8, !tbaa !6
  %2124 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 22, i32 %4
  %2125 = load float, float addrspace(3)* %2124, align 4, !tbaa !6
  %2126 = fmul contract float %2123, %2125
  %2127 = fsub contract float %2122, %2126
  store float %2127, float addrspace(3)* %2011, align 4, !tbaa !6
  %2128 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 23), align 4, !tbaa !6
  %2129 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 23, i32 %4
  %2130 = load float, float addrspace(3)* %2129, align 4, !tbaa !6
  %2131 = fmul contract float %2128, %2130
  %2132 = fsub contract float %2127, %2131
  store float %2132, float addrspace(3)* %2011, align 4, !tbaa !6
  %2133 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 25, i32 %4
  %2134 = load float, float addrspace(3)* %2133, align 4, !tbaa !6
  %2135 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 0), align 16, !tbaa !6
  %2136 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %2137 = load float, float addrspace(3)* %2136, align 4, !tbaa !6
  %2138 = fmul contract float %2135, %2137
  %2139 = fsub contract float %2134, %2138
  store float %2139, float addrspace(3)* %2133, align 4, !tbaa !6
  %2140 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 1), align 4, !tbaa !6
  %2141 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %2142 = load float, float addrspace(3)* %2141, align 4, !tbaa !6
  %2143 = fmul contract float %2140, %2142
  %2144 = fsub contract float %2139, %2143
  store float %2144, float addrspace(3)* %2133, align 4, !tbaa !6
  %2145 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 2), align 8, !tbaa !6
  %2146 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %2147 = load float, float addrspace(3)* %2146, align 4, !tbaa !6
  %2148 = fmul contract float %2145, %2147
  %2149 = fsub contract float %2144, %2148
  store float %2149, float addrspace(3)* %2133, align 4, !tbaa !6
  %2150 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 3), align 4, !tbaa !6
  %2151 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %2152 = load float, float addrspace(3)* %2151, align 4, !tbaa !6
  %2153 = fmul contract float %2150, %2152
  %2154 = fsub contract float %2149, %2153
  store float %2154, float addrspace(3)* %2133, align 4, !tbaa !6
  %2155 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 4), align 16, !tbaa !6
  %2156 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %2157 = load float, float addrspace(3)* %2156, align 4, !tbaa !6
  %2158 = fmul contract float %2155, %2157
  %2159 = fsub contract float %2154, %2158
  store float %2159, float addrspace(3)* %2133, align 4, !tbaa !6
  %2160 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 5), align 4, !tbaa !6
  %2161 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %2162 = load float, float addrspace(3)* %2161, align 4, !tbaa !6
  %2163 = fmul contract float %2160, %2162
  %2164 = fsub contract float %2159, %2163
  store float %2164, float addrspace(3)* %2133, align 4, !tbaa !6
  %2165 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 6), align 8, !tbaa !6
  %2166 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %2167 = load float, float addrspace(3)* %2166, align 4, !tbaa !6
  %2168 = fmul contract float %2165, %2167
  %2169 = fsub contract float %2164, %2168
  store float %2169, float addrspace(3)* %2133, align 4, !tbaa !6
  %2170 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 7), align 4, !tbaa !6
  %2171 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %2172 = load float, float addrspace(3)* %2171, align 4, !tbaa !6
  %2173 = fmul contract float %2170, %2172
  %2174 = fsub contract float %2169, %2173
  store float %2174, float addrspace(3)* %2133, align 4, !tbaa !6
  %2175 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 8), align 16, !tbaa !6
  %2176 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %2177 = load float, float addrspace(3)* %2176, align 4, !tbaa !6
  %2178 = fmul contract float %2175, %2177
  %2179 = fsub contract float %2174, %2178
  store float %2179, float addrspace(3)* %2133, align 4, !tbaa !6
  %2180 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 9), align 4, !tbaa !6
  %2181 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %2182 = load float, float addrspace(3)* %2181, align 4, !tbaa !6
  %2183 = fmul contract float %2180, %2182
  %2184 = fsub contract float %2179, %2183
  store float %2184, float addrspace(3)* %2133, align 4, !tbaa !6
  %2185 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 10), align 8, !tbaa !6
  %2186 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %2187 = load float, float addrspace(3)* %2186, align 4, !tbaa !6
  %2188 = fmul contract float %2185, %2187
  %2189 = fsub contract float %2184, %2188
  store float %2189, float addrspace(3)* %2133, align 4, !tbaa !6
  %2190 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 11), align 4, !tbaa !6
  %2191 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %2192 = load float, float addrspace(3)* %2191, align 4, !tbaa !6
  %2193 = fmul contract float %2190, %2192
  %2194 = fsub contract float %2189, %2193
  store float %2194, float addrspace(3)* %2133, align 4, !tbaa !6
  %2195 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 12), align 16, !tbaa !6
  %2196 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %2197 = load float, float addrspace(3)* %2196, align 4, !tbaa !6
  %2198 = fmul contract float %2195, %2197
  %2199 = fsub contract float %2194, %2198
  store float %2199, float addrspace(3)* %2133, align 4, !tbaa !6
  %2200 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 13), align 4, !tbaa !6
  %2201 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %2202 = load float, float addrspace(3)* %2201, align 4, !tbaa !6
  %2203 = fmul contract float %2200, %2202
  %2204 = fsub contract float %2199, %2203
  store float %2204, float addrspace(3)* %2133, align 4, !tbaa !6
  %2205 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 14), align 8, !tbaa !6
  %2206 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %2207 = load float, float addrspace(3)* %2206, align 4, !tbaa !6
  %2208 = fmul contract float %2205, %2207
  %2209 = fsub contract float %2204, %2208
  store float %2209, float addrspace(3)* %2133, align 4, !tbaa !6
  %2210 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 15), align 4, !tbaa !6
  %2211 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %2212 = load float, float addrspace(3)* %2211, align 4, !tbaa !6
  %2213 = fmul contract float %2210, %2212
  %2214 = fsub contract float %2209, %2213
  store float %2214, float addrspace(3)* %2133, align 4, !tbaa !6
  %2215 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 16), align 16, !tbaa !6
  %2216 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %2217 = load float, float addrspace(3)* %2216, align 4, !tbaa !6
  %2218 = fmul contract float %2215, %2217
  %2219 = fsub contract float %2214, %2218
  store float %2219, float addrspace(3)* %2133, align 4, !tbaa !6
  %2220 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 17), align 4, !tbaa !6
  %2221 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %2222 = load float, float addrspace(3)* %2221, align 4, !tbaa !6
  %2223 = fmul contract float %2220, %2222
  %2224 = fsub contract float %2219, %2223
  store float %2224, float addrspace(3)* %2133, align 4, !tbaa !6
  %2225 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 18), align 8, !tbaa !6
  %2226 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  %2227 = load float, float addrspace(3)* %2226, align 4, !tbaa !6
  %2228 = fmul contract float %2225, %2227
  %2229 = fsub contract float %2224, %2228
  store float %2229, float addrspace(3)* %2133, align 4, !tbaa !6
  %2230 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 19), align 4, !tbaa !6
  %2231 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 19, i32 %4
  %2232 = load float, float addrspace(3)* %2231, align 4, !tbaa !6
  %2233 = fmul contract float %2230, %2232
  %2234 = fsub contract float %2229, %2233
  store float %2234, float addrspace(3)* %2133, align 4, !tbaa !6
  %2235 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 20), align 16, !tbaa !6
  %2236 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 20, i32 %4
  %2237 = load float, float addrspace(3)* %2236, align 4, !tbaa !6
  %2238 = fmul contract float %2235, %2237
  %2239 = fsub contract float %2234, %2238
  store float %2239, float addrspace(3)* %2133, align 4, !tbaa !6
  %2240 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 21), align 4, !tbaa !6
  %2241 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 21, i32 %4
  %2242 = load float, float addrspace(3)* %2241, align 4, !tbaa !6
  %2243 = fmul contract float %2240, %2242
  %2244 = fsub contract float %2239, %2243
  store float %2244, float addrspace(3)* %2133, align 4, !tbaa !6
  %2245 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 22), align 8, !tbaa !6
  %2246 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 22, i32 %4
  %2247 = load float, float addrspace(3)* %2246, align 4, !tbaa !6
  %2248 = fmul contract float %2245, %2247
  %2249 = fsub contract float %2244, %2248
  store float %2249, float addrspace(3)* %2133, align 4, !tbaa !6
  %2250 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 23), align 4, !tbaa !6
  %2251 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 23, i32 %4
  %2252 = load float, float addrspace(3)* %2251, align 4, !tbaa !6
  %2253 = fmul contract float %2250, %2252
  %2254 = fsub contract float %2249, %2253
  store float %2254, float addrspace(3)* %2133, align 4, !tbaa !6
  %2255 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 24), align 16, !tbaa !6
  %2256 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 24, i32 %4
  %2257 = load float, float addrspace(3)* %2256, align 4, !tbaa !6
  %2258 = fmul contract float %2255, %2257
  %2259 = fsub contract float %2254, %2258
  store float %2259, float addrspace(3)* %2133, align 4, !tbaa !6
  %2260 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 26, i32 %4
  %2261 = load float, float addrspace(3)* %2260, align 4, !tbaa !6
  %2262 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 0), align 16, !tbaa !6
  %2263 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %2264 = load float, float addrspace(3)* %2263, align 4, !tbaa !6
  %2265 = fmul contract float %2262, %2264
  %2266 = fsub contract float %2261, %2265
  store float %2266, float addrspace(3)* %2260, align 4, !tbaa !6
  %2267 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 1), align 4, !tbaa !6
  %2268 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %2269 = load float, float addrspace(3)* %2268, align 4, !tbaa !6
  %2270 = fmul contract float %2267, %2269
  %2271 = fsub contract float %2266, %2270
  store float %2271, float addrspace(3)* %2260, align 4, !tbaa !6
  %2272 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 2), align 8, !tbaa !6
  %2273 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %2274 = load float, float addrspace(3)* %2273, align 4, !tbaa !6
  %2275 = fmul contract float %2272, %2274
  %2276 = fsub contract float %2271, %2275
  store float %2276, float addrspace(3)* %2260, align 4, !tbaa !6
  %2277 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 3), align 4, !tbaa !6
  %2278 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %2279 = load float, float addrspace(3)* %2278, align 4, !tbaa !6
  %2280 = fmul contract float %2277, %2279
  %2281 = fsub contract float %2276, %2280
  store float %2281, float addrspace(3)* %2260, align 4, !tbaa !6
  %2282 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 4), align 16, !tbaa !6
  %2283 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %2284 = load float, float addrspace(3)* %2283, align 4, !tbaa !6
  %2285 = fmul contract float %2282, %2284
  %2286 = fsub contract float %2281, %2285
  store float %2286, float addrspace(3)* %2260, align 4, !tbaa !6
  %2287 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 5), align 4, !tbaa !6
  %2288 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %2289 = load float, float addrspace(3)* %2288, align 4, !tbaa !6
  %2290 = fmul contract float %2287, %2289
  %2291 = fsub contract float %2286, %2290
  store float %2291, float addrspace(3)* %2260, align 4, !tbaa !6
  %2292 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 6), align 8, !tbaa !6
  %2293 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %2294 = load float, float addrspace(3)* %2293, align 4, !tbaa !6
  %2295 = fmul contract float %2292, %2294
  %2296 = fsub contract float %2291, %2295
  store float %2296, float addrspace(3)* %2260, align 4, !tbaa !6
  %2297 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 7), align 4, !tbaa !6
  %2298 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %2299 = load float, float addrspace(3)* %2298, align 4, !tbaa !6
  %2300 = fmul contract float %2297, %2299
  %2301 = fsub contract float %2296, %2300
  store float %2301, float addrspace(3)* %2260, align 4, !tbaa !6
  %2302 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 8), align 16, !tbaa !6
  %2303 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %2304 = load float, float addrspace(3)* %2303, align 4, !tbaa !6
  %2305 = fmul contract float %2302, %2304
  %2306 = fsub contract float %2301, %2305
  store float %2306, float addrspace(3)* %2260, align 4, !tbaa !6
  %2307 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 9), align 4, !tbaa !6
  %2308 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %2309 = load float, float addrspace(3)* %2308, align 4, !tbaa !6
  %2310 = fmul contract float %2307, %2309
  %2311 = fsub contract float %2306, %2310
  store float %2311, float addrspace(3)* %2260, align 4, !tbaa !6
  %2312 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 10), align 8, !tbaa !6
  %2313 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %2314 = load float, float addrspace(3)* %2313, align 4, !tbaa !6
  %2315 = fmul contract float %2312, %2314
  %2316 = fsub contract float %2311, %2315
  store float %2316, float addrspace(3)* %2260, align 4, !tbaa !6
  %2317 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 11), align 4, !tbaa !6
  %2318 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %2319 = load float, float addrspace(3)* %2318, align 4, !tbaa !6
  %2320 = fmul contract float %2317, %2319
  %2321 = fsub contract float %2316, %2320
  store float %2321, float addrspace(3)* %2260, align 4, !tbaa !6
  %2322 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 12), align 16, !tbaa !6
  %2323 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %2324 = load float, float addrspace(3)* %2323, align 4, !tbaa !6
  %2325 = fmul contract float %2322, %2324
  %2326 = fsub contract float %2321, %2325
  store float %2326, float addrspace(3)* %2260, align 4, !tbaa !6
  %2327 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 13), align 4, !tbaa !6
  %2328 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %2329 = load float, float addrspace(3)* %2328, align 4, !tbaa !6
  %2330 = fmul contract float %2327, %2329
  %2331 = fsub contract float %2326, %2330
  store float %2331, float addrspace(3)* %2260, align 4, !tbaa !6
  %2332 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 14), align 8, !tbaa !6
  %2333 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %2334 = load float, float addrspace(3)* %2333, align 4, !tbaa !6
  %2335 = fmul contract float %2332, %2334
  %2336 = fsub contract float %2331, %2335
  store float %2336, float addrspace(3)* %2260, align 4, !tbaa !6
  %2337 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 15), align 4, !tbaa !6
  %2338 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %2339 = load float, float addrspace(3)* %2338, align 4, !tbaa !6
  %2340 = fmul contract float %2337, %2339
  %2341 = fsub contract float %2336, %2340
  store float %2341, float addrspace(3)* %2260, align 4, !tbaa !6
  %2342 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 16), align 16, !tbaa !6
  %2343 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %2344 = load float, float addrspace(3)* %2343, align 4, !tbaa !6
  %2345 = fmul contract float %2342, %2344
  %2346 = fsub contract float %2341, %2345
  store float %2346, float addrspace(3)* %2260, align 4, !tbaa !6
  %2347 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 17), align 4, !tbaa !6
  %2348 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %2349 = load float, float addrspace(3)* %2348, align 4, !tbaa !6
  %2350 = fmul contract float %2347, %2349
  %2351 = fsub contract float %2346, %2350
  store float %2351, float addrspace(3)* %2260, align 4, !tbaa !6
  %2352 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 18), align 8, !tbaa !6
  %2353 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  %2354 = load float, float addrspace(3)* %2353, align 4, !tbaa !6
  %2355 = fmul contract float %2352, %2354
  %2356 = fsub contract float %2351, %2355
  store float %2356, float addrspace(3)* %2260, align 4, !tbaa !6
  %2357 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 19), align 4, !tbaa !6
  %2358 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 19, i32 %4
  %2359 = load float, float addrspace(3)* %2358, align 4, !tbaa !6
  %2360 = fmul contract float %2357, %2359
  %2361 = fsub contract float %2356, %2360
  store float %2361, float addrspace(3)* %2260, align 4, !tbaa !6
  %2362 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 20), align 16, !tbaa !6
  %2363 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 20, i32 %4
  %2364 = load float, float addrspace(3)* %2363, align 4, !tbaa !6
  %2365 = fmul contract float %2362, %2364
  %2366 = fsub contract float %2361, %2365
  store float %2366, float addrspace(3)* %2260, align 4, !tbaa !6
  %2367 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 21), align 4, !tbaa !6
  %2368 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 21, i32 %4
  %2369 = load float, float addrspace(3)* %2368, align 4, !tbaa !6
  %2370 = fmul contract float %2367, %2369
  %2371 = fsub contract float %2366, %2370
  store float %2371, float addrspace(3)* %2260, align 4, !tbaa !6
  %2372 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 22), align 8, !tbaa !6
  %2373 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 22, i32 %4
  %2374 = load float, float addrspace(3)* %2373, align 4, !tbaa !6
  %2375 = fmul contract float %2372, %2374
  %2376 = fsub contract float %2371, %2375
  store float %2376, float addrspace(3)* %2260, align 4, !tbaa !6
  %2377 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 23), align 4, !tbaa !6
  %2378 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 23, i32 %4
  %2379 = load float, float addrspace(3)* %2378, align 4, !tbaa !6
  %2380 = fmul contract float %2377, %2379
  %2381 = fsub contract float %2376, %2380
  store float %2381, float addrspace(3)* %2260, align 4, !tbaa !6
  %2382 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 24), align 16, !tbaa !6
  %2383 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 24, i32 %4
  %2384 = load float, float addrspace(3)* %2383, align 4, !tbaa !6
  %2385 = fmul contract float %2382, %2384
  %2386 = fsub contract float %2381, %2385
  store float %2386, float addrspace(3)* %2260, align 4, !tbaa !6
  %2387 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 25), align 4, !tbaa !6
  %2388 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 25, i32 %4
  %2389 = load float, float addrspace(3)* %2388, align 4, !tbaa !6
  %2390 = fmul contract float %2387, %2389
  %2391 = fsub contract float %2386, %2390
  store float %2391, float addrspace(3)* %2260, align 4, !tbaa !6
  %2392 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 27, i32 %4
  %2393 = load float, float addrspace(3)* %2392, align 4, !tbaa !6
  %2394 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 0), align 16, !tbaa !6
  %2395 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %2396 = load float, float addrspace(3)* %2395, align 4, !tbaa !6
  %2397 = fmul contract float %2394, %2396
  %2398 = fsub contract float %2393, %2397
  store float %2398, float addrspace(3)* %2392, align 4, !tbaa !6
  %2399 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 1), align 4, !tbaa !6
  %2400 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %2401 = load float, float addrspace(3)* %2400, align 4, !tbaa !6
  %2402 = fmul contract float %2399, %2401
  %2403 = fsub contract float %2398, %2402
  store float %2403, float addrspace(3)* %2392, align 4, !tbaa !6
  %2404 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 2), align 8, !tbaa !6
  %2405 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %2406 = load float, float addrspace(3)* %2405, align 4, !tbaa !6
  %2407 = fmul contract float %2404, %2406
  %2408 = fsub contract float %2403, %2407
  store float %2408, float addrspace(3)* %2392, align 4, !tbaa !6
  %2409 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 3), align 4, !tbaa !6
  %2410 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %2411 = load float, float addrspace(3)* %2410, align 4, !tbaa !6
  %2412 = fmul contract float %2409, %2411
  %2413 = fsub contract float %2408, %2412
  store float %2413, float addrspace(3)* %2392, align 4, !tbaa !6
  %2414 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 4), align 16, !tbaa !6
  %2415 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %2416 = load float, float addrspace(3)* %2415, align 4, !tbaa !6
  %2417 = fmul contract float %2414, %2416
  %2418 = fsub contract float %2413, %2417
  store float %2418, float addrspace(3)* %2392, align 4, !tbaa !6
  %2419 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 5), align 4, !tbaa !6
  %2420 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %2421 = load float, float addrspace(3)* %2420, align 4, !tbaa !6
  %2422 = fmul contract float %2419, %2421
  %2423 = fsub contract float %2418, %2422
  store float %2423, float addrspace(3)* %2392, align 4, !tbaa !6
  %2424 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 6), align 8, !tbaa !6
  %2425 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %2426 = load float, float addrspace(3)* %2425, align 4, !tbaa !6
  %2427 = fmul contract float %2424, %2426
  %2428 = fsub contract float %2423, %2427
  store float %2428, float addrspace(3)* %2392, align 4, !tbaa !6
  %2429 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 7), align 4, !tbaa !6
  %2430 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %2431 = load float, float addrspace(3)* %2430, align 4, !tbaa !6
  %2432 = fmul contract float %2429, %2431
  %2433 = fsub contract float %2428, %2432
  store float %2433, float addrspace(3)* %2392, align 4, !tbaa !6
  %2434 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 8), align 16, !tbaa !6
  %2435 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %2436 = load float, float addrspace(3)* %2435, align 4, !tbaa !6
  %2437 = fmul contract float %2434, %2436
  %2438 = fsub contract float %2433, %2437
  store float %2438, float addrspace(3)* %2392, align 4, !tbaa !6
  %2439 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 9), align 4, !tbaa !6
  %2440 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %2441 = load float, float addrspace(3)* %2440, align 4, !tbaa !6
  %2442 = fmul contract float %2439, %2441
  %2443 = fsub contract float %2438, %2442
  store float %2443, float addrspace(3)* %2392, align 4, !tbaa !6
  %2444 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 10), align 8, !tbaa !6
  %2445 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %2446 = load float, float addrspace(3)* %2445, align 4, !tbaa !6
  %2447 = fmul contract float %2444, %2446
  %2448 = fsub contract float %2443, %2447
  store float %2448, float addrspace(3)* %2392, align 4, !tbaa !6
  %2449 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 11), align 4, !tbaa !6
  %2450 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %2451 = load float, float addrspace(3)* %2450, align 4, !tbaa !6
  %2452 = fmul contract float %2449, %2451
  %2453 = fsub contract float %2448, %2452
  store float %2453, float addrspace(3)* %2392, align 4, !tbaa !6
  %2454 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 12), align 16, !tbaa !6
  %2455 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %2456 = load float, float addrspace(3)* %2455, align 4, !tbaa !6
  %2457 = fmul contract float %2454, %2456
  %2458 = fsub contract float %2453, %2457
  store float %2458, float addrspace(3)* %2392, align 4, !tbaa !6
  %2459 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 13), align 4, !tbaa !6
  %2460 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %2461 = load float, float addrspace(3)* %2460, align 4, !tbaa !6
  %2462 = fmul contract float %2459, %2461
  %2463 = fsub contract float %2458, %2462
  store float %2463, float addrspace(3)* %2392, align 4, !tbaa !6
  %2464 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 14), align 8, !tbaa !6
  %2465 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %2466 = load float, float addrspace(3)* %2465, align 4, !tbaa !6
  %2467 = fmul contract float %2464, %2466
  %2468 = fsub contract float %2463, %2467
  store float %2468, float addrspace(3)* %2392, align 4, !tbaa !6
  %2469 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 15), align 4, !tbaa !6
  %2470 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %2471 = load float, float addrspace(3)* %2470, align 4, !tbaa !6
  %2472 = fmul contract float %2469, %2471
  %2473 = fsub contract float %2468, %2472
  store float %2473, float addrspace(3)* %2392, align 4, !tbaa !6
  %2474 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 16), align 16, !tbaa !6
  %2475 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %2476 = load float, float addrspace(3)* %2475, align 4, !tbaa !6
  %2477 = fmul contract float %2474, %2476
  %2478 = fsub contract float %2473, %2477
  store float %2478, float addrspace(3)* %2392, align 4, !tbaa !6
  %2479 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 17), align 4, !tbaa !6
  %2480 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %2481 = load float, float addrspace(3)* %2480, align 4, !tbaa !6
  %2482 = fmul contract float %2479, %2481
  %2483 = fsub contract float %2478, %2482
  store float %2483, float addrspace(3)* %2392, align 4, !tbaa !6
  %2484 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 18), align 8, !tbaa !6
  %2485 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  %2486 = load float, float addrspace(3)* %2485, align 4, !tbaa !6
  %2487 = fmul contract float %2484, %2486
  %2488 = fsub contract float %2483, %2487
  store float %2488, float addrspace(3)* %2392, align 4, !tbaa !6
  %2489 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 19), align 4, !tbaa !6
  %2490 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 19, i32 %4
  %2491 = load float, float addrspace(3)* %2490, align 4, !tbaa !6
  %2492 = fmul contract float %2489, %2491
  %2493 = fsub contract float %2488, %2492
  store float %2493, float addrspace(3)* %2392, align 4, !tbaa !6
  %2494 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 20), align 16, !tbaa !6
  %2495 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 20, i32 %4
  %2496 = load float, float addrspace(3)* %2495, align 4, !tbaa !6
  %2497 = fmul contract float %2494, %2496
  %2498 = fsub contract float %2493, %2497
  store float %2498, float addrspace(3)* %2392, align 4, !tbaa !6
  %2499 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 21), align 4, !tbaa !6
  %2500 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 21, i32 %4
  %2501 = load float, float addrspace(3)* %2500, align 4, !tbaa !6
  %2502 = fmul contract float %2499, %2501
  %2503 = fsub contract float %2498, %2502
  store float %2503, float addrspace(3)* %2392, align 4, !tbaa !6
  %2504 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 22), align 8, !tbaa !6
  %2505 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 22, i32 %4
  %2506 = load float, float addrspace(3)* %2505, align 4, !tbaa !6
  %2507 = fmul contract float %2504, %2506
  %2508 = fsub contract float %2503, %2507
  store float %2508, float addrspace(3)* %2392, align 4, !tbaa !6
  %2509 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 23), align 4, !tbaa !6
  %2510 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 23, i32 %4
  %2511 = load float, float addrspace(3)* %2510, align 4, !tbaa !6
  %2512 = fmul contract float %2509, %2511
  %2513 = fsub contract float %2508, %2512
  store float %2513, float addrspace(3)* %2392, align 4, !tbaa !6
  %2514 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 24), align 16, !tbaa !6
  %2515 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 24, i32 %4
  %2516 = load float, float addrspace(3)* %2515, align 4, !tbaa !6
  %2517 = fmul contract float %2514, %2516
  %2518 = fsub contract float %2513, %2517
  store float %2518, float addrspace(3)* %2392, align 4, !tbaa !6
  %2519 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 25), align 4, !tbaa !6
  %2520 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 25, i32 %4
  %2521 = load float, float addrspace(3)* %2520, align 4, !tbaa !6
  %2522 = fmul contract float %2519, %2521
  %2523 = fsub contract float %2518, %2522
  store float %2523, float addrspace(3)* %2392, align 4, !tbaa !6
  %2524 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 26), align 8, !tbaa !6
  %2525 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 26, i32 %4
  %2526 = load float, float addrspace(3)* %2525, align 4, !tbaa !6
  %2527 = fmul contract float %2524, %2526
  %2528 = fsub contract float %2523, %2527
  store float %2528, float addrspace(3)* %2392, align 4, !tbaa !6
  %2529 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 28, i32 %4
  %2530 = load float, float addrspace(3)* %2529, align 4, !tbaa !6
  %2531 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 0), align 16, !tbaa !6
  %2532 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %2533 = load float, float addrspace(3)* %2532, align 4, !tbaa !6
  %2534 = fmul contract float %2531, %2533
  %2535 = fsub contract float %2530, %2534
  store float %2535, float addrspace(3)* %2529, align 4, !tbaa !6
  %2536 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 1), align 4, !tbaa !6
  %2537 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %2538 = load float, float addrspace(3)* %2537, align 4, !tbaa !6
  %2539 = fmul contract float %2536, %2538
  %2540 = fsub contract float %2535, %2539
  store float %2540, float addrspace(3)* %2529, align 4, !tbaa !6
  %2541 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 2), align 8, !tbaa !6
  %2542 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %2543 = load float, float addrspace(3)* %2542, align 4, !tbaa !6
  %2544 = fmul contract float %2541, %2543
  %2545 = fsub contract float %2540, %2544
  store float %2545, float addrspace(3)* %2529, align 4, !tbaa !6
  %2546 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 3), align 4, !tbaa !6
  %2547 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %2548 = load float, float addrspace(3)* %2547, align 4, !tbaa !6
  %2549 = fmul contract float %2546, %2548
  %2550 = fsub contract float %2545, %2549
  store float %2550, float addrspace(3)* %2529, align 4, !tbaa !6
  %2551 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 4), align 16, !tbaa !6
  %2552 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %2553 = load float, float addrspace(3)* %2552, align 4, !tbaa !6
  %2554 = fmul contract float %2551, %2553
  %2555 = fsub contract float %2550, %2554
  store float %2555, float addrspace(3)* %2529, align 4, !tbaa !6
  %2556 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 5), align 4, !tbaa !6
  %2557 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %2558 = load float, float addrspace(3)* %2557, align 4, !tbaa !6
  %2559 = fmul contract float %2556, %2558
  %2560 = fsub contract float %2555, %2559
  store float %2560, float addrspace(3)* %2529, align 4, !tbaa !6
  %2561 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 6), align 8, !tbaa !6
  %2562 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %2563 = load float, float addrspace(3)* %2562, align 4, !tbaa !6
  %2564 = fmul contract float %2561, %2563
  %2565 = fsub contract float %2560, %2564
  store float %2565, float addrspace(3)* %2529, align 4, !tbaa !6
  %2566 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 7), align 4, !tbaa !6
  %2567 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %2568 = load float, float addrspace(3)* %2567, align 4, !tbaa !6
  %2569 = fmul contract float %2566, %2568
  %2570 = fsub contract float %2565, %2569
  store float %2570, float addrspace(3)* %2529, align 4, !tbaa !6
  %2571 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 8), align 16, !tbaa !6
  %2572 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %2573 = load float, float addrspace(3)* %2572, align 4, !tbaa !6
  %2574 = fmul contract float %2571, %2573
  %2575 = fsub contract float %2570, %2574
  store float %2575, float addrspace(3)* %2529, align 4, !tbaa !6
  %2576 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 9), align 4, !tbaa !6
  %2577 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %2578 = load float, float addrspace(3)* %2577, align 4, !tbaa !6
  %2579 = fmul contract float %2576, %2578
  %2580 = fsub contract float %2575, %2579
  store float %2580, float addrspace(3)* %2529, align 4, !tbaa !6
  %2581 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 10), align 8, !tbaa !6
  %2582 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %2583 = load float, float addrspace(3)* %2582, align 4, !tbaa !6
  %2584 = fmul contract float %2581, %2583
  %2585 = fsub contract float %2580, %2584
  store float %2585, float addrspace(3)* %2529, align 4, !tbaa !6
  %2586 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 11), align 4, !tbaa !6
  %2587 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %2588 = load float, float addrspace(3)* %2587, align 4, !tbaa !6
  %2589 = fmul contract float %2586, %2588
  %2590 = fsub contract float %2585, %2589
  store float %2590, float addrspace(3)* %2529, align 4, !tbaa !6
  %2591 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 12), align 16, !tbaa !6
  %2592 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %2593 = load float, float addrspace(3)* %2592, align 4, !tbaa !6
  %2594 = fmul contract float %2591, %2593
  %2595 = fsub contract float %2590, %2594
  store float %2595, float addrspace(3)* %2529, align 4, !tbaa !6
  %2596 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 13), align 4, !tbaa !6
  %2597 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %2598 = load float, float addrspace(3)* %2597, align 4, !tbaa !6
  %2599 = fmul contract float %2596, %2598
  %2600 = fsub contract float %2595, %2599
  store float %2600, float addrspace(3)* %2529, align 4, !tbaa !6
  %2601 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 14), align 8, !tbaa !6
  %2602 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %2603 = load float, float addrspace(3)* %2602, align 4, !tbaa !6
  %2604 = fmul contract float %2601, %2603
  %2605 = fsub contract float %2600, %2604
  store float %2605, float addrspace(3)* %2529, align 4, !tbaa !6
  %2606 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 15), align 4, !tbaa !6
  %2607 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %2608 = load float, float addrspace(3)* %2607, align 4, !tbaa !6
  %2609 = fmul contract float %2606, %2608
  %2610 = fsub contract float %2605, %2609
  store float %2610, float addrspace(3)* %2529, align 4, !tbaa !6
  %2611 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 16), align 16, !tbaa !6
  %2612 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %2613 = load float, float addrspace(3)* %2612, align 4, !tbaa !6
  %2614 = fmul contract float %2611, %2613
  %2615 = fsub contract float %2610, %2614
  store float %2615, float addrspace(3)* %2529, align 4, !tbaa !6
  %2616 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 17), align 4, !tbaa !6
  %2617 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %2618 = load float, float addrspace(3)* %2617, align 4, !tbaa !6
  %2619 = fmul contract float %2616, %2618
  %2620 = fsub contract float %2615, %2619
  store float %2620, float addrspace(3)* %2529, align 4, !tbaa !6
  %2621 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 18), align 8, !tbaa !6
  %2622 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  %2623 = load float, float addrspace(3)* %2622, align 4, !tbaa !6
  %2624 = fmul contract float %2621, %2623
  %2625 = fsub contract float %2620, %2624
  store float %2625, float addrspace(3)* %2529, align 4, !tbaa !6
  %2626 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 19), align 4, !tbaa !6
  %2627 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 19, i32 %4
  %2628 = load float, float addrspace(3)* %2627, align 4, !tbaa !6
  %2629 = fmul contract float %2626, %2628
  %2630 = fsub contract float %2625, %2629
  store float %2630, float addrspace(3)* %2529, align 4, !tbaa !6
  %2631 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 20), align 16, !tbaa !6
  %2632 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 20, i32 %4
  %2633 = load float, float addrspace(3)* %2632, align 4, !tbaa !6
  %2634 = fmul contract float %2631, %2633
  %2635 = fsub contract float %2630, %2634
  store float %2635, float addrspace(3)* %2529, align 4, !tbaa !6
  %2636 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 21), align 4, !tbaa !6
  %2637 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 21, i32 %4
  %2638 = load float, float addrspace(3)* %2637, align 4, !tbaa !6
  %2639 = fmul contract float %2636, %2638
  %2640 = fsub contract float %2635, %2639
  store float %2640, float addrspace(3)* %2529, align 4, !tbaa !6
  %2641 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 22), align 8, !tbaa !6
  %2642 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 22, i32 %4
  %2643 = load float, float addrspace(3)* %2642, align 4, !tbaa !6
  %2644 = fmul contract float %2641, %2643
  %2645 = fsub contract float %2640, %2644
  store float %2645, float addrspace(3)* %2529, align 4, !tbaa !6
  %2646 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 23), align 4, !tbaa !6
  %2647 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 23, i32 %4
  %2648 = load float, float addrspace(3)* %2647, align 4, !tbaa !6
  %2649 = fmul contract float %2646, %2648
  %2650 = fsub contract float %2645, %2649
  store float %2650, float addrspace(3)* %2529, align 4, !tbaa !6
  %2651 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 24), align 16, !tbaa !6
  %2652 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 24, i32 %4
  %2653 = load float, float addrspace(3)* %2652, align 4, !tbaa !6
  %2654 = fmul contract float %2651, %2653
  %2655 = fsub contract float %2650, %2654
  store float %2655, float addrspace(3)* %2529, align 4, !tbaa !6
  %2656 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 25), align 4, !tbaa !6
  %2657 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 25, i32 %4
  %2658 = load float, float addrspace(3)* %2657, align 4, !tbaa !6
  %2659 = fmul contract float %2656, %2658
  %2660 = fsub contract float %2655, %2659
  store float %2660, float addrspace(3)* %2529, align 4, !tbaa !6
  %2661 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 26), align 8, !tbaa !6
  %2662 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 26, i32 %4
  %2663 = load float, float addrspace(3)* %2662, align 4, !tbaa !6
  %2664 = fmul contract float %2661, %2663
  %2665 = fsub contract float %2660, %2664
  store float %2665, float addrspace(3)* %2529, align 4, !tbaa !6
  %2666 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 27), align 4, !tbaa !6
  %2667 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 27, i32 %4
  %2668 = load float, float addrspace(3)* %2667, align 4, !tbaa !6
  %2669 = fmul contract float %2666, %2668
  %2670 = fsub contract float %2665, %2669
  store float %2670, float addrspace(3)* %2529, align 4, !tbaa !6
  %2671 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 29, i32 %4
  %2672 = load float, float addrspace(3)* %2671, align 4, !tbaa !6
  %2673 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 0), align 16, !tbaa !6
  %2674 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %2675 = load float, float addrspace(3)* %2674, align 4, !tbaa !6
  %2676 = fmul contract float %2673, %2675
  %2677 = fsub contract float %2672, %2676
  store float %2677, float addrspace(3)* %2671, align 4, !tbaa !6
  %2678 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 1), align 4, !tbaa !6
  %2679 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %2680 = load float, float addrspace(3)* %2679, align 4, !tbaa !6
  %2681 = fmul contract float %2678, %2680
  %2682 = fsub contract float %2677, %2681
  store float %2682, float addrspace(3)* %2671, align 4, !tbaa !6
  %2683 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 2), align 8, !tbaa !6
  %2684 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %2685 = load float, float addrspace(3)* %2684, align 4, !tbaa !6
  %2686 = fmul contract float %2683, %2685
  %2687 = fsub contract float %2682, %2686
  store float %2687, float addrspace(3)* %2671, align 4, !tbaa !6
  %2688 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 3), align 4, !tbaa !6
  %2689 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %2690 = load float, float addrspace(3)* %2689, align 4, !tbaa !6
  %2691 = fmul contract float %2688, %2690
  %2692 = fsub contract float %2687, %2691
  store float %2692, float addrspace(3)* %2671, align 4, !tbaa !6
  %2693 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 4), align 16, !tbaa !6
  %2694 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %2695 = load float, float addrspace(3)* %2694, align 4, !tbaa !6
  %2696 = fmul contract float %2693, %2695
  %2697 = fsub contract float %2692, %2696
  store float %2697, float addrspace(3)* %2671, align 4, !tbaa !6
  %2698 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 5), align 4, !tbaa !6
  %2699 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %2700 = load float, float addrspace(3)* %2699, align 4, !tbaa !6
  %2701 = fmul contract float %2698, %2700
  %2702 = fsub contract float %2697, %2701
  store float %2702, float addrspace(3)* %2671, align 4, !tbaa !6
  %2703 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 6), align 8, !tbaa !6
  %2704 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %2705 = load float, float addrspace(3)* %2704, align 4, !tbaa !6
  %2706 = fmul contract float %2703, %2705
  %2707 = fsub contract float %2702, %2706
  store float %2707, float addrspace(3)* %2671, align 4, !tbaa !6
  %2708 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 7), align 4, !tbaa !6
  %2709 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %2710 = load float, float addrspace(3)* %2709, align 4, !tbaa !6
  %2711 = fmul contract float %2708, %2710
  %2712 = fsub contract float %2707, %2711
  store float %2712, float addrspace(3)* %2671, align 4, !tbaa !6
  %2713 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 8), align 16, !tbaa !6
  %2714 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %2715 = load float, float addrspace(3)* %2714, align 4, !tbaa !6
  %2716 = fmul contract float %2713, %2715
  %2717 = fsub contract float %2712, %2716
  store float %2717, float addrspace(3)* %2671, align 4, !tbaa !6
  %2718 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 9), align 4, !tbaa !6
  %2719 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %2720 = load float, float addrspace(3)* %2719, align 4, !tbaa !6
  %2721 = fmul contract float %2718, %2720
  %2722 = fsub contract float %2717, %2721
  store float %2722, float addrspace(3)* %2671, align 4, !tbaa !6
  %2723 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 10), align 8, !tbaa !6
  %2724 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %2725 = load float, float addrspace(3)* %2724, align 4, !tbaa !6
  %2726 = fmul contract float %2723, %2725
  %2727 = fsub contract float %2722, %2726
  store float %2727, float addrspace(3)* %2671, align 4, !tbaa !6
  %2728 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 11), align 4, !tbaa !6
  %2729 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %2730 = load float, float addrspace(3)* %2729, align 4, !tbaa !6
  %2731 = fmul contract float %2728, %2730
  %2732 = fsub contract float %2727, %2731
  store float %2732, float addrspace(3)* %2671, align 4, !tbaa !6
  %2733 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 12), align 16, !tbaa !6
  %2734 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %2735 = load float, float addrspace(3)* %2734, align 4, !tbaa !6
  %2736 = fmul contract float %2733, %2735
  %2737 = fsub contract float %2732, %2736
  store float %2737, float addrspace(3)* %2671, align 4, !tbaa !6
  %2738 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 13), align 4, !tbaa !6
  %2739 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %2740 = load float, float addrspace(3)* %2739, align 4, !tbaa !6
  %2741 = fmul contract float %2738, %2740
  %2742 = fsub contract float %2737, %2741
  store float %2742, float addrspace(3)* %2671, align 4, !tbaa !6
  %2743 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 14), align 8, !tbaa !6
  %2744 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %2745 = load float, float addrspace(3)* %2744, align 4, !tbaa !6
  %2746 = fmul contract float %2743, %2745
  %2747 = fsub contract float %2742, %2746
  store float %2747, float addrspace(3)* %2671, align 4, !tbaa !6
  %2748 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 15), align 4, !tbaa !6
  %2749 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %2750 = load float, float addrspace(3)* %2749, align 4, !tbaa !6
  %2751 = fmul contract float %2748, %2750
  %2752 = fsub contract float %2747, %2751
  store float %2752, float addrspace(3)* %2671, align 4, !tbaa !6
  %2753 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 16), align 16, !tbaa !6
  %2754 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %2755 = load float, float addrspace(3)* %2754, align 4, !tbaa !6
  %2756 = fmul contract float %2753, %2755
  %2757 = fsub contract float %2752, %2756
  store float %2757, float addrspace(3)* %2671, align 4, !tbaa !6
  %2758 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 17), align 4, !tbaa !6
  %2759 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %2760 = load float, float addrspace(3)* %2759, align 4, !tbaa !6
  %2761 = fmul contract float %2758, %2760
  %2762 = fsub contract float %2757, %2761
  store float %2762, float addrspace(3)* %2671, align 4, !tbaa !6
  %2763 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 18), align 8, !tbaa !6
  %2764 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  %2765 = load float, float addrspace(3)* %2764, align 4, !tbaa !6
  %2766 = fmul contract float %2763, %2765
  %2767 = fsub contract float %2762, %2766
  store float %2767, float addrspace(3)* %2671, align 4, !tbaa !6
  %2768 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 19), align 4, !tbaa !6
  %2769 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 19, i32 %4
  %2770 = load float, float addrspace(3)* %2769, align 4, !tbaa !6
  %2771 = fmul contract float %2768, %2770
  %2772 = fsub contract float %2767, %2771
  store float %2772, float addrspace(3)* %2671, align 4, !tbaa !6
  %2773 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 20), align 16, !tbaa !6
  %2774 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 20, i32 %4
  %2775 = load float, float addrspace(3)* %2774, align 4, !tbaa !6
  %2776 = fmul contract float %2773, %2775
  %2777 = fsub contract float %2772, %2776
  store float %2777, float addrspace(3)* %2671, align 4, !tbaa !6
  %2778 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 21), align 4, !tbaa !6
  %2779 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 21, i32 %4
  %2780 = load float, float addrspace(3)* %2779, align 4, !tbaa !6
  %2781 = fmul contract float %2778, %2780
  %2782 = fsub contract float %2777, %2781
  store float %2782, float addrspace(3)* %2671, align 4, !tbaa !6
  %2783 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 22), align 8, !tbaa !6
  %2784 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 22, i32 %4
  %2785 = load float, float addrspace(3)* %2784, align 4, !tbaa !6
  %2786 = fmul contract float %2783, %2785
  %2787 = fsub contract float %2782, %2786
  store float %2787, float addrspace(3)* %2671, align 4, !tbaa !6
  %2788 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 23), align 4, !tbaa !6
  %2789 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 23, i32 %4
  %2790 = load float, float addrspace(3)* %2789, align 4, !tbaa !6
  %2791 = fmul contract float %2788, %2790
  %2792 = fsub contract float %2787, %2791
  store float %2792, float addrspace(3)* %2671, align 4, !tbaa !6
  %2793 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 24), align 16, !tbaa !6
  %2794 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 24, i32 %4
  %2795 = load float, float addrspace(3)* %2794, align 4, !tbaa !6
  %2796 = fmul contract float %2793, %2795
  %2797 = fsub contract float %2792, %2796
  store float %2797, float addrspace(3)* %2671, align 4, !tbaa !6
  %2798 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 25), align 4, !tbaa !6
  %2799 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 25, i32 %4
  %2800 = load float, float addrspace(3)* %2799, align 4, !tbaa !6
  %2801 = fmul contract float %2798, %2800
  %2802 = fsub contract float %2797, %2801
  store float %2802, float addrspace(3)* %2671, align 4, !tbaa !6
  %2803 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 26), align 8, !tbaa !6
  %2804 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 26, i32 %4
  %2805 = load float, float addrspace(3)* %2804, align 4, !tbaa !6
  %2806 = fmul contract float %2803, %2805
  %2807 = fsub contract float %2802, %2806
  store float %2807, float addrspace(3)* %2671, align 4, !tbaa !6
  %2808 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 27), align 4, !tbaa !6
  %2809 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 27, i32 %4
  %2810 = load float, float addrspace(3)* %2809, align 4, !tbaa !6
  %2811 = fmul contract float %2808, %2810
  %2812 = fsub contract float %2807, %2811
  store float %2812, float addrspace(3)* %2671, align 4, !tbaa !6
  %2813 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 28), align 16, !tbaa !6
  %2814 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 28, i32 %4
  %2815 = load float, float addrspace(3)* %2814, align 4, !tbaa !6
  %2816 = fmul contract float %2813, %2815
  %2817 = fsub contract float %2812, %2816
  store float %2817, float addrspace(3)* %2671, align 4, !tbaa !6
  %2818 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 30, i32 %4
  %2819 = load float, float addrspace(3)* %2818, align 4, !tbaa !6
  %2820 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 0), align 16, !tbaa !6
  %2821 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %2822 = load float, float addrspace(3)* %2821, align 4, !tbaa !6
  %2823 = fmul contract float %2820, %2822
  %2824 = fsub contract float %2819, %2823
  store float %2824, float addrspace(3)* %2818, align 4, !tbaa !6
  %2825 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 1), align 4, !tbaa !6
  %2826 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %2827 = load float, float addrspace(3)* %2826, align 4, !tbaa !6
  %2828 = fmul contract float %2825, %2827
  %2829 = fsub contract float %2824, %2828
  store float %2829, float addrspace(3)* %2818, align 4, !tbaa !6
  %2830 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 2), align 8, !tbaa !6
  %2831 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %2832 = load float, float addrspace(3)* %2831, align 4, !tbaa !6
  %2833 = fmul contract float %2830, %2832
  %2834 = fsub contract float %2829, %2833
  store float %2834, float addrspace(3)* %2818, align 4, !tbaa !6
  %2835 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 3), align 4, !tbaa !6
  %2836 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %2837 = load float, float addrspace(3)* %2836, align 4, !tbaa !6
  %2838 = fmul contract float %2835, %2837
  %2839 = fsub contract float %2834, %2838
  store float %2839, float addrspace(3)* %2818, align 4, !tbaa !6
  %2840 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 4), align 16, !tbaa !6
  %2841 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %2842 = load float, float addrspace(3)* %2841, align 4, !tbaa !6
  %2843 = fmul contract float %2840, %2842
  %2844 = fsub contract float %2839, %2843
  store float %2844, float addrspace(3)* %2818, align 4, !tbaa !6
  %2845 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 5), align 4, !tbaa !6
  %2846 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %2847 = load float, float addrspace(3)* %2846, align 4, !tbaa !6
  %2848 = fmul contract float %2845, %2847
  %2849 = fsub contract float %2844, %2848
  store float %2849, float addrspace(3)* %2818, align 4, !tbaa !6
  %2850 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 6), align 8, !tbaa !6
  %2851 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %2852 = load float, float addrspace(3)* %2851, align 4, !tbaa !6
  %2853 = fmul contract float %2850, %2852
  %2854 = fsub contract float %2849, %2853
  store float %2854, float addrspace(3)* %2818, align 4, !tbaa !6
  %2855 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 7), align 4, !tbaa !6
  %2856 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %2857 = load float, float addrspace(3)* %2856, align 4, !tbaa !6
  %2858 = fmul contract float %2855, %2857
  %2859 = fsub contract float %2854, %2858
  store float %2859, float addrspace(3)* %2818, align 4, !tbaa !6
  %2860 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 8), align 16, !tbaa !6
  %2861 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %2862 = load float, float addrspace(3)* %2861, align 4, !tbaa !6
  %2863 = fmul contract float %2860, %2862
  %2864 = fsub contract float %2859, %2863
  store float %2864, float addrspace(3)* %2818, align 4, !tbaa !6
  %2865 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 9), align 4, !tbaa !6
  %2866 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %2867 = load float, float addrspace(3)* %2866, align 4, !tbaa !6
  %2868 = fmul contract float %2865, %2867
  %2869 = fsub contract float %2864, %2868
  store float %2869, float addrspace(3)* %2818, align 4, !tbaa !6
  %2870 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 10), align 8, !tbaa !6
  %2871 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %2872 = load float, float addrspace(3)* %2871, align 4, !tbaa !6
  %2873 = fmul contract float %2870, %2872
  %2874 = fsub contract float %2869, %2873
  store float %2874, float addrspace(3)* %2818, align 4, !tbaa !6
  %2875 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 11), align 4, !tbaa !6
  %2876 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %2877 = load float, float addrspace(3)* %2876, align 4, !tbaa !6
  %2878 = fmul contract float %2875, %2877
  %2879 = fsub contract float %2874, %2878
  store float %2879, float addrspace(3)* %2818, align 4, !tbaa !6
  %2880 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 12), align 16, !tbaa !6
  %2881 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %2882 = load float, float addrspace(3)* %2881, align 4, !tbaa !6
  %2883 = fmul contract float %2880, %2882
  %2884 = fsub contract float %2879, %2883
  store float %2884, float addrspace(3)* %2818, align 4, !tbaa !6
  %2885 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 13), align 4, !tbaa !6
  %2886 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %2887 = load float, float addrspace(3)* %2886, align 4, !tbaa !6
  %2888 = fmul contract float %2885, %2887
  %2889 = fsub contract float %2884, %2888
  store float %2889, float addrspace(3)* %2818, align 4, !tbaa !6
  %2890 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 14), align 8, !tbaa !6
  %2891 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %2892 = load float, float addrspace(3)* %2891, align 4, !tbaa !6
  %2893 = fmul contract float %2890, %2892
  %2894 = fsub contract float %2889, %2893
  store float %2894, float addrspace(3)* %2818, align 4, !tbaa !6
  %2895 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 15), align 4, !tbaa !6
  %2896 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %2897 = load float, float addrspace(3)* %2896, align 4, !tbaa !6
  %2898 = fmul contract float %2895, %2897
  %2899 = fsub contract float %2894, %2898
  store float %2899, float addrspace(3)* %2818, align 4, !tbaa !6
  %2900 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 16), align 16, !tbaa !6
  %2901 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %2902 = load float, float addrspace(3)* %2901, align 4, !tbaa !6
  %2903 = fmul contract float %2900, %2902
  %2904 = fsub contract float %2899, %2903
  store float %2904, float addrspace(3)* %2818, align 4, !tbaa !6
  %2905 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 17), align 4, !tbaa !6
  %2906 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %2907 = load float, float addrspace(3)* %2906, align 4, !tbaa !6
  %2908 = fmul contract float %2905, %2907
  %2909 = fsub contract float %2904, %2908
  store float %2909, float addrspace(3)* %2818, align 4, !tbaa !6
  %2910 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 18), align 8, !tbaa !6
  %2911 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  %2912 = load float, float addrspace(3)* %2911, align 4, !tbaa !6
  %2913 = fmul contract float %2910, %2912
  %2914 = fsub contract float %2909, %2913
  store float %2914, float addrspace(3)* %2818, align 4, !tbaa !6
  %2915 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 19), align 4, !tbaa !6
  %2916 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 19, i32 %4
  %2917 = load float, float addrspace(3)* %2916, align 4, !tbaa !6
  %2918 = fmul contract float %2915, %2917
  %2919 = fsub contract float %2914, %2918
  store float %2919, float addrspace(3)* %2818, align 4, !tbaa !6
  %2920 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 20), align 16, !tbaa !6
  %2921 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 20, i32 %4
  %2922 = load float, float addrspace(3)* %2921, align 4, !tbaa !6
  %2923 = fmul contract float %2920, %2922
  %2924 = fsub contract float %2919, %2923
  store float %2924, float addrspace(3)* %2818, align 4, !tbaa !6
  %2925 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 21), align 4, !tbaa !6
  %2926 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 21, i32 %4
  %2927 = load float, float addrspace(3)* %2926, align 4, !tbaa !6
  %2928 = fmul contract float %2925, %2927
  %2929 = fsub contract float %2924, %2928
  store float %2929, float addrspace(3)* %2818, align 4, !tbaa !6
  %2930 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 22), align 8, !tbaa !6
  %2931 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 22, i32 %4
  %2932 = load float, float addrspace(3)* %2931, align 4, !tbaa !6
  %2933 = fmul contract float %2930, %2932
  %2934 = fsub contract float %2929, %2933
  store float %2934, float addrspace(3)* %2818, align 4, !tbaa !6
  %2935 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 23), align 4, !tbaa !6
  %2936 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 23, i32 %4
  %2937 = load float, float addrspace(3)* %2936, align 4, !tbaa !6
  %2938 = fmul contract float %2935, %2937
  %2939 = fsub contract float %2934, %2938
  store float %2939, float addrspace(3)* %2818, align 4, !tbaa !6
  %2940 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 24), align 16, !tbaa !6
  %2941 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 24, i32 %4
  %2942 = load float, float addrspace(3)* %2941, align 4, !tbaa !6
  %2943 = fmul contract float %2940, %2942
  %2944 = fsub contract float %2939, %2943
  store float %2944, float addrspace(3)* %2818, align 4, !tbaa !6
  %2945 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 25), align 4, !tbaa !6
  %2946 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 25, i32 %4
  %2947 = load float, float addrspace(3)* %2946, align 4, !tbaa !6
  %2948 = fmul contract float %2945, %2947
  %2949 = fsub contract float %2944, %2948
  store float %2949, float addrspace(3)* %2818, align 4, !tbaa !6
  %2950 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 26), align 8, !tbaa !6
  %2951 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 26, i32 %4
  %2952 = load float, float addrspace(3)* %2951, align 4, !tbaa !6
  %2953 = fmul contract float %2950, %2952
  %2954 = fsub contract float %2949, %2953
  store float %2954, float addrspace(3)* %2818, align 4, !tbaa !6
  %2955 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 27), align 4, !tbaa !6
  %2956 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 27, i32 %4
  %2957 = load float, float addrspace(3)* %2956, align 4, !tbaa !6
  %2958 = fmul contract float %2955, %2957
  %2959 = fsub contract float %2954, %2958
  store float %2959, float addrspace(3)* %2818, align 4, !tbaa !6
  %2960 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 28), align 16, !tbaa !6
  %2961 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 28, i32 %4
  %2962 = load float, float addrspace(3)* %2961, align 4, !tbaa !6
  %2963 = fmul contract float %2960, %2962
  %2964 = fsub contract float %2959, %2963
  store float %2964, float addrspace(3)* %2818, align 4, !tbaa !6
  %2965 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 29), align 4, !tbaa !6
  %2966 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 29, i32 %4
  %2967 = load float, float addrspace(3)* %2966, align 4, !tbaa !6
  %2968 = fmul contract float %2965, %2967
  %2969 = fsub contract float %2964, %2968
  store float %2969, float addrspace(3)* %2818, align 4, !tbaa !6
  %2970 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 31, i32 %4
  %2971 = load float, float addrspace(3)* %2970, align 4, !tbaa !6
  %2972 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 0), align 16, !tbaa !6
  %2973 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %2974 = load float, float addrspace(3)* %2973, align 4, !tbaa !6
  %2975 = fmul contract float %2972, %2974
  %2976 = fsub contract float %2971, %2975
  store float %2976, float addrspace(3)* %2970, align 4, !tbaa !6
  %2977 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 1), align 4, !tbaa !6
  %2978 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %2979 = load float, float addrspace(3)* %2978, align 4, !tbaa !6
  %2980 = fmul contract float %2977, %2979
  %2981 = fsub contract float %2976, %2980
  store float %2981, float addrspace(3)* %2970, align 4, !tbaa !6
  %2982 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 2), align 8, !tbaa !6
  %2983 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %2984 = load float, float addrspace(3)* %2983, align 4, !tbaa !6
  %2985 = fmul contract float %2982, %2984
  %2986 = fsub contract float %2981, %2985
  store float %2986, float addrspace(3)* %2970, align 4, !tbaa !6
  %2987 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 3), align 4, !tbaa !6
  %2988 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %2989 = load float, float addrspace(3)* %2988, align 4, !tbaa !6
  %2990 = fmul contract float %2987, %2989
  %2991 = fsub contract float %2986, %2990
  store float %2991, float addrspace(3)* %2970, align 4, !tbaa !6
  %2992 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 4), align 16, !tbaa !6
  %2993 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %2994 = load float, float addrspace(3)* %2993, align 4, !tbaa !6
  %2995 = fmul contract float %2992, %2994
  %2996 = fsub contract float %2991, %2995
  store float %2996, float addrspace(3)* %2970, align 4, !tbaa !6
  %2997 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 5), align 4, !tbaa !6
  %2998 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %2999 = load float, float addrspace(3)* %2998, align 4, !tbaa !6
  %3000 = fmul contract float %2997, %2999
  %3001 = fsub contract float %2996, %3000
  store float %3001, float addrspace(3)* %2970, align 4, !tbaa !6
  %3002 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 6), align 8, !tbaa !6
  %3003 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %3004 = load float, float addrspace(3)* %3003, align 4, !tbaa !6
  %3005 = fmul contract float %3002, %3004
  %3006 = fsub contract float %3001, %3005
  store float %3006, float addrspace(3)* %2970, align 4, !tbaa !6
  %3007 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 7), align 4, !tbaa !6
  %3008 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %3009 = load float, float addrspace(3)* %3008, align 4, !tbaa !6
  %3010 = fmul contract float %3007, %3009
  %3011 = fsub contract float %3006, %3010
  store float %3011, float addrspace(3)* %2970, align 4, !tbaa !6
  %3012 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 8), align 16, !tbaa !6
  %3013 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %3014 = load float, float addrspace(3)* %3013, align 4, !tbaa !6
  %3015 = fmul contract float %3012, %3014
  %3016 = fsub contract float %3011, %3015
  store float %3016, float addrspace(3)* %2970, align 4, !tbaa !6
  %3017 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 9), align 4, !tbaa !6
  %3018 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %3019 = load float, float addrspace(3)* %3018, align 4, !tbaa !6
  %3020 = fmul contract float %3017, %3019
  %3021 = fsub contract float %3016, %3020
  store float %3021, float addrspace(3)* %2970, align 4, !tbaa !6
  %3022 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 10), align 8, !tbaa !6
  %3023 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %3024 = load float, float addrspace(3)* %3023, align 4, !tbaa !6
  %3025 = fmul contract float %3022, %3024
  %3026 = fsub contract float %3021, %3025
  store float %3026, float addrspace(3)* %2970, align 4, !tbaa !6
  %3027 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 11), align 4, !tbaa !6
  %3028 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %3029 = load float, float addrspace(3)* %3028, align 4, !tbaa !6
  %3030 = fmul contract float %3027, %3029
  %3031 = fsub contract float %3026, %3030
  store float %3031, float addrspace(3)* %2970, align 4, !tbaa !6
  %3032 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 12), align 16, !tbaa !6
  %3033 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %3034 = load float, float addrspace(3)* %3033, align 4, !tbaa !6
  %3035 = fmul contract float %3032, %3034
  %3036 = fsub contract float %3031, %3035
  store float %3036, float addrspace(3)* %2970, align 4, !tbaa !6
  %3037 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 13), align 4, !tbaa !6
  %3038 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %3039 = load float, float addrspace(3)* %3038, align 4, !tbaa !6
  %3040 = fmul contract float %3037, %3039
  %3041 = fsub contract float %3036, %3040
  store float %3041, float addrspace(3)* %2970, align 4, !tbaa !6
  %3042 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 14), align 8, !tbaa !6
  %3043 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %3044 = load float, float addrspace(3)* %3043, align 4, !tbaa !6
  %3045 = fmul contract float %3042, %3044
  %3046 = fsub contract float %3041, %3045
  store float %3046, float addrspace(3)* %2970, align 4, !tbaa !6
  %3047 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 15), align 4, !tbaa !6
  %3048 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %3049 = load float, float addrspace(3)* %3048, align 4, !tbaa !6
  %3050 = fmul contract float %3047, %3049
  %3051 = fsub contract float %3046, %3050
  store float %3051, float addrspace(3)* %2970, align 4, !tbaa !6
  %3052 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 16), align 16, !tbaa !6
  %3053 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %3054 = load float, float addrspace(3)* %3053, align 4, !tbaa !6
  %3055 = fmul contract float %3052, %3054
  %3056 = fsub contract float %3051, %3055
  store float %3056, float addrspace(3)* %2970, align 4, !tbaa !6
  %3057 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 17), align 4, !tbaa !6
  %3058 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %3059 = load float, float addrspace(3)* %3058, align 4, !tbaa !6
  %3060 = fmul contract float %3057, %3059
  %3061 = fsub contract float %3056, %3060
  store float %3061, float addrspace(3)* %2970, align 4, !tbaa !6
  %3062 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 18), align 8, !tbaa !6
  %3063 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  %3064 = load float, float addrspace(3)* %3063, align 4, !tbaa !6
  %3065 = fmul contract float %3062, %3064
  %3066 = fsub contract float %3061, %3065
  store float %3066, float addrspace(3)* %2970, align 4, !tbaa !6
  %3067 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 19), align 4, !tbaa !6
  %3068 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 19, i32 %4
  %3069 = load float, float addrspace(3)* %3068, align 4, !tbaa !6
  %3070 = fmul contract float %3067, %3069
  %3071 = fsub contract float %3066, %3070
  store float %3071, float addrspace(3)* %2970, align 4, !tbaa !6
  %3072 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 20), align 16, !tbaa !6
  %3073 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 20, i32 %4
  %3074 = load float, float addrspace(3)* %3073, align 4, !tbaa !6
  %3075 = fmul contract float %3072, %3074
  %3076 = fsub contract float %3071, %3075
  store float %3076, float addrspace(3)* %2970, align 4, !tbaa !6
  %3077 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 21), align 4, !tbaa !6
  %3078 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 21, i32 %4
  %3079 = load float, float addrspace(3)* %3078, align 4, !tbaa !6
  %3080 = fmul contract float %3077, %3079
  %3081 = fsub contract float %3076, %3080
  store float %3081, float addrspace(3)* %2970, align 4, !tbaa !6
  %3082 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 22), align 8, !tbaa !6
  %3083 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 22, i32 %4
  %3084 = load float, float addrspace(3)* %3083, align 4, !tbaa !6
  %3085 = fmul contract float %3082, %3084
  %3086 = fsub contract float %3081, %3085
  store float %3086, float addrspace(3)* %2970, align 4, !tbaa !6
  %3087 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 23), align 4, !tbaa !6
  %3088 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 23, i32 %4
  %3089 = load float, float addrspace(3)* %3088, align 4, !tbaa !6
  %3090 = fmul contract float %3087, %3089
  %3091 = fsub contract float %3086, %3090
  store float %3091, float addrspace(3)* %2970, align 4, !tbaa !6
  %3092 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 24), align 16, !tbaa !6
  %3093 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 24, i32 %4
  %3094 = load float, float addrspace(3)* %3093, align 4, !tbaa !6
  %3095 = fmul contract float %3092, %3094
  %3096 = fsub contract float %3091, %3095
  store float %3096, float addrspace(3)* %2970, align 4, !tbaa !6
  %3097 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 25), align 4, !tbaa !6
  %3098 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 25, i32 %4
  %3099 = load float, float addrspace(3)* %3098, align 4, !tbaa !6
  %3100 = fmul contract float %3097, %3099
  %3101 = fsub contract float %3096, %3100
  store float %3101, float addrspace(3)* %2970, align 4, !tbaa !6
  %3102 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 26), align 8, !tbaa !6
  %3103 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 26, i32 %4
  %3104 = load float, float addrspace(3)* %3103, align 4, !tbaa !6
  %3105 = fmul contract float %3102, %3104
  %3106 = fsub contract float %3101, %3105
  store float %3106, float addrspace(3)* %2970, align 4, !tbaa !6
  %3107 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 27), align 4, !tbaa !6
  %3108 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 27, i32 %4
  %3109 = load float, float addrspace(3)* %3108, align 4, !tbaa !6
  %3110 = fmul contract float %3107, %3109
  %3111 = fsub contract float %3106, %3110
  store float %3111, float addrspace(3)* %2970, align 4, !tbaa !6
  %3112 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 28), align 16, !tbaa !6
  %3113 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 28, i32 %4
  %3114 = load float, float addrspace(3)* %3113, align 4, !tbaa !6
  %3115 = fmul contract float %3112, %3114
  %3116 = fsub contract float %3111, %3115
  store float %3116, float addrspace(3)* %2970, align 4, !tbaa !6
  %3117 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 29), align 4, !tbaa !6
  %3118 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 29, i32 %4
  %3119 = load float, float addrspace(3)* %3118, align 4, !tbaa !6
  %3120 = fmul contract float %3117, %3119
  %3121 = fsub contract float %3116, %3120
  store float %3121, float addrspace(3)* %2970, align 4, !tbaa !6
  %3122 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 30), align 8, !tbaa !6
  %3123 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 30, i32 %4
  %3124 = load float, float addrspace(3)* %3123, align 4, !tbaa !6
  %3125 = fmul contract float %3122, %3124
  %3126 = fsub contract float %3121, %3125
  store float %3126, float addrspace(3)* %2970, align 4, !tbaa !6
  br label %5707

3127:                                             ; preds = %579
  %3128 = add nsw i32 %4, -32
  %3129 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 0
  %3130 = load float, float addrspace(3)* %3129, align 16, !tbaa !6
  %3131 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 0), align 16, !tbaa !6
  %3132 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 0
  %3133 = fdiv contract float %3130, %3131
  store float %3133, float addrspace(3)* %3132, align 16, !tbaa !6
  %3134 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3135 = load float, float addrspace(3)* %3134, align 4, !tbaa !6
  %3136 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 1), align 4, !tbaa !6
  %3137 = fmul contract float %3133, %3136
  %3138 = fsub contract float %3135, %3137
  store float %3138, float addrspace(3)* %3134, align 4, !tbaa !6
  %3139 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 1), align 4, !tbaa !6
  %3140 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3141 = fdiv contract float %3138, %3139
  store float %3141, float addrspace(3)* %3140, align 4, !tbaa !6
  %3142 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3143 = load float, float addrspace(3)* %3142, align 8, !tbaa !6
  %3144 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 2), align 8, !tbaa !6
  %3145 = fmul contract float %3133, %3144
  %3146 = fsub contract float %3143, %3145
  store float %3146, float addrspace(3)* %3142, align 8, !tbaa !6
  %3147 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3148 = load float, float addrspace(3)* %3147, align 4, !tbaa !6
  %3149 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 2), align 8, !tbaa !6
  %3150 = fmul contract float %3148, %3149
  %3151 = fsub contract float %3146, %3150
  store float %3151, float addrspace(3)* %3142, align 8, !tbaa !6
  %3152 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 2), align 8, !tbaa !6
  %3153 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3154 = fdiv contract float %3151, %3152
  store float %3154, float addrspace(3)* %3153, align 8, !tbaa !6
  %3155 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3156 = load float, float addrspace(3)* %3155, align 4, !tbaa !6
  %3157 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 3), align 4, !tbaa !6
  %3158 = fmul contract float %3133, %3157
  %3159 = fsub contract float %3156, %3158
  store float %3159, float addrspace(3)* %3155, align 4, !tbaa !6
  %3160 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3161 = load float, float addrspace(3)* %3160, align 4, !tbaa !6
  %3162 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 3), align 4, !tbaa !6
  %3163 = fmul contract float %3161, %3162
  %3164 = fsub contract float %3159, %3163
  store float %3164, float addrspace(3)* %3155, align 4, !tbaa !6
  %3165 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3166 = load float, float addrspace(3)* %3165, align 8, !tbaa !6
  %3167 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 3), align 4, !tbaa !6
  %3168 = fmul contract float %3166, %3167
  %3169 = fsub contract float %3164, %3168
  store float %3169, float addrspace(3)* %3155, align 4, !tbaa !6
  %3170 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 3), align 4, !tbaa !6
  %3171 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3172 = fdiv contract float %3169, %3170
  store float %3172, float addrspace(3)* %3171, align 4, !tbaa !6
  %3173 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3174 = load float, float addrspace(3)* %3173, align 16, !tbaa !6
  %3175 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 4), align 16, !tbaa !6
  %3176 = fmul contract float %3133, %3175
  %3177 = fsub contract float %3174, %3176
  store float %3177, float addrspace(3)* %3173, align 16, !tbaa !6
  %3178 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3179 = load float, float addrspace(3)* %3178, align 4, !tbaa !6
  %3180 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 4), align 16, !tbaa !6
  %3181 = fmul contract float %3179, %3180
  %3182 = fsub contract float %3177, %3181
  store float %3182, float addrspace(3)* %3173, align 16, !tbaa !6
  %3183 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3184 = load float, float addrspace(3)* %3183, align 8, !tbaa !6
  %3185 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 4), align 16, !tbaa !6
  %3186 = fmul contract float %3184, %3185
  %3187 = fsub contract float %3182, %3186
  store float %3187, float addrspace(3)* %3173, align 16, !tbaa !6
  %3188 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3189 = load float, float addrspace(3)* %3188, align 4, !tbaa !6
  %3190 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 4), align 16, !tbaa !6
  %3191 = fmul contract float %3189, %3190
  %3192 = fsub contract float %3187, %3191
  store float %3192, float addrspace(3)* %3173, align 16, !tbaa !6
  %3193 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 4), align 16, !tbaa !6
  %3194 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3195 = fdiv contract float %3192, %3193
  store float %3195, float addrspace(3)* %3194, align 16, !tbaa !6
  %3196 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %3197 = load float, float addrspace(3)* %3196, align 4, !tbaa !6
  %3198 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 5), align 4, !tbaa !6
  %3199 = fmul contract float %3133, %3198
  %3200 = fsub contract float %3197, %3199
  store float %3200, float addrspace(3)* %3196, align 4, !tbaa !6
  %3201 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3202 = load float, float addrspace(3)* %3201, align 4, !tbaa !6
  %3203 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 5), align 4, !tbaa !6
  %3204 = fmul contract float %3202, %3203
  %3205 = fsub contract float %3200, %3204
  store float %3205, float addrspace(3)* %3196, align 4, !tbaa !6
  %3206 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3207 = load float, float addrspace(3)* %3206, align 8, !tbaa !6
  %3208 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 5), align 4, !tbaa !6
  %3209 = fmul contract float %3207, %3208
  %3210 = fsub contract float %3205, %3209
  store float %3210, float addrspace(3)* %3196, align 4, !tbaa !6
  %3211 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3212 = load float, float addrspace(3)* %3211, align 4, !tbaa !6
  %3213 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 5), align 4, !tbaa !6
  %3214 = fmul contract float %3212, %3213
  %3215 = fsub contract float %3210, %3214
  store float %3215, float addrspace(3)* %3196, align 4, !tbaa !6
  %3216 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3217 = load float, float addrspace(3)* %3216, align 16, !tbaa !6
  %3218 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 5), align 4, !tbaa !6
  %3219 = fmul contract float %3217, %3218
  %3220 = fsub contract float %3215, %3219
  store float %3220, float addrspace(3)* %3196, align 4, !tbaa !6
  %3221 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 5), align 4, !tbaa !6
  %3222 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %3223 = fdiv contract float %3220, %3221
  store float %3223, float addrspace(3)* %3222, align 4, !tbaa !6
  %3224 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %3225 = load float, float addrspace(3)* %3224, align 8, !tbaa !6
  %3226 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 6), align 8, !tbaa !6
  %3227 = fmul contract float %3133, %3226
  %3228 = fsub contract float %3225, %3227
  store float %3228, float addrspace(3)* %3224, align 8, !tbaa !6
  %3229 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3230 = load float, float addrspace(3)* %3229, align 4, !tbaa !6
  %3231 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 6), align 8, !tbaa !6
  %3232 = fmul contract float %3230, %3231
  %3233 = fsub contract float %3228, %3232
  store float %3233, float addrspace(3)* %3224, align 8, !tbaa !6
  %3234 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3235 = load float, float addrspace(3)* %3234, align 8, !tbaa !6
  %3236 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 6), align 8, !tbaa !6
  %3237 = fmul contract float %3235, %3236
  %3238 = fsub contract float %3233, %3237
  store float %3238, float addrspace(3)* %3224, align 8, !tbaa !6
  %3239 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3240 = load float, float addrspace(3)* %3239, align 4, !tbaa !6
  %3241 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 6), align 8, !tbaa !6
  %3242 = fmul contract float %3240, %3241
  %3243 = fsub contract float %3238, %3242
  store float %3243, float addrspace(3)* %3224, align 8, !tbaa !6
  %3244 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3245 = load float, float addrspace(3)* %3244, align 16, !tbaa !6
  %3246 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 6), align 8, !tbaa !6
  %3247 = fmul contract float %3245, %3246
  %3248 = fsub contract float %3243, %3247
  store float %3248, float addrspace(3)* %3224, align 8, !tbaa !6
  %3249 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %3250 = load float, float addrspace(3)* %3249, align 4, !tbaa !6
  %3251 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 6), align 8, !tbaa !6
  %3252 = fmul contract float %3250, %3251
  %3253 = fsub contract float %3248, %3252
  store float %3253, float addrspace(3)* %3224, align 8, !tbaa !6
  %3254 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 6), align 8, !tbaa !6
  %3255 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %3256 = fdiv contract float %3253, %3254
  store float %3256, float addrspace(3)* %3255, align 8, !tbaa !6
  %3257 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %3258 = load float, float addrspace(3)* %3257, align 4, !tbaa !6
  %3259 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 7), align 4, !tbaa !6
  %3260 = fmul contract float %3133, %3259
  %3261 = fsub contract float %3258, %3260
  store float %3261, float addrspace(3)* %3257, align 4, !tbaa !6
  %3262 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3263 = load float, float addrspace(3)* %3262, align 4, !tbaa !6
  %3264 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 7), align 4, !tbaa !6
  %3265 = fmul contract float %3263, %3264
  %3266 = fsub contract float %3261, %3265
  store float %3266, float addrspace(3)* %3257, align 4, !tbaa !6
  %3267 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3268 = load float, float addrspace(3)* %3267, align 8, !tbaa !6
  %3269 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 7), align 4, !tbaa !6
  %3270 = fmul contract float %3268, %3269
  %3271 = fsub contract float %3266, %3270
  store float %3271, float addrspace(3)* %3257, align 4, !tbaa !6
  %3272 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3273 = load float, float addrspace(3)* %3272, align 4, !tbaa !6
  %3274 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 7), align 4, !tbaa !6
  %3275 = fmul contract float %3273, %3274
  %3276 = fsub contract float %3271, %3275
  store float %3276, float addrspace(3)* %3257, align 4, !tbaa !6
  %3277 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3278 = load float, float addrspace(3)* %3277, align 16, !tbaa !6
  %3279 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 7), align 4, !tbaa !6
  %3280 = fmul contract float %3278, %3279
  %3281 = fsub contract float %3276, %3280
  store float %3281, float addrspace(3)* %3257, align 4, !tbaa !6
  %3282 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %3283 = load float, float addrspace(3)* %3282, align 4, !tbaa !6
  %3284 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 7), align 4, !tbaa !6
  %3285 = fmul contract float %3283, %3284
  %3286 = fsub contract float %3281, %3285
  store float %3286, float addrspace(3)* %3257, align 4, !tbaa !6
  %3287 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %3288 = load float, float addrspace(3)* %3287, align 8, !tbaa !6
  %3289 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 7), align 4, !tbaa !6
  %3290 = fmul contract float %3288, %3289
  %3291 = fsub contract float %3286, %3290
  store float %3291, float addrspace(3)* %3257, align 4, !tbaa !6
  %3292 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 7), align 4, !tbaa !6
  %3293 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %3294 = fdiv contract float %3291, %3292
  store float %3294, float addrspace(3)* %3293, align 4, !tbaa !6
  %3295 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %3296 = load float, float addrspace(3)* %3295, align 16, !tbaa !6
  %3297 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 8), align 16, !tbaa !6
  %3298 = fmul contract float %3133, %3297
  %3299 = fsub contract float %3296, %3298
  store float %3299, float addrspace(3)* %3295, align 16, !tbaa !6
  %3300 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3301 = load float, float addrspace(3)* %3300, align 4, !tbaa !6
  %3302 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 8), align 16, !tbaa !6
  %3303 = fmul contract float %3301, %3302
  %3304 = fsub contract float %3299, %3303
  store float %3304, float addrspace(3)* %3295, align 16, !tbaa !6
  %3305 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3306 = load float, float addrspace(3)* %3305, align 8, !tbaa !6
  %3307 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 8), align 16, !tbaa !6
  %3308 = fmul contract float %3306, %3307
  %3309 = fsub contract float %3304, %3308
  store float %3309, float addrspace(3)* %3295, align 16, !tbaa !6
  %3310 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3311 = load float, float addrspace(3)* %3310, align 4, !tbaa !6
  %3312 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 8), align 16, !tbaa !6
  %3313 = fmul contract float %3311, %3312
  %3314 = fsub contract float %3309, %3313
  store float %3314, float addrspace(3)* %3295, align 16, !tbaa !6
  %3315 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3316 = load float, float addrspace(3)* %3315, align 16, !tbaa !6
  %3317 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 8), align 16, !tbaa !6
  %3318 = fmul contract float %3316, %3317
  %3319 = fsub contract float %3314, %3318
  store float %3319, float addrspace(3)* %3295, align 16, !tbaa !6
  %3320 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %3321 = load float, float addrspace(3)* %3320, align 4, !tbaa !6
  %3322 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 8), align 16, !tbaa !6
  %3323 = fmul contract float %3321, %3322
  %3324 = fsub contract float %3319, %3323
  store float %3324, float addrspace(3)* %3295, align 16, !tbaa !6
  %3325 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %3326 = load float, float addrspace(3)* %3325, align 8, !tbaa !6
  %3327 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 8), align 16, !tbaa !6
  %3328 = fmul contract float %3326, %3327
  %3329 = fsub contract float %3324, %3328
  store float %3329, float addrspace(3)* %3295, align 16, !tbaa !6
  %3330 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %3331 = load float, float addrspace(3)* %3330, align 4, !tbaa !6
  %3332 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 8), align 16, !tbaa !6
  %3333 = fmul contract float %3331, %3332
  %3334 = fsub contract float %3329, %3333
  store float %3334, float addrspace(3)* %3295, align 16, !tbaa !6
  %3335 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 8), align 16, !tbaa !6
  %3336 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %3337 = fdiv contract float %3334, %3335
  store float %3337, float addrspace(3)* %3336, align 16, !tbaa !6
  %3338 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %3339 = load float, float addrspace(3)* %3338, align 4, !tbaa !6
  %3340 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 9), align 4, !tbaa !6
  %3341 = fmul contract float %3133, %3340
  %3342 = fsub contract float %3339, %3341
  store float %3342, float addrspace(3)* %3338, align 4, !tbaa !6
  %3343 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3344 = load float, float addrspace(3)* %3343, align 4, !tbaa !6
  %3345 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 9), align 4, !tbaa !6
  %3346 = fmul contract float %3344, %3345
  %3347 = fsub contract float %3342, %3346
  store float %3347, float addrspace(3)* %3338, align 4, !tbaa !6
  %3348 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3349 = load float, float addrspace(3)* %3348, align 8, !tbaa !6
  %3350 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 9), align 4, !tbaa !6
  %3351 = fmul contract float %3349, %3350
  %3352 = fsub contract float %3347, %3351
  store float %3352, float addrspace(3)* %3338, align 4, !tbaa !6
  %3353 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3354 = load float, float addrspace(3)* %3353, align 4, !tbaa !6
  %3355 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 9), align 4, !tbaa !6
  %3356 = fmul contract float %3354, %3355
  %3357 = fsub contract float %3352, %3356
  store float %3357, float addrspace(3)* %3338, align 4, !tbaa !6
  %3358 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3359 = load float, float addrspace(3)* %3358, align 16, !tbaa !6
  %3360 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 9), align 4, !tbaa !6
  %3361 = fmul contract float %3359, %3360
  %3362 = fsub contract float %3357, %3361
  store float %3362, float addrspace(3)* %3338, align 4, !tbaa !6
  %3363 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %3364 = load float, float addrspace(3)* %3363, align 4, !tbaa !6
  %3365 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 9), align 4, !tbaa !6
  %3366 = fmul contract float %3364, %3365
  %3367 = fsub contract float %3362, %3366
  store float %3367, float addrspace(3)* %3338, align 4, !tbaa !6
  %3368 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %3369 = load float, float addrspace(3)* %3368, align 8, !tbaa !6
  %3370 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 9), align 4, !tbaa !6
  %3371 = fmul contract float %3369, %3370
  %3372 = fsub contract float %3367, %3371
  store float %3372, float addrspace(3)* %3338, align 4, !tbaa !6
  %3373 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %3374 = load float, float addrspace(3)* %3373, align 4, !tbaa !6
  %3375 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 9), align 4, !tbaa !6
  %3376 = fmul contract float %3374, %3375
  %3377 = fsub contract float %3372, %3376
  store float %3377, float addrspace(3)* %3338, align 4, !tbaa !6
  %3378 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %3379 = load float, float addrspace(3)* %3378, align 16, !tbaa !6
  %3380 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 9), align 4, !tbaa !6
  %3381 = fmul contract float %3379, %3380
  %3382 = fsub contract float %3377, %3381
  store float %3382, float addrspace(3)* %3338, align 4, !tbaa !6
  %3383 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 9), align 4, !tbaa !6
  %3384 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %3385 = fdiv contract float %3382, %3383
  store float %3385, float addrspace(3)* %3384, align 4, !tbaa !6
  %3386 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %3387 = load float, float addrspace(3)* %3386, align 8, !tbaa !6
  %3388 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 10), align 8, !tbaa !6
  %3389 = fmul contract float %3133, %3388
  %3390 = fsub contract float %3387, %3389
  store float %3390, float addrspace(3)* %3386, align 8, !tbaa !6
  %3391 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3392 = load float, float addrspace(3)* %3391, align 4, !tbaa !6
  %3393 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 10), align 8, !tbaa !6
  %3394 = fmul contract float %3392, %3393
  %3395 = fsub contract float %3390, %3394
  store float %3395, float addrspace(3)* %3386, align 8, !tbaa !6
  %3396 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3397 = load float, float addrspace(3)* %3396, align 8, !tbaa !6
  %3398 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 10), align 8, !tbaa !6
  %3399 = fmul contract float %3397, %3398
  %3400 = fsub contract float %3395, %3399
  store float %3400, float addrspace(3)* %3386, align 8, !tbaa !6
  %3401 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3402 = load float, float addrspace(3)* %3401, align 4, !tbaa !6
  %3403 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 10), align 8, !tbaa !6
  %3404 = fmul contract float %3402, %3403
  %3405 = fsub contract float %3400, %3404
  store float %3405, float addrspace(3)* %3386, align 8, !tbaa !6
  %3406 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3407 = load float, float addrspace(3)* %3406, align 16, !tbaa !6
  %3408 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 10), align 8, !tbaa !6
  %3409 = fmul contract float %3407, %3408
  %3410 = fsub contract float %3405, %3409
  store float %3410, float addrspace(3)* %3386, align 8, !tbaa !6
  %3411 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %3412 = load float, float addrspace(3)* %3411, align 4, !tbaa !6
  %3413 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 10), align 8, !tbaa !6
  %3414 = fmul contract float %3412, %3413
  %3415 = fsub contract float %3410, %3414
  store float %3415, float addrspace(3)* %3386, align 8, !tbaa !6
  %3416 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %3417 = load float, float addrspace(3)* %3416, align 8, !tbaa !6
  %3418 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 10), align 8, !tbaa !6
  %3419 = fmul contract float %3417, %3418
  %3420 = fsub contract float %3415, %3419
  store float %3420, float addrspace(3)* %3386, align 8, !tbaa !6
  %3421 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %3422 = load float, float addrspace(3)* %3421, align 4, !tbaa !6
  %3423 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 10), align 8, !tbaa !6
  %3424 = fmul contract float %3422, %3423
  %3425 = fsub contract float %3420, %3424
  store float %3425, float addrspace(3)* %3386, align 8, !tbaa !6
  %3426 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %3427 = load float, float addrspace(3)* %3426, align 16, !tbaa !6
  %3428 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 10), align 8, !tbaa !6
  %3429 = fmul contract float %3427, %3428
  %3430 = fsub contract float %3425, %3429
  store float %3430, float addrspace(3)* %3386, align 8, !tbaa !6
  %3431 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %3432 = load float, float addrspace(3)* %3431, align 4, !tbaa !6
  %3433 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 10), align 8, !tbaa !6
  %3434 = fmul contract float %3432, %3433
  %3435 = fsub contract float %3430, %3434
  store float %3435, float addrspace(3)* %3386, align 8, !tbaa !6
  %3436 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 10), align 8, !tbaa !6
  %3437 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %3438 = fdiv contract float %3435, %3436
  store float %3438, float addrspace(3)* %3437, align 8, !tbaa !6
  %3439 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %3440 = load float, float addrspace(3)* %3439, align 4, !tbaa !6
  %3441 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 11), align 4, !tbaa !6
  %3442 = fmul contract float %3133, %3441
  %3443 = fsub contract float %3440, %3442
  store float %3443, float addrspace(3)* %3439, align 4, !tbaa !6
  %3444 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3445 = load float, float addrspace(3)* %3444, align 4, !tbaa !6
  %3446 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 11), align 4, !tbaa !6
  %3447 = fmul contract float %3445, %3446
  %3448 = fsub contract float %3443, %3447
  store float %3448, float addrspace(3)* %3439, align 4, !tbaa !6
  %3449 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3450 = load float, float addrspace(3)* %3449, align 8, !tbaa !6
  %3451 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 11), align 4, !tbaa !6
  %3452 = fmul contract float %3450, %3451
  %3453 = fsub contract float %3448, %3452
  store float %3453, float addrspace(3)* %3439, align 4, !tbaa !6
  %3454 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3455 = load float, float addrspace(3)* %3454, align 4, !tbaa !6
  %3456 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 11), align 4, !tbaa !6
  %3457 = fmul contract float %3455, %3456
  %3458 = fsub contract float %3453, %3457
  store float %3458, float addrspace(3)* %3439, align 4, !tbaa !6
  %3459 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3460 = load float, float addrspace(3)* %3459, align 16, !tbaa !6
  %3461 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 11), align 4, !tbaa !6
  %3462 = fmul contract float %3460, %3461
  %3463 = fsub contract float %3458, %3462
  store float %3463, float addrspace(3)* %3439, align 4, !tbaa !6
  %3464 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %3465 = load float, float addrspace(3)* %3464, align 4, !tbaa !6
  %3466 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 11), align 4, !tbaa !6
  %3467 = fmul contract float %3465, %3466
  %3468 = fsub contract float %3463, %3467
  store float %3468, float addrspace(3)* %3439, align 4, !tbaa !6
  %3469 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %3470 = load float, float addrspace(3)* %3469, align 8, !tbaa !6
  %3471 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 11), align 4, !tbaa !6
  %3472 = fmul contract float %3470, %3471
  %3473 = fsub contract float %3468, %3472
  store float %3473, float addrspace(3)* %3439, align 4, !tbaa !6
  %3474 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %3475 = load float, float addrspace(3)* %3474, align 4, !tbaa !6
  %3476 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 11), align 4, !tbaa !6
  %3477 = fmul contract float %3475, %3476
  %3478 = fsub contract float %3473, %3477
  store float %3478, float addrspace(3)* %3439, align 4, !tbaa !6
  %3479 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %3480 = load float, float addrspace(3)* %3479, align 16, !tbaa !6
  %3481 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 11), align 4, !tbaa !6
  %3482 = fmul contract float %3480, %3481
  %3483 = fsub contract float %3478, %3482
  store float %3483, float addrspace(3)* %3439, align 4, !tbaa !6
  %3484 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %3485 = load float, float addrspace(3)* %3484, align 4, !tbaa !6
  %3486 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 11), align 4, !tbaa !6
  %3487 = fmul contract float %3485, %3486
  %3488 = fsub contract float %3483, %3487
  store float %3488, float addrspace(3)* %3439, align 4, !tbaa !6
  %3489 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %3490 = load float, float addrspace(3)* %3489, align 8, !tbaa !6
  %3491 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 11), align 4, !tbaa !6
  %3492 = fmul contract float %3490, %3491
  %3493 = fsub contract float %3488, %3492
  store float %3493, float addrspace(3)* %3439, align 4, !tbaa !6
  %3494 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 11), align 4, !tbaa !6
  %3495 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %3496 = fdiv contract float %3493, %3494
  store float %3496, float addrspace(3)* %3495, align 4, !tbaa !6
  %3497 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %3498 = load float, float addrspace(3)* %3497, align 16, !tbaa !6
  %3499 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 12), align 16, !tbaa !6
  %3500 = fmul contract float %3133, %3499
  %3501 = fsub contract float %3498, %3500
  store float %3501, float addrspace(3)* %3497, align 16, !tbaa !6
  %3502 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3503 = load float, float addrspace(3)* %3502, align 4, !tbaa !6
  %3504 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 12), align 16, !tbaa !6
  %3505 = fmul contract float %3503, %3504
  %3506 = fsub contract float %3501, %3505
  store float %3506, float addrspace(3)* %3497, align 16, !tbaa !6
  %3507 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3508 = load float, float addrspace(3)* %3507, align 8, !tbaa !6
  %3509 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 12), align 16, !tbaa !6
  %3510 = fmul contract float %3508, %3509
  %3511 = fsub contract float %3506, %3510
  store float %3511, float addrspace(3)* %3497, align 16, !tbaa !6
  %3512 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3513 = load float, float addrspace(3)* %3512, align 4, !tbaa !6
  %3514 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 12), align 16, !tbaa !6
  %3515 = fmul contract float %3513, %3514
  %3516 = fsub contract float %3511, %3515
  store float %3516, float addrspace(3)* %3497, align 16, !tbaa !6
  %3517 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3518 = load float, float addrspace(3)* %3517, align 16, !tbaa !6
  %3519 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 12), align 16, !tbaa !6
  %3520 = fmul contract float %3518, %3519
  %3521 = fsub contract float %3516, %3520
  store float %3521, float addrspace(3)* %3497, align 16, !tbaa !6
  %3522 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %3523 = load float, float addrspace(3)* %3522, align 4, !tbaa !6
  %3524 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 12), align 16, !tbaa !6
  %3525 = fmul contract float %3523, %3524
  %3526 = fsub contract float %3521, %3525
  store float %3526, float addrspace(3)* %3497, align 16, !tbaa !6
  %3527 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %3528 = load float, float addrspace(3)* %3527, align 8, !tbaa !6
  %3529 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 12), align 16, !tbaa !6
  %3530 = fmul contract float %3528, %3529
  %3531 = fsub contract float %3526, %3530
  store float %3531, float addrspace(3)* %3497, align 16, !tbaa !6
  %3532 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %3533 = load float, float addrspace(3)* %3532, align 4, !tbaa !6
  %3534 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 12), align 16, !tbaa !6
  %3535 = fmul contract float %3533, %3534
  %3536 = fsub contract float %3531, %3535
  store float %3536, float addrspace(3)* %3497, align 16, !tbaa !6
  %3537 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %3538 = load float, float addrspace(3)* %3537, align 16, !tbaa !6
  %3539 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 12), align 16, !tbaa !6
  %3540 = fmul contract float %3538, %3539
  %3541 = fsub contract float %3536, %3540
  store float %3541, float addrspace(3)* %3497, align 16, !tbaa !6
  %3542 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %3543 = load float, float addrspace(3)* %3542, align 4, !tbaa !6
  %3544 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 12), align 16, !tbaa !6
  %3545 = fmul contract float %3543, %3544
  %3546 = fsub contract float %3541, %3545
  store float %3546, float addrspace(3)* %3497, align 16, !tbaa !6
  %3547 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %3548 = load float, float addrspace(3)* %3547, align 8, !tbaa !6
  %3549 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 12), align 16, !tbaa !6
  %3550 = fmul contract float %3548, %3549
  %3551 = fsub contract float %3546, %3550
  store float %3551, float addrspace(3)* %3497, align 16, !tbaa !6
  %3552 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %3553 = load float, float addrspace(3)* %3552, align 4, !tbaa !6
  %3554 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 12), align 16, !tbaa !6
  %3555 = fmul contract float %3553, %3554
  %3556 = fsub contract float %3551, %3555
  store float %3556, float addrspace(3)* %3497, align 16, !tbaa !6
  %3557 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 12), align 16, !tbaa !6
  %3558 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %3559 = fdiv contract float %3556, %3557
  store float %3559, float addrspace(3)* %3558, align 16, !tbaa !6
  %3560 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %3561 = load float, float addrspace(3)* %3560, align 4, !tbaa !6
  %3562 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 13), align 4, !tbaa !6
  %3563 = fmul contract float %3133, %3562
  %3564 = fsub contract float %3561, %3563
  store float %3564, float addrspace(3)* %3560, align 4, !tbaa !6
  %3565 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3566 = load float, float addrspace(3)* %3565, align 4, !tbaa !6
  %3567 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 13), align 4, !tbaa !6
  %3568 = fmul contract float %3566, %3567
  %3569 = fsub contract float %3564, %3568
  store float %3569, float addrspace(3)* %3560, align 4, !tbaa !6
  %3570 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3571 = load float, float addrspace(3)* %3570, align 8, !tbaa !6
  %3572 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 13), align 4, !tbaa !6
  %3573 = fmul contract float %3571, %3572
  %3574 = fsub contract float %3569, %3573
  store float %3574, float addrspace(3)* %3560, align 4, !tbaa !6
  %3575 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3576 = load float, float addrspace(3)* %3575, align 4, !tbaa !6
  %3577 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 13), align 4, !tbaa !6
  %3578 = fmul contract float %3576, %3577
  %3579 = fsub contract float %3574, %3578
  store float %3579, float addrspace(3)* %3560, align 4, !tbaa !6
  %3580 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3581 = load float, float addrspace(3)* %3580, align 16, !tbaa !6
  %3582 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 13), align 4, !tbaa !6
  %3583 = fmul contract float %3581, %3582
  %3584 = fsub contract float %3579, %3583
  store float %3584, float addrspace(3)* %3560, align 4, !tbaa !6
  %3585 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %3586 = load float, float addrspace(3)* %3585, align 4, !tbaa !6
  %3587 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 13), align 4, !tbaa !6
  %3588 = fmul contract float %3586, %3587
  %3589 = fsub contract float %3584, %3588
  store float %3589, float addrspace(3)* %3560, align 4, !tbaa !6
  %3590 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %3591 = load float, float addrspace(3)* %3590, align 8, !tbaa !6
  %3592 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 13), align 4, !tbaa !6
  %3593 = fmul contract float %3591, %3592
  %3594 = fsub contract float %3589, %3593
  store float %3594, float addrspace(3)* %3560, align 4, !tbaa !6
  %3595 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %3596 = load float, float addrspace(3)* %3595, align 4, !tbaa !6
  %3597 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 13), align 4, !tbaa !6
  %3598 = fmul contract float %3596, %3597
  %3599 = fsub contract float %3594, %3598
  store float %3599, float addrspace(3)* %3560, align 4, !tbaa !6
  %3600 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %3601 = load float, float addrspace(3)* %3600, align 16, !tbaa !6
  %3602 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 13), align 4, !tbaa !6
  %3603 = fmul contract float %3601, %3602
  %3604 = fsub contract float %3599, %3603
  store float %3604, float addrspace(3)* %3560, align 4, !tbaa !6
  %3605 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %3606 = load float, float addrspace(3)* %3605, align 4, !tbaa !6
  %3607 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 13), align 4, !tbaa !6
  %3608 = fmul contract float %3606, %3607
  %3609 = fsub contract float %3604, %3608
  store float %3609, float addrspace(3)* %3560, align 4, !tbaa !6
  %3610 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %3611 = load float, float addrspace(3)* %3610, align 8, !tbaa !6
  %3612 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 13), align 4, !tbaa !6
  %3613 = fmul contract float %3611, %3612
  %3614 = fsub contract float %3609, %3613
  store float %3614, float addrspace(3)* %3560, align 4, !tbaa !6
  %3615 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %3616 = load float, float addrspace(3)* %3615, align 4, !tbaa !6
  %3617 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 13), align 4, !tbaa !6
  %3618 = fmul contract float %3616, %3617
  %3619 = fsub contract float %3614, %3618
  store float %3619, float addrspace(3)* %3560, align 4, !tbaa !6
  %3620 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %3621 = load float, float addrspace(3)* %3620, align 16, !tbaa !6
  %3622 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 13), align 4, !tbaa !6
  %3623 = fmul contract float %3621, %3622
  %3624 = fsub contract float %3619, %3623
  store float %3624, float addrspace(3)* %3560, align 4, !tbaa !6
  %3625 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 13), align 4, !tbaa !6
  %3626 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %3627 = fdiv contract float %3624, %3625
  store float %3627, float addrspace(3)* %3626, align 4, !tbaa !6
  %3628 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %3629 = load float, float addrspace(3)* %3628, align 8, !tbaa !6
  %3630 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 14), align 8, !tbaa !6
  %3631 = fmul contract float %3133, %3630
  %3632 = fsub contract float %3629, %3631
  store float %3632, float addrspace(3)* %3628, align 8, !tbaa !6
  %3633 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3634 = load float, float addrspace(3)* %3633, align 4, !tbaa !6
  %3635 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 14), align 8, !tbaa !6
  %3636 = fmul contract float %3634, %3635
  %3637 = fsub contract float %3632, %3636
  store float %3637, float addrspace(3)* %3628, align 8, !tbaa !6
  %3638 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3639 = load float, float addrspace(3)* %3638, align 8, !tbaa !6
  %3640 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 14), align 8, !tbaa !6
  %3641 = fmul contract float %3639, %3640
  %3642 = fsub contract float %3637, %3641
  store float %3642, float addrspace(3)* %3628, align 8, !tbaa !6
  %3643 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3644 = load float, float addrspace(3)* %3643, align 4, !tbaa !6
  %3645 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 14), align 8, !tbaa !6
  %3646 = fmul contract float %3644, %3645
  %3647 = fsub contract float %3642, %3646
  store float %3647, float addrspace(3)* %3628, align 8, !tbaa !6
  %3648 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3649 = load float, float addrspace(3)* %3648, align 16, !tbaa !6
  %3650 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 14), align 8, !tbaa !6
  %3651 = fmul contract float %3649, %3650
  %3652 = fsub contract float %3647, %3651
  store float %3652, float addrspace(3)* %3628, align 8, !tbaa !6
  %3653 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %3654 = load float, float addrspace(3)* %3653, align 4, !tbaa !6
  %3655 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 14), align 8, !tbaa !6
  %3656 = fmul contract float %3654, %3655
  %3657 = fsub contract float %3652, %3656
  store float %3657, float addrspace(3)* %3628, align 8, !tbaa !6
  %3658 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %3659 = load float, float addrspace(3)* %3658, align 8, !tbaa !6
  %3660 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 14), align 8, !tbaa !6
  %3661 = fmul contract float %3659, %3660
  %3662 = fsub contract float %3657, %3661
  store float %3662, float addrspace(3)* %3628, align 8, !tbaa !6
  %3663 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %3664 = load float, float addrspace(3)* %3663, align 4, !tbaa !6
  %3665 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 14), align 8, !tbaa !6
  %3666 = fmul contract float %3664, %3665
  %3667 = fsub contract float %3662, %3666
  store float %3667, float addrspace(3)* %3628, align 8, !tbaa !6
  %3668 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %3669 = load float, float addrspace(3)* %3668, align 16, !tbaa !6
  %3670 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 14), align 8, !tbaa !6
  %3671 = fmul contract float %3669, %3670
  %3672 = fsub contract float %3667, %3671
  store float %3672, float addrspace(3)* %3628, align 8, !tbaa !6
  %3673 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %3674 = load float, float addrspace(3)* %3673, align 4, !tbaa !6
  %3675 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 14), align 8, !tbaa !6
  %3676 = fmul contract float %3674, %3675
  %3677 = fsub contract float %3672, %3676
  store float %3677, float addrspace(3)* %3628, align 8, !tbaa !6
  %3678 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %3679 = load float, float addrspace(3)* %3678, align 8, !tbaa !6
  %3680 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 14), align 8, !tbaa !6
  %3681 = fmul contract float %3679, %3680
  %3682 = fsub contract float %3677, %3681
  store float %3682, float addrspace(3)* %3628, align 8, !tbaa !6
  %3683 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %3684 = load float, float addrspace(3)* %3683, align 4, !tbaa !6
  %3685 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 14), align 8, !tbaa !6
  %3686 = fmul contract float %3684, %3685
  %3687 = fsub contract float %3682, %3686
  store float %3687, float addrspace(3)* %3628, align 8, !tbaa !6
  %3688 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %3689 = load float, float addrspace(3)* %3688, align 16, !tbaa !6
  %3690 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 14), align 8, !tbaa !6
  %3691 = fmul contract float %3689, %3690
  %3692 = fsub contract float %3687, %3691
  store float %3692, float addrspace(3)* %3628, align 8, !tbaa !6
  %3693 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %3694 = load float, float addrspace(3)* %3693, align 4, !tbaa !6
  %3695 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 14), align 8, !tbaa !6
  %3696 = fmul contract float %3694, %3695
  %3697 = fsub contract float %3692, %3696
  store float %3697, float addrspace(3)* %3628, align 8, !tbaa !6
  %3698 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 14), align 8, !tbaa !6
  %3699 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %3700 = fdiv contract float %3697, %3698
  store float %3700, float addrspace(3)* %3699, align 8, !tbaa !6
  %3701 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %3702 = load float, float addrspace(3)* %3701, align 4, !tbaa !6
  %3703 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 15), align 4, !tbaa !6
  %3704 = fmul contract float %3133, %3703
  %3705 = fsub contract float %3702, %3704
  store float %3705, float addrspace(3)* %3701, align 4, !tbaa !6
  %3706 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3707 = load float, float addrspace(3)* %3706, align 4, !tbaa !6
  %3708 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 15), align 4, !tbaa !6
  %3709 = fmul contract float %3707, %3708
  %3710 = fsub contract float %3705, %3709
  store float %3710, float addrspace(3)* %3701, align 4, !tbaa !6
  %3711 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3712 = load float, float addrspace(3)* %3711, align 8, !tbaa !6
  %3713 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 15), align 4, !tbaa !6
  %3714 = fmul contract float %3712, %3713
  %3715 = fsub contract float %3710, %3714
  store float %3715, float addrspace(3)* %3701, align 4, !tbaa !6
  %3716 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3717 = load float, float addrspace(3)* %3716, align 4, !tbaa !6
  %3718 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 15), align 4, !tbaa !6
  %3719 = fmul contract float %3717, %3718
  %3720 = fsub contract float %3715, %3719
  store float %3720, float addrspace(3)* %3701, align 4, !tbaa !6
  %3721 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3722 = load float, float addrspace(3)* %3721, align 16, !tbaa !6
  %3723 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 15), align 4, !tbaa !6
  %3724 = fmul contract float %3722, %3723
  %3725 = fsub contract float %3720, %3724
  store float %3725, float addrspace(3)* %3701, align 4, !tbaa !6
  %3726 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %3727 = load float, float addrspace(3)* %3726, align 4, !tbaa !6
  %3728 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 15), align 4, !tbaa !6
  %3729 = fmul contract float %3727, %3728
  %3730 = fsub contract float %3725, %3729
  store float %3730, float addrspace(3)* %3701, align 4, !tbaa !6
  %3731 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %3732 = load float, float addrspace(3)* %3731, align 8, !tbaa !6
  %3733 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 15), align 4, !tbaa !6
  %3734 = fmul contract float %3732, %3733
  %3735 = fsub contract float %3730, %3734
  store float %3735, float addrspace(3)* %3701, align 4, !tbaa !6
  %3736 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %3737 = load float, float addrspace(3)* %3736, align 4, !tbaa !6
  %3738 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 15), align 4, !tbaa !6
  %3739 = fmul contract float %3737, %3738
  %3740 = fsub contract float %3735, %3739
  store float %3740, float addrspace(3)* %3701, align 4, !tbaa !6
  %3741 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %3742 = load float, float addrspace(3)* %3741, align 16, !tbaa !6
  %3743 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 15), align 4, !tbaa !6
  %3744 = fmul contract float %3742, %3743
  %3745 = fsub contract float %3740, %3744
  store float %3745, float addrspace(3)* %3701, align 4, !tbaa !6
  %3746 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %3747 = load float, float addrspace(3)* %3746, align 4, !tbaa !6
  %3748 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 15), align 4, !tbaa !6
  %3749 = fmul contract float %3747, %3748
  %3750 = fsub contract float %3745, %3749
  store float %3750, float addrspace(3)* %3701, align 4, !tbaa !6
  %3751 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %3752 = load float, float addrspace(3)* %3751, align 8, !tbaa !6
  %3753 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 15), align 4, !tbaa !6
  %3754 = fmul contract float %3752, %3753
  %3755 = fsub contract float %3750, %3754
  store float %3755, float addrspace(3)* %3701, align 4, !tbaa !6
  %3756 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %3757 = load float, float addrspace(3)* %3756, align 4, !tbaa !6
  %3758 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 15), align 4, !tbaa !6
  %3759 = fmul contract float %3757, %3758
  %3760 = fsub contract float %3755, %3759
  store float %3760, float addrspace(3)* %3701, align 4, !tbaa !6
  %3761 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %3762 = load float, float addrspace(3)* %3761, align 16, !tbaa !6
  %3763 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 15), align 4, !tbaa !6
  %3764 = fmul contract float %3762, %3763
  %3765 = fsub contract float %3760, %3764
  store float %3765, float addrspace(3)* %3701, align 4, !tbaa !6
  %3766 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %3767 = load float, float addrspace(3)* %3766, align 4, !tbaa !6
  %3768 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 15), align 4, !tbaa !6
  %3769 = fmul contract float %3767, %3768
  %3770 = fsub contract float %3765, %3769
  store float %3770, float addrspace(3)* %3701, align 4, !tbaa !6
  %3771 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %3772 = load float, float addrspace(3)* %3771, align 8, !tbaa !6
  %3773 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 15), align 4, !tbaa !6
  %3774 = fmul contract float %3772, %3773
  %3775 = fsub contract float %3770, %3774
  store float %3775, float addrspace(3)* %3701, align 4, !tbaa !6
  %3776 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 15), align 4, !tbaa !6
  %3777 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %3778 = fdiv contract float %3775, %3776
  store float %3778, float addrspace(3)* %3777, align 4, !tbaa !6
  %3779 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %3780 = load float, float addrspace(3)* %3779, align 16, !tbaa !6
  %3781 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 16), align 16, !tbaa !6
  %3782 = fmul contract float %3133, %3781
  %3783 = fsub contract float %3780, %3782
  store float %3783, float addrspace(3)* %3779, align 16, !tbaa !6
  %3784 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3785 = load float, float addrspace(3)* %3784, align 4, !tbaa !6
  %3786 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 16), align 16, !tbaa !6
  %3787 = fmul contract float %3785, %3786
  %3788 = fsub contract float %3783, %3787
  store float %3788, float addrspace(3)* %3779, align 16, !tbaa !6
  %3789 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3790 = load float, float addrspace(3)* %3789, align 8, !tbaa !6
  %3791 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 16), align 16, !tbaa !6
  %3792 = fmul contract float %3790, %3791
  %3793 = fsub contract float %3788, %3792
  store float %3793, float addrspace(3)* %3779, align 16, !tbaa !6
  %3794 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3795 = load float, float addrspace(3)* %3794, align 4, !tbaa !6
  %3796 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 16), align 16, !tbaa !6
  %3797 = fmul contract float %3795, %3796
  %3798 = fsub contract float %3793, %3797
  store float %3798, float addrspace(3)* %3779, align 16, !tbaa !6
  %3799 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3800 = load float, float addrspace(3)* %3799, align 16, !tbaa !6
  %3801 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 16), align 16, !tbaa !6
  %3802 = fmul contract float %3800, %3801
  %3803 = fsub contract float %3798, %3802
  store float %3803, float addrspace(3)* %3779, align 16, !tbaa !6
  %3804 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %3805 = load float, float addrspace(3)* %3804, align 4, !tbaa !6
  %3806 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 16), align 16, !tbaa !6
  %3807 = fmul contract float %3805, %3806
  %3808 = fsub contract float %3803, %3807
  store float %3808, float addrspace(3)* %3779, align 16, !tbaa !6
  %3809 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %3810 = load float, float addrspace(3)* %3809, align 8, !tbaa !6
  %3811 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 16), align 16, !tbaa !6
  %3812 = fmul contract float %3810, %3811
  %3813 = fsub contract float %3808, %3812
  store float %3813, float addrspace(3)* %3779, align 16, !tbaa !6
  %3814 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %3815 = load float, float addrspace(3)* %3814, align 4, !tbaa !6
  %3816 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 16), align 16, !tbaa !6
  %3817 = fmul contract float %3815, %3816
  %3818 = fsub contract float %3813, %3817
  store float %3818, float addrspace(3)* %3779, align 16, !tbaa !6
  %3819 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %3820 = load float, float addrspace(3)* %3819, align 16, !tbaa !6
  %3821 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 16), align 16, !tbaa !6
  %3822 = fmul contract float %3820, %3821
  %3823 = fsub contract float %3818, %3822
  store float %3823, float addrspace(3)* %3779, align 16, !tbaa !6
  %3824 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %3825 = load float, float addrspace(3)* %3824, align 4, !tbaa !6
  %3826 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 16), align 16, !tbaa !6
  %3827 = fmul contract float %3825, %3826
  %3828 = fsub contract float %3823, %3827
  store float %3828, float addrspace(3)* %3779, align 16, !tbaa !6
  %3829 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %3830 = load float, float addrspace(3)* %3829, align 8, !tbaa !6
  %3831 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 16), align 16, !tbaa !6
  %3832 = fmul contract float %3830, %3831
  %3833 = fsub contract float %3828, %3832
  store float %3833, float addrspace(3)* %3779, align 16, !tbaa !6
  %3834 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %3835 = load float, float addrspace(3)* %3834, align 4, !tbaa !6
  %3836 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 16), align 16, !tbaa !6
  %3837 = fmul contract float %3835, %3836
  %3838 = fsub contract float %3833, %3837
  store float %3838, float addrspace(3)* %3779, align 16, !tbaa !6
  %3839 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %3840 = load float, float addrspace(3)* %3839, align 16, !tbaa !6
  %3841 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 16), align 16, !tbaa !6
  %3842 = fmul contract float %3840, %3841
  %3843 = fsub contract float %3838, %3842
  store float %3843, float addrspace(3)* %3779, align 16, !tbaa !6
  %3844 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %3845 = load float, float addrspace(3)* %3844, align 4, !tbaa !6
  %3846 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 16), align 16, !tbaa !6
  %3847 = fmul contract float %3845, %3846
  %3848 = fsub contract float %3843, %3847
  store float %3848, float addrspace(3)* %3779, align 16, !tbaa !6
  %3849 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %3850 = load float, float addrspace(3)* %3849, align 8, !tbaa !6
  %3851 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 16), align 16, !tbaa !6
  %3852 = fmul contract float %3850, %3851
  %3853 = fsub contract float %3848, %3852
  store float %3853, float addrspace(3)* %3779, align 16, !tbaa !6
  %3854 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %3855 = load float, float addrspace(3)* %3854, align 4, !tbaa !6
  %3856 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 16), align 16, !tbaa !6
  %3857 = fmul contract float %3855, %3856
  %3858 = fsub contract float %3853, %3857
  store float %3858, float addrspace(3)* %3779, align 16, !tbaa !6
  %3859 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 16), align 16, !tbaa !6
  %3860 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %3861 = fdiv contract float %3858, %3859
  store float %3861, float addrspace(3)* %3860, align 16, !tbaa !6
  %3862 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %3863 = load float, float addrspace(3)* %3862, align 4, !tbaa !6
  %3864 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 17), align 4, !tbaa !6
  %3865 = fmul contract float %3133, %3864
  %3866 = fsub contract float %3863, %3865
  store float %3866, float addrspace(3)* %3862, align 4, !tbaa !6
  %3867 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3868 = load float, float addrspace(3)* %3867, align 4, !tbaa !6
  %3869 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 17), align 4, !tbaa !6
  %3870 = fmul contract float %3868, %3869
  %3871 = fsub contract float %3866, %3870
  store float %3871, float addrspace(3)* %3862, align 4, !tbaa !6
  %3872 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3873 = load float, float addrspace(3)* %3872, align 8, !tbaa !6
  %3874 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 17), align 4, !tbaa !6
  %3875 = fmul contract float %3873, %3874
  %3876 = fsub contract float %3871, %3875
  store float %3876, float addrspace(3)* %3862, align 4, !tbaa !6
  %3877 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3878 = load float, float addrspace(3)* %3877, align 4, !tbaa !6
  %3879 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 17), align 4, !tbaa !6
  %3880 = fmul contract float %3878, %3879
  %3881 = fsub contract float %3876, %3880
  store float %3881, float addrspace(3)* %3862, align 4, !tbaa !6
  %3882 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3883 = load float, float addrspace(3)* %3882, align 16, !tbaa !6
  %3884 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 17), align 4, !tbaa !6
  %3885 = fmul contract float %3883, %3884
  %3886 = fsub contract float %3881, %3885
  store float %3886, float addrspace(3)* %3862, align 4, !tbaa !6
  %3887 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %3888 = load float, float addrspace(3)* %3887, align 4, !tbaa !6
  %3889 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 17), align 4, !tbaa !6
  %3890 = fmul contract float %3888, %3889
  %3891 = fsub contract float %3886, %3890
  store float %3891, float addrspace(3)* %3862, align 4, !tbaa !6
  %3892 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %3893 = load float, float addrspace(3)* %3892, align 8, !tbaa !6
  %3894 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 17), align 4, !tbaa !6
  %3895 = fmul contract float %3893, %3894
  %3896 = fsub contract float %3891, %3895
  store float %3896, float addrspace(3)* %3862, align 4, !tbaa !6
  %3897 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %3898 = load float, float addrspace(3)* %3897, align 4, !tbaa !6
  %3899 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 17), align 4, !tbaa !6
  %3900 = fmul contract float %3898, %3899
  %3901 = fsub contract float %3896, %3900
  store float %3901, float addrspace(3)* %3862, align 4, !tbaa !6
  %3902 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %3903 = load float, float addrspace(3)* %3902, align 16, !tbaa !6
  %3904 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 17), align 4, !tbaa !6
  %3905 = fmul contract float %3903, %3904
  %3906 = fsub contract float %3901, %3905
  store float %3906, float addrspace(3)* %3862, align 4, !tbaa !6
  %3907 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %3908 = load float, float addrspace(3)* %3907, align 4, !tbaa !6
  %3909 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 17), align 4, !tbaa !6
  %3910 = fmul contract float %3908, %3909
  %3911 = fsub contract float %3906, %3910
  store float %3911, float addrspace(3)* %3862, align 4, !tbaa !6
  %3912 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %3913 = load float, float addrspace(3)* %3912, align 8, !tbaa !6
  %3914 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 17), align 4, !tbaa !6
  %3915 = fmul contract float %3913, %3914
  %3916 = fsub contract float %3911, %3915
  store float %3916, float addrspace(3)* %3862, align 4, !tbaa !6
  %3917 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %3918 = load float, float addrspace(3)* %3917, align 4, !tbaa !6
  %3919 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 17), align 4, !tbaa !6
  %3920 = fmul contract float %3918, %3919
  %3921 = fsub contract float %3916, %3920
  store float %3921, float addrspace(3)* %3862, align 4, !tbaa !6
  %3922 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %3923 = load float, float addrspace(3)* %3922, align 16, !tbaa !6
  %3924 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 17), align 4, !tbaa !6
  %3925 = fmul contract float %3923, %3924
  %3926 = fsub contract float %3921, %3925
  store float %3926, float addrspace(3)* %3862, align 4, !tbaa !6
  %3927 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %3928 = load float, float addrspace(3)* %3927, align 4, !tbaa !6
  %3929 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 17), align 4, !tbaa !6
  %3930 = fmul contract float %3928, %3929
  %3931 = fsub contract float %3926, %3930
  store float %3931, float addrspace(3)* %3862, align 4, !tbaa !6
  %3932 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %3933 = load float, float addrspace(3)* %3932, align 8, !tbaa !6
  %3934 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 17), align 4, !tbaa !6
  %3935 = fmul contract float %3933, %3934
  %3936 = fsub contract float %3931, %3935
  store float %3936, float addrspace(3)* %3862, align 4, !tbaa !6
  %3937 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %3938 = load float, float addrspace(3)* %3937, align 4, !tbaa !6
  %3939 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 17), align 4, !tbaa !6
  %3940 = fmul contract float %3938, %3939
  %3941 = fsub contract float %3936, %3940
  store float %3941, float addrspace(3)* %3862, align 4, !tbaa !6
  %3942 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %3943 = load float, float addrspace(3)* %3942, align 16, !tbaa !6
  %3944 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 17), align 4, !tbaa !6
  %3945 = fmul contract float %3943, %3944
  %3946 = fsub contract float %3941, %3945
  store float %3946, float addrspace(3)* %3862, align 4, !tbaa !6
  %3947 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 17), align 4, !tbaa !6
  %3948 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %3949 = fdiv contract float %3946, %3947
  store float %3949, float addrspace(3)* %3948, align 4, !tbaa !6
  %3950 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 18
  %3951 = load float, float addrspace(3)* %3950, align 8, !tbaa !6
  %3952 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 18), align 8, !tbaa !6
  %3953 = fmul contract float %3133, %3952
  %3954 = fsub contract float %3951, %3953
  store float %3954, float addrspace(3)* %3950, align 8, !tbaa !6
  %3955 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %3956 = load float, float addrspace(3)* %3955, align 4, !tbaa !6
  %3957 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 18), align 8, !tbaa !6
  %3958 = fmul contract float %3956, %3957
  %3959 = fsub contract float %3954, %3958
  store float %3959, float addrspace(3)* %3950, align 8, !tbaa !6
  %3960 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %3961 = load float, float addrspace(3)* %3960, align 8, !tbaa !6
  %3962 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 18), align 8, !tbaa !6
  %3963 = fmul contract float %3961, %3962
  %3964 = fsub contract float %3959, %3963
  store float %3964, float addrspace(3)* %3950, align 8, !tbaa !6
  %3965 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %3966 = load float, float addrspace(3)* %3965, align 4, !tbaa !6
  %3967 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 18), align 8, !tbaa !6
  %3968 = fmul contract float %3966, %3967
  %3969 = fsub contract float %3964, %3968
  store float %3969, float addrspace(3)* %3950, align 8, !tbaa !6
  %3970 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %3971 = load float, float addrspace(3)* %3970, align 16, !tbaa !6
  %3972 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 18), align 8, !tbaa !6
  %3973 = fmul contract float %3971, %3972
  %3974 = fsub contract float %3969, %3973
  store float %3974, float addrspace(3)* %3950, align 8, !tbaa !6
  %3975 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %3976 = load float, float addrspace(3)* %3975, align 4, !tbaa !6
  %3977 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 18), align 8, !tbaa !6
  %3978 = fmul contract float %3976, %3977
  %3979 = fsub contract float %3974, %3978
  store float %3979, float addrspace(3)* %3950, align 8, !tbaa !6
  %3980 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %3981 = load float, float addrspace(3)* %3980, align 8, !tbaa !6
  %3982 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 18), align 8, !tbaa !6
  %3983 = fmul contract float %3981, %3982
  %3984 = fsub contract float %3979, %3983
  store float %3984, float addrspace(3)* %3950, align 8, !tbaa !6
  %3985 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %3986 = load float, float addrspace(3)* %3985, align 4, !tbaa !6
  %3987 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 18), align 8, !tbaa !6
  %3988 = fmul contract float %3986, %3987
  %3989 = fsub contract float %3984, %3988
  store float %3989, float addrspace(3)* %3950, align 8, !tbaa !6
  %3990 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %3991 = load float, float addrspace(3)* %3990, align 16, !tbaa !6
  %3992 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 18), align 8, !tbaa !6
  %3993 = fmul contract float %3991, %3992
  %3994 = fsub contract float %3989, %3993
  store float %3994, float addrspace(3)* %3950, align 8, !tbaa !6
  %3995 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %3996 = load float, float addrspace(3)* %3995, align 4, !tbaa !6
  %3997 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 18), align 8, !tbaa !6
  %3998 = fmul contract float %3996, %3997
  %3999 = fsub contract float %3994, %3998
  store float %3999, float addrspace(3)* %3950, align 8, !tbaa !6
  %4000 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %4001 = load float, float addrspace(3)* %4000, align 8, !tbaa !6
  %4002 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 18), align 8, !tbaa !6
  %4003 = fmul contract float %4001, %4002
  %4004 = fsub contract float %3999, %4003
  store float %4004, float addrspace(3)* %3950, align 8, !tbaa !6
  %4005 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %4006 = load float, float addrspace(3)* %4005, align 4, !tbaa !6
  %4007 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 18), align 8, !tbaa !6
  %4008 = fmul contract float %4006, %4007
  %4009 = fsub contract float %4004, %4008
  store float %4009, float addrspace(3)* %3950, align 8, !tbaa !6
  %4010 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %4011 = load float, float addrspace(3)* %4010, align 16, !tbaa !6
  %4012 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 18), align 8, !tbaa !6
  %4013 = fmul contract float %4011, %4012
  %4014 = fsub contract float %4009, %4013
  store float %4014, float addrspace(3)* %3950, align 8, !tbaa !6
  %4015 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %4016 = load float, float addrspace(3)* %4015, align 4, !tbaa !6
  %4017 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 18), align 8, !tbaa !6
  %4018 = fmul contract float %4016, %4017
  %4019 = fsub contract float %4014, %4018
  store float %4019, float addrspace(3)* %3950, align 8, !tbaa !6
  %4020 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %4021 = load float, float addrspace(3)* %4020, align 8, !tbaa !6
  %4022 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 18), align 8, !tbaa !6
  %4023 = fmul contract float %4021, %4022
  %4024 = fsub contract float %4019, %4023
  store float %4024, float addrspace(3)* %3950, align 8, !tbaa !6
  %4025 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %4026 = load float, float addrspace(3)* %4025, align 4, !tbaa !6
  %4027 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 18), align 8, !tbaa !6
  %4028 = fmul contract float %4026, %4027
  %4029 = fsub contract float %4024, %4028
  store float %4029, float addrspace(3)* %3950, align 8, !tbaa !6
  %4030 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %4031 = load float, float addrspace(3)* %4030, align 16, !tbaa !6
  %4032 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 18), align 8, !tbaa !6
  %4033 = fmul contract float %4031, %4032
  %4034 = fsub contract float %4029, %4033
  store float %4034, float addrspace(3)* %3950, align 8, !tbaa !6
  %4035 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %4036 = load float, float addrspace(3)* %4035, align 4, !tbaa !6
  %4037 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 18), align 8, !tbaa !6
  %4038 = fmul contract float %4036, %4037
  %4039 = fsub contract float %4034, %4038
  store float %4039, float addrspace(3)* %3950, align 8, !tbaa !6
  %4040 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 18), align 8, !tbaa !6
  %4041 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 18
  %4042 = fdiv contract float %4039, %4040
  store float %4042, float addrspace(3)* %4041, align 8, !tbaa !6
  %4043 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 19
  %4044 = load float, float addrspace(3)* %4043, align 4, !tbaa !6
  %4045 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 19), align 4, !tbaa !6
  %4046 = fmul contract float %3133, %4045
  %4047 = fsub contract float %4044, %4046
  store float %4047, float addrspace(3)* %4043, align 4, !tbaa !6
  %4048 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %4049 = load float, float addrspace(3)* %4048, align 4, !tbaa !6
  %4050 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 19), align 4, !tbaa !6
  %4051 = fmul contract float %4049, %4050
  %4052 = fsub contract float %4047, %4051
  store float %4052, float addrspace(3)* %4043, align 4, !tbaa !6
  %4053 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %4054 = load float, float addrspace(3)* %4053, align 8, !tbaa !6
  %4055 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 19), align 4, !tbaa !6
  %4056 = fmul contract float %4054, %4055
  %4057 = fsub contract float %4052, %4056
  store float %4057, float addrspace(3)* %4043, align 4, !tbaa !6
  %4058 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %4059 = load float, float addrspace(3)* %4058, align 4, !tbaa !6
  %4060 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 19), align 4, !tbaa !6
  %4061 = fmul contract float %4059, %4060
  %4062 = fsub contract float %4057, %4061
  store float %4062, float addrspace(3)* %4043, align 4, !tbaa !6
  %4063 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %4064 = load float, float addrspace(3)* %4063, align 16, !tbaa !6
  %4065 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 19), align 4, !tbaa !6
  %4066 = fmul contract float %4064, %4065
  %4067 = fsub contract float %4062, %4066
  store float %4067, float addrspace(3)* %4043, align 4, !tbaa !6
  %4068 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %4069 = load float, float addrspace(3)* %4068, align 4, !tbaa !6
  %4070 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 19), align 4, !tbaa !6
  %4071 = fmul contract float %4069, %4070
  %4072 = fsub contract float %4067, %4071
  store float %4072, float addrspace(3)* %4043, align 4, !tbaa !6
  %4073 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %4074 = load float, float addrspace(3)* %4073, align 8, !tbaa !6
  %4075 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 19), align 4, !tbaa !6
  %4076 = fmul contract float %4074, %4075
  %4077 = fsub contract float %4072, %4076
  store float %4077, float addrspace(3)* %4043, align 4, !tbaa !6
  %4078 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %4079 = load float, float addrspace(3)* %4078, align 4, !tbaa !6
  %4080 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 19), align 4, !tbaa !6
  %4081 = fmul contract float %4079, %4080
  %4082 = fsub contract float %4077, %4081
  store float %4082, float addrspace(3)* %4043, align 4, !tbaa !6
  %4083 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %4084 = load float, float addrspace(3)* %4083, align 16, !tbaa !6
  %4085 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 19), align 4, !tbaa !6
  %4086 = fmul contract float %4084, %4085
  %4087 = fsub contract float %4082, %4086
  store float %4087, float addrspace(3)* %4043, align 4, !tbaa !6
  %4088 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %4089 = load float, float addrspace(3)* %4088, align 4, !tbaa !6
  %4090 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 19), align 4, !tbaa !6
  %4091 = fmul contract float %4089, %4090
  %4092 = fsub contract float %4087, %4091
  store float %4092, float addrspace(3)* %4043, align 4, !tbaa !6
  %4093 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %4094 = load float, float addrspace(3)* %4093, align 8, !tbaa !6
  %4095 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 19), align 4, !tbaa !6
  %4096 = fmul contract float %4094, %4095
  %4097 = fsub contract float %4092, %4096
  store float %4097, float addrspace(3)* %4043, align 4, !tbaa !6
  %4098 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %4099 = load float, float addrspace(3)* %4098, align 4, !tbaa !6
  %4100 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 19), align 4, !tbaa !6
  %4101 = fmul contract float %4099, %4100
  %4102 = fsub contract float %4097, %4101
  store float %4102, float addrspace(3)* %4043, align 4, !tbaa !6
  %4103 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %4104 = load float, float addrspace(3)* %4103, align 16, !tbaa !6
  %4105 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 19), align 4, !tbaa !6
  %4106 = fmul contract float %4104, %4105
  %4107 = fsub contract float %4102, %4106
  store float %4107, float addrspace(3)* %4043, align 4, !tbaa !6
  %4108 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %4109 = load float, float addrspace(3)* %4108, align 4, !tbaa !6
  %4110 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 19), align 4, !tbaa !6
  %4111 = fmul contract float %4109, %4110
  %4112 = fsub contract float %4107, %4111
  store float %4112, float addrspace(3)* %4043, align 4, !tbaa !6
  %4113 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %4114 = load float, float addrspace(3)* %4113, align 8, !tbaa !6
  %4115 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 19), align 4, !tbaa !6
  %4116 = fmul contract float %4114, %4115
  %4117 = fsub contract float %4112, %4116
  store float %4117, float addrspace(3)* %4043, align 4, !tbaa !6
  %4118 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %4119 = load float, float addrspace(3)* %4118, align 4, !tbaa !6
  %4120 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 19), align 4, !tbaa !6
  %4121 = fmul contract float %4119, %4120
  %4122 = fsub contract float %4117, %4121
  store float %4122, float addrspace(3)* %4043, align 4, !tbaa !6
  %4123 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %4124 = load float, float addrspace(3)* %4123, align 16, !tbaa !6
  %4125 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 19), align 4, !tbaa !6
  %4126 = fmul contract float %4124, %4125
  %4127 = fsub contract float %4122, %4126
  store float %4127, float addrspace(3)* %4043, align 4, !tbaa !6
  %4128 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %4129 = load float, float addrspace(3)* %4128, align 4, !tbaa !6
  %4130 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 19), align 4, !tbaa !6
  %4131 = fmul contract float %4129, %4130
  %4132 = fsub contract float %4127, %4131
  store float %4132, float addrspace(3)* %4043, align 4, !tbaa !6
  %4133 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 18
  %4134 = load float, float addrspace(3)* %4133, align 8, !tbaa !6
  %4135 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 19), align 4, !tbaa !6
  %4136 = fmul contract float %4134, %4135
  %4137 = fsub contract float %4132, %4136
  store float %4137, float addrspace(3)* %4043, align 4, !tbaa !6
  %4138 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 19), align 4, !tbaa !6
  %4139 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 19
  %4140 = fdiv contract float %4137, %4138
  store float %4140, float addrspace(3)* %4139, align 4, !tbaa !6
  %4141 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 20
  %4142 = load float, float addrspace(3)* %4141, align 16, !tbaa !6
  %4143 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 20), align 16, !tbaa !6
  %4144 = fmul contract float %3133, %4143
  %4145 = fsub contract float %4142, %4144
  store float %4145, float addrspace(3)* %4141, align 16, !tbaa !6
  %4146 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %4147 = load float, float addrspace(3)* %4146, align 4, !tbaa !6
  %4148 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 20), align 16, !tbaa !6
  %4149 = fmul contract float %4147, %4148
  %4150 = fsub contract float %4145, %4149
  store float %4150, float addrspace(3)* %4141, align 16, !tbaa !6
  %4151 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %4152 = load float, float addrspace(3)* %4151, align 8, !tbaa !6
  %4153 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 20), align 16, !tbaa !6
  %4154 = fmul contract float %4152, %4153
  %4155 = fsub contract float %4150, %4154
  store float %4155, float addrspace(3)* %4141, align 16, !tbaa !6
  %4156 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %4157 = load float, float addrspace(3)* %4156, align 4, !tbaa !6
  %4158 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 20), align 16, !tbaa !6
  %4159 = fmul contract float %4157, %4158
  %4160 = fsub contract float %4155, %4159
  store float %4160, float addrspace(3)* %4141, align 16, !tbaa !6
  %4161 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %4162 = load float, float addrspace(3)* %4161, align 16, !tbaa !6
  %4163 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 20), align 16, !tbaa !6
  %4164 = fmul contract float %4162, %4163
  %4165 = fsub contract float %4160, %4164
  store float %4165, float addrspace(3)* %4141, align 16, !tbaa !6
  %4166 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %4167 = load float, float addrspace(3)* %4166, align 4, !tbaa !6
  %4168 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 20), align 16, !tbaa !6
  %4169 = fmul contract float %4167, %4168
  %4170 = fsub contract float %4165, %4169
  store float %4170, float addrspace(3)* %4141, align 16, !tbaa !6
  %4171 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %4172 = load float, float addrspace(3)* %4171, align 8, !tbaa !6
  %4173 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 20), align 16, !tbaa !6
  %4174 = fmul contract float %4172, %4173
  %4175 = fsub contract float %4170, %4174
  store float %4175, float addrspace(3)* %4141, align 16, !tbaa !6
  %4176 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %4177 = load float, float addrspace(3)* %4176, align 4, !tbaa !6
  %4178 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 20), align 16, !tbaa !6
  %4179 = fmul contract float %4177, %4178
  %4180 = fsub contract float %4175, %4179
  store float %4180, float addrspace(3)* %4141, align 16, !tbaa !6
  %4181 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %4182 = load float, float addrspace(3)* %4181, align 16, !tbaa !6
  %4183 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 20), align 16, !tbaa !6
  %4184 = fmul contract float %4182, %4183
  %4185 = fsub contract float %4180, %4184
  store float %4185, float addrspace(3)* %4141, align 16, !tbaa !6
  %4186 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %4187 = load float, float addrspace(3)* %4186, align 4, !tbaa !6
  %4188 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 20), align 16, !tbaa !6
  %4189 = fmul contract float %4187, %4188
  %4190 = fsub contract float %4185, %4189
  store float %4190, float addrspace(3)* %4141, align 16, !tbaa !6
  %4191 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %4192 = load float, float addrspace(3)* %4191, align 8, !tbaa !6
  %4193 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 20), align 16, !tbaa !6
  %4194 = fmul contract float %4192, %4193
  %4195 = fsub contract float %4190, %4194
  store float %4195, float addrspace(3)* %4141, align 16, !tbaa !6
  %4196 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %4197 = load float, float addrspace(3)* %4196, align 4, !tbaa !6
  %4198 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 20), align 16, !tbaa !6
  %4199 = fmul contract float %4197, %4198
  %4200 = fsub contract float %4195, %4199
  store float %4200, float addrspace(3)* %4141, align 16, !tbaa !6
  %4201 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %4202 = load float, float addrspace(3)* %4201, align 16, !tbaa !6
  %4203 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 20), align 16, !tbaa !6
  %4204 = fmul contract float %4202, %4203
  %4205 = fsub contract float %4200, %4204
  store float %4205, float addrspace(3)* %4141, align 16, !tbaa !6
  %4206 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %4207 = load float, float addrspace(3)* %4206, align 4, !tbaa !6
  %4208 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 20), align 16, !tbaa !6
  %4209 = fmul contract float %4207, %4208
  %4210 = fsub contract float %4205, %4209
  store float %4210, float addrspace(3)* %4141, align 16, !tbaa !6
  %4211 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %4212 = load float, float addrspace(3)* %4211, align 8, !tbaa !6
  %4213 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 20), align 16, !tbaa !6
  %4214 = fmul contract float %4212, %4213
  %4215 = fsub contract float %4210, %4214
  store float %4215, float addrspace(3)* %4141, align 16, !tbaa !6
  %4216 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %4217 = load float, float addrspace(3)* %4216, align 4, !tbaa !6
  %4218 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 20), align 16, !tbaa !6
  %4219 = fmul contract float %4217, %4218
  %4220 = fsub contract float %4215, %4219
  store float %4220, float addrspace(3)* %4141, align 16, !tbaa !6
  %4221 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %4222 = load float, float addrspace(3)* %4221, align 16, !tbaa !6
  %4223 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 20), align 16, !tbaa !6
  %4224 = fmul contract float %4222, %4223
  %4225 = fsub contract float %4220, %4224
  store float %4225, float addrspace(3)* %4141, align 16, !tbaa !6
  %4226 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %4227 = load float, float addrspace(3)* %4226, align 4, !tbaa !6
  %4228 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 20), align 16, !tbaa !6
  %4229 = fmul contract float %4227, %4228
  %4230 = fsub contract float %4225, %4229
  store float %4230, float addrspace(3)* %4141, align 16, !tbaa !6
  %4231 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 18
  %4232 = load float, float addrspace(3)* %4231, align 8, !tbaa !6
  %4233 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 20), align 16, !tbaa !6
  %4234 = fmul contract float %4232, %4233
  %4235 = fsub contract float %4230, %4234
  store float %4235, float addrspace(3)* %4141, align 16, !tbaa !6
  %4236 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 19
  %4237 = load float, float addrspace(3)* %4236, align 4, !tbaa !6
  %4238 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 20), align 16, !tbaa !6
  %4239 = fmul contract float %4237, %4238
  %4240 = fsub contract float %4235, %4239
  store float %4240, float addrspace(3)* %4141, align 16, !tbaa !6
  %4241 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 20), align 16, !tbaa !6
  %4242 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 20
  %4243 = fdiv contract float %4240, %4241
  store float %4243, float addrspace(3)* %4242, align 16, !tbaa !6
  %4244 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 21
  %4245 = load float, float addrspace(3)* %4244, align 4, !tbaa !6
  %4246 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 21), align 4, !tbaa !6
  %4247 = fmul contract float %3133, %4246
  %4248 = fsub contract float %4245, %4247
  store float %4248, float addrspace(3)* %4244, align 4, !tbaa !6
  %4249 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %4250 = load float, float addrspace(3)* %4249, align 4, !tbaa !6
  %4251 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 21), align 4, !tbaa !6
  %4252 = fmul contract float %4250, %4251
  %4253 = fsub contract float %4248, %4252
  store float %4253, float addrspace(3)* %4244, align 4, !tbaa !6
  %4254 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %4255 = load float, float addrspace(3)* %4254, align 8, !tbaa !6
  %4256 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 21), align 4, !tbaa !6
  %4257 = fmul contract float %4255, %4256
  %4258 = fsub contract float %4253, %4257
  store float %4258, float addrspace(3)* %4244, align 4, !tbaa !6
  %4259 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %4260 = load float, float addrspace(3)* %4259, align 4, !tbaa !6
  %4261 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 21), align 4, !tbaa !6
  %4262 = fmul contract float %4260, %4261
  %4263 = fsub contract float %4258, %4262
  store float %4263, float addrspace(3)* %4244, align 4, !tbaa !6
  %4264 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %4265 = load float, float addrspace(3)* %4264, align 16, !tbaa !6
  %4266 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 21), align 4, !tbaa !6
  %4267 = fmul contract float %4265, %4266
  %4268 = fsub contract float %4263, %4267
  store float %4268, float addrspace(3)* %4244, align 4, !tbaa !6
  %4269 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %4270 = load float, float addrspace(3)* %4269, align 4, !tbaa !6
  %4271 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 21), align 4, !tbaa !6
  %4272 = fmul contract float %4270, %4271
  %4273 = fsub contract float %4268, %4272
  store float %4273, float addrspace(3)* %4244, align 4, !tbaa !6
  %4274 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %4275 = load float, float addrspace(3)* %4274, align 8, !tbaa !6
  %4276 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 21), align 4, !tbaa !6
  %4277 = fmul contract float %4275, %4276
  %4278 = fsub contract float %4273, %4277
  store float %4278, float addrspace(3)* %4244, align 4, !tbaa !6
  %4279 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %4280 = load float, float addrspace(3)* %4279, align 4, !tbaa !6
  %4281 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 21), align 4, !tbaa !6
  %4282 = fmul contract float %4280, %4281
  %4283 = fsub contract float %4278, %4282
  store float %4283, float addrspace(3)* %4244, align 4, !tbaa !6
  %4284 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %4285 = load float, float addrspace(3)* %4284, align 16, !tbaa !6
  %4286 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 21), align 4, !tbaa !6
  %4287 = fmul contract float %4285, %4286
  %4288 = fsub contract float %4283, %4287
  store float %4288, float addrspace(3)* %4244, align 4, !tbaa !6
  %4289 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %4290 = load float, float addrspace(3)* %4289, align 4, !tbaa !6
  %4291 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 21), align 4, !tbaa !6
  %4292 = fmul contract float %4290, %4291
  %4293 = fsub contract float %4288, %4292
  store float %4293, float addrspace(3)* %4244, align 4, !tbaa !6
  %4294 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %4295 = load float, float addrspace(3)* %4294, align 8, !tbaa !6
  %4296 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 21), align 4, !tbaa !6
  %4297 = fmul contract float %4295, %4296
  %4298 = fsub contract float %4293, %4297
  store float %4298, float addrspace(3)* %4244, align 4, !tbaa !6
  %4299 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %4300 = load float, float addrspace(3)* %4299, align 4, !tbaa !6
  %4301 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 21), align 4, !tbaa !6
  %4302 = fmul contract float %4300, %4301
  %4303 = fsub contract float %4298, %4302
  store float %4303, float addrspace(3)* %4244, align 4, !tbaa !6
  %4304 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %4305 = load float, float addrspace(3)* %4304, align 16, !tbaa !6
  %4306 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 21), align 4, !tbaa !6
  %4307 = fmul contract float %4305, %4306
  %4308 = fsub contract float %4303, %4307
  store float %4308, float addrspace(3)* %4244, align 4, !tbaa !6
  %4309 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %4310 = load float, float addrspace(3)* %4309, align 4, !tbaa !6
  %4311 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 21), align 4, !tbaa !6
  %4312 = fmul contract float %4310, %4311
  %4313 = fsub contract float %4308, %4312
  store float %4313, float addrspace(3)* %4244, align 4, !tbaa !6
  %4314 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %4315 = load float, float addrspace(3)* %4314, align 8, !tbaa !6
  %4316 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 21), align 4, !tbaa !6
  %4317 = fmul contract float %4315, %4316
  %4318 = fsub contract float %4313, %4317
  store float %4318, float addrspace(3)* %4244, align 4, !tbaa !6
  %4319 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %4320 = load float, float addrspace(3)* %4319, align 4, !tbaa !6
  %4321 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 21), align 4, !tbaa !6
  %4322 = fmul contract float %4320, %4321
  %4323 = fsub contract float %4318, %4322
  store float %4323, float addrspace(3)* %4244, align 4, !tbaa !6
  %4324 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %4325 = load float, float addrspace(3)* %4324, align 16, !tbaa !6
  %4326 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 21), align 4, !tbaa !6
  %4327 = fmul contract float %4325, %4326
  %4328 = fsub contract float %4323, %4327
  store float %4328, float addrspace(3)* %4244, align 4, !tbaa !6
  %4329 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %4330 = load float, float addrspace(3)* %4329, align 4, !tbaa !6
  %4331 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 21), align 4, !tbaa !6
  %4332 = fmul contract float %4330, %4331
  %4333 = fsub contract float %4328, %4332
  store float %4333, float addrspace(3)* %4244, align 4, !tbaa !6
  %4334 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 18
  %4335 = load float, float addrspace(3)* %4334, align 8, !tbaa !6
  %4336 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 21), align 4, !tbaa !6
  %4337 = fmul contract float %4335, %4336
  %4338 = fsub contract float %4333, %4337
  store float %4338, float addrspace(3)* %4244, align 4, !tbaa !6
  %4339 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 19
  %4340 = load float, float addrspace(3)* %4339, align 4, !tbaa !6
  %4341 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 21), align 4, !tbaa !6
  %4342 = fmul contract float %4340, %4341
  %4343 = fsub contract float %4338, %4342
  store float %4343, float addrspace(3)* %4244, align 4, !tbaa !6
  %4344 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 20
  %4345 = load float, float addrspace(3)* %4344, align 16, !tbaa !6
  %4346 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 21), align 4, !tbaa !6
  %4347 = fmul contract float %4345, %4346
  %4348 = fsub contract float %4343, %4347
  store float %4348, float addrspace(3)* %4244, align 4, !tbaa !6
  %4349 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 21), align 4, !tbaa !6
  %4350 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 21
  %4351 = fdiv contract float %4348, %4349
  store float %4351, float addrspace(3)* %4350, align 4, !tbaa !6
  %4352 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 22
  %4353 = load float, float addrspace(3)* %4352, align 8, !tbaa !6
  %4354 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 22), align 8, !tbaa !6
  %4355 = fmul contract float %3133, %4354
  %4356 = fsub contract float %4353, %4355
  store float %4356, float addrspace(3)* %4352, align 8, !tbaa !6
  %4357 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %4358 = load float, float addrspace(3)* %4357, align 4, !tbaa !6
  %4359 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 22), align 8, !tbaa !6
  %4360 = fmul contract float %4358, %4359
  %4361 = fsub contract float %4356, %4360
  store float %4361, float addrspace(3)* %4352, align 8, !tbaa !6
  %4362 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %4363 = load float, float addrspace(3)* %4362, align 8, !tbaa !6
  %4364 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 22), align 8, !tbaa !6
  %4365 = fmul contract float %4363, %4364
  %4366 = fsub contract float %4361, %4365
  store float %4366, float addrspace(3)* %4352, align 8, !tbaa !6
  %4367 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %4368 = load float, float addrspace(3)* %4367, align 4, !tbaa !6
  %4369 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 22), align 8, !tbaa !6
  %4370 = fmul contract float %4368, %4369
  %4371 = fsub contract float %4366, %4370
  store float %4371, float addrspace(3)* %4352, align 8, !tbaa !6
  %4372 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %4373 = load float, float addrspace(3)* %4372, align 16, !tbaa !6
  %4374 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 22), align 8, !tbaa !6
  %4375 = fmul contract float %4373, %4374
  %4376 = fsub contract float %4371, %4375
  store float %4376, float addrspace(3)* %4352, align 8, !tbaa !6
  %4377 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %4378 = load float, float addrspace(3)* %4377, align 4, !tbaa !6
  %4379 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 22), align 8, !tbaa !6
  %4380 = fmul contract float %4378, %4379
  %4381 = fsub contract float %4376, %4380
  store float %4381, float addrspace(3)* %4352, align 8, !tbaa !6
  %4382 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %4383 = load float, float addrspace(3)* %4382, align 8, !tbaa !6
  %4384 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 22), align 8, !tbaa !6
  %4385 = fmul contract float %4383, %4384
  %4386 = fsub contract float %4381, %4385
  store float %4386, float addrspace(3)* %4352, align 8, !tbaa !6
  %4387 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %4388 = load float, float addrspace(3)* %4387, align 4, !tbaa !6
  %4389 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 22), align 8, !tbaa !6
  %4390 = fmul contract float %4388, %4389
  %4391 = fsub contract float %4386, %4390
  store float %4391, float addrspace(3)* %4352, align 8, !tbaa !6
  %4392 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %4393 = load float, float addrspace(3)* %4392, align 16, !tbaa !6
  %4394 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 22), align 8, !tbaa !6
  %4395 = fmul contract float %4393, %4394
  %4396 = fsub contract float %4391, %4395
  store float %4396, float addrspace(3)* %4352, align 8, !tbaa !6
  %4397 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %4398 = load float, float addrspace(3)* %4397, align 4, !tbaa !6
  %4399 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 22), align 8, !tbaa !6
  %4400 = fmul contract float %4398, %4399
  %4401 = fsub contract float %4396, %4400
  store float %4401, float addrspace(3)* %4352, align 8, !tbaa !6
  %4402 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %4403 = load float, float addrspace(3)* %4402, align 8, !tbaa !6
  %4404 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 22), align 8, !tbaa !6
  %4405 = fmul contract float %4403, %4404
  %4406 = fsub contract float %4401, %4405
  store float %4406, float addrspace(3)* %4352, align 8, !tbaa !6
  %4407 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %4408 = load float, float addrspace(3)* %4407, align 4, !tbaa !6
  %4409 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 22), align 8, !tbaa !6
  %4410 = fmul contract float %4408, %4409
  %4411 = fsub contract float %4406, %4410
  store float %4411, float addrspace(3)* %4352, align 8, !tbaa !6
  %4412 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %4413 = load float, float addrspace(3)* %4412, align 16, !tbaa !6
  %4414 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 22), align 8, !tbaa !6
  %4415 = fmul contract float %4413, %4414
  %4416 = fsub contract float %4411, %4415
  store float %4416, float addrspace(3)* %4352, align 8, !tbaa !6
  %4417 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %4418 = load float, float addrspace(3)* %4417, align 4, !tbaa !6
  %4419 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 22), align 8, !tbaa !6
  %4420 = fmul contract float %4418, %4419
  %4421 = fsub contract float %4416, %4420
  store float %4421, float addrspace(3)* %4352, align 8, !tbaa !6
  %4422 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %4423 = load float, float addrspace(3)* %4422, align 8, !tbaa !6
  %4424 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 22), align 8, !tbaa !6
  %4425 = fmul contract float %4423, %4424
  %4426 = fsub contract float %4421, %4425
  store float %4426, float addrspace(3)* %4352, align 8, !tbaa !6
  %4427 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %4428 = load float, float addrspace(3)* %4427, align 4, !tbaa !6
  %4429 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 22), align 8, !tbaa !6
  %4430 = fmul contract float %4428, %4429
  %4431 = fsub contract float %4426, %4430
  store float %4431, float addrspace(3)* %4352, align 8, !tbaa !6
  %4432 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %4433 = load float, float addrspace(3)* %4432, align 16, !tbaa !6
  %4434 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 22), align 8, !tbaa !6
  %4435 = fmul contract float %4433, %4434
  %4436 = fsub contract float %4431, %4435
  store float %4436, float addrspace(3)* %4352, align 8, !tbaa !6
  %4437 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %4438 = load float, float addrspace(3)* %4437, align 4, !tbaa !6
  %4439 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 22), align 8, !tbaa !6
  %4440 = fmul contract float %4438, %4439
  %4441 = fsub contract float %4436, %4440
  store float %4441, float addrspace(3)* %4352, align 8, !tbaa !6
  %4442 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 18
  %4443 = load float, float addrspace(3)* %4442, align 8, !tbaa !6
  %4444 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 22), align 8, !tbaa !6
  %4445 = fmul contract float %4443, %4444
  %4446 = fsub contract float %4441, %4445
  store float %4446, float addrspace(3)* %4352, align 8, !tbaa !6
  %4447 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 19
  %4448 = load float, float addrspace(3)* %4447, align 4, !tbaa !6
  %4449 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 22), align 8, !tbaa !6
  %4450 = fmul contract float %4448, %4449
  %4451 = fsub contract float %4446, %4450
  store float %4451, float addrspace(3)* %4352, align 8, !tbaa !6
  %4452 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 20
  %4453 = load float, float addrspace(3)* %4452, align 16, !tbaa !6
  %4454 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 22), align 8, !tbaa !6
  %4455 = fmul contract float %4453, %4454
  %4456 = fsub contract float %4451, %4455
  store float %4456, float addrspace(3)* %4352, align 8, !tbaa !6
  %4457 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 21
  %4458 = load float, float addrspace(3)* %4457, align 4, !tbaa !6
  %4459 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 22), align 8, !tbaa !6
  %4460 = fmul contract float %4458, %4459
  %4461 = fsub contract float %4456, %4460
  store float %4461, float addrspace(3)* %4352, align 8, !tbaa !6
  %4462 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 22), align 8, !tbaa !6
  %4463 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 22
  %4464 = fdiv contract float %4461, %4462
  store float %4464, float addrspace(3)* %4463, align 8, !tbaa !6
  %4465 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 23
  %4466 = load float, float addrspace(3)* %4465, align 4, !tbaa !6
  %4467 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 23), align 4, !tbaa !6
  %4468 = fmul contract float %3133, %4467
  %4469 = fsub contract float %4466, %4468
  store float %4469, float addrspace(3)* %4465, align 4, !tbaa !6
  %4470 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %4471 = load float, float addrspace(3)* %4470, align 4, !tbaa !6
  %4472 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 23), align 4, !tbaa !6
  %4473 = fmul contract float %4471, %4472
  %4474 = fsub contract float %4469, %4473
  store float %4474, float addrspace(3)* %4465, align 4, !tbaa !6
  %4475 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %4476 = load float, float addrspace(3)* %4475, align 8, !tbaa !6
  %4477 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 23), align 4, !tbaa !6
  %4478 = fmul contract float %4476, %4477
  %4479 = fsub contract float %4474, %4478
  store float %4479, float addrspace(3)* %4465, align 4, !tbaa !6
  %4480 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %4481 = load float, float addrspace(3)* %4480, align 4, !tbaa !6
  %4482 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 23), align 4, !tbaa !6
  %4483 = fmul contract float %4481, %4482
  %4484 = fsub contract float %4479, %4483
  store float %4484, float addrspace(3)* %4465, align 4, !tbaa !6
  %4485 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %4486 = load float, float addrspace(3)* %4485, align 16, !tbaa !6
  %4487 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 23), align 4, !tbaa !6
  %4488 = fmul contract float %4486, %4487
  %4489 = fsub contract float %4484, %4488
  store float %4489, float addrspace(3)* %4465, align 4, !tbaa !6
  %4490 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %4491 = load float, float addrspace(3)* %4490, align 4, !tbaa !6
  %4492 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 23), align 4, !tbaa !6
  %4493 = fmul contract float %4491, %4492
  %4494 = fsub contract float %4489, %4493
  store float %4494, float addrspace(3)* %4465, align 4, !tbaa !6
  %4495 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %4496 = load float, float addrspace(3)* %4495, align 8, !tbaa !6
  %4497 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 23), align 4, !tbaa !6
  %4498 = fmul contract float %4496, %4497
  %4499 = fsub contract float %4494, %4498
  store float %4499, float addrspace(3)* %4465, align 4, !tbaa !6
  %4500 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %4501 = load float, float addrspace(3)* %4500, align 4, !tbaa !6
  %4502 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 23), align 4, !tbaa !6
  %4503 = fmul contract float %4501, %4502
  %4504 = fsub contract float %4499, %4503
  store float %4504, float addrspace(3)* %4465, align 4, !tbaa !6
  %4505 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %4506 = load float, float addrspace(3)* %4505, align 16, !tbaa !6
  %4507 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 23), align 4, !tbaa !6
  %4508 = fmul contract float %4506, %4507
  %4509 = fsub contract float %4504, %4508
  store float %4509, float addrspace(3)* %4465, align 4, !tbaa !6
  %4510 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %4511 = load float, float addrspace(3)* %4510, align 4, !tbaa !6
  %4512 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 23), align 4, !tbaa !6
  %4513 = fmul contract float %4511, %4512
  %4514 = fsub contract float %4509, %4513
  store float %4514, float addrspace(3)* %4465, align 4, !tbaa !6
  %4515 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %4516 = load float, float addrspace(3)* %4515, align 8, !tbaa !6
  %4517 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 23), align 4, !tbaa !6
  %4518 = fmul contract float %4516, %4517
  %4519 = fsub contract float %4514, %4518
  store float %4519, float addrspace(3)* %4465, align 4, !tbaa !6
  %4520 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %4521 = load float, float addrspace(3)* %4520, align 4, !tbaa !6
  %4522 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 23), align 4, !tbaa !6
  %4523 = fmul contract float %4521, %4522
  %4524 = fsub contract float %4519, %4523
  store float %4524, float addrspace(3)* %4465, align 4, !tbaa !6
  %4525 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %4526 = load float, float addrspace(3)* %4525, align 16, !tbaa !6
  %4527 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 23), align 4, !tbaa !6
  %4528 = fmul contract float %4526, %4527
  %4529 = fsub contract float %4524, %4528
  store float %4529, float addrspace(3)* %4465, align 4, !tbaa !6
  %4530 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %4531 = load float, float addrspace(3)* %4530, align 4, !tbaa !6
  %4532 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 23), align 4, !tbaa !6
  %4533 = fmul contract float %4531, %4532
  %4534 = fsub contract float %4529, %4533
  store float %4534, float addrspace(3)* %4465, align 4, !tbaa !6
  %4535 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %4536 = load float, float addrspace(3)* %4535, align 8, !tbaa !6
  %4537 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 23), align 4, !tbaa !6
  %4538 = fmul contract float %4536, %4537
  %4539 = fsub contract float %4534, %4538
  store float %4539, float addrspace(3)* %4465, align 4, !tbaa !6
  %4540 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %4541 = load float, float addrspace(3)* %4540, align 4, !tbaa !6
  %4542 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 23), align 4, !tbaa !6
  %4543 = fmul contract float %4541, %4542
  %4544 = fsub contract float %4539, %4543
  store float %4544, float addrspace(3)* %4465, align 4, !tbaa !6
  %4545 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %4546 = load float, float addrspace(3)* %4545, align 16, !tbaa !6
  %4547 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 23), align 4, !tbaa !6
  %4548 = fmul contract float %4546, %4547
  %4549 = fsub contract float %4544, %4548
  store float %4549, float addrspace(3)* %4465, align 4, !tbaa !6
  %4550 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %4551 = load float, float addrspace(3)* %4550, align 4, !tbaa !6
  %4552 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 23), align 4, !tbaa !6
  %4553 = fmul contract float %4551, %4552
  %4554 = fsub contract float %4549, %4553
  store float %4554, float addrspace(3)* %4465, align 4, !tbaa !6
  %4555 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 18
  %4556 = load float, float addrspace(3)* %4555, align 8, !tbaa !6
  %4557 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 23), align 4, !tbaa !6
  %4558 = fmul contract float %4556, %4557
  %4559 = fsub contract float %4554, %4558
  store float %4559, float addrspace(3)* %4465, align 4, !tbaa !6
  %4560 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 19
  %4561 = load float, float addrspace(3)* %4560, align 4, !tbaa !6
  %4562 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 23), align 4, !tbaa !6
  %4563 = fmul contract float %4561, %4562
  %4564 = fsub contract float %4559, %4563
  store float %4564, float addrspace(3)* %4465, align 4, !tbaa !6
  %4565 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 20
  %4566 = load float, float addrspace(3)* %4565, align 16, !tbaa !6
  %4567 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 23), align 4, !tbaa !6
  %4568 = fmul contract float %4566, %4567
  %4569 = fsub contract float %4564, %4568
  store float %4569, float addrspace(3)* %4465, align 4, !tbaa !6
  %4570 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 21
  %4571 = load float, float addrspace(3)* %4570, align 4, !tbaa !6
  %4572 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 23), align 4, !tbaa !6
  %4573 = fmul contract float %4571, %4572
  %4574 = fsub contract float %4569, %4573
  store float %4574, float addrspace(3)* %4465, align 4, !tbaa !6
  %4575 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 22
  %4576 = load float, float addrspace(3)* %4575, align 8, !tbaa !6
  %4577 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 23), align 4, !tbaa !6
  %4578 = fmul contract float %4576, %4577
  %4579 = fsub contract float %4574, %4578
  store float %4579, float addrspace(3)* %4465, align 4, !tbaa !6
  %4580 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 23), align 4, !tbaa !6
  %4581 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 23
  %4582 = fdiv contract float %4579, %4580
  store float %4582, float addrspace(3)* %4581, align 4, !tbaa !6
  %4583 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 24
  %4584 = load float, float addrspace(3)* %4583, align 16, !tbaa !6
  %4585 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 24), align 16, !tbaa !6
  %4586 = fmul contract float %3133, %4585
  %4587 = fsub contract float %4584, %4586
  store float %4587, float addrspace(3)* %4583, align 16, !tbaa !6
  %4588 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %4589 = load float, float addrspace(3)* %4588, align 4, !tbaa !6
  %4590 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 24), align 16, !tbaa !6
  %4591 = fmul contract float %4589, %4590
  %4592 = fsub contract float %4587, %4591
  store float %4592, float addrspace(3)* %4583, align 16, !tbaa !6
  %4593 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %4594 = load float, float addrspace(3)* %4593, align 8, !tbaa !6
  %4595 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 24), align 16, !tbaa !6
  %4596 = fmul contract float %4594, %4595
  %4597 = fsub contract float %4592, %4596
  store float %4597, float addrspace(3)* %4583, align 16, !tbaa !6
  %4598 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %4599 = load float, float addrspace(3)* %4598, align 4, !tbaa !6
  %4600 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 24), align 16, !tbaa !6
  %4601 = fmul contract float %4599, %4600
  %4602 = fsub contract float %4597, %4601
  store float %4602, float addrspace(3)* %4583, align 16, !tbaa !6
  %4603 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %4604 = load float, float addrspace(3)* %4603, align 16, !tbaa !6
  %4605 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 24), align 16, !tbaa !6
  %4606 = fmul contract float %4604, %4605
  %4607 = fsub contract float %4602, %4606
  store float %4607, float addrspace(3)* %4583, align 16, !tbaa !6
  %4608 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %4609 = load float, float addrspace(3)* %4608, align 4, !tbaa !6
  %4610 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 24), align 16, !tbaa !6
  %4611 = fmul contract float %4609, %4610
  %4612 = fsub contract float %4607, %4611
  store float %4612, float addrspace(3)* %4583, align 16, !tbaa !6
  %4613 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %4614 = load float, float addrspace(3)* %4613, align 8, !tbaa !6
  %4615 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 24), align 16, !tbaa !6
  %4616 = fmul contract float %4614, %4615
  %4617 = fsub contract float %4612, %4616
  store float %4617, float addrspace(3)* %4583, align 16, !tbaa !6
  %4618 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %4619 = load float, float addrspace(3)* %4618, align 4, !tbaa !6
  %4620 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 24), align 16, !tbaa !6
  %4621 = fmul contract float %4619, %4620
  %4622 = fsub contract float %4617, %4621
  store float %4622, float addrspace(3)* %4583, align 16, !tbaa !6
  %4623 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %4624 = load float, float addrspace(3)* %4623, align 16, !tbaa !6
  %4625 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 24), align 16, !tbaa !6
  %4626 = fmul contract float %4624, %4625
  %4627 = fsub contract float %4622, %4626
  store float %4627, float addrspace(3)* %4583, align 16, !tbaa !6
  %4628 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %4629 = load float, float addrspace(3)* %4628, align 4, !tbaa !6
  %4630 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 24), align 16, !tbaa !6
  %4631 = fmul contract float %4629, %4630
  %4632 = fsub contract float %4627, %4631
  store float %4632, float addrspace(3)* %4583, align 16, !tbaa !6
  %4633 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %4634 = load float, float addrspace(3)* %4633, align 8, !tbaa !6
  %4635 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 24), align 16, !tbaa !6
  %4636 = fmul contract float %4634, %4635
  %4637 = fsub contract float %4632, %4636
  store float %4637, float addrspace(3)* %4583, align 16, !tbaa !6
  %4638 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %4639 = load float, float addrspace(3)* %4638, align 4, !tbaa !6
  %4640 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 24), align 16, !tbaa !6
  %4641 = fmul contract float %4639, %4640
  %4642 = fsub contract float %4637, %4641
  store float %4642, float addrspace(3)* %4583, align 16, !tbaa !6
  %4643 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %4644 = load float, float addrspace(3)* %4643, align 16, !tbaa !6
  %4645 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 24), align 16, !tbaa !6
  %4646 = fmul contract float %4644, %4645
  %4647 = fsub contract float %4642, %4646
  store float %4647, float addrspace(3)* %4583, align 16, !tbaa !6
  %4648 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %4649 = load float, float addrspace(3)* %4648, align 4, !tbaa !6
  %4650 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 24), align 16, !tbaa !6
  %4651 = fmul contract float %4649, %4650
  %4652 = fsub contract float %4647, %4651
  store float %4652, float addrspace(3)* %4583, align 16, !tbaa !6
  %4653 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %4654 = load float, float addrspace(3)* %4653, align 8, !tbaa !6
  %4655 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 24), align 16, !tbaa !6
  %4656 = fmul contract float %4654, %4655
  %4657 = fsub contract float %4652, %4656
  store float %4657, float addrspace(3)* %4583, align 16, !tbaa !6
  %4658 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %4659 = load float, float addrspace(3)* %4658, align 4, !tbaa !6
  %4660 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 24), align 16, !tbaa !6
  %4661 = fmul contract float %4659, %4660
  %4662 = fsub contract float %4657, %4661
  store float %4662, float addrspace(3)* %4583, align 16, !tbaa !6
  %4663 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %4664 = load float, float addrspace(3)* %4663, align 16, !tbaa !6
  %4665 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 24), align 16, !tbaa !6
  %4666 = fmul contract float %4664, %4665
  %4667 = fsub contract float %4662, %4666
  store float %4667, float addrspace(3)* %4583, align 16, !tbaa !6
  %4668 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %4669 = load float, float addrspace(3)* %4668, align 4, !tbaa !6
  %4670 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 24), align 16, !tbaa !6
  %4671 = fmul contract float %4669, %4670
  %4672 = fsub contract float %4667, %4671
  store float %4672, float addrspace(3)* %4583, align 16, !tbaa !6
  %4673 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 18
  %4674 = load float, float addrspace(3)* %4673, align 8, !tbaa !6
  %4675 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 24), align 16, !tbaa !6
  %4676 = fmul contract float %4674, %4675
  %4677 = fsub contract float %4672, %4676
  store float %4677, float addrspace(3)* %4583, align 16, !tbaa !6
  %4678 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 19
  %4679 = load float, float addrspace(3)* %4678, align 4, !tbaa !6
  %4680 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 24), align 16, !tbaa !6
  %4681 = fmul contract float %4679, %4680
  %4682 = fsub contract float %4677, %4681
  store float %4682, float addrspace(3)* %4583, align 16, !tbaa !6
  %4683 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 20
  %4684 = load float, float addrspace(3)* %4683, align 16, !tbaa !6
  %4685 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 24), align 16, !tbaa !6
  %4686 = fmul contract float %4684, %4685
  %4687 = fsub contract float %4682, %4686
  store float %4687, float addrspace(3)* %4583, align 16, !tbaa !6
  %4688 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 21
  %4689 = load float, float addrspace(3)* %4688, align 4, !tbaa !6
  %4690 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 24), align 16, !tbaa !6
  %4691 = fmul contract float %4689, %4690
  %4692 = fsub contract float %4687, %4691
  store float %4692, float addrspace(3)* %4583, align 16, !tbaa !6
  %4693 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 22
  %4694 = load float, float addrspace(3)* %4693, align 8, !tbaa !6
  %4695 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 24), align 16, !tbaa !6
  %4696 = fmul contract float %4694, %4695
  %4697 = fsub contract float %4692, %4696
  store float %4697, float addrspace(3)* %4583, align 16, !tbaa !6
  %4698 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 23
  %4699 = load float, float addrspace(3)* %4698, align 4, !tbaa !6
  %4700 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 24), align 16, !tbaa !6
  %4701 = fmul contract float %4699, %4700
  %4702 = fsub contract float %4697, %4701
  store float %4702, float addrspace(3)* %4583, align 16, !tbaa !6
  %4703 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 24), align 16, !tbaa !6
  %4704 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 24
  %4705 = fdiv contract float %4702, %4703
  store float %4705, float addrspace(3)* %4704, align 16, !tbaa !6
  %4706 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 25
  %4707 = load float, float addrspace(3)* %4706, align 4, !tbaa !6
  %4708 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 25), align 4, !tbaa !6
  %4709 = fmul contract float %3133, %4708
  %4710 = fsub contract float %4707, %4709
  store float %4710, float addrspace(3)* %4706, align 4, !tbaa !6
  %4711 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %4712 = load float, float addrspace(3)* %4711, align 4, !tbaa !6
  %4713 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 25), align 4, !tbaa !6
  %4714 = fmul contract float %4712, %4713
  %4715 = fsub contract float %4710, %4714
  store float %4715, float addrspace(3)* %4706, align 4, !tbaa !6
  %4716 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %4717 = load float, float addrspace(3)* %4716, align 8, !tbaa !6
  %4718 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 25), align 4, !tbaa !6
  %4719 = fmul contract float %4717, %4718
  %4720 = fsub contract float %4715, %4719
  store float %4720, float addrspace(3)* %4706, align 4, !tbaa !6
  %4721 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %4722 = load float, float addrspace(3)* %4721, align 4, !tbaa !6
  %4723 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 25), align 4, !tbaa !6
  %4724 = fmul contract float %4722, %4723
  %4725 = fsub contract float %4720, %4724
  store float %4725, float addrspace(3)* %4706, align 4, !tbaa !6
  %4726 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %4727 = load float, float addrspace(3)* %4726, align 16, !tbaa !6
  %4728 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 25), align 4, !tbaa !6
  %4729 = fmul contract float %4727, %4728
  %4730 = fsub contract float %4725, %4729
  store float %4730, float addrspace(3)* %4706, align 4, !tbaa !6
  %4731 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %4732 = load float, float addrspace(3)* %4731, align 4, !tbaa !6
  %4733 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 25), align 4, !tbaa !6
  %4734 = fmul contract float %4732, %4733
  %4735 = fsub contract float %4730, %4734
  store float %4735, float addrspace(3)* %4706, align 4, !tbaa !6
  %4736 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %4737 = load float, float addrspace(3)* %4736, align 8, !tbaa !6
  %4738 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 25), align 4, !tbaa !6
  %4739 = fmul contract float %4737, %4738
  %4740 = fsub contract float %4735, %4739
  store float %4740, float addrspace(3)* %4706, align 4, !tbaa !6
  %4741 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %4742 = load float, float addrspace(3)* %4741, align 4, !tbaa !6
  %4743 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 25), align 4, !tbaa !6
  %4744 = fmul contract float %4742, %4743
  %4745 = fsub contract float %4740, %4744
  store float %4745, float addrspace(3)* %4706, align 4, !tbaa !6
  %4746 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %4747 = load float, float addrspace(3)* %4746, align 16, !tbaa !6
  %4748 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 25), align 4, !tbaa !6
  %4749 = fmul contract float %4747, %4748
  %4750 = fsub contract float %4745, %4749
  store float %4750, float addrspace(3)* %4706, align 4, !tbaa !6
  %4751 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %4752 = load float, float addrspace(3)* %4751, align 4, !tbaa !6
  %4753 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 25), align 4, !tbaa !6
  %4754 = fmul contract float %4752, %4753
  %4755 = fsub contract float %4750, %4754
  store float %4755, float addrspace(3)* %4706, align 4, !tbaa !6
  %4756 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %4757 = load float, float addrspace(3)* %4756, align 8, !tbaa !6
  %4758 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 25), align 4, !tbaa !6
  %4759 = fmul contract float %4757, %4758
  %4760 = fsub contract float %4755, %4759
  store float %4760, float addrspace(3)* %4706, align 4, !tbaa !6
  %4761 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %4762 = load float, float addrspace(3)* %4761, align 4, !tbaa !6
  %4763 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 25), align 4, !tbaa !6
  %4764 = fmul contract float %4762, %4763
  %4765 = fsub contract float %4760, %4764
  store float %4765, float addrspace(3)* %4706, align 4, !tbaa !6
  %4766 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %4767 = load float, float addrspace(3)* %4766, align 16, !tbaa !6
  %4768 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 25), align 4, !tbaa !6
  %4769 = fmul contract float %4767, %4768
  %4770 = fsub contract float %4765, %4769
  store float %4770, float addrspace(3)* %4706, align 4, !tbaa !6
  %4771 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %4772 = load float, float addrspace(3)* %4771, align 4, !tbaa !6
  %4773 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 25), align 4, !tbaa !6
  %4774 = fmul contract float %4772, %4773
  %4775 = fsub contract float %4770, %4774
  store float %4775, float addrspace(3)* %4706, align 4, !tbaa !6
  %4776 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %4777 = load float, float addrspace(3)* %4776, align 8, !tbaa !6
  %4778 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 25), align 4, !tbaa !6
  %4779 = fmul contract float %4777, %4778
  %4780 = fsub contract float %4775, %4779
  store float %4780, float addrspace(3)* %4706, align 4, !tbaa !6
  %4781 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %4782 = load float, float addrspace(3)* %4781, align 4, !tbaa !6
  %4783 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 25), align 4, !tbaa !6
  %4784 = fmul contract float %4782, %4783
  %4785 = fsub contract float %4780, %4784
  store float %4785, float addrspace(3)* %4706, align 4, !tbaa !6
  %4786 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %4787 = load float, float addrspace(3)* %4786, align 16, !tbaa !6
  %4788 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 25), align 4, !tbaa !6
  %4789 = fmul contract float %4787, %4788
  %4790 = fsub contract float %4785, %4789
  store float %4790, float addrspace(3)* %4706, align 4, !tbaa !6
  %4791 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %4792 = load float, float addrspace(3)* %4791, align 4, !tbaa !6
  %4793 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 25), align 4, !tbaa !6
  %4794 = fmul contract float %4792, %4793
  %4795 = fsub contract float %4790, %4794
  store float %4795, float addrspace(3)* %4706, align 4, !tbaa !6
  %4796 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 18
  %4797 = load float, float addrspace(3)* %4796, align 8, !tbaa !6
  %4798 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 25), align 4, !tbaa !6
  %4799 = fmul contract float %4797, %4798
  %4800 = fsub contract float %4795, %4799
  store float %4800, float addrspace(3)* %4706, align 4, !tbaa !6
  %4801 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 19
  %4802 = load float, float addrspace(3)* %4801, align 4, !tbaa !6
  %4803 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 25), align 4, !tbaa !6
  %4804 = fmul contract float %4802, %4803
  %4805 = fsub contract float %4800, %4804
  store float %4805, float addrspace(3)* %4706, align 4, !tbaa !6
  %4806 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 20
  %4807 = load float, float addrspace(3)* %4806, align 16, !tbaa !6
  %4808 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 25), align 4, !tbaa !6
  %4809 = fmul contract float %4807, %4808
  %4810 = fsub contract float %4805, %4809
  store float %4810, float addrspace(3)* %4706, align 4, !tbaa !6
  %4811 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 21
  %4812 = load float, float addrspace(3)* %4811, align 4, !tbaa !6
  %4813 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 25), align 4, !tbaa !6
  %4814 = fmul contract float %4812, %4813
  %4815 = fsub contract float %4810, %4814
  store float %4815, float addrspace(3)* %4706, align 4, !tbaa !6
  %4816 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 22
  %4817 = load float, float addrspace(3)* %4816, align 8, !tbaa !6
  %4818 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 25), align 4, !tbaa !6
  %4819 = fmul contract float %4817, %4818
  %4820 = fsub contract float %4815, %4819
  store float %4820, float addrspace(3)* %4706, align 4, !tbaa !6
  %4821 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 23
  %4822 = load float, float addrspace(3)* %4821, align 4, !tbaa !6
  %4823 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 25), align 4, !tbaa !6
  %4824 = fmul contract float %4822, %4823
  %4825 = fsub contract float %4820, %4824
  store float %4825, float addrspace(3)* %4706, align 4, !tbaa !6
  %4826 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 24
  %4827 = load float, float addrspace(3)* %4826, align 16, !tbaa !6
  %4828 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 25), align 4, !tbaa !6
  %4829 = fmul contract float %4827, %4828
  %4830 = fsub contract float %4825, %4829
  store float %4830, float addrspace(3)* %4706, align 4, !tbaa !6
  %4831 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 25), align 4, !tbaa !6
  %4832 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 25
  %4833 = fdiv contract float %4830, %4831
  store float %4833, float addrspace(3)* %4832, align 4, !tbaa !6
  %4834 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 26
  %4835 = load float, float addrspace(3)* %4834, align 8, !tbaa !6
  %4836 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 26), align 8, !tbaa !6
  %4837 = fmul contract float %3133, %4836
  %4838 = fsub contract float %4835, %4837
  store float %4838, float addrspace(3)* %4834, align 8, !tbaa !6
  %4839 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %4840 = load float, float addrspace(3)* %4839, align 4, !tbaa !6
  %4841 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 26), align 8, !tbaa !6
  %4842 = fmul contract float %4840, %4841
  %4843 = fsub contract float %4838, %4842
  store float %4843, float addrspace(3)* %4834, align 8, !tbaa !6
  %4844 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %4845 = load float, float addrspace(3)* %4844, align 8, !tbaa !6
  %4846 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 26), align 8, !tbaa !6
  %4847 = fmul contract float %4845, %4846
  %4848 = fsub contract float %4843, %4847
  store float %4848, float addrspace(3)* %4834, align 8, !tbaa !6
  %4849 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %4850 = load float, float addrspace(3)* %4849, align 4, !tbaa !6
  %4851 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 26), align 8, !tbaa !6
  %4852 = fmul contract float %4850, %4851
  %4853 = fsub contract float %4848, %4852
  store float %4853, float addrspace(3)* %4834, align 8, !tbaa !6
  %4854 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %4855 = load float, float addrspace(3)* %4854, align 16, !tbaa !6
  %4856 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 26), align 8, !tbaa !6
  %4857 = fmul contract float %4855, %4856
  %4858 = fsub contract float %4853, %4857
  store float %4858, float addrspace(3)* %4834, align 8, !tbaa !6
  %4859 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %4860 = load float, float addrspace(3)* %4859, align 4, !tbaa !6
  %4861 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 26), align 8, !tbaa !6
  %4862 = fmul contract float %4860, %4861
  %4863 = fsub contract float %4858, %4862
  store float %4863, float addrspace(3)* %4834, align 8, !tbaa !6
  %4864 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %4865 = load float, float addrspace(3)* %4864, align 8, !tbaa !6
  %4866 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 26), align 8, !tbaa !6
  %4867 = fmul contract float %4865, %4866
  %4868 = fsub contract float %4863, %4867
  store float %4868, float addrspace(3)* %4834, align 8, !tbaa !6
  %4869 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %4870 = load float, float addrspace(3)* %4869, align 4, !tbaa !6
  %4871 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 26), align 8, !tbaa !6
  %4872 = fmul contract float %4870, %4871
  %4873 = fsub contract float %4868, %4872
  store float %4873, float addrspace(3)* %4834, align 8, !tbaa !6
  %4874 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %4875 = load float, float addrspace(3)* %4874, align 16, !tbaa !6
  %4876 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 26), align 8, !tbaa !6
  %4877 = fmul contract float %4875, %4876
  %4878 = fsub contract float %4873, %4877
  store float %4878, float addrspace(3)* %4834, align 8, !tbaa !6
  %4879 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %4880 = load float, float addrspace(3)* %4879, align 4, !tbaa !6
  %4881 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 26), align 8, !tbaa !6
  %4882 = fmul contract float %4880, %4881
  %4883 = fsub contract float %4878, %4882
  store float %4883, float addrspace(3)* %4834, align 8, !tbaa !6
  %4884 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %4885 = load float, float addrspace(3)* %4884, align 8, !tbaa !6
  %4886 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 26), align 8, !tbaa !6
  %4887 = fmul contract float %4885, %4886
  %4888 = fsub contract float %4883, %4887
  store float %4888, float addrspace(3)* %4834, align 8, !tbaa !6
  %4889 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %4890 = load float, float addrspace(3)* %4889, align 4, !tbaa !6
  %4891 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 26), align 8, !tbaa !6
  %4892 = fmul contract float %4890, %4891
  %4893 = fsub contract float %4888, %4892
  store float %4893, float addrspace(3)* %4834, align 8, !tbaa !6
  %4894 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %4895 = load float, float addrspace(3)* %4894, align 16, !tbaa !6
  %4896 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 26), align 8, !tbaa !6
  %4897 = fmul contract float %4895, %4896
  %4898 = fsub contract float %4893, %4897
  store float %4898, float addrspace(3)* %4834, align 8, !tbaa !6
  %4899 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %4900 = load float, float addrspace(3)* %4899, align 4, !tbaa !6
  %4901 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 26), align 8, !tbaa !6
  %4902 = fmul contract float %4900, %4901
  %4903 = fsub contract float %4898, %4902
  store float %4903, float addrspace(3)* %4834, align 8, !tbaa !6
  %4904 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %4905 = load float, float addrspace(3)* %4904, align 8, !tbaa !6
  %4906 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 26), align 8, !tbaa !6
  %4907 = fmul contract float %4905, %4906
  %4908 = fsub contract float %4903, %4907
  store float %4908, float addrspace(3)* %4834, align 8, !tbaa !6
  %4909 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %4910 = load float, float addrspace(3)* %4909, align 4, !tbaa !6
  %4911 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 26), align 8, !tbaa !6
  %4912 = fmul contract float %4910, %4911
  %4913 = fsub contract float %4908, %4912
  store float %4913, float addrspace(3)* %4834, align 8, !tbaa !6
  %4914 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %4915 = load float, float addrspace(3)* %4914, align 16, !tbaa !6
  %4916 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 26), align 8, !tbaa !6
  %4917 = fmul contract float %4915, %4916
  %4918 = fsub contract float %4913, %4917
  store float %4918, float addrspace(3)* %4834, align 8, !tbaa !6
  %4919 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %4920 = load float, float addrspace(3)* %4919, align 4, !tbaa !6
  %4921 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 26), align 8, !tbaa !6
  %4922 = fmul contract float %4920, %4921
  %4923 = fsub contract float %4918, %4922
  store float %4923, float addrspace(3)* %4834, align 8, !tbaa !6
  %4924 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 18
  %4925 = load float, float addrspace(3)* %4924, align 8, !tbaa !6
  %4926 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 26), align 8, !tbaa !6
  %4927 = fmul contract float %4925, %4926
  %4928 = fsub contract float %4923, %4927
  store float %4928, float addrspace(3)* %4834, align 8, !tbaa !6
  %4929 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 19
  %4930 = load float, float addrspace(3)* %4929, align 4, !tbaa !6
  %4931 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 26), align 8, !tbaa !6
  %4932 = fmul contract float %4930, %4931
  %4933 = fsub contract float %4928, %4932
  store float %4933, float addrspace(3)* %4834, align 8, !tbaa !6
  %4934 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 20
  %4935 = load float, float addrspace(3)* %4934, align 16, !tbaa !6
  %4936 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 26), align 8, !tbaa !6
  %4937 = fmul contract float %4935, %4936
  %4938 = fsub contract float %4933, %4937
  store float %4938, float addrspace(3)* %4834, align 8, !tbaa !6
  %4939 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 21
  %4940 = load float, float addrspace(3)* %4939, align 4, !tbaa !6
  %4941 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 26), align 8, !tbaa !6
  %4942 = fmul contract float %4940, %4941
  %4943 = fsub contract float %4938, %4942
  store float %4943, float addrspace(3)* %4834, align 8, !tbaa !6
  %4944 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 22
  %4945 = load float, float addrspace(3)* %4944, align 8, !tbaa !6
  %4946 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 26), align 8, !tbaa !6
  %4947 = fmul contract float %4945, %4946
  %4948 = fsub contract float %4943, %4947
  store float %4948, float addrspace(3)* %4834, align 8, !tbaa !6
  %4949 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 23
  %4950 = load float, float addrspace(3)* %4949, align 4, !tbaa !6
  %4951 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 26), align 8, !tbaa !6
  %4952 = fmul contract float %4950, %4951
  %4953 = fsub contract float %4948, %4952
  store float %4953, float addrspace(3)* %4834, align 8, !tbaa !6
  %4954 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 24
  %4955 = load float, float addrspace(3)* %4954, align 16, !tbaa !6
  %4956 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 26), align 8, !tbaa !6
  %4957 = fmul contract float %4955, %4956
  %4958 = fsub contract float %4953, %4957
  store float %4958, float addrspace(3)* %4834, align 8, !tbaa !6
  %4959 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 25
  %4960 = load float, float addrspace(3)* %4959, align 4, !tbaa !6
  %4961 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 26), align 8, !tbaa !6
  %4962 = fmul contract float %4960, %4961
  %4963 = fsub contract float %4958, %4962
  store float %4963, float addrspace(3)* %4834, align 8, !tbaa !6
  %4964 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 26), align 8, !tbaa !6
  %4965 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 26
  %4966 = fdiv contract float %4963, %4964
  store float %4966, float addrspace(3)* %4965, align 8, !tbaa !6
  %4967 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 27
  %4968 = load float, float addrspace(3)* %4967, align 4, !tbaa !6
  %4969 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 27), align 4, !tbaa !6
  %4970 = fmul contract float %3133, %4969
  %4971 = fsub contract float %4968, %4970
  store float %4971, float addrspace(3)* %4967, align 4, !tbaa !6
  %4972 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %4973 = load float, float addrspace(3)* %4972, align 4, !tbaa !6
  %4974 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 27), align 4, !tbaa !6
  %4975 = fmul contract float %4973, %4974
  %4976 = fsub contract float %4971, %4975
  store float %4976, float addrspace(3)* %4967, align 4, !tbaa !6
  %4977 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %4978 = load float, float addrspace(3)* %4977, align 8, !tbaa !6
  %4979 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 27), align 4, !tbaa !6
  %4980 = fmul contract float %4978, %4979
  %4981 = fsub contract float %4976, %4980
  store float %4981, float addrspace(3)* %4967, align 4, !tbaa !6
  %4982 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %4983 = load float, float addrspace(3)* %4982, align 4, !tbaa !6
  %4984 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 27), align 4, !tbaa !6
  %4985 = fmul contract float %4983, %4984
  %4986 = fsub contract float %4981, %4985
  store float %4986, float addrspace(3)* %4967, align 4, !tbaa !6
  %4987 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %4988 = load float, float addrspace(3)* %4987, align 16, !tbaa !6
  %4989 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 27), align 4, !tbaa !6
  %4990 = fmul contract float %4988, %4989
  %4991 = fsub contract float %4986, %4990
  store float %4991, float addrspace(3)* %4967, align 4, !tbaa !6
  %4992 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %4993 = load float, float addrspace(3)* %4992, align 4, !tbaa !6
  %4994 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 27), align 4, !tbaa !6
  %4995 = fmul contract float %4993, %4994
  %4996 = fsub contract float %4991, %4995
  store float %4996, float addrspace(3)* %4967, align 4, !tbaa !6
  %4997 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %4998 = load float, float addrspace(3)* %4997, align 8, !tbaa !6
  %4999 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 27), align 4, !tbaa !6
  %5000 = fmul contract float %4998, %4999
  %5001 = fsub contract float %4996, %5000
  store float %5001, float addrspace(3)* %4967, align 4, !tbaa !6
  %5002 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %5003 = load float, float addrspace(3)* %5002, align 4, !tbaa !6
  %5004 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 27), align 4, !tbaa !6
  %5005 = fmul contract float %5003, %5004
  %5006 = fsub contract float %5001, %5005
  store float %5006, float addrspace(3)* %4967, align 4, !tbaa !6
  %5007 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %5008 = load float, float addrspace(3)* %5007, align 16, !tbaa !6
  %5009 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 27), align 4, !tbaa !6
  %5010 = fmul contract float %5008, %5009
  %5011 = fsub contract float %5006, %5010
  store float %5011, float addrspace(3)* %4967, align 4, !tbaa !6
  %5012 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %5013 = load float, float addrspace(3)* %5012, align 4, !tbaa !6
  %5014 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 27), align 4, !tbaa !6
  %5015 = fmul contract float %5013, %5014
  %5016 = fsub contract float %5011, %5015
  store float %5016, float addrspace(3)* %4967, align 4, !tbaa !6
  %5017 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %5018 = load float, float addrspace(3)* %5017, align 8, !tbaa !6
  %5019 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 27), align 4, !tbaa !6
  %5020 = fmul contract float %5018, %5019
  %5021 = fsub contract float %5016, %5020
  store float %5021, float addrspace(3)* %4967, align 4, !tbaa !6
  %5022 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %5023 = load float, float addrspace(3)* %5022, align 4, !tbaa !6
  %5024 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 27), align 4, !tbaa !6
  %5025 = fmul contract float %5023, %5024
  %5026 = fsub contract float %5021, %5025
  store float %5026, float addrspace(3)* %4967, align 4, !tbaa !6
  %5027 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %5028 = load float, float addrspace(3)* %5027, align 16, !tbaa !6
  %5029 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 27), align 4, !tbaa !6
  %5030 = fmul contract float %5028, %5029
  %5031 = fsub contract float %5026, %5030
  store float %5031, float addrspace(3)* %4967, align 4, !tbaa !6
  %5032 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %5033 = load float, float addrspace(3)* %5032, align 4, !tbaa !6
  %5034 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 27), align 4, !tbaa !6
  %5035 = fmul contract float %5033, %5034
  %5036 = fsub contract float %5031, %5035
  store float %5036, float addrspace(3)* %4967, align 4, !tbaa !6
  %5037 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %5038 = load float, float addrspace(3)* %5037, align 8, !tbaa !6
  %5039 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 27), align 4, !tbaa !6
  %5040 = fmul contract float %5038, %5039
  %5041 = fsub contract float %5036, %5040
  store float %5041, float addrspace(3)* %4967, align 4, !tbaa !6
  %5042 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %5043 = load float, float addrspace(3)* %5042, align 4, !tbaa !6
  %5044 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 27), align 4, !tbaa !6
  %5045 = fmul contract float %5043, %5044
  %5046 = fsub contract float %5041, %5045
  store float %5046, float addrspace(3)* %4967, align 4, !tbaa !6
  %5047 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %5048 = load float, float addrspace(3)* %5047, align 16, !tbaa !6
  %5049 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 27), align 4, !tbaa !6
  %5050 = fmul contract float %5048, %5049
  %5051 = fsub contract float %5046, %5050
  store float %5051, float addrspace(3)* %4967, align 4, !tbaa !6
  %5052 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %5053 = load float, float addrspace(3)* %5052, align 4, !tbaa !6
  %5054 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 27), align 4, !tbaa !6
  %5055 = fmul contract float %5053, %5054
  %5056 = fsub contract float %5051, %5055
  store float %5056, float addrspace(3)* %4967, align 4, !tbaa !6
  %5057 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 18
  %5058 = load float, float addrspace(3)* %5057, align 8, !tbaa !6
  %5059 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 27), align 4, !tbaa !6
  %5060 = fmul contract float %5058, %5059
  %5061 = fsub contract float %5056, %5060
  store float %5061, float addrspace(3)* %4967, align 4, !tbaa !6
  %5062 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 19
  %5063 = load float, float addrspace(3)* %5062, align 4, !tbaa !6
  %5064 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 27), align 4, !tbaa !6
  %5065 = fmul contract float %5063, %5064
  %5066 = fsub contract float %5061, %5065
  store float %5066, float addrspace(3)* %4967, align 4, !tbaa !6
  %5067 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 20
  %5068 = load float, float addrspace(3)* %5067, align 16, !tbaa !6
  %5069 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 27), align 4, !tbaa !6
  %5070 = fmul contract float %5068, %5069
  %5071 = fsub contract float %5066, %5070
  store float %5071, float addrspace(3)* %4967, align 4, !tbaa !6
  %5072 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 21
  %5073 = load float, float addrspace(3)* %5072, align 4, !tbaa !6
  %5074 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 27), align 4, !tbaa !6
  %5075 = fmul contract float %5073, %5074
  %5076 = fsub contract float %5071, %5075
  store float %5076, float addrspace(3)* %4967, align 4, !tbaa !6
  %5077 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 22
  %5078 = load float, float addrspace(3)* %5077, align 8, !tbaa !6
  %5079 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 27), align 4, !tbaa !6
  %5080 = fmul contract float %5078, %5079
  %5081 = fsub contract float %5076, %5080
  store float %5081, float addrspace(3)* %4967, align 4, !tbaa !6
  %5082 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 23
  %5083 = load float, float addrspace(3)* %5082, align 4, !tbaa !6
  %5084 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 27), align 4, !tbaa !6
  %5085 = fmul contract float %5083, %5084
  %5086 = fsub contract float %5081, %5085
  store float %5086, float addrspace(3)* %4967, align 4, !tbaa !6
  %5087 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 24
  %5088 = load float, float addrspace(3)* %5087, align 16, !tbaa !6
  %5089 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 27), align 4, !tbaa !6
  %5090 = fmul contract float %5088, %5089
  %5091 = fsub contract float %5086, %5090
  store float %5091, float addrspace(3)* %4967, align 4, !tbaa !6
  %5092 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 25
  %5093 = load float, float addrspace(3)* %5092, align 4, !tbaa !6
  %5094 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 27), align 4, !tbaa !6
  %5095 = fmul contract float %5093, %5094
  %5096 = fsub contract float %5091, %5095
  store float %5096, float addrspace(3)* %4967, align 4, !tbaa !6
  %5097 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 26
  %5098 = load float, float addrspace(3)* %5097, align 8, !tbaa !6
  %5099 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 27), align 4, !tbaa !6
  %5100 = fmul contract float %5098, %5099
  %5101 = fsub contract float %5096, %5100
  store float %5101, float addrspace(3)* %4967, align 4, !tbaa !6
  %5102 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 27), align 4, !tbaa !6
  %5103 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 27
  %5104 = fdiv contract float %5101, %5102
  store float %5104, float addrspace(3)* %5103, align 4, !tbaa !6
  %5105 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 28
  %5106 = load float, float addrspace(3)* %5105, align 16, !tbaa !6
  %5107 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 28), align 16, !tbaa !6
  %5108 = fmul contract float %3133, %5107
  %5109 = fsub contract float %5106, %5108
  store float %5109, float addrspace(3)* %5105, align 16, !tbaa !6
  %5110 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %5111 = load float, float addrspace(3)* %5110, align 4, !tbaa !6
  %5112 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 28), align 16, !tbaa !6
  %5113 = fmul contract float %5111, %5112
  %5114 = fsub contract float %5109, %5113
  store float %5114, float addrspace(3)* %5105, align 16, !tbaa !6
  %5115 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %5116 = load float, float addrspace(3)* %5115, align 8, !tbaa !6
  %5117 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 28), align 16, !tbaa !6
  %5118 = fmul contract float %5116, %5117
  %5119 = fsub contract float %5114, %5118
  store float %5119, float addrspace(3)* %5105, align 16, !tbaa !6
  %5120 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %5121 = load float, float addrspace(3)* %5120, align 4, !tbaa !6
  %5122 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 28), align 16, !tbaa !6
  %5123 = fmul contract float %5121, %5122
  %5124 = fsub contract float %5119, %5123
  store float %5124, float addrspace(3)* %5105, align 16, !tbaa !6
  %5125 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %5126 = load float, float addrspace(3)* %5125, align 16, !tbaa !6
  %5127 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 28), align 16, !tbaa !6
  %5128 = fmul contract float %5126, %5127
  %5129 = fsub contract float %5124, %5128
  store float %5129, float addrspace(3)* %5105, align 16, !tbaa !6
  %5130 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %5131 = load float, float addrspace(3)* %5130, align 4, !tbaa !6
  %5132 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 28), align 16, !tbaa !6
  %5133 = fmul contract float %5131, %5132
  %5134 = fsub contract float %5129, %5133
  store float %5134, float addrspace(3)* %5105, align 16, !tbaa !6
  %5135 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %5136 = load float, float addrspace(3)* %5135, align 8, !tbaa !6
  %5137 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 28), align 16, !tbaa !6
  %5138 = fmul contract float %5136, %5137
  %5139 = fsub contract float %5134, %5138
  store float %5139, float addrspace(3)* %5105, align 16, !tbaa !6
  %5140 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %5141 = load float, float addrspace(3)* %5140, align 4, !tbaa !6
  %5142 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 28), align 16, !tbaa !6
  %5143 = fmul contract float %5141, %5142
  %5144 = fsub contract float %5139, %5143
  store float %5144, float addrspace(3)* %5105, align 16, !tbaa !6
  %5145 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %5146 = load float, float addrspace(3)* %5145, align 16, !tbaa !6
  %5147 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 28), align 16, !tbaa !6
  %5148 = fmul contract float %5146, %5147
  %5149 = fsub contract float %5144, %5148
  store float %5149, float addrspace(3)* %5105, align 16, !tbaa !6
  %5150 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %5151 = load float, float addrspace(3)* %5150, align 4, !tbaa !6
  %5152 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 28), align 16, !tbaa !6
  %5153 = fmul contract float %5151, %5152
  %5154 = fsub contract float %5149, %5153
  store float %5154, float addrspace(3)* %5105, align 16, !tbaa !6
  %5155 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %5156 = load float, float addrspace(3)* %5155, align 8, !tbaa !6
  %5157 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 28), align 16, !tbaa !6
  %5158 = fmul contract float %5156, %5157
  %5159 = fsub contract float %5154, %5158
  store float %5159, float addrspace(3)* %5105, align 16, !tbaa !6
  %5160 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %5161 = load float, float addrspace(3)* %5160, align 4, !tbaa !6
  %5162 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 28), align 16, !tbaa !6
  %5163 = fmul contract float %5161, %5162
  %5164 = fsub contract float %5159, %5163
  store float %5164, float addrspace(3)* %5105, align 16, !tbaa !6
  %5165 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %5166 = load float, float addrspace(3)* %5165, align 16, !tbaa !6
  %5167 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 28), align 16, !tbaa !6
  %5168 = fmul contract float %5166, %5167
  %5169 = fsub contract float %5164, %5168
  store float %5169, float addrspace(3)* %5105, align 16, !tbaa !6
  %5170 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %5171 = load float, float addrspace(3)* %5170, align 4, !tbaa !6
  %5172 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 28), align 16, !tbaa !6
  %5173 = fmul contract float %5171, %5172
  %5174 = fsub contract float %5169, %5173
  store float %5174, float addrspace(3)* %5105, align 16, !tbaa !6
  %5175 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %5176 = load float, float addrspace(3)* %5175, align 8, !tbaa !6
  %5177 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 28), align 16, !tbaa !6
  %5178 = fmul contract float %5176, %5177
  %5179 = fsub contract float %5174, %5178
  store float %5179, float addrspace(3)* %5105, align 16, !tbaa !6
  %5180 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %5181 = load float, float addrspace(3)* %5180, align 4, !tbaa !6
  %5182 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 28), align 16, !tbaa !6
  %5183 = fmul contract float %5181, %5182
  %5184 = fsub contract float %5179, %5183
  store float %5184, float addrspace(3)* %5105, align 16, !tbaa !6
  %5185 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %5186 = load float, float addrspace(3)* %5185, align 16, !tbaa !6
  %5187 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 28), align 16, !tbaa !6
  %5188 = fmul contract float %5186, %5187
  %5189 = fsub contract float %5184, %5188
  store float %5189, float addrspace(3)* %5105, align 16, !tbaa !6
  %5190 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %5191 = load float, float addrspace(3)* %5190, align 4, !tbaa !6
  %5192 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 28), align 16, !tbaa !6
  %5193 = fmul contract float %5191, %5192
  %5194 = fsub contract float %5189, %5193
  store float %5194, float addrspace(3)* %5105, align 16, !tbaa !6
  %5195 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 18
  %5196 = load float, float addrspace(3)* %5195, align 8, !tbaa !6
  %5197 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 28), align 16, !tbaa !6
  %5198 = fmul contract float %5196, %5197
  %5199 = fsub contract float %5194, %5198
  store float %5199, float addrspace(3)* %5105, align 16, !tbaa !6
  %5200 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 19
  %5201 = load float, float addrspace(3)* %5200, align 4, !tbaa !6
  %5202 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 28), align 16, !tbaa !6
  %5203 = fmul contract float %5201, %5202
  %5204 = fsub contract float %5199, %5203
  store float %5204, float addrspace(3)* %5105, align 16, !tbaa !6
  %5205 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 20
  %5206 = load float, float addrspace(3)* %5205, align 16, !tbaa !6
  %5207 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 28), align 16, !tbaa !6
  %5208 = fmul contract float %5206, %5207
  %5209 = fsub contract float %5204, %5208
  store float %5209, float addrspace(3)* %5105, align 16, !tbaa !6
  %5210 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 21
  %5211 = load float, float addrspace(3)* %5210, align 4, !tbaa !6
  %5212 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 28), align 16, !tbaa !6
  %5213 = fmul contract float %5211, %5212
  %5214 = fsub contract float %5209, %5213
  store float %5214, float addrspace(3)* %5105, align 16, !tbaa !6
  %5215 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 22
  %5216 = load float, float addrspace(3)* %5215, align 8, !tbaa !6
  %5217 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 28), align 16, !tbaa !6
  %5218 = fmul contract float %5216, %5217
  %5219 = fsub contract float %5214, %5218
  store float %5219, float addrspace(3)* %5105, align 16, !tbaa !6
  %5220 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 23
  %5221 = load float, float addrspace(3)* %5220, align 4, !tbaa !6
  %5222 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 28), align 16, !tbaa !6
  %5223 = fmul contract float %5221, %5222
  %5224 = fsub contract float %5219, %5223
  store float %5224, float addrspace(3)* %5105, align 16, !tbaa !6
  %5225 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 24
  %5226 = load float, float addrspace(3)* %5225, align 16, !tbaa !6
  %5227 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 28), align 16, !tbaa !6
  %5228 = fmul contract float %5226, %5227
  %5229 = fsub contract float %5224, %5228
  store float %5229, float addrspace(3)* %5105, align 16, !tbaa !6
  %5230 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 25
  %5231 = load float, float addrspace(3)* %5230, align 4, !tbaa !6
  %5232 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 28), align 16, !tbaa !6
  %5233 = fmul contract float %5231, %5232
  %5234 = fsub contract float %5229, %5233
  store float %5234, float addrspace(3)* %5105, align 16, !tbaa !6
  %5235 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 26
  %5236 = load float, float addrspace(3)* %5235, align 8, !tbaa !6
  %5237 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 28), align 16, !tbaa !6
  %5238 = fmul contract float %5236, %5237
  %5239 = fsub contract float %5234, %5238
  store float %5239, float addrspace(3)* %5105, align 16, !tbaa !6
  %5240 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 27
  %5241 = load float, float addrspace(3)* %5240, align 4, !tbaa !6
  %5242 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 28), align 16, !tbaa !6
  %5243 = fmul contract float %5241, %5242
  %5244 = fsub contract float %5239, %5243
  store float %5244, float addrspace(3)* %5105, align 16, !tbaa !6
  %5245 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 28), align 16, !tbaa !6
  %5246 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 28
  %5247 = fdiv contract float %5244, %5245
  store float %5247, float addrspace(3)* %5246, align 16, !tbaa !6
  %5248 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 29
  %5249 = load float, float addrspace(3)* %5248, align 4, !tbaa !6
  %5250 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 29), align 4, !tbaa !6
  %5251 = fmul contract float %3133, %5250
  %5252 = fsub contract float %5249, %5251
  store float %5252, float addrspace(3)* %5248, align 4, !tbaa !6
  %5253 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %5254 = load float, float addrspace(3)* %5253, align 4, !tbaa !6
  %5255 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 29), align 4, !tbaa !6
  %5256 = fmul contract float %5254, %5255
  %5257 = fsub contract float %5252, %5256
  store float %5257, float addrspace(3)* %5248, align 4, !tbaa !6
  %5258 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %5259 = load float, float addrspace(3)* %5258, align 8, !tbaa !6
  %5260 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 29), align 4, !tbaa !6
  %5261 = fmul contract float %5259, %5260
  %5262 = fsub contract float %5257, %5261
  store float %5262, float addrspace(3)* %5248, align 4, !tbaa !6
  %5263 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %5264 = load float, float addrspace(3)* %5263, align 4, !tbaa !6
  %5265 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 29), align 4, !tbaa !6
  %5266 = fmul contract float %5264, %5265
  %5267 = fsub contract float %5262, %5266
  store float %5267, float addrspace(3)* %5248, align 4, !tbaa !6
  %5268 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %5269 = load float, float addrspace(3)* %5268, align 16, !tbaa !6
  %5270 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 29), align 4, !tbaa !6
  %5271 = fmul contract float %5269, %5270
  %5272 = fsub contract float %5267, %5271
  store float %5272, float addrspace(3)* %5248, align 4, !tbaa !6
  %5273 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %5274 = load float, float addrspace(3)* %5273, align 4, !tbaa !6
  %5275 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 29), align 4, !tbaa !6
  %5276 = fmul contract float %5274, %5275
  %5277 = fsub contract float %5272, %5276
  store float %5277, float addrspace(3)* %5248, align 4, !tbaa !6
  %5278 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %5279 = load float, float addrspace(3)* %5278, align 8, !tbaa !6
  %5280 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 29), align 4, !tbaa !6
  %5281 = fmul contract float %5279, %5280
  %5282 = fsub contract float %5277, %5281
  store float %5282, float addrspace(3)* %5248, align 4, !tbaa !6
  %5283 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %5284 = load float, float addrspace(3)* %5283, align 4, !tbaa !6
  %5285 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 29), align 4, !tbaa !6
  %5286 = fmul contract float %5284, %5285
  %5287 = fsub contract float %5282, %5286
  store float %5287, float addrspace(3)* %5248, align 4, !tbaa !6
  %5288 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %5289 = load float, float addrspace(3)* %5288, align 16, !tbaa !6
  %5290 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 29), align 4, !tbaa !6
  %5291 = fmul contract float %5289, %5290
  %5292 = fsub contract float %5287, %5291
  store float %5292, float addrspace(3)* %5248, align 4, !tbaa !6
  %5293 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %5294 = load float, float addrspace(3)* %5293, align 4, !tbaa !6
  %5295 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 29), align 4, !tbaa !6
  %5296 = fmul contract float %5294, %5295
  %5297 = fsub contract float %5292, %5296
  store float %5297, float addrspace(3)* %5248, align 4, !tbaa !6
  %5298 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %5299 = load float, float addrspace(3)* %5298, align 8, !tbaa !6
  %5300 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 29), align 4, !tbaa !6
  %5301 = fmul contract float %5299, %5300
  %5302 = fsub contract float %5297, %5301
  store float %5302, float addrspace(3)* %5248, align 4, !tbaa !6
  %5303 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %5304 = load float, float addrspace(3)* %5303, align 4, !tbaa !6
  %5305 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 29), align 4, !tbaa !6
  %5306 = fmul contract float %5304, %5305
  %5307 = fsub contract float %5302, %5306
  store float %5307, float addrspace(3)* %5248, align 4, !tbaa !6
  %5308 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %5309 = load float, float addrspace(3)* %5308, align 16, !tbaa !6
  %5310 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 29), align 4, !tbaa !6
  %5311 = fmul contract float %5309, %5310
  %5312 = fsub contract float %5307, %5311
  store float %5312, float addrspace(3)* %5248, align 4, !tbaa !6
  %5313 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %5314 = load float, float addrspace(3)* %5313, align 4, !tbaa !6
  %5315 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 29), align 4, !tbaa !6
  %5316 = fmul contract float %5314, %5315
  %5317 = fsub contract float %5312, %5316
  store float %5317, float addrspace(3)* %5248, align 4, !tbaa !6
  %5318 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %5319 = load float, float addrspace(3)* %5318, align 8, !tbaa !6
  %5320 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 29), align 4, !tbaa !6
  %5321 = fmul contract float %5319, %5320
  %5322 = fsub contract float %5317, %5321
  store float %5322, float addrspace(3)* %5248, align 4, !tbaa !6
  %5323 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %5324 = load float, float addrspace(3)* %5323, align 4, !tbaa !6
  %5325 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 29), align 4, !tbaa !6
  %5326 = fmul contract float %5324, %5325
  %5327 = fsub contract float %5322, %5326
  store float %5327, float addrspace(3)* %5248, align 4, !tbaa !6
  %5328 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %5329 = load float, float addrspace(3)* %5328, align 16, !tbaa !6
  %5330 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 29), align 4, !tbaa !6
  %5331 = fmul contract float %5329, %5330
  %5332 = fsub contract float %5327, %5331
  store float %5332, float addrspace(3)* %5248, align 4, !tbaa !6
  %5333 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %5334 = load float, float addrspace(3)* %5333, align 4, !tbaa !6
  %5335 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 29), align 4, !tbaa !6
  %5336 = fmul contract float %5334, %5335
  %5337 = fsub contract float %5332, %5336
  store float %5337, float addrspace(3)* %5248, align 4, !tbaa !6
  %5338 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 18
  %5339 = load float, float addrspace(3)* %5338, align 8, !tbaa !6
  %5340 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 29), align 4, !tbaa !6
  %5341 = fmul contract float %5339, %5340
  %5342 = fsub contract float %5337, %5341
  store float %5342, float addrspace(3)* %5248, align 4, !tbaa !6
  %5343 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 19
  %5344 = load float, float addrspace(3)* %5343, align 4, !tbaa !6
  %5345 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 29), align 4, !tbaa !6
  %5346 = fmul contract float %5344, %5345
  %5347 = fsub contract float %5342, %5346
  store float %5347, float addrspace(3)* %5248, align 4, !tbaa !6
  %5348 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 20
  %5349 = load float, float addrspace(3)* %5348, align 16, !tbaa !6
  %5350 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 29), align 4, !tbaa !6
  %5351 = fmul contract float %5349, %5350
  %5352 = fsub contract float %5347, %5351
  store float %5352, float addrspace(3)* %5248, align 4, !tbaa !6
  %5353 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 21
  %5354 = load float, float addrspace(3)* %5353, align 4, !tbaa !6
  %5355 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 29), align 4, !tbaa !6
  %5356 = fmul contract float %5354, %5355
  %5357 = fsub contract float %5352, %5356
  store float %5357, float addrspace(3)* %5248, align 4, !tbaa !6
  %5358 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 22
  %5359 = load float, float addrspace(3)* %5358, align 8, !tbaa !6
  %5360 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 29), align 4, !tbaa !6
  %5361 = fmul contract float %5359, %5360
  %5362 = fsub contract float %5357, %5361
  store float %5362, float addrspace(3)* %5248, align 4, !tbaa !6
  %5363 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 23
  %5364 = load float, float addrspace(3)* %5363, align 4, !tbaa !6
  %5365 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 29), align 4, !tbaa !6
  %5366 = fmul contract float %5364, %5365
  %5367 = fsub contract float %5362, %5366
  store float %5367, float addrspace(3)* %5248, align 4, !tbaa !6
  %5368 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 24
  %5369 = load float, float addrspace(3)* %5368, align 16, !tbaa !6
  %5370 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 29), align 4, !tbaa !6
  %5371 = fmul contract float %5369, %5370
  %5372 = fsub contract float %5367, %5371
  store float %5372, float addrspace(3)* %5248, align 4, !tbaa !6
  %5373 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 25
  %5374 = load float, float addrspace(3)* %5373, align 4, !tbaa !6
  %5375 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 29), align 4, !tbaa !6
  %5376 = fmul contract float %5374, %5375
  %5377 = fsub contract float %5372, %5376
  store float %5377, float addrspace(3)* %5248, align 4, !tbaa !6
  %5378 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 26
  %5379 = load float, float addrspace(3)* %5378, align 8, !tbaa !6
  %5380 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 29), align 4, !tbaa !6
  %5381 = fmul contract float %5379, %5380
  %5382 = fsub contract float %5377, %5381
  store float %5382, float addrspace(3)* %5248, align 4, !tbaa !6
  %5383 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 27
  %5384 = load float, float addrspace(3)* %5383, align 4, !tbaa !6
  %5385 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 29), align 4, !tbaa !6
  %5386 = fmul contract float %5384, %5385
  %5387 = fsub contract float %5382, %5386
  store float %5387, float addrspace(3)* %5248, align 4, !tbaa !6
  %5388 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 28
  %5389 = load float, float addrspace(3)* %5388, align 16, !tbaa !6
  %5390 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 29), align 4, !tbaa !6
  %5391 = fmul contract float %5389, %5390
  %5392 = fsub contract float %5387, %5391
  store float %5392, float addrspace(3)* %5248, align 4, !tbaa !6
  %5393 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 29), align 4, !tbaa !6
  %5394 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 29
  %5395 = fdiv contract float %5392, %5393
  store float %5395, float addrspace(3)* %5394, align 4, !tbaa !6
  %5396 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 30
  %5397 = load float, float addrspace(3)* %5396, align 8, !tbaa !6
  %5398 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 30), align 8, !tbaa !6
  %5399 = fmul contract float %3133, %5398
  %5400 = fsub contract float %5397, %5399
  store float %5400, float addrspace(3)* %5396, align 8, !tbaa !6
  %5401 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %5402 = load float, float addrspace(3)* %5401, align 4, !tbaa !6
  %5403 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 30), align 8, !tbaa !6
  %5404 = fmul contract float %5402, %5403
  %5405 = fsub contract float %5400, %5404
  store float %5405, float addrspace(3)* %5396, align 8, !tbaa !6
  %5406 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %5407 = load float, float addrspace(3)* %5406, align 8, !tbaa !6
  %5408 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 30), align 8, !tbaa !6
  %5409 = fmul contract float %5407, %5408
  %5410 = fsub contract float %5405, %5409
  store float %5410, float addrspace(3)* %5396, align 8, !tbaa !6
  %5411 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %5412 = load float, float addrspace(3)* %5411, align 4, !tbaa !6
  %5413 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 30), align 8, !tbaa !6
  %5414 = fmul contract float %5412, %5413
  %5415 = fsub contract float %5410, %5414
  store float %5415, float addrspace(3)* %5396, align 8, !tbaa !6
  %5416 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %5417 = load float, float addrspace(3)* %5416, align 16, !tbaa !6
  %5418 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 30), align 8, !tbaa !6
  %5419 = fmul contract float %5417, %5418
  %5420 = fsub contract float %5415, %5419
  store float %5420, float addrspace(3)* %5396, align 8, !tbaa !6
  %5421 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %5422 = load float, float addrspace(3)* %5421, align 4, !tbaa !6
  %5423 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 30), align 8, !tbaa !6
  %5424 = fmul contract float %5422, %5423
  %5425 = fsub contract float %5420, %5424
  store float %5425, float addrspace(3)* %5396, align 8, !tbaa !6
  %5426 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %5427 = load float, float addrspace(3)* %5426, align 8, !tbaa !6
  %5428 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 30), align 8, !tbaa !6
  %5429 = fmul contract float %5427, %5428
  %5430 = fsub contract float %5425, %5429
  store float %5430, float addrspace(3)* %5396, align 8, !tbaa !6
  %5431 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %5432 = load float, float addrspace(3)* %5431, align 4, !tbaa !6
  %5433 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 30), align 8, !tbaa !6
  %5434 = fmul contract float %5432, %5433
  %5435 = fsub contract float %5430, %5434
  store float %5435, float addrspace(3)* %5396, align 8, !tbaa !6
  %5436 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %5437 = load float, float addrspace(3)* %5436, align 16, !tbaa !6
  %5438 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 30), align 8, !tbaa !6
  %5439 = fmul contract float %5437, %5438
  %5440 = fsub contract float %5435, %5439
  store float %5440, float addrspace(3)* %5396, align 8, !tbaa !6
  %5441 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %5442 = load float, float addrspace(3)* %5441, align 4, !tbaa !6
  %5443 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 30), align 8, !tbaa !6
  %5444 = fmul contract float %5442, %5443
  %5445 = fsub contract float %5440, %5444
  store float %5445, float addrspace(3)* %5396, align 8, !tbaa !6
  %5446 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %5447 = load float, float addrspace(3)* %5446, align 8, !tbaa !6
  %5448 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 30), align 8, !tbaa !6
  %5449 = fmul contract float %5447, %5448
  %5450 = fsub contract float %5445, %5449
  store float %5450, float addrspace(3)* %5396, align 8, !tbaa !6
  %5451 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %5452 = load float, float addrspace(3)* %5451, align 4, !tbaa !6
  %5453 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 30), align 8, !tbaa !6
  %5454 = fmul contract float %5452, %5453
  %5455 = fsub contract float %5450, %5454
  store float %5455, float addrspace(3)* %5396, align 8, !tbaa !6
  %5456 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %5457 = load float, float addrspace(3)* %5456, align 16, !tbaa !6
  %5458 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 30), align 8, !tbaa !6
  %5459 = fmul contract float %5457, %5458
  %5460 = fsub contract float %5455, %5459
  store float %5460, float addrspace(3)* %5396, align 8, !tbaa !6
  %5461 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %5462 = load float, float addrspace(3)* %5461, align 4, !tbaa !6
  %5463 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 30), align 8, !tbaa !6
  %5464 = fmul contract float %5462, %5463
  %5465 = fsub contract float %5460, %5464
  store float %5465, float addrspace(3)* %5396, align 8, !tbaa !6
  %5466 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %5467 = load float, float addrspace(3)* %5466, align 8, !tbaa !6
  %5468 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 30), align 8, !tbaa !6
  %5469 = fmul contract float %5467, %5468
  %5470 = fsub contract float %5465, %5469
  store float %5470, float addrspace(3)* %5396, align 8, !tbaa !6
  %5471 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %5472 = load float, float addrspace(3)* %5471, align 4, !tbaa !6
  %5473 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 30), align 8, !tbaa !6
  %5474 = fmul contract float %5472, %5473
  %5475 = fsub contract float %5470, %5474
  store float %5475, float addrspace(3)* %5396, align 8, !tbaa !6
  %5476 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %5477 = load float, float addrspace(3)* %5476, align 16, !tbaa !6
  %5478 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 30), align 8, !tbaa !6
  %5479 = fmul contract float %5477, %5478
  %5480 = fsub contract float %5475, %5479
  store float %5480, float addrspace(3)* %5396, align 8, !tbaa !6
  %5481 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %5482 = load float, float addrspace(3)* %5481, align 4, !tbaa !6
  %5483 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 30), align 8, !tbaa !6
  %5484 = fmul contract float %5482, %5483
  %5485 = fsub contract float %5480, %5484
  store float %5485, float addrspace(3)* %5396, align 8, !tbaa !6
  %5486 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 18
  %5487 = load float, float addrspace(3)* %5486, align 8, !tbaa !6
  %5488 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 30), align 8, !tbaa !6
  %5489 = fmul contract float %5487, %5488
  %5490 = fsub contract float %5485, %5489
  store float %5490, float addrspace(3)* %5396, align 8, !tbaa !6
  %5491 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 19
  %5492 = load float, float addrspace(3)* %5491, align 4, !tbaa !6
  %5493 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 30), align 8, !tbaa !6
  %5494 = fmul contract float %5492, %5493
  %5495 = fsub contract float %5490, %5494
  store float %5495, float addrspace(3)* %5396, align 8, !tbaa !6
  %5496 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 20
  %5497 = load float, float addrspace(3)* %5496, align 16, !tbaa !6
  %5498 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 30), align 8, !tbaa !6
  %5499 = fmul contract float %5497, %5498
  %5500 = fsub contract float %5495, %5499
  store float %5500, float addrspace(3)* %5396, align 8, !tbaa !6
  %5501 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 21
  %5502 = load float, float addrspace(3)* %5501, align 4, !tbaa !6
  %5503 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 30), align 8, !tbaa !6
  %5504 = fmul contract float %5502, %5503
  %5505 = fsub contract float %5500, %5504
  store float %5505, float addrspace(3)* %5396, align 8, !tbaa !6
  %5506 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 22
  %5507 = load float, float addrspace(3)* %5506, align 8, !tbaa !6
  %5508 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 30), align 8, !tbaa !6
  %5509 = fmul contract float %5507, %5508
  %5510 = fsub contract float %5505, %5509
  store float %5510, float addrspace(3)* %5396, align 8, !tbaa !6
  %5511 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 23
  %5512 = load float, float addrspace(3)* %5511, align 4, !tbaa !6
  %5513 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 30), align 8, !tbaa !6
  %5514 = fmul contract float %5512, %5513
  %5515 = fsub contract float %5510, %5514
  store float %5515, float addrspace(3)* %5396, align 8, !tbaa !6
  %5516 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 24
  %5517 = load float, float addrspace(3)* %5516, align 16, !tbaa !6
  %5518 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 30), align 8, !tbaa !6
  %5519 = fmul contract float %5517, %5518
  %5520 = fsub contract float %5515, %5519
  store float %5520, float addrspace(3)* %5396, align 8, !tbaa !6
  %5521 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 25
  %5522 = load float, float addrspace(3)* %5521, align 4, !tbaa !6
  %5523 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 30), align 8, !tbaa !6
  %5524 = fmul contract float %5522, %5523
  %5525 = fsub contract float %5520, %5524
  store float %5525, float addrspace(3)* %5396, align 8, !tbaa !6
  %5526 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 26
  %5527 = load float, float addrspace(3)* %5526, align 8, !tbaa !6
  %5528 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 30), align 8, !tbaa !6
  %5529 = fmul contract float %5527, %5528
  %5530 = fsub contract float %5525, %5529
  store float %5530, float addrspace(3)* %5396, align 8, !tbaa !6
  %5531 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 27
  %5532 = load float, float addrspace(3)* %5531, align 4, !tbaa !6
  %5533 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 30), align 8, !tbaa !6
  %5534 = fmul contract float %5532, %5533
  %5535 = fsub contract float %5530, %5534
  store float %5535, float addrspace(3)* %5396, align 8, !tbaa !6
  %5536 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 28
  %5537 = load float, float addrspace(3)* %5536, align 16, !tbaa !6
  %5538 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 30), align 8, !tbaa !6
  %5539 = fmul contract float %5537, %5538
  %5540 = fsub contract float %5535, %5539
  store float %5540, float addrspace(3)* %5396, align 8, !tbaa !6
  %5541 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 29
  %5542 = load float, float addrspace(3)* %5541, align 4, !tbaa !6
  %5543 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 30), align 8, !tbaa !6
  %5544 = fmul contract float %5542, %5543
  %5545 = fsub contract float %5540, %5544
  store float %5545, float addrspace(3)* %5396, align 8, !tbaa !6
  %5546 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 30), align 8, !tbaa !6
  %5547 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 30
  %5548 = fdiv contract float %5545, %5546
  store float %5548, float addrspace(3)* %5547, align 8, !tbaa !6
  %5549 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 31
  %5550 = load float, float addrspace(3)* %5549, align 4, !tbaa !6
  %5551 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 31), align 4, !tbaa !6
  %5552 = fmul contract float %3133, %5551
  %5553 = fsub contract float %5550, %5552
  store float %5553, float addrspace(3)* %5549, align 4, !tbaa !6
  %5554 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 1
  %5555 = load float, float addrspace(3)* %5554, align 4, !tbaa !6
  %5556 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 31), align 4, !tbaa !6
  %5557 = fmul contract float %5555, %5556
  %5558 = fsub contract float %5553, %5557
  store float %5558, float addrspace(3)* %5549, align 4, !tbaa !6
  %5559 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 2
  %5560 = load float, float addrspace(3)* %5559, align 8, !tbaa !6
  %5561 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 31), align 4, !tbaa !6
  %5562 = fmul contract float %5560, %5561
  %5563 = fsub contract float %5558, %5562
  store float %5563, float addrspace(3)* %5549, align 4, !tbaa !6
  %5564 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 3
  %5565 = load float, float addrspace(3)* %5564, align 4, !tbaa !6
  %5566 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 31), align 4, !tbaa !6
  %5567 = fmul contract float %5565, %5566
  %5568 = fsub contract float %5563, %5567
  store float %5568, float addrspace(3)* %5549, align 4, !tbaa !6
  %5569 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 4
  %5570 = load float, float addrspace(3)* %5569, align 16, !tbaa !6
  %5571 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 31), align 4, !tbaa !6
  %5572 = fmul contract float %5570, %5571
  %5573 = fsub contract float %5568, %5572
  store float %5573, float addrspace(3)* %5549, align 4, !tbaa !6
  %5574 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 5
  %5575 = load float, float addrspace(3)* %5574, align 4, !tbaa !6
  %5576 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 31), align 4, !tbaa !6
  %5577 = fmul contract float %5575, %5576
  %5578 = fsub contract float %5573, %5577
  store float %5578, float addrspace(3)* %5549, align 4, !tbaa !6
  %5579 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 6
  %5580 = load float, float addrspace(3)* %5579, align 8, !tbaa !6
  %5581 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 31), align 4, !tbaa !6
  %5582 = fmul contract float %5580, %5581
  %5583 = fsub contract float %5578, %5582
  store float %5583, float addrspace(3)* %5549, align 4, !tbaa !6
  %5584 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 7
  %5585 = load float, float addrspace(3)* %5584, align 4, !tbaa !6
  %5586 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 31), align 4, !tbaa !6
  %5587 = fmul contract float %5585, %5586
  %5588 = fsub contract float %5583, %5587
  store float %5588, float addrspace(3)* %5549, align 4, !tbaa !6
  %5589 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 8
  %5590 = load float, float addrspace(3)* %5589, align 16, !tbaa !6
  %5591 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 31), align 4, !tbaa !6
  %5592 = fmul contract float %5590, %5591
  %5593 = fsub contract float %5588, %5592
  store float %5593, float addrspace(3)* %5549, align 4, !tbaa !6
  %5594 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 9
  %5595 = load float, float addrspace(3)* %5594, align 4, !tbaa !6
  %5596 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 31), align 4, !tbaa !6
  %5597 = fmul contract float %5595, %5596
  %5598 = fsub contract float %5593, %5597
  store float %5598, float addrspace(3)* %5549, align 4, !tbaa !6
  %5599 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 10
  %5600 = load float, float addrspace(3)* %5599, align 8, !tbaa !6
  %5601 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 31), align 4, !tbaa !6
  %5602 = fmul contract float %5600, %5601
  %5603 = fsub contract float %5598, %5602
  store float %5603, float addrspace(3)* %5549, align 4, !tbaa !6
  %5604 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 11
  %5605 = load float, float addrspace(3)* %5604, align 4, !tbaa !6
  %5606 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 31), align 4, !tbaa !6
  %5607 = fmul contract float %5605, %5606
  %5608 = fsub contract float %5603, %5607
  store float %5608, float addrspace(3)* %5549, align 4, !tbaa !6
  %5609 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 12
  %5610 = load float, float addrspace(3)* %5609, align 16, !tbaa !6
  %5611 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 31), align 4, !tbaa !6
  %5612 = fmul contract float %5610, %5611
  %5613 = fsub contract float %5608, %5612
  store float %5613, float addrspace(3)* %5549, align 4, !tbaa !6
  %5614 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 13
  %5615 = load float, float addrspace(3)* %5614, align 4, !tbaa !6
  %5616 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 31), align 4, !tbaa !6
  %5617 = fmul contract float %5615, %5616
  %5618 = fsub contract float %5613, %5617
  store float %5618, float addrspace(3)* %5549, align 4, !tbaa !6
  %5619 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 14
  %5620 = load float, float addrspace(3)* %5619, align 8, !tbaa !6
  %5621 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 31), align 4, !tbaa !6
  %5622 = fmul contract float %5620, %5621
  %5623 = fsub contract float %5618, %5622
  store float %5623, float addrspace(3)* %5549, align 4, !tbaa !6
  %5624 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 15
  %5625 = load float, float addrspace(3)* %5624, align 4, !tbaa !6
  %5626 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 31), align 4, !tbaa !6
  %5627 = fmul contract float %5625, %5626
  %5628 = fsub contract float %5623, %5627
  store float %5628, float addrspace(3)* %5549, align 4, !tbaa !6
  %5629 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 16
  %5630 = load float, float addrspace(3)* %5629, align 16, !tbaa !6
  %5631 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 16, i32 31), align 4, !tbaa !6
  %5632 = fmul contract float %5630, %5631
  %5633 = fsub contract float %5628, %5632
  store float %5633, float addrspace(3)* %5549, align 4, !tbaa !6
  %5634 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 17
  %5635 = load float, float addrspace(3)* %5634, align 4, !tbaa !6
  %5636 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 17, i32 31), align 4, !tbaa !6
  %5637 = fmul contract float %5635, %5636
  %5638 = fsub contract float %5633, %5637
  store float %5638, float addrspace(3)* %5549, align 4, !tbaa !6
  %5639 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 18
  %5640 = load float, float addrspace(3)* %5639, align 8, !tbaa !6
  %5641 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 18, i32 31), align 4, !tbaa !6
  %5642 = fmul contract float %5640, %5641
  %5643 = fsub contract float %5638, %5642
  store float %5643, float addrspace(3)* %5549, align 4, !tbaa !6
  %5644 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 19
  %5645 = load float, float addrspace(3)* %5644, align 4, !tbaa !6
  %5646 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 19, i32 31), align 4, !tbaa !6
  %5647 = fmul contract float %5645, %5646
  %5648 = fsub contract float %5643, %5647
  store float %5648, float addrspace(3)* %5549, align 4, !tbaa !6
  %5649 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 20
  %5650 = load float, float addrspace(3)* %5649, align 16, !tbaa !6
  %5651 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 20, i32 31), align 4, !tbaa !6
  %5652 = fmul contract float %5650, %5651
  %5653 = fsub contract float %5648, %5652
  store float %5653, float addrspace(3)* %5549, align 4, !tbaa !6
  %5654 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 21
  %5655 = load float, float addrspace(3)* %5654, align 4, !tbaa !6
  %5656 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 21, i32 31), align 4, !tbaa !6
  %5657 = fmul contract float %5655, %5656
  %5658 = fsub contract float %5653, %5657
  store float %5658, float addrspace(3)* %5549, align 4, !tbaa !6
  %5659 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 22
  %5660 = load float, float addrspace(3)* %5659, align 8, !tbaa !6
  %5661 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 22, i32 31), align 4, !tbaa !6
  %5662 = fmul contract float %5660, %5661
  %5663 = fsub contract float %5658, %5662
  store float %5663, float addrspace(3)* %5549, align 4, !tbaa !6
  %5664 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 23
  %5665 = load float, float addrspace(3)* %5664, align 4, !tbaa !6
  %5666 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 23, i32 31), align 4, !tbaa !6
  %5667 = fmul contract float %5665, %5666
  %5668 = fsub contract float %5663, %5667
  store float %5668, float addrspace(3)* %5549, align 4, !tbaa !6
  %5669 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 24
  %5670 = load float, float addrspace(3)* %5669, align 16, !tbaa !6
  %5671 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 24, i32 31), align 4, !tbaa !6
  %5672 = fmul contract float %5670, %5671
  %5673 = fsub contract float %5668, %5672
  store float %5673, float addrspace(3)* %5549, align 4, !tbaa !6
  %5674 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 25
  %5675 = load float, float addrspace(3)* %5674, align 4, !tbaa !6
  %5676 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 25, i32 31), align 4, !tbaa !6
  %5677 = fmul contract float %5675, %5676
  %5678 = fsub contract float %5673, %5677
  store float %5678, float addrspace(3)* %5549, align 4, !tbaa !6
  %5679 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 26
  %5680 = load float, float addrspace(3)* %5679, align 8, !tbaa !6
  %5681 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 26, i32 31), align 4, !tbaa !6
  %5682 = fmul contract float %5680, %5681
  %5683 = fsub contract float %5678, %5682
  store float %5683, float addrspace(3)* %5549, align 4, !tbaa !6
  %5684 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 27
  %5685 = load float, float addrspace(3)* %5684, align 4, !tbaa !6
  %5686 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 27, i32 31), align 4, !tbaa !6
  %5687 = fmul contract float %5685, %5686
  %5688 = fsub contract float %5683, %5687
  store float %5688, float addrspace(3)* %5549, align 4, !tbaa !6
  %5689 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 28
  %5690 = load float, float addrspace(3)* %5689, align 16, !tbaa !6
  %5691 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 28, i32 31), align 4, !tbaa !6
  %5692 = fmul contract float %5690, %5691
  %5693 = fsub contract float %5688, %5692
  store float %5693, float addrspace(3)* %5549, align 4, !tbaa !6
  %5694 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 29
  %5695 = load float, float addrspace(3)* %5694, align 4, !tbaa !6
  %5696 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 29, i32 31), align 4, !tbaa !6
  %5697 = fmul contract float %5695, %5696
  %5698 = fsub contract float %5693, %5697
  store float %5698, float addrspace(3)* %5549, align 4, !tbaa !6
  %5699 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 30
  %5700 = load float, float addrspace(3)* %5699, align 8, !tbaa !6
  %5701 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 30, i32 31), align 4, !tbaa !6
  %5702 = fmul contract float %5700, %5701
  %5703 = fsub contract float %5698, %5702
  store float %5703, float addrspace(3)* %5549, align 4, !tbaa !6
  %5704 = load float, float addrspace(3)* getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 31, i32 31), align 4, !tbaa !6
  %5705 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %3128, i32 31
  %5706 = fdiv contract float %5703, %5704
  store float %5706, float addrspace(3)* %5705, align 4, !tbaa !6
  br label %5707

5707:                                             ; preds = %3127, %584
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %6, label %5708, label %5900

5708:                                             ; preds = %5707
  %5709 = add nsw i32 %2, 1
  %5710 = mul nsw i32 %5709, %1
  %5711 = add nsw i32 %5710, %2
  %5712 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %5713 = zext i32 %5712 to i64
  %5714 = shl nuw nsw i64 %5713, 5
  %5715 = add nuw nsw i64 %5, 32
  %5716 = add nuw nsw i64 %5715, %5714
  %5717 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %5718 = load float, float addrspace(3)* %5717, align 4, !tbaa !6
  %5719 = sext i32 %5711 to i64
  %5720 = add nsw i64 %5716, %5719
  %5721 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5720
  store float %5718, float addrspace(1)* %5721, align 4, !tbaa !6
  %5722 = add nsw i32 %5711, %1
  %5723 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %5724 = load float, float addrspace(3)* %5723, align 4, !tbaa !6
  %5725 = sext i32 %5722 to i64
  %5726 = add nsw i64 %5716, %5725
  %5727 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5726
  store float %5724, float addrspace(1)* %5727, align 4, !tbaa !6
  %5728 = add nsw i32 %5722, %1
  %5729 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %5730 = load float, float addrspace(3)* %5729, align 4, !tbaa !6
  %5731 = sext i32 %5728 to i64
  %5732 = add nsw i64 %5716, %5731
  %5733 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5732
  store float %5730, float addrspace(1)* %5733, align 4, !tbaa !6
  %5734 = add nsw i32 %5728, %1
  %5735 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %5736 = load float, float addrspace(3)* %5735, align 4, !tbaa !6
  %5737 = sext i32 %5734 to i64
  %5738 = add nsw i64 %5716, %5737
  %5739 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5738
  store float %5736, float addrspace(1)* %5739, align 4, !tbaa !6
  %5740 = add nsw i32 %5734, %1
  %5741 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %5742 = load float, float addrspace(3)* %5741, align 4, !tbaa !6
  %5743 = sext i32 %5740 to i64
  %5744 = add nsw i64 %5716, %5743
  %5745 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5744
  store float %5742, float addrspace(1)* %5745, align 4, !tbaa !6
  %5746 = add nsw i32 %5740, %1
  %5747 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %5748 = load float, float addrspace(3)* %5747, align 4, !tbaa !6
  %5749 = sext i32 %5746 to i64
  %5750 = add nsw i64 %5716, %5749
  %5751 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5750
  store float %5748, float addrspace(1)* %5751, align 4, !tbaa !6
  %5752 = add nsw i32 %5746, %1
  %5753 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %5754 = load float, float addrspace(3)* %5753, align 4, !tbaa !6
  %5755 = sext i32 %5752 to i64
  %5756 = add nsw i64 %5716, %5755
  %5757 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5756
  store float %5754, float addrspace(1)* %5757, align 4, !tbaa !6
  %5758 = add nsw i32 %5752, %1
  %5759 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %5760 = load float, float addrspace(3)* %5759, align 4, !tbaa !6
  %5761 = sext i32 %5758 to i64
  %5762 = add nsw i64 %5716, %5761
  %5763 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5762
  store float %5760, float addrspace(1)* %5763, align 4, !tbaa !6
  %5764 = add nsw i32 %5758, %1
  %5765 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %5766 = load float, float addrspace(3)* %5765, align 4, !tbaa !6
  %5767 = sext i32 %5764 to i64
  %5768 = add nsw i64 %5716, %5767
  %5769 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5768
  store float %5766, float addrspace(1)* %5769, align 4, !tbaa !6
  %5770 = add nsw i32 %5764, %1
  %5771 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %5772 = load float, float addrspace(3)* %5771, align 4, !tbaa !6
  %5773 = sext i32 %5770 to i64
  %5774 = add nsw i64 %5716, %5773
  %5775 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5774
  store float %5772, float addrspace(1)* %5775, align 4, !tbaa !6
  %5776 = add nsw i32 %5770, %1
  %5777 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %5778 = load float, float addrspace(3)* %5777, align 4, !tbaa !6
  %5779 = sext i32 %5776 to i64
  %5780 = add nsw i64 %5716, %5779
  %5781 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5780
  store float %5778, float addrspace(1)* %5781, align 4, !tbaa !6
  %5782 = add nsw i32 %5776, %1
  %5783 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %5784 = load float, float addrspace(3)* %5783, align 4, !tbaa !6
  %5785 = sext i32 %5782 to i64
  %5786 = add nsw i64 %5716, %5785
  %5787 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5786
  store float %5784, float addrspace(1)* %5787, align 4, !tbaa !6
  %5788 = add nsw i32 %5782, %1
  %5789 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %5790 = load float, float addrspace(3)* %5789, align 4, !tbaa !6
  %5791 = sext i32 %5788 to i64
  %5792 = add nsw i64 %5716, %5791
  %5793 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5792
  store float %5790, float addrspace(1)* %5793, align 4, !tbaa !6
  %5794 = add nsw i32 %5788, %1
  %5795 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %5796 = load float, float addrspace(3)* %5795, align 4, !tbaa !6
  %5797 = sext i32 %5794 to i64
  %5798 = add nsw i64 %5716, %5797
  %5799 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5798
  store float %5796, float addrspace(1)* %5799, align 4, !tbaa !6
  %5800 = add nsw i32 %5794, %1
  %5801 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %5802 = load float, float addrspace(3)* %5801, align 4, !tbaa !6
  %5803 = sext i32 %5800 to i64
  %5804 = add nsw i64 %5716, %5803
  %5805 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5804
  store float %5802, float addrspace(1)* %5805, align 4, !tbaa !6
  %5806 = add nsw i32 %5800, %1
  %5807 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 16, i32 %4
  %5808 = load float, float addrspace(3)* %5807, align 4, !tbaa !6
  %5809 = sext i32 %5806 to i64
  %5810 = add nsw i64 %5716, %5809
  %5811 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5810
  store float %5808, float addrspace(1)* %5811, align 4, !tbaa !6
  %5812 = add nsw i32 %5806, %1
  %5813 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 17, i32 %4
  %5814 = load float, float addrspace(3)* %5813, align 4, !tbaa !6
  %5815 = sext i32 %5812 to i64
  %5816 = add nsw i64 %5716, %5815
  %5817 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5816
  store float %5814, float addrspace(1)* %5817, align 4, !tbaa !6
  %5818 = add nsw i32 %5812, %1
  %5819 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 18, i32 %4
  %5820 = load float, float addrspace(3)* %5819, align 4, !tbaa !6
  %5821 = sext i32 %5818 to i64
  %5822 = add nsw i64 %5716, %5821
  %5823 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5822
  store float %5820, float addrspace(1)* %5823, align 4, !tbaa !6
  %5824 = add nsw i32 %5818, %1
  %5825 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 19, i32 %4
  %5826 = load float, float addrspace(3)* %5825, align 4, !tbaa !6
  %5827 = sext i32 %5824 to i64
  %5828 = add nsw i64 %5716, %5827
  %5829 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5828
  store float %5826, float addrspace(1)* %5829, align 4, !tbaa !6
  %5830 = add nsw i32 %5824, %1
  %5831 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 20, i32 %4
  %5832 = load float, float addrspace(3)* %5831, align 4, !tbaa !6
  %5833 = sext i32 %5830 to i64
  %5834 = add nsw i64 %5716, %5833
  %5835 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5834
  store float %5832, float addrspace(1)* %5835, align 4, !tbaa !6
  %5836 = add nsw i32 %5830, %1
  %5837 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 21, i32 %4
  %5838 = load float, float addrspace(3)* %5837, align 4, !tbaa !6
  %5839 = sext i32 %5836 to i64
  %5840 = add nsw i64 %5716, %5839
  %5841 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5840
  store float %5838, float addrspace(1)* %5841, align 4, !tbaa !6
  %5842 = add nsw i32 %5836, %1
  %5843 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 22, i32 %4
  %5844 = load float, float addrspace(3)* %5843, align 4, !tbaa !6
  %5845 = sext i32 %5842 to i64
  %5846 = add nsw i64 %5716, %5845
  %5847 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5846
  store float %5844, float addrspace(1)* %5847, align 4, !tbaa !6
  %5848 = add nsw i32 %5842, %1
  %5849 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 23, i32 %4
  %5850 = load float, float addrspace(3)* %5849, align 4, !tbaa !6
  %5851 = sext i32 %5848 to i64
  %5852 = add nsw i64 %5716, %5851
  %5853 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5852
  store float %5850, float addrspace(1)* %5853, align 4, !tbaa !6
  %5854 = add nsw i32 %5848, %1
  %5855 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 24, i32 %4
  %5856 = load float, float addrspace(3)* %5855, align 4, !tbaa !6
  %5857 = sext i32 %5854 to i64
  %5858 = add nsw i64 %5716, %5857
  %5859 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5858
  store float %5856, float addrspace(1)* %5859, align 4, !tbaa !6
  %5860 = add nsw i32 %5854, %1
  %5861 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 25, i32 %4
  %5862 = load float, float addrspace(3)* %5861, align 4, !tbaa !6
  %5863 = sext i32 %5860 to i64
  %5864 = add nsw i64 %5716, %5863
  %5865 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5864
  store float %5862, float addrspace(1)* %5865, align 4, !tbaa !6
  %5866 = add nsw i32 %5860, %1
  %5867 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 26, i32 %4
  %5868 = load float, float addrspace(3)* %5867, align 4, !tbaa !6
  %5869 = sext i32 %5866 to i64
  %5870 = add nsw i64 %5716, %5869
  %5871 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5870
  store float %5868, float addrspace(1)* %5871, align 4, !tbaa !6
  %5872 = add nsw i32 %5866, %1
  %5873 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 27, i32 %4
  %5874 = load float, float addrspace(3)* %5873, align 4, !tbaa !6
  %5875 = sext i32 %5872 to i64
  %5876 = add nsw i64 %5716, %5875
  %5877 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5876
  store float %5874, float addrspace(1)* %5877, align 4, !tbaa !6
  %5878 = add nsw i32 %5872, %1
  %5879 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 28, i32 %4
  %5880 = load float, float addrspace(3)* %5879, align 4, !tbaa !6
  %5881 = sext i32 %5878 to i64
  %5882 = add nsw i64 %5716, %5881
  %5883 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5882
  store float %5880, float addrspace(1)* %5883, align 4, !tbaa !6
  %5884 = add nsw i32 %5878, %1
  %5885 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 29, i32 %4
  %5886 = load float, float addrspace(3)* %5885, align 4, !tbaa !6
  %5887 = sext i32 %5884 to i64
  %5888 = add nsw i64 %5716, %5887
  %5889 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5888
  store float %5886, float addrspace(1)* %5889, align 4, !tbaa !6
  %5890 = add nsw i32 %5884, %1
  %5891 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 30, i32 %4
  %5892 = load float, float addrspace(3)* %5891, align 4, !tbaa !6
  %5893 = sext i32 %5890 to i64
  %5894 = add nsw i64 %5716, %5893
  %5895 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5894
  store float %5892, float addrspace(1)* %5895, align 4, !tbaa !6
  %5896 = add nsw i32 %5890, %1
  %5897 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 31, i32 %4
  %5898 = sext i32 %5896 to i64
  %5899 = add nsw i64 %5716, %5898
  br label %6097

5900:                                             ; preds = %5707
  %5901 = add nsw i32 %4, -32
  %5902 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %5903 = shl i32 %5902, 5
  %5904 = add i32 %2, 32
  %5905 = add i32 %5904, %5903
  %5906 = mul i32 %5905, %1
  %5907 = add i32 %5906, %2
  %5908 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 0, i32 %5901
  %5909 = load float, float addrspace(3)* %5908, align 4, !tbaa !6
  %5910 = add nsw i32 %5907, %5901
  %5911 = sext i32 %5910 to i64
  %5912 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5911
  store float %5909, float addrspace(1)* %5912, align 4, !tbaa !6
  %5913 = add nsw i32 %5907, %1
  %5914 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 1, i32 %5901
  %5915 = load float, float addrspace(3)* %5914, align 4, !tbaa !6
  %5916 = add nsw i32 %5913, %5901
  %5917 = sext i32 %5916 to i64
  %5918 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5917
  store float %5915, float addrspace(1)* %5918, align 4, !tbaa !6
  %5919 = add nsw i32 %5913, %1
  %5920 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 2, i32 %5901
  %5921 = load float, float addrspace(3)* %5920, align 4, !tbaa !6
  %5922 = add nsw i32 %5919, %5901
  %5923 = sext i32 %5922 to i64
  %5924 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5923
  store float %5921, float addrspace(1)* %5924, align 4, !tbaa !6
  %5925 = add nsw i32 %5919, %1
  %5926 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 3, i32 %5901
  %5927 = load float, float addrspace(3)* %5926, align 4, !tbaa !6
  %5928 = add nsw i32 %5925, %5901
  %5929 = sext i32 %5928 to i64
  %5930 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5929
  store float %5927, float addrspace(1)* %5930, align 4, !tbaa !6
  %5931 = add nsw i32 %5925, %1
  %5932 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 4, i32 %5901
  %5933 = load float, float addrspace(3)* %5932, align 4, !tbaa !6
  %5934 = add nsw i32 %5931, %5901
  %5935 = sext i32 %5934 to i64
  %5936 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5935
  store float %5933, float addrspace(1)* %5936, align 4, !tbaa !6
  %5937 = add nsw i32 %5931, %1
  %5938 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 5, i32 %5901
  %5939 = load float, float addrspace(3)* %5938, align 4, !tbaa !6
  %5940 = add nsw i32 %5937, %5901
  %5941 = sext i32 %5940 to i64
  %5942 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5941
  store float %5939, float addrspace(1)* %5942, align 4, !tbaa !6
  %5943 = add nsw i32 %5937, %1
  %5944 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 6, i32 %5901
  %5945 = load float, float addrspace(3)* %5944, align 4, !tbaa !6
  %5946 = add nsw i32 %5943, %5901
  %5947 = sext i32 %5946 to i64
  %5948 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5947
  store float %5945, float addrspace(1)* %5948, align 4, !tbaa !6
  %5949 = add nsw i32 %5943, %1
  %5950 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 7, i32 %5901
  %5951 = load float, float addrspace(3)* %5950, align 4, !tbaa !6
  %5952 = add nsw i32 %5949, %5901
  %5953 = sext i32 %5952 to i64
  %5954 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5953
  store float %5951, float addrspace(1)* %5954, align 4, !tbaa !6
  %5955 = add nsw i32 %5949, %1
  %5956 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 8, i32 %5901
  %5957 = load float, float addrspace(3)* %5956, align 4, !tbaa !6
  %5958 = add nsw i32 %5955, %5901
  %5959 = sext i32 %5958 to i64
  %5960 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5959
  store float %5957, float addrspace(1)* %5960, align 4, !tbaa !6
  %5961 = add nsw i32 %5955, %1
  %5962 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 9, i32 %5901
  %5963 = load float, float addrspace(3)* %5962, align 4, !tbaa !6
  %5964 = add nsw i32 %5961, %5901
  %5965 = sext i32 %5964 to i64
  %5966 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5965
  store float %5963, float addrspace(1)* %5966, align 4, !tbaa !6
  %5967 = add nsw i32 %5961, %1
  %5968 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 10, i32 %5901
  %5969 = load float, float addrspace(3)* %5968, align 4, !tbaa !6
  %5970 = add nsw i32 %5967, %5901
  %5971 = sext i32 %5970 to i64
  %5972 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5971
  store float %5969, float addrspace(1)* %5972, align 4, !tbaa !6
  %5973 = add nsw i32 %5967, %1
  %5974 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 11, i32 %5901
  %5975 = load float, float addrspace(3)* %5974, align 4, !tbaa !6
  %5976 = add nsw i32 %5973, %5901
  %5977 = sext i32 %5976 to i64
  %5978 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5977
  store float %5975, float addrspace(1)* %5978, align 4, !tbaa !6
  %5979 = add nsw i32 %5973, %1
  %5980 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 12, i32 %5901
  %5981 = load float, float addrspace(3)* %5980, align 4, !tbaa !6
  %5982 = add nsw i32 %5979, %5901
  %5983 = sext i32 %5982 to i64
  %5984 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5983
  store float %5981, float addrspace(1)* %5984, align 4, !tbaa !6
  %5985 = add nsw i32 %5979, %1
  %5986 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 13, i32 %5901
  %5987 = load float, float addrspace(3)* %5986, align 4, !tbaa !6
  %5988 = add nsw i32 %5985, %5901
  %5989 = sext i32 %5988 to i64
  %5990 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5989
  store float %5987, float addrspace(1)* %5990, align 4, !tbaa !6
  %5991 = add nsw i32 %5985, %1
  %5992 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 14, i32 %5901
  %5993 = load float, float addrspace(3)* %5992, align 4, !tbaa !6
  %5994 = add nsw i32 %5991, %5901
  %5995 = sext i32 %5994 to i64
  %5996 = getelementptr inbounds float, float addrspace(1)* %0, i64 %5995
  store float %5993, float addrspace(1)* %5996, align 4, !tbaa !6
  %5997 = add nsw i32 %5991, %1
  %5998 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 15, i32 %5901
  %5999 = load float, float addrspace(3)* %5998, align 4, !tbaa !6
  %6000 = add nsw i32 %5997, %5901
  %6001 = sext i32 %6000 to i64
  %6002 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6001
  store float %5999, float addrspace(1)* %6002, align 4, !tbaa !6
  %6003 = add nsw i32 %5997, %1
  %6004 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 16, i32 %5901
  %6005 = load float, float addrspace(3)* %6004, align 4, !tbaa !6
  %6006 = add nsw i32 %6003, %5901
  %6007 = sext i32 %6006 to i64
  %6008 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6007
  store float %6005, float addrspace(1)* %6008, align 4, !tbaa !6
  %6009 = add nsw i32 %6003, %1
  %6010 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 17, i32 %5901
  %6011 = load float, float addrspace(3)* %6010, align 4, !tbaa !6
  %6012 = add nsw i32 %6009, %5901
  %6013 = sext i32 %6012 to i64
  %6014 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6013
  store float %6011, float addrspace(1)* %6014, align 4, !tbaa !6
  %6015 = add nsw i32 %6009, %1
  %6016 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 18, i32 %5901
  %6017 = load float, float addrspace(3)* %6016, align 4, !tbaa !6
  %6018 = add nsw i32 %6015, %5901
  %6019 = sext i32 %6018 to i64
  %6020 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6019
  store float %6017, float addrspace(1)* %6020, align 4, !tbaa !6
  %6021 = add nsw i32 %6015, %1
  %6022 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 19, i32 %5901
  %6023 = load float, float addrspace(3)* %6022, align 4, !tbaa !6
  %6024 = add nsw i32 %6021, %5901
  %6025 = sext i32 %6024 to i64
  %6026 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6025
  store float %6023, float addrspace(1)* %6026, align 4, !tbaa !6
  %6027 = add nsw i32 %6021, %1
  %6028 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 20, i32 %5901
  %6029 = load float, float addrspace(3)* %6028, align 4, !tbaa !6
  %6030 = add nsw i32 %6027, %5901
  %6031 = sext i32 %6030 to i64
  %6032 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6031
  store float %6029, float addrspace(1)* %6032, align 4, !tbaa !6
  %6033 = add nsw i32 %6027, %1
  %6034 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 21, i32 %5901
  %6035 = load float, float addrspace(3)* %6034, align 4, !tbaa !6
  %6036 = add nsw i32 %6033, %5901
  %6037 = sext i32 %6036 to i64
  %6038 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6037
  store float %6035, float addrspace(1)* %6038, align 4, !tbaa !6
  %6039 = add nsw i32 %6033, %1
  %6040 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 22, i32 %5901
  %6041 = load float, float addrspace(3)* %6040, align 4, !tbaa !6
  %6042 = add nsw i32 %6039, %5901
  %6043 = sext i32 %6042 to i64
  %6044 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6043
  store float %6041, float addrspace(1)* %6044, align 4, !tbaa !6
  %6045 = add nsw i32 %6039, %1
  %6046 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 23, i32 %5901
  %6047 = load float, float addrspace(3)* %6046, align 4, !tbaa !6
  %6048 = add nsw i32 %6045, %5901
  %6049 = sext i32 %6048 to i64
  %6050 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6049
  store float %6047, float addrspace(1)* %6050, align 4, !tbaa !6
  %6051 = add nsw i32 %6045, %1
  %6052 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 24, i32 %5901
  %6053 = load float, float addrspace(3)* %6052, align 4, !tbaa !6
  %6054 = add nsw i32 %6051, %5901
  %6055 = sext i32 %6054 to i64
  %6056 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6055
  store float %6053, float addrspace(1)* %6056, align 4, !tbaa !6
  %6057 = add nsw i32 %6051, %1
  %6058 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 25, i32 %5901
  %6059 = load float, float addrspace(3)* %6058, align 4, !tbaa !6
  %6060 = add nsw i32 %6057, %5901
  %6061 = sext i32 %6060 to i64
  %6062 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6061
  store float %6059, float addrspace(1)* %6062, align 4, !tbaa !6
  %6063 = add nsw i32 %6057, %1
  %6064 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 26, i32 %5901
  %6065 = load float, float addrspace(3)* %6064, align 4, !tbaa !6
  %6066 = add nsw i32 %6063, %5901
  %6067 = sext i32 %6066 to i64
  %6068 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6067
  store float %6065, float addrspace(1)* %6068, align 4, !tbaa !6
  %6069 = add nsw i32 %6063, %1
  %6070 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 27, i32 %5901
  %6071 = load float, float addrspace(3)* %6070, align 4, !tbaa !6
  %6072 = add nsw i32 %6069, %5901
  %6073 = sext i32 %6072 to i64
  %6074 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6073
  store float %6071, float addrspace(1)* %6074, align 4, !tbaa !6
  %6075 = add nsw i32 %6069, %1
  %6076 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 28, i32 %5901
  %6077 = load float, float addrspace(3)* %6076, align 4, !tbaa !6
  %6078 = add nsw i32 %6075, %5901
  %6079 = sext i32 %6078 to i64
  %6080 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6079
  store float %6077, float addrspace(1)* %6080, align 4, !tbaa !6
  %6081 = add nsw i32 %6075, %1
  %6082 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 29, i32 %5901
  %6083 = load float, float addrspace(3)* %6082, align 4, !tbaa !6
  %6084 = add nsw i32 %6081, %5901
  %6085 = sext i32 %6084 to i64
  %6086 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6085
  store float %6083, float addrspace(1)* %6086, align 4, !tbaa !6
  %6087 = add nsw i32 %6081, %1
  %6088 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 30, i32 %5901
  %6089 = load float, float addrspace(3)* %6088, align 4, !tbaa !6
  %6090 = add nsw i32 %6087, %5901
  %6091 = sext i32 %6090 to i64
  %6092 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6091
  store float %6089, float addrspace(1)* %6092, align 4, !tbaa !6
  %6093 = add nsw i32 %6087, %1
  %6094 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 31, i32 %5901
  %6095 = add nsw i32 %6093, %5901
  %6096 = sext i32 %6095 to i64
  br label %6097

6097:                                             ; preds = %5900, %5708
  %6098 = phi i64 [ %6096, %5900 ], [ %5899, %5708 ]
  %6099 = phi float addrspace(3)* [ %6094, %5900 ], [ %5897, %5708 ]
  %6100 = load float, float addrspace(3)* %6099, align 4, !tbaa !6
  %6101 = getelementptr inbounds float, float addrspace(1)* %0, i64 %6098
  store float %6100, float addrspace(1)* %6101, align 4, !tbaa !6
  ret void
}

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z12lud_internalPfii(float addrspace(1)* nocapture %0, i32 %1, i32 %2) local_unnamed_addr #0 {
  %4 = sext i32 %2 to i64
  %5 = tail call i32 @llvm.amdgcn.workgroup.id.y() #3
  %6 = shl i32 %5, 5
  %7 = add i32 %2, 32
  %8 = add i32 %7, %6
  %9 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %10 = shl i32 %9, 5
  %11 = add i32 %7, %10
  %12 = tail call i32 @llvm.amdgcn.workitem.id.y() #3, !range !5
  %13 = zext i32 %12 to i64
  %14 = add nsw i64 %4, %13
  %15 = sext i32 %1 to i64
  %16 = mul i64 %14, %15
  %17 = sext i32 %11 to i64
  %18 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %19 = zext i32 %18 to i64
  %20 = add nsw i64 %17, %19
  %21 = add i64 %20, %16
  %22 = getelementptr inbounds float, float addrspace(1)* %0, i64 %21
  %23 = load float, float addrspace(1)* %22, align 4, !tbaa !6
  %24 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 %12, i32 %18
  store float %23, float addrspace(3)* %24, align 4, !tbaa !6
  %25 = sext i32 %8 to i64
  %26 = add nsw i64 %25, %13
  %27 = mul i64 %26, %15
  %28 = add i64 %27, %19
  %29 = add i64 %28, %4
  %30 = getelementptr inbounds float, float addrspace(1)* %0, i64 %29
  %31 = load float, float addrspace(1)* %30, align 4, !tbaa !6
  %32 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 %18
  store float %31, float addrspace(3)* %32, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %33 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 0
  %34 = load float, float addrspace(3)* %33, align 16, !tbaa !6
  %35 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 0, i32 %18
  %36 = load float, float addrspace(3)* %35, align 4, !tbaa !6
  %37 = fmul contract float %34, %36
  %38 = fadd contract float %37, 0.000000e+00
  %39 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 1
  %40 = load float, float addrspace(3)* %39, align 4, !tbaa !6
  %41 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 1, i32 %18
  %42 = load float, float addrspace(3)* %41, align 4, !tbaa !6
  %43 = fmul contract float %40, %42
  %44 = fadd contract float %38, %43
  %45 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 2
  %46 = load float, float addrspace(3)* %45, align 8, !tbaa !6
  %47 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 2, i32 %18
  %48 = load float, float addrspace(3)* %47, align 4, !tbaa !6
  %49 = fmul contract float %46, %48
  %50 = fadd contract float %44, %49
  %51 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 3
  %52 = load float, float addrspace(3)* %51, align 4, !tbaa !6
  %53 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 3, i32 %18
  %54 = load float, float addrspace(3)* %53, align 4, !tbaa !6
  %55 = fmul contract float %52, %54
  %56 = fadd contract float %50, %55
  %57 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 4
  %58 = load float, float addrspace(3)* %57, align 16, !tbaa !6
  %59 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 4, i32 %18
  %60 = load float, float addrspace(3)* %59, align 4, !tbaa !6
  %61 = fmul contract float %58, %60
  %62 = fadd contract float %56, %61
  %63 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 5
  %64 = load float, float addrspace(3)* %63, align 4, !tbaa !6
  %65 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 5, i32 %18
  %66 = load float, float addrspace(3)* %65, align 4, !tbaa !6
  %67 = fmul contract float %64, %66
  %68 = fadd contract float %62, %67
  %69 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 6
  %70 = load float, float addrspace(3)* %69, align 8, !tbaa !6
  %71 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 6, i32 %18
  %72 = load float, float addrspace(3)* %71, align 4, !tbaa !6
  %73 = fmul contract float %70, %72
  %74 = fadd contract float %68, %73
  %75 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 7
  %76 = load float, float addrspace(3)* %75, align 4, !tbaa !6
  %77 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 7, i32 %18
  %78 = load float, float addrspace(3)* %77, align 4, !tbaa !6
  %79 = fmul contract float %76, %78
  %80 = fadd contract float %74, %79
  %81 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 8
  %82 = load float, float addrspace(3)* %81, align 16, !tbaa !6
  %83 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 8, i32 %18
  %84 = load float, float addrspace(3)* %83, align 4, !tbaa !6
  %85 = fmul contract float %82, %84
  %86 = fadd contract float %80, %85
  %87 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 9
  %88 = load float, float addrspace(3)* %87, align 4, !tbaa !6
  %89 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 9, i32 %18
  %90 = load float, float addrspace(3)* %89, align 4, !tbaa !6
  %91 = fmul contract float %88, %90
  %92 = fadd contract float %86, %91
  %93 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 10
  %94 = load float, float addrspace(3)* %93, align 8, !tbaa !6
  %95 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 10, i32 %18
  %96 = load float, float addrspace(3)* %95, align 4, !tbaa !6
  %97 = fmul contract float %94, %96
  %98 = fadd contract float %92, %97
  %99 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 11
  %100 = load float, float addrspace(3)* %99, align 4, !tbaa !6
  %101 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 11, i32 %18
  %102 = load float, float addrspace(3)* %101, align 4, !tbaa !6
  %103 = fmul contract float %100, %102
  %104 = fadd contract float %98, %103
  %105 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 12
  %106 = load float, float addrspace(3)* %105, align 16, !tbaa !6
  %107 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 12, i32 %18
  %108 = load float, float addrspace(3)* %107, align 4, !tbaa !6
  %109 = fmul contract float %106, %108
  %110 = fadd contract float %104, %109
  %111 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 13
  %112 = load float, float addrspace(3)* %111, align 4, !tbaa !6
  %113 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 13, i32 %18
  %114 = load float, float addrspace(3)* %113, align 4, !tbaa !6
  %115 = fmul contract float %112, %114
  %116 = fadd contract float %110, %115
  %117 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 14
  %118 = load float, float addrspace(3)* %117, align 8, !tbaa !6
  %119 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 14, i32 %18
  %120 = load float, float addrspace(3)* %119, align 4, !tbaa !6
  %121 = fmul contract float %118, %120
  %122 = fadd contract float %116, %121
  %123 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 15
  %124 = load float, float addrspace(3)* %123, align 4, !tbaa !6
  %125 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 15, i32 %18
  %126 = load float, float addrspace(3)* %125, align 4, !tbaa !6
  %127 = fmul contract float %124, %126
  %128 = fadd contract float %122, %127
  %129 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 16
  %130 = load float, float addrspace(3)* %129, align 16, !tbaa !6
  %131 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 16, i32 %18
  %132 = load float, float addrspace(3)* %131, align 4, !tbaa !6
  %133 = fmul contract float %130, %132
  %134 = fadd contract float %128, %133
  %135 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 17
  %136 = load float, float addrspace(3)* %135, align 4, !tbaa !6
  %137 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 17, i32 %18
  %138 = load float, float addrspace(3)* %137, align 4, !tbaa !6
  %139 = fmul contract float %136, %138
  %140 = fadd contract float %134, %139
  %141 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 18
  %142 = load float, float addrspace(3)* %141, align 8, !tbaa !6
  %143 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 18, i32 %18
  %144 = load float, float addrspace(3)* %143, align 4, !tbaa !6
  %145 = fmul contract float %142, %144
  %146 = fadd contract float %140, %145
  %147 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 19
  %148 = load float, float addrspace(3)* %147, align 4, !tbaa !6
  %149 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 19, i32 %18
  %150 = load float, float addrspace(3)* %149, align 4, !tbaa !6
  %151 = fmul contract float %148, %150
  %152 = fadd contract float %146, %151
  %153 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 20
  %154 = load float, float addrspace(3)* %153, align 16, !tbaa !6
  %155 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 20, i32 %18
  %156 = load float, float addrspace(3)* %155, align 4, !tbaa !6
  %157 = fmul contract float %154, %156
  %158 = fadd contract float %152, %157
  %159 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 21
  %160 = load float, float addrspace(3)* %159, align 4, !tbaa !6
  %161 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 21, i32 %18
  %162 = load float, float addrspace(3)* %161, align 4, !tbaa !6
  %163 = fmul contract float %160, %162
  %164 = fadd contract float %158, %163
  %165 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 22
  %166 = load float, float addrspace(3)* %165, align 8, !tbaa !6
  %167 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 22, i32 %18
  %168 = load float, float addrspace(3)* %167, align 4, !tbaa !6
  %169 = fmul contract float %166, %168
  %170 = fadd contract float %164, %169
  %171 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 23
  %172 = load float, float addrspace(3)* %171, align 4, !tbaa !6
  %173 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 23, i32 %18
  %174 = load float, float addrspace(3)* %173, align 4, !tbaa !6
  %175 = fmul contract float %172, %174
  %176 = fadd contract float %170, %175
  %177 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 24
  %178 = load float, float addrspace(3)* %177, align 16, !tbaa !6
  %179 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 24, i32 %18
  %180 = load float, float addrspace(3)* %179, align 4, !tbaa !6
  %181 = fmul contract float %178, %180
  %182 = fadd contract float %176, %181
  %183 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 25
  %184 = load float, float addrspace(3)* %183, align 4, !tbaa !6
  %185 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 25, i32 %18
  %186 = load float, float addrspace(3)* %185, align 4, !tbaa !6
  %187 = fmul contract float %184, %186
  %188 = fadd contract float %182, %187
  %189 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 26
  %190 = load float, float addrspace(3)* %189, align 8, !tbaa !6
  %191 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 26, i32 %18
  %192 = load float, float addrspace(3)* %191, align 4, !tbaa !6
  %193 = fmul contract float %190, %192
  %194 = fadd contract float %188, %193
  %195 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 27
  %196 = load float, float addrspace(3)* %195, align 4, !tbaa !6
  %197 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 27, i32 %18
  %198 = load float, float addrspace(3)* %197, align 4, !tbaa !6
  %199 = fmul contract float %196, %198
  %200 = fadd contract float %194, %199
  %201 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 28
  %202 = load float, float addrspace(3)* %201, align 16, !tbaa !6
  %203 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 28, i32 %18
  %204 = load float, float addrspace(3)* %203, align 4, !tbaa !6
  %205 = fmul contract float %202, %204
  %206 = fadd contract float %200, %205
  %207 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 29
  %208 = load float, float addrspace(3)* %207, align 4, !tbaa !6
  %209 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 29, i32 %18
  %210 = load float, float addrspace(3)* %209, align 4, !tbaa !6
  %211 = fmul contract float %208, %210
  %212 = fadd contract float %206, %211
  %213 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 30
  %214 = load float, float addrspace(3)* %213, align 8, !tbaa !6
  %215 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 30, i32 %18
  %216 = load float, float addrspace(3)* %215, align 4, !tbaa !6
  %217 = fmul contract float %214, %216
  %218 = fadd contract float %212, %217
  %219 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 31
  %220 = load float, float addrspace(3)* %219, align 4, !tbaa !6
  %221 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 31, i32 %18
  %222 = load float, float addrspace(3)* %221, align 4, !tbaa !6
  %223 = fmul contract float %220, %222
  %224 = fadd contract float %218, %223
  %225 = add i64 %20, %27
  %226 = getelementptr inbounds float, float addrspace(1)* %0, i64 %225
  %227 = load float, float addrspace(1)* %226, align 4, !tbaa !6
  %228 = fsub contract float %227, %224
  store float %228, float addrspace(1)* %226, align 4, !tbaa !6
  ret void
}

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.y() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.y() #2

attributes #0 = { convergent norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { convergent nounwind willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i32 0, i32 1024}
!6 = !{!7, !7, i64 0}
!7 = !{!"float", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C++ TBAA"}
!10 = distinct !{!10, !11}
!11 = !{!"llvm.loop.mustprogress"}
!12 = distinct !{!12, !13}
!13 = !{!"llvm.loop.unroll.disable"}
!14 = distinct !{!14, !11}
!15 = distinct !{!15, !13}
!16 = distinct !{!16, !11}
