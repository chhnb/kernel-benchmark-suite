; ModuleID = '/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-repro.XpJFTn/BIT64/compat.ll'
source_filename = "/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-benchmarks/benchmarks/BIT/bitonic_sort.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" = type { i8 }

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = comdat any

@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" undef, comdat, align 1
@shared = external hidden local_unnamed_addr addrspace(3) global [0 x i32], align 4

; Function Attrs: convergent norecurse nounwind
define amdgpu_kernel void @_ZL11bitonicSortPi(i32 addrspace(1)* nocapture %0) local_unnamed_addr #0 {
  %2 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %3 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %4 = shl i32 %3, 6
  %5 = add i32 %4, %2
  %6 = zext i32 %5 to i64
  %7 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %6
  %8 = load i32, i32 addrspace(1)* %7, align 4, !tbaa !6
  %9 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %2
  store i32 %8, i32 addrspace(3)* %9, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %10 = xor i32 %2, 1
  %11 = icmp ugt i32 %10, %2
  %12 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %10
  %13 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %10
  br i1 %11, label %14, label %27

14:                                               ; preds = %1
  %15 = and i32 %2, 2
  %16 = icmp eq i32 %15, 0
  br i1 %16, label %17, label %22

17:                                               ; preds = %14
  %18 = load i32, i32 addrspace(3)* %13, align 4, !tbaa !6
  %19 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  %20 = icmp slt i32 %18, %19
  br i1 %20, label %21, label %27

21:                                               ; preds = %17
  store i32 %18, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %19, i32 addrspace(3)* %13, align 4, !tbaa !6
  br label %27

22:                                               ; preds = %14
  %23 = load i32, i32 addrspace(3)* %12, align 4, !tbaa !6
  %24 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  %25 = icmp sgt i32 %23, %24
  br i1 %25, label %26, label %27

26:                                               ; preds = %22
  store i32 %23, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %24, i32 addrspace(3)* %12, align 4, !tbaa !6
  br label %27

27:                                               ; preds = %26, %22, %21, %17, %1
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %28 = and i32 %2, 4
  %29 = icmp eq i32 %28, 0
  %30 = xor i32 %2, 2
  %31 = icmp ugt i32 %30, %2
  br i1 %31, label %32, label %42

32:                                               ; preds = %27
  %33 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %30
  %34 = load i32, i32 addrspace(3)* %33, align 4, !tbaa !6
  %35 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %29, label %39, label %36

36:                                               ; preds = %32
  %37 = icmp sgt i32 %34, %35
  br i1 %37, label %38, label %42

38:                                               ; preds = %36
  store i32 %34, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %35, i32 addrspace(3)* %33, align 4, !tbaa !6
  br label %42

39:                                               ; preds = %32
  %40 = icmp slt i32 %34, %35
  br i1 %40, label %41, label %42

41:                                               ; preds = %39
  store i32 %34, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %35, i32 addrspace(3)* %33, align 4, !tbaa !6
  br label %42

42:                                               ; preds = %41, %39, %38, %36, %27
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %43 = xor i32 %2, 1
  %44 = icmp ugt i32 %43, %2
  br i1 %44, label %284, label %294

45:                                               ; preds = %294
  %46 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %297
  %47 = load i32, i32 addrspace(3)* %46, align 4, !tbaa !6
  %48 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %296, label %52, label %49

49:                                               ; preds = %45
  %50 = icmp sgt i32 %47, %48
  br i1 %50, label %51, label %55

51:                                               ; preds = %49
  store i32 %47, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %48, i32 addrspace(3)* %46, align 4, !tbaa !6
  br label %55

52:                                               ; preds = %45
  %53 = icmp slt i32 %47, %48
  br i1 %53, label %54, label %55

54:                                               ; preds = %52
  store i32 %47, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %48, i32 addrspace(3)* %46, align 4, !tbaa !6
  br label %55

55:                                               ; preds = %294, %54, %52, %51, %49
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %56 = xor i32 %2, 2
  %57 = icmp ugt i32 %56, %2
  br i1 %57, label %256, label %266

58:                                               ; preds = %279
  %59 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %282
  %60 = load i32, i32 addrspace(3)* %59, align 4, !tbaa !6
  %61 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %281, label %65, label %62

62:                                               ; preds = %58
  %63 = icmp sgt i32 %60, %61
  br i1 %63, label %64, label %68

64:                                               ; preds = %62
  store i32 %60, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %61, i32 addrspace(3)* %59, align 4, !tbaa !6
  br label %68

65:                                               ; preds = %58
  %66 = icmp slt i32 %60, %61
  br i1 %66, label %67, label %68

67:                                               ; preds = %65
  store i32 %60, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %61, i32 addrspace(3)* %59, align 4, !tbaa !6
  br label %68

68:                                               ; preds = %279, %67, %65, %64, %62
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %69 = xor i32 %2, 4
  %70 = icmp ugt i32 %69, %2
  br i1 %70, label %215, label %225

71:                                               ; preds = %251
  %72 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %254
  %73 = load i32, i32 addrspace(3)* %72, align 4, !tbaa !6
  %74 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %253, label %78, label %75

75:                                               ; preds = %71
  %76 = icmp sgt i32 %73, %74
  br i1 %76, label %77, label %81

77:                                               ; preds = %75
  store i32 %73, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %74, i32 addrspace(3)* %72, align 4, !tbaa !6
  br label %81

78:                                               ; preds = %71
  %79 = icmp slt i32 %73, %74
  br i1 %79, label %80, label %81

80:                                               ; preds = %78
  store i32 %73, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %74, i32 addrspace(3)* %72, align 4, !tbaa !6
  br label %81

81:                                               ; preds = %251, %80, %78, %77, %75
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %82 = xor i32 %2, 8
  %83 = icmp ugt i32 %82, %2
  br i1 %83, label %161, label %171

84:                                               ; preds = %210
  %85 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %213
  %86 = load i32, i32 addrspace(3)* %85, align 4, !tbaa !6
  %87 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %212, label %91, label %88

88:                                               ; preds = %84
  %89 = icmp sgt i32 %86, %87
  br i1 %89, label %90, label %94

90:                                               ; preds = %88
  store i32 %86, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %87, i32 addrspace(3)* %85, align 4, !tbaa !6
  br label %94

91:                                               ; preds = %84
  %92 = icmp slt i32 %86, %87
  br i1 %92, label %93, label %94

93:                                               ; preds = %91
  store i32 %86, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %87, i32 addrspace(3)* %85, align 4, !tbaa !6
  br label %94

94:                                               ; preds = %210, %93, %91, %90, %88
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %95 = xor i32 %2, 16
  %96 = icmp ugt i32 %95, %2
  br i1 %96, label %97, label %107

97:                                               ; preds = %94
  %98 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %95
  %99 = load i32, i32 addrspace(3)* %98, align 4, !tbaa !6
  %100 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %212, label %104, label %101

101:                                              ; preds = %97
  %102 = icmp sgt i32 %99, %100
  br i1 %102, label %103, label %107

103:                                              ; preds = %101
  store i32 %99, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %100, i32 addrspace(3)* %98, align 4, !tbaa !6
  br label %107

104:                                              ; preds = %97
  %105 = icmp slt i32 %99, %100
  br i1 %105, label %106, label %107

106:                                              ; preds = %104
  store i32 %99, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %100, i32 addrspace(3)* %98, align 4, !tbaa !6
  br label %107

107:                                              ; preds = %106, %104, %103, %101, %94
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %108 = xor i32 %2, 8
  %109 = icmp ugt i32 %108, %2
  br i1 %109, label %110, label %120

110:                                              ; preds = %107
  %111 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %108
  %112 = load i32, i32 addrspace(3)* %111, align 4, !tbaa !6
  %113 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %212, label %117, label %114

114:                                              ; preds = %110
  %115 = icmp sgt i32 %112, %113
  br i1 %115, label %116, label %120

116:                                              ; preds = %114
  store i32 %112, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %113, i32 addrspace(3)* %111, align 4, !tbaa !6
  br label %120

117:                                              ; preds = %110
  %118 = icmp slt i32 %112, %113
  br i1 %118, label %119, label %120

119:                                              ; preds = %117
  store i32 %112, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %113, i32 addrspace(3)* %111, align 4, !tbaa !6
  br label %120

120:                                              ; preds = %119, %117, %116, %114, %107
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %121 = xor i32 %2, 4
  %122 = icmp ugt i32 %121, %2
  br i1 %122, label %123, label %133

123:                                              ; preds = %120
  %124 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %121
  %125 = load i32, i32 addrspace(3)* %124, align 4, !tbaa !6
  %126 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %212, label %130, label %127

127:                                              ; preds = %123
  %128 = icmp sgt i32 %125, %126
  br i1 %128, label %129, label %133

129:                                              ; preds = %127
  store i32 %125, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %126, i32 addrspace(3)* %124, align 4, !tbaa !6
  br label %133

130:                                              ; preds = %123
  %131 = icmp slt i32 %125, %126
  br i1 %131, label %132, label %133

132:                                              ; preds = %130
  store i32 %125, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %126, i32 addrspace(3)* %124, align 4, !tbaa !6
  br label %133

133:                                              ; preds = %132, %130, %129, %127, %120
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %134 = xor i32 %2, 2
  %135 = icmp ugt i32 %134, %2
  br i1 %135, label %136, label %146

136:                                              ; preds = %133
  %137 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %134
  %138 = load i32, i32 addrspace(3)* %137, align 4, !tbaa !6
  %139 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %212, label %143, label %140

140:                                              ; preds = %136
  %141 = icmp sgt i32 %138, %139
  br i1 %141, label %142, label %146

142:                                              ; preds = %140
  store i32 %138, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %139, i32 addrspace(3)* %137, align 4, !tbaa !6
  br label %146

143:                                              ; preds = %136
  %144 = icmp slt i32 %138, %139
  br i1 %144, label %145, label %146

145:                                              ; preds = %143
  store i32 %138, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %139, i32 addrspace(3)* %137, align 4, !tbaa !6
  br label %146

146:                                              ; preds = %145, %143, %142, %140, %133
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %147 = xor i32 %2, 1
  %148 = icmp ugt i32 %147, %2
  br i1 %148, label %149, label %159

149:                                              ; preds = %146
  %150 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %147
  %151 = load i32, i32 addrspace(3)* %150, align 4, !tbaa !6
  %152 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %212, label %156, label %153

153:                                              ; preds = %149
  %154 = icmp sgt i32 %151, %152
  br i1 %154, label %155, label %159

155:                                              ; preds = %153
  store i32 %151, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %152, i32 addrspace(3)* %150, align 4, !tbaa !6
  br label %159

156:                                              ; preds = %149
  %157 = icmp slt i32 %151, %152
  br i1 %157, label %158, label %159

158:                                              ; preds = %156
  store i32 %151, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %152, i32 addrspace(3)* %150, align 4, !tbaa !6
  br label %159

159:                                              ; preds = %158, %156, %155, %153, %146
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %160 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %160, i32 addrspace(1)* %7, align 4, !tbaa !6
  ret void

161:                                              ; preds = %81
  %162 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %82
  %163 = load i32, i32 addrspace(3)* %162, align 4, !tbaa !6
  %164 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %253, label %168, label %165

165:                                              ; preds = %161
  %166 = icmp sgt i32 %163, %164
  br i1 %166, label %167, label %171

167:                                              ; preds = %165
  store i32 %163, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %164, i32 addrspace(3)* %162, align 4, !tbaa !6
  br label %171

168:                                              ; preds = %161
  %169 = icmp slt i32 %163, %164
  br i1 %169, label %170, label %171

170:                                              ; preds = %168
  store i32 %163, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %164, i32 addrspace(3)* %162, align 4, !tbaa !6
  br label %171

171:                                              ; preds = %170, %168, %167, %165, %81
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %172 = xor i32 %2, 4
  %173 = icmp ugt i32 %172, %2
  br i1 %173, label %174, label %184

174:                                              ; preds = %171
  %175 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %172
  %176 = load i32, i32 addrspace(3)* %175, align 4, !tbaa !6
  %177 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %253, label %181, label %178

178:                                              ; preds = %174
  %179 = icmp sgt i32 %176, %177
  br i1 %179, label %180, label %184

180:                                              ; preds = %178
  store i32 %176, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %177, i32 addrspace(3)* %175, align 4, !tbaa !6
  br label %184

181:                                              ; preds = %174
  %182 = icmp slt i32 %176, %177
  br i1 %182, label %183, label %184

183:                                              ; preds = %181
  store i32 %176, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %177, i32 addrspace(3)* %175, align 4, !tbaa !6
  br label %184

184:                                              ; preds = %183, %181, %180, %178, %171
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %185 = xor i32 %2, 2
  %186 = icmp ugt i32 %185, %2
  br i1 %186, label %187, label %197

187:                                              ; preds = %184
  %188 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %185
  %189 = load i32, i32 addrspace(3)* %188, align 4, !tbaa !6
  %190 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %253, label %194, label %191

191:                                              ; preds = %187
  %192 = icmp sgt i32 %189, %190
  br i1 %192, label %193, label %197

193:                                              ; preds = %191
  store i32 %189, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %190, i32 addrspace(3)* %188, align 4, !tbaa !6
  br label %197

194:                                              ; preds = %187
  %195 = icmp slt i32 %189, %190
  br i1 %195, label %196, label %197

196:                                              ; preds = %194
  store i32 %189, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %190, i32 addrspace(3)* %188, align 4, !tbaa !6
  br label %197

197:                                              ; preds = %196, %194, %193, %191, %184
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %198 = xor i32 %2, 1
  %199 = icmp ugt i32 %198, %2
  br i1 %199, label %200, label %210

200:                                              ; preds = %197
  %201 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %198
  %202 = load i32, i32 addrspace(3)* %201, align 4, !tbaa !6
  %203 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %253, label %207, label %204

204:                                              ; preds = %200
  %205 = icmp sgt i32 %202, %203
  br i1 %205, label %206, label %210

206:                                              ; preds = %204
  store i32 %202, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %203, i32 addrspace(3)* %201, align 4, !tbaa !6
  br label %210

207:                                              ; preds = %200
  %208 = icmp slt i32 %202, %203
  br i1 %208, label %209, label %210

209:                                              ; preds = %207
  store i32 %202, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %203, i32 addrspace(3)* %201, align 4, !tbaa !6
  br label %210

210:                                              ; preds = %209, %207, %206, %204, %197
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %211 = and i32 %2, 64
  %212 = icmp eq i32 %211, 0
  %213 = xor i32 %2, 32
  %214 = icmp ugt i32 %213, %2
  br i1 %214, label %84, label %94

215:                                              ; preds = %68
  %216 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %69
  %217 = load i32, i32 addrspace(3)* %216, align 4, !tbaa !6
  %218 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %281, label %222, label %219

219:                                              ; preds = %215
  %220 = icmp sgt i32 %217, %218
  br i1 %220, label %221, label %225

221:                                              ; preds = %219
  store i32 %217, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %218, i32 addrspace(3)* %216, align 4, !tbaa !6
  br label %225

222:                                              ; preds = %215
  %223 = icmp slt i32 %217, %218
  br i1 %223, label %224, label %225

224:                                              ; preds = %222
  store i32 %217, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %218, i32 addrspace(3)* %216, align 4, !tbaa !6
  br label %225

225:                                              ; preds = %224, %222, %221, %219, %68
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %226 = xor i32 %2, 2
  %227 = icmp ugt i32 %226, %2
  br i1 %227, label %228, label %238

228:                                              ; preds = %225
  %229 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %226
  %230 = load i32, i32 addrspace(3)* %229, align 4, !tbaa !6
  %231 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %281, label %235, label %232

232:                                              ; preds = %228
  %233 = icmp sgt i32 %230, %231
  br i1 %233, label %234, label %238

234:                                              ; preds = %232
  store i32 %230, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %231, i32 addrspace(3)* %229, align 4, !tbaa !6
  br label %238

235:                                              ; preds = %228
  %236 = icmp slt i32 %230, %231
  br i1 %236, label %237, label %238

237:                                              ; preds = %235
  store i32 %230, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %231, i32 addrspace(3)* %229, align 4, !tbaa !6
  br label %238

238:                                              ; preds = %237, %235, %234, %232, %225
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %239 = xor i32 %2, 1
  %240 = icmp ugt i32 %239, %2
  br i1 %240, label %241, label %251

241:                                              ; preds = %238
  %242 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %239
  %243 = load i32, i32 addrspace(3)* %242, align 4, !tbaa !6
  %244 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %281, label %248, label %245

245:                                              ; preds = %241
  %246 = icmp sgt i32 %243, %244
  br i1 %246, label %247, label %251

247:                                              ; preds = %245
  store i32 %243, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %244, i32 addrspace(3)* %242, align 4, !tbaa !6
  br label %251

248:                                              ; preds = %241
  %249 = icmp slt i32 %243, %244
  br i1 %249, label %250, label %251

250:                                              ; preds = %248
  store i32 %243, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %244, i32 addrspace(3)* %242, align 4, !tbaa !6
  br label %251

251:                                              ; preds = %250, %248, %247, %245, %238
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %252 = and i32 %2, 32
  %253 = icmp eq i32 %252, 0
  %254 = xor i32 %2, 16
  %255 = icmp ugt i32 %254, %2
  br i1 %255, label %71, label %81

256:                                              ; preds = %55
  %257 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %56
  %258 = load i32, i32 addrspace(3)* %257, align 4, !tbaa !6
  %259 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %296, label %263, label %260

260:                                              ; preds = %256
  %261 = icmp sgt i32 %258, %259
  br i1 %261, label %262, label %266

262:                                              ; preds = %260
  store i32 %258, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %259, i32 addrspace(3)* %257, align 4, !tbaa !6
  br label %266

263:                                              ; preds = %256
  %264 = icmp slt i32 %258, %259
  br i1 %264, label %265, label %266

265:                                              ; preds = %263
  store i32 %258, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %259, i32 addrspace(3)* %257, align 4, !tbaa !6
  br label %266

266:                                              ; preds = %265, %263, %262, %260, %55
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %267 = xor i32 %2, 1
  %268 = icmp ugt i32 %267, %2
  br i1 %268, label %269, label %279

269:                                              ; preds = %266
  %270 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %267
  %271 = load i32, i32 addrspace(3)* %270, align 4, !tbaa !6
  %272 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %296, label %276, label %273

273:                                              ; preds = %269
  %274 = icmp sgt i32 %271, %272
  br i1 %274, label %275, label %279

275:                                              ; preds = %273
  store i32 %271, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %272, i32 addrspace(3)* %270, align 4, !tbaa !6
  br label %279

276:                                              ; preds = %269
  %277 = icmp slt i32 %271, %272
  br i1 %277, label %278, label %279

278:                                              ; preds = %276
  store i32 %271, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %272, i32 addrspace(3)* %270, align 4, !tbaa !6
  br label %279

279:                                              ; preds = %278, %276, %275, %273, %266
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %280 = and i32 %2, 16
  %281 = icmp eq i32 %280, 0
  %282 = xor i32 %2, 8
  %283 = icmp ugt i32 %282, %2
  br i1 %283, label %58, label %68

284:                                              ; preds = %42
  %285 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %43
  %286 = load i32, i32 addrspace(3)* %285, align 4, !tbaa !6
  %287 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %29, label %291, label %288

288:                                              ; preds = %284
  %289 = icmp sgt i32 %286, %287
  br i1 %289, label %290, label %294

290:                                              ; preds = %288
  store i32 %286, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %287, i32 addrspace(3)* %285, align 4, !tbaa !6
  br label %294

291:                                              ; preds = %284
  %292 = icmp slt i32 %286, %287
  br i1 %292, label %293, label %294

293:                                              ; preds = %291
  store i32 %286, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %287, i32 addrspace(3)* %285, align 4, !tbaa !6
  br label %294

294:                                              ; preds = %293, %291, %290, %288, %42
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %295 = and i32 %2, 8
  %296 = icmp eq i32 %295, 0
  %297 = xor i32 %2, 4
  %298 = icmp ugt i32 %297, %2
  br i1 %298, label %45, label %55
}

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

attributes #0 = { convergent norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { convergent nounwind willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i32 0, i32 1024}
!6 = !{!7, !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C++ TBAA"}
