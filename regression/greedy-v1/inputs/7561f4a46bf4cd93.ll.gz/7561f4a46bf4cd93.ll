; ModuleID = '/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-repro.XpJFTn/BIT128/compat.ll'
source_filename = "/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-benchmarks/benchmarks/BIT/bitonic_sort.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" = type { i8 }

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = comdat any

@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" undef, comdat, align 1
@shared = external hidden local_unnamed_addr addrspace(3) global [0 x i32], align 4

; Function Attrs: convergent norecurse nounwind
define amdgpu_kernel void @_ZL11bitonicSortPi(i32 addrspace(1)* nocapture %0) local_unnamed_addr #0 {
  %2 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %3 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %4 = shl i32 %3, 7
  %5 = add i32 %4, %2
  %6 = zext i32 %5 to i64
  %7 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %6
  %8 = load i32, i32 addrspace(1)* %7, align 4, !tbaa !6
  %9 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %2
  store i32 %8, i32 addrspace(3)* %9, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %10 = xor i32 %2, 1
  %11 = icmp ugt i32 %10, %2
  %12 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %10
  %13 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %10
  br i1 %11, label %14, label %27

14:                                               ; preds = %1
  %15 = and i32 %2, 2
  %16 = icmp eq i32 %15, 0
  br i1 %16, label %17, label %22

17:                                               ; preds = %14
  %18 = load i32, i32 addrspace(3)* %13, align 4, !tbaa !6
  %19 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  %20 = icmp slt i32 %18, %19
  br i1 %20, label %21, label %27

21:                                               ; preds = %17
  store i32 %18, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %19, i32 addrspace(3)* %13, align 4, !tbaa !6
  br label %27

22:                                               ; preds = %14
  %23 = load i32, i32 addrspace(3)* %12, align 4, !tbaa !6
  %24 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  %25 = icmp sgt i32 %23, %24
  br i1 %25, label %26, label %27

26:                                               ; preds = %22
  store i32 %23, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %24, i32 addrspace(3)* %12, align 4, !tbaa !6
  br label %27

27:                                               ; preds = %26, %22, %21, %17, %1
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %28 = and i32 %2, 4
  %29 = icmp eq i32 %28, 0
  %30 = xor i32 %2, 2
  %31 = icmp ugt i32 %30, %2
  br i1 %31, label %32, label %42

32:                                               ; preds = %27
  %33 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %30
  %34 = load i32, i32 addrspace(3)* %33, align 4, !tbaa !6
  %35 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %29, label %39, label %36

36:                                               ; preds = %32
  %37 = icmp sgt i32 %34, %35
  br i1 %37, label %38, label %42

38:                                               ; preds = %36
  store i32 %34, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %35, i32 addrspace(3)* %33, align 4, !tbaa !6
  br label %42

39:                                               ; preds = %32
  %40 = icmp slt i32 %34, %35
  br i1 %40, label %41, label %42

41:                                               ; preds = %39
  store i32 %34, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %35, i32 addrspace(3)* %33, align 4, !tbaa !6
  br label %42

42:                                               ; preds = %41, %39, %38, %36, %27
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %43 = xor i32 %2, 1
  %44 = icmp ugt i32 %43, %2
  br i1 %44, label %377, label %387

45:                                               ; preds = %387
  %46 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %390
  %47 = load i32, i32 addrspace(3)* %46, align 4, !tbaa !6
  %48 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %389, label %52, label %49

49:                                               ; preds = %45
  %50 = icmp sgt i32 %47, %48
  br i1 %50, label %51, label %55

51:                                               ; preds = %49
  store i32 %47, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %48, i32 addrspace(3)* %46, align 4, !tbaa !6
  br label %55

52:                                               ; preds = %45
  %53 = icmp slt i32 %47, %48
  br i1 %53, label %54, label %55

54:                                               ; preds = %52
  store i32 %47, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %48, i32 addrspace(3)* %46, align 4, !tbaa !6
  br label %55

55:                                               ; preds = %387, %54, %52, %51, %49
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %56 = xor i32 %2, 2
  %57 = icmp ugt i32 %56, %2
  br i1 %57, label %349, label %359

58:                                               ; preds = %372
  %59 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %375
  %60 = load i32, i32 addrspace(3)* %59, align 4, !tbaa !6
  %61 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %374, label %65, label %62

62:                                               ; preds = %58
  %63 = icmp sgt i32 %60, %61
  br i1 %63, label %64, label %68

64:                                               ; preds = %62
  store i32 %60, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %61, i32 addrspace(3)* %59, align 4, !tbaa !6
  br label %68

65:                                               ; preds = %58
  %66 = icmp slt i32 %60, %61
  br i1 %66, label %67, label %68

67:                                               ; preds = %65
  store i32 %60, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %61, i32 addrspace(3)* %59, align 4, !tbaa !6
  br label %68

68:                                               ; preds = %372, %67, %65, %64, %62
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %69 = xor i32 %2, 4
  %70 = icmp ugt i32 %69, %2
  br i1 %70, label %308, label %318

71:                                               ; preds = %344
  %72 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %347
  %73 = load i32, i32 addrspace(3)* %72, align 4, !tbaa !6
  %74 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %346, label %78, label %75

75:                                               ; preds = %71
  %76 = icmp sgt i32 %73, %74
  br i1 %76, label %77, label %81

77:                                               ; preds = %75
  store i32 %73, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %74, i32 addrspace(3)* %72, align 4, !tbaa !6
  br label %81

78:                                               ; preds = %71
  %79 = icmp slt i32 %73, %74
  br i1 %79, label %80, label %81

80:                                               ; preds = %78
  store i32 %73, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %74, i32 addrspace(3)* %72, align 4, !tbaa !6
  br label %81

81:                                               ; preds = %344, %80, %78, %77, %75
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %82 = xor i32 %2, 8
  %83 = icmp ugt i32 %82, %2
  br i1 %83, label %254, label %264

84:                                               ; preds = %303
  %85 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %306
  %86 = load i32, i32 addrspace(3)* %85, align 4, !tbaa !6
  %87 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %305, label %91, label %88

88:                                               ; preds = %84
  %89 = icmp sgt i32 %86, %87
  br i1 %89, label %90, label %94

90:                                               ; preds = %88
  store i32 %86, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %87, i32 addrspace(3)* %85, align 4, !tbaa !6
  br label %94

91:                                               ; preds = %84
  %92 = icmp slt i32 %86, %87
  br i1 %92, label %93, label %94

93:                                               ; preds = %91
  store i32 %86, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %87, i32 addrspace(3)* %85, align 4, !tbaa !6
  br label %94

94:                                               ; preds = %303, %93, %91, %90, %88
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %95 = xor i32 %2, 16
  %96 = icmp ugt i32 %95, %2
  br i1 %96, label %187, label %197

97:                                               ; preds = %249
  %98 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %252
  %99 = load i32, i32 addrspace(3)* %98, align 4, !tbaa !6
  %100 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %251, label %104, label %101

101:                                              ; preds = %97
  %102 = icmp sgt i32 %99, %100
  br i1 %102, label %103, label %107

103:                                              ; preds = %101
  store i32 %99, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %100, i32 addrspace(3)* %98, align 4, !tbaa !6
  br label %107

104:                                              ; preds = %97
  %105 = icmp slt i32 %99, %100
  br i1 %105, label %106, label %107

106:                                              ; preds = %104
  store i32 %99, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %100, i32 addrspace(3)* %98, align 4, !tbaa !6
  br label %107

107:                                              ; preds = %249, %106, %104, %103, %101
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %108 = xor i32 %2, 32
  %109 = icmp ugt i32 %108, %2
  br i1 %109, label %110, label %120

110:                                              ; preds = %107
  %111 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %108
  %112 = load i32, i32 addrspace(3)* %111, align 4, !tbaa !6
  %113 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %251, label %117, label %114

114:                                              ; preds = %110
  %115 = icmp sgt i32 %112, %113
  br i1 %115, label %116, label %120

116:                                              ; preds = %114
  store i32 %112, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %113, i32 addrspace(3)* %111, align 4, !tbaa !6
  br label %120

117:                                              ; preds = %110
  %118 = icmp slt i32 %112, %113
  br i1 %118, label %119, label %120

119:                                              ; preds = %117
  store i32 %112, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %113, i32 addrspace(3)* %111, align 4, !tbaa !6
  br label %120

120:                                              ; preds = %119, %117, %116, %114, %107
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %121 = xor i32 %2, 16
  %122 = icmp ugt i32 %121, %2
  br i1 %122, label %123, label %133

123:                                              ; preds = %120
  %124 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %121
  %125 = load i32, i32 addrspace(3)* %124, align 4, !tbaa !6
  %126 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %251, label %130, label %127

127:                                              ; preds = %123
  %128 = icmp sgt i32 %125, %126
  br i1 %128, label %129, label %133

129:                                              ; preds = %127
  store i32 %125, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %126, i32 addrspace(3)* %124, align 4, !tbaa !6
  br label %133

130:                                              ; preds = %123
  %131 = icmp slt i32 %125, %126
  br i1 %131, label %132, label %133

132:                                              ; preds = %130
  store i32 %125, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %126, i32 addrspace(3)* %124, align 4, !tbaa !6
  br label %133

133:                                              ; preds = %132, %130, %129, %127, %120
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %134 = xor i32 %2, 8
  %135 = icmp ugt i32 %134, %2
  br i1 %135, label %136, label %146

136:                                              ; preds = %133
  %137 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %134
  %138 = load i32, i32 addrspace(3)* %137, align 4, !tbaa !6
  %139 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %251, label %143, label %140

140:                                              ; preds = %136
  %141 = icmp sgt i32 %138, %139
  br i1 %141, label %142, label %146

142:                                              ; preds = %140
  store i32 %138, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %139, i32 addrspace(3)* %137, align 4, !tbaa !6
  br label %146

143:                                              ; preds = %136
  %144 = icmp slt i32 %138, %139
  br i1 %144, label %145, label %146

145:                                              ; preds = %143
  store i32 %138, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %139, i32 addrspace(3)* %137, align 4, !tbaa !6
  br label %146

146:                                              ; preds = %145, %143, %142, %140, %133
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %147 = xor i32 %2, 4
  %148 = icmp ugt i32 %147, %2
  br i1 %148, label %149, label %159

149:                                              ; preds = %146
  %150 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %147
  %151 = load i32, i32 addrspace(3)* %150, align 4, !tbaa !6
  %152 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %251, label %156, label %153

153:                                              ; preds = %149
  %154 = icmp sgt i32 %151, %152
  br i1 %154, label %155, label %159

155:                                              ; preds = %153
  store i32 %151, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %152, i32 addrspace(3)* %150, align 4, !tbaa !6
  br label %159

156:                                              ; preds = %149
  %157 = icmp slt i32 %151, %152
  br i1 %157, label %158, label %159

158:                                              ; preds = %156
  store i32 %151, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %152, i32 addrspace(3)* %150, align 4, !tbaa !6
  br label %159

159:                                              ; preds = %158, %156, %155, %153, %146
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %160 = xor i32 %2, 2
  %161 = icmp ugt i32 %160, %2
  br i1 %161, label %162, label %172

162:                                              ; preds = %159
  %163 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %160
  %164 = load i32, i32 addrspace(3)* %163, align 4, !tbaa !6
  %165 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %251, label %169, label %166

166:                                              ; preds = %162
  %167 = icmp sgt i32 %164, %165
  br i1 %167, label %168, label %172

168:                                              ; preds = %166
  store i32 %164, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %165, i32 addrspace(3)* %163, align 4, !tbaa !6
  br label %172

169:                                              ; preds = %162
  %170 = icmp slt i32 %164, %165
  br i1 %170, label %171, label %172

171:                                              ; preds = %169
  store i32 %164, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %165, i32 addrspace(3)* %163, align 4, !tbaa !6
  br label %172

172:                                              ; preds = %171, %169, %168, %166, %159
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %173 = xor i32 %2, 1
  %174 = icmp ugt i32 %173, %2
  br i1 %174, label %175, label %185

175:                                              ; preds = %172
  %176 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %173
  %177 = load i32, i32 addrspace(3)* %176, align 4, !tbaa !6
  %178 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %251, label %182, label %179

179:                                              ; preds = %175
  %180 = icmp sgt i32 %177, %178
  br i1 %180, label %181, label %185

181:                                              ; preds = %179
  store i32 %177, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %178, i32 addrspace(3)* %176, align 4, !tbaa !6
  br label %185

182:                                              ; preds = %175
  %183 = icmp slt i32 %177, %178
  br i1 %183, label %184, label %185

184:                                              ; preds = %182
  store i32 %177, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %178, i32 addrspace(3)* %176, align 4, !tbaa !6
  br label %185

185:                                              ; preds = %184, %182, %181, %179, %172
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %186 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %186, i32 addrspace(1)* %7, align 4, !tbaa !6
  ret void

187:                                              ; preds = %94
  %188 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %95
  %189 = load i32, i32 addrspace(3)* %188, align 4, !tbaa !6
  %190 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %305, label %194, label %191

191:                                              ; preds = %187
  %192 = icmp sgt i32 %189, %190
  br i1 %192, label %193, label %197

193:                                              ; preds = %191
  store i32 %189, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %190, i32 addrspace(3)* %188, align 4, !tbaa !6
  br label %197

194:                                              ; preds = %187
  %195 = icmp slt i32 %189, %190
  br i1 %195, label %196, label %197

196:                                              ; preds = %194
  store i32 %189, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %190, i32 addrspace(3)* %188, align 4, !tbaa !6
  br label %197

197:                                              ; preds = %196, %194, %193, %191, %94
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %198 = xor i32 %2, 8
  %199 = icmp ugt i32 %198, %2
  br i1 %199, label %200, label %210

200:                                              ; preds = %197
  %201 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %198
  %202 = load i32, i32 addrspace(3)* %201, align 4, !tbaa !6
  %203 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %305, label %207, label %204

204:                                              ; preds = %200
  %205 = icmp sgt i32 %202, %203
  br i1 %205, label %206, label %210

206:                                              ; preds = %204
  store i32 %202, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %203, i32 addrspace(3)* %201, align 4, !tbaa !6
  br label %210

207:                                              ; preds = %200
  %208 = icmp slt i32 %202, %203
  br i1 %208, label %209, label %210

209:                                              ; preds = %207
  store i32 %202, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %203, i32 addrspace(3)* %201, align 4, !tbaa !6
  br label %210

210:                                              ; preds = %209, %207, %206, %204, %197
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %211 = xor i32 %2, 4
  %212 = icmp ugt i32 %211, %2
  br i1 %212, label %213, label %223

213:                                              ; preds = %210
  %214 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %211
  %215 = load i32, i32 addrspace(3)* %214, align 4, !tbaa !6
  %216 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %305, label %220, label %217

217:                                              ; preds = %213
  %218 = icmp sgt i32 %215, %216
  br i1 %218, label %219, label %223

219:                                              ; preds = %217
  store i32 %215, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %216, i32 addrspace(3)* %214, align 4, !tbaa !6
  br label %223

220:                                              ; preds = %213
  %221 = icmp slt i32 %215, %216
  br i1 %221, label %222, label %223

222:                                              ; preds = %220
  store i32 %215, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %216, i32 addrspace(3)* %214, align 4, !tbaa !6
  br label %223

223:                                              ; preds = %222, %220, %219, %217, %210
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %224 = xor i32 %2, 2
  %225 = icmp ugt i32 %224, %2
  br i1 %225, label %226, label %236

226:                                              ; preds = %223
  %227 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %224
  %228 = load i32, i32 addrspace(3)* %227, align 4, !tbaa !6
  %229 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %305, label %233, label %230

230:                                              ; preds = %226
  %231 = icmp sgt i32 %228, %229
  br i1 %231, label %232, label %236

232:                                              ; preds = %230
  store i32 %228, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %229, i32 addrspace(3)* %227, align 4, !tbaa !6
  br label %236

233:                                              ; preds = %226
  %234 = icmp slt i32 %228, %229
  br i1 %234, label %235, label %236

235:                                              ; preds = %233
  store i32 %228, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %229, i32 addrspace(3)* %227, align 4, !tbaa !6
  br label %236

236:                                              ; preds = %235, %233, %232, %230, %223
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %237 = xor i32 %2, 1
  %238 = icmp ugt i32 %237, %2
  br i1 %238, label %239, label %249

239:                                              ; preds = %236
  %240 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %237
  %241 = load i32, i32 addrspace(3)* %240, align 4, !tbaa !6
  %242 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %305, label %246, label %243

243:                                              ; preds = %239
  %244 = icmp sgt i32 %241, %242
  br i1 %244, label %245, label %249

245:                                              ; preds = %243
  store i32 %241, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %242, i32 addrspace(3)* %240, align 4, !tbaa !6
  br label %249

246:                                              ; preds = %239
  %247 = icmp slt i32 %241, %242
  br i1 %247, label %248, label %249

248:                                              ; preds = %246
  store i32 %241, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %242, i32 addrspace(3)* %240, align 4, !tbaa !6
  br label %249

249:                                              ; preds = %248, %246, %245, %243, %236
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %250 = and i32 %2, 128
  %251 = icmp eq i32 %250, 0
  %252 = xor i32 %2, 64
  %253 = icmp ugt i32 %252, %2
  br i1 %253, label %97, label %107

254:                                              ; preds = %81
  %255 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %82
  %256 = load i32, i32 addrspace(3)* %255, align 4, !tbaa !6
  %257 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %346, label %261, label %258

258:                                              ; preds = %254
  %259 = icmp sgt i32 %256, %257
  br i1 %259, label %260, label %264

260:                                              ; preds = %258
  store i32 %256, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %257, i32 addrspace(3)* %255, align 4, !tbaa !6
  br label %264

261:                                              ; preds = %254
  %262 = icmp slt i32 %256, %257
  br i1 %262, label %263, label %264

263:                                              ; preds = %261
  store i32 %256, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %257, i32 addrspace(3)* %255, align 4, !tbaa !6
  br label %264

264:                                              ; preds = %263, %261, %260, %258, %81
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %265 = xor i32 %2, 4
  %266 = icmp ugt i32 %265, %2
  br i1 %266, label %267, label %277

267:                                              ; preds = %264
  %268 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %265
  %269 = load i32, i32 addrspace(3)* %268, align 4, !tbaa !6
  %270 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %346, label %274, label %271

271:                                              ; preds = %267
  %272 = icmp sgt i32 %269, %270
  br i1 %272, label %273, label %277

273:                                              ; preds = %271
  store i32 %269, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %270, i32 addrspace(3)* %268, align 4, !tbaa !6
  br label %277

274:                                              ; preds = %267
  %275 = icmp slt i32 %269, %270
  br i1 %275, label %276, label %277

276:                                              ; preds = %274
  store i32 %269, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %270, i32 addrspace(3)* %268, align 4, !tbaa !6
  br label %277

277:                                              ; preds = %276, %274, %273, %271, %264
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %278 = xor i32 %2, 2
  %279 = icmp ugt i32 %278, %2
  br i1 %279, label %280, label %290

280:                                              ; preds = %277
  %281 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %278
  %282 = load i32, i32 addrspace(3)* %281, align 4, !tbaa !6
  %283 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %346, label %287, label %284

284:                                              ; preds = %280
  %285 = icmp sgt i32 %282, %283
  br i1 %285, label %286, label %290

286:                                              ; preds = %284
  store i32 %282, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %283, i32 addrspace(3)* %281, align 4, !tbaa !6
  br label %290

287:                                              ; preds = %280
  %288 = icmp slt i32 %282, %283
  br i1 %288, label %289, label %290

289:                                              ; preds = %287
  store i32 %282, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %283, i32 addrspace(3)* %281, align 4, !tbaa !6
  br label %290

290:                                              ; preds = %289, %287, %286, %284, %277
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %291 = xor i32 %2, 1
  %292 = icmp ugt i32 %291, %2
  br i1 %292, label %293, label %303

293:                                              ; preds = %290
  %294 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %291
  %295 = load i32, i32 addrspace(3)* %294, align 4, !tbaa !6
  %296 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %346, label %300, label %297

297:                                              ; preds = %293
  %298 = icmp sgt i32 %295, %296
  br i1 %298, label %299, label %303

299:                                              ; preds = %297
  store i32 %295, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %296, i32 addrspace(3)* %294, align 4, !tbaa !6
  br label %303

300:                                              ; preds = %293
  %301 = icmp slt i32 %295, %296
  br i1 %301, label %302, label %303

302:                                              ; preds = %300
  store i32 %295, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %296, i32 addrspace(3)* %294, align 4, !tbaa !6
  br label %303

303:                                              ; preds = %302, %300, %299, %297, %290
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %304 = and i32 %2, 64
  %305 = icmp eq i32 %304, 0
  %306 = xor i32 %2, 32
  %307 = icmp ugt i32 %306, %2
  br i1 %307, label %84, label %94

308:                                              ; preds = %68
  %309 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %69
  %310 = load i32, i32 addrspace(3)* %309, align 4, !tbaa !6
  %311 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %374, label %315, label %312

312:                                              ; preds = %308
  %313 = icmp sgt i32 %310, %311
  br i1 %313, label %314, label %318

314:                                              ; preds = %312
  store i32 %310, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %311, i32 addrspace(3)* %309, align 4, !tbaa !6
  br label %318

315:                                              ; preds = %308
  %316 = icmp slt i32 %310, %311
  br i1 %316, label %317, label %318

317:                                              ; preds = %315
  store i32 %310, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %311, i32 addrspace(3)* %309, align 4, !tbaa !6
  br label %318

318:                                              ; preds = %317, %315, %314, %312, %68
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %319 = xor i32 %2, 2
  %320 = icmp ugt i32 %319, %2
  br i1 %320, label %321, label %331

321:                                              ; preds = %318
  %322 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %319
  %323 = load i32, i32 addrspace(3)* %322, align 4, !tbaa !6
  %324 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %374, label %328, label %325

325:                                              ; preds = %321
  %326 = icmp sgt i32 %323, %324
  br i1 %326, label %327, label %331

327:                                              ; preds = %325
  store i32 %323, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %324, i32 addrspace(3)* %322, align 4, !tbaa !6
  br label %331

328:                                              ; preds = %321
  %329 = icmp slt i32 %323, %324
  br i1 %329, label %330, label %331

330:                                              ; preds = %328
  store i32 %323, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %324, i32 addrspace(3)* %322, align 4, !tbaa !6
  br label %331

331:                                              ; preds = %330, %328, %327, %325, %318
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %332 = xor i32 %2, 1
  %333 = icmp ugt i32 %332, %2
  br i1 %333, label %334, label %344

334:                                              ; preds = %331
  %335 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %332
  %336 = load i32, i32 addrspace(3)* %335, align 4, !tbaa !6
  %337 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %374, label %341, label %338

338:                                              ; preds = %334
  %339 = icmp sgt i32 %336, %337
  br i1 %339, label %340, label %344

340:                                              ; preds = %338
  store i32 %336, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %337, i32 addrspace(3)* %335, align 4, !tbaa !6
  br label %344

341:                                              ; preds = %334
  %342 = icmp slt i32 %336, %337
  br i1 %342, label %343, label %344

343:                                              ; preds = %341
  store i32 %336, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %337, i32 addrspace(3)* %335, align 4, !tbaa !6
  br label %344

344:                                              ; preds = %343, %341, %340, %338, %331
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %345 = and i32 %2, 32
  %346 = icmp eq i32 %345, 0
  %347 = xor i32 %2, 16
  %348 = icmp ugt i32 %347, %2
  br i1 %348, label %71, label %81

349:                                              ; preds = %55
  %350 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %56
  %351 = load i32, i32 addrspace(3)* %350, align 4, !tbaa !6
  %352 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %389, label %356, label %353

353:                                              ; preds = %349
  %354 = icmp sgt i32 %351, %352
  br i1 %354, label %355, label %359

355:                                              ; preds = %353
  store i32 %351, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %352, i32 addrspace(3)* %350, align 4, !tbaa !6
  br label %359

356:                                              ; preds = %349
  %357 = icmp slt i32 %351, %352
  br i1 %357, label %358, label %359

358:                                              ; preds = %356
  store i32 %351, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %352, i32 addrspace(3)* %350, align 4, !tbaa !6
  br label %359

359:                                              ; preds = %358, %356, %355, %353, %55
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %360 = xor i32 %2, 1
  %361 = icmp ugt i32 %360, %2
  br i1 %361, label %362, label %372

362:                                              ; preds = %359
  %363 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %360
  %364 = load i32, i32 addrspace(3)* %363, align 4, !tbaa !6
  %365 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %389, label %369, label %366

366:                                              ; preds = %362
  %367 = icmp sgt i32 %364, %365
  br i1 %367, label %368, label %372

368:                                              ; preds = %366
  store i32 %364, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %365, i32 addrspace(3)* %363, align 4, !tbaa !6
  br label %372

369:                                              ; preds = %362
  %370 = icmp slt i32 %364, %365
  br i1 %370, label %371, label %372

371:                                              ; preds = %369
  store i32 %364, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %365, i32 addrspace(3)* %363, align 4, !tbaa !6
  br label %372

372:                                              ; preds = %371, %369, %368, %366, %359
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %373 = and i32 %2, 16
  %374 = icmp eq i32 %373, 0
  %375 = xor i32 %2, 8
  %376 = icmp ugt i32 %375, %2
  br i1 %376, label %58, label %68

377:                                              ; preds = %42
  %378 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %43
  %379 = load i32, i32 addrspace(3)* %378, align 4, !tbaa !6
  %380 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %29, label %384, label %381

381:                                              ; preds = %377
  %382 = icmp sgt i32 %379, %380
  br i1 %382, label %383, label %387

383:                                              ; preds = %381
  store i32 %379, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %380, i32 addrspace(3)* %378, align 4, !tbaa !6
  br label %387

384:                                              ; preds = %377
  %385 = icmp slt i32 %379, %380
  br i1 %385, label %386, label %387

386:                                              ; preds = %384
  store i32 %379, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %380, i32 addrspace(3)* %378, align 4, !tbaa !6
  br label %387

387:                                              ; preds = %386, %384, %383, %381, %42
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %388 = and i32 %2, 8
  %389 = icmp eq i32 %388, 0
  %390 = xor i32 %2, 4
  %391 = icmp ugt i32 %390, %2
  br i1 %391, label %45, label %55
}

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

attributes #0 = { convergent norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { convergent nounwind willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i32 0, i32 1024}
!6 = !{!7, !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C++ TBAA"}
