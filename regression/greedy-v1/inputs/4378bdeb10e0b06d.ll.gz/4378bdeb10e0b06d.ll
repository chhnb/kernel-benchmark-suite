; ModuleID = '/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-repro.XpJFTn/BIT256/compat.ll'
source_filename = "/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-benchmarks/benchmarks/BIT/bitonic_sort.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" = type { i8 }

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = comdat any

@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" undef, comdat, align 1
@shared = external hidden local_unnamed_addr addrspace(3) global [0 x i32], align 4

; Function Attrs: convergent norecurse nounwind
define amdgpu_kernel void @_ZL11bitonicSortPi(i32 addrspace(1)* nocapture %0) local_unnamed_addr #0 {
  %2 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %3 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %4 = shl i32 %3, 8
  %5 = add i32 %4, %2
  %6 = zext i32 %5 to i64
  %7 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %6
  %8 = load i32, i32 addrspace(1)* %7, align 4, !tbaa !6
  %9 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %2
  store i32 %8, i32 addrspace(3)* %9, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %10 = xor i32 %2, 1
  %11 = icmp ugt i32 %10, %2
  %12 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %10
  %13 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %10
  br i1 %11, label %14, label %27

14:                                               ; preds = %1
  %15 = and i32 %2, 2
  %16 = icmp eq i32 %15, 0
  br i1 %16, label %17, label %22

17:                                               ; preds = %14
  %18 = load i32, i32 addrspace(3)* %13, align 4, !tbaa !6
  %19 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  %20 = icmp slt i32 %18, %19
  br i1 %20, label %21, label %27

21:                                               ; preds = %17
  store i32 %18, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %19, i32 addrspace(3)* %13, align 4, !tbaa !6
  br label %27

22:                                               ; preds = %14
  %23 = load i32, i32 addrspace(3)* %12, align 4, !tbaa !6
  %24 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  %25 = icmp sgt i32 %23, %24
  br i1 %25, label %26, label %27

26:                                               ; preds = %22
  store i32 %23, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %24, i32 addrspace(3)* %12, align 4, !tbaa !6
  br label %27

27:                                               ; preds = %26, %22, %21, %17, %1
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %28 = and i32 %2, 4
  %29 = icmp eq i32 %28, 0
  %30 = xor i32 %2, 2
  %31 = icmp ugt i32 %30, %2
  br i1 %31, label %32, label %42

32:                                               ; preds = %27
  %33 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %30
  %34 = load i32, i32 addrspace(3)* %33, align 4, !tbaa !6
  %35 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %29, label %39, label %36

36:                                               ; preds = %32
  %37 = icmp sgt i32 %34, %35
  br i1 %37, label %38, label %42

38:                                               ; preds = %36
  store i32 %34, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %35, i32 addrspace(3)* %33, align 4, !tbaa !6
  br label %42

39:                                               ; preds = %32
  %40 = icmp slt i32 %34, %35
  br i1 %40, label %41, label %42

41:                                               ; preds = %39
  store i32 %34, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %35, i32 addrspace(3)* %33, align 4, !tbaa !6
  br label %42

42:                                               ; preds = %41, %39, %38, %36, %27
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %43 = xor i32 %2, 1
  %44 = icmp ugt i32 %43, %2
  br i1 %44, label %483, label %493

45:                                               ; preds = %493
  %46 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %496
  %47 = load i32, i32 addrspace(3)* %46, align 4, !tbaa !6
  %48 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %495, label %52, label %49

49:                                               ; preds = %45
  %50 = icmp sgt i32 %47, %48
  br i1 %50, label %51, label %55

51:                                               ; preds = %49
  store i32 %47, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %48, i32 addrspace(3)* %46, align 4, !tbaa !6
  br label %55

52:                                               ; preds = %45
  %53 = icmp slt i32 %47, %48
  br i1 %53, label %54, label %55

54:                                               ; preds = %52
  store i32 %47, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %48, i32 addrspace(3)* %46, align 4, !tbaa !6
  br label %55

55:                                               ; preds = %493, %54, %52, %51, %49
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %56 = xor i32 %2, 2
  %57 = icmp ugt i32 %56, %2
  br i1 %57, label %455, label %465

58:                                               ; preds = %478
  %59 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %481
  %60 = load i32, i32 addrspace(3)* %59, align 4, !tbaa !6
  %61 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %480, label %65, label %62

62:                                               ; preds = %58
  %63 = icmp sgt i32 %60, %61
  br i1 %63, label %64, label %68

64:                                               ; preds = %62
  store i32 %60, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %61, i32 addrspace(3)* %59, align 4, !tbaa !6
  br label %68

65:                                               ; preds = %58
  %66 = icmp slt i32 %60, %61
  br i1 %66, label %67, label %68

67:                                               ; preds = %65
  store i32 %60, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %61, i32 addrspace(3)* %59, align 4, !tbaa !6
  br label %68

68:                                               ; preds = %478, %67, %65, %64, %62
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %69 = xor i32 %2, 4
  %70 = icmp ugt i32 %69, %2
  br i1 %70, label %414, label %424

71:                                               ; preds = %450
  %72 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %453
  %73 = load i32, i32 addrspace(3)* %72, align 4, !tbaa !6
  %74 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %452, label %78, label %75

75:                                               ; preds = %71
  %76 = icmp sgt i32 %73, %74
  br i1 %76, label %77, label %81

77:                                               ; preds = %75
  store i32 %73, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %74, i32 addrspace(3)* %72, align 4, !tbaa !6
  br label %81

78:                                               ; preds = %71
  %79 = icmp slt i32 %73, %74
  br i1 %79, label %80, label %81

80:                                               ; preds = %78
  store i32 %73, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %74, i32 addrspace(3)* %72, align 4, !tbaa !6
  br label %81

81:                                               ; preds = %450, %80, %78, %77, %75
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %82 = xor i32 %2, 8
  %83 = icmp ugt i32 %82, %2
  br i1 %83, label %360, label %370

84:                                               ; preds = %409
  %85 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %412
  %86 = load i32, i32 addrspace(3)* %85, align 4, !tbaa !6
  %87 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %411, label %91, label %88

88:                                               ; preds = %84
  %89 = icmp sgt i32 %86, %87
  br i1 %89, label %90, label %94

90:                                               ; preds = %88
  store i32 %86, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %87, i32 addrspace(3)* %85, align 4, !tbaa !6
  br label %94

91:                                               ; preds = %84
  %92 = icmp slt i32 %86, %87
  br i1 %92, label %93, label %94

93:                                               ; preds = %91
  store i32 %86, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %87, i32 addrspace(3)* %85, align 4, !tbaa !6
  br label %94

94:                                               ; preds = %409, %93, %91, %90, %88
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %95 = xor i32 %2, 16
  %96 = icmp ugt i32 %95, %2
  br i1 %96, label %293, label %303

97:                                               ; preds = %355
  %98 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %358
  %99 = load i32, i32 addrspace(3)* %98, align 4, !tbaa !6
  %100 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %357, label %104, label %101

101:                                              ; preds = %97
  %102 = icmp sgt i32 %99, %100
  br i1 %102, label %103, label %107

103:                                              ; preds = %101
  store i32 %99, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %100, i32 addrspace(3)* %98, align 4, !tbaa !6
  br label %107

104:                                              ; preds = %97
  %105 = icmp slt i32 %99, %100
  br i1 %105, label %106, label %107

106:                                              ; preds = %104
  store i32 %99, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %100, i32 addrspace(3)* %98, align 4, !tbaa !6
  br label %107

107:                                              ; preds = %355, %106, %104, %103, %101
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %108 = xor i32 %2, 32
  %109 = icmp ugt i32 %108, %2
  br i1 %109, label %213, label %223

110:                                              ; preds = %288
  %111 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %291
  %112 = load i32, i32 addrspace(3)* %111, align 4, !tbaa !6
  %113 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %290, label %117, label %114

114:                                              ; preds = %110
  %115 = icmp sgt i32 %112, %113
  br i1 %115, label %116, label %120

116:                                              ; preds = %114
  store i32 %112, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %113, i32 addrspace(3)* %111, align 4, !tbaa !6
  br label %120

117:                                              ; preds = %110
  %118 = icmp slt i32 %112, %113
  br i1 %118, label %119, label %120

119:                                              ; preds = %117
  store i32 %112, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %113, i32 addrspace(3)* %111, align 4, !tbaa !6
  br label %120

120:                                              ; preds = %288, %119, %117, %116, %114
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %121 = xor i32 %2, 64
  %122 = icmp ugt i32 %121, %2
  br i1 %122, label %123, label %133

123:                                              ; preds = %120
  %124 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %121
  %125 = load i32, i32 addrspace(3)* %124, align 4, !tbaa !6
  %126 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %290, label %130, label %127

127:                                              ; preds = %123
  %128 = icmp sgt i32 %125, %126
  br i1 %128, label %129, label %133

129:                                              ; preds = %127
  store i32 %125, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %126, i32 addrspace(3)* %124, align 4, !tbaa !6
  br label %133

130:                                              ; preds = %123
  %131 = icmp slt i32 %125, %126
  br i1 %131, label %132, label %133

132:                                              ; preds = %130
  store i32 %125, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %126, i32 addrspace(3)* %124, align 4, !tbaa !6
  br label %133

133:                                              ; preds = %132, %130, %129, %127, %120
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %134 = xor i32 %2, 32
  %135 = icmp ugt i32 %134, %2
  br i1 %135, label %136, label %146

136:                                              ; preds = %133
  %137 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %134
  %138 = load i32, i32 addrspace(3)* %137, align 4, !tbaa !6
  %139 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %290, label %143, label %140

140:                                              ; preds = %136
  %141 = icmp sgt i32 %138, %139
  br i1 %141, label %142, label %146

142:                                              ; preds = %140
  store i32 %138, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %139, i32 addrspace(3)* %137, align 4, !tbaa !6
  br label %146

143:                                              ; preds = %136
  %144 = icmp slt i32 %138, %139
  br i1 %144, label %145, label %146

145:                                              ; preds = %143
  store i32 %138, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %139, i32 addrspace(3)* %137, align 4, !tbaa !6
  br label %146

146:                                              ; preds = %145, %143, %142, %140, %133
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %147 = xor i32 %2, 16
  %148 = icmp ugt i32 %147, %2
  br i1 %148, label %149, label %159

149:                                              ; preds = %146
  %150 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %147
  %151 = load i32, i32 addrspace(3)* %150, align 4, !tbaa !6
  %152 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %290, label %156, label %153

153:                                              ; preds = %149
  %154 = icmp sgt i32 %151, %152
  br i1 %154, label %155, label %159

155:                                              ; preds = %153
  store i32 %151, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %152, i32 addrspace(3)* %150, align 4, !tbaa !6
  br label %159

156:                                              ; preds = %149
  %157 = icmp slt i32 %151, %152
  br i1 %157, label %158, label %159

158:                                              ; preds = %156
  store i32 %151, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %152, i32 addrspace(3)* %150, align 4, !tbaa !6
  br label %159

159:                                              ; preds = %158, %156, %155, %153, %146
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %160 = xor i32 %2, 8
  %161 = icmp ugt i32 %160, %2
  br i1 %161, label %162, label %172

162:                                              ; preds = %159
  %163 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %160
  %164 = load i32, i32 addrspace(3)* %163, align 4, !tbaa !6
  %165 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %290, label %169, label %166

166:                                              ; preds = %162
  %167 = icmp sgt i32 %164, %165
  br i1 %167, label %168, label %172

168:                                              ; preds = %166
  store i32 %164, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %165, i32 addrspace(3)* %163, align 4, !tbaa !6
  br label %172

169:                                              ; preds = %162
  %170 = icmp slt i32 %164, %165
  br i1 %170, label %171, label %172

171:                                              ; preds = %169
  store i32 %164, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %165, i32 addrspace(3)* %163, align 4, !tbaa !6
  br label %172

172:                                              ; preds = %171, %169, %168, %166, %159
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %173 = xor i32 %2, 4
  %174 = icmp ugt i32 %173, %2
  br i1 %174, label %175, label %185

175:                                              ; preds = %172
  %176 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %173
  %177 = load i32, i32 addrspace(3)* %176, align 4, !tbaa !6
  %178 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %290, label %182, label %179

179:                                              ; preds = %175
  %180 = icmp sgt i32 %177, %178
  br i1 %180, label %181, label %185

181:                                              ; preds = %179
  store i32 %177, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %178, i32 addrspace(3)* %176, align 4, !tbaa !6
  br label %185

182:                                              ; preds = %175
  %183 = icmp slt i32 %177, %178
  br i1 %183, label %184, label %185

184:                                              ; preds = %182
  store i32 %177, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %178, i32 addrspace(3)* %176, align 4, !tbaa !6
  br label %185

185:                                              ; preds = %184, %182, %181, %179, %172
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %186 = xor i32 %2, 2
  %187 = icmp ugt i32 %186, %2
  br i1 %187, label %188, label %198

188:                                              ; preds = %185
  %189 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %186
  %190 = load i32, i32 addrspace(3)* %189, align 4, !tbaa !6
  %191 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %290, label %195, label %192

192:                                              ; preds = %188
  %193 = icmp sgt i32 %190, %191
  br i1 %193, label %194, label %198

194:                                              ; preds = %192
  store i32 %190, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %191, i32 addrspace(3)* %189, align 4, !tbaa !6
  br label %198

195:                                              ; preds = %188
  %196 = icmp slt i32 %190, %191
  br i1 %196, label %197, label %198

197:                                              ; preds = %195
  store i32 %190, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %191, i32 addrspace(3)* %189, align 4, !tbaa !6
  br label %198

198:                                              ; preds = %197, %195, %194, %192, %185
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %199 = xor i32 %2, 1
  %200 = icmp ugt i32 %199, %2
  br i1 %200, label %201, label %211

201:                                              ; preds = %198
  %202 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %199
  %203 = load i32, i32 addrspace(3)* %202, align 4, !tbaa !6
  %204 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %290, label %208, label %205

205:                                              ; preds = %201
  %206 = icmp sgt i32 %203, %204
  br i1 %206, label %207, label %211

207:                                              ; preds = %205
  store i32 %203, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %204, i32 addrspace(3)* %202, align 4, !tbaa !6
  br label %211

208:                                              ; preds = %201
  %209 = icmp slt i32 %203, %204
  br i1 %209, label %210, label %211

210:                                              ; preds = %208
  store i32 %203, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %204, i32 addrspace(3)* %202, align 4, !tbaa !6
  br label %211

211:                                              ; preds = %210, %208, %207, %205, %198
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %212 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %212, i32 addrspace(1)* %7, align 4, !tbaa !6
  ret void

213:                                              ; preds = %107
  %214 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %108
  %215 = load i32, i32 addrspace(3)* %214, align 4, !tbaa !6
  %216 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %357, label %220, label %217

217:                                              ; preds = %213
  %218 = icmp sgt i32 %215, %216
  br i1 %218, label %219, label %223

219:                                              ; preds = %217
  store i32 %215, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %216, i32 addrspace(3)* %214, align 4, !tbaa !6
  br label %223

220:                                              ; preds = %213
  %221 = icmp slt i32 %215, %216
  br i1 %221, label %222, label %223

222:                                              ; preds = %220
  store i32 %215, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %216, i32 addrspace(3)* %214, align 4, !tbaa !6
  br label %223

223:                                              ; preds = %222, %220, %219, %217, %107
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %224 = xor i32 %2, 16
  %225 = icmp ugt i32 %224, %2
  br i1 %225, label %226, label %236

226:                                              ; preds = %223
  %227 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %224
  %228 = load i32, i32 addrspace(3)* %227, align 4, !tbaa !6
  %229 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %357, label %233, label %230

230:                                              ; preds = %226
  %231 = icmp sgt i32 %228, %229
  br i1 %231, label %232, label %236

232:                                              ; preds = %230
  store i32 %228, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %229, i32 addrspace(3)* %227, align 4, !tbaa !6
  br label %236

233:                                              ; preds = %226
  %234 = icmp slt i32 %228, %229
  br i1 %234, label %235, label %236

235:                                              ; preds = %233
  store i32 %228, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %229, i32 addrspace(3)* %227, align 4, !tbaa !6
  br label %236

236:                                              ; preds = %235, %233, %232, %230, %223
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %237 = xor i32 %2, 8
  %238 = icmp ugt i32 %237, %2
  br i1 %238, label %239, label %249

239:                                              ; preds = %236
  %240 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %237
  %241 = load i32, i32 addrspace(3)* %240, align 4, !tbaa !6
  %242 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %357, label %246, label %243

243:                                              ; preds = %239
  %244 = icmp sgt i32 %241, %242
  br i1 %244, label %245, label %249

245:                                              ; preds = %243
  store i32 %241, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %242, i32 addrspace(3)* %240, align 4, !tbaa !6
  br label %249

246:                                              ; preds = %239
  %247 = icmp slt i32 %241, %242
  br i1 %247, label %248, label %249

248:                                              ; preds = %246
  store i32 %241, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %242, i32 addrspace(3)* %240, align 4, !tbaa !6
  br label %249

249:                                              ; preds = %248, %246, %245, %243, %236
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %250 = xor i32 %2, 4
  %251 = icmp ugt i32 %250, %2
  br i1 %251, label %252, label %262

252:                                              ; preds = %249
  %253 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %250
  %254 = load i32, i32 addrspace(3)* %253, align 4, !tbaa !6
  %255 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %357, label %259, label %256

256:                                              ; preds = %252
  %257 = icmp sgt i32 %254, %255
  br i1 %257, label %258, label %262

258:                                              ; preds = %256
  store i32 %254, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %255, i32 addrspace(3)* %253, align 4, !tbaa !6
  br label %262

259:                                              ; preds = %252
  %260 = icmp slt i32 %254, %255
  br i1 %260, label %261, label %262

261:                                              ; preds = %259
  store i32 %254, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %255, i32 addrspace(3)* %253, align 4, !tbaa !6
  br label %262

262:                                              ; preds = %261, %259, %258, %256, %249
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %263 = xor i32 %2, 2
  %264 = icmp ugt i32 %263, %2
  br i1 %264, label %265, label %275

265:                                              ; preds = %262
  %266 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %263
  %267 = load i32, i32 addrspace(3)* %266, align 4, !tbaa !6
  %268 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %357, label %272, label %269

269:                                              ; preds = %265
  %270 = icmp sgt i32 %267, %268
  br i1 %270, label %271, label %275

271:                                              ; preds = %269
  store i32 %267, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %268, i32 addrspace(3)* %266, align 4, !tbaa !6
  br label %275

272:                                              ; preds = %265
  %273 = icmp slt i32 %267, %268
  br i1 %273, label %274, label %275

274:                                              ; preds = %272
  store i32 %267, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %268, i32 addrspace(3)* %266, align 4, !tbaa !6
  br label %275

275:                                              ; preds = %274, %272, %271, %269, %262
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %276 = xor i32 %2, 1
  %277 = icmp ugt i32 %276, %2
  br i1 %277, label %278, label %288

278:                                              ; preds = %275
  %279 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %276
  %280 = load i32, i32 addrspace(3)* %279, align 4, !tbaa !6
  %281 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %357, label %285, label %282

282:                                              ; preds = %278
  %283 = icmp sgt i32 %280, %281
  br i1 %283, label %284, label %288

284:                                              ; preds = %282
  store i32 %280, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %281, i32 addrspace(3)* %279, align 4, !tbaa !6
  br label %288

285:                                              ; preds = %278
  %286 = icmp slt i32 %280, %281
  br i1 %286, label %287, label %288

287:                                              ; preds = %285
  store i32 %280, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %281, i32 addrspace(3)* %279, align 4, !tbaa !6
  br label %288

288:                                              ; preds = %287, %285, %284, %282, %275
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %289 = and i32 %2, 256
  %290 = icmp eq i32 %289, 0
  %291 = xor i32 %2, 128
  %292 = icmp ugt i32 %291, %2
  br i1 %292, label %110, label %120

293:                                              ; preds = %94
  %294 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %95
  %295 = load i32, i32 addrspace(3)* %294, align 4, !tbaa !6
  %296 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %411, label %300, label %297

297:                                              ; preds = %293
  %298 = icmp sgt i32 %295, %296
  br i1 %298, label %299, label %303

299:                                              ; preds = %297
  store i32 %295, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %296, i32 addrspace(3)* %294, align 4, !tbaa !6
  br label %303

300:                                              ; preds = %293
  %301 = icmp slt i32 %295, %296
  br i1 %301, label %302, label %303

302:                                              ; preds = %300
  store i32 %295, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %296, i32 addrspace(3)* %294, align 4, !tbaa !6
  br label %303

303:                                              ; preds = %302, %300, %299, %297, %94
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %304 = xor i32 %2, 8
  %305 = icmp ugt i32 %304, %2
  br i1 %305, label %306, label %316

306:                                              ; preds = %303
  %307 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %304
  %308 = load i32, i32 addrspace(3)* %307, align 4, !tbaa !6
  %309 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %411, label %313, label %310

310:                                              ; preds = %306
  %311 = icmp sgt i32 %308, %309
  br i1 %311, label %312, label %316

312:                                              ; preds = %310
  store i32 %308, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %309, i32 addrspace(3)* %307, align 4, !tbaa !6
  br label %316

313:                                              ; preds = %306
  %314 = icmp slt i32 %308, %309
  br i1 %314, label %315, label %316

315:                                              ; preds = %313
  store i32 %308, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %309, i32 addrspace(3)* %307, align 4, !tbaa !6
  br label %316

316:                                              ; preds = %315, %313, %312, %310, %303
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %317 = xor i32 %2, 4
  %318 = icmp ugt i32 %317, %2
  br i1 %318, label %319, label %329

319:                                              ; preds = %316
  %320 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %317
  %321 = load i32, i32 addrspace(3)* %320, align 4, !tbaa !6
  %322 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %411, label %326, label %323

323:                                              ; preds = %319
  %324 = icmp sgt i32 %321, %322
  br i1 %324, label %325, label %329

325:                                              ; preds = %323
  store i32 %321, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %322, i32 addrspace(3)* %320, align 4, !tbaa !6
  br label %329

326:                                              ; preds = %319
  %327 = icmp slt i32 %321, %322
  br i1 %327, label %328, label %329

328:                                              ; preds = %326
  store i32 %321, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %322, i32 addrspace(3)* %320, align 4, !tbaa !6
  br label %329

329:                                              ; preds = %328, %326, %325, %323, %316
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %330 = xor i32 %2, 2
  %331 = icmp ugt i32 %330, %2
  br i1 %331, label %332, label %342

332:                                              ; preds = %329
  %333 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %330
  %334 = load i32, i32 addrspace(3)* %333, align 4, !tbaa !6
  %335 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %411, label %339, label %336

336:                                              ; preds = %332
  %337 = icmp sgt i32 %334, %335
  br i1 %337, label %338, label %342

338:                                              ; preds = %336
  store i32 %334, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %335, i32 addrspace(3)* %333, align 4, !tbaa !6
  br label %342

339:                                              ; preds = %332
  %340 = icmp slt i32 %334, %335
  br i1 %340, label %341, label %342

341:                                              ; preds = %339
  store i32 %334, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %335, i32 addrspace(3)* %333, align 4, !tbaa !6
  br label %342

342:                                              ; preds = %341, %339, %338, %336, %329
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %343 = xor i32 %2, 1
  %344 = icmp ugt i32 %343, %2
  br i1 %344, label %345, label %355

345:                                              ; preds = %342
  %346 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %343
  %347 = load i32, i32 addrspace(3)* %346, align 4, !tbaa !6
  %348 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %411, label %352, label %349

349:                                              ; preds = %345
  %350 = icmp sgt i32 %347, %348
  br i1 %350, label %351, label %355

351:                                              ; preds = %349
  store i32 %347, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %348, i32 addrspace(3)* %346, align 4, !tbaa !6
  br label %355

352:                                              ; preds = %345
  %353 = icmp slt i32 %347, %348
  br i1 %353, label %354, label %355

354:                                              ; preds = %352
  store i32 %347, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %348, i32 addrspace(3)* %346, align 4, !tbaa !6
  br label %355

355:                                              ; preds = %354, %352, %351, %349, %342
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %356 = and i32 %2, 128
  %357 = icmp eq i32 %356, 0
  %358 = xor i32 %2, 64
  %359 = icmp ugt i32 %358, %2
  br i1 %359, label %97, label %107

360:                                              ; preds = %81
  %361 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %82
  %362 = load i32, i32 addrspace(3)* %361, align 4, !tbaa !6
  %363 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %452, label %367, label %364

364:                                              ; preds = %360
  %365 = icmp sgt i32 %362, %363
  br i1 %365, label %366, label %370

366:                                              ; preds = %364
  store i32 %362, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %363, i32 addrspace(3)* %361, align 4, !tbaa !6
  br label %370

367:                                              ; preds = %360
  %368 = icmp slt i32 %362, %363
  br i1 %368, label %369, label %370

369:                                              ; preds = %367
  store i32 %362, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %363, i32 addrspace(3)* %361, align 4, !tbaa !6
  br label %370

370:                                              ; preds = %369, %367, %366, %364, %81
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %371 = xor i32 %2, 4
  %372 = icmp ugt i32 %371, %2
  br i1 %372, label %373, label %383

373:                                              ; preds = %370
  %374 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %371
  %375 = load i32, i32 addrspace(3)* %374, align 4, !tbaa !6
  %376 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %452, label %380, label %377

377:                                              ; preds = %373
  %378 = icmp sgt i32 %375, %376
  br i1 %378, label %379, label %383

379:                                              ; preds = %377
  store i32 %375, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %376, i32 addrspace(3)* %374, align 4, !tbaa !6
  br label %383

380:                                              ; preds = %373
  %381 = icmp slt i32 %375, %376
  br i1 %381, label %382, label %383

382:                                              ; preds = %380
  store i32 %375, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %376, i32 addrspace(3)* %374, align 4, !tbaa !6
  br label %383

383:                                              ; preds = %382, %380, %379, %377, %370
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %384 = xor i32 %2, 2
  %385 = icmp ugt i32 %384, %2
  br i1 %385, label %386, label %396

386:                                              ; preds = %383
  %387 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %384
  %388 = load i32, i32 addrspace(3)* %387, align 4, !tbaa !6
  %389 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %452, label %393, label %390

390:                                              ; preds = %386
  %391 = icmp sgt i32 %388, %389
  br i1 %391, label %392, label %396

392:                                              ; preds = %390
  store i32 %388, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %389, i32 addrspace(3)* %387, align 4, !tbaa !6
  br label %396

393:                                              ; preds = %386
  %394 = icmp slt i32 %388, %389
  br i1 %394, label %395, label %396

395:                                              ; preds = %393
  store i32 %388, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %389, i32 addrspace(3)* %387, align 4, !tbaa !6
  br label %396

396:                                              ; preds = %395, %393, %392, %390, %383
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %397 = xor i32 %2, 1
  %398 = icmp ugt i32 %397, %2
  br i1 %398, label %399, label %409

399:                                              ; preds = %396
  %400 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %397
  %401 = load i32, i32 addrspace(3)* %400, align 4, !tbaa !6
  %402 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %452, label %406, label %403

403:                                              ; preds = %399
  %404 = icmp sgt i32 %401, %402
  br i1 %404, label %405, label %409

405:                                              ; preds = %403
  store i32 %401, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %402, i32 addrspace(3)* %400, align 4, !tbaa !6
  br label %409

406:                                              ; preds = %399
  %407 = icmp slt i32 %401, %402
  br i1 %407, label %408, label %409

408:                                              ; preds = %406
  store i32 %401, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %402, i32 addrspace(3)* %400, align 4, !tbaa !6
  br label %409

409:                                              ; preds = %408, %406, %405, %403, %396
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %410 = and i32 %2, 64
  %411 = icmp eq i32 %410, 0
  %412 = xor i32 %2, 32
  %413 = icmp ugt i32 %412, %2
  br i1 %413, label %84, label %94

414:                                              ; preds = %68
  %415 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %69
  %416 = load i32, i32 addrspace(3)* %415, align 4, !tbaa !6
  %417 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %480, label %421, label %418

418:                                              ; preds = %414
  %419 = icmp sgt i32 %416, %417
  br i1 %419, label %420, label %424

420:                                              ; preds = %418
  store i32 %416, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %417, i32 addrspace(3)* %415, align 4, !tbaa !6
  br label %424

421:                                              ; preds = %414
  %422 = icmp slt i32 %416, %417
  br i1 %422, label %423, label %424

423:                                              ; preds = %421
  store i32 %416, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %417, i32 addrspace(3)* %415, align 4, !tbaa !6
  br label %424

424:                                              ; preds = %423, %421, %420, %418, %68
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %425 = xor i32 %2, 2
  %426 = icmp ugt i32 %425, %2
  br i1 %426, label %427, label %437

427:                                              ; preds = %424
  %428 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %425
  %429 = load i32, i32 addrspace(3)* %428, align 4, !tbaa !6
  %430 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %480, label %434, label %431

431:                                              ; preds = %427
  %432 = icmp sgt i32 %429, %430
  br i1 %432, label %433, label %437

433:                                              ; preds = %431
  store i32 %429, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %430, i32 addrspace(3)* %428, align 4, !tbaa !6
  br label %437

434:                                              ; preds = %427
  %435 = icmp slt i32 %429, %430
  br i1 %435, label %436, label %437

436:                                              ; preds = %434
  store i32 %429, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %430, i32 addrspace(3)* %428, align 4, !tbaa !6
  br label %437

437:                                              ; preds = %436, %434, %433, %431, %424
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %438 = xor i32 %2, 1
  %439 = icmp ugt i32 %438, %2
  br i1 %439, label %440, label %450

440:                                              ; preds = %437
  %441 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %438
  %442 = load i32, i32 addrspace(3)* %441, align 4, !tbaa !6
  %443 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %480, label %447, label %444

444:                                              ; preds = %440
  %445 = icmp sgt i32 %442, %443
  br i1 %445, label %446, label %450

446:                                              ; preds = %444
  store i32 %442, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %443, i32 addrspace(3)* %441, align 4, !tbaa !6
  br label %450

447:                                              ; preds = %440
  %448 = icmp slt i32 %442, %443
  br i1 %448, label %449, label %450

449:                                              ; preds = %447
  store i32 %442, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %443, i32 addrspace(3)* %441, align 4, !tbaa !6
  br label %450

450:                                              ; preds = %449, %447, %446, %444, %437
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %451 = and i32 %2, 32
  %452 = icmp eq i32 %451, 0
  %453 = xor i32 %2, 16
  %454 = icmp ugt i32 %453, %2
  br i1 %454, label %71, label %81

455:                                              ; preds = %55
  %456 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %56
  %457 = load i32, i32 addrspace(3)* %456, align 4, !tbaa !6
  %458 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %495, label %462, label %459

459:                                              ; preds = %455
  %460 = icmp sgt i32 %457, %458
  br i1 %460, label %461, label %465

461:                                              ; preds = %459
  store i32 %457, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %458, i32 addrspace(3)* %456, align 4, !tbaa !6
  br label %465

462:                                              ; preds = %455
  %463 = icmp slt i32 %457, %458
  br i1 %463, label %464, label %465

464:                                              ; preds = %462
  store i32 %457, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %458, i32 addrspace(3)* %456, align 4, !tbaa !6
  br label %465

465:                                              ; preds = %464, %462, %461, %459, %55
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %466 = xor i32 %2, 1
  %467 = icmp ugt i32 %466, %2
  br i1 %467, label %468, label %478

468:                                              ; preds = %465
  %469 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %466
  %470 = load i32, i32 addrspace(3)* %469, align 4, !tbaa !6
  %471 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %495, label %475, label %472

472:                                              ; preds = %468
  %473 = icmp sgt i32 %470, %471
  br i1 %473, label %474, label %478

474:                                              ; preds = %472
  store i32 %470, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %471, i32 addrspace(3)* %469, align 4, !tbaa !6
  br label %478

475:                                              ; preds = %468
  %476 = icmp slt i32 %470, %471
  br i1 %476, label %477, label %478

477:                                              ; preds = %475
  store i32 %470, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %471, i32 addrspace(3)* %469, align 4, !tbaa !6
  br label %478

478:                                              ; preds = %477, %475, %474, %472, %465
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %479 = and i32 %2, 16
  %480 = icmp eq i32 %479, 0
  %481 = xor i32 %2, 8
  %482 = icmp ugt i32 %481, %2
  br i1 %482, label %58, label %68

483:                                              ; preds = %42
  %484 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %43
  %485 = load i32, i32 addrspace(3)* %484, align 4, !tbaa !6
  %486 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %29, label %490, label %487

487:                                              ; preds = %483
  %488 = icmp sgt i32 %485, %486
  br i1 %488, label %489, label %493

489:                                              ; preds = %487
  store i32 %485, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %486, i32 addrspace(3)* %484, align 4, !tbaa !6
  br label %493

490:                                              ; preds = %483
  %491 = icmp slt i32 %485, %486
  br i1 %491, label %492, label %493

492:                                              ; preds = %490
  store i32 %485, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %486, i32 addrspace(3)* %484, align 4, !tbaa !6
  br label %493

493:                                              ; preds = %492, %490, %489, %487, %42
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %494 = and i32 %2, 8
  %495 = icmp eq i32 %494, 0
  %496 = xor i32 %2, 4
  %497 = icmp ugt i32 %496, %2
  br i1 %497, label %45, label %55
}

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

attributes #0 = { convergent norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { convergent nounwind willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i32 0, i32 1024}
!6 = !{!7, !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C++ TBAA"}
