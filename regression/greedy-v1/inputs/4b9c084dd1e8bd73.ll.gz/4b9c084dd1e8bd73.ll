; ModuleID = '/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-repro.XpJFTn/PCM64/compat.ll'
source_filename = "/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-benchmarks/benchmarks/PCM/pcm.hip.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockDim>::X" = type { i8 }

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockDimE1xE = comdat any

@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockDimE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockDim>::X" undef, comdat, align 1
@_ZZ3pcmPiE2sR = internal unnamed_addr addrspace(3) global [8192 x i32] undef, align 16
@_ZZ3pcmPiE2sC = internal unnamed_addr addrspace(3) global [8192 x i32] undef, align 16

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z3pcmPi(i32 addrspace(1)* nocapture %0) local_unnamed_addr #0 {
  %2 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %3 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %4 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %5 = getelementptr i8, i8 addrspace(4)* %4, i64 4
  %6 = bitcast i8 addrspace(4)* %5 to i16 addrspace(4)*
  %7 = load i16, i16 addrspace(4)* %6, align 4, !range !6, !invariant.load !7
  %8 = zext i16 %7 to i32
  %9 = mul i32 %3, %8
  %10 = add i32 %9, %2
  %11 = icmp slt i32 %10, 268435456
  br i1 %11, label %14, label %12

12:                                               ; preds = %1
  %13 = shl nuw nsw i32 %2, 7
  br label %132

14:                                               ; preds = %1
  %15 = shl nsw i32 %10, 7
  %16 = shl nuw nsw i32 %2, 7
  br label %17

17:                                               ; preds = %17, %14
  %18 = phi i32 [ 0, %14 ], [ %130, %17 ]
  %19 = add nuw nsw i32 %18, %15
  %20 = sext i32 %19 to i64
  %21 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %20
  %22 = load i32, i32 addrspace(1)* %21, align 4, !tbaa !8
  %23 = add nuw nsw i32 %18, %16
  %24 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %23
  store i32 %22, i32 addrspace(3)* %24, align 16, !tbaa !8
  %25 = or i32 %18, 1
  %26 = add nuw nsw i32 %25, %15
  %27 = sext i32 %26 to i64
  %28 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %27
  %29 = load i32, i32 addrspace(1)* %28, align 4, !tbaa !8
  %30 = add nuw nsw i32 %25, %16
  %31 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %30
  store i32 %29, i32 addrspace(3)* %31, align 4, !tbaa !8
  %32 = or i32 %18, 2
  %33 = add nuw nsw i32 %32, %15
  %34 = sext i32 %33 to i64
  %35 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %34
  %36 = load i32, i32 addrspace(1)* %35, align 4, !tbaa !8
  %37 = add nuw nsw i32 %32, %16
  %38 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %37
  store i32 %36, i32 addrspace(3)* %38, align 8, !tbaa !8
  %39 = or i32 %18, 3
  %40 = add nuw nsw i32 %39, %15
  %41 = sext i32 %40 to i64
  %42 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %41
  %43 = load i32, i32 addrspace(1)* %42, align 4, !tbaa !8
  %44 = add nuw nsw i32 %39, %16
  %45 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %44
  store i32 %43, i32 addrspace(3)* %45, align 4, !tbaa !8
  %46 = or i32 %18, 4
  %47 = add nuw nsw i32 %46, %15
  %48 = sext i32 %47 to i64
  %49 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %48
  %50 = load i32, i32 addrspace(1)* %49, align 4, !tbaa !8
  %51 = add nuw nsw i32 %46, %16
  %52 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %51
  store i32 %50, i32 addrspace(3)* %52, align 16, !tbaa !8
  %53 = or i32 %18, 5
  %54 = add nuw nsw i32 %53, %15
  %55 = sext i32 %54 to i64
  %56 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %55
  %57 = load i32, i32 addrspace(1)* %56, align 4, !tbaa !8
  %58 = add nuw nsw i32 %53, %16
  %59 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %58
  store i32 %57, i32 addrspace(3)* %59, align 4, !tbaa !8
  %60 = or i32 %18, 6
  %61 = add nuw nsw i32 %60, %15
  %62 = sext i32 %61 to i64
  %63 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %62
  %64 = load i32, i32 addrspace(1)* %63, align 4, !tbaa !8
  %65 = add nuw nsw i32 %60, %16
  %66 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %65
  store i32 %64, i32 addrspace(3)* %66, align 8, !tbaa !8
  %67 = or i32 %18, 7
  %68 = add nuw nsw i32 %67, %15
  %69 = sext i32 %68 to i64
  %70 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %69
  %71 = load i32, i32 addrspace(1)* %70, align 4, !tbaa !8
  %72 = add nuw nsw i32 %67, %16
  %73 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %72
  store i32 %71, i32 addrspace(3)* %73, align 4, !tbaa !8
  %74 = or i32 %18, 8
  %75 = add nuw nsw i32 %74, %15
  %76 = sext i32 %75 to i64
  %77 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %76
  %78 = load i32, i32 addrspace(1)* %77, align 4, !tbaa !8
  %79 = add nuw nsw i32 %74, %16
  %80 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %79
  store i32 %78, i32 addrspace(3)* %80, align 16, !tbaa !8
  %81 = or i32 %18, 9
  %82 = add nuw nsw i32 %81, %15
  %83 = sext i32 %82 to i64
  %84 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %83
  %85 = load i32, i32 addrspace(1)* %84, align 4, !tbaa !8
  %86 = add nuw nsw i32 %81, %16
  %87 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %86
  store i32 %85, i32 addrspace(3)* %87, align 4, !tbaa !8
  %88 = or i32 %18, 10
  %89 = add nuw nsw i32 %88, %15
  %90 = sext i32 %89 to i64
  %91 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %90
  %92 = load i32, i32 addrspace(1)* %91, align 4, !tbaa !8
  %93 = add nuw nsw i32 %88, %16
  %94 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %93
  store i32 %92, i32 addrspace(3)* %94, align 8, !tbaa !8
  %95 = or i32 %18, 11
  %96 = add nuw nsw i32 %95, %15
  %97 = sext i32 %96 to i64
  %98 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %97
  %99 = load i32, i32 addrspace(1)* %98, align 4, !tbaa !8
  %100 = add nuw nsw i32 %95, %16
  %101 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %100
  store i32 %99, i32 addrspace(3)* %101, align 4, !tbaa !8
  %102 = or i32 %18, 12
  %103 = add nuw nsw i32 %102, %15
  %104 = sext i32 %103 to i64
  %105 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %104
  %106 = load i32, i32 addrspace(1)* %105, align 4, !tbaa !8
  %107 = add nuw nsw i32 %102, %16
  %108 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %107
  store i32 %106, i32 addrspace(3)* %108, align 16, !tbaa !8
  %109 = or i32 %18, 13
  %110 = add nuw nsw i32 %109, %15
  %111 = sext i32 %110 to i64
  %112 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %111
  %113 = load i32, i32 addrspace(1)* %112, align 4, !tbaa !8
  %114 = add nuw nsw i32 %109, %16
  %115 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %114
  store i32 %113, i32 addrspace(3)* %115, align 4, !tbaa !8
  %116 = or i32 %18, 14
  %117 = add nuw nsw i32 %116, %15
  %118 = sext i32 %117 to i64
  %119 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %118
  %120 = load i32, i32 addrspace(1)* %119, align 4, !tbaa !8
  %121 = add nuw nsw i32 %116, %16
  %122 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %121
  store i32 %120, i32 addrspace(3)* %122, align 8, !tbaa !8
  %123 = or i32 %18, 15
  %124 = add nuw nsw i32 %123, %15
  %125 = sext i32 %124 to i64
  %126 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %125
  %127 = load i32, i32 addrspace(1)* %126, align 4, !tbaa !8
  %128 = add nuw nsw i32 %123, %16
  %129 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %128
  store i32 %127, i32 addrspace(3)* %129, align 4, !tbaa !8
  %130 = add nuw nsw i32 %18, 16
  %131 = icmp eq i32 %130, 128
  br i1 %131, label %132, label %17, !llvm.loop !12

132:                                              ; preds = %17, %12
  %133 = phi i32 [ %13, %12 ], [ %16, %17 ]
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %134 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sR, i32 0, i32 %133
  %135 = and i32 %2, 1
  %136 = icmp ne i32 %135, 0
  %137 = icmp ult i32 %2, 63
  %138 = xor i1 %136, true
  %139 = and i1 %137, %138
  %140 = add nsw i32 %133, -128
  %141 = add nuw nsw i32 %133, 128
  %142 = icmp ult i32 %2, 64
  %143 = and i1 %137, %136
  %144 = icmp eq i32 %2, 0
  br label %148

145:                                              ; preds = %628
  br i1 %11, label %146, label %746

146:                                              ; preds = %145
  %147 = shl nsw i32 %10, 7
  br label %631

148:                                              ; preds = %628, %132
  %149 = phi i32 [ 0, %132 ], [ %629, %628 ]
  br i1 %139, label %150, label %275

150:                                              ; preds = %150, %148
  %151 = phi i32 [ %273, %150 ], [ 0, %148 ]
  %152 = phi i32 [ %271, %150 ], [ 0, %148 ]
  %153 = phi i32 [ %269, %150 ], [ 0, %148 ]
  %154 = add nsw i32 %153, %133
  %155 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %154
  %156 = load i32, i32 addrspace(3)* %155, align 4, !tbaa !8
  %157 = add nsw i32 %141, %152
  %158 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %157
  %159 = load i32, i32 addrspace(3)* %158, align 4, !tbaa !8
  %160 = icmp sgt i32 %156, %159
  %161 = select i1 %160, i32 %159, i32 %156
  %162 = xor i1 %160, true
  %163 = zext i1 %162 to i32
  %164 = add nuw nsw i32 %153, %163
  %165 = zext i1 %160 to i32
  %166 = add nuw nsw i32 %152, %165
  %167 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %151
  store i32 %161, i32 addrspace(3)* %167, align 16
  %168 = or i32 %151, 1
  %169 = add nsw i32 %164, %133
  %170 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %169
  %171 = load i32, i32 addrspace(3)* %170, align 4, !tbaa !8
  %172 = add nsw i32 %141, %166
  %173 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %172
  %174 = load i32, i32 addrspace(3)* %173, align 4, !tbaa !8
  %175 = icmp sgt i32 %171, %174
  %176 = select i1 %175, i32 %174, i32 %171
  %177 = xor i1 %175, true
  %178 = zext i1 %177 to i32
  %179 = add nuw nsw i32 %164, %178
  %180 = zext i1 %175 to i32
  %181 = add nuw nsw i32 %166, %180
  %182 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %168
  store i32 %176, i32 addrspace(3)* %182, align 4
  %183 = or i32 %151, 2
  %184 = add nsw i32 %179, %133
  %185 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %184
  %186 = load i32, i32 addrspace(3)* %185, align 4, !tbaa !8
  %187 = add nsw i32 %141, %181
  %188 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %187
  %189 = load i32, i32 addrspace(3)* %188, align 4, !tbaa !8
  %190 = icmp sgt i32 %186, %189
  %191 = select i1 %190, i32 %189, i32 %186
  %192 = xor i1 %190, true
  %193 = zext i1 %192 to i32
  %194 = add nuw nsw i32 %179, %193
  %195 = zext i1 %190 to i32
  %196 = add nuw nsw i32 %181, %195
  %197 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %183
  store i32 %191, i32 addrspace(3)* %197, align 8
  %198 = or i32 %151, 3
  %199 = add nsw i32 %194, %133
  %200 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %199
  %201 = load i32, i32 addrspace(3)* %200, align 4, !tbaa !8
  %202 = add nsw i32 %141, %196
  %203 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %202
  %204 = load i32, i32 addrspace(3)* %203, align 4, !tbaa !8
  %205 = icmp sgt i32 %201, %204
  %206 = select i1 %205, i32 %204, i32 %201
  %207 = xor i1 %205, true
  %208 = zext i1 %207 to i32
  %209 = add nuw nsw i32 %194, %208
  %210 = zext i1 %205 to i32
  %211 = add nuw nsw i32 %196, %210
  %212 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %198
  store i32 %206, i32 addrspace(3)* %212, align 4
  %213 = or i32 %151, 4
  %214 = add nsw i32 %209, %133
  %215 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %214
  %216 = load i32, i32 addrspace(3)* %215, align 4, !tbaa !8
  %217 = add nsw i32 %141, %211
  %218 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %217
  %219 = load i32, i32 addrspace(3)* %218, align 4, !tbaa !8
  %220 = icmp sgt i32 %216, %219
  %221 = select i1 %220, i32 %219, i32 %216
  %222 = xor i1 %220, true
  %223 = zext i1 %222 to i32
  %224 = add nuw nsw i32 %209, %223
  %225 = zext i1 %220 to i32
  %226 = add nuw nsw i32 %211, %225
  %227 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %213
  store i32 %221, i32 addrspace(3)* %227, align 16
  %228 = or i32 %151, 5
  %229 = add nsw i32 %224, %133
  %230 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %229
  %231 = load i32, i32 addrspace(3)* %230, align 4, !tbaa !8
  %232 = add nsw i32 %141, %226
  %233 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %232
  %234 = load i32, i32 addrspace(3)* %233, align 4, !tbaa !8
  %235 = icmp sgt i32 %231, %234
  %236 = select i1 %235, i32 %234, i32 %231
  %237 = xor i1 %235, true
  %238 = zext i1 %237 to i32
  %239 = add nuw nsw i32 %224, %238
  %240 = zext i1 %235 to i32
  %241 = add nuw nsw i32 %226, %240
  %242 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %228
  store i32 %236, i32 addrspace(3)* %242, align 4
  %243 = or i32 %151, 6
  %244 = add nsw i32 %239, %133
  %245 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %244
  %246 = load i32, i32 addrspace(3)* %245, align 4, !tbaa !8
  %247 = add nsw i32 %141, %241
  %248 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %247
  %249 = load i32, i32 addrspace(3)* %248, align 4, !tbaa !8
  %250 = icmp sgt i32 %246, %249
  %251 = select i1 %250, i32 %249, i32 %246
  %252 = xor i1 %250, true
  %253 = zext i1 %252 to i32
  %254 = add nuw nsw i32 %239, %253
  %255 = zext i1 %250 to i32
  %256 = add nuw nsw i32 %241, %255
  %257 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %243
  store i32 %251, i32 addrspace(3)* %257, align 8
  %258 = or i32 %151, 7
  %259 = add nsw i32 %254, %133
  %260 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %259
  %261 = load i32, i32 addrspace(3)* %260, align 4, !tbaa !8
  %262 = add nsw i32 %141, %256
  %263 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %262
  %264 = load i32, i32 addrspace(3)* %263, align 4, !tbaa !8
  %265 = icmp sgt i32 %261, %264
  %266 = select i1 %265, i32 %264, i32 %261
  %267 = xor i1 %265, true
  %268 = zext i1 %267 to i32
  %269 = add nuw nsw i32 %254, %268
  %270 = zext i1 %265 to i32
  %271 = add nuw nsw i32 %256, %270
  %272 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %258
  store i32 %266, i32 addrspace(3)* %272, align 4
  %273 = add nuw nsw i32 %151, 8
  %274 = icmp eq i32 %273, 128
  br i1 %274, label %304, label %150, !llvm.loop !14

275:                                              ; preds = %847, %148
  %276 = phi i32 [ %850, %847 ], [ 0, %148 ]
  %277 = phi i32 [ %849, %847 ], [ 127, %148 ]
  %278 = phi i32 [ %848, %847 ], [ 127, %148 ]
  %279 = add nsw i32 %277, %133
  %280 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %279
  %281 = load i32, i32 addrspace(3)* %280, align 4, !tbaa !8
  %282 = add nsw i32 %140, %278
  %283 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %282
  %284 = load i32, i32 addrspace(3)* %283, align 4, !tbaa !8
  %285 = icmp sgt i32 %281, %284
  %286 = sub nuw nsw i32 127, %276
  %287 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %286
  br i1 %285, label %288, label %290

288:                                              ; preds = %275
  store i32 %281, i32 addrspace(3)* %287, align 4, !tbaa !8
  %289 = add nsw i32 %277, -1
  br label %292

290:                                              ; preds = %275
  store i32 %284, i32 addrspace(3)* %287, align 4, !tbaa !8
  %291 = add nsw i32 %278, -1
  br label %292

292:                                              ; preds = %290, %288
  %293 = phi i32 [ %278, %288 ], [ %291, %290 ]
  %294 = phi i32 [ %289, %288 ], [ %277, %290 ]
  %295 = add nsw i32 %294, %133
  %296 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %295
  %297 = load i32, i32 addrspace(3)* %296, align 4, !tbaa !8
  %298 = add nsw i32 %140, %293
  %299 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %298
  %300 = load i32, i32 addrspace(3)* %299, align 4, !tbaa !8
  %301 = icmp sgt i32 %297, %300
  %302 = sub nsw i32 126, %276
  %303 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %302
  br i1 %301, label %749, label %747

304:                                              ; preds = %847, %150
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %142, label %305, label %388

305:                                              ; preds = %305, %304
  %306 = phi i32 [ %386, %305 ], [ 0, %304 ]
  %307 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %306
  %308 = load i32, i32 addrspace(3)* %307, align 16, !tbaa !8
  %309 = add nuw nsw i32 %306, %133
  %310 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %309
  store i32 %308, i32 addrspace(3)* %310, align 16, !tbaa !8
  %311 = or i32 %306, 1
  %312 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %311
  %313 = load i32, i32 addrspace(3)* %312, align 4, !tbaa !8
  %314 = add nuw nsw i32 %311, %133
  %315 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %314
  store i32 %313, i32 addrspace(3)* %315, align 4, !tbaa !8
  %316 = or i32 %306, 2
  %317 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %316
  %318 = load i32, i32 addrspace(3)* %317, align 8, !tbaa !8
  %319 = add nuw nsw i32 %316, %133
  %320 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %319
  store i32 %318, i32 addrspace(3)* %320, align 8, !tbaa !8
  %321 = or i32 %306, 3
  %322 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %321
  %323 = load i32, i32 addrspace(3)* %322, align 4, !tbaa !8
  %324 = add nuw nsw i32 %321, %133
  %325 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %324
  store i32 %323, i32 addrspace(3)* %325, align 4, !tbaa !8
  %326 = or i32 %306, 4
  %327 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %326
  %328 = load i32, i32 addrspace(3)* %327, align 16, !tbaa !8
  %329 = add nuw nsw i32 %326, %133
  %330 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %329
  store i32 %328, i32 addrspace(3)* %330, align 16, !tbaa !8
  %331 = or i32 %306, 5
  %332 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %331
  %333 = load i32, i32 addrspace(3)* %332, align 4, !tbaa !8
  %334 = add nuw nsw i32 %331, %133
  %335 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %334
  store i32 %333, i32 addrspace(3)* %335, align 4, !tbaa !8
  %336 = or i32 %306, 6
  %337 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %336
  %338 = load i32, i32 addrspace(3)* %337, align 8, !tbaa !8
  %339 = add nuw nsw i32 %336, %133
  %340 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %339
  store i32 %338, i32 addrspace(3)* %340, align 8, !tbaa !8
  %341 = or i32 %306, 7
  %342 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %341
  %343 = load i32, i32 addrspace(3)* %342, align 4, !tbaa !8
  %344 = add nuw nsw i32 %341, %133
  %345 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %344
  store i32 %343, i32 addrspace(3)* %345, align 4, !tbaa !8
  %346 = or i32 %306, 8
  %347 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %346
  %348 = load i32, i32 addrspace(3)* %347, align 16, !tbaa !8
  %349 = add nuw nsw i32 %346, %133
  %350 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %349
  store i32 %348, i32 addrspace(3)* %350, align 16, !tbaa !8
  %351 = or i32 %306, 9
  %352 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %351
  %353 = load i32, i32 addrspace(3)* %352, align 4, !tbaa !8
  %354 = add nuw nsw i32 %351, %133
  %355 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %354
  store i32 %353, i32 addrspace(3)* %355, align 4, !tbaa !8
  %356 = or i32 %306, 10
  %357 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %356
  %358 = load i32, i32 addrspace(3)* %357, align 8, !tbaa !8
  %359 = add nuw nsw i32 %356, %133
  %360 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %359
  store i32 %358, i32 addrspace(3)* %360, align 8, !tbaa !8
  %361 = or i32 %306, 11
  %362 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %361
  %363 = load i32, i32 addrspace(3)* %362, align 4, !tbaa !8
  %364 = add nuw nsw i32 %361, %133
  %365 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %364
  store i32 %363, i32 addrspace(3)* %365, align 4, !tbaa !8
  %366 = or i32 %306, 12
  %367 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %366
  %368 = load i32, i32 addrspace(3)* %367, align 16, !tbaa !8
  %369 = add nuw nsw i32 %366, %133
  %370 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %369
  store i32 %368, i32 addrspace(3)* %370, align 16, !tbaa !8
  %371 = or i32 %306, 13
  %372 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %371
  %373 = load i32, i32 addrspace(3)* %372, align 4, !tbaa !8
  %374 = add nuw nsw i32 %371, %133
  %375 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %374
  store i32 %373, i32 addrspace(3)* %375, align 4, !tbaa !8
  %376 = or i32 %306, 14
  %377 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %376
  %378 = load i32, i32 addrspace(3)* %377, align 8, !tbaa !8
  %379 = add nuw nsw i32 %376, %133
  %380 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %379
  store i32 %378, i32 addrspace(3)* %380, align 8, !tbaa !8
  %381 = or i32 %306, 15
  %382 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %381
  %383 = load i32, i32 addrspace(3)* %382, align 4, !tbaa !8
  %384 = add nuw nsw i32 %381, %133
  %385 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %384
  store i32 %383, i32 addrspace(3)* %385, align 4, !tbaa !8
  %386 = add nuw nsw i32 %306, 16
  %387 = icmp eq i32 %386, 128
  br i1 %387, label %388, label %305, !llvm.loop !15

388:                                              ; preds = %305, %304
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %143, label %389, label %514

389:                                              ; preds = %389, %388
  %390 = phi i32 [ %512, %389 ], [ 0, %388 ]
  %391 = phi i32 [ %510, %389 ], [ 0, %388 ]
  %392 = phi i32 [ %508, %389 ], [ 0, %388 ]
  %393 = add nsw i32 %392, %133
  %394 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %393
  %395 = load i32, i32 addrspace(3)* %394, align 4, !tbaa !8
  %396 = add nsw i32 %141, %391
  %397 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %396
  %398 = load i32, i32 addrspace(3)* %397, align 4, !tbaa !8
  %399 = icmp sgt i32 %395, %398
  %400 = select i1 %399, i32 %398, i32 %395
  %401 = xor i1 %399, true
  %402 = zext i1 %401 to i32
  %403 = add nuw nsw i32 %392, %402
  %404 = zext i1 %399 to i32
  %405 = add nuw nsw i32 %391, %404
  %406 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %390
  store i32 %400, i32 addrspace(3)* %406, align 16
  %407 = or i32 %390, 1
  %408 = add nsw i32 %403, %133
  %409 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %408
  %410 = load i32, i32 addrspace(3)* %409, align 4, !tbaa !8
  %411 = add nsw i32 %141, %405
  %412 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %411
  %413 = load i32, i32 addrspace(3)* %412, align 4, !tbaa !8
  %414 = icmp sgt i32 %410, %413
  %415 = select i1 %414, i32 %413, i32 %410
  %416 = xor i1 %414, true
  %417 = zext i1 %416 to i32
  %418 = add nuw nsw i32 %403, %417
  %419 = zext i1 %414 to i32
  %420 = add nuw nsw i32 %405, %419
  %421 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %407
  store i32 %415, i32 addrspace(3)* %421, align 4
  %422 = or i32 %390, 2
  %423 = add nsw i32 %418, %133
  %424 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %423
  %425 = load i32, i32 addrspace(3)* %424, align 4, !tbaa !8
  %426 = add nsw i32 %141, %420
  %427 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %426
  %428 = load i32, i32 addrspace(3)* %427, align 4, !tbaa !8
  %429 = icmp sgt i32 %425, %428
  %430 = select i1 %429, i32 %428, i32 %425
  %431 = xor i1 %429, true
  %432 = zext i1 %431 to i32
  %433 = add nuw nsw i32 %418, %432
  %434 = zext i1 %429 to i32
  %435 = add nuw nsw i32 %420, %434
  %436 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %422
  store i32 %430, i32 addrspace(3)* %436, align 8
  %437 = or i32 %390, 3
  %438 = add nsw i32 %433, %133
  %439 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %438
  %440 = load i32, i32 addrspace(3)* %439, align 4, !tbaa !8
  %441 = add nsw i32 %141, %435
  %442 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %441
  %443 = load i32, i32 addrspace(3)* %442, align 4, !tbaa !8
  %444 = icmp sgt i32 %440, %443
  %445 = select i1 %444, i32 %443, i32 %440
  %446 = xor i1 %444, true
  %447 = zext i1 %446 to i32
  %448 = add nuw nsw i32 %433, %447
  %449 = zext i1 %444 to i32
  %450 = add nuw nsw i32 %435, %449
  %451 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %437
  store i32 %445, i32 addrspace(3)* %451, align 4
  %452 = or i32 %390, 4
  %453 = add nsw i32 %448, %133
  %454 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %453
  %455 = load i32, i32 addrspace(3)* %454, align 4, !tbaa !8
  %456 = add nsw i32 %141, %450
  %457 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %456
  %458 = load i32, i32 addrspace(3)* %457, align 4, !tbaa !8
  %459 = icmp sgt i32 %455, %458
  %460 = select i1 %459, i32 %458, i32 %455
  %461 = xor i1 %459, true
  %462 = zext i1 %461 to i32
  %463 = add nuw nsw i32 %448, %462
  %464 = zext i1 %459 to i32
  %465 = add nuw nsw i32 %450, %464
  %466 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %452
  store i32 %460, i32 addrspace(3)* %466, align 16
  %467 = or i32 %390, 5
  %468 = add nsw i32 %463, %133
  %469 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %468
  %470 = load i32, i32 addrspace(3)* %469, align 4, !tbaa !8
  %471 = add nsw i32 %141, %465
  %472 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %471
  %473 = load i32, i32 addrspace(3)* %472, align 4, !tbaa !8
  %474 = icmp sgt i32 %470, %473
  %475 = select i1 %474, i32 %473, i32 %470
  %476 = xor i1 %474, true
  %477 = zext i1 %476 to i32
  %478 = add nuw nsw i32 %463, %477
  %479 = zext i1 %474 to i32
  %480 = add nuw nsw i32 %465, %479
  %481 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %467
  store i32 %475, i32 addrspace(3)* %481, align 4
  %482 = or i32 %390, 6
  %483 = add nsw i32 %478, %133
  %484 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %483
  %485 = load i32, i32 addrspace(3)* %484, align 4, !tbaa !8
  %486 = add nsw i32 %141, %480
  %487 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %486
  %488 = load i32, i32 addrspace(3)* %487, align 4, !tbaa !8
  %489 = icmp sgt i32 %485, %488
  %490 = select i1 %489, i32 %488, i32 %485
  %491 = xor i1 %489, true
  %492 = zext i1 %491 to i32
  %493 = add nuw nsw i32 %478, %492
  %494 = zext i1 %489 to i32
  %495 = add nuw nsw i32 %480, %494
  %496 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %482
  store i32 %490, i32 addrspace(3)* %496, align 8
  %497 = or i32 %390, 7
  %498 = add nsw i32 %493, %133
  %499 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %498
  %500 = load i32, i32 addrspace(3)* %499, align 4, !tbaa !8
  %501 = add nsw i32 %141, %495
  %502 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %501
  %503 = load i32, i32 addrspace(3)* %502, align 4, !tbaa !8
  %504 = icmp sgt i32 %500, %503
  %505 = select i1 %504, i32 %503, i32 %500
  %506 = xor i1 %504, true
  %507 = zext i1 %506 to i32
  %508 = add nuw nsw i32 %493, %507
  %509 = zext i1 %504 to i32
  %510 = add nuw nsw i32 %495, %509
  %511 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %497
  store i32 %505, i32 addrspace(3)* %511, align 4
  %512 = add nuw nsw i32 %390, 8
  %513 = icmp eq i32 %512, 128
  br i1 %513, label %544, label %389, !llvm.loop !16

514:                                              ; preds = %388
  br i1 %144, label %544, label %515

515:                                              ; preds = %952, %514
  %516 = phi i32 [ %955, %952 ], [ 0, %514 ]
  %517 = phi i32 [ %954, %952 ], [ 127, %514 ]
  %518 = phi i32 [ %953, %952 ], [ 127, %514 ]
  %519 = add nsw i32 %517, %133
  %520 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %519
  %521 = load i32, i32 addrspace(3)* %520, align 4, !tbaa !8
  %522 = add nsw i32 %140, %518
  %523 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %522
  %524 = load i32, i32 addrspace(3)* %523, align 4, !tbaa !8
  %525 = icmp sgt i32 %521, %524
  %526 = sub nuw nsw i32 127, %516
  %527 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %526
  br i1 %525, label %528, label %530

528:                                              ; preds = %515
  store i32 %521, i32 addrspace(3)* %527, align 4, !tbaa !8
  %529 = add nsw i32 %517, -1
  br label %532

530:                                              ; preds = %515
  store i32 %524, i32 addrspace(3)* %527, align 4, !tbaa !8
  %531 = add nsw i32 %518, -1
  br label %532

532:                                              ; preds = %530, %528
  %533 = phi i32 [ %518, %528 ], [ %531, %530 ]
  %534 = phi i32 [ %529, %528 ], [ %517, %530 ]
  %535 = add nsw i32 %534, %133
  %536 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %535
  %537 = load i32, i32 addrspace(3)* %536, align 4, !tbaa !8
  %538 = add nsw i32 %140, %533
  %539 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %538
  %540 = load i32, i32 addrspace(3)* %539, align 4, !tbaa !8
  %541 = icmp sgt i32 %537, %540
  %542 = sub nsw i32 126, %516
  %543 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %542
  br i1 %541, label %854, label %852

544:                                              ; preds = %952, %514, %389
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %142, label %545, label %628

545:                                              ; preds = %545, %544
  %546 = phi i32 [ %626, %545 ], [ 0, %544 ]
  %547 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %546
  %548 = load i32, i32 addrspace(3)* %547, align 16, !tbaa !8
  %549 = add nuw nsw i32 %546, %133
  %550 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %549
  store i32 %548, i32 addrspace(3)* %550, align 16, !tbaa !8
  %551 = or i32 %546, 1
  %552 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %551
  %553 = load i32, i32 addrspace(3)* %552, align 4, !tbaa !8
  %554 = add nuw nsw i32 %551, %133
  %555 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %554
  store i32 %553, i32 addrspace(3)* %555, align 4, !tbaa !8
  %556 = or i32 %546, 2
  %557 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %556
  %558 = load i32, i32 addrspace(3)* %557, align 8, !tbaa !8
  %559 = add nuw nsw i32 %556, %133
  %560 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %559
  store i32 %558, i32 addrspace(3)* %560, align 8, !tbaa !8
  %561 = or i32 %546, 3
  %562 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %561
  %563 = load i32, i32 addrspace(3)* %562, align 4, !tbaa !8
  %564 = add nuw nsw i32 %561, %133
  %565 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %564
  store i32 %563, i32 addrspace(3)* %565, align 4, !tbaa !8
  %566 = or i32 %546, 4
  %567 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %566
  %568 = load i32, i32 addrspace(3)* %567, align 16, !tbaa !8
  %569 = add nuw nsw i32 %566, %133
  %570 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %569
  store i32 %568, i32 addrspace(3)* %570, align 16, !tbaa !8
  %571 = or i32 %546, 5
  %572 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %571
  %573 = load i32, i32 addrspace(3)* %572, align 4, !tbaa !8
  %574 = add nuw nsw i32 %571, %133
  %575 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %574
  store i32 %573, i32 addrspace(3)* %575, align 4, !tbaa !8
  %576 = or i32 %546, 6
  %577 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %576
  %578 = load i32, i32 addrspace(3)* %577, align 8, !tbaa !8
  %579 = add nuw nsw i32 %576, %133
  %580 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %579
  store i32 %578, i32 addrspace(3)* %580, align 8, !tbaa !8
  %581 = or i32 %546, 7
  %582 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %581
  %583 = load i32, i32 addrspace(3)* %582, align 4, !tbaa !8
  %584 = add nuw nsw i32 %581, %133
  %585 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %584
  store i32 %583, i32 addrspace(3)* %585, align 4, !tbaa !8
  %586 = or i32 %546, 8
  %587 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %586
  %588 = load i32, i32 addrspace(3)* %587, align 16, !tbaa !8
  %589 = add nuw nsw i32 %586, %133
  %590 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %589
  store i32 %588, i32 addrspace(3)* %590, align 16, !tbaa !8
  %591 = or i32 %546, 9
  %592 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %591
  %593 = load i32, i32 addrspace(3)* %592, align 4, !tbaa !8
  %594 = add nuw nsw i32 %591, %133
  %595 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %594
  store i32 %593, i32 addrspace(3)* %595, align 4, !tbaa !8
  %596 = or i32 %546, 10
  %597 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %596
  %598 = load i32, i32 addrspace(3)* %597, align 8, !tbaa !8
  %599 = add nuw nsw i32 %596, %133
  %600 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %599
  store i32 %598, i32 addrspace(3)* %600, align 8, !tbaa !8
  %601 = or i32 %546, 11
  %602 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %601
  %603 = load i32, i32 addrspace(3)* %602, align 4, !tbaa !8
  %604 = add nuw nsw i32 %601, %133
  %605 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %604
  store i32 %603, i32 addrspace(3)* %605, align 4, !tbaa !8
  %606 = or i32 %546, 12
  %607 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %606
  %608 = load i32, i32 addrspace(3)* %607, align 16, !tbaa !8
  %609 = add nuw nsw i32 %606, %133
  %610 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %609
  store i32 %608, i32 addrspace(3)* %610, align 16, !tbaa !8
  %611 = or i32 %546, 13
  %612 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %611
  %613 = load i32, i32 addrspace(3)* %612, align 4, !tbaa !8
  %614 = add nuw nsw i32 %611, %133
  %615 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %614
  store i32 %613, i32 addrspace(3)* %615, align 4, !tbaa !8
  %616 = or i32 %546, 14
  %617 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %616
  %618 = load i32, i32 addrspace(3)* %617, align 8, !tbaa !8
  %619 = add nuw nsw i32 %616, %133
  %620 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %619
  store i32 %618, i32 addrspace(3)* %620, align 8, !tbaa !8
  %621 = or i32 %546, 15
  %622 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %621
  %623 = load i32, i32 addrspace(3)* %622, align 4, !tbaa !8
  %624 = add nuw nsw i32 %621, %133
  %625 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %624
  store i32 %623, i32 addrspace(3)* %625, align 4, !tbaa !8
  %626 = add nuw nsw i32 %546, 16
  %627 = icmp eq i32 %626, 128
  br i1 %627, label %628, label %545, !llvm.loop !17

628:                                              ; preds = %545, %544
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %629 = add nuw nsw i32 %149, 1
  %630 = icmp eq i32 %629, 32
  br i1 %630, label %145, label %148, !llvm.loop !18

631:                                              ; preds = %631, %146
  %632 = phi i32 [ 0, %146 ], [ %744, %631 ]
  %633 = add nuw nsw i32 %632, %133
  %634 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %633
  %635 = load i32, i32 addrspace(3)* %634, align 16, !tbaa !8
  %636 = add nuw nsw i32 %632, %147
  %637 = sext i32 %636 to i64
  %638 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %637
  store i32 %635, i32 addrspace(1)* %638, align 4, !tbaa !8
  %639 = or i32 %632, 1
  %640 = add nuw nsw i32 %639, %133
  %641 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %640
  %642 = load i32, i32 addrspace(3)* %641, align 4, !tbaa !8
  %643 = add nuw nsw i32 %639, %147
  %644 = sext i32 %643 to i64
  %645 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %644
  store i32 %642, i32 addrspace(1)* %645, align 4, !tbaa !8
  %646 = or i32 %632, 2
  %647 = add nuw nsw i32 %646, %133
  %648 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %647
  %649 = load i32, i32 addrspace(3)* %648, align 8, !tbaa !8
  %650 = add nuw nsw i32 %646, %147
  %651 = sext i32 %650 to i64
  %652 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %651
  store i32 %649, i32 addrspace(1)* %652, align 4, !tbaa !8
  %653 = or i32 %632, 3
  %654 = add nuw nsw i32 %653, %133
  %655 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %654
  %656 = load i32, i32 addrspace(3)* %655, align 4, !tbaa !8
  %657 = add nuw nsw i32 %653, %147
  %658 = sext i32 %657 to i64
  %659 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %658
  store i32 %656, i32 addrspace(1)* %659, align 4, !tbaa !8
  %660 = or i32 %632, 4
  %661 = add nuw nsw i32 %660, %133
  %662 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %661
  %663 = load i32, i32 addrspace(3)* %662, align 16, !tbaa !8
  %664 = add nuw nsw i32 %660, %147
  %665 = sext i32 %664 to i64
  %666 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %665
  store i32 %663, i32 addrspace(1)* %666, align 4, !tbaa !8
  %667 = or i32 %632, 5
  %668 = add nuw nsw i32 %667, %133
  %669 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %668
  %670 = load i32, i32 addrspace(3)* %669, align 4, !tbaa !8
  %671 = add nuw nsw i32 %667, %147
  %672 = sext i32 %671 to i64
  %673 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %672
  store i32 %670, i32 addrspace(1)* %673, align 4, !tbaa !8
  %674 = or i32 %632, 6
  %675 = add nuw nsw i32 %674, %133
  %676 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %675
  %677 = load i32, i32 addrspace(3)* %676, align 8, !tbaa !8
  %678 = add nuw nsw i32 %674, %147
  %679 = sext i32 %678 to i64
  %680 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %679
  store i32 %677, i32 addrspace(1)* %680, align 4, !tbaa !8
  %681 = or i32 %632, 7
  %682 = add nuw nsw i32 %681, %133
  %683 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %682
  %684 = load i32, i32 addrspace(3)* %683, align 4, !tbaa !8
  %685 = add nuw nsw i32 %681, %147
  %686 = sext i32 %685 to i64
  %687 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %686
  store i32 %684, i32 addrspace(1)* %687, align 4, !tbaa !8
  %688 = or i32 %632, 8
  %689 = add nuw nsw i32 %688, %133
  %690 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %689
  %691 = load i32, i32 addrspace(3)* %690, align 16, !tbaa !8
  %692 = add nuw nsw i32 %688, %147
  %693 = sext i32 %692 to i64
  %694 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %693
  store i32 %691, i32 addrspace(1)* %694, align 4, !tbaa !8
  %695 = or i32 %632, 9
  %696 = add nuw nsw i32 %695, %133
  %697 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %696
  %698 = load i32, i32 addrspace(3)* %697, align 4, !tbaa !8
  %699 = add nuw nsw i32 %695, %147
  %700 = sext i32 %699 to i64
  %701 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %700
  store i32 %698, i32 addrspace(1)* %701, align 4, !tbaa !8
  %702 = or i32 %632, 10
  %703 = add nuw nsw i32 %702, %133
  %704 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %703
  %705 = load i32, i32 addrspace(3)* %704, align 8, !tbaa !8
  %706 = add nuw nsw i32 %702, %147
  %707 = sext i32 %706 to i64
  %708 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %707
  store i32 %705, i32 addrspace(1)* %708, align 4, !tbaa !8
  %709 = or i32 %632, 11
  %710 = add nuw nsw i32 %709, %133
  %711 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %710
  %712 = load i32, i32 addrspace(3)* %711, align 4, !tbaa !8
  %713 = add nuw nsw i32 %709, %147
  %714 = sext i32 %713 to i64
  %715 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %714
  store i32 %712, i32 addrspace(1)* %715, align 4, !tbaa !8
  %716 = or i32 %632, 12
  %717 = add nuw nsw i32 %716, %133
  %718 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %717
  %719 = load i32, i32 addrspace(3)* %718, align 16, !tbaa !8
  %720 = add nuw nsw i32 %716, %147
  %721 = sext i32 %720 to i64
  %722 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %721
  store i32 %719, i32 addrspace(1)* %722, align 4, !tbaa !8
  %723 = or i32 %632, 13
  %724 = add nuw nsw i32 %723, %133
  %725 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %724
  %726 = load i32, i32 addrspace(3)* %725, align 4, !tbaa !8
  %727 = add nuw nsw i32 %723, %147
  %728 = sext i32 %727 to i64
  %729 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %728
  store i32 %726, i32 addrspace(1)* %729, align 4, !tbaa !8
  %730 = or i32 %632, 14
  %731 = add nuw nsw i32 %730, %133
  %732 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %731
  %733 = load i32, i32 addrspace(3)* %732, align 8, !tbaa !8
  %734 = add nuw nsw i32 %730, %147
  %735 = sext i32 %734 to i64
  %736 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %735
  store i32 %733, i32 addrspace(1)* %736, align 4, !tbaa !8
  %737 = or i32 %632, 15
  %738 = add nuw nsw i32 %737, %133
  %739 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %738
  %740 = load i32, i32 addrspace(3)* %739, align 4, !tbaa !8
  %741 = add nuw nsw i32 %737, %147
  %742 = sext i32 %741 to i64
  %743 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %742
  store i32 %740, i32 addrspace(1)* %743, align 4, !tbaa !8
  %744 = add nuw nsw i32 %632, 16
  %745 = icmp eq i32 %744, 128
  br i1 %745, label %746, label %631, !llvm.loop !19

746:                                              ; preds = %631, %145
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  ret void

747:                                              ; preds = %292
  store i32 %300, i32 addrspace(3)* %303, align 8, !tbaa !8
  %748 = add nsw i32 %293, -1
  br label %751

749:                                              ; preds = %292
  store i32 %297, i32 addrspace(3)* %303, align 8, !tbaa !8
  %750 = add nsw i32 %294, -1
  br label %751

751:                                              ; preds = %749, %747
  %752 = phi i32 [ %293, %749 ], [ %748, %747 ]
  %753 = phi i32 [ %750, %749 ], [ %294, %747 ]
  %754 = add nsw i32 %753, %133
  %755 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %754
  %756 = load i32, i32 addrspace(3)* %755, align 4, !tbaa !8
  %757 = add nsw i32 %140, %752
  %758 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %757
  %759 = load i32, i32 addrspace(3)* %758, align 4, !tbaa !8
  %760 = icmp sgt i32 %756, %759
  %761 = sub nsw i32 125, %276
  %762 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %761
  br i1 %760, label %765, label %763

763:                                              ; preds = %751
  store i32 %759, i32 addrspace(3)* %762, align 4, !tbaa !8
  %764 = add nsw i32 %752, -1
  br label %767

765:                                              ; preds = %751
  store i32 %756, i32 addrspace(3)* %762, align 4, !tbaa !8
  %766 = add nsw i32 %753, -1
  br label %767

767:                                              ; preds = %765, %763
  %768 = phi i32 [ %752, %765 ], [ %764, %763 ]
  %769 = phi i32 [ %766, %765 ], [ %753, %763 ]
  %770 = add nsw i32 %769, %133
  %771 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %770
  %772 = load i32, i32 addrspace(3)* %771, align 4, !tbaa !8
  %773 = add nsw i32 %140, %768
  %774 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %773
  %775 = load i32, i32 addrspace(3)* %774, align 4, !tbaa !8
  %776 = icmp sgt i32 %772, %775
  %777 = sub nsw i32 124, %276
  %778 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %777
  br i1 %776, label %781, label %779

779:                                              ; preds = %767
  store i32 %775, i32 addrspace(3)* %778, align 16, !tbaa !8
  %780 = add nsw i32 %768, -1
  br label %783

781:                                              ; preds = %767
  store i32 %772, i32 addrspace(3)* %778, align 16, !tbaa !8
  %782 = add nsw i32 %769, -1
  br label %783

783:                                              ; preds = %781, %779
  %784 = phi i32 [ %768, %781 ], [ %780, %779 ]
  %785 = phi i32 [ %782, %781 ], [ %769, %779 ]
  %786 = add nsw i32 %785, %133
  %787 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %786
  %788 = load i32, i32 addrspace(3)* %787, align 4, !tbaa !8
  %789 = add nsw i32 %140, %784
  %790 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %789
  %791 = load i32, i32 addrspace(3)* %790, align 4, !tbaa !8
  %792 = icmp sgt i32 %788, %791
  %793 = sub nsw i32 123, %276
  %794 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %793
  br i1 %792, label %797, label %795

795:                                              ; preds = %783
  store i32 %791, i32 addrspace(3)* %794, align 4, !tbaa !8
  %796 = add nsw i32 %784, -1
  br label %799

797:                                              ; preds = %783
  store i32 %788, i32 addrspace(3)* %794, align 4, !tbaa !8
  %798 = add nsw i32 %785, -1
  br label %799

799:                                              ; preds = %797, %795
  %800 = phi i32 [ %784, %797 ], [ %796, %795 ]
  %801 = phi i32 [ %798, %797 ], [ %785, %795 ]
  %802 = add nsw i32 %801, %133
  %803 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %802
  %804 = load i32, i32 addrspace(3)* %803, align 4, !tbaa !8
  %805 = add nsw i32 %140, %800
  %806 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %805
  %807 = load i32, i32 addrspace(3)* %806, align 4, !tbaa !8
  %808 = icmp sgt i32 %804, %807
  %809 = sub nsw i32 122, %276
  %810 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %809
  br i1 %808, label %813, label %811

811:                                              ; preds = %799
  store i32 %807, i32 addrspace(3)* %810, align 8, !tbaa !8
  %812 = add nsw i32 %800, -1
  br label %815

813:                                              ; preds = %799
  store i32 %804, i32 addrspace(3)* %810, align 8, !tbaa !8
  %814 = add nsw i32 %801, -1
  br label %815

815:                                              ; preds = %813, %811
  %816 = phi i32 [ %800, %813 ], [ %812, %811 ]
  %817 = phi i32 [ %814, %813 ], [ %801, %811 ]
  %818 = add nsw i32 %817, %133
  %819 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %818
  %820 = load i32, i32 addrspace(3)* %819, align 4, !tbaa !8
  %821 = add nsw i32 %140, %816
  %822 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %821
  %823 = load i32, i32 addrspace(3)* %822, align 4, !tbaa !8
  %824 = icmp sgt i32 %820, %823
  %825 = sub nsw i32 121, %276
  %826 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %825
  br i1 %824, label %829, label %827

827:                                              ; preds = %815
  store i32 %823, i32 addrspace(3)* %826, align 4, !tbaa !8
  %828 = add nsw i32 %816, -1
  br label %831

829:                                              ; preds = %815
  store i32 %820, i32 addrspace(3)* %826, align 4, !tbaa !8
  %830 = add nsw i32 %817, -1
  br label %831

831:                                              ; preds = %829, %827
  %832 = phi i32 [ %816, %829 ], [ %828, %827 ]
  %833 = phi i32 [ %830, %829 ], [ %817, %827 ]
  %834 = add nsw i32 %833, %133
  %835 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %834
  %836 = load i32, i32 addrspace(3)* %835, align 4, !tbaa !8
  %837 = add nsw i32 %140, %832
  %838 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %837
  %839 = load i32, i32 addrspace(3)* %838, align 4, !tbaa !8
  %840 = icmp sgt i32 %836, %839
  %841 = sub nsw i32 120, %276
  %842 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %841
  br i1 %840, label %845, label %843

843:                                              ; preds = %831
  store i32 %839, i32 addrspace(3)* %842, align 16, !tbaa !8
  %844 = add nsw i32 %832, -1
  br label %847

845:                                              ; preds = %831
  store i32 %836, i32 addrspace(3)* %842, align 16, !tbaa !8
  %846 = add nsw i32 %833, -1
  br label %847

847:                                              ; preds = %845, %843
  %848 = phi i32 [ %832, %845 ], [ %844, %843 ]
  %849 = phi i32 [ %846, %845 ], [ %833, %843 ]
  %850 = add nuw nsw i32 %276, 8
  %851 = icmp eq i32 %850, 128
  br i1 %851, label %304, label %275, !llvm.loop !20

852:                                              ; preds = %532
  store i32 %540, i32 addrspace(3)* %543, align 8, !tbaa !8
  %853 = add nsw i32 %533, -1
  br label %856

854:                                              ; preds = %532
  store i32 %537, i32 addrspace(3)* %543, align 8, !tbaa !8
  %855 = add nsw i32 %534, -1
  br label %856

856:                                              ; preds = %854, %852
  %857 = phi i32 [ %533, %854 ], [ %853, %852 ]
  %858 = phi i32 [ %855, %854 ], [ %534, %852 ]
  %859 = add nsw i32 %858, %133
  %860 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %859
  %861 = load i32, i32 addrspace(3)* %860, align 4, !tbaa !8
  %862 = add nsw i32 %140, %857
  %863 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %862
  %864 = load i32, i32 addrspace(3)* %863, align 4, !tbaa !8
  %865 = icmp sgt i32 %861, %864
  %866 = sub nsw i32 125, %516
  %867 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %866
  br i1 %865, label %870, label %868

868:                                              ; preds = %856
  store i32 %864, i32 addrspace(3)* %867, align 4, !tbaa !8
  %869 = add nsw i32 %857, -1
  br label %872

870:                                              ; preds = %856
  store i32 %861, i32 addrspace(3)* %867, align 4, !tbaa !8
  %871 = add nsw i32 %858, -1
  br label %872

872:                                              ; preds = %870, %868
  %873 = phi i32 [ %857, %870 ], [ %869, %868 ]
  %874 = phi i32 [ %871, %870 ], [ %858, %868 ]
  %875 = add nsw i32 %874, %133
  %876 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %875
  %877 = load i32, i32 addrspace(3)* %876, align 4, !tbaa !8
  %878 = add nsw i32 %140, %873
  %879 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %878
  %880 = load i32, i32 addrspace(3)* %879, align 4, !tbaa !8
  %881 = icmp sgt i32 %877, %880
  %882 = sub nsw i32 124, %516
  %883 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %882
  br i1 %881, label %886, label %884

884:                                              ; preds = %872
  store i32 %880, i32 addrspace(3)* %883, align 16, !tbaa !8
  %885 = add nsw i32 %873, -1
  br label %888

886:                                              ; preds = %872
  store i32 %877, i32 addrspace(3)* %883, align 16, !tbaa !8
  %887 = add nsw i32 %874, -1
  br label %888

888:                                              ; preds = %886, %884
  %889 = phi i32 [ %873, %886 ], [ %885, %884 ]
  %890 = phi i32 [ %887, %886 ], [ %874, %884 ]
  %891 = add nsw i32 %890, %133
  %892 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %891
  %893 = load i32, i32 addrspace(3)* %892, align 4, !tbaa !8
  %894 = add nsw i32 %140, %889
  %895 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %894
  %896 = load i32, i32 addrspace(3)* %895, align 4, !tbaa !8
  %897 = icmp sgt i32 %893, %896
  %898 = sub nsw i32 123, %516
  %899 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %898
  br i1 %897, label %902, label %900

900:                                              ; preds = %888
  store i32 %896, i32 addrspace(3)* %899, align 4, !tbaa !8
  %901 = add nsw i32 %889, -1
  br label %904

902:                                              ; preds = %888
  store i32 %893, i32 addrspace(3)* %899, align 4, !tbaa !8
  %903 = add nsw i32 %890, -1
  br label %904

904:                                              ; preds = %902, %900
  %905 = phi i32 [ %889, %902 ], [ %901, %900 ]
  %906 = phi i32 [ %903, %902 ], [ %890, %900 ]
  %907 = add nsw i32 %906, %133
  %908 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %907
  %909 = load i32, i32 addrspace(3)* %908, align 4, !tbaa !8
  %910 = add nsw i32 %140, %905
  %911 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %910
  %912 = load i32, i32 addrspace(3)* %911, align 4, !tbaa !8
  %913 = icmp sgt i32 %909, %912
  %914 = sub nsw i32 122, %516
  %915 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %914
  br i1 %913, label %918, label %916

916:                                              ; preds = %904
  store i32 %912, i32 addrspace(3)* %915, align 8, !tbaa !8
  %917 = add nsw i32 %905, -1
  br label %920

918:                                              ; preds = %904
  store i32 %909, i32 addrspace(3)* %915, align 8, !tbaa !8
  %919 = add nsw i32 %906, -1
  br label %920

920:                                              ; preds = %918, %916
  %921 = phi i32 [ %905, %918 ], [ %917, %916 ]
  %922 = phi i32 [ %919, %918 ], [ %906, %916 ]
  %923 = add nsw i32 %922, %133
  %924 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %923
  %925 = load i32, i32 addrspace(3)* %924, align 4, !tbaa !8
  %926 = add nsw i32 %140, %921
  %927 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %926
  %928 = load i32, i32 addrspace(3)* %927, align 4, !tbaa !8
  %929 = icmp sgt i32 %925, %928
  %930 = sub nsw i32 121, %516
  %931 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %930
  br i1 %929, label %934, label %932

932:                                              ; preds = %920
  store i32 %928, i32 addrspace(3)* %931, align 4, !tbaa !8
  %933 = add nsw i32 %921, -1
  br label %936

934:                                              ; preds = %920
  store i32 %925, i32 addrspace(3)* %931, align 4, !tbaa !8
  %935 = add nsw i32 %922, -1
  br label %936

936:                                              ; preds = %934, %932
  %937 = phi i32 [ %921, %934 ], [ %933, %932 ]
  %938 = phi i32 [ %935, %934 ], [ %922, %932 ]
  %939 = add nsw i32 %938, %133
  %940 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %939
  %941 = load i32, i32 addrspace(3)* %940, align 4, !tbaa !8
  %942 = add nsw i32 %140, %937
  %943 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %942
  %944 = load i32, i32 addrspace(3)* %943, align 4, !tbaa !8
  %945 = icmp sgt i32 %941, %944
  %946 = sub nsw i32 120, %516
  %947 = getelementptr inbounds i32, i32 addrspace(3)* %134, i32 %946
  br i1 %945, label %950, label %948

948:                                              ; preds = %936
  store i32 %944, i32 addrspace(3)* %947, align 16, !tbaa !8
  %949 = add nsw i32 %937, -1
  br label %952

950:                                              ; preds = %936
  store i32 %941, i32 addrspace(3)* %947, align 16, !tbaa !8
  %951 = add nsw i32 %938, -1
  br label %952

952:                                              ; preds = %950, %948
  %953 = phi i32 [ %937, %950 ], [ %949, %948 ]
  %954 = phi i32 [ %951, %950 ], [ %938, %948 ]
  %955 = add nuw nsw i32 %516, 8
  %956 = icmp eq i32 %955, 128
  br i1 %956, label %544, label %515, !llvm.loop !21
}

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

attributes #0 = { convergent norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { convergent nounwind willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i32 0, i32 1024}
!6 = !{i16 1, i16 1025}
!7 = !{}
!8 = !{!9, !9, i64 0}
!9 = !{!"int", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = distinct !{!12, !13}
!13 = !{!"llvm.loop.mustprogress"}
!14 = distinct !{!14, !13}
!15 = distinct !{!15, !13}
!16 = distinct !{!16, !13}
!17 = distinct !{!17, !13}
!18 = distinct !{!18, !13}
!19 = distinct !{!19, !13}
!20 = distinct !{!20, !13}
!21 = distinct !{!21, !13}
