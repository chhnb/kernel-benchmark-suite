; ModuleID = '/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-repro.XpJFTn/LUD8/compat.ll'
source_filename = "/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-benchmarks/benchmarks/LUD/lud_kernel.hip.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

@_ZZ12lud_diagonalPfiiE6shadow = internal unnamed_addr addrspace(3) global [8 x [8 x float]] undef, align 16
@_ZZ13lud_perimeterPfiiE3dia = internal unnamed_addr addrspace(3) global [8 x [8 x float]] undef, align 16
@_ZZ13lud_perimeterPfiiE8peri_row = internal unnamed_addr addrspace(3) global [8 x [8 x float]] undef, align 16
@_ZZ13lud_perimeterPfiiE8peri_col = internal unnamed_addr addrspace(3) global [8 x [8 x float]] undef, align 16
@_ZZ12lud_internalPfiiE8peri_row = internal unnamed_addr addrspace(3) global [8 x [8 x float]] undef, align 16
@_ZZ12lud_internalPfiiE8peri_col = internal unnamed_addr addrspace(3) global [8 x [8 x float]] undef, align 16

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z12lud_diagonalPfii(float addrspace(1)* nocapture %0, i32 %1, i32 %2) local_unnamed_addr #0 {
  %4 = mul nsw i32 %2, %1
  %5 = add nsw i32 %4, %2
  %6 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %7 = zext i32 %6 to i64
  %8 = sext i32 %5 to i64
  %9 = add nsw i64 %8, %7
  %10 = getelementptr inbounds float, float addrspace(1)* %0, i64 %9
  %11 = load float, float addrspace(1)* %10, align 4, !tbaa !6
  %12 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  store float %11, float addrspace(3)* %12, align 4, !tbaa !6
  %13 = add nsw i32 %5, %1
  %14 = sext i32 %13 to i64
  %15 = add nsw i64 %14, %7
  %16 = getelementptr inbounds float, float addrspace(1)* %0, i64 %15
  %17 = load float, float addrspace(1)* %16, align 4, !tbaa !6
  %18 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  store float %17, float addrspace(3)* %18, align 4, !tbaa !6
  %19 = add nsw i32 %13, %1
  %20 = sext i32 %19 to i64
  %21 = add nsw i64 %20, %7
  %22 = getelementptr inbounds float, float addrspace(1)* %0, i64 %21
  %23 = load float, float addrspace(1)* %22, align 4, !tbaa !6
  %24 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  store float %23, float addrspace(3)* %24, align 4, !tbaa !6
  %25 = add nsw i32 %19, %1
  %26 = sext i32 %25 to i64
  %27 = add nsw i64 %26, %7
  %28 = getelementptr inbounds float, float addrspace(1)* %0, i64 %27
  %29 = load float, float addrspace(1)* %28, align 4, !tbaa !6
  %30 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  store float %29, float addrspace(3)* %30, align 4, !tbaa !6
  %31 = add nsw i32 %25, %1
  %32 = sext i32 %31 to i64
  %33 = add nsw i64 %32, %7
  %34 = getelementptr inbounds float, float addrspace(1)* %0, i64 %33
  %35 = load float, float addrspace(1)* %34, align 4, !tbaa !6
  %36 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  store float %35, float addrspace(3)* %36, align 4, !tbaa !6
  %37 = add nsw i32 %31, %1
  %38 = sext i32 %37 to i64
  %39 = add nsw i64 %38, %7
  %40 = getelementptr inbounds float, float addrspace(1)* %0, i64 %39
  %41 = load float, float addrspace(1)* %40, align 4, !tbaa !6
  %42 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  store float %41, float addrspace(3)* %42, align 4, !tbaa !6
  %43 = add nsw i32 %37, %1
  %44 = sext i32 %43 to i64
  %45 = add nsw i64 %44, %7
  %46 = getelementptr inbounds float, float addrspace(1)* %0, i64 %45
  %47 = load float, float addrspace(1)* %46, align 4, !tbaa !6
  %48 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 %6
  store float %47, float addrspace(3)* %48, align 4, !tbaa !6
  %49 = add nsw i32 %43, %1
  %50 = sext i32 %49 to i64
  %51 = add nsw i64 %50, %7
  %52 = getelementptr inbounds float, float addrspace(1)* %0, i64 %51
  %53 = load float, float addrspace(1)* %52, align 4, !tbaa !6
  %54 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 %6
  store float %53, float addrspace(3)* %54, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %55 = icmp eq i32 %6, 0
  br i1 %55, label %62, label %56

56:                                               ; preds = %3
  %57 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %58 = load float, float addrspace(3)* %57, align 16, !tbaa !6
  %59 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 0), align 16, !tbaa !6
  %60 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %61 = fdiv contract float %58, %59
  store float %61, float addrspace(3)* %60, align 16, !tbaa !6
  br label %62

62:                                               ; preds = %56, %3
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %55, label %70, label %63

63:                                               ; preds = %62
  %64 = load float, float addrspace(3)* %18, align 4, !tbaa !6
  %65 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %66 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 0), align 16, !tbaa !6
  %67 = load float, float addrspace(3)* %65, align 4, !tbaa !6
  %68 = fmul contract float %66, %67
  %69 = fsub contract float %64, %68
  store float %69, float addrspace(3)* %18, align 4, !tbaa !6
  br label %70

70:                                               ; preds = %63, %62
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %71 = icmp ugt i32 %6, 1
  br i1 %71, label %72, label %83

72:                                               ; preds = %70
  %73 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %74 = load float, float addrspace(3)* %73, align 4, !tbaa !6
  %75 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %76 = load float, float addrspace(3)* %75, align 16, !tbaa !6
  %77 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 1), align 4, !tbaa !6
  %78 = fmul contract float %76, %77
  %79 = fsub contract float %74, %78
  store float %79, float addrspace(3)* %73, align 4, !tbaa !6
  %80 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 1), align 4, !tbaa !6
  %81 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %82 = fdiv contract float %79, %80
  store float %82, float addrspace(3)* %81, align 4, !tbaa !6
  br label %83

83:                                               ; preds = %72, %70
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %71, label %84, label %96

84:                                               ; preds = %83
  %85 = load float, float addrspace(3)* %24, align 4, !tbaa !6
  %86 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 0), align 16, !tbaa !6
  %87 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %88 = load float, float addrspace(3)* %87, align 4, !tbaa !6
  %89 = fmul contract float %86, %88
  %90 = fsub contract float %85, %89
  store float %90, float addrspace(3)* %24, align 4, !tbaa !6
  %91 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 1), align 4, !tbaa !6
  %92 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %93 = load float, float addrspace(3)* %92, align 4, !tbaa !6
  %94 = fmul contract float %91, %93
  %95 = fsub contract float %90, %94
  store float %95, float addrspace(3)* %24, align 4, !tbaa !6
  br label %96

96:                                               ; preds = %84, %83
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %97 = icmp ugt i32 %6, 2
  br i1 %97, label %98, label %114

98:                                               ; preds = %96
  %99 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %100 = load float, float addrspace(3)* %99, align 8, !tbaa !6
  %101 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %102 = load float, float addrspace(3)* %101, align 16, !tbaa !6
  %103 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 2), align 8, !tbaa !6
  %104 = fmul contract float %102, %103
  %105 = fsub contract float %100, %104
  store float %105, float addrspace(3)* %99, align 8, !tbaa !6
  %106 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %107 = load float, float addrspace(3)* %106, align 4, !tbaa !6
  %108 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 2), align 8, !tbaa !6
  %109 = fmul contract float %107, %108
  %110 = fsub contract float %105, %109
  store float %110, float addrspace(3)* %99, align 8, !tbaa !6
  %111 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 2), align 8, !tbaa !6
  %112 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %113 = fdiv contract float %110, %111
  store float %113, float addrspace(3)* %112, align 8, !tbaa !6
  br label %114

114:                                              ; preds = %98, %96
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %97, label %115, label %132

115:                                              ; preds = %114
  %116 = load float, float addrspace(3)* %30, align 4, !tbaa !6
  %117 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 0), align 16, !tbaa !6
  %118 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %119 = load float, float addrspace(3)* %118, align 4, !tbaa !6
  %120 = fmul contract float %117, %119
  %121 = fsub contract float %116, %120
  store float %121, float addrspace(3)* %30, align 4, !tbaa !6
  %122 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 1), align 4, !tbaa !6
  %123 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %124 = load float, float addrspace(3)* %123, align 4, !tbaa !6
  %125 = fmul contract float %122, %124
  %126 = fsub contract float %121, %125
  store float %126, float addrspace(3)* %30, align 4, !tbaa !6
  %127 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 2), align 8, !tbaa !6
  %128 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %129 = load float, float addrspace(3)* %128, align 4, !tbaa !6
  %130 = fmul contract float %127, %129
  %131 = fsub contract float %126, %130
  store float %131, float addrspace(3)* %30, align 4, !tbaa !6
  br label %132

132:                                              ; preds = %115, %114
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %133 = icmp ugt i32 %6, 3
  br i1 %133, label %134, label %155

134:                                              ; preds = %132
  %135 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %136 = load float, float addrspace(3)* %135, align 4, !tbaa !6
  %137 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %138 = load float, float addrspace(3)* %137, align 16, !tbaa !6
  %139 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 3), align 4, !tbaa !6
  %140 = fmul contract float %138, %139
  %141 = fsub contract float %136, %140
  store float %141, float addrspace(3)* %135, align 4, !tbaa !6
  %142 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %143 = load float, float addrspace(3)* %142, align 4, !tbaa !6
  %144 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 3), align 4, !tbaa !6
  %145 = fmul contract float %143, %144
  %146 = fsub contract float %141, %145
  store float %146, float addrspace(3)* %135, align 4, !tbaa !6
  %147 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %148 = load float, float addrspace(3)* %147, align 8, !tbaa !6
  %149 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 3), align 4, !tbaa !6
  %150 = fmul contract float %148, %149
  %151 = fsub contract float %146, %150
  store float %151, float addrspace(3)* %135, align 4, !tbaa !6
  %152 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 3), align 4, !tbaa !6
  %153 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %154 = fdiv contract float %151, %152
  store float %154, float addrspace(3)* %153, align 4, !tbaa !6
  br label %155

155:                                              ; preds = %134, %132
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %133, label %156, label %178

156:                                              ; preds = %155
  %157 = load float, float addrspace(3)* %36, align 4, !tbaa !6
  %158 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 0), align 16, !tbaa !6
  %159 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %160 = load float, float addrspace(3)* %159, align 4, !tbaa !6
  %161 = fmul contract float %158, %160
  %162 = fsub contract float %157, %161
  store float %162, float addrspace(3)* %36, align 4, !tbaa !6
  %163 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 1), align 4, !tbaa !6
  %164 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %165 = load float, float addrspace(3)* %164, align 4, !tbaa !6
  %166 = fmul contract float %163, %165
  %167 = fsub contract float %162, %166
  store float %167, float addrspace(3)* %36, align 4, !tbaa !6
  %168 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 2), align 8, !tbaa !6
  %169 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %170 = load float, float addrspace(3)* %169, align 4, !tbaa !6
  %171 = fmul contract float %168, %170
  %172 = fsub contract float %167, %171
  store float %172, float addrspace(3)* %36, align 4, !tbaa !6
  %173 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 3), align 4, !tbaa !6
  %174 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %175 = load float, float addrspace(3)* %174, align 4, !tbaa !6
  %176 = fmul contract float %173, %175
  %177 = fsub contract float %172, %176
  store float %177, float addrspace(3)* %36, align 4, !tbaa !6
  br label %178

178:                                              ; preds = %156, %155
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %179 = icmp ugt i32 %6, 4
  br i1 %179, label %180, label %206

180:                                              ; preds = %178
  %181 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %182 = load float, float addrspace(3)* %181, align 16, !tbaa !6
  %183 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %184 = load float, float addrspace(3)* %183, align 16, !tbaa !6
  %185 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 4), align 16, !tbaa !6
  %186 = fmul contract float %184, %185
  %187 = fsub contract float %182, %186
  store float %187, float addrspace(3)* %181, align 16, !tbaa !6
  %188 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %189 = load float, float addrspace(3)* %188, align 4, !tbaa !6
  %190 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 4), align 16, !tbaa !6
  %191 = fmul contract float %189, %190
  %192 = fsub contract float %187, %191
  store float %192, float addrspace(3)* %181, align 16, !tbaa !6
  %193 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %194 = load float, float addrspace(3)* %193, align 8, !tbaa !6
  %195 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 4), align 16, !tbaa !6
  %196 = fmul contract float %194, %195
  %197 = fsub contract float %192, %196
  store float %197, float addrspace(3)* %181, align 16, !tbaa !6
  %198 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %199 = load float, float addrspace(3)* %198, align 4, !tbaa !6
  %200 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 4), align 16, !tbaa !6
  %201 = fmul contract float %199, %200
  %202 = fsub contract float %197, %201
  store float %202, float addrspace(3)* %181, align 16, !tbaa !6
  %203 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 4), align 16, !tbaa !6
  %204 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %205 = fdiv contract float %202, %203
  store float %205, float addrspace(3)* %204, align 16, !tbaa !6
  br label %206

206:                                              ; preds = %180, %178
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %179, label %207, label %234

207:                                              ; preds = %206
  %208 = load float, float addrspace(3)* %42, align 4, !tbaa !6
  %209 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 0), align 16, !tbaa !6
  %210 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %211 = load float, float addrspace(3)* %210, align 4, !tbaa !6
  %212 = fmul contract float %209, %211
  %213 = fsub contract float %208, %212
  store float %213, float addrspace(3)* %42, align 4, !tbaa !6
  %214 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 1), align 4, !tbaa !6
  %215 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %216 = load float, float addrspace(3)* %215, align 4, !tbaa !6
  %217 = fmul contract float %214, %216
  %218 = fsub contract float %213, %217
  store float %218, float addrspace(3)* %42, align 4, !tbaa !6
  %219 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 2), align 8, !tbaa !6
  %220 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %221 = load float, float addrspace(3)* %220, align 4, !tbaa !6
  %222 = fmul contract float %219, %221
  %223 = fsub contract float %218, %222
  store float %223, float addrspace(3)* %42, align 4, !tbaa !6
  %224 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 3), align 4, !tbaa !6
  %225 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %226 = load float, float addrspace(3)* %225, align 4, !tbaa !6
  %227 = fmul contract float %224, %226
  %228 = fsub contract float %223, %227
  store float %228, float addrspace(3)* %42, align 4, !tbaa !6
  %229 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 4), align 16, !tbaa !6
  %230 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %231 = load float, float addrspace(3)* %230, align 4, !tbaa !6
  %232 = fmul contract float %229, %231
  %233 = fsub contract float %228, %232
  store float %233, float addrspace(3)* %42, align 4, !tbaa !6
  br label %234

234:                                              ; preds = %207, %206
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %235 = icmp ugt i32 %6, 5
  br i1 %235, label %236, label %267

236:                                              ; preds = %234
  %237 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %238 = load float, float addrspace(3)* %237, align 4, !tbaa !6
  %239 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %240 = load float, float addrspace(3)* %239, align 16, !tbaa !6
  %241 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 5), align 4, !tbaa !6
  %242 = fmul contract float %240, %241
  %243 = fsub contract float %238, %242
  store float %243, float addrspace(3)* %237, align 4, !tbaa !6
  %244 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %245 = load float, float addrspace(3)* %244, align 4, !tbaa !6
  %246 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 5), align 4, !tbaa !6
  %247 = fmul contract float %245, %246
  %248 = fsub contract float %243, %247
  store float %248, float addrspace(3)* %237, align 4, !tbaa !6
  %249 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %250 = load float, float addrspace(3)* %249, align 8, !tbaa !6
  %251 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 5), align 4, !tbaa !6
  %252 = fmul contract float %250, %251
  %253 = fsub contract float %248, %252
  store float %253, float addrspace(3)* %237, align 4, !tbaa !6
  %254 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %255 = load float, float addrspace(3)* %254, align 4, !tbaa !6
  %256 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 5), align 4, !tbaa !6
  %257 = fmul contract float %255, %256
  %258 = fsub contract float %253, %257
  store float %258, float addrspace(3)* %237, align 4, !tbaa !6
  %259 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %260 = load float, float addrspace(3)* %259, align 16, !tbaa !6
  %261 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 5), align 4, !tbaa !6
  %262 = fmul contract float %260, %261
  %263 = fsub contract float %258, %262
  store float %263, float addrspace(3)* %237, align 4, !tbaa !6
  %264 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 5), align 4, !tbaa !6
  %265 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %266 = fdiv contract float %263, %264
  store float %266, float addrspace(3)* %265, align 4, !tbaa !6
  br label %267

267:                                              ; preds = %236, %234
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %235, label %268, label %300

268:                                              ; preds = %267
  %269 = load float, float addrspace(3)* %48, align 4, !tbaa !6
  %270 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 0), align 16, !tbaa !6
  %271 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %272 = load float, float addrspace(3)* %271, align 4, !tbaa !6
  %273 = fmul contract float %270, %272
  %274 = fsub contract float %269, %273
  store float %274, float addrspace(3)* %48, align 4, !tbaa !6
  %275 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 1), align 4, !tbaa !6
  %276 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %277 = load float, float addrspace(3)* %276, align 4, !tbaa !6
  %278 = fmul contract float %275, %277
  %279 = fsub contract float %274, %278
  store float %279, float addrspace(3)* %48, align 4, !tbaa !6
  %280 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 2), align 8, !tbaa !6
  %281 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %282 = load float, float addrspace(3)* %281, align 4, !tbaa !6
  %283 = fmul contract float %280, %282
  %284 = fsub contract float %279, %283
  store float %284, float addrspace(3)* %48, align 4, !tbaa !6
  %285 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 3), align 4, !tbaa !6
  %286 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %287 = load float, float addrspace(3)* %286, align 4, !tbaa !6
  %288 = fmul contract float %285, %287
  %289 = fsub contract float %284, %288
  store float %289, float addrspace(3)* %48, align 4, !tbaa !6
  %290 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 4), align 16, !tbaa !6
  %291 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %292 = load float, float addrspace(3)* %291, align 4, !tbaa !6
  %293 = fmul contract float %290, %292
  %294 = fsub contract float %289, %293
  store float %294, float addrspace(3)* %48, align 4, !tbaa !6
  %295 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 5), align 4, !tbaa !6
  %296 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  %297 = load float, float addrspace(3)* %296, align 4, !tbaa !6
  %298 = fmul contract float %295, %297
  %299 = fsub contract float %294, %298
  store float %299, float addrspace(3)* %48, align 4, !tbaa !6
  br label %300

300:                                              ; preds = %268, %267
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %301 = icmp ugt i32 %6, 6
  br i1 %301, label %302, label %338

302:                                              ; preds = %300
  %303 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 6
  %304 = load float, float addrspace(3)* %303, align 8, !tbaa !6
  %305 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %306 = load float, float addrspace(3)* %305, align 16, !tbaa !6
  %307 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 6), align 8, !tbaa !6
  %308 = fmul contract float %306, %307
  %309 = fsub contract float %304, %308
  store float %309, float addrspace(3)* %303, align 8, !tbaa !6
  %310 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %311 = load float, float addrspace(3)* %310, align 4, !tbaa !6
  %312 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 6), align 8, !tbaa !6
  %313 = fmul contract float %311, %312
  %314 = fsub contract float %309, %313
  store float %314, float addrspace(3)* %303, align 8, !tbaa !6
  %315 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %316 = load float, float addrspace(3)* %315, align 8, !tbaa !6
  %317 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 6), align 8, !tbaa !6
  %318 = fmul contract float %316, %317
  %319 = fsub contract float %314, %318
  store float %319, float addrspace(3)* %303, align 8, !tbaa !6
  %320 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %321 = load float, float addrspace(3)* %320, align 4, !tbaa !6
  %322 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 6), align 8, !tbaa !6
  %323 = fmul contract float %321, %322
  %324 = fsub contract float %319, %323
  store float %324, float addrspace(3)* %303, align 8, !tbaa !6
  %325 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %326 = load float, float addrspace(3)* %325, align 16, !tbaa !6
  %327 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 6), align 8, !tbaa !6
  %328 = fmul contract float %326, %327
  %329 = fsub contract float %324, %328
  store float %329, float addrspace(3)* %303, align 8, !tbaa !6
  %330 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %331 = load float, float addrspace(3)* %330, align 4, !tbaa !6
  %332 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 6), align 8, !tbaa !6
  %333 = fmul contract float %331, %332
  %334 = fsub contract float %329, %333
  store float %334, float addrspace(3)* %303, align 8, !tbaa !6
  %335 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 6), align 8, !tbaa !6
  %336 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 6
  %337 = fdiv contract float %334, %335
  store float %337, float addrspace(3)* %336, align 8, !tbaa !6
  br label %338

338:                                              ; preds = %302, %300
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %301, label %339, label %376

339:                                              ; preds = %338
  %340 = load float, float addrspace(3)* %54, align 4, !tbaa !6
  %341 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 0), align 16, !tbaa !6
  %342 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %343 = load float, float addrspace(3)* %342, align 4, !tbaa !6
  %344 = fmul contract float %341, %343
  %345 = fsub contract float %340, %344
  store float %345, float addrspace(3)* %54, align 4, !tbaa !6
  %346 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 1), align 4, !tbaa !6
  %347 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %348 = load float, float addrspace(3)* %347, align 4, !tbaa !6
  %349 = fmul contract float %346, %348
  %350 = fsub contract float %345, %349
  store float %350, float addrspace(3)* %54, align 4, !tbaa !6
  %351 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 2), align 8, !tbaa !6
  %352 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %353 = load float, float addrspace(3)* %352, align 4, !tbaa !6
  %354 = fmul contract float %351, %353
  %355 = fsub contract float %350, %354
  store float %355, float addrspace(3)* %54, align 4, !tbaa !6
  %356 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 3), align 4, !tbaa !6
  %357 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %358 = load float, float addrspace(3)* %357, align 4, !tbaa !6
  %359 = fmul contract float %356, %358
  %360 = fsub contract float %355, %359
  store float %360, float addrspace(3)* %54, align 4, !tbaa !6
  %361 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 4), align 16, !tbaa !6
  %362 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %363 = load float, float addrspace(3)* %362, align 4, !tbaa !6
  %364 = fmul contract float %361, %363
  %365 = fsub contract float %360, %364
  store float %365, float addrspace(3)* %54, align 4, !tbaa !6
  %366 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 5), align 4, !tbaa !6
  %367 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  %368 = load float, float addrspace(3)* %367, align 4, !tbaa !6
  %369 = fmul contract float %366, %368
  %370 = fsub contract float %365, %369
  store float %370, float addrspace(3)* %54, align 4, !tbaa !6
  %371 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 6), align 8, !tbaa !6
  %372 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 %6
  %373 = load float, float addrspace(3)* %372, align 4, !tbaa !6
  %374 = fmul contract float %371, %373
  %375 = fsub contract float %370, %374
  store float %375, float addrspace(3)* %54, align 4, !tbaa !6
  br label %376

376:                                              ; preds = %339, %338
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %377 = add nsw i32 %2, 1
  %378 = mul nsw i32 %377, %1
  %379 = add nsw i32 %378, %2
  %380 = load float, float addrspace(3)* %18, align 4, !tbaa !6
  %381 = sext i32 %379 to i64
  %382 = add nsw i64 %381, %7
  %383 = getelementptr inbounds float, float addrspace(1)* %0, i64 %382
  store float %380, float addrspace(1)* %383, align 4, !tbaa !6
  %384 = add nsw i32 %379, %1
  %385 = load float, float addrspace(3)* %24, align 4, !tbaa !6
  %386 = sext i32 %384 to i64
  %387 = add nsw i64 %386, %7
  %388 = getelementptr inbounds float, float addrspace(1)* %0, i64 %387
  store float %385, float addrspace(1)* %388, align 4, !tbaa !6
  %389 = add nsw i32 %384, %1
  %390 = load float, float addrspace(3)* %30, align 4, !tbaa !6
  %391 = sext i32 %389 to i64
  %392 = add nsw i64 %391, %7
  %393 = getelementptr inbounds float, float addrspace(1)* %0, i64 %392
  store float %390, float addrspace(1)* %393, align 4, !tbaa !6
  %394 = add nsw i32 %389, %1
  %395 = load float, float addrspace(3)* %36, align 4, !tbaa !6
  %396 = sext i32 %394 to i64
  %397 = add nsw i64 %396, %7
  %398 = getelementptr inbounds float, float addrspace(1)* %0, i64 %397
  store float %395, float addrspace(1)* %398, align 4, !tbaa !6
  %399 = add nsw i32 %394, %1
  %400 = load float, float addrspace(3)* %42, align 4, !tbaa !6
  %401 = sext i32 %399 to i64
  %402 = add nsw i64 %401, %7
  %403 = getelementptr inbounds float, float addrspace(1)* %0, i64 %402
  store float %400, float addrspace(1)* %403, align 4, !tbaa !6
  %404 = add nsw i32 %399, %1
  %405 = load float, float addrspace(3)* %48, align 4, !tbaa !6
  %406 = sext i32 %404 to i64
  %407 = add nsw i64 %406, %7
  %408 = getelementptr inbounds float, float addrspace(1)* %0, i64 %407
  store float %405, float addrspace(1)* %408, align 4, !tbaa !6
  %409 = add nsw i32 %404, %1
  %410 = load float, float addrspace(3)* %54, align 4, !tbaa !6
  %411 = sext i32 %409 to i64
  %412 = add nsw i64 %411, %7
  %413 = getelementptr inbounds float, float addrspace(1)* %0, i64 %412
  store float %410, float addrspace(1)* %413, align 4, !tbaa !6
  ret void
}

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z13lud_perimeterPfii(float addrspace(1)* nocapture %0, i32 %1, i32 %2) local_unnamed_addr #0 {
  %4 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %5 = zext i32 %4 to i64
  %6 = icmp ult i32 %4, 8
  br i1 %6, label %7, label %80

7:                                                ; preds = %3
  %8 = mul nsw i32 %2, %1
  %9 = add nsw i32 %8, %2
  %10 = add nsw i32 %9, %4
  %11 = sext i32 %10 to i64
  %12 = getelementptr inbounds float, float addrspace(1)* %0, i64 %11
  %13 = load float, float addrspace(1)* %12, align 4, !tbaa !6
  %14 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 %4
  store float %13, float addrspace(3)* %14, align 4, !tbaa !6
  %15 = add nsw i32 %9, %1
  %16 = add nsw i32 %15, %4
  %17 = sext i32 %16 to i64
  %18 = getelementptr inbounds float, float addrspace(1)* %0, i64 %17
  %19 = load float, float addrspace(1)* %18, align 4, !tbaa !6
  %20 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 %4
  store float %19, float addrspace(3)* %20, align 4, !tbaa !6
  %21 = add nsw i32 %15, %1
  %22 = add nsw i32 %21, %4
  %23 = sext i32 %22 to i64
  %24 = getelementptr inbounds float, float addrspace(1)* %0, i64 %23
  %25 = load float, float addrspace(1)* %24, align 4, !tbaa !6
  %26 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 %4
  store float %25, float addrspace(3)* %26, align 4, !tbaa !6
  %27 = add nsw i32 %21, %1
  %28 = add nsw i32 %27, %4
  %29 = sext i32 %28 to i64
  %30 = getelementptr inbounds float, float addrspace(1)* %0, i64 %29
  %31 = load float, float addrspace(1)* %30, align 4, !tbaa !6
  %32 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 %4
  store float %31, float addrspace(3)* %32, align 4, !tbaa !6
  %33 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %34 = zext i32 %33 to i64
  %35 = shl nuw nsw i64 %34, 3
  %36 = add nuw nsw i64 %5, 8
  %37 = add nuw nsw i64 %36, %35
  %38 = sext i32 %9 to i64
  %39 = add nsw i64 %37, %38
  %40 = getelementptr inbounds float, float addrspace(1)* %0, i64 %39
  %41 = load float, float addrspace(1)* %40, align 4, !tbaa !6
  %42 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  store float %41, float addrspace(3)* %42, align 4, !tbaa !6
  %43 = sext i32 %15 to i64
  %44 = add nsw i64 %37, %43
  %45 = getelementptr inbounds float, float addrspace(1)* %0, i64 %44
  %46 = load float, float addrspace(1)* %45, align 4, !tbaa !6
  %47 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  store float %46, float addrspace(3)* %47, align 4, !tbaa !6
  %48 = sext i32 %21 to i64
  %49 = add nsw i64 %37, %48
  %50 = getelementptr inbounds float, float addrspace(1)* %0, i64 %49
  %51 = load float, float addrspace(1)* %50, align 4, !tbaa !6
  %52 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  store float %51, float addrspace(3)* %52, align 4, !tbaa !6
  %53 = sext i32 %27 to i64
  %54 = add nsw i64 %37, %53
  %55 = getelementptr inbounds float, float addrspace(1)* %0, i64 %54
  %56 = load float, float addrspace(1)* %55, align 4, !tbaa !6
  %57 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  store float %56, float addrspace(3)* %57, align 4, !tbaa !6
  %58 = add nsw i32 %27, %1
  %59 = sext i32 %58 to i64
  %60 = add nsw i64 %37, %59
  %61 = getelementptr inbounds float, float addrspace(1)* %0, i64 %60
  %62 = load float, float addrspace(1)* %61, align 4, !tbaa !6
  %63 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  store float %62, float addrspace(3)* %63, align 4, !tbaa !6
  %64 = add nsw i32 %58, %1
  %65 = sext i32 %64 to i64
  %66 = add nsw i64 %37, %65
  %67 = getelementptr inbounds float, float addrspace(1)* %0, i64 %66
  %68 = load float, float addrspace(1)* %67, align 4, !tbaa !6
  %69 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  store float %68, float addrspace(3)* %69, align 4, !tbaa !6
  %70 = add nsw i32 %64, %1
  %71 = sext i32 %70 to i64
  %72 = add nsw i64 %37, %71
  %73 = getelementptr inbounds float, float addrspace(1)* %0, i64 %72
  %74 = load float, float addrspace(1)* %73, align 4, !tbaa !6
  %75 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  store float %74, float addrspace(3)* %75, align 4, !tbaa !6
  %76 = add nsw i32 %70, %1
  %77 = sext i32 %76 to i64
  %78 = add nsw i64 %37, %77
  %79 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  br label %159

80:                                               ; preds = %3
  %81 = add nsw i32 %4, -8
  %82 = add nsw i32 %2, 4
  %83 = mul nsw i32 %82, %1
  %84 = add nsw i32 %83, %2
  %85 = add nsw i32 %84, %81
  %86 = sext i32 %85 to i64
  %87 = getelementptr inbounds float, float addrspace(1)* %0, i64 %86
  %88 = load float, float addrspace(1)* %87, align 4, !tbaa !6
  %89 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 %81
  store float %88, float addrspace(3)* %89, align 4, !tbaa !6
  %90 = add nsw i32 %84, %1
  %91 = add nsw i32 %90, %81
  %92 = sext i32 %91 to i64
  %93 = getelementptr inbounds float, float addrspace(1)* %0, i64 %92
  %94 = load float, float addrspace(1)* %93, align 4, !tbaa !6
  %95 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 %81
  store float %94, float addrspace(3)* %95, align 4, !tbaa !6
  %96 = add nsw i32 %90, %1
  %97 = add nsw i32 %96, %81
  %98 = sext i32 %97 to i64
  %99 = getelementptr inbounds float, float addrspace(1)* %0, i64 %98
  %100 = load float, float addrspace(1)* %99, align 4, !tbaa !6
  %101 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 %81
  store float %100, float addrspace(3)* %101, align 4, !tbaa !6
  %102 = add nsw i32 %96, %1
  %103 = add nsw i32 %102, %81
  %104 = sext i32 %103 to i64
  %105 = getelementptr inbounds float, float addrspace(1)* %0, i64 %104
  %106 = load float, float addrspace(1)* %105, align 4, !tbaa !6
  %107 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 %81
  store float %106, float addrspace(3)* %107, align 4, !tbaa !6
  %108 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %109 = shl i32 %108, 3
  %110 = add i32 %2, 8
  %111 = add i32 %110, %109
  %112 = mul i32 %111, %1
  %113 = add i32 %112, %2
  %114 = add nsw i32 %113, %81
  %115 = sext i32 %114 to i64
  %116 = getelementptr inbounds float, float addrspace(1)* %0, i64 %115
  %117 = load float, float addrspace(1)* %116, align 4, !tbaa !6
  %118 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 0, i32 %81
  store float %117, float addrspace(3)* %118, align 4, !tbaa !6
  %119 = add nsw i32 %113, %1
  %120 = add nsw i32 %119, %81
  %121 = sext i32 %120 to i64
  %122 = getelementptr inbounds float, float addrspace(1)* %0, i64 %121
  %123 = load float, float addrspace(1)* %122, align 4, !tbaa !6
  %124 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 1, i32 %81
  store float %123, float addrspace(3)* %124, align 4, !tbaa !6
  %125 = add nsw i32 %119, %1
  %126 = add nsw i32 %125, %81
  %127 = sext i32 %126 to i64
  %128 = getelementptr inbounds float, float addrspace(1)* %0, i64 %127
  %129 = load float, float addrspace(1)* %128, align 4, !tbaa !6
  %130 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 2, i32 %81
  store float %129, float addrspace(3)* %130, align 4, !tbaa !6
  %131 = add nsw i32 %125, %1
  %132 = add nsw i32 %131, %81
  %133 = sext i32 %132 to i64
  %134 = getelementptr inbounds float, float addrspace(1)* %0, i64 %133
  %135 = load float, float addrspace(1)* %134, align 4, !tbaa !6
  %136 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 3, i32 %81
  store float %135, float addrspace(3)* %136, align 4, !tbaa !6
  %137 = add nsw i32 %131, %1
  %138 = add nsw i32 %137, %81
  %139 = sext i32 %138 to i64
  %140 = getelementptr inbounds float, float addrspace(1)* %0, i64 %139
  %141 = load float, float addrspace(1)* %140, align 4, !tbaa !6
  %142 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 4, i32 %81
  store float %141, float addrspace(3)* %142, align 4, !tbaa !6
  %143 = add nsw i32 %137, %1
  %144 = add nsw i32 %143, %81
  %145 = sext i32 %144 to i64
  %146 = getelementptr inbounds float, float addrspace(1)* %0, i64 %145
  %147 = load float, float addrspace(1)* %146, align 4, !tbaa !6
  %148 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 5, i32 %81
  store float %147, float addrspace(3)* %148, align 4, !tbaa !6
  %149 = add nsw i32 %143, %1
  %150 = add nsw i32 %149, %81
  %151 = sext i32 %150 to i64
  %152 = getelementptr inbounds float, float addrspace(1)* %0, i64 %151
  %153 = load float, float addrspace(1)* %152, align 4, !tbaa !6
  %154 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 6, i32 %81
  store float %153, float addrspace(3)* %154, align 4, !tbaa !6
  %155 = add nsw i32 %149, %1
  %156 = add nsw i32 %155, %81
  %157 = sext i32 %156 to i64
  %158 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 7, i32 %81
  br label %159

159:                                              ; preds = %80, %7
  %160 = phi float addrspace(3)* [ %158, %80 ], [ %79, %7 ]
  %161 = phi i64 [ %157, %80 ], [ %78, %7 ]
  %162 = getelementptr inbounds float, float addrspace(1)* %0, i64 %161
  %163 = load float, float addrspace(1)* %162, align 4, !tbaa !6
  store float %163, float addrspace(3)* %160, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %6, label %164, label %319

164:                                              ; preds = %159
  %165 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %166 = load float, float addrspace(3)* %165, align 4, !tbaa !6
  %167 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 0), align 16, !tbaa !6
  %168 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %169 = load float, float addrspace(3)* %168, align 4, !tbaa !6
  %170 = fmul contract float %167, %169
  %171 = fsub contract float %166, %170
  store float %171, float addrspace(3)* %165, align 4, !tbaa !6
  %172 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %173 = load float, float addrspace(3)* %172, align 4, !tbaa !6
  %174 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 0), align 16, !tbaa !6
  %175 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %176 = load float, float addrspace(3)* %175, align 4, !tbaa !6
  %177 = fmul contract float %174, %176
  %178 = fsub contract float %173, %177
  store float %178, float addrspace(3)* %172, align 4, !tbaa !6
  %179 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 1), align 4, !tbaa !6
  %180 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %181 = load float, float addrspace(3)* %180, align 4, !tbaa !6
  %182 = fmul contract float %179, %181
  %183 = fsub contract float %178, %182
  store float %183, float addrspace(3)* %172, align 4, !tbaa !6
  %184 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %185 = load float, float addrspace(3)* %184, align 4, !tbaa !6
  %186 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 0), align 16, !tbaa !6
  %187 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %188 = load float, float addrspace(3)* %187, align 4, !tbaa !6
  %189 = fmul contract float %186, %188
  %190 = fsub contract float %185, %189
  store float %190, float addrspace(3)* %184, align 4, !tbaa !6
  %191 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 1), align 4, !tbaa !6
  %192 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %193 = load float, float addrspace(3)* %192, align 4, !tbaa !6
  %194 = fmul contract float %191, %193
  %195 = fsub contract float %190, %194
  store float %195, float addrspace(3)* %184, align 4, !tbaa !6
  %196 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 2), align 8, !tbaa !6
  %197 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %198 = load float, float addrspace(3)* %197, align 4, !tbaa !6
  %199 = fmul contract float %196, %198
  %200 = fsub contract float %195, %199
  store float %200, float addrspace(3)* %184, align 4, !tbaa !6
  %201 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %202 = load float, float addrspace(3)* %201, align 4, !tbaa !6
  %203 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 0), align 16, !tbaa !6
  %204 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %205 = load float, float addrspace(3)* %204, align 4, !tbaa !6
  %206 = fmul contract float %203, %205
  %207 = fsub contract float %202, %206
  store float %207, float addrspace(3)* %201, align 4, !tbaa !6
  %208 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 1), align 4, !tbaa !6
  %209 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %210 = load float, float addrspace(3)* %209, align 4, !tbaa !6
  %211 = fmul contract float %208, %210
  %212 = fsub contract float %207, %211
  store float %212, float addrspace(3)* %201, align 4, !tbaa !6
  %213 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 2), align 8, !tbaa !6
  %214 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %215 = load float, float addrspace(3)* %214, align 4, !tbaa !6
  %216 = fmul contract float %213, %215
  %217 = fsub contract float %212, %216
  store float %217, float addrspace(3)* %201, align 4, !tbaa !6
  %218 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 3), align 4, !tbaa !6
  %219 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %220 = load float, float addrspace(3)* %219, align 4, !tbaa !6
  %221 = fmul contract float %218, %220
  %222 = fsub contract float %217, %221
  store float %222, float addrspace(3)* %201, align 4, !tbaa !6
  %223 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %224 = load float, float addrspace(3)* %223, align 4, !tbaa !6
  %225 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 0), align 16, !tbaa !6
  %226 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %227 = load float, float addrspace(3)* %226, align 4, !tbaa !6
  %228 = fmul contract float %225, %227
  %229 = fsub contract float %224, %228
  store float %229, float addrspace(3)* %223, align 4, !tbaa !6
  %230 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 1), align 4, !tbaa !6
  %231 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %232 = load float, float addrspace(3)* %231, align 4, !tbaa !6
  %233 = fmul contract float %230, %232
  %234 = fsub contract float %229, %233
  store float %234, float addrspace(3)* %223, align 4, !tbaa !6
  %235 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 2), align 8, !tbaa !6
  %236 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %237 = load float, float addrspace(3)* %236, align 4, !tbaa !6
  %238 = fmul contract float %235, %237
  %239 = fsub contract float %234, %238
  store float %239, float addrspace(3)* %223, align 4, !tbaa !6
  %240 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 3), align 4, !tbaa !6
  %241 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %242 = load float, float addrspace(3)* %241, align 4, !tbaa !6
  %243 = fmul contract float %240, %242
  %244 = fsub contract float %239, %243
  store float %244, float addrspace(3)* %223, align 4, !tbaa !6
  %245 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 4), align 16, !tbaa !6
  %246 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %247 = load float, float addrspace(3)* %246, align 4, !tbaa !6
  %248 = fmul contract float %245, %247
  %249 = fsub contract float %244, %248
  store float %249, float addrspace(3)* %223, align 4, !tbaa !6
  %250 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %251 = load float, float addrspace(3)* %250, align 4, !tbaa !6
  %252 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 0), align 16, !tbaa !6
  %253 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %254 = load float, float addrspace(3)* %253, align 4, !tbaa !6
  %255 = fmul contract float %252, %254
  %256 = fsub contract float %251, %255
  store float %256, float addrspace(3)* %250, align 4, !tbaa !6
  %257 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 1), align 4, !tbaa !6
  %258 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %259 = load float, float addrspace(3)* %258, align 4, !tbaa !6
  %260 = fmul contract float %257, %259
  %261 = fsub contract float %256, %260
  store float %261, float addrspace(3)* %250, align 4, !tbaa !6
  %262 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 2), align 8, !tbaa !6
  %263 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %264 = load float, float addrspace(3)* %263, align 4, !tbaa !6
  %265 = fmul contract float %262, %264
  %266 = fsub contract float %261, %265
  store float %266, float addrspace(3)* %250, align 4, !tbaa !6
  %267 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 3), align 4, !tbaa !6
  %268 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %269 = load float, float addrspace(3)* %268, align 4, !tbaa !6
  %270 = fmul contract float %267, %269
  %271 = fsub contract float %266, %270
  store float %271, float addrspace(3)* %250, align 4, !tbaa !6
  %272 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 4), align 16, !tbaa !6
  %273 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %274 = load float, float addrspace(3)* %273, align 4, !tbaa !6
  %275 = fmul contract float %272, %274
  %276 = fsub contract float %271, %275
  store float %276, float addrspace(3)* %250, align 4, !tbaa !6
  %277 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 5), align 4, !tbaa !6
  %278 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %279 = load float, float addrspace(3)* %278, align 4, !tbaa !6
  %280 = fmul contract float %277, %279
  %281 = fsub contract float %276, %280
  store float %281, float addrspace(3)* %250, align 4, !tbaa !6
  %282 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %283 = load float, float addrspace(3)* %282, align 4, !tbaa !6
  %284 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 0), align 16, !tbaa !6
  %285 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %286 = load float, float addrspace(3)* %285, align 4, !tbaa !6
  %287 = fmul contract float %284, %286
  %288 = fsub contract float %283, %287
  store float %288, float addrspace(3)* %282, align 4, !tbaa !6
  %289 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 1), align 4, !tbaa !6
  %290 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %291 = load float, float addrspace(3)* %290, align 4, !tbaa !6
  %292 = fmul contract float %289, %291
  %293 = fsub contract float %288, %292
  store float %293, float addrspace(3)* %282, align 4, !tbaa !6
  %294 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 2), align 8, !tbaa !6
  %295 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %296 = load float, float addrspace(3)* %295, align 4, !tbaa !6
  %297 = fmul contract float %294, %296
  %298 = fsub contract float %293, %297
  store float %298, float addrspace(3)* %282, align 4, !tbaa !6
  %299 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 3), align 4, !tbaa !6
  %300 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %301 = load float, float addrspace(3)* %300, align 4, !tbaa !6
  %302 = fmul contract float %299, %301
  %303 = fsub contract float %298, %302
  store float %303, float addrspace(3)* %282, align 4, !tbaa !6
  %304 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 4), align 16, !tbaa !6
  %305 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %306 = load float, float addrspace(3)* %305, align 4, !tbaa !6
  %307 = fmul contract float %304, %306
  %308 = fsub contract float %303, %307
  store float %308, float addrspace(3)* %282, align 4, !tbaa !6
  %309 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 5), align 4, !tbaa !6
  %310 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %311 = load float, float addrspace(3)* %310, align 4, !tbaa !6
  %312 = fmul contract float %309, %311
  %313 = fsub contract float %308, %312
  store float %313, float addrspace(3)* %282, align 4, !tbaa !6
  %314 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 6), align 8, !tbaa !6
  %315 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %316 = load float, float addrspace(3)* %315, align 4, !tbaa !6
  %317 = fmul contract float %314, %316
  %318 = fsub contract float %313, %317
  store float %318, float addrspace(3)* %282, align 4, !tbaa !6
  br label %487

319:                                              ; preds = %159
  %320 = add nsw i32 %4, -8
  %321 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 0
  %322 = load float, float addrspace(3)* %321, align 16, !tbaa !6
  %323 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 0), align 16, !tbaa !6
  %324 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 0
  %325 = fdiv contract float %322, %323
  store float %325, float addrspace(3)* %324, align 16, !tbaa !6
  %326 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 1
  %327 = load float, float addrspace(3)* %326, align 4, !tbaa !6
  %328 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 1), align 4, !tbaa !6
  %329 = fmul contract float %325, %328
  %330 = fsub contract float %327, %329
  store float %330, float addrspace(3)* %326, align 4, !tbaa !6
  %331 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 1), align 4, !tbaa !6
  %332 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 1
  %333 = fdiv contract float %330, %331
  store float %333, float addrspace(3)* %332, align 4, !tbaa !6
  %334 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 2
  %335 = load float, float addrspace(3)* %334, align 8, !tbaa !6
  %336 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 2), align 8, !tbaa !6
  %337 = fmul contract float %325, %336
  %338 = fsub contract float %335, %337
  store float %338, float addrspace(3)* %334, align 8, !tbaa !6
  %339 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 1
  %340 = load float, float addrspace(3)* %339, align 4, !tbaa !6
  %341 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 2), align 8, !tbaa !6
  %342 = fmul contract float %340, %341
  %343 = fsub contract float %338, %342
  store float %343, float addrspace(3)* %334, align 8, !tbaa !6
  %344 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 2), align 8, !tbaa !6
  %345 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 2
  %346 = fdiv contract float %343, %344
  store float %346, float addrspace(3)* %345, align 8, !tbaa !6
  %347 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 3
  %348 = load float, float addrspace(3)* %347, align 4, !tbaa !6
  %349 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 3), align 4, !tbaa !6
  %350 = fmul contract float %325, %349
  %351 = fsub contract float %348, %350
  store float %351, float addrspace(3)* %347, align 4, !tbaa !6
  %352 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 1
  %353 = load float, float addrspace(3)* %352, align 4, !tbaa !6
  %354 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 3), align 4, !tbaa !6
  %355 = fmul contract float %353, %354
  %356 = fsub contract float %351, %355
  store float %356, float addrspace(3)* %347, align 4, !tbaa !6
  %357 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 2
  %358 = load float, float addrspace(3)* %357, align 8, !tbaa !6
  %359 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 3), align 4, !tbaa !6
  %360 = fmul contract float %358, %359
  %361 = fsub contract float %356, %360
  store float %361, float addrspace(3)* %347, align 4, !tbaa !6
  %362 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 3), align 4, !tbaa !6
  %363 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 3
  %364 = fdiv contract float %361, %362
  store float %364, float addrspace(3)* %363, align 4, !tbaa !6
  %365 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 4
  %366 = load float, float addrspace(3)* %365, align 16, !tbaa !6
  %367 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 4), align 16, !tbaa !6
  %368 = fmul contract float %325, %367
  %369 = fsub contract float %366, %368
  store float %369, float addrspace(3)* %365, align 16, !tbaa !6
  %370 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 1
  %371 = load float, float addrspace(3)* %370, align 4, !tbaa !6
  %372 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 4), align 16, !tbaa !6
  %373 = fmul contract float %371, %372
  %374 = fsub contract float %369, %373
  store float %374, float addrspace(3)* %365, align 16, !tbaa !6
  %375 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 2
  %376 = load float, float addrspace(3)* %375, align 8, !tbaa !6
  %377 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 4), align 16, !tbaa !6
  %378 = fmul contract float %376, %377
  %379 = fsub contract float %374, %378
  store float %379, float addrspace(3)* %365, align 16, !tbaa !6
  %380 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 3
  %381 = load float, float addrspace(3)* %380, align 4, !tbaa !6
  %382 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 4), align 16, !tbaa !6
  %383 = fmul contract float %381, %382
  %384 = fsub contract float %379, %383
  store float %384, float addrspace(3)* %365, align 16, !tbaa !6
  %385 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 4), align 16, !tbaa !6
  %386 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 4
  %387 = fdiv contract float %384, %385
  store float %387, float addrspace(3)* %386, align 16, !tbaa !6
  %388 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 5
  %389 = load float, float addrspace(3)* %388, align 4, !tbaa !6
  %390 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 5), align 4, !tbaa !6
  %391 = fmul contract float %325, %390
  %392 = fsub contract float %389, %391
  store float %392, float addrspace(3)* %388, align 4, !tbaa !6
  %393 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 1
  %394 = load float, float addrspace(3)* %393, align 4, !tbaa !6
  %395 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 5), align 4, !tbaa !6
  %396 = fmul contract float %394, %395
  %397 = fsub contract float %392, %396
  store float %397, float addrspace(3)* %388, align 4, !tbaa !6
  %398 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 2
  %399 = load float, float addrspace(3)* %398, align 8, !tbaa !6
  %400 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 5), align 4, !tbaa !6
  %401 = fmul contract float %399, %400
  %402 = fsub contract float %397, %401
  store float %402, float addrspace(3)* %388, align 4, !tbaa !6
  %403 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 3
  %404 = load float, float addrspace(3)* %403, align 4, !tbaa !6
  %405 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 5), align 4, !tbaa !6
  %406 = fmul contract float %404, %405
  %407 = fsub contract float %402, %406
  store float %407, float addrspace(3)* %388, align 4, !tbaa !6
  %408 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 4
  %409 = load float, float addrspace(3)* %408, align 16, !tbaa !6
  %410 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 5), align 4, !tbaa !6
  %411 = fmul contract float %409, %410
  %412 = fsub contract float %407, %411
  store float %412, float addrspace(3)* %388, align 4, !tbaa !6
  %413 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 5), align 4, !tbaa !6
  %414 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 5
  %415 = fdiv contract float %412, %413
  store float %415, float addrspace(3)* %414, align 4, !tbaa !6
  %416 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 6
  %417 = load float, float addrspace(3)* %416, align 8, !tbaa !6
  %418 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 6), align 8, !tbaa !6
  %419 = fmul contract float %325, %418
  %420 = fsub contract float %417, %419
  store float %420, float addrspace(3)* %416, align 8, !tbaa !6
  %421 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 1
  %422 = load float, float addrspace(3)* %421, align 4, !tbaa !6
  %423 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 6), align 8, !tbaa !6
  %424 = fmul contract float %422, %423
  %425 = fsub contract float %420, %424
  store float %425, float addrspace(3)* %416, align 8, !tbaa !6
  %426 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 2
  %427 = load float, float addrspace(3)* %426, align 8, !tbaa !6
  %428 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 6), align 8, !tbaa !6
  %429 = fmul contract float %427, %428
  %430 = fsub contract float %425, %429
  store float %430, float addrspace(3)* %416, align 8, !tbaa !6
  %431 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 3
  %432 = load float, float addrspace(3)* %431, align 4, !tbaa !6
  %433 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 6), align 8, !tbaa !6
  %434 = fmul contract float %432, %433
  %435 = fsub contract float %430, %434
  store float %435, float addrspace(3)* %416, align 8, !tbaa !6
  %436 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 4
  %437 = load float, float addrspace(3)* %436, align 16, !tbaa !6
  %438 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 6), align 8, !tbaa !6
  %439 = fmul contract float %437, %438
  %440 = fsub contract float %435, %439
  store float %440, float addrspace(3)* %416, align 8, !tbaa !6
  %441 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 5
  %442 = load float, float addrspace(3)* %441, align 4, !tbaa !6
  %443 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 6), align 8, !tbaa !6
  %444 = fmul contract float %442, %443
  %445 = fsub contract float %440, %444
  store float %445, float addrspace(3)* %416, align 8, !tbaa !6
  %446 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 6), align 8, !tbaa !6
  %447 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 6
  %448 = fdiv contract float %445, %446
  store float %448, float addrspace(3)* %447, align 8, !tbaa !6
  %449 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 7
  %450 = load float, float addrspace(3)* %449, align 4, !tbaa !6
  %451 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 7), align 4, !tbaa !6
  %452 = fmul contract float %325, %451
  %453 = fsub contract float %450, %452
  store float %453, float addrspace(3)* %449, align 4, !tbaa !6
  %454 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 1
  %455 = load float, float addrspace(3)* %454, align 4, !tbaa !6
  %456 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 7), align 4, !tbaa !6
  %457 = fmul contract float %455, %456
  %458 = fsub contract float %453, %457
  store float %458, float addrspace(3)* %449, align 4, !tbaa !6
  %459 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 2
  %460 = load float, float addrspace(3)* %459, align 8, !tbaa !6
  %461 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 7), align 4, !tbaa !6
  %462 = fmul contract float %460, %461
  %463 = fsub contract float %458, %462
  store float %463, float addrspace(3)* %449, align 4, !tbaa !6
  %464 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 3
  %465 = load float, float addrspace(3)* %464, align 4, !tbaa !6
  %466 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 7), align 4, !tbaa !6
  %467 = fmul contract float %465, %466
  %468 = fsub contract float %463, %467
  store float %468, float addrspace(3)* %449, align 4, !tbaa !6
  %469 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 4
  %470 = load float, float addrspace(3)* %469, align 16, !tbaa !6
  %471 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 7), align 4, !tbaa !6
  %472 = fmul contract float %470, %471
  %473 = fsub contract float %468, %472
  store float %473, float addrspace(3)* %449, align 4, !tbaa !6
  %474 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 5
  %475 = load float, float addrspace(3)* %474, align 4, !tbaa !6
  %476 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 7), align 4, !tbaa !6
  %477 = fmul contract float %475, %476
  %478 = fsub contract float %473, %477
  store float %478, float addrspace(3)* %449, align 4, !tbaa !6
  %479 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 6
  %480 = load float, float addrspace(3)* %479, align 8, !tbaa !6
  %481 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 7), align 4, !tbaa !6
  %482 = fmul contract float %480, %481
  %483 = fsub contract float %478, %482
  store float %483, float addrspace(3)* %449, align 4, !tbaa !6
  %484 = load float, float addrspace(3)* getelementptr inbounds ([8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 7), align 4, !tbaa !6
  %485 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %320, i32 7
  %486 = fdiv contract float %483, %484
  store float %486, float addrspace(3)* %485, align 4, !tbaa !6
  br label %487

487:                                              ; preds = %319, %164
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %6, label %488, label %536

488:                                              ; preds = %487
  %489 = add nsw i32 %2, 1
  %490 = mul nsw i32 %489, %1
  %491 = add nsw i32 %490, %2
  %492 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %493 = zext i32 %492 to i64
  %494 = shl nuw nsw i64 %493, 3
  %495 = add nuw nsw i64 %5, 8
  %496 = add nuw nsw i64 %495, %494
  %497 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %498 = load float, float addrspace(3)* %497, align 4, !tbaa !6
  %499 = sext i32 %491 to i64
  %500 = add nsw i64 %496, %499
  %501 = getelementptr inbounds float, float addrspace(1)* %0, i64 %500
  store float %498, float addrspace(1)* %501, align 4, !tbaa !6
  %502 = add nsw i32 %491, %1
  %503 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %504 = load float, float addrspace(3)* %503, align 4, !tbaa !6
  %505 = sext i32 %502 to i64
  %506 = add nsw i64 %496, %505
  %507 = getelementptr inbounds float, float addrspace(1)* %0, i64 %506
  store float %504, float addrspace(1)* %507, align 4, !tbaa !6
  %508 = add nsw i32 %502, %1
  %509 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %510 = load float, float addrspace(3)* %509, align 4, !tbaa !6
  %511 = sext i32 %508 to i64
  %512 = add nsw i64 %496, %511
  %513 = getelementptr inbounds float, float addrspace(1)* %0, i64 %512
  store float %510, float addrspace(1)* %513, align 4, !tbaa !6
  %514 = add nsw i32 %508, %1
  %515 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %516 = load float, float addrspace(3)* %515, align 4, !tbaa !6
  %517 = sext i32 %514 to i64
  %518 = add nsw i64 %496, %517
  %519 = getelementptr inbounds float, float addrspace(1)* %0, i64 %518
  store float %516, float addrspace(1)* %519, align 4, !tbaa !6
  %520 = add nsw i32 %514, %1
  %521 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %522 = load float, float addrspace(3)* %521, align 4, !tbaa !6
  %523 = sext i32 %520 to i64
  %524 = add nsw i64 %496, %523
  %525 = getelementptr inbounds float, float addrspace(1)* %0, i64 %524
  store float %522, float addrspace(1)* %525, align 4, !tbaa !6
  %526 = add nsw i32 %520, %1
  %527 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %528 = load float, float addrspace(3)* %527, align 4, !tbaa !6
  %529 = sext i32 %526 to i64
  %530 = add nsw i64 %496, %529
  %531 = getelementptr inbounds float, float addrspace(1)* %0, i64 %530
  store float %528, float addrspace(1)* %531, align 4, !tbaa !6
  %532 = add nsw i32 %526, %1
  %533 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %534 = sext i32 %532 to i64
  %535 = add nsw i64 %496, %534
  br label %589

536:                                              ; preds = %487
  %537 = add nsw i32 %4, -8
  %538 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %539 = shl i32 %538, 3
  %540 = add i32 %2, 8
  %541 = add i32 %540, %539
  %542 = mul i32 %541, %1
  %543 = add i32 %542, %2
  %544 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 0, i32 %537
  %545 = load float, float addrspace(3)* %544, align 4, !tbaa !6
  %546 = add nsw i32 %543, %537
  %547 = sext i32 %546 to i64
  %548 = getelementptr inbounds float, float addrspace(1)* %0, i64 %547
  store float %545, float addrspace(1)* %548, align 4, !tbaa !6
  %549 = add nsw i32 %543, %1
  %550 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 1, i32 %537
  %551 = load float, float addrspace(3)* %550, align 4, !tbaa !6
  %552 = add nsw i32 %549, %537
  %553 = sext i32 %552 to i64
  %554 = getelementptr inbounds float, float addrspace(1)* %0, i64 %553
  store float %551, float addrspace(1)* %554, align 4, !tbaa !6
  %555 = add nsw i32 %549, %1
  %556 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 2, i32 %537
  %557 = load float, float addrspace(3)* %556, align 4, !tbaa !6
  %558 = add nsw i32 %555, %537
  %559 = sext i32 %558 to i64
  %560 = getelementptr inbounds float, float addrspace(1)* %0, i64 %559
  store float %557, float addrspace(1)* %560, align 4, !tbaa !6
  %561 = add nsw i32 %555, %1
  %562 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 3, i32 %537
  %563 = load float, float addrspace(3)* %562, align 4, !tbaa !6
  %564 = add nsw i32 %561, %537
  %565 = sext i32 %564 to i64
  %566 = getelementptr inbounds float, float addrspace(1)* %0, i64 %565
  store float %563, float addrspace(1)* %566, align 4, !tbaa !6
  %567 = add nsw i32 %561, %1
  %568 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 4, i32 %537
  %569 = load float, float addrspace(3)* %568, align 4, !tbaa !6
  %570 = add nsw i32 %567, %537
  %571 = sext i32 %570 to i64
  %572 = getelementptr inbounds float, float addrspace(1)* %0, i64 %571
  store float %569, float addrspace(1)* %572, align 4, !tbaa !6
  %573 = add nsw i32 %567, %1
  %574 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 5, i32 %537
  %575 = load float, float addrspace(3)* %574, align 4, !tbaa !6
  %576 = add nsw i32 %573, %537
  %577 = sext i32 %576 to i64
  %578 = getelementptr inbounds float, float addrspace(1)* %0, i64 %577
  store float %575, float addrspace(1)* %578, align 4, !tbaa !6
  %579 = add nsw i32 %573, %1
  %580 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 6, i32 %537
  %581 = load float, float addrspace(3)* %580, align 4, !tbaa !6
  %582 = add nsw i32 %579, %537
  %583 = sext i32 %582 to i64
  %584 = getelementptr inbounds float, float addrspace(1)* %0, i64 %583
  store float %581, float addrspace(1)* %584, align 4, !tbaa !6
  %585 = add nsw i32 %579, %1
  %586 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 7, i32 %537
  %587 = add nsw i32 %585, %537
  %588 = sext i32 %587 to i64
  br label %589

589:                                              ; preds = %536, %488
  %590 = phi i64 [ %588, %536 ], [ %535, %488 ]
  %591 = phi float addrspace(3)* [ %586, %536 ], [ %533, %488 ]
  %592 = load float, float addrspace(3)* %591, align 4, !tbaa !6
  %593 = getelementptr inbounds float, float addrspace(1)* %0, i64 %590
  store float %592, float addrspace(1)* %593, align 4, !tbaa !6
  ret void
}

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z12lud_internalPfii(float addrspace(1)* nocapture %0, i32 %1, i32 %2) local_unnamed_addr #0 {
  %4 = sext i32 %2 to i64
  %5 = tail call i32 @llvm.amdgcn.workgroup.id.y() #3
  %6 = shl i32 %5, 3
  %7 = add i32 %2, 8
  %8 = add i32 %7, %6
  %9 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %10 = shl i32 %9, 3
  %11 = add i32 %7, %10
  %12 = tail call i32 @llvm.amdgcn.workitem.id.y() #3, !range !5
  %13 = zext i32 %12 to i64
  %14 = add nsw i64 %4, %13
  %15 = sext i32 %1 to i64
  %16 = mul i64 %14, %15
  %17 = sext i32 %11 to i64
  %18 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %19 = zext i32 %18 to i64
  %20 = add nsw i64 %17, %19
  %21 = add i64 %20, %16
  %22 = getelementptr inbounds float, float addrspace(1)* %0, i64 %21
  %23 = load float, float addrspace(1)* %22, align 4, !tbaa !6
  %24 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 %12, i32 %18
  store float %23, float addrspace(3)* %24, align 4, !tbaa !6
  %25 = sext i32 %8 to i64
  %26 = add nsw i64 %25, %13
  %27 = mul i64 %26, %15
  %28 = add i64 %27, %19
  %29 = add i64 %28, %4
  %30 = getelementptr inbounds float, float addrspace(1)* %0, i64 %29
  %31 = load float, float addrspace(1)* %30, align 4, !tbaa !6
  %32 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 %18
  store float %31, float addrspace(3)* %32, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %33 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 0
  %34 = load float, float addrspace(3)* %33, align 16, !tbaa !6
  %35 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 0, i32 %18
  %36 = load float, float addrspace(3)* %35, align 4, !tbaa !6
  %37 = fmul contract float %34, %36
  %38 = fadd contract float %37, 0.000000e+00
  %39 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 1
  %40 = load float, float addrspace(3)* %39, align 4, !tbaa !6
  %41 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 1, i32 %18
  %42 = load float, float addrspace(3)* %41, align 4, !tbaa !6
  %43 = fmul contract float %40, %42
  %44 = fadd contract float %38, %43
  %45 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 2
  %46 = load float, float addrspace(3)* %45, align 8, !tbaa !6
  %47 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 2, i32 %18
  %48 = load float, float addrspace(3)* %47, align 4, !tbaa !6
  %49 = fmul contract float %46, %48
  %50 = fadd contract float %44, %49
  %51 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 3
  %52 = load float, float addrspace(3)* %51, align 4, !tbaa !6
  %53 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 3, i32 %18
  %54 = load float, float addrspace(3)* %53, align 4, !tbaa !6
  %55 = fmul contract float %52, %54
  %56 = fadd contract float %50, %55
  %57 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 4
  %58 = load float, float addrspace(3)* %57, align 16, !tbaa !6
  %59 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 4, i32 %18
  %60 = load float, float addrspace(3)* %59, align 4, !tbaa !6
  %61 = fmul contract float %58, %60
  %62 = fadd contract float %56, %61
  %63 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 5
  %64 = load float, float addrspace(3)* %63, align 4, !tbaa !6
  %65 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 5, i32 %18
  %66 = load float, float addrspace(3)* %65, align 4, !tbaa !6
  %67 = fmul contract float %64, %66
  %68 = fadd contract float %62, %67
  %69 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 6
  %70 = load float, float addrspace(3)* %69, align 8, !tbaa !6
  %71 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 6, i32 %18
  %72 = load float, float addrspace(3)* %71, align 4, !tbaa !6
  %73 = fmul contract float %70, %72
  %74 = fadd contract float %68, %73
  %75 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 7
  %76 = load float, float addrspace(3)* %75, align 4, !tbaa !6
  %77 = getelementptr inbounds [8 x [8 x float]], [8 x [8 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 7, i32 %18
  %78 = load float, float addrspace(3)* %77, align 4, !tbaa !6
  %79 = fmul contract float %76, %78
  %80 = fadd contract float %74, %79
  %81 = add i64 %20, %27
  %82 = getelementptr inbounds float, float addrspace(1)* %0, i64 %81
  %83 = load float, float addrspace(1)* %82, align 4, !tbaa !6
  %84 = fsub contract float %83, %80
  store float %84, float addrspace(1)* %82, align 4, !tbaa !6
  ret void
}

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.y() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.y() #2

attributes #0 = { convergent norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { convergent nounwind willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i32 0, i32 1024}
!6 = !{!7, !7, i64 0}
!7 = !{!"float", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C++ TBAA"}
