; ModuleID = '/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-repro.XpJFTn/LUD16/compat.ll'
source_filename = "/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-benchmarks/benchmarks/LUD/lud_kernel.hip.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

@_ZZ12lud_diagonalPfiiE6shadow = internal unnamed_addr addrspace(3) global [16 x [16 x float]] undef, align 16
@_ZZ13lud_perimeterPfiiE3dia = internal unnamed_addr addrspace(3) global [16 x [16 x float]] undef, align 16
@_ZZ13lud_perimeterPfiiE8peri_row = internal unnamed_addr addrspace(3) global [16 x [16 x float]] undef, align 16
@_ZZ13lud_perimeterPfiiE8peri_col = internal unnamed_addr addrspace(3) global [16 x [16 x float]] undef, align 16
@_ZZ12lud_internalPfiiE8peri_row = internal unnamed_addr addrspace(3) global [16 x [16 x float]] undef, align 16
@_ZZ12lud_internalPfiiE8peri_col = internal unnamed_addr addrspace(3) global [16 x [16 x float]] undef, align 16

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z12lud_diagonalPfii(float addrspace(1)* nocapture %0, i32 %1, i32 %2) local_unnamed_addr #0 {
  %4 = mul nsw i32 %2, %1
  %5 = add nsw i32 %4, %2
  %6 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %7 = zext i32 %6 to i64
  %8 = sext i32 %5 to i64
  %9 = add nsw i64 %8, %7
  %10 = getelementptr inbounds float, float addrspace(1)* %0, i64 %9
  %11 = load float, float addrspace(1)* %10, align 4, !tbaa !6
  %12 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  store float %11, float addrspace(3)* %12, align 4, !tbaa !6
  %13 = add nsw i32 %5, %1
  %14 = sext i32 %13 to i64
  %15 = add nsw i64 %14, %7
  %16 = getelementptr inbounds float, float addrspace(1)* %0, i64 %15
  %17 = load float, float addrspace(1)* %16, align 4, !tbaa !6
  %18 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  store float %17, float addrspace(3)* %18, align 4, !tbaa !6
  %19 = add nsw i32 %13, %1
  %20 = sext i32 %19 to i64
  %21 = add nsw i64 %20, %7
  %22 = getelementptr inbounds float, float addrspace(1)* %0, i64 %21
  %23 = load float, float addrspace(1)* %22, align 4, !tbaa !6
  %24 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  store float %23, float addrspace(3)* %24, align 4, !tbaa !6
  %25 = add nsw i32 %19, %1
  %26 = sext i32 %25 to i64
  %27 = add nsw i64 %26, %7
  %28 = getelementptr inbounds float, float addrspace(1)* %0, i64 %27
  %29 = load float, float addrspace(1)* %28, align 4, !tbaa !6
  %30 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  store float %29, float addrspace(3)* %30, align 4, !tbaa !6
  %31 = add nsw i32 %25, %1
  %32 = sext i32 %31 to i64
  %33 = add nsw i64 %32, %7
  %34 = getelementptr inbounds float, float addrspace(1)* %0, i64 %33
  %35 = load float, float addrspace(1)* %34, align 4, !tbaa !6
  %36 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  store float %35, float addrspace(3)* %36, align 4, !tbaa !6
  %37 = add nsw i32 %31, %1
  %38 = sext i32 %37 to i64
  %39 = add nsw i64 %38, %7
  %40 = getelementptr inbounds float, float addrspace(1)* %0, i64 %39
  %41 = load float, float addrspace(1)* %40, align 4, !tbaa !6
  %42 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  store float %41, float addrspace(3)* %42, align 4, !tbaa !6
  %43 = add nsw i32 %37, %1
  %44 = sext i32 %43 to i64
  %45 = add nsw i64 %44, %7
  %46 = getelementptr inbounds float, float addrspace(1)* %0, i64 %45
  %47 = load float, float addrspace(1)* %46, align 4, !tbaa !6
  %48 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 %6
  store float %47, float addrspace(3)* %48, align 4, !tbaa !6
  %49 = add nsw i32 %43, %1
  %50 = sext i32 %49 to i64
  %51 = add nsw i64 %50, %7
  %52 = getelementptr inbounds float, float addrspace(1)* %0, i64 %51
  %53 = load float, float addrspace(1)* %52, align 4, !tbaa !6
  %54 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 %6
  store float %53, float addrspace(3)* %54, align 4, !tbaa !6
  %55 = add nsw i32 %49, %1
  %56 = sext i32 %55 to i64
  %57 = add nsw i64 %56, %7
  %58 = getelementptr inbounds float, float addrspace(1)* %0, i64 %57
  %59 = load float, float addrspace(1)* %58, align 4, !tbaa !6
  %60 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 %6
  store float %59, float addrspace(3)* %60, align 4, !tbaa !6
  %61 = add nsw i32 %55, %1
  %62 = sext i32 %61 to i64
  %63 = add nsw i64 %62, %7
  %64 = getelementptr inbounds float, float addrspace(1)* %0, i64 %63
  %65 = load float, float addrspace(1)* %64, align 4, !tbaa !6
  %66 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 %6
  store float %65, float addrspace(3)* %66, align 4, !tbaa !6
  %67 = add nsw i32 %61, %1
  %68 = sext i32 %67 to i64
  %69 = add nsw i64 %68, %7
  %70 = getelementptr inbounds float, float addrspace(1)* %0, i64 %69
  %71 = load float, float addrspace(1)* %70, align 4, !tbaa !6
  %72 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 %6
  store float %71, float addrspace(3)* %72, align 4, !tbaa !6
  %73 = add nsw i32 %67, %1
  %74 = sext i32 %73 to i64
  %75 = add nsw i64 %74, %7
  %76 = getelementptr inbounds float, float addrspace(1)* %0, i64 %75
  %77 = load float, float addrspace(1)* %76, align 4, !tbaa !6
  %78 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 %6
  store float %77, float addrspace(3)* %78, align 4, !tbaa !6
  %79 = add nsw i32 %73, %1
  %80 = sext i32 %79 to i64
  %81 = add nsw i64 %80, %7
  %82 = getelementptr inbounds float, float addrspace(1)* %0, i64 %81
  %83 = load float, float addrspace(1)* %82, align 4, !tbaa !6
  %84 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 %6
  store float %83, float addrspace(3)* %84, align 4, !tbaa !6
  %85 = add nsw i32 %79, %1
  %86 = sext i32 %85 to i64
  %87 = add nsw i64 %86, %7
  %88 = getelementptr inbounds float, float addrspace(1)* %0, i64 %87
  %89 = load float, float addrspace(1)* %88, align 4, !tbaa !6
  %90 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 %6
  store float %89, float addrspace(3)* %90, align 4, !tbaa !6
  %91 = add nsw i32 %85, %1
  %92 = sext i32 %91 to i64
  %93 = add nsw i64 %92, %7
  %94 = getelementptr inbounds float, float addrspace(1)* %0, i64 %93
  %95 = load float, float addrspace(1)* %94, align 4, !tbaa !6
  %96 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 %6
  store float %95, float addrspace(3)* %96, align 4, !tbaa !6
  %97 = add nsw i32 %91, %1
  %98 = sext i32 %97 to i64
  %99 = add nsw i64 %98, %7
  %100 = getelementptr inbounds float, float addrspace(1)* %0, i64 %99
  %101 = load float, float addrspace(1)* %100, align 4, !tbaa !6
  %102 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 %6
  store float %101, float addrspace(3)* %102, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %103 = icmp eq i32 %6, 0
  br i1 %103, label %110, label %104

104:                                              ; preds = %3
  %105 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %106 = load float, float addrspace(3)* %105, align 16, !tbaa !6
  %107 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 0), align 16, !tbaa !6
  %108 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %109 = fdiv contract float %106, %107
  store float %109, float addrspace(3)* %108, align 16, !tbaa !6
  br label %110

110:                                              ; preds = %104, %3
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %103, label %118, label %111

111:                                              ; preds = %110
  %112 = load float, float addrspace(3)* %18, align 4, !tbaa !6
  %113 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %114 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 0), align 16, !tbaa !6
  %115 = load float, float addrspace(3)* %113, align 4, !tbaa !6
  %116 = fmul contract float %114, %115
  %117 = fsub contract float %112, %116
  store float %117, float addrspace(3)* %18, align 4, !tbaa !6
  br label %118

118:                                              ; preds = %111, %110
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %119 = icmp ugt i32 %6, 1
  br i1 %119, label %120, label %131

120:                                              ; preds = %118
  %121 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %122 = load float, float addrspace(3)* %121, align 4, !tbaa !6
  %123 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %124 = load float, float addrspace(3)* %123, align 16, !tbaa !6
  %125 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 1), align 4, !tbaa !6
  %126 = fmul contract float %124, %125
  %127 = fsub contract float %122, %126
  store float %127, float addrspace(3)* %121, align 4, !tbaa !6
  %128 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 1), align 4, !tbaa !6
  %129 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %130 = fdiv contract float %127, %128
  store float %130, float addrspace(3)* %129, align 4, !tbaa !6
  br label %131

131:                                              ; preds = %120, %118
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %119, label %132, label %144

132:                                              ; preds = %131
  %133 = load float, float addrspace(3)* %24, align 4, !tbaa !6
  %134 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 0), align 16, !tbaa !6
  %135 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %136 = load float, float addrspace(3)* %135, align 4, !tbaa !6
  %137 = fmul contract float %134, %136
  %138 = fsub contract float %133, %137
  store float %138, float addrspace(3)* %24, align 4, !tbaa !6
  %139 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 1), align 4, !tbaa !6
  %140 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %141 = load float, float addrspace(3)* %140, align 4, !tbaa !6
  %142 = fmul contract float %139, %141
  %143 = fsub contract float %138, %142
  store float %143, float addrspace(3)* %24, align 4, !tbaa !6
  br label %144

144:                                              ; preds = %132, %131
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %145 = icmp ugt i32 %6, 2
  br i1 %145, label %146, label %162

146:                                              ; preds = %144
  %147 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %148 = load float, float addrspace(3)* %147, align 8, !tbaa !6
  %149 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %150 = load float, float addrspace(3)* %149, align 16, !tbaa !6
  %151 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 2), align 8, !tbaa !6
  %152 = fmul contract float %150, %151
  %153 = fsub contract float %148, %152
  store float %153, float addrspace(3)* %147, align 8, !tbaa !6
  %154 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %155 = load float, float addrspace(3)* %154, align 4, !tbaa !6
  %156 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 2), align 8, !tbaa !6
  %157 = fmul contract float %155, %156
  %158 = fsub contract float %153, %157
  store float %158, float addrspace(3)* %147, align 8, !tbaa !6
  %159 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 2), align 8, !tbaa !6
  %160 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %161 = fdiv contract float %158, %159
  store float %161, float addrspace(3)* %160, align 8, !tbaa !6
  br label %162

162:                                              ; preds = %146, %144
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %145, label %163, label %180

163:                                              ; preds = %162
  %164 = load float, float addrspace(3)* %30, align 4, !tbaa !6
  %165 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 0), align 16, !tbaa !6
  %166 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %167 = load float, float addrspace(3)* %166, align 4, !tbaa !6
  %168 = fmul contract float %165, %167
  %169 = fsub contract float %164, %168
  store float %169, float addrspace(3)* %30, align 4, !tbaa !6
  %170 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 1), align 4, !tbaa !6
  %171 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %172 = load float, float addrspace(3)* %171, align 4, !tbaa !6
  %173 = fmul contract float %170, %172
  %174 = fsub contract float %169, %173
  store float %174, float addrspace(3)* %30, align 4, !tbaa !6
  %175 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 2), align 8, !tbaa !6
  %176 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %177 = load float, float addrspace(3)* %176, align 4, !tbaa !6
  %178 = fmul contract float %175, %177
  %179 = fsub contract float %174, %178
  store float %179, float addrspace(3)* %30, align 4, !tbaa !6
  br label %180

180:                                              ; preds = %163, %162
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %181 = icmp ugt i32 %6, 3
  br i1 %181, label %182, label %203

182:                                              ; preds = %180
  %183 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %184 = load float, float addrspace(3)* %183, align 4, !tbaa !6
  %185 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %186 = load float, float addrspace(3)* %185, align 16, !tbaa !6
  %187 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 3), align 4, !tbaa !6
  %188 = fmul contract float %186, %187
  %189 = fsub contract float %184, %188
  store float %189, float addrspace(3)* %183, align 4, !tbaa !6
  %190 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %191 = load float, float addrspace(3)* %190, align 4, !tbaa !6
  %192 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 3), align 4, !tbaa !6
  %193 = fmul contract float %191, %192
  %194 = fsub contract float %189, %193
  store float %194, float addrspace(3)* %183, align 4, !tbaa !6
  %195 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %196 = load float, float addrspace(3)* %195, align 8, !tbaa !6
  %197 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 3), align 4, !tbaa !6
  %198 = fmul contract float %196, %197
  %199 = fsub contract float %194, %198
  store float %199, float addrspace(3)* %183, align 4, !tbaa !6
  %200 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 3), align 4, !tbaa !6
  %201 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %202 = fdiv contract float %199, %200
  store float %202, float addrspace(3)* %201, align 4, !tbaa !6
  br label %203

203:                                              ; preds = %182, %180
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %181, label %204, label %226

204:                                              ; preds = %203
  %205 = load float, float addrspace(3)* %36, align 4, !tbaa !6
  %206 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 0), align 16, !tbaa !6
  %207 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %208 = load float, float addrspace(3)* %207, align 4, !tbaa !6
  %209 = fmul contract float %206, %208
  %210 = fsub contract float %205, %209
  store float %210, float addrspace(3)* %36, align 4, !tbaa !6
  %211 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 1), align 4, !tbaa !6
  %212 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %213 = load float, float addrspace(3)* %212, align 4, !tbaa !6
  %214 = fmul contract float %211, %213
  %215 = fsub contract float %210, %214
  store float %215, float addrspace(3)* %36, align 4, !tbaa !6
  %216 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 2), align 8, !tbaa !6
  %217 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %218 = load float, float addrspace(3)* %217, align 4, !tbaa !6
  %219 = fmul contract float %216, %218
  %220 = fsub contract float %215, %219
  store float %220, float addrspace(3)* %36, align 4, !tbaa !6
  %221 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 3), align 4, !tbaa !6
  %222 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %223 = load float, float addrspace(3)* %222, align 4, !tbaa !6
  %224 = fmul contract float %221, %223
  %225 = fsub contract float %220, %224
  store float %225, float addrspace(3)* %36, align 4, !tbaa !6
  br label %226

226:                                              ; preds = %204, %203
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %227 = icmp ugt i32 %6, 4
  br i1 %227, label %228, label %254

228:                                              ; preds = %226
  %229 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %230 = load float, float addrspace(3)* %229, align 16, !tbaa !6
  %231 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %232 = load float, float addrspace(3)* %231, align 16, !tbaa !6
  %233 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 4), align 16, !tbaa !6
  %234 = fmul contract float %232, %233
  %235 = fsub contract float %230, %234
  store float %235, float addrspace(3)* %229, align 16, !tbaa !6
  %236 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %237 = load float, float addrspace(3)* %236, align 4, !tbaa !6
  %238 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 4), align 16, !tbaa !6
  %239 = fmul contract float %237, %238
  %240 = fsub contract float %235, %239
  store float %240, float addrspace(3)* %229, align 16, !tbaa !6
  %241 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %242 = load float, float addrspace(3)* %241, align 8, !tbaa !6
  %243 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 4), align 16, !tbaa !6
  %244 = fmul contract float %242, %243
  %245 = fsub contract float %240, %244
  store float %245, float addrspace(3)* %229, align 16, !tbaa !6
  %246 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %247 = load float, float addrspace(3)* %246, align 4, !tbaa !6
  %248 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 4), align 16, !tbaa !6
  %249 = fmul contract float %247, %248
  %250 = fsub contract float %245, %249
  store float %250, float addrspace(3)* %229, align 16, !tbaa !6
  %251 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 4), align 16, !tbaa !6
  %252 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %253 = fdiv contract float %250, %251
  store float %253, float addrspace(3)* %252, align 16, !tbaa !6
  br label %254

254:                                              ; preds = %228, %226
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %227, label %255, label %282

255:                                              ; preds = %254
  %256 = load float, float addrspace(3)* %42, align 4, !tbaa !6
  %257 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 0), align 16, !tbaa !6
  %258 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %259 = load float, float addrspace(3)* %258, align 4, !tbaa !6
  %260 = fmul contract float %257, %259
  %261 = fsub contract float %256, %260
  store float %261, float addrspace(3)* %42, align 4, !tbaa !6
  %262 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 1), align 4, !tbaa !6
  %263 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %264 = load float, float addrspace(3)* %263, align 4, !tbaa !6
  %265 = fmul contract float %262, %264
  %266 = fsub contract float %261, %265
  store float %266, float addrspace(3)* %42, align 4, !tbaa !6
  %267 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 2), align 8, !tbaa !6
  %268 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %269 = load float, float addrspace(3)* %268, align 4, !tbaa !6
  %270 = fmul contract float %267, %269
  %271 = fsub contract float %266, %270
  store float %271, float addrspace(3)* %42, align 4, !tbaa !6
  %272 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 3), align 4, !tbaa !6
  %273 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %274 = load float, float addrspace(3)* %273, align 4, !tbaa !6
  %275 = fmul contract float %272, %274
  %276 = fsub contract float %271, %275
  store float %276, float addrspace(3)* %42, align 4, !tbaa !6
  %277 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 4), align 16, !tbaa !6
  %278 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %279 = load float, float addrspace(3)* %278, align 4, !tbaa !6
  %280 = fmul contract float %277, %279
  %281 = fsub contract float %276, %280
  store float %281, float addrspace(3)* %42, align 4, !tbaa !6
  br label %282

282:                                              ; preds = %255, %254
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %283 = icmp ugt i32 %6, 5
  br i1 %283, label %284, label %315

284:                                              ; preds = %282
  %285 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %286 = load float, float addrspace(3)* %285, align 4, !tbaa !6
  %287 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %288 = load float, float addrspace(3)* %287, align 16, !tbaa !6
  %289 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 5), align 4, !tbaa !6
  %290 = fmul contract float %288, %289
  %291 = fsub contract float %286, %290
  store float %291, float addrspace(3)* %285, align 4, !tbaa !6
  %292 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %293 = load float, float addrspace(3)* %292, align 4, !tbaa !6
  %294 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 5), align 4, !tbaa !6
  %295 = fmul contract float %293, %294
  %296 = fsub contract float %291, %295
  store float %296, float addrspace(3)* %285, align 4, !tbaa !6
  %297 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %298 = load float, float addrspace(3)* %297, align 8, !tbaa !6
  %299 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 5), align 4, !tbaa !6
  %300 = fmul contract float %298, %299
  %301 = fsub contract float %296, %300
  store float %301, float addrspace(3)* %285, align 4, !tbaa !6
  %302 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %303 = load float, float addrspace(3)* %302, align 4, !tbaa !6
  %304 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 5), align 4, !tbaa !6
  %305 = fmul contract float %303, %304
  %306 = fsub contract float %301, %305
  store float %306, float addrspace(3)* %285, align 4, !tbaa !6
  %307 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %308 = load float, float addrspace(3)* %307, align 16, !tbaa !6
  %309 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 5), align 4, !tbaa !6
  %310 = fmul contract float %308, %309
  %311 = fsub contract float %306, %310
  store float %311, float addrspace(3)* %285, align 4, !tbaa !6
  %312 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 5), align 4, !tbaa !6
  %313 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %314 = fdiv contract float %311, %312
  store float %314, float addrspace(3)* %313, align 4, !tbaa !6
  br label %315

315:                                              ; preds = %284, %282
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %283, label %316, label %348

316:                                              ; preds = %315
  %317 = load float, float addrspace(3)* %48, align 4, !tbaa !6
  %318 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 0), align 16, !tbaa !6
  %319 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %320 = load float, float addrspace(3)* %319, align 4, !tbaa !6
  %321 = fmul contract float %318, %320
  %322 = fsub contract float %317, %321
  store float %322, float addrspace(3)* %48, align 4, !tbaa !6
  %323 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 1), align 4, !tbaa !6
  %324 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %325 = load float, float addrspace(3)* %324, align 4, !tbaa !6
  %326 = fmul contract float %323, %325
  %327 = fsub contract float %322, %326
  store float %327, float addrspace(3)* %48, align 4, !tbaa !6
  %328 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 2), align 8, !tbaa !6
  %329 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %330 = load float, float addrspace(3)* %329, align 4, !tbaa !6
  %331 = fmul contract float %328, %330
  %332 = fsub contract float %327, %331
  store float %332, float addrspace(3)* %48, align 4, !tbaa !6
  %333 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 3), align 4, !tbaa !6
  %334 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %335 = load float, float addrspace(3)* %334, align 4, !tbaa !6
  %336 = fmul contract float %333, %335
  %337 = fsub contract float %332, %336
  store float %337, float addrspace(3)* %48, align 4, !tbaa !6
  %338 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 4), align 16, !tbaa !6
  %339 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %340 = load float, float addrspace(3)* %339, align 4, !tbaa !6
  %341 = fmul contract float %338, %340
  %342 = fsub contract float %337, %341
  store float %342, float addrspace(3)* %48, align 4, !tbaa !6
  %343 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 5), align 4, !tbaa !6
  %344 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  %345 = load float, float addrspace(3)* %344, align 4, !tbaa !6
  %346 = fmul contract float %343, %345
  %347 = fsub contract float %342, %346
  store float %347, float addrspace(3)* %48, align 4, !tbaa !6
  br label %348

348:                                              ; preds = %316, %315
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %349 = icmp ugt i32 %6, 6
  br i1 %349, label %350, label %386

350:                                              ; preds = %348
  %351 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 6
  %352 = load float, float addrspace(3)* %351, align 8, !tbaa !6
  %353 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %354 = load float, float addrspace(3)* %353, align 16, !tbaa !6
  %355 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 6), align 8, !tbaa !6
  %356 = fmul contract float %354, %355
  %357 = fsub contract float %352, %356
  store float %357, float addrspace(3)* %351, align 8, !tbaa !6
  %358 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %359 = load float, float addrspace(3)* %358, align 4, !tbaa !6
  %360 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 6), align 8, !tbaa !6
  %361 = fmul contract float %359, %360
  %362 = fsub contract float %357, %361
  store float %362, float addrspace(3)* %351, align 8, !tbaa !6
  %363 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %364 = load float, float addrspace(3)* %363, align 8, !tbaa !6
  %365 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 6), align 8, !tbaa !6
  %366 = fmul contract float %364, %365
  %367 = fsub contract float %362, %366
  store float %367, float addrspace(3)* %351, align 8, !tbaa !6
  %368 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %369 = load float, float addrspace(3)* %368, align 4, !tbaa !6
  %370 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 6), align 8, !tbaa !6
  %371 = fmul contract float %369, %370
  %372 = fsub contract float %367, %371
  store float %372, float addrspace(3)* %351, align 8, !tbaa !6
  %373 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %374 = load float, float addrspace(3)* %373, align 16, !tbaa !6
  %375 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 6), align 8, !tbaa !6
  %376 = fmul contract float %374, %375
  %377 = fsub contract float %372, %376
  store float %377, float addrspace(3)* %351, align 8, !tbaa !6
  %378 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %379 = load float, float addrspace(3)* %378, align 4, !tbaa !6
  %380 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 6), align 8, !tbaa !6
  %381 = fmul contract float %379, %380
  %382 = fsub contract float %377, %381
  store float %382, float addrspace(3)* %351, align 8, !tbaa !6
  %383 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 6), align 8, !tbaa !6
  %384 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 6
  %385 = fdiv contract float %382, %383
  store float %385, float addrspace(3)* %384, align 8, !tbaa !6
  br label %386

386:                                              ; preds = %350, %348
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %349, label %387, label %424

387:                                              ; preds = %386
  %388 = load float, float addrspace(3)* %54, align 4, !tbaa !6
  %389 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 0), align 16, !tbaa !6
  %390 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %391 = load float, float addrspace(3)* %390, align 4, !tbaa !6
  %392 = fmul contract float %389, %391
  %393 = fsub contract float %388, %392
  store float %393, float addrspace(3)* %54, align 4, !tbaa !6
  %394 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 1), align 4, !tbaa !6
  %395 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %396 = load float, float addrspace(3)* %395, align 4, !tbaa !6
  %397 = fmul contract float %394, %396
  %398 = fsub contract float %393, %397
  store float %398, float addrspace(3)* %54, align 4, !tbaa !6
  %399 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 2), align 8, !tbaa !6
  %400 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %401 = load float, float addrspace(3)* %400, align 4, !tbaa !6
  %402 = fmul contract float %399, %401
  %403 = fsub contract float %398, %402
  store float %403, float addrspace(3)* %54, align 4, !tbaa !6
  %404 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 3), align 4, !tbaa !6
  %405 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %406 = load float, float addrspace(3)* %405, align 4, !tbaa !6
  %407 = fmul contract float %404, %406
  %408 = fsub contract float %403, %407
  store float %408, float addrspace(3)* %54, align 4, !tbaa !6
  %409 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 4), align 16, !tbaa !6
  %410 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %411 = load float, float addrspace(3)* %410, align 4, !tbaa !6
  %412 = fmul contract float %409, %411
  %413 = fsub contract float %408, %412
  store float %413, float addrspace(3)* %54, align 4, !tbaa !6
  %414 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 5), align 4, !tbaa !6
  %415 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  %416 = load float, float addrspace(3)* %415, align 4, !tbaa !6
  %417 = fmul contract float %414, %416
  %418 = fsub contract float %413, %417
  store float %418, float addrspace(3)* %54, align 4, !tbaa !6
  %419 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 6), align 8, !tbaa !6
  %420 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 %6
  %421 = load float, float addrspace(3)* %420, align 4, !tbaa !6
  %422 = fmul contract float %419, %421
  %423 = fsub contract float %418, %422
  store float %423, float addrspace(3)* %54, align 4, !tbaa !6
  br label %424

424:                                              ; preds = %387, %386
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %425 = icmp ugt i32 %6, 7
  br i1 %425, label %426, label %467

426:                                              ; preds = %424
  %427 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 7
  %428 = load float, float addrspace(3)* %427, align 4, !tbaa !6
  %429 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %430 = load float, float addrspace(3)* %429, align 16, !tbaa !6
  %431 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 7), align 4, !tbaa !6
  %432 = fmul contract float %430, %431
  %433 = fsub contract float %428, %432
  store float %433, float addrspace(3)* %427, align 4, !tbaa !6
  %434 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %435 = load float, float addrspace(3)* %434, align 4, !tbaa !6
  %436 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 7), align 4, !tbaa !6
  %437 = fmul contract float %435, %436
  %438 = fsub contract float %433, %437
  store float %438, float addrspace(3)* %427, align 4, !tbaa !6
  %439 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %440 = load float, float addrspace(3)* %439, align 8, !tbaa !6
  %441 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 7), align 4, !tbaa !6
  %442 = fmul contract float %440, %441
  %443 = fsub contract float %438, %442
  store float %443, float addrspace(3)* %427, align 4, !tbaa !6
  %444 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %445 = load float, float addrspace(3)* %444, align 4, !tbaa !6
  %446 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 7), align 4, !tbaa !6
  %447 = fmul contract float %445, %446
  %448 = fsub contract float %443, %447
  store float %448, float addrspace(3)* %427, align 4, !tbaa !6
  %449 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %450 = load float, float addrspace(3)* %449, align 16, !tbaa !6
  %451 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 7), align 4, !tbaa !6
  %452 = fmul contract float %450, %451
  %453 = fsub contract float %448, %452
  store float %453, float addrspace(3)* %427, align 4, !tbaa !6
  %454 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %455 = load float, float addrspace(3)* %454, align 4, !tbaa !6
  %456 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 7), align 4, !tbaa !6
  %457 = fmul contract float %455, %456
  %458 = fsub contract float %453, %457
  store float %458, float addrspace(3)* %427, align 4, !tbaa !6
  %459 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 6
  %460 = load float, float addrspace(3)* %459, align 8, !tbaa !6
  %461 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 7), align 4, !tbaa !6
  %462 = fmul contract float %460, %461
  %463 = fsub contract float %458, %462
  store float %463, float addrspace(3)* %427, align 4, !tbaa !6
  %464 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 7), align 4, !tbaa !6
  %465 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 7
  %466 = fdiv contract float %463, %464
  store float %466, float addrspace(3)* %465, align 4, !tbaa !6
  br label %467

467:                                              ; preds = %426, %424
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %425, label %468, label %510

468:                                              ; preds = %467
  %469 = load float, float addrspace(3)* %60, align 4, !tbaa !6
  %470 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 0), align 16, !tbaa !6
  %471 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %472 = load float, float addrspace(3)* %471, align 4, !tbaa !6
  %473 = fmul contract float %470, %472
  %474 = fsub contract float %469, %473
  store float %474, float addrspace(3)* %60, align 4, !tbaa !6
  %475 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 1), align 4, !tbaa !6
  %476 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %477 = load float, float addrspace(3)* %476, align 4, !tbaa !6
  %478 = fmul contract float %475, %477
  %479 = fsub contract float %474, %478
  store float %479, float addrspace(3)* %60, align 4, !tbaa !6
  %480 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 2), align 8, !tbaa !6
  %481 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %482 = load float, float addrspace(3)* %481, align 4, !tbaa !6
  %483 = fmul contract float %480, %482
  %484 = fsub contract float %479, %483
  store float %484, float addrspace(3)* %60, align 4, !tbaa !6
  %485 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 3), align 4, !tbaa !6
  %486 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %487 = load float, float addrspace(3)* %486, align 4, !tbaa !6
  %488 = fmul contract float %485, %487
  %489 = fsub contract float %484, %488
  store float %489, float addrspace(3)* %60, align 4, !tbaa !6
  %490 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 4), align 16, !tbaa !6
  %491 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %492 = load float, float addrspace(3)* %491, align 4, !tbaa !6
  %493 = fmul contract float %490, %492
  %494 = fsub contract float %489, %493
  store float %494, float addrspace(3)* %60, align 4, !tbaa !6
  %495 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 5), align 4, !tbaa !6
  %496 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  %497 = load float, float addrspace(3)* %496, align 4, !tbaa !6
  %498 = fmul contract float %495, %497
  %499 = fsub contract float %494, %498
  store float %499, float addrspace(3)* %60, align 4, !tbaa !6
  %500 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 6), align 8, !tbaa !6
  %501 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 %6
  %502 = load float, float addrspace(3)* %501, align 4, !tbaa !6
  %503 = fmul contract float %500, %502
  %504 = fsub contract float %499, %503
  store float %504, float addrspace(3)* %60, align 4, !tbaa !6
  %505 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 7), align 4, !tbaa !6
  %506 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 %6
  %507 = load float, float addrspace(3)* %506, align 4, !tbaa !6
  %508 = fmul contract float %505, %507
  %509 = fsub contract float %504, %508
  store float %509, float addrspace(3)* %60, align 4, !tbaa !6
  br label %510

510:                                              ; preds = %468, %467
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %511 = icmp ugt i32 %6, 8
  br i1 %511, label %512, label %558

512:                                              ; preds = %510
  %513 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 8
  %514 = load float, float addrspace(3)* %513, align 16, !tbaa !6
  %515 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %516 = load float, float addrspace(3)* %515, align 16, !tbaa !6
  %517 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 8), align 16, !tbaa !6
  %518 = fmul contract float %516, %517
  %519 = fsub contract float %514, %518
  store float %519, float addrspace(3)* %513, align 16, !tbaa !6
  %520 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %521 = load float, float addrspace(3)* %520, align 4, !tbaa !6
  %522 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 8), align 16, !tbaa !6
  %523 = fmul contract float %521, %522
  %524 = fsub contract float %519, %523
  store float %524, float addrspace(3)* %513, align 16, !tbaa !6
  %525 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %526 = load float, float addrspace(3)* %525, align 8, !tbaa !6
  %527 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 8), align 16, !tbaa !6
  %528 = fmul contract float %526, %527
  %529 = fsub contract float %524, %528
  store float %529, float addrspace(3)* %513, align 16, !tbaa !6
  %530 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %531 = load float, float addrspace(3)* %530, align 4, !tbaa !6
  %532 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 8), align 16, !tbaa !6
  %533 = fmul contract float %531, %532
  %534 = fsub contract float %529, %533
  store float %534, float addrspace(3)* %513, align 16, !tbaa !6
  %535 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %536 = load float, float addrspace(3)* %535, align 16, !tbaa !6
  %537 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 8), align 16, !tbaa !6
  %538 = fmul contract float %536, %537
  %539 = fsub contract float %534, %538
  store float %539, float addrspace(3)* %513, align 16, !tbaa !6
  %540 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %541 = load float, float addrspace(3)* %540, align 4, !tbaa !6
  %542 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 8), align 16, !tbaa !6
  %543 = fmul contract float %541, %542
  %544 = fsub contract float %539, %543
  store float %544, float addrspace(3)* %513, align 16, !tbaa !6
  %545 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 6
  %546 = load float, float addrspace(3)* %545, align 8, !tbaa !6
  %547 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 8), align 16, !tbaa !6
  %548 = fmul contract float %546, %547
  %549 = fsub contract float %544, %548
  store float %549, float addrspace(3)* %513, align 16, !tbaa !6
  %550 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 7
  %551 = load float, float addrspace(3)* %550, align 4, !tbaa !6
  %552 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 8), align 16, !tbaa !6
  %553 = fmul contract float %551, %552
  %554 = fsub contract float %549, %553
  store float %554, float addrspace(3)* %513, align 16, !tbaa !6
  %555 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 8), align 16, !tbaa !6
  %556 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 8
  %557 = fdiv contract float %554, %555
  store float %557, float addrspace(3)* %556, align 16, !tbaa !6
  br label %558

558:                                              ; preds = %512, %510
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %511, label %559, label %606

559:                                              ; preds = %558
  %560 = load float, float addrspace(3)* %66, align 4, !tbaa !6
  %561 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 0), align 16, !tbaa !6
  %562 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %563 = load float, float addrspace(3)* %562, align 4, !tbaa !6
  %564 = fmul contract float %561, %563
  %565 = fsub contract float %560, %564
  store float %565, float addrspace(3)* %66, align 4, !tbaa !6
  %566 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 1), align 4, !tbaa !6
  %567 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %568 = load float, float addrspace(3)* %567, align 4, !tbaa !6
  %569 = fmul contract float %566, %568
  %570 = fsub contract float %565, %569
  store float %570, float addrspace(3)* %66, align 4, !tbaa !6
  %571 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 2), align 8, !tbaa !6
  %572 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %573 = load float, float addrspace(3)* %572, align 4, !tbaa !6
  %574 = fmul contract float %571, %573
  %575 = fsub contract float %570, %574
  store float %575, float addrspace(3)* %66, align 4, !tbaa !6
  %576 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 3), align 4, !tbaa !6
  %577 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %578 = load float, float addrspace(3)* %577, align 4, !tbaa !6
  %579 = fmul contract float %576, %578
  %580 = fsub contract float %575, %579
  store float %580, float addrspace(3)* %66, align 4, !tbaa !6
  %581 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 4), align 16, !tbaa !6
  %582 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %583 = load float, float addrspace(3)* %582, align 4, !tbaa !6
  %584 = fmul contract float %581, %583
  %585 = fsub contract float %580, %584
  store float %585, float addrspace(3)* %66, align 4, !tbaa !6
  %586 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 5), align 4, !tbaa !6
  %587 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  %588 = load float, float addrspace(3)* %587, align 4, !tbaa !6
  %589 = fmul contract float %586, %588
  %590 = fsub contract float %585, %589
  store float %590, float addrspace(3)* %66, align 4, !tbaa !6
  %591 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 6), align 8, !tbaa !6
  %592 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 %6
  %593 = load float, float addrspace(3)* %592, align 4, !tbaa !6
  %594 = fmul contract float %591, %593
  %595 = fsub contract float %590, %594
  store float %595, float addrspace(3)* %66, align 4, !tbaa !6
  %596 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 7), align 4, !tbaa !6
  %597 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 %6
  %598 = load float, float addrspace(3)* %597, align 4, !tbaa !6
  %599 = fmul contract float %596, %598
  %600 = fsub contract float %595, %599
  store float %600, float addrspace(3)* %66, align 4, !tbaa !6
  %601 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 8), align 16, !tbaa !6
  %602 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 %6
  %603 = load float, float addrspace(3)* %602, align 4, !tbaa !6
  %604 = fmul contract float %601, %603
  %605 = fsub contract float %600, %604
  store float %605, float addrspace(3)* %66, align 4, !tbaa !6
  br label %606

606:                                              ; preds = %559, %558
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %607 = icmp ugt i32 %6, 9
  br i1 %607, label %608, label %659

608:                                              ; preds = %606
  %609 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 9
  %610 = load float, float addrspace(3)* %609, align 4, !tbaa !6
  %611 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %612 = load float, float addrspace(3)* %611, align 16, !tbaa !6
  %613 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 9), align 4, !tbaa !6
  %614 = fmul contract float %612, %613
  %615 = fsub contract float %610, %614
  store float %615, float addrspace(3)* %609, align 4, !tbaa !6
  %616 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %617 = load float, float addrspace(3)* %616, align 4, !tbaa !6
  %618 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 9), align 4, !tbaa !6
  %619 = fmul contract float %617, %618
  %620 = fsub contract float %615, %619
  store float %620, float addrspace(3)* %609, align 4, !tbaa !6
  %621 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %622 = load float, float addrspace(3)* %621, align 8, !tbaa !6
  %623 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 9), align 4, !tbaa !6
  %624 = fmul contract float %622, %623
  %625 = fsub contract float %620, %624
  store float %625, float addrspace(3)* %609, align 4, !tbaa !6
  %626 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %627 = load float, float addrspace(3)* %626, align 4, !tbaa !6
  %628 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 9), align 4, !tbaa !6
  %629 = fmul contract float %627, %628
  %630 = fsub contract float %625, %629
  store float %630, float addrspace(3)* %609, align 4, !tbaa !6
  %631 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %632 = load float, float addrspace(3)* %631, align 16, !tbaa !6
  %633 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 9), align 4, !tbaa !6
  %634 = fmul contract float %632, %633
  %635 = fsub contract float %630, %634
  store float %635, float addrspace(3)* %609, align 4, !tbaa !6
  %636 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %637 = load float, float addrspace(3)* %636, align 4, !tbaa !6
  %638 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 9), align 4, !tbaa !6
  %639 = fmul contract float %637, %638
  %640 = fsub contract float %635, %639
  store float %640, float addrspace(3)* %609, align 4, !tbaa !6
  %641 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 6
  %642 = load float, float addrspace(3)* %641, align 8, !tbaa !6
  %643 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 9), align 4, !tbaa !6
  %644 = fmul contract float %642, %643
  %645 = fsub contract float %640, %644
  store float %645, float addrspace(3)* %609, align 4, !tbaa !6
  %646 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 7
  %647 = load float, float addrspace(3)* %646, align 4, !tbaa !6
  %648 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 9), align 4, !tbaa !6
  %649 = fmul contract float %647, %648
  %650 = fsub contract float %645, %649
  store float %650, float addrspace(3)* %609, align 4, !tbaa !6
  %651 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 8
  %652 = load float, float addrspace(3)* %651, align 16, !tbaa !6
  %653 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 9), align 4, !tbaa !6
  %654 = fmul contract float %652, %653
  %655 = fsub contract float %650, %654
  store float %655, float addrspace(3)* %609, align 4, !tbaa !6
  %656 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 9), align 4, !tbaa !6
  %657 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 9
  %658 = fdiv contract float %655, %656
  store float %658, float addrspace(3)* %657, align 4, !tbaa !6
  br label %659

659:                                              ; preds = %608, %606
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %607, label %660, label %712

660:                                              ; preds = %659
  %661 = load float, float addrspace(3)* %72, align 4, !tbaa !6
  %662 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 0), align 16, !tbaa !6
  %663 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %664 = load float, float addrspace(3)* %663, align 4, !tbaa !6
  %665 = fmul contract float %662, %664
  %666 = fsub contract float %661, %665
  store float %666, float addrspace(3)* %72, align 4, !tbaa !6
  %667 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 1), align 4, !tbaa !6
  %668 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %669 = load float, float addrspace(3)* %668, align 4, !tbaa !6
  %670 = fmul contract float %667, %669
  %671 = fsub contract float %666, %670
  store float %671, float addrspace(3)* %72, align 4, !tbaa !6
  %672 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 2), align 8, !tbaa !6
  %673 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %674 = load float, float addrspace(3)* %673, align 4, !tbaa !6
  %675 = fmul contract float %672, %674
  %676 = fsub contract float %671, %675
  store float %676, float addrspace(3)* %72, align 4, !tbaa !6
  %677 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 3), align 4, !tbaa !6
  %678 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %679 = load float, float addrspace(3)* %678, align 4, !tbaa !6
  %680 = fmul contract float %677, %679
  %681 = fsub contract float %676, %680
  store float %681, float addrspace(3)* %72, align 4, !tbaa !6
  %682 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 4), align 16, !tbaa !6
  %683 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %684 = load float, float addrspace(3)* %683, align 4, !tbaa !6
  %685 = fmul contract float %682, %684
  %686 = fsub contract float %681, %685
  store float %686, float addrspace(3)* %72, align 4, !tbaa !6
  %687 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 5), align 4, !tbaa !6
  %688 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  %689 = load float, float addrspace(3)* %688, align 4, !tbaa !6
  %690 = fmul contract float %687, %689
  %691 = fsub contract float %686, %690
  store float %691, float addrspace(3)* %72, align 4, !tbaa !6
  %692 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 6), align 8, !tbaa !6
  %693 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 %6
  %694 = load float, float addrspace(3)* %693, align 4, !tbaa !6
  %695 = fmul contract float %692, %694
  %696 = fsub contract float %691, %695
  store float %696, float addrspace(3)* %72, align 4, !tbaa !6
  %697 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 7), align 4, !tbaa !6
  %698 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 %6
  %699 = load float, float addrspace(3)* %698, align 4, !tbaa !6
  %700 = fmul contract float %697, %699
  %701 = fsub contract float %696, %700
  store float %701, float addrspace(3)* %72, align 4, !tbaa !6
  %702 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 8), align 16, !tbaa !6
  %703 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 %6
  %704 = load float, float addrspace(3)* %703, align 4, !tbaa !6
  %705 = fmul contract float %702, %704
  %706 = fsub contract float %701, %705
  store float %706, float addrspace(3)* %72, align 4, !tbaa !6
  %707 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 9), align 4, !tbaa !6
  %708 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 %6
  %709 = load float, float addrspace(3)* %708, align 4, !tbaa !6
  %710 = fmul contract float %707, %709
  %711 = fsub contract float %706, %710
  store float %711, float addrspace(3)* %72, align 4, !tbaa !6
  br label %712

712:                                              ; preds = %660, %659
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %713 = icmp ugt i32 %6, 10
  br i1 %713, label %714, label %770

714:                                              ; preds = %712
  %715 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 10
  %716 = load float, float addrspace(3)* %715, align 8, !tbaa !6
  %717 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %718 = load float, float addrspace(3)* %717, align 16, !tbaa !6
  %719 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 10), align 8, !tbaa !6
  %720 = fmul contract float %718, %719
  %721 = fsub contract float %716, %720
  store float %721, float addrspace(3)* %715, align 8, !tbaa !6
  %722 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %723 = load float, float addrspace(3)* %722, align 4, !tbaa !6
  %724 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 10), align 8, !tbaa !6
  %725 = fmul contract float %723, %724
  %726 = fsub contract float %721, %725
  store float %726, float addrspace(3)* %715, align 8, !tbaa !6
  %727 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %728 = load float, float addrspace(3)* %727, align 8, !tbaa !6
  %729 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 10), align 8, !tbaa !6
  %730 = fmul contract float %728, %729
  %731 = fsub contract float %726, %730
  store float %731, float addrspace(3)* %715, align 8, !tbaa !6
  %732 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %733 = load float, float addrspace(3)* %732, align 4, !tbaa !6
  %734 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 10), align 8, !tbaa !6
  %735 = fmul contract float %733, %734
  %736 = fsub contract float %731, %735
  store float %736, float addrspace(3)* %715, align 8, !tbaa !6
  %737 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %738 = load float, float addrspace(3)* %737, align 16, !tbaa !6
  %739 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 10), align 8, !tbaa !6
  %740 = fmul contract float %738, %739
  %741 = fsub contract float %736, %740
  store float %741, float addrspace(3)* %715, align 8, !tbaa !6
  %742 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %743 = load float, float addrspace(3)* %742, align 4, !tbaa !6
  %744 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 10), align 8, !tbaa !6
  %745 = fmul contract float %743, %744
  %746 = fsub contract float %741, %745
  store float %746, float addrspace(3)* %715, align 8, !tbaa !6
  %747 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 6
  %748 = load float, float addrspace(3)* %747, align 8, !tbaa !6
  %749 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 10), align 8, !tbaa !6
  %750 = fmul contract float %748, %749
  %751 = fsub contract float %746, %750
  store float %751, float addrspace(3)* %715, align 8, !tbaa !6
  %752 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 7
  %753 = load float, float addrspace(3)* %752, align 4, !tbaa !6
  %754 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 10), align 8, !tbaa !6
  %755 = fmul contract float %753, %754
  %756 = fsub contract float %751, %755
  store float %756, float addrspace(3)* %715, align 8, !tbaa !6
  %757 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 8
  %758 = load float, float addrspace(3)* %757, align 16, !tbaa !6
  %759 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 10), align 8, !tbaa !6
  %760 = fmul contract float %758, %759
  %761 = fsub contract float %756, %760
  store float %761, float addrspace(3)* %715, align 8, !tbaa !6
  %762 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 9
  %763 = load float, float addrspace(3)* %762, align 4, !tbaa !6
  %764 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 10), align 8, !tbaa !6
  %765 = fmul contract float %763, %764
  %766 = fsub contract float %761, %765
  store float %766, float addrspace(3)* %715, align 8, !tbaa !6
  %767 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 10), align 8, !tbaa !6
  %768 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 10
  %769 = fdiv contract float %766, %767
  store float %769, float addrspace(3)* %768, align 8, !tbaa !6
  br label %770

770:                                              ; preds = %714, %712
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %713, label %771, label %828

771:                                              ; preds = %770
  %772 = load float, float addrspace(3)* %78, align 4, !tbaa !6
  %773 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 0), align 16, !tbaa !6
  %774 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %775 = load float, float addrspace(3)* %774, align 4, !tbaa !6
  %776 = fmul contract float %773, %775
  %777 = fsub contract float %772, %776
  store float %777, float addrspace(3)* %78, align 4, !tbaa !6
  %778 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 1), align 4, !tbaa !6
  %779 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %780 = load float, float addrspace(3)* %779, align 4, !tbaa !6
  %781 = fmul contract float %778, %780
  %782 = fsub contract float %777, %781
  store float %782, float addrspace(3)* %78, align 4, !tbaa !6
  %783 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 2), align 8, !tbaa !6
  %784 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %785 = load float, float addrspace(3)* %784, align 4, !tbaa !6
  %786 = fmul contract float %783, %785
  %787 = fsub contract float %782, %786
  store float %787, float addrspace(3)* %78, align 4, !tbaa !6
  %788 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 3), align 4, !tbaa !6
  %789 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %790 = load float, float addrspace(3)* %789, align 4, !tbaa !6
  %791 = fmul contract float %788, %790
  %792 = fsub contract float %787, %791
  store float %792, float addrspace(3)* %78, align 4, !tbaa !6
  %793 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 4), align 16, !tbaa !6
  %794 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %795 = load float, float addrspace(3)* %794, align 4, !tbaa !6
  %796 = fmul contract float %793, %795
  %797 = fsub contract float %792, %796
  store float %797, float addrspace(3)* %78, align 4, !tbaa !6
  %798 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 5), align 4, !tbaa !6
  %799 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  %800 = load float, float addrspace(3)* %799, align 4, !tbaa !6
  %801 = fmul contract float %798, %800
  %802 = fsub contract float %797, %801
  store float %802, float addrspace(3)* %78, align 4, !tbaa !6
  %803 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 6), align 8, !tbaa !6
  %804 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 %6
  %805 = load float, float addrspace(3)* %804, align 4, !tbaa !6
  %806 = fmul contract float %803, %805
  %807 = fsub contract float %802, %806
  store float %807, float addrspace(3)* %78, align 4, !tbaa !6
  %808 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 7), align 4, !tbaa !6
  %809 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 %6
  %810 = load float, float addrspace(3)* %809, align 4, !tbaa !6
  %811 = fmul contract float %808, %810
  %812 = fsub contract float %807, %811
  store float %812, float addrspace(3)* %78, align 4, !tbaa !6
  %813 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 8), align 16, !tbaa !6
  %814 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 %6
  %815 = load float, float addrspace(3)* %814, align 4, !tbaa !6
  %816 = fmul contract float %813, %815
  %817 = fsub contract float %812, %816
  store float %817, float addrspace(3)* %78, align 4, !tbaa !6
  %818 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 9), align 4, !tbaa !6
  %819 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 %6
  %820 = load float, float addrspace(3)* %819, align 4, !tbaa !6
  %821 = fmul contract float %818, %820
  %822 = fsub contract float %817, %821
  store float %822, float addrspace(3)* %78, align 4, !tbaa !6
  %823 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 10), align 8, !tbaa !6
  %824 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 %6
  %825 = load float, float addrspace(3)* %824, align 4, !tbaa !6
  %826 = fmul contract float %823, %825
  %827 = fsub contract float %822, %826
  store float %827, float addrspace(3)* %78, align 4, !tbaa !6
  br label %828

828:                                              ; preds = %771, %770
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %829 = icmp ugt i32 %6, 11
  br i1 %829, label %830, label %891

830:                                              ; preds = %828
  %831 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 11
  %832 = load float, float addrspace(3)* %831, align 4, !tbaa !6
  %833 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %834 = load float, float addrspace(3)* %833, align 16, !tbaa !6
  %835 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 11), align 4, !tbaa !6
  %836 = fmul contract float %834, %835
  %837 = fsub contract float %832, %836
  store float %837, float addrspace(3)* %831, align 4, !tbaa !6
  %838 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %839 = load float, float addrspace(3)* %838, align 4, !tbaa !6
  %840 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 11), align 4, !tbaa !6
  %841 = fmul contract float %839, %840
  %842 = fsub contract float %837, %841
  store float %842, float addrspace(3)* %831, align 4, !tbaa !6
  %843 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %844 = load float, float addrspace(3)* %843, align 8, !tbaa !6
  %845 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 11), align 4, !tbaa !6
  %846 = fmul contract float %844, %845
  %847 = fsub contract float %842, %846
  store float %847, float addrspace(3)* %831, align 4, !tbaa !6
  %848 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %849 = load float, float addrspace(3)* %848, align 4, !tbaa !6
  %850 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 11), align 4, !tbaa !6
  %851 = fmul contract float %849, %850
  %852 = fsub contract float %847, %851
  store float %852, float addrspace(3)* %831, align 4, !tbaa !6
  %853 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %854 = load float, float addrspace(3)* %853, align 16, !tbaa !6
  %855 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 11), align 4, !tbaa !6
  %856 = fmul contract float %854, %855
  %857 = fsub contract float %852, %856
  store float %857, float addrspace(3)* %831, align 4, !tbaa !6
  %858 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %859 = load float, float addrspace(3)* %858, align 4, !tbaa !6
  %860 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 11), align 4, !tbaa !6
  %861 = fmul contract float %859, %860
  %862 = fsub contract float %857, %861
  store float %862, float addrspace(3)* %831, align 4, !tbaa !6
  %863 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 6
  %864 = load float, float addrspace(3)* %863, align 8, !tbaa !6
  %865 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 11), align 4, !tbaa !6
  %866 = fmul contract float %864, %865
  %867 = fsub contract float %862, %866
  store float %867, float addrspace(3)* %831, align 4, !tbaa !6
  %868 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 7
  %869 = load float, float addrspace(3)* %868, align 4, !tbaa !6
  %870 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 11), align 4, !tbaa !6
  %871 = fmul contract float %869, %870
  %872 = fsub contract float %867, %871
  store float %872, float addrspace(3)* %831, align 4, !tbaa !6
  %873 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 8
  %874 = load float, float addrspace(3)* %873, align 16, !tbaa !6
  %875 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 11), align 4, !tbaa !6
  %876 = fmul contract float %874, %875
  %877 = fsub contract float %872, %876
  store float %877, float addrspace(3)* %831, align 4, !tbaa !6
  %878 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 9
  %879 = load float, float addrspace(3)* %878, align 4, !tbaa !6
  %880 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 11), align 4, !tbaa !6
  %881 = fmul contract float %879, %880
  %882 = fsub contract float %877, %881
  store float %882, float addrspace(3)* %831, align 4, !tbaa !6
  %883 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 10
  %884 = load float, float addrspace(3)* %883, align 8, !tbaa !6
  %885 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 11), align 4, !tbaa !6
  %886 = fmul contract float %884, %885
  %887 = fsub contract float %882, %886
  store float %887, float addrspace(3)* %831, align 4, !tbaa !6
  %888 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 11), align 4, !tbaa !6
  %889 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 11
  %890 = fdiv contract float %887, %888
  store float %890, float addrspace(3)* %889, align 4, !tbaa !6
  br label %891

891:                                              ; preds = %830, %828
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %829, label %892, label %954

892:                                              ; preds = %891
  %893 = load float, float addrspace(3)* %84, align 4, !tbaa !6
  %894 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 0), align 16, !tbaa !6
  %895 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %896 = load float, float addrspace(3)* %895, align 4, !tbaa !6
  %897 = fmul contract float %894, %896
  %898 = fsub contract float %893, %897
  store float %898, float addrspace(3)* %84, align 4, !tbaa !6
  %899 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 1), align 4, !tbaa !6
  %900 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %901 = load float, float addrspace(3)* %900, align 4, !tbaa !6
  %902 = fmul contract float %899, %901
  %903 = fsub contract float %898, %902
  store float %903, float addrspace(3)* %84, align 4, !tbaa !6
  %904 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 2), align 8, !tbaa !6
  %905 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %906 = load float, float addrspace(3)* %905, align 4, !tbaa !6
  %907 = fmul contract float %904, %906
  %908 = fsub contract float %903, %907
  store float %908, float addrspace(3)* %84, align 4, !tbaa !6
  %909 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 3), align 4, !tbaa !6
  %910 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %911 = load float, float addrspace(3)* %910, align 4, !tbaa !6
  %912 = fmul contract float %909, %911
  %913 = fsub contract float %908, %912
  store float %913, float addrspace(3)* %84, align 4, !tbaa !6
  %914 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 4), align 16, !tbaa !6
  %915 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %916 = load float, float addrspace(3)* %915, align 4, !tbaa !6
  %917 = fmul contract float %914, %916
  %918 = fsub contract float %913, %917
  store float %918, float addrspace(3)* %84, align 4, !tbaa !6
  %919 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 5), align 4, !tbaa !6
  %920 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  %921 = load float, float addrspace(3)* %920, align 4, !tbaa !6
  %922 = fmul contract float %919, %921
  %923 = fsub contract float %918, %922
  store float %923, float addrspace(3)* %84, align 4, !tbaa !6
  %924 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 6), align 8, !tbaa !6
  %925 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 %6
  %926 = load float, float addrspace(3)* %925, align 4, !tbaa !6
  %927 = fmul contract float %924, %926
  %928 = fsub contract float %923, %927
  store float %928, float addrspace(3)* %84, align 4, !tbaa !6
  %929 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 7), align 4, !tbaa !6
  %930 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 %6
  %931 = load float, float addrspace(3)* %930, align 4, !tbaa !6
  %932 = fmul contract float %929, %931
  %933 = fsub contract float %928, %932
  store float %933, float addrspace(3)* %84, align 4, !tbaa !6
  %934 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 8), align 16, !tbaa !6
  %935 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 %6
  %936 = load float, float addrspace(3)* %935, align 4, !tbaa !6
  %937 = fmul contract float %934, %936
  %938 = fsub contract float %933, %937
  store float %938, float addrspace(3)* %84, align 4, !tbaa !6
  %939 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 9), align 4, !tbaa !6
  %940 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 %6
  %941 = load float, float addrspace(3)* %940, align 4, !tbaa !6
  %942 = fmul contract float %939, %941
  %943 = fsub contract float %938, %942
  store float %943, float addrspace(3)* %84, align 4, !tbaa !6
  %944 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 10), align 8, !tbaa !6
  %945 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 %6
  %946 = load float, float addrspace(3)* %945, align 4, !tbaa !6
  %947 = fmul contract float %944, %946
  %948 = fsub contract float %943, %947
  store float %948, float addrspace(3)* %84, align 4, !tbaa !6
  %949 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 11), align 4, !tbaa !6
  %950 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 %6
  %951 = load float, float addrspace(3)* %950, align 4, !tbaa !6
  %952 = fmul contract float %949, %951
  %953 = fsub contract float %948, %952
  store float %953, float addrspace(3)* %84, align 4, !tbaa !6
  br label %954

954:                                              ; preds = %892, %891
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %955 = icmp ugt i32 %6, 12
  br i1 %955, label %956, label %1022

956:                                              ; preds = %954
  %957 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 12
  %958 = load float, float addrspace(3)* %957, align 16, !tbaa !6
  %959 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %960 = load float, float addrspace(3)* %959, align 16, !tbaa !6
  %961 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 12), align 16, !tbaa !6
  %962 = fmul contract float %960, %961
  %963 = fsub contract float %958, %962
  store float %963, float addrspace(3)* %957, align 16, !tbaa !6
  %964 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %965 = load float, float addrspace(3)* %964, align 4, !tbaa !6
  %966 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 12), align 16, !tbaa !6
  %967 = fmul contract float %965, %966
  %968 = fsub contract float %963, %967
  store float %968, float addrspace(3)* %957, align 16, !tbaa !6
  %969 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %970 = load float, float addrspace(3)* %969, align 8, !tbaa !6
  %971 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 12), align 16, !tbaa !6
  %972 = fmul contract float %970, %971
  %973 = fsub contract float %968, %972
  store float %973, float addrspace(3)* %957, align 16, !tbaa !6
  %974 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %975 = load float, float addrspace(3)* %974, align 4, !tbaa !6
  %976 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 12), align 16, !tbaa !6
  %977 = fmul contract float %975, %976
  %978 = fsub contract float %973, %977
  store float %978, float addrspace(3)* %957, align 16, !tbaa !6
  %979 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %980 = load float, float addrspace(3)* %979, align 16, !tbaa !6
  %981 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 12), align 16, !tbaa !6
  %982 = fmul contract float %980, %981
  %983 = fsub contract float %978, %982
  store float %983, float addrspace(3)* %957, align 16, !tbaa !6
  %984 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %985 = load float, float addrspace(3)* %984, align 4, !tbaa !6
  %986 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 12), align 16, !tbaa !6
  %987 = fmul contract float %985, %986
  %988 = fsub contract float %983, %987
  store float %988, float addrspace(3)* %957, align 16, !tbaa !6
  %989 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 6
  %990 = load float, float addrspace(3)* %989, align 8, !tbaa !6
  %991 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 12), align 16, !tbaa !6
  %992 = fmul contract float %990, %991
  %993 = fsub contract float %988, %992
  store float %993, float addrspace(3)* %957, align 16, !tbaa !6
  %994 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 7
  %995 = load float, float addrspace(3)* %994, align 4, !tbaa !6
  %996 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 12), align 16, !tbaa !6
  %997 = fmul contract float %995, %996
  %998 = fsub contract float %993, %997
  store float %998, float addrspace(3)* %957, align 16, !tbaa !6
  %999 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 8
  %1000 = load float, float addrspace(3)* %999, align 16, !tbaa !6
  %1001 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 12), align 16, !tbaa !6
  %1002 = fmul contract float %1000, %1001
  %1003 = fsub contract float %998, %1002
  store float %1003, float addrspace(3)* %957, align 16, !tbaa !6
  %1004 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 9
  %1005 = load float, float addrspace(3)* %1004, align 4, !tbaa !6
  %1006 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 12), align 16, !tbaa !6
  %1007 = fmul contract float %1005, %1006
  %1008 = fsub contract float %1003, %1007
  store float %1008, float addrspace(3)* %957, align 16, !tbaa !6
  %1009 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 10
  %1010 = load float, float addrspace(3)* %1009, align 8, !tbaa !6
  %1011 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 12), align 16, !tbaa !6
  %1012 = fmul contract float %1010, %1011
  %1013 = fsub contract float %1008, %1012
  store float %1013, float addrspace(3)* %957, align 16, !tbaa !6
  %1014 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 11
  %1015 = load float, float addrspace(3)* %1014, align 4, !tbaa !6
  %1016 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 12), align 16, !tbaa !6
  %1017 = fmul contract float %1015, %1016
  %1018 = fsub contract float %1013, %1017
  store float %1018, float addrspace(3)* %957, align 16, !tbaa !6
  %1019 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 12), align 16, !tbaa !6
  %1020 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 12
  %1021 = fdiv contract float %1018, %1019
  store float %1021, float addrspace(3)* %1020, align 16, !tbaa !6
  br label %1022

1022:                                             ; preds = %956, %954
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %955, label %1023, label %1090

1023:                                             ; preds = %1022
  %1024 = load float, float addrspace(3)* %90, align 4, !tbaa !6
  %1025 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 0), align 16, !tbaa !6
  %1026 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %1027 = load float, float addrspace(3)* %1026, align 4, !tbaa !6
  %1028 = fmul contract float %1025, %1027
  %1029 = fsub contract float %1024, %1028
  store float %1029, float addrspace(3)* %90, align 4, !tbaa !6
  %1030 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 1), align 4, !tbaa !6
  %1031 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %1032 = load float, float addrspace(3)* %1031, align 4, !tbaa !6
  %1033 = fmul contract float %1030, %1032
  %1034 = fsub contract float %1029, %1033
  store float %1034, float addrspace(3)* %90, align 4, !tbaa !6
  %1035 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 2), align 8, !tbaa !6
  %1036 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %1037 = load float, float addrspace(3)* %1036, align 4, !tbaa !6
  %1038 = fmul contract float %1035, %1037
  %1039 = fsub contract float %1034, %1038
  store float %1039, float addrspace(3)* %90, align 4, !tbaa !6
  %1040 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 3), align 4, !tbaa !6
  %1041 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %1042 = load float, float addrspace(3)* %1041, align 4, !tbaa !6
  %1043 = fmul contract float %1040, %1042
  %1044 = fsub contract float %1039, %1043
  store float %1044, float addrspace(3)* %90, align 4, !tbaa !6
  %1045 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 4), align 16, !tbaa !6
  %1046 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %1047 = load float, float addrspace(3)* %1046, align 4, !tbaa !6
  %1048 = fmul contract float %1045, %1047
  %1049 = fsub contract float %1044, %1048
  store float %1049, float addrspace(3)* %90, align 4, !tbaa !6
  %1050 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 5), align 4, !tbaa !6
  %1051 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  %1052 = load float, float addrspace(3)* %1051, align 4, !tbaa !6
  %1053 = fmul contract float %1050, %1052
  %1054 = fsub contract float %1049, %1053
  store float %1054, float addrspace(3)* %90, align 4, !tbaa !6
  %1055 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 6), align 8, !tbaa !6
  %1056 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 %6
  %1057 = load float, float addrspace(3)* %1056, align 4, !tbaa !6
  %1058 = fmul contract float %1055, %1057
  %1059 = fsub contract float %1054, %1058
  store float %1059, float addrspace(3)* %90, align 4, !tbaa !6
  %1060 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 7), align 4, !tbaa !6
  %1061 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 %6
  %1062 = load float, float addrspace(3)* %1061, align 4, !tbaa !6
  %1063 = fmul contract float %1060, %1062
  %1064 = fsub contract float %1059, %1063
  store float %1064, float addrspace(3)* %90, align 4, !tbaa !6
  %1065 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 8), align 16, !tbaa !6
  %1066 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 %6
  %1067 = load float, float addrspace(3)* %1066, align 4, !tbaa !6
  %1068 = fmul contract float %1065, %1067
  %1069 = fsub contract float %1064, %1068
  store float %1069, float addrspace(3)* %90, align 4, !tbaa !6
  %1070 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 9), align 4, !tbaa !6
  %1071 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 %6
  %1072 = load float, float addrspace(3)* %1071, align 4, !tbaa !6
  %1073 = fmul contract float %1070, %1072
  %1074 = fsub contract float %1069, %1073
  store float %1074, float addrspace(3)* %90, align 4, !tbaa !6
  %1075 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 10), align 8, !tbaa !6
  %1076 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 %6
  %1077 = load float, float addrspace(3)* %1076, align 4, !tbaa !6
  %1078 = fmul contract float %1075, %1077
  %1079 = fsub contract float %1074, %1078
  store float %1079, float addrspace(3)* %90, align 4, !tbaa !6
  %1080 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 11), align 4, !tbaa !6
  %1081 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 %6
  %1082 = load float, float addrspace(3)* %1081, align 4, !tbaa !6
  %1083 = fmul contract float %1080, %1082
  %1084 = fsub contract float %1079, %1083
  store float %1084, float addrspace(3)* %90, align 4, !tbaa !6
  %1085 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 12), align 16, !tbaa !6
  %1086 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 %6
  %1087 = load float, float addrspace(3)* %1086, align 4, !tbaa !6
  %1088 = fmul contract float %1085, %1087
  %1089 = fsub contract float %1084, %1088
  store float %1089, float addrspace(3)* %90, align 4, !tbaa !6
  br label %1090

1090:                                             ; preds = %1023, %1022
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %1091 = icmp ugt i32 %6, 13
  br i1 %1091, label %1092, label %1163

1092:                                             ; preds = %1090
  %1093 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 13
  %1094 = load float, float addrspace(3)* %1093, align 4, !tbaa !6
  %1095 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %1096 = load float, float addrspace(3)* %1095, align 16, !tbaa !6
  %1097 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 13), align 4, !tbaa !6
  %1098 = fmul contract float %1096, %1097
  %1099 = fsub contract float %1094, %1098
  store float %1099, float addrspace(3)* %1093, align 4, !tbaa !6
  %1100 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %1101 = load float, float addrspace(3)* %1100, align 4, !tbaa !6
  %1102 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 13), align 4, !tbaa !6
  %1103 = fmul contract float %1101, %1102
  %1104 = fsub contract float %1099, %1103
  store float %1104, float addrspace(3)* %1093, align 4, !tbaa !6
  %1105 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %1106 = load float, float addrspace(3)* %1105, align 8, !tbaa !6
  %1107 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 13), align 4, !tbaa !6
  %1108 = fmul contract float %1106, %1107
  %1109 = fsub contract float %1104, %1108
  store float %1109, float addrspace(3)* %1093, align 4, !tbaa !6
  %1110 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %1111 = load float, float addrspace(3)* %1110, align 4, !tbaa !6
  %1112 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 13), align 4, !tbaa !6
  %1113 = fmul contract float %1111, %1112
  %1114 = fsub contract float %1109, %1113
  store float %1114, float addrspace(3)* %1093, align 4, !tbaa !6
  %1115 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %1116 = load float, float addrspace(3)* %1115, align 16, !tbaa !6
  %1117 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 13), align 4, !tbaa !6
  %1118 = fmul contract float %1116, %1117
  %1119 = fsub contract float %1114, %1118
  store float %1119, float addrspace(3)* %1093, align 4, !tbaa !6
  %1120 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %1121 = load float, float addrspace(3)* %1120, align 4, !tbaa !6
  %1122 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 13), align 4, !tbaa !6
  %1123 = fmul contract float %1121, %1122
  %1124 = fsub contract float %1119, %1123
  store float %1124, float addrspace(3)* %1093, align 4, !tbaa !6
  %1125 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 6
  %1126 = load float, float addrspace(3)* %1125, align 8, !tbaa !6
  %1127 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 13), align 4, !tbaa !6
  %1128 = fmul contract float %1126, %1127
  %1129 = fsub contract float %1124, %1128
  store float %1129, float addrspace(3)* %1093, align 4, !tbaa !6
  %1130 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 7
  %1131 = load float, float addrspace(3)* %1130, align 4, !tbaa !6
  %1132 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 13), align 4, !tbaa !6
  %1133 = fmul contract float %1131, %1132
  %1134 = fsub contract float %1129, %1133
  store float %1134, float addrspace(3)* %1093, align 4, !tbaa !6
  %1135 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 8
  %1136 = load float, float addrspace(3)* %1135, align 16, !tbaa !6
  %1137 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 13), align 4, !tbaa !6
  %1138 = fmul contract float %1136, %1137
  %1139 = fsub contract float %1134, %1138
  store float %1139, float addrspace(3)* %1093, align 4, !tbaa !6
  %1140 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 9
  %1141 = load float, float addrspace(3)* %1140, align 4, !tbaa !6
  %1142 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 13), align 4, !tbaa !6
  %1143 = fmul contract float %1141, %1142
  %1144 = fsub contract float %1139, %1143
  store float %1144, float addrspace(3)* %1093, align 4, !tbaa !6
  %1145 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 10
  %1146 = load float, float addrspace(3)* %1145, align 8, !tbaa !6
  %1147 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 13), align 4, !tbaa !6
  %1148 = fmul contract float %1146, %1147
  %1149 = fsub contract float %1144, %1148
  store float %1149, float addrspace(3)* %1093, align 4, !tbaa !6
  %1150 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 11
  %1151 = load float, float addrspace(3)* %1150, align 4, !tbaa !6
  %1152 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 13), align 4, !tbaa !6
  %1153 = fmul contract float %1151, %1152
  %1154 = fsub contract float %1149, %1153
  store float %1154, float addrspace(3)* %1093, align 4, !tbaa !6
  %1155 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 12
  %1156 = load float, float addrspace(3)* %1155, align 16, !tbaa !6
  %1157 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 13), align 4, !tbaa !6
  %1158 = fmul contract float %1156, %1157
  %1159 = fsub contract float %1154, %1158
  store float %1159, float addrspace(3)* %1093, align 4, !tbaa !6
  %1160 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 13), align 4, !tbaa !6
  %1161 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 13
  %1162 = fdiv contract float %1159, %1160
  store float %1162, float addrspace(3)* %1161, align 4, !tbaa !6
  br label %1163

1163:                                             ; preds = %1092, %1090
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %1091, label %1164, label %1236

1164:                                             ; preds = %1163
  %1165 = load float, float addrspace(3)* %96, align 4, !tbaa !6
  %1166 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 0), align 16, !tbaa !6
  %1167 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %1168 = load float, float addrspace(3)* %1167, align 4, !tbaa !6
  %1169 = fmul contract float %1166, %1168
  %1170 = fsub contract float %1165, %1169
  store float %1170, float addrspace(3)* %96, align 4, !tbaa !6
  %1171 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 1), align 4, !tbaa !6
  %1172 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %1173 = load float, float addrspace(3)* %1172, align 4, !tbaa !6
  %1174 = fmul contract float %1171, %1173
  %1175 = fsub contract float %1170, %1174
  store float %1175, float addrspace(3)* %96, align 4, !tbaa !6
  %1176 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 2), align 8, !tbaa !6
  %1177 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %1178 = load float, float addrspace(3)* %1177, align 4, !tbaa !6
  %1179 = fmul contract float %1176, %1178
  %1180 = fsub contract float %1175, %1179
  store float %1180, float addrspace(3)* %96, align 4, !tbaa !6
  %1181 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 3), align 4, !tbaa !6
  %1182 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %1183 = load float, float addrspace(3)* %1182, align 4, !tbaa !6
  %1184 = fmul contract float %1181, %1183
  %1185 = fsub contract float %1180, %1184
  store float %1185, float addrspace(3)* %96, align 4, !tbaa !6
  %1186 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 4), align 16, !tbaa !6
  %1187 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %1188 = load float, float addrspace(3)* %1187, align 4, !tbaa !6
  %1189 = fmul contract float %1186, %1188
  %1190 = fsub contract float %1185, %1189
  store float %1190, float addrspace(3)* %96, align 4, !tbaa !6
  %1191 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 5), align 4, !tbaa !6
  %1192 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  %1193 = load float, float addrspace(3)* %1192, align 4, !tbaa !6
  %1194 = fmul contract float %1191, %1193
  %1195 = fsub contract float %1190, %1194
  store float %1195, float addrspace(3)* %96, align 4, !tbaa !6
  %1196 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 6), align 8, !tbaa !6
  %1197 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 %6
  %1198 = load float, float addrspace(3)* %1197, align 4, !tbaa !6
  %1199 = fmul contract float %1196, %1198
  %1200 = fsub contract float %1195, %1199
  store float %1200, float addrspace(3)* %96, align 4, !tbaa !6
  %1201 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 7), align 4, !tbaa !6
  %1202 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 %6
  %1203 = load float, float addrspace(3)* %1202, align 4, !tbaa !6
  %1204 = fmul contract float %1201, %1203
  %1205 = fsub contract float %1200, %1204
  store float %1205, float addrspace(3)* %96, align 4, !tbaa !6
  %1206 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 8), align 16, !tbaa !6
  %1207 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 %6
  %1208 = load float, float addrspace(3)* %1207, align 4, !tbaa !6
  %1209 = fmul contract float %1206, %1208
  %1210 = fsub contract float %1205, %1209
  store float %1210, float addrspace(3)* %96, align 4, !tbaa !6
  %1211 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 9), align 4, !tbaa !6
  %1212 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 %6
  %1213 = load float, float addrspace(3)* %1212, align 4, !tbaa !6
  %1214 = fmul contract float %1211, %1213
  %1215 = fsub contract float %1210, %1214
  store float %1215, float addrspace(3)* %96, align 4, !tbaa !6
  %1216 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 10), align 8, !tbaa !6
  %1217 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 %6
  %1218 = load float, float addrspace(3)* %1217, align 4, !tbaa !6
  %1219 = fmul contract float %1216, %1218
  %1220 = fsub contract float %1215, %1219
  store float %1220, float addrspace(3)* %96, align 4, !tbaa !6
  %1221 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 11), align 4, !tbaa !6
  %1222 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 %6
  %1223 = load float, float addrspace(3)* %1222, align 4, !tbaa !6
  %1224 = fmul contract float %1221, %1223
  %1225 = fsub contract float %1220, %1224
  store float %1225, float addrspace(3)* %96, align 4, !tbaa !6
  %1226 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 12), align 16, !tbaa !6
  %1227 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 %6
  %1228 = load float, float addrspace(3)* %1227, align 4, !tbaa !6
  %1229 = fmul contract float %1226, %1228
  %1230 = fsub contract float %1225, %1229
  store float %1230, float addrspace(3)* %96, align 4, !tbaa !6
  %1231 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 13), align 4, !tbaa !6
  %1232 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 %6
  %1233 = load float, float addrspace(3)* %1232, align 4, !tbaa !6
  %1234 = fmul contract float %1231, %1233
  %1235 = fsub contract float %1230, %1234
  store float %1235, float addrspace(3)* %96, align 4, !tbaa !6
  br label %1236

1236:                                             ; preds = %1164, %1163
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %1237 = icmp ugt i32 %6, 14
  br i1 %1237, label %1238, label %1314

1238:                                             ; preds = %1236
  %1239 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 14
  %1240 = load float, float addrspace(3)* %1239, align 8, !tbaa !6
  %1241 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 0
  %1242 = load float, float addrspace(3)* %1241, align 16, !tbaa !6
  %1243 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 14), align 8, !tbaa !6
  %1244 = fmul contract float %1242, %1243
  %1245 = fsub contract float %1240, %1244
  store float %1245, float addrspace(3)* %1239, align 8, !tbaa !6
  %1246 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 1
  %1247 = load float, float addrspace(3)* %1246, align 4, !tbaa !6
  %1248 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 14), align 8, !tbaa !6
  %1249 = fmul contract float %1247, %1248
  %1250 = fsub contract float %1245, %1249
  store float %1250, float addrspace(3)* %1239, align 8, !tbaa !6
  %1251 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 2
  %1252 = load float, float addrspace(3)* %1251, align 8, !tbaa !6
  %1253 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 14), align 8, !tbaa !6
  %1254 = fmul contract float %1252, %1253
  %1255 = fsub contract float %1250, %1254
  store float %1255, float addrspace(3)* %1239, align 8, !tbaa !6
  %1256 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 3
  %1257 = load float, float addrspace(3)* %1256, align 4, !tbaa !6
  %1258 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 14), align 8, !tbaa !6
  %1259 = fmul contract float %1257, %1258
  %1260 = fsub contract float %1255, %1259
  store float %1260, float addrspace(3)* %1239, align 8, !tbaa !6
  %1261 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 4
  %1262 = load float, float addrspace(3)* %1261, align 16, !tbaa !6
  %1263 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 14), align 8, !tbaa !6
  %1264 = fmul contract float %1262, %1263
  %1265 = fsub contract float %1260, %1264
  store float %1265, float addrspace(3)* %1239, align 8, !tbaa !6
  %1266 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 5
  %1267 = load float, float addrspace(3)* %1266, align 4, !tbaa !6
  %1268 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 14), align 8, !tbaa !6
  %1269 = fmul contract float %1267, %1268
  %1270 = fsub contract float %1265, %1269
  store float %1270, float addrspace(3)* %1239, align 8, !tbaa !6
  %1271 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 6
  %1272 = load float, float addrspace(3)* %1271, align 8, !tbaa !6
  %1273 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 14), align 8, !tbaa !6
  %1274 = fmul contract float %1272, %1273
  %1275 = fsub contract float %1270, %1274
  store float %1275, float addrspace(3)* %1239, align 8, !tbaa !6
  %1276 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 7
  %1277 = load float, float addrspace(3)* %1276, align 4, !tbaa !6
  %1278 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 14), align 8, !tbaa !6
  %1279 = fmul contract float %1277, %1278
  %1280 = fsub contract float %1275, %1279
  store float %1280, float addrspace(3)* %1239, align 8, !tbaa !6
  %1281 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 8
  %1282 = load float, float addrspace(3)* %1281, align 16, !tbaa !6
  %1283 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 14), align 8, !tbaa !6
  %1284 = fmul contract float %1282, %1283
  %1285 = fsub contract float %1280, %1284
  store float %1285, float addrspace(3)* %1239, align 8, !tbaa !6
  %1286 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 9
  %1287 = load float, float addrspace(3)* %1286, align 4, !tbaa !6
  %1288 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 14), align 8, !tbaa !6
  %1289 = fmul contract float %1287, %1288
  %1290 = fsub contract float %1285, %1289
  store float %1290, float addrspace(3)* %1239, align 8, !tbaa !6
  %1291 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 10
  %1292 = load float, float addrspace(3)* %1291, align 8, !tbaa !6
  %1293 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 14), align 8, !tbaa !6
  %1294 = fmul contract float %1292, %1293
  %1295 = fsub contract float %1290, %1294
  store float %1295, float addrspace(3)* %1239, align 8, !tbaa !6
  %1296 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 11
  %1297 = load float, float addrspace(3)* %1296, align 4, !tbaa !6
  %1298 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 14), align 8, !tbaa !6
  %1299 = fmul contract float %1297, %1298
  %1300 = fsub contract float %1295, %1299
  store float %1300, float addrspace(3)* %1239, align 8, !tbaa !6
  %1301 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 12
  %1302 = load float, float addrspace(3)* %1301, align 16, !tbaa !6
  %1303 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 14), align 8, !tbaa !6
  %1304 = fmul contract float %1302, %1303
  %1305 = fsub contract float %1300, %1304
  store float %1305, float addrspace(3)* %1239, align 8, !tbaa !6
  %1306 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 13
  %1307 = load float, float addrspace(3)* %1306, align 4, !tbaa !6
  %1308 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 14), align 8, !tbaa !6
  %1309 = fmul contract float %1307, %1308
  %1310 = fsub contract float %1305, %1309
  store float %1310, float addrspace(3)* %1239, align 8, !tbaa !6
  %1311 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 14), align 8, !tbaa !6
  %1312 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 %6, i32 14
  %1313 = fdiv contract float %1310, %1311
  store float %1313, float addrspace(3)* %1312, align 8, !tbaa !6
  br label %1314

1314:                                             ; preds = %1238, %1236
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %1237, label %1315, label %1392

1315:                                             ; preds = %1314
  %1316 = load float, float addrspace(3)* %102, align 4, !tbaa !6
  %1317 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 0), align 16, !tbaa !6
  %1318 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 0, i32 %6
  %1319 = load float, float addrspace(3)* %1318, align 4, !tbaa !6
  %1320 = fmul contract float %1317, %1319
  %1321 = fsub contract float %1316, %1320
  store float %1321, float addrspace(3)* %102, align 4, !tbaa !6
  %1322 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 1), align 4, !tbaa !6
  %1323 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 1, i32 %6
  %1324 = load float, float addrspace(3)* %1323, align 4, !tbaa !6
  %1325 = fmul contract float %1322, %1324
  %1326 = fsub contract float %1321, %1325
  store float %1326, float addrspace(3)* %102, align 4, !tbaa !6
  %1327 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 2), align 8, !tbaa !6
  %1328 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 2, i32 %6
  %1329 = load float, float addrspace(3)* %1328, align 4, !tbaa !6
  %1330 = fmul contract float %1327, %1329
  %1331 = fsub contract float %1326, %1330
  store float %1331, float addrspace(3)* %102, align 4, !tbaa !6
  %1332 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 3), align 4, !tbaa !6
  %1333 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 3, i32 %6
  %1334 = load float, float addrspace(3)* %1333, align 4, !tbaa !6
  %1335 = fmul contract float %1332, %1334
  %1336 = fsub contract float %1331, %1335
  store float %1336, float addrspace(3)* %102, align 4, !tbaa !6
  %1337 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 4), align 16, !tbaa !6
  %1338 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 4, i32 %6
  %1339 = load float, float addrspace(3)* %1338, align 4, !tbaa !6
  %1340 = fmul contract float %1337, %1339
  %1341 = fsub contract float %1336, %1340
  store float %1341, float addrspace(3)* %102, align 4, !tbaa !6
  %1342 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 5), align 4, !tbaa !6
  %1343 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 5, i32 %6
  %1344 = load float, float addrspace(3)* %1343, align 4, !tbaa !6
  %1345 = fmul contract float %1342, %1344
  %1346 = fsub contract float %1341, %1345
  store float %1346, float addrspace(3)* %102, align 4, !tbaa !6
  %1347 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 6), align 8, !tbaa !6
  %1348 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 6, i32 %6
  %1349 = load float, float addrspace(3)* %1348, align 4, !tbaa !6
  %1350 = fmul contract float %1347, %1349
  %1351 = fsub contract float %1346, %1350
  store float %1351, float addrspace(3)* %102, align 4, !tbaa !6
  %1352 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 7), align 4, !tbaa !6
  %1353 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 7, i32 %6
  %1354 = load float, float addrspace(3)* %1353, align 4, !tbaa !6
  %1355 = fmul contract float %1352, %1354
  %1356 = fsub contract float %1351, %1355
  store float %1356, float addrspace(3)* %102, align 4, !tbaa !6
  %1357 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 8), align 16, !tbaa !6
  %1358 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 8, i32 %6
  %1359 = load float, float addrspace(3)* %1358, align 4, !tbaa !6
  %1360 = fmul contract float %1357, %1359
  %1361 = fsub contract float %1356, %1360
  store float %1361, float addrspace(3)* %102, align 4, !tbaa !6
  %1362 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 9), align 4, !tbaa !6
  %1363 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 9, i32 %6
  %1364 = load float, float addrspace(3)* %1363, align 4, !tbaa !6
  %1365 = fmul contract float %1362, %1364
  %1366 = fsub contract float %1361, %1365
  store float %1366, float addrspace(3)* %102, align 4, !tbaa !6
  %1367 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 10), align 8, !tbaa !6
  %1368 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 10, i32 %6
  %1369 = load float, float addrspace(3)* %1368, align 4, !tbaa !6
  %1370 = fmul contract float %1367, %1369
  %1371 = fsub contract float %1366, %1370
  store float %1371, float addrspace(3)* %102, align 4, !tbaa !6
  %1372 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 11), align 4, !tbaa !6
  %1373 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 11, i32 %6
  %1374 = load float, float addrspace(3)* %1373, align 4, !tbaa !6
  %1375 = fmul contract float %1372, %1374
  %1376 = fsub contract float %1371, %1375
  store float %1376, float addrspace(3)* %102, align 4, !tbaa !6
  %1377 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 12), align 16, !tbaa !6
  %1378 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 12, i32 %6
  %1379 = load float, float addrspace(3)* %1378, align 4, !tbaa !6
  %1380 = fmul contract float %1377, %1379
  %1381 = fsub contract float %1376, %1380
  store float %1381, float addrspace(3)* %102, align 4, !tbaa !6
  %1382 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 13), align 4, !tbaa !6
  %1383 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 13, i32 %6
  %1384 = load float, float addrspace(3)* %1383, align 4, !tbaa !6
  %1385 = fmul contract float %1382, %1384
  %1386 = fsub contract float %1381, %1385
  store float %1386, float addrspace(3)* %102, align 4, !tbaa !6
  %1387 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 15, i32 14), align 8, !tbaa !6
  %1388 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_diagonalPfiiE6shadow, i32 0, i32 14, i32 %6
  %1389 = load float, float addrspace(3)* %1388, align 4, !tbaa !6
  %1390 = fmul contract float %1387, %1389
  %1391 = fsub contract float %1386, %1390
  store float %1391, float addrspace(3)* %102, align 4, !tbaa !6
  br label %1392

1392:                                             ; preds = %1315, %1314
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %1393 = add nsw i32 %2, 1
  %1394 = mul nsw i32 %1393, %1
  %1395 = add nsw i32 %1394, %2
  %1396 = load float, float addrspace(3)* %18, align 4, !tbaa !6
  %1397 = sext i32 %1395 to i64
  %1398 = add nsw i64 %1397, %7
  %1399 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1398
  store float %1396, float addrspace(1)* %1399, align 4, !tbaa !6
  %1400 = add nsw i32 %1395, %1
  %1401 = load float, float addrspace(3)* %24, align 4, !tbaa !6
  %1402 = sext i32 %1400 to i64
  %1403 = add nsw i64 %1402, %7
  %1404 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1403
  store float %1401, float addrspace(1)* %1404, align 4, !tbaa !6
  %1405 = add nsw i32 %1400, %1
  %1406 = load float, float addrspace(3)* %30, align 4, !tbaa !6
  %1407 = sext i32 %1405 to i64
  %1408 = add nsw i64 %1407, %7
  %1409 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1408
  store float %1406, float addrspace(1)* %1409, align 4, !tbaa !6
  %1410 = add nsw i32 %1405, %1
  %1411 = load float, float addrspace(3)* %36, align 4, !tbaa !6
  %1412 = sext i32 %1410 to i64
  %1413 = add nsw i64 %1412, %7
  %1414 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1413
  store float %1411, float addrspace(1)* %1414, align 4, !tbaa !6
  %1415 = add nsw i32 %1410, %1
  %1416 = load float, float addrspace(3)* %42, align 4, !tbaa !6
  %1417 = sext i32 %1415 to i64
  %1418 = add nsw i64 %1417, %7
  %1419 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1418
  store float %1416, float addrspace(1)* %1419, align 4, !tbaa !6
  %1420 = add nsw i32 %1415, %1
  %1421 = load float, float addrspace(3)* %48, align 4, !tbaa !6
  %1422 = sext i32 %1420 to i64
  %1423 = add nsw i64 %1422, %7
  %1424 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1423
  store float %1421, float addrspace(1)* %1424, align 4, !tbaa !6
  %1425 = add nsw i32 %1420, %1
  %1426 = load float, float addrspace(3)* %54, align 4, !tbaa !6
  %1427 = sext i32 %1425 to i64
  %1428 = add nsw i64 %1427, %7
  %1429 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1428
  store float %1426, float addrspace(1)* %1429, align 4, !tbaa !6
  %1430 = add nsw i32 %1425, %1
  %1431 = load float, float addrspace(3)* %60, align 4, !tbaa !6
  %1432 = sext i32 %1430 to i64
  %1433 = add nsw i64 %1432, %7
  %1434 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1433
  store float %1431, float addrspace(1)* %1434, align 4, !tbaa !6
  %1435 = add nsw i32 %1430, %1
  %1436 = load float, float addrspace(3)* %66, align 4, !tbaa !6
  %1437 = sext i32 %1435 to i64
  %1438 = add nsw i64 %1437, %7
  %1439 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1438
  store float %1436, float addrspace(1)* %1439, align 4, !tbaa !6
  %1440 = add nsw i32 %1435, %1
  %1441 = load float, float addrspace(3)* %72, align 4, !tbaa !6
  %1442 = sext i32 %1440 to i64
  %1443 = add nsw i64 %1442, %7
  %1444 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1443
  store float %1441, float addrspace(1)* %1444, align 4, !tbaa !6
  %1445 = add nsw i32 %1440, %1
  %1446 = load float, float addrspace(3)* %78, align 4, !tbaa !6
  %1447 = sext i32 %1445 to i64
  %1448 = add nsw i64 %1447, %7
  %1449 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1448
  store float %1446, float addrspace(1)* %1449, align 4, !tbaa !6
  %1450 = add nsw i32 %1445, %1
  %1451 = load float, float addrspace(3)* %84, align 4, !tbaa !6
  %1452 = sext i32 %1450 to i64
  %1453 = add nsw i64 %1452, %7
  %1454 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1453
  store float %1451, float addrspace(1)* %1454, align 4, !tbaa !6
  %1455 = add nsw i32 %1450, %1
  %1456 = load float, float addrspace(3)* %90, align 4, !tbaa !6
  %1457 = sext i32 %1455 to i64
  %1458 = add nsw i64 %1457, %7
  %1459 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1458
  store float %1456, float addrspace(1)* %1459, align 4, !tbaa !6
  %1460 = add nsw i32 %1455, %1
  %1461 = load float, float addrspace(3)* %96, align 4, !tbaa !6
  %1462 = sext i32 %1460 to i64
  %1463 = add nsw i64 %1462, %7
  %1464 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1463
  store float %1461, float addrspace(1)* %1464, align 4, !tbaa !6
  %1465 = add nsw i32 %1460, %1
  %1466 = load float, float addrspace(3)* %102, align 4, !tbaa !6
  %1467 = sext i32 %1465 to i64
  %1468 = add nsw i64 %1467, %7
  %1469 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1468
  store float %1466, float addrspace(1)* %1469, align 4, !tbaa !6
  ret void
}

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z13lud_perimeterPfii(float addrspace(1)* nocapture %0, i32 %1, i32 %2) local_unnamed_addr #0 {
  %4 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %5 = zext i32 %4 to i64
  %6 = icmp ult i32 %4, 16
  br i1 %6, label %7, label %148

7:                                                ; preds = %3
  %8 = mul nsw i32 %2, %1
  %9 = add nsw i32 %8, %2
  %10 = add nsw i32 %9, %4
  %11 = sext i32 %10 to i64
  %12 = getelementptr inbounds float, float addrspace(1)* %0, i64 %11
  %13 = load float, float addrspace(1)* %12, align 4, !tbaa !6
  %14 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 %4
  store float %13, float addrspace(3)* %14, align 4, !tbaa !6
  %15 = add nsw i32 %9, %1
  %16 = add nsw i32 %15, %4
  %17 = sext i32 %16 to i64
  %18 = getelementptr inbounds float, float addrspace(1)* %0, i64 %17
  %19 = load float, float addrspace(1)* %18, align 4, !tbaa !6
  %20 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 %4
  store float %19, float addrspace(3)* %20, align 4, !tbaa !6
  %21 = add nsw i32 %15, %1
  %22 = add nsw i32 %21, %4
  %23 = sext i32 %22 to i64
  %24 = getelementptr inbounds float, float addrspace(1)* %0, i64 %23
  %25 = load float, float addrspace(1)* %24, align 4, !tbaa !6
  %26 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 %4
  store float %25, float addrspace(3)* %26, align 4, !tbaa !6
  %27 = add nsw i32 %21, %1
  %28 = add nsw i32 %27, %4
  %29 = sext i32 %28 to i64
  %30 = getelementptr inbounds float, float addrspace(1)* %0, i64 %29
  %31 = load float, float addrspace(1)* %30, align 4, !tbaa !6
  %32 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 %4
  store float %31, float addrspace(3)* %32, align 4, !tbaa !6
  %33 = add nsw i32 %27, %1
  %34 = add nsw i32 %33, %4
  %35 = sext i32 %34 to i64
  %36 = getelementptr inbounds float, float addrspace(1)* %0, i64 %35
  %37 = load float, float addrspace(1)* %36, align 4, !tbaa !6
  %38 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 %4
  store float %37, float addrspace(3)* %38, align 4, !tbaa !6
  %39 = add nsw i32 %33, %1
  %40 = add nsw i32 %39, %4
  %41 = sext i32 %40 to i64
  %42 = getelementptr inbounds float, float addrspace(1)* %0, i64 %41
  %43 = load float, float addrspace(1)* %42, align 4, !tbaa !6
  %44 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 %4
  store float %43, float addrspace(3)* %44, align 4, !tbaa !6
  %45 = add nsw i32 %39, %1
  %46 = add nsw i32 %45, %4
  %47 = sext i32 %46 to i64
  %48 = getelementptr inbounds float, float addrspace(1)* %0, i64 %47
  %49 = load float, float addrspace(1)* %48, align 4, !tbaa !6
  %50 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 %4
  store float %49, float addrspace(3)* %50, align 4, !tbaa !6
  %51 = add nsw i32 %45, %1
  %52 = add nsw i32 %51, %4
  %53 = sext i32 %52 to i64
  %54 = getelementptr inbounds float, float addrspace(1)* %0, i64 %53
  %55 = load float, float addrspace(1)* %54, align 4, !tbaa !6
  %56 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 %4
  store float %55, float addrspace(3)* %56, align 4, !tbaa !6
  %57 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %58 = zext i32 %57 to i64
  %59 = shl nuw nsw i64 %58, 4
  %60 = add nuw nsw i64 %5, 16
  %61 = add nuw nsw i64 %60, %59
  %62 = sext i32 %9 to i64
  %63 = add nsw i64 %61, %62
  %64 = getelementptr inbounds float, float addrspace(1)* %0, i64 %63
  %65 = load float, float addrspace(1)* %64, align 4, !tbaa !6
  %66 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  store float %65, float addrspace(3)* %66, align 4, !tbaa !6
  %67 = sext i32 %15 to i64
  %68 = add nsw i64 %61, %67
  %69 = getelementptr inbounds float, float addrspace(1)* %0, i64 %68
  %70 = load float, float addrspace(1)* %69, align 4, !tbaa !6
  %71 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  store float %70, float addrspace(3)* %71, align 4, !tbaa !6
  %72 = sext i32 %21 to i64
  %73 = add nsw i64 %61, %72
  %74 = getelementptr inbounds float, float addrspace(1)* %0, i64 %73
  %75 = load float, float addrspace(1)* %74, align 4, !tbaa !6
  %76 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  store float %75, float addrspace(3)* %76, align 4, !tbaa !6
  %77 = sext i32 %27 to i64
  %78 = add nsw i64 %61, %77
  %79 = getelementptr inbounds float, float addrspace(1)* %0, i64 %78
  %80 = load float, float addrspace(1)* %79, align 4, !tbaa !6
  %81 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  store float %80, float addrspace(3)* %81, align 4, !tbaa !6
  %82 = sext i32 %33 to i64
  %83 = add nsw i64 %61, %82
  %84 = getelementptr inbounds float, float addrspace(1)* %0, i64 %83
  %85 = load float, float addrspace(1)* %84, align 4, !tbaa !6
  %86 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  store float %85, float addrspace(3)* %86, align 4, !tbaa !6
  %87 = sext i32 %39 to i64
  %88 = add nsw i64 %61, %87
  %89 = getelementptr inbounds float, float addrspace(1)* %0, i64 %88
  %90 = load float, float addrspace(1)* %89, align 4, !tbaa !6
  %91 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  store float %90, float addrspace(3)* %91, align 4, !tbaa !6
  %92 = sext i32 %45 to i64
  %93 = add nsw i64 %61, %92
  %94 = getelementptr inbounds float, float addrspace(1)* %0, i64 %93
  %95 = load float, float addrspace(1)* %94, align 4, !tbaa !6
  %96 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  store float %95, float addrspace(3)* %96, align 4, !tbaa !6
  %97 = sext i32 %51 to i64
  %98 = add nsw i64 %61, %97
  %99 = getelementptr inbounds float, float addrspace(1)* %0, i64 %98
  %100 = load float, float addrspace(1)* %99, align 4, !tbaa !6
  %101 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  store float %100, float addrspace(3)* %101, align 4, !tbaa !6
  %102 = add nsw i32 %51, %1
  %103 = sext i32 %102 to i64
  %104 = add nsw i64 %61, %103
  %105 = getelementptr inbounds float, float addrspace(1)* %0, i64 %104
  %106 = load float, float addrspace(1)* %105, align 4, !tbaa !6
  %107 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  store float %106, float addrspace(3)* %107, align 4, !tbaa !6
  %108 = add nsw i32 %102, %1
  %109 = sext i32 %108 to i64
  %110 = add nsw i64 %61, %109
  %111 = getelementptr inbounds float, float addrspace(1)* %0, i64 %110
  %112 = load float, float addrspace(1)* %111, align 4, !tbaa !6
  %113 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  store float %112, float addrspace(3)* %113, align 4, !tbaa !6
  %114 = add nsw i32 %108, %1
  %115 = sext i32 %114 to i64
  %116 = add nsw i64 %61, %115
  %117 = getelementptr inbounds float, float addrspace(1)* %0, i64 %116
  %118 = load float, float addrspace(1)* %117, align 4, !tbaa !6
  %119 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  store float %118, float addrspace(3)* %119, align 4, !tbaa !6
  %120 = add nsw i32 %114, %1
  %121 = sext i32 %120 to i64
  %122 = add nsw i64 %61, %121
  %123 = getelementptr inbounds float, float addrspace(1)* %0, i64 %122
  %124 = load float, float addrspace(1)* %123, align 4, !tbaa !6
  %125 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  store float %124, float addrspace(3)* %125, align 4, !tbaa !6
  %126 = add nsw i32 %120, %1
  %127 = sext i32 %126 to i64
  %128 = add nsw i64 %61, %127
  %129 = getelementptr inbounds float, float addrspace(1)* %0, i64 %128
  %130 = load float, float addrspace(1)* %129, align 4, !tbaa !6
  %131 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  store float %130, float addrspace(3)* %131, align 4, !tbaa !6
  %132 = add nsw i32 %126, %1
  %133 = sext i32 %132 to i64
  %134 = add nsw i64 %61, %133
  %135 = getelementptr inbounds float, float addrspace(1)* %0, i64 %134
  %136 = load float, float addrspace(1)* %135, align 4, !tbaa !6
  %137 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  store float %136, float addrspace(3)* %137, align 4, !tbaa !6
  %138 = add nsw i32 %132, %1
  %139 = sext i32 %138 to i64
  %140 = add nsw i64 %61, %139
  %141 = getelementptr inbounds float, float addrspace(1)* %0, i64 %140
  %142 = load float, float addrspace(1)* %141, align 4, !tbaa !6
  %143 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  store float %142, float addrspace(3)* %143, align 4, !tbaa !6
  %144 = add nsw i32 %138, %1
  %145 = sext i32 %144 to i64
  %146 = add nsw i64 %61, %145
  %147 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  br label %299

148:                                              ; preds = %3
  %149 = add nsw i32 %4, -16
  %150 = add nsw i32 %2, 8
  %151 = mul nsw i32 %150, %1
  %152 = add nsw i32 %151, %2
  %153 = add nsw i32 %152, %149
  %154 = sext i32 %153 to i64
  %155 = getelementptr inbounds float, float addrspace(1)* %0, i64 %154
  %156 = load float, float addrspace(1)* %155, align 4, !tbaa !6
  %157 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 %149
  store float %156, float addrspace(3)* %157, align 4, !tbaa !6
  %158 = add nsw i32 %152, %1
  %159 = add nsw i32 %158, %149
  %160 = sext i32 %159 to i64
  %161 = getelementptr inbounds float, float addrspace(1)* %0, i64 %160
  %162 = load float, float addrspace(1)* %161, align 4, !tbaa !6
  %163 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 %149
  store float %162, float addrspace(3)* %163, align 4, !tbaa !6
  %164 = add nsw i32 %158, %1
  %165 = add nsw i32 %164, %149
  %166 = sext i32 %165 to i64
  %167 = getelementptr inbounds float, float addrspace(1)* %0, i64 %166
  %168 = load float, float addrspace(1)* %167, align 4, !tbaa !6
  %169 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 %149
  store float %168, float addrspace(3)* %169, align 4, !tbaa !6
  %170 = add nsw i32 %164, %1
  %171 = add nsw i32 %170, %149
  %172 = sext i32 %171 to i64
  %173 = getelementptr inbounds float, float addrspace(1)* %0, i64 %172
  %174 = load float, float addrspace(1)* %173, align 4, !tbaa !6
  %175 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 %149
  store float %174, float addrspace(3)* %175, align 4, !tbaa !6
  %176 = add nsw i32 %170, %1
  %177 = add nsw i32 %176, %149
  %178 = sext i32 %177 to i64
  %179 = getelementptr inbounds float, float addrspace(1)* %0, i64 %178
  %180 = load float, float addrspace(1)* %179, align 4, !tbaa !6
  %181 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 %149
  store float %180, float addrspace(3)* %181, align 4, !tbaa !6
  %182 = add nsw i32 %176, %1
  %183 = add nsw i32 %182, %149
  %184 = sext i32 %183 to i64
  %185 = getelementptr inbounds float, float addrspace(1)* %0, i64 %184
  %186 = load float, float addrspace(1)* %185, align 4, !tbaa !6
  %187 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 %149
  store float %186, float addrspace(3)* %187, align 4, !tbaa !6
  %188 = add nsw i32 %182, %1
  %189 = add nsw i32 %188, %149
  %190 = sext i32 %189 to i64
  %191 = getelementptr inbounds float, float addrspace(1)* %0, i64 %190
  %192 = load float, float addrspace(1)* %191, align 4, !tbaa !6
  %193 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 %149
  store float %192, float addrspace(3)* %193, align 4, !tbaa !6
  %194 = add nsw i32 %188, %1
  %195 = add nsw i32 %194, %149
  %196 = sext i32 %195 to i64
  %197 = getelementptr inbounds float, float addrspace(1)* %0, i64 %196
  %198 = load float, float addrspace(1)* %197, align 4, !tbaa !6
  %199 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 %149
  store float %198, float addrspace(3)* %199, align 4, !tbaa !6
  %200 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %201 = shl i32 %200, 4
  %202 = add i32 %2, 16
  %203 = add i32 %202, %201
  %204 = mul i32 %203, %1
  %205 = add i32 %204, %2
  %206 = add nsw i32 %205, %149
  %207 = sext i32 %206 to i64
  %208 = getelementptr inbounds float, float addrspace(1)* %0, i64 %207
  %209 = load float, float addrspace(1)* %208, align 4, !tbaa !6
  %210 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 0, i32 %149
  store float %209, float addrspace(3)* %210, align 4, !tbaa !6
  %211 = add nsw i32 %205, %1
  %212 = add nsw i32 %211, %149
  %213 = sext i32 %212 to i64
  %214 = getelementptr inbounds float, float addrspace(1)* %0, i64 %213
  %215 = load float, float addrspace(1)* %214, align 4, !tbaa !6
  %216 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 1, i32 %149
  store float %215, float addrspace(3)* %216, align 4, !tbaa !6
  %217 = add nsw i32 %211, %1
  %218 = add nsw i32 %217, %149
  %219 = sext i32 %218 to i64
  %220 = getelementptr inbounds float, float addrspace(1)* %0, i64 %219
  %221 = load float, float addrspace(1)* %220, align 4, !tbaa !6
  %222 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 2, i32 %149
  store float %221, float addrspace(3)* %222, align 4, !tbaa !6
  %223 = add nsw i32 %217, %1
  %224 = add nsw i32 %223, %149
  %225 = sext i32 %224 to i64
  %226 = getelementptr inbounds float, float addrspace(1)* %0, i64 %225
  %227 = load float, float addrspace(1)* %226, align 4, !tbaa !6
  %228 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 3, i32 %149
  store float %227, float addrspace(3)* %228, align 4, !tbaa !6
  %229 = add nsw i32 %223, %1
  %230 = add nsw i32 %229, %149
  %231 = sext i32 %230 to i64
  %232 = getelementptr inbounds float, float addrspace(1)* %0, i64 %231
  %233 = load float, float addrspace(1)* %232, align 4, !tbaa !6
  %234 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 4, i32 %149
  store float %233, float addrspace(3)* %234, align 4, !tbaa !6
  %235 = add nsw i32 %229, %1
  %236 = add nsw i32 %235, %149
  %237 = sext i32 %236 to i64
  %238 = getelementptr inbounds float, float addrspace(1)* %0, i64 %237
  %239 = load float, float addrspace(1)* %238, align 4, !tbaa !6
  %240 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 5, i32 %149
  store float %239, float addrspace(3)* %240, align 4, !tbaa !6
  %241 = add nsw i32 %235, %1
  %242 = add nsw i32 %241, %149
  %243 = sext i32 %242 to i64
  %244 = getelementptr inbounds float, float addrspace(1)* %0, i64 %243
  %245 = load float, float addrspace(1)* %244, align 4, !tbaa !6
  %246 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 6, i32 %149
  store float %245, float addrspace(3)* %246, align 4, !tbaa !6
  %247 = add nsw i32 %241, %1
  %248 = add nsw i32 %247, %149
  %249 = sext i32 %248 to i64
  %250 = getelementptr inbounds float, float addrspace(1)* %0, i64 %249
  %251 = load float, float addrspace(1)* %250, align 4, !tbaa !6
  %252 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 7, i32 %149
  store float %251, float addrspace(3)* %252, align 4, !tbaa !6
  %253 = add nsw i32 %247, %1
  %254 = add nsw i32 %253, %149
  %255 = sext i32 %254 to i64
  %256 = getelementptr inbounds float, float addrspace(1)* %0, i64 %255
  %257 = load float, float addrspace(1)* %256, align 4, !tbaa !6
  %258 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 8, i32 %149
  store float %257, float addrspace(3)* %258, align 4, !tbaa !6
  %259 = add nsw i32 %253, %1
  %260 = add nsw i32 %259, %149
  %261 = sext i32 %260 to i64
  %262 = getelementptr inbounds float, float addrspace(1)* %0, i64 %261
  %263 = load float, float addrspace(1)* %262, align 4, !tbaa !6
  %264 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 9, i32 %149
  store float %263, float addrspace(3)* %264, align 4, !tbaa !6
  %265 = add nsw i32 %259, %1
  %266 = add nsw i32 %265, %149
  %267 = sext i32 %266 to i64
  %268 = getelementptr inbounds float, float addrspace(1)* %0, i64 %267
  %269 = load float, float addrspace(1)* %268, align 4, !tbaa !6
  %270 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 10, i32 %149
  store float %269, float addrspace(3)* %270, align 4, !tbaa !6
  %271 = add nsw i32 %265, %1
  %272 = add nsw i32 %271, %149
  %273 = sext i32 %272 to i64
  %274 = getelementptr inbounds float, float addrspace(1)* %0, i64 %273
  %275 = load float, float addrspace(1)* %274, align 4, !tbaa !6
  %276 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 11, i32 %149
  store float %275, float addrspace(3)* %276, align 4, !tbaa !6
  %277 = add nsw i32 %271, %1
  %278 = add nsw i32 %277, %149
  %279 = sext i32 %278 to i64
  %280 = getelementptr inbounds float, float addrspace(1)* %0, i64 %279
  %281 = load float, float addrspace(1)* %280, align 4, !tbaa !6
  %282 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 12, i32 %149
  store float %281, float addrspace(3)* %282, align 4, !tbaa !6
  %283 = add nsw i32 %277, %1
  %284 = add nsw i32 %283, %149
  %285 = sext i32 %284 to i64
  %286 = getelementptr inbounds float, float addrspace(1)* %0, i64 %285
  %287 = load float, float addrspace(1)* %286, align 4, !tbaa !6
  %288 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 13, i32 %149
  store float %287, float addrspace(3)* %288, align 4, !tbaa !6
  %289 = add nsw i32 %283, %1
  %290 = add nsw i32 %289, %149
  %291 = sext i32 %290 to i64
  %292 = getelementptr inbounds float, float addrspace(1)* %0, i64 %291
  %293 = load float, float addrspace(1)* %292, align 4, !tbaa !6
  %294 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 14, i32 %149
  store float %293, float addrspace(3)* %294, align 4, !tbaa !6
  %295 = add nsw i32 %289, %1
  %296 = add nsw i32 %295, %149
  %297 = sext i32 %296 to i64
  %298 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 15, i32 %149
  br label %299

299:                                              ; preds = %148, %7
  %300 = phi float addrspace(3)* [ %298, %148 ], [ %147, %7 ]
  %301 = phi i64 [ %297, %148 ], [ %146, %7 ]
  %302 = getelementptr inbounds float, float addrspace(1)* %0, i64 %301
  %303 = load float, float addrspace(1)* %302, align 4, !tbaa !6
  store float %303, float addrspace(3)* %300, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %6, label %304, label %935

304:                                              ; preds = %299
  %305 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %306 = load float, float addrspace(3)* %305, align 4, !tbaa !6
  %307 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 0), align 16, !tbaa !6
  %308 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %309 = load float, float addrspace(3)* %308, align 4, !tbaa !6
  %310 = fmul contract float %307, %309
  %311 = fsub contract float %306, %310
  store float %311, float addrspace(3)* %305, align 4, !tbaa !6
  %312 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %313 = load float, float addrspace(3)* %312, align 4, !tbaa !6
  %314 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 0), align 16, !tbaa !6
  %315 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %316 = load float, float addrspace(3)* %315, align 4, !tbaa !6
  %317 = fmul contract float %314, %316
  %318 = fsub contract float %313, %317
  store float %318, float addrspace(3)* %312, align 4, !tbaa !6
  %319 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 1), align 4, !tbaa !6
  %320 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %321 = load float, float addrspace(3)* %320, align 4, !tbaa !6
  %322 = fmul contract float %319, %321
  %323 = fsub contract float %318, %322
  store float %323, float addrspace(3)* %312, align 4, !tbaa !6
  %324 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %325 = load float, float addrspace(3)* %324, align 4, !tbaa !6
  %326 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 0), align 16, !tbaa !6
  %327 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %328 = load float, float addrspace(3)* %327, align 4, !tbaa !6
  %329 = fmul contract float %326, %328
  %330 = fsub contract float %325, %329
  store float %330, float addrspace(3)* %324, align 4, !tbaa !6
  %331 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 1), align 4, !tbaa !6
  %332 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %333 = load float, float addrspace(3)* %332, align 4, !tbaa !6
  %334 = fmul contract float %331, %333
  %335 = fsub contract float %330, %334
  store float %335, float addrspace(3)* %324, align 4, !tbaa !6
  %336 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 2), align 8, !tbaa !6
  %337 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %338 = load float, float addrspace(3)* %337, align 4, !tbaa !6
  %339 = fmul contract float %336, %338
  %340 = fsub contract float %335, %339
  store float %340, float addrspace(3)* %324, align 4, !tbaa !6
  %341 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %342 = load float, float addrspace(3)* %341, align 4, !tbaa !6
  %343 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 0), align 16, !tbaa !6
  %344 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %345 = load float, float addrspace(3)* %344, align 4, !tbaa !6
  %346 = fmul contract float %343, %345
  %347 = fsub contract float %342, %346
  store float %347, float addrspace(3)* %341, align 4, !tbaa !6
  %348 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 1), align 4, !tbaa !6
  %349 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %350 = load float, float addrspace(3)* %349, align 4, !tbaa !6
  %351 = fmul contract float %348, %350
  %352 = fsub contract float %347, %351
  store float %352, float addrspace(3)* %341, align 4, !tbaa !6
  %353 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 2), align 8, !tbaa !6
  %354 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %355 = load float, float addrspace(3)* %354, align 4, !tbaa !6
  %356 = fmul contract float %353, %355
  %357 = fsub contract float %352, %356
  store float %357, float addrspace(3)* %341, align 4, !tbaa !6
  %358 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 3), align 4, !tbaa !6
  %359 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %360 = load float, float addrspace(3)* %359, align 4, !tbaa !6
  %361 = fmul contract float %358, %360
  %362 = fsub contract float %357, %361
  store float %362, float addrspace(3)* %341, align 4, !tbaa !6
  %363 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %364 = load float, float addrspace(3)* %363, align 4, !tbaa !6
  %365 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 0), align 16, !tbaa !6
  %366 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %367 = load float, float addrspace(3)* %366, align 4, !tbaa !6
  %368 = fmul contract float %365, %367
  %369 = fsub contract float %364, %368
  store float %369, float addrspace(3)* %363, align 4, !tbaa !6
  %370 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 1), align 4, !tbaa !6
  %371 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %372 = load float, float addrspace(3)* %371, align 4, !tbaa !6
  %373 = fmul contract float %370, %372
  %374 = fsub contract float %369, %373
  store float %374, float addrspace(3)* %363, align 4, !tbaa !6
  %375 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 2), align 8, !tbaa !6
  %376 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %377 = load float, float addrspace(3)* %376, align 4, !tbaa !6
  %378 = fmul contract float %375, %377
  %379 = fsub contract float %374, %378
  store float %379, float addrspace(3)* %363, align 4, !tbaa !6
  %380 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 3), align 4, !tbaa !6
  %381 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %382 = load float, float addrspace(3)* %381, align 4, !tbaa !6
  %383 = fmul contract float %380, %382
  %384 = fsub contract float %379, %383
  store float %384, float addrspace(3)* %363, align 4, !tbaa !6
  %385 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 4), align 16, !tbaa !6
  %386 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %387 = load float, float addrspace(3)* %386, align 4, !tbaa !6
  %388 = fmul contract float %385, %387
  %389 = fsub contract float %384, %388
  store float %389, float addrspace(3)* %363, align 4, !tbaa !6
  %390 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %391 = load float, float addrspace(3)* %390, align 4, !tbaa !6
  %392 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 0), align 16, !tbaa !6
  %393 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %394 = load float, float addrspace(3)* %393, align 4, !tbaa !6
  %395 = fmul contract float %392, %394
  %396 = fsub contract float %391, %395
  store float %396, float addrspace(3)* %390, align 4, !tbaa !6
  %397 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 1), align 4, !tbaa !6
  %398 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %399 = load float, float addrspace(3)* %398, align 4, !tbaa !6
  %400 = fmul contract float %397, %399
  %401 = fsub contract float %396, %400
  store float %401, float addrspace(3)* %390, align 4, !tbaa !6
  %402 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 2), align 8, !tbaa !6
  %403 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %404 = load float, float addrspace(3)* %403, align 4, !tbaa !6
  %405 = fmul contract float %402, %404
  %406 = fsub contract float %401, %405
  store float %406, float addrspace(3)* %390, align 4, !tbaa !6
  %407 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 3), align 4, !tbaa !6
  %408 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %409 = load float, float addrspace(3)* %408, align 4, !tbaa !6
  %410 = fmul contract float %407, %409
  %411 = fsub contract float %406, %410
  store float %411, float addrspace(3)* %390, align 4, !tbaa !6
  %412 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 4), align 16, !tbaa !6
  %413 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %414 = load float, float addrspace(3)* %413, align 4, !tbaa !6
  %415 = fmul contract float %412, %414
  %416 = fsub contract float %411, %415
  store float %416, float addrspace(3)* %390, align 4, !tbaa !6
  %417 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 5), align 4, !tbaa !6
  %418 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %419 = load float, float addrspace(3)* %418, align 4, !tbaa !6
  %420 = fmul contract float %417, %419
  %421 = fsub contract float %416, %420
  store float %421, float addrspace(3)* %390, align 4, !tbaa !6
  %422 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %423 = load float, float addrspace(3)* %422, align 4, !tbaa !6
  %424 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 0), align 16, !tbaa !6
  %425 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %426 = load float, float addrspace(3)* %425, align 4, !tbaa !6
  %427 = fmul contract float %424, %426
  %428 = fsub contract float %423, %427
  store float %428, float addrspace(3)* %422, align 4, !tbaa !6
  %429 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 1), align 4, !tbaa !6
  %430 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %431 = load float, float addrspace(3)* %430, align 4, !tbaa !6
  %432 = fmul contract float %429, %431
  %433 = fsub contract float %428, %432
  store float %433, float addrspace(3)* %422, align 4, !tbaa !6
  %434 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 2), align 8, !tbaa !6
  %435 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %436 = load float, float addrspace(3)* %435, align 4, !tbaa !6
  %437 = fmul contract float %434, %436
  %438 = fsub contract float %433, %437
  store float %438, float addrspace(3)* %422, align 4, !tbaa !6
  %439 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 3), align 4, !tbaa !6
  %440 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %441 = load float, float addrspace(3)* %440, align 4, !tbaa !6
  %442 = fmul contract float %439, %441
  %443 = fsub contract float %438, %442
  store float %443, float addrspace(3)* %422, align 4, !tbaa !6
  %444 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 4), align 16, !tbaa !6
  %445 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %446 = load float, float addrspace(3)* %445, align 4, !tbaa !6
  %447 = fmul contract float %444, %446
  %448 = fsub contract float %443, %447
  store float %448, float addrspace(3)* %422, align 4, !tbaa !6
  %449 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 5), align 4, !tbaa !6
  %450 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %451 = load float, float addrspace(3)* %450, align 4, !tbaa !6
  %452 = fmul contract float %449, %451
  %453 = fsub contract float %448, %452
  store float %453, float addrspace(3)* %422, align 4, !tbaa !6
  %454 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 6), align 8, !tbaa !6
  %455 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %456 = load float, float addrspace(3)* %455, align 4, !tbaa !6
  %457 = fmul contract float %454, %456
  %458 = fsub contract float %453, %457
  store float %458, float addrspace(3)* %422, align 4, !tbaa !6
  %459 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %460 = load float, float addrspace(3)* %459, align 4, !tbaa !6
  %461 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 0), align 16, !tbaa !6
  %462 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %463 = load float, float addrspace(3)* %462, align 4, !tbaa !6
  %464 = fmul contract float %461, %463
  %465 = fsub contract float %460, %464
  store float %465, float addrspace(3)* %459, align 4, !tbaa !6
  %466 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 1), align 4, !tbaa !6
  %467 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %468 = load float, float addrspace(3)* %467, align 4, !tbaa !6
  %469 = fmul contract float %466, %468
  %470 = fsub contract float %465, %469
  store float %470, float addrspace(3)* %459, align 4, !tbaa !6
  %471 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 2), align 8, !tbaa !6
  %472 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %473 = load float, float addrspace(3)* %472, align 4, !tbaa !6
  %474 = fmul contract float %471, %473
  %475 = fsub contract float %470, %474
  store float %475, float addrspace(3)* %459, align 4, !tbaa !6
  %476 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 3), align 4, !tbaa !6
  %477 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %478 = load float, float addrspace(3)* %477, align 4, !tbaa !6
  %479 = fmul contract float %476, %478
  %480 = fsub contract float %475, %479
  store float %480, float addrspace(3)* %459, align 4, !tbaa !6
  %481 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 4), align 16, !tbaa !6
  %482 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %483 = load float, float addrspace(3)* %482, align 4, !tbaa !6
  %484 = fmul contract float %481, %483
  %485 = fsub contract float %480, %484
  store float %485, float addrspace(3)* %459, align 4, !tbaa !6
  %486 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 5), align 4, !tbaa !6
  %487 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %488 = load float, float addrspace(3)* %487, align 4, !tbaa !6
  %489 = fmul contract float %486, %488
  %490 = fsub contract float %485, %489
  store float %490, float addrspace(3)* %459, align 4, !tbaa !6
  %491 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 6), align 8, !tbaa !6
  %492 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %493 = load float, float addrspace(3)* %492, align 4, !tbaa !6
  %494 = fmul contract float %491, %493
  %495 = fsub contract float %490, %494
  store float %495, float addrspace(3)* %459, align 4, !tbaa !6
  %496 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 7), align 4, !tbaa !6
  %497 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %498 = load float, float addrspace(3)* %497, align 4, !tbaa !6
  %499 = fmul contract float %496, %498
  %500 = fsub contract float %495, %499
  store float %500, float addrspace(3)* %459, align 4, !tbaa !6
  %501 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %502 = load float, float addrspace(3)* %501, align 4, !tbaa !6
  %503 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 0), align 16, !tbaa !6
  %504 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %505 = load float, float addrspace(3)* %504, align 4, !tbaa !6
  %506 = fmul contract float %503, %505
  %507 = fsub contract float %502, %506
  store float %507, float addrspace(3)* %501, align 4, !tbaa !6
  %508 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 1), align 4, !tbaa !6
  %509 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %510 = load float, float addrspace(3)* %509, align 4, !tbaa !6
  %511 = fmul contract float %508, %510
  %512 = fsub contract float %507, %511
  store float %512, float addrspace(3)* %501, align 4, !tbaa !6
  %513 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 2), align 8, !tbaa !6
  %514 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %515 = load float, float addrspace(3)* %514, align 4, !tbaa !6
  %516 = fmul contract float %513, %515
  %517 = fsub contract float %512, %516
  store float %517, float addrspace(3)* %501, align 4, !tbaa !6
  %518 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 3), align 4, !tbaa !6
  %519 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %520 = load float, float addrspace(3)* %519, align 4, !tbaa !6
  %521 = fmul contract float %518, %520
  %522 = fsub contract float %517, %521
  store float %522, float addrspace(3)* %501, align 4, !tbaa !6
  %523 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 4), align 16, !tbaa !6
  %524 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %525 = load float, float addrspace(3)* %524, align 4, !tbaa !6
  %526 = fmul contract float %523, %525
  %527 = fsub contract float %522, %526
  store float %527, float addrspace(3)* %501, align 4, !tbaa !6
  %528 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 5), align 4, !tbaa !6
  %529 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %530 = load float, float addrspace(3)* %529, align 4, !tbaa !6
  %531 = fmul contract float %528, %530
  %532 = fsub contract float %527, %531
  store float %532, float addrspace(3)* %501, align 4, !tbaa !6
  %533 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 6), align 8, !tbaa !6
  %534 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %535 = load float, float addrspace(3)* %534, align 4, !tbaa !6
  %536 = fmul contract float %533, %535
  %537 = fsub contract float %532, %536
  store float %537, float addrspace(3)* %501, align 4, !tbaa !6
  %538 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 7), align 4, !tbaa !6
  %539 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %540 = load float, float addrspace(3)* %539, align 4, !tbaa !6
  %541 = fmul contract float %538, %540
  %542 = fsub contract float %537, %541
  store float %542, float addrspace(3)* %501, align 4, !tbaa !6
  %543 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 8), align 16, !tbaa !6
  %544 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %545 = load float, float addrspace(3)* %544, align 4, !tbaa !6
  %546 = fmul contract float %543, %545
  %547 = fsub contract float %542, %546
  store float %547, float addrspace(3)* %501, align 4, !tbaa !6
  %548 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %549 = load float, float addrspace(3)* %548, align 4, !tbaa !6
  %550 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 0), align 16, !tbaa !6
  %551 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %552 = load float, float addrspace(3)* %551, align 4, !tbaa !6
  %553 = fmul contract float %550, %552
  %554 = fsub contract float %549, %553
  store float %554, float addrspace(3)* %548, align 4, !tbaa !6
  %555 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 1), align 4, !tbaa !6
  %556 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %557 = load float, float addrspace(3)* %556, align 4, !tbaa !6
  %558 = fmul contract float %555, %557
  %559 = fsub contract float %554, %558
  store float %559, float addrspace(3)* %548, align 4, !tbaa !6
  %560 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 2), align 8, !tbaa !6
  %561 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %562 = load float, float addrspace(3)* %561, align 4, !tbaa !6
  %563 = fmul contract float %560, %562
  %564 = fsub contract float %559, %563
  store float %564, float addrspace(3)* %548, align 4, !tbaa !6
  %565 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 3), align 4, !tbaa !6
  %566 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %567 = load float, float addrspace(3)* %566, align 4, !tbaa !6
  %568 = fmul contract float %565, %567
  %569 = fsub contract float %564, %568
  store float %569, float addrspace(3)* %548, align 4, !tbaa !6
  %570 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 4), align 16, !tbaa !6
  %571 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %572 = load float, float addrspace(3)* %571, align 4, !tbaa !6
  %573 = fmul contract float %570, %572
  %574 = fsub contract float %569, %573
  store float %574, float addrspace(3)* %548, align 4, !tbaa !6
  %575 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 5), align 4, !tbaa !6
  %576 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %577 = load float, float addrspace(3)* %576, align 4, !tbaa !6
  %578 = fmul contract float %575, %577
  %579 = fsub contract float %574, %578
  store float %579, float addrspace(3)* %548, align 4, !tbaa !6
  %580 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 6), align 8, !tbaa !6
  %581 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %582 = load float, float addrspace(3)* %581, align 4, !tbaa !6
  %583 = fmul contract float %580, %582
  %584 = fsub contract float %579, %583
  store float %584, float addrspace(3)* %548, align 4, !tbaa !6
  %585 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 7), align 4, !tbaa !6
  %586 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %587 = load float, float addrspace(3)* %586, align 4, !tbaa !6
  %588 = fmul contract float %585, %587
  %589 = fsub contract float %584, %588
  store float %589, float addrspace(3)* %548, align 4, !tbaa !6
  %590 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 8), align 16, !tbaa !6
  %591 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %592 = load float, float addrspace(3)* %591, align 4, !tbaa !6
  %593 = fmul contract float %590, %592
  %594 = fsub contract float %589, %593
  store float %594, float addrspace(3)* %548, align 4, !tbaa !6
  %595 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 9), align 4, !tbaa !6
  %596 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %597 = load float, float addrspace(3)* %596, align 4, !tbaa !6
  %598 = fmul contract float %595, %597
  %599 = fsub contract float %594, %598
  store float %599, float addrspace(3)* %548, align 4, !tbaa !6
  %600 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %601 = load float, float addrspace(3)* %600, align 4, !tbaa !6
  %602 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 0), align 16, !tbaa !6
  %603 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %604 = load float, float addrspace(3)* %603, align 4, !tbaa !6
  %605 = fmul contract float %602, %604
  %606 = fsub contract float %601, %605
  store float %606, float addrspace(3)* %600, align 4, !tbaa !6
  %607 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 1), align 4, !tbaa !6
  %608 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %609 = load float, float addrspace(3)* %608, align 4, !tbaa !6
  %610 = fmul contract float %607, %609
  %611 = fsub contract float %606, %610
  store float %611, float addrspace(3)* %600, align 4, !tbaa !6
  %612 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 2), align 8, !tbaa !6
  %613 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %614 = load float, float addrspace(3)* %613, align 4, !tbaa !6
  %615 = fmul contract float %612, %614
  %616 = fsub contract float %611, %615
  store float %616, float addrspace(3)* %600, align 4, !tbaa !6
  %617 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 3), align 4, !tbaa !6
  %618 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %619 = load float, float addrspace(3)* %618, align 4, !tbaa !6
  %620 = fmul contract float %617, %619
  %621 = fsub contract float %616, %620
  store float %621, float addrspace(3)* %600, align 4, !tbaa !6
  %622 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 4), align 16, !tbaa !6
  %623 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %624 = load float, float addrspace(3)* %623, align 4, !tbaa !6
  %625 = fmul contract float %622, %624
  %626 = fsub contract float %621, %625
  store float %626, float addrspace(3)* %600, align 4, !tbaa !6
  %627 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 5), align 4, !tbaa !6
  %628 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %629 = load float, float addrspace(3)* %628, align 4, !tbaa !6
  %630 = fmul contract float %627, %629
  %631 = fsub contract float %626, %630
  store float %631, float addrspace(3)* %600, align 4, !tbaa !6
  %632 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 6), align 8, !tbaa !6
  %633 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %634 = load float, float addrspace(3)* %633, align 4, !tbaa !6
  %635 = fmul contract float %632, %634
  %636 = fsub contract float %631, %635
  store float %636, float addrspace(3)* %600, align 4, !tbaa !6
  %637 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 7), align 4, !tbaa !6
  %638 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %639 = load float, float addrspace(3)* %638, align 4, !tbaa !6
  %640 = fmul contract float %637, %639
  %641 = fsub contract float %636, %640
  store float %641, float addrspace(3)* %600, align 4, !tbaa !6
  %642 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 8), align 16, !tbaa !6
  %643 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %644 = load float, float addrspace(3)* %643, align 4, !tbaa !6
  %645 = fmul contract float %642, %644
  %646 = fsub contract float %641, %645
  store float %646, float addrspace(3)* %600, align 4, !tbaa !6
  %647 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 9), align 4, !tbaa !6
  %648 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %649 = load float, float addrspace(3)* %648, align 4, !tbaa !6
  %650 = fmul contract float %647, %649
  %651 = fsub contract float %646, %650
  store float %651, float addrspace(3)* %600, align 4, !tbaa !6
  %652 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 10), align 8, !tbaa !6
  %653 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %654 = load float, float addrspace(3)* %653, align 4, !tbaa !6
  %655 = fmul contract float %652, %654
  %656 = fsub contract float %651, %655
  store float %656, float addrspace(3)* %600, align 4, !tbaa !6
  %657 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %658 = load float, float addrspace(3)* %657, align 4, !tbaa !6
  %659 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 0), align 16, !tbaa !6
  %660 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %661 = load float, float addrspace(3)* %660, align 4, !tbaa !6
  %662 = fmul contract float %659, %661
  %663 = fsub contract float %658, %662
  store float %663, float addrspace(3)* %657, align 4, !tbaa !6
  %664 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 1), align 4, !tbaa !6
  %665 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %666 = load float, float addrspace(3)* %665, align 4, !tbaa !6
  %667 = fmul contract float %664, %666
  %668 = fsub contract float %663, %667
  store float %668, float addrspace(3)* %657, align 4, !tbaa !6
  %669 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 2), align 8, !tbaa !6
  %670 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %671 = load float, float addrspace(3)* %670, align 4, !tbaa !6
  %672 = fmul contract float %669, %671
  %673 = fsub contract float %668, %672
  store float %673, float addrspace(3)* %657, align 4, !tbaa !6
  %674 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 3), align 4, !tbaa !6
  %675 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %676 = load float, float addrspace(3)* %675, align 4, !tbaa !6
  %677 = fmul contract float %674, %676
  %678 = fsub contract float %673, %677
  store float %678, float addrspace(3)* %657, align 4, !tbaa !6
  %679 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 4), align 16, !tbaa !6
  %680 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %681 = load float, float addrspace(3)* %680, align 4, !tbaa !6
  %682 = fmul contract float %679, %681
  %683 = fsub contract float %678, %682
  store float %683, float addrspace(3)* %657, align 4, !tbaa !6
  %684 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 5), align 4, !tbaa !6
  %685 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %686 = load float, float addrspace(3)* %685, align 4, !tbaa !6
  %687 = fmul contract float %684, %686
  %688 = fsub contract float %683, %687
  store float %688, float addrspace(3)* %657, align 4, !tbaa !6
  %689 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 6), align 8, !tbaa !6
  %690 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %691 = load float, float addrspace(3)* %690, align 4, !tbaa !6
  %692 = fmul contract float %689, %691
  %693 = fsub contract float %688, %692
  store float %693, float addrspace(3)* %657, align 4, !tbaa !6
  %694 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 7), align 4, !tbaa !6
  %695 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %696 = load float, float addrspace(3)* %695, align 4, !tbaa !6
  %697 = fmul contract float %694, %696
  %698 = fsub contract float %693, %697
  store float %698, float addrspace(3)* %657, align 4, !tbaa !6
  %699 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 8), align 16, !tbaa !6
  %700 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %701 = load float, float addrspace(3)* %700, align 4, !tbaa !6
  %702 = fmul contract float %699, %701
  %703 = fsub contract float %698, %702
  store float %703, float addrspace(3)* %657, align 4, !tbaa !6
  %704 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 9), align 4, !tbaa !6
  %705 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %706 = load float, float addrspace(3)* %705, align 4, !tbaa !6
  %707 = fmul contract float %704, %706
  %708 = fsub contract float %703, %707
  store float %708, float addrspace(3)* %657, align 4, !tbaa !6
  %709 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 10), align 8, !tbaa !6
  %710 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %711 = load float, float addrspace(3)* %710, align 4, !tbaa !6
  %712 = fmul contract float %709, %711
  %713 = fsub contract float %708, %712
  store float %713, float addrspace(3)* %657, align 4, !tbaa !6
  %714 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 11), align 4, !tbaa !6
  %715 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %716 = load float, float addrspace(3)* %715, align 4, !tbaa !6
  %717 = fmul contract float %714, %716
  %718 = fsub contract float %713, %717
  store float %718, float addrspace(3)* %657, align 4, !tbaa !6
  %719 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %720 = load float, float addrspace(3)* %719, align 4, !tbaa !6
  %721 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 0), align 16, !tbaa !6
  %722 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %723 = load float, float addrspace(3)* %722, align 4, !tbaa !6
  %724 = fmul contract float %721, %723
  %725 = fsub contract float %720, %724
  store float %725, float addrspace(3)* %719, align 4, !tbaa !6
  %726 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 1), align 4, !tbaa !6
  %727 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %728 = load float, float addrspace(3)* %727, align 4, !tbaa !6
  %729 = fmul contract float %726, %728
  %730 = fsub contract float %725, %729
  store float %730, float addrspace(3)* %719, align 4, !tbaa !6
  %731 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 2), align 8, !tbaa !6
  %732 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %733 = load float, float addrspace(3)* %732, align 4, !tbaa !6
  %734 = fmul contract float %731, %733
  %735 = fsub contract float %730, %734
  store float %735, float addrspace(3)* %719, align 4, !tbaa !6
  %736 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 3), align 4, !tbaa !6
  %737 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %738 = load float, float addrspace(3)* %737, align 4, !tbaa !6
  %739 = fmul contract float %736, %738
  %740 = fsub contract float %735, %739
  store float %740, float addrspace(3)* %719, align 4, !tbaa !6
  %741 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 4), align 16, !tbaa !6
  %742 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %743 = load float, float addrspace(3)* %742, align 4, !tbaa !6
  %744 = fmul contract float %741, %743
  %745 = fsub contract float %740, %744
  store float %745, float addrspace(3)* %719, align 4, !tbaa !6
  %746 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 5), align 4, !tbaa !6
  %747 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %748 = load float, float addrspace(3)* %747, align 4, !tbaa !6
  %749 = fmul contract float %746, %748
  %750 = fsub contract float %745, %749
  store float %750, float addrspace(3)* %719, align 4, !tbaa !6
  %751 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 6), align 8, !tbaa !6
  %752 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %753 = load float, float addrspace(3)* %752, align 4, !tbaa !6
  %754 = fmul contract float %751, %753
  %755 = fsub contract float %750, %754
  store float %755, float addrspace(3)* %719, align 4, !tbaa !6
  %756 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 7), align 4, !tbaa !6
  %757 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %758 = load float, float addrspace(3)* %757, align 4, !tbaa !6
  %759 = fmul contract float %756, %758
  %760 = fsub contract float %755, %759
  store float %760, float addrspace(3)* %719, align 4, !tbaa !6
  %761 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 8), align 16, !tbaa !6
  %762 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %763 = load float, float addrspace(3)* %762, align 4, !tbaa !6
  %764 = fmul contract float %761, %763
  %765 = fsub contract float %760, %764
  store float %765, float addrspace(3)* %719, align 4, !tbaa !6
  %766 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 9), align 4, !tbaa !6
  %767 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %768 = load float, float addrspace(3)* %767, align 4, !tbaa !6
  %769 = fmul contract float %766, %768
  %770 = fsub contract float %765, %769
  store float %770, float addrspace(3)* %719, align 4, !tbaa !6
  %771 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 10), align 8, !tbaa !6
  %772 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %773 = load float, float addrspace(3)* %772, align 4, !tbaa !6
  %774 = fmul contract float %771, %773
  %775 = fsub contract float %770, %774
  store float %775, float addrspace(3)* %719, align 4, !tbaa !6
  %776 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 11), align 4, !tbaa !6
  %777 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %778 = load float, float addrspace(3)* %777, align 4, !tbaa !6
  %779 = fmul contract float %776, %778
  %780 = fsub contract float %775, %779
  store float %780, float addrspace(3)* %719, align 4, !tbaa !6
  %781 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 12), align 16, !tbaa !6
  %782 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %783 = load float, float addrspace(3)* %782, align 4, !tbaa !6
  %784 = fmul contract float %781, %783
  %785 = fsub contract float %780, %784
  store float %785, float addrspace(3)* %719, align 4, !tbaa !6
  %786 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %787 = load float, float addrspace(3)* %786, align 4, !tbaa !6
  %788 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 0), align 16, !tbaa !6
  %789 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %790 = load float, float addrspace(3)* %789, align 4, !tbaa !6
  %791 = fmul contract float %788, %790
  %792 = fsub contract float %787, %791
  store float %792, float addrspace(3)* %786, align 4, !tbaa !6
  %793 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 1), align 4, !tbaa !6
  %794 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %795 = load float, float addrspace(3)* %794, align 4, !tbaa !6
  %796 = fmul contract float %793, %795
  %797 = fsub contract float %792, %796
  store float %797, float addrspace(3)* %786, align 4, !tbaa !6
  %798 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 2), align 8, !tbaa !6
  %799 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %800 = load float, float addrspace(3)* %799, align 4, !tbaa !6
  %801 = fmul contract float %798, %800
  %802 = fsub contract float %797, %801
  store float %802, float addrspace(3)* %786, align 4, !tbaa !6
  %803 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 3), align 4, !tbaa !6
  %804 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %805 = load float, float addrspace(3)* %804, align 4, !tbaa !6
  %806 = fmul contract float %803, %805
  %807 = fsub contract float %802, %806
  store float %807, float addrspace(3)* %786, align 4, !tbaa !6
  %808 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 4), align 16, !tbaa !6
  %809 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %810 = load float, float addrspace(3)* %809, align 4, !tbaa !6
  %811 = fmul contract float %808, %810
  %812 = fsub contract float %807, %811
  store float %812, float addrspace(3)* %786, align 4, !tbaa !6
  %813 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 5), align 4, !tbaa !6
  %814 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %815 = load float, float addrspace(3)* %814, align 4, !tbaa !6
  %816 = fmul contract float %813, %815
  %817 = fsub contract float %812, %816
  store float %817, float addrspace(3)* %786, align 4, !tbaa !6
  %818 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 6), align 8, !tbaa !6
  %819 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %820 = load float, float addrspace(3)* %819, align 4, !tbaa !6
  %821 = fmul contract float %818, %820
  %822 = fsub contract float %817, %821
  store float %822, float addrspace(3)* %786, align 4, !tbaa !6
  %823 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 7), align 4, !tbaa !6
  %824 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %825 = load float, float addrspace(3)* %824, align 4, !tbaa !6
  %826 = fmul contract float %823, %825
  %827 = fsub contract float %822, %826
  store float %827, float addrspace(3)* %786, align 4, !tbaa !6
  %828 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 8), align 16, !tbaa !6
  %829 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %830 = load float, float addrspace(3)* %829, align 4, !tbaa !6
  %831 = fmul contract float %828, %830
  %832 = fsub contract float %827, %831
  store float %832, float addrspace(3)* %786, align 4, !tbaa !6
  %833 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 9), align 4, !tbaa !6
  %834 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %835 = load float, float addrspace(3)* %834, align 4, !tbaa !6
  %836 = fmul contract float %833, %835
  %837 = fsub contract float %832, %836
  store float %837, float addrspace(3)* %786, align 4, !tbaa !6
  %838 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 10), align 8, !tbaa !6
  %839 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %840 = load float, float addrspace(3)* %839, align 4, !tbaa !6
  %841 = fmul contract float %838, %840
  %842 = fsub contract float %837, %841
  store float %842, float addrspace(3)* %786, align 4, !tbaa !6
  %843 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 11), align 4, !tbaa !6
  %844 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %845 = load float, float addrspace(3)* %844, align 4, !tbaa !6
  %846 = fmul contract float %843, %845
  %847 = fsub contract float %842, %846
  store float %847, float addrspace(3)* %786, align 4, !tbaa !6
  %848 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 12), align 16, !tbaa !6
  %849 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %850 = load float, float addrspace(3)* %849, align 4, !tbaa !6
  %851 = fmul contract float %848, %850
  %852 = fsub contract float %847, %851
  store float %852, float addrspace(3)* %786, align 4, !tbaa !6
  %853 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 13), align 4, !tbaa !6
  %854 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %855 = load float, float addrspace(3)* %854, align 4, !tbaa !6
  %856 = fmul contract float %853, %855
  %857 = fsub contract float %852, %856
  store float %857, float addrspace(3)* %786, align 4, !tbaa !6
  %858 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %859 = load float, float addrspace(3)* %858, align 4, !tbaa !6
  %860 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 0), align 16, !tbaa !6
  %861 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 0, i32 %4
  %862 = load float, float addrspace(3)* %861, align 4, !tbaa !6
  %863 = fmul contract float %860, %862
  %864 = fsub contract float %859, %863
  store float %864, float addrspace(3)* %858, align 4, !tbaa !6
  %865 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 1), align 4, !tbaa !6
  %866 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %867 = load float, float addrspace(3)* %866, align 4, !tbaa !6
  %868 = fmul contract float %865, %867
  %869 = fsub contract float %864, %868
  store float %869, float addrspace(3)* %858, align 4, !tbaa !6
  %870 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 2), align 8, !tbaa !6
  %871 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %872 = load float, float addrspace(3)* %871, align 4, !tbaa !6
  %873 = fmul contract float %870, %872
  %874 = fsub contract float %869, %873
  store float %874, float addrspace(3)* %858, align 4, !tbaa !6
  %875 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 3), align 4, !tbaa !6
  %876 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %877 = load float, float addrspace(3)* %876, align 4, !tbaa !6
  %878 = fmul contract float %875, %877
  %879 = fsub contract float %874, %878
  store float %879, float addrspace(3)* %858, align 4, !tbaa !6
  %880 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 4), align 16, !tbaa !6
  %881 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %882 = load float, float addrspace(3)* %881, align 4, !tbaa !6
  %883 = fmul contract float %880, %882
  %884 = fsub contract float %879, %883
  store float %884, float addrspace(3)* %858, align 4, !tbaa !6
  %885 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 5), align 4, !tbaa !6
  %886 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %887 = load float, float addrspace(3)* %886, align 4, !tbaa !6
  %888 = fmul contract float %885, %887
  %889 = fsub contract float %884, %888
  store float %889, float addrspace(3)* %858, align 4, !tbaa !6
  %890 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 6), align 8, !tbaa !6
  %891 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %892 = load float, float addrspace(3)* %891, align 4, !tbaa !6
  %893 = fmul contract float %890, %892
  %894 = fsub contract float %889, %893
  store float %894, float addrspace(3)* %858, align 4, !tbaa !6
  %895 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 7), align 4, !tbaa !6
  %896 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %897 = load float, float addrspace(3)* %896, align 4, !tbaa !6
  %898 = fmul contract float %895, %897
  %899 = fsub contract float %894, %898
  store float %899, float addrspace(3)* %858, align 4, !tbaa !6
  %900 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 8), align 16, !tbaa !6
  %901 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %902 = load float, float addrspace(3)* %901, align 4, !tbaa !6
  %903 = fmul contract float %900, %902
  %904 = fsub contract float %899, %903
  store float %904, float addrspace(3)* %858, align 4, !tbaa !6
  %905 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 9), align 4, !tbaa !6
  %906 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %907 = load float, float addrspace(3)* %906, align 4, !tbaa !6
  %908 = fmul contract float %905, %907
  %909 = fsub contract float %904, %908
  store float %909, float addrspace(3)* %858, align 4, !tbaa !6
  %910 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 10), align 8, !tbaa !6
  %911 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %912 = load float, float addrspace(3)* %911, align 4, !tbaa !6
  %913 = fmul contract float %910, %912
  %914 = fsub contract float %909, %913
  store float %914, float addrspace(3)* %858, align 4, !tbaa !6
  %915 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 11), align 4, !tbaa !6
  %916 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %917 = load float, float addrspace(3)* %916, align 4, !tbaa !6
  %918 = fmul contract float %915, %917
  %919 = fsub contract float %914, %918
  store float %919, float addrspace(3)* %858, align 4, !tbaa !6
  %920 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 12), align 16, !tbaa !6
  %921 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %922 = load float, float addrspace(3)* %921, align 4, !tbaa !6
  %923 = fmul contract float %920, %922
  %924 = fsub contract float %919, %923
  store float %924, float addrspace(3)* %858, align 4, !tbaa !6
  %925 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 13), align 4, !tbaa !6
  %926 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %927 = load float, float addrspace(3)* %926, align 4, !tbaa !6
  %928 = fmul contract float %925, %927
  %929 = fsub contract float %924, %928
  store float %929, float addrspace(3)* %858, align 4, !tbaa !6
  %930 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 14), align 8, !tbaa !6
  %931 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %932 = load float, float addrspace(3)* %931, align 4, !tbaa !6
  %933 = fmul contract float %930, %932
  %934 = fsub contract float %929, %933
  store float %934, float addrspace(3)* %858, align 4, !tbaa !6
  br label %1587

935:                                              ; preds = %299
  %936 = add nsw i32 %4, -16
  %937 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 0
  %938 = load float, float addrspace(3)* %937, align 16, !tbaa !6
  %939 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 0), align 16, !tbaa !6
  %940 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 0
  %941 = fdiv contract float %938, %939
  store float %941, float addrspace(3)* %940, align 16, !tbaa !6
  %942 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %943 = load float, float addrspace(3)* %942, align 4, !tbaa !6
  %944 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 1), align 4, !tbaa !6
  %945 = fmul contract float %941, %944
  %946 = fsub contract float %943, %945
  store float %946, float addrspace(3)* %942, align 4, !tbaa !6
  %947 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 1), align 4, !tbaa !6
  %948 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %949 = fdiv contract float %946, %947
  store float %949, float addrspace(3)* %948, align 4, !tbaa !6
  %950 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 2
  %951 = load float, float addrspace(3)* %950, align 8, !tbaa !6
  %952 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 2), align 8, !tbaa !6
  %953 = fmul contract float %941, %952
  %954 = fsub contract float %951, %953
  store float %954, float addrspace(3)* %950, align 8, !tbaa !6
  %955 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %956 = load float, float addrspace(3)* %955, align 4, !tbaa !6
  %957 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 2), align 8, !tbaa !6
  %958 = fmul contract float %956, %957
  %959 = fsub contract float %954, %958
  store float %959, float addrspace(3)* %950, align 8, !tbaa !6
  %960 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 2), align 8, !tbaa !6
  %961 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 2
  %962 = fdiv contract float %959, %960
  store float %962, float addrspace(3)* %961, align 8, !tbaa !6
  %963 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 3
  %964 = load float, float addrspace(3)* %963, align 4, !tbaa !6
  %965 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 3), align 4, !tbaa !6
  %966 = fmul contract float %941, %965
  %967 = fsub contract float %964, %966
  store float %967, float addrspace(3)* %963, align 4, !tbaa !6
  %968 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %969 = load float, float addrspace(3)* %968, align 4, !tbaa !6
  %970 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 3), align 4, !tbaa !6
  %971 = fmul contract float %969, %970
  %972 = fsub contract float %967, %971
  store float %972, float addrspace(3)* %963, align 4, !tbaa !6
  %973 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 2
  %974 = load float, float addrspace(3)* %973, align 8, !tbaa !6
  %975 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 3), align 4, !tbaa !6
  %976 = fmul contract float %974, %975
  %977 = fsub contract float %972, %976
  store float %977, float addrspace(3)* %963, align 4, !tbaa !6
  %978 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 3), align 4, !tbaa !6
  %979 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 3
  %980 = fdiv contract float %977, %978
  store float %980, float addrspace(3)* %979, align 4, !tbaa !6
  %981 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 4
  %982 = load float, float addrspace(3)* %981, align 16, !tbaa !6
  %983 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 4), align 16, !tbaa !6
  %984 = fmul contract float %941, %983
  %985 = fsub contract float %982, %984
  store float %985, float addrspace(3)* %981, align 16, !tbaa !6
  %986 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %987 = load float, float addrspace(3)* %986, align 4, !tbaa !6
  %988 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 4), align 16, !tbaa !6
  %989 = fmul contract float %987, %988
  %990 = fsub contract float %985, %989
  store float %990, float addrspace(3)* %981, align 16, !tbaa !6
  %991 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 2
  %992 = load float, float addrspace(3)* %991, align 8, !tbaa !6
  %993 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 4), align 16, !tbaa !6
  %994 = fmul contract float %992, %993
  %995 = fsub contract float %990, %994
  store float %995, float addrspace(3)* %981, align 16, !tbaa !6
  %996 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 3
  %997 = load float, float addrspace(3)* %996, align 4, !tbaa !6
  %998 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 4), align 16, !tbaa !6
  %999 = fmul contract float %997, %998
  %1000 = fsub contract float %995, %999
  store float %1000, float addrspace(3)* %981, align 16, !tbaa !6
  %1001 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 4), align 16, !tbaa !6
  %1002 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 4
  %1003 = fdiv contract float %1000, %1001
  store float %1003, float addrspace(3)* %1002, align 16, !tbaa !6
  %1004 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 5
  %1005 = load float, float addrspace(3)* %1004, align 4, !tbaa !6
  %1006 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 5), align 4, !tbaa !6
  %1007 = fmul contract float %941, %1006
  %1008 = fsub contract float %1005, %1007
  store float %1008, float addrspace(3)* %1004, align 4, !tbaa !6
  %1009 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %1010 = load float, float addrspace(3)* %1009, align 4, !tbaa !6
  %1011 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 5), align 4, !tbaa !6
  %1012 = fmul contract float %1010, %1011
  %1013 = fsub contract float %1008, %1012
  store float %1013, float addrspace(3)* %1004, align 4, !tbaa !6
  %1014 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 2
  %1015 = load float, float addrspace(3)* %1014, align 8, !tbaa !6
  %1016 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 5), align 4, !tbaa !6
  %1017 = fmul contract float %1015, %1016
  %1018 = fsub contract float %1013, %1017
  store float %1018, float addrspace(3)* %1004, align 4, !tbaa !6
  %1019 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 3
  %1020 = load float, float addrspace(3)* %1019, align 4, !tbaa !6
  %1021 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 5), align 4, !tbaa !6
  %1022 = fmul contract float %1020, %1021
  %1023 = fsub contract float %1018, %1022
  store float %1023, float addrspace(3)* %1004, align 4, !tbaa !6
  %1024 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 4
  %1025 = load float, float addrspace(3)* %1024, align 16, !tbaa !6
  %1026 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 5), align 4, !tbaa !6
  %1027 = fmul contract float %1025, %1026
  %1028 = fsub contract float %1023, %1027
  store float %1028, float addrspace(3)* %1004, align 4, !tbaa !6
  %1029 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 5), align 4, !tbaa !6
  %1030 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 5
  %1031 = fdiv contract float %1028, %1029
  store float %1031, float addrspace(3)* %1030, align 4, !tbaa !6
  %1032 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 6
  %1033 = load float, float addrspace(3)* %1032, align 8, !tbaa !6
  %1034 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 6), align 8, !tbaa !6
  %1035 = fmul contract float %941, %1034
  %1036 = fsub contract float %1033, %1035
  store float %1036, float addrspace(3)* %1032, align 8, !tbaa !6
  %1037 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %1038 = load float, float addrspace(3)* %1037, align 4, !tbaa !6
  %1039 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 6), align 8, !tbaa !6
  %1040 = fmul contract float %1038, %1039
  %1041 = fsub contract float %1036, %1040
  store float %1041, float addrspace(3)* %1032, align 8, !tbaa !6
  %1042 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 2
  %1043 = load float, float addrspace(3)* %1042, align 8, !tbaa !6
  %1044 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 6), align 8, !tbaa !6
  %1045 = fmul contract float %1043, %1044
  %1046 = fsub contract float %1041, %1045
  store float %1046, float addrspace(3)* %1032, align 8, !tbaa !6
  %1047 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 3
  %1048 = load float, float addrspace(3)* %1047, align 4, !tbaa !6
  %1049 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 6), align 8, !tbaa !6
  %1050 = fmul contract float %1048, %1049
  %1051 = fsub contract float %1046, %1050
  store float %1051, float addrspace(3)* %1032, align 8, !tbaa !6
  %1052 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 4
  %1053 = load float, float addrspace(3)* %1052, align 16, !tbaa !6
  %1054 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 6), align 8, !tbaa !6
  %1055 = fmul contract float %1053, %1054
  %1056 = fsub contract float %1051, %1055
  store float %1056, float addrspace(3)* %1032, align 8, !tbaa !6
  %1057 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 5
  %1058 = load float, float addrspace(3)* %1057, align 4, !tbaa !6
  %1059 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 6), align 8, !tbaa !6
  %1060 = fmul contract float %1058, %1059
  %1061 = fsub contract float %1056, %1060
  store float %1061, float addrspace(3)* %1032, align 8, !tbaa !6
  %1062 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 6), align 8, !tbaa !6
  %1063 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 6
  %1064 = fdiv contract float %1061, %1062
  store float %1064, float addrspace(3)* %1063, align 8, !tbaa !6
  %1065 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 7
  %1066 = load float, float addrspace(3)* %1065, align 4, !tbaa !6
  %1067 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 7), align 4, !tbaa !6
  %1068 = fmul contract float %941, %1067
  %1069 = fsub contract float %1066, %1068
  store float %1069, float addrspace(3)* %1065, align 4, !tbaa !6
  %1070 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %1071 = load float, float addrspace(3)* %1070, align 4, !tbaa !6
  %1072 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 7), align 4, !tbaa !6
  %1073 = fmul contract float %1071, %1072
  %1074 = fsub contract float %1069, %1073
  store float %1074, float addrspace(3)* %1065, align 4, !tbaa !6
  %1075 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 2
  %1076 = load float, float addrspace(3)* %1075, align 8, !tbaa !6
  %1077 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 7), align 4, !tbaa !6
  %1078 = fmul contract float %1076, %1077
  %1079 = fsub contract float %1074, %1078
  store float %1079, float addrspace(3)* %1065, align 4, !tbaa !6
  %1080 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 3
  %1081 = load float, float addrspace(3)* %1080, align 4, !tbaa !6
  %1082 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 7), align 4, !tbaa !6
  %1083 = fmul contract float %1081, %1082
  %1084 = fsub contract float %1079, %1083
  store float %1084, float addrspace(3)* %1065, align 4, !tbaa !6
  %1085 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 4
  %1086 = load float, float addrspace(3)* %1085, align 16, !tbaa !6
  %1087 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 7), align 4, !tbaa !6
  %1088 = fmul contract float %1086, %1087
  %1089 = fsub contract float %1084, %1088
  store float %1089, float addrspace(3)* %1065, align 4, !tbaa !6
  %1090 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 5
  %1091 = load float, float addrspace(3)* %1090, align 4, !tbaa !6
  %1092 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 7), align 4, !tbaa !6
  %1093 = fmul contract float %1091, %1092
  %1094 = fsub contract float %1089, %1093
  store float %1094, float addrspace(3)* %1065, align 4, !tbaa !6
  %1095 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 6
  %1096 = load float, float addrspace(3)* %1095, align 8, !tbaa !6
  %1097 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 7), align 4, !tbaa !6
  %1098 = fmul contract float %1096, %1097
  %1099 = fsub contract float %1094, %1098
  store float %1099, float addrspace(3)* %1065, align 4, !tbaa !6
  %1100 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 7), align 4, !tbaa !6
  %1101 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 7
  %1102 = fdiv contract float %1099, %1100
  store float %1102, float addrspace(3)* %1101, align 4, !tbaa !6
  %1103 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 8
  %1104 = load float, float addrspace(3)* %1103, align 16, !tbaa !6
  %1105 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 8), align 16, !tbaa !6
  %1106 = fmul contract float %941, %1105
  %1107 = fsub contract float %1104, %1106
  store float %1107, float addrspace(3)* %1103, align 16, !tbaa !6
  %1108 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %1109 = load float, float addrspace(3)* %1108, align 4, !tbaa !6
  %1110 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 8), align 16, !tbaa !6
  %1111 = fmul contract float %1109, %1110
  %1112 = fsub contract float %1107, %1111
  store float %1112, float addrspace(3)* %1103, align 16, !tbaa !6
  %1113 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 2
  %1114 = load float, float addrspace(3)* %1113, align 8, !tbaa !6
  %1115 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 8), align 16, !tbaa !6
  %1116 = fmul contract float %1114, %1115
  %1117 = fsub contract float %1112, %1116
  store float %1117, float addrspace(3)* %1103, align 16, !tbaa !6
  %1118 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 3
  %1119 = load float, float addrspace(3)* %1118, align 4, !tbaa !6
  %1120 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 8), align 16, !tbaa !6
  %1121 = fmul contract float %1119, %1120
  %1122 = fsub contract float %1117, %1121
  store float %1122, float addrspace(3)* %1103, align 16, !tbaa !6
  %1123 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 4
  %1124 = load float, float addrspace(3)* %1123, align 16, !tbaa !6
  %1125 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 8), align 16, !tbaa !6
  %1126 = fmul contract float %1124, %1125
  %1127 = fsub contract float %1122, %1126
  store float %1127, float addrspace(3)* %1103, align 16, !tbaa !6
  %1128 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 5
  %1129 = load float, float addrspace(3)* %1128, align 4, !tbaa !6
  %1130 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 8), align 16, !tbaa !6
  %1131 = fmul contract float %1129, %1130
  %1132 = fsub contract float %1127, %1131
  store float %1132, float addrspace(3)* %1103, align 16, !tbaa !6
  %1133 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 6
  %1134 = load float, float addrspace(3)* %1133, align 8, !tbaa !6
  %1135 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 8), align 16, !tbaa !6
  %1136 = fmul contract float %1134, %1135
  %1137 = fsub contract float %1132, %1136
  store float %1137, float addrspace(3)* %1103, align 16, !tbaa !6
  %1138 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 7
  %1139 = load float, float addrspace(3)* %1138, align 4, !tbaa !6
  %1140 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 8), align 16, !tbaa !6
  %1141 = fmul contract float %1139, %1140
  %1142 = fsub contract float %1137, %1141
  store float %1142, float addrspace(3)* %1103, align 16, !tbaa !6
  %1143 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 8), align 16, !tbaa !6
  %1144 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 8
  %1145 = fdiv contract float %1142, %1143
  store float %1145, float addrspace(3)* %1144, align 16, !tbaa !6
  %1146 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 9
  %1147 = load float, float addrspace(3)* %1146, align 4, !tbaa !6
  %1148 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 9), align 4, !tbaa !6
  %1149 = fmul contract float %941, %1148
  %1150 = fsub contract float %1147, %1149
  store float %1150, float addrspace(3)* %1146, align 4, !tbaa !6
  %1151 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %1152 = load float, float addrspace(3)* %1151, align 4, !tbaa !6
  %1153 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 9), align 4, !tbaa !6
  %1154 = fmul contract float %1152, %1153
  %1155 = fsub contract float %1150, %1154
  store float %1155, float addrspace(3)* %1146, align 4, !tbaa !6
  %1156 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 2
  %1157 = load float, float addrspace(3)* %1156, align 8, !tbaa !6
  %1158 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 9), align 4, !tbaa !6
  %1159 = fmul contract float %1157, %1158
  %1160 = fsub contract float %1155, %1159
  store float %1160, float addrspace(3)* %1146, align 4, !tbaa !6
  %1161 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 3
  %1162 = load float, float addrspace(3)* %1161, align 4, !tbaa !6
  %1163 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 9), align 4, !tbaa !6
  %1164 = fmul contract float %1162, %1163
  %1165 = fsub contract float %1160, %1164
  store float %1165, float addrspace(3)* %1146, align 4, !tbaa !6
  %1166 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 4
  %1167 = load float, float addrspace(3)* %1166, align 16, !tbaa !6
  %1168 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 9), align 4, !tbaa !6
  %1169 = fmul contract float %1167, %1168
  %1170 = fsub contract float %1165, %1169
  store float %1170, float addrspace(3)* %1146, align 4, !tbaa !6
  %1171 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 5
  %1172 = load float, float addrspace(3)* %1171, align 4, !tbaa !6
  %1173 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 9), align 4, !tbaa !6
  %1174 = fmul contract float %1172, %1173
  %1175 = fsub contract float %1170, %1174
  store float %1175, float addrspace(3)* %1146, align 4, !tbaa !6
  %1176 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 6
  %1177 = load float, float addrspace(3)* %1176, align 8, !tbaa !6
  %1178 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 9), align 4, !tbaa !6
  %1179 = fmul contract float %1177, %1178
  %1180 = fsub contract float %1175, %1179
  store float %1180, float addrspace(3)* %1146, align 4, !tbaa !6
  %1181 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 7
  %1182 = load float, float addrspace(3)* %1181, align 4, !tbaa !6
  %1183 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 9), align 4, !tbaa !6
  %1184 = fmul contract float %1182, %1183
  %1185 = fsub contract float %1180, %1184
  store float %1185, float addrspace(3)* %1146, align 4, !tbaa !6
  %1186 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 8
  %1187 = load float, float addrspace(3)* %1186, align 16, !tbaa !6
  %1188 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 9), align 4, !tbaa !6
  %1189 = fmul contract float %1187, %1188
  %1190 = fsub contract float %1185, %1189
  store float %1190, float addrspace(3)* %1146, align 4, !tbaa !6
  %1191 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 9), align 4, !tbaa !6
  %1192 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 9
  %1193 = fdiv contract float %1190, %1191
  store float %1193, float addrspace(3)* %1192, align 4, !tbaa !6
  %1194 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 10
  %1195 = load float, float addrspace(3)* %1194, align 8, !tbaa !6
  %1196 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 10), align 8, !tbaa !6
  %1197 = fmul contract float %941, %1196
  %1198 = fsub contract float %1195, %1197
  store float %1198, float addrspace(3)* %1194, align 8, !tbaa !6
  %1199 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %1200 = load float, float addrspace(3)* %1199, align 4, !tbaa !6
  %1201 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 10), align 8, !tbaa !6
  %1202 = fmul contract float %1200, %1201
  %1203 = fsub contract float %1198, %1202
  store float %1203, float addrspace(3)* %1194, align 8, !tbaa !6
  %1204 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 2
  %1205 = load float, float addrspace(3)* %1204, align 8, !tbaa !6
  %1206 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 10), align 8, !tbaa !6
  %1207 = fmul contract float %1205, %1206
  %1208 = fsub contract float %1203, %1207
  store float %1208, float addrspace(3)* %1194, align 8, !tbaa !6
  %1209 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 3
  %1210 = load float, float addrspace(3)* %1209, align 4, !tbaa !6
  %1211 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 10), align 8, !tbaa !6
  %1212 = fmul contract float %1210, %1211
  %1213 = fsub contract float %1208, %1212
  store float %1213, float addrspace(3)* %1194, align 8, !tbaa !6
  %1214 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 4
  %1215 = load float, float addrspace(3)* %1214, align 16, !tbaa !6
  %1216 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 10), align 8, !tbaa !6
  %1217 = fmul contract float %1215, %1216
  %1218 = fsub contract float %1213, %1217
  store float %1218, float addrspace(3)* %1194, align 8, !tbaa !6
  %1219 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 5
  %1220 = load float, float addrspace(3)* %1219, align 4, !tbaa !6
  %1221 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 10), align 8, !tbaa !6
  %1222 = fmul contract float %1220, %1221
  %1223 = fsub contract float %1218, %1222
  store float %1223, float addrspace(3)* %1194, align 8, !tbaa !6
  %1224 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 6
  %1225 = load float, float addrspace(3)* %1224, align 8, !tbaa !6
  %1226 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 10), align 8, !tbaa !6
  %1227 = fmul contract float %1225, %1226
  %1228 = fsub contract float %1223, %1227
  store float %1228, float addrspace(3)* %1194, align 8, !tbaa !6
  %1229 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 7
  %1230 = load float, float addrspace(3)* %1229, align 4, !tbaa !6
  %1231 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 10), align 8, !tbaa !6
  %1232 = fmul contract float %1230, %1231
  %1233 = fsub contract float %1228, %1232
  store float %1233, float addrspace(3)* %1194, align 8, !tbaa !6
  %1234 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 8
  %1235 = load float, float addrspace(3)* %1234, align 16, !tbaa !6
  %1236 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 10), align 8, !tbaa !6
  %1237 = fmul contract float %1235, %1236
  %1238 = fsub contract float %1233, %1237
  store float %1238, float addrspace(3)* %1194, align 8, !tbaa !6
  %1239 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 9
  %1240 = load float, float addrspace(3)* %1239, align 4, !tbaa !6
  %1241 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 10), align 8, !tbaa !6
  %1242 = fmul contract float %1240, %1241
  %1243 = fsub contract float %1238, %1242
  store float %1243, float addrspace(3)* %1194, align 8, !tbaa !6
  %1244 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 10), align 8, !tbaa !6
  %1245 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 10
  %1246 = fdiv contract float %1243, %1244
  store float %1246, float addrspace(3)* %1245, align 8, !tbaa !6
  %1247 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 11
  %1248 = load float, float addrspace(3)* %1247, align 4, !tbaa !6
  %1249 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 11), align 4, !tbaa !6
  %1250 = fmul contract float %941, %1249
  %1251 = fsub contract float %1248, %1250
  store float %1251, float addrspace(3)* %1247, align 4, !tbaa !6
  %1252 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %1253 = load float, float addrspace(3)* %1252, align 4, !tbaa !6
  %1254 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 11), align 4, !tbaa !6
  %1255 = fmul contract float %1253, %1254
  %1256 = fsub contract float %1251, %1255
  store float %1256, float addrspace(3)* %1247, align 4, !tbaa !6
  %1257 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 2
  %1258 = load float, float addrspace(3)* %1257, align 8, !tbaa !6
  %1259 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 11), align 4, !tbaa !6
  %1260 = fmul contract float %1258, %1259
  %1261 = fsub contract float %1256, %1260
  store float %1261, float addrspace(3)* %1247, align 4, !tbaa !6
  %1262 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 3
  %1263 = load float, float addrspace(3)* %1262, align 4, !tbaa !6
  %1264 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 11), align 4, !tbaa !6
  %1265 = fmul contract float %1263, %1264
  %1266 = fsub contract float %1261, %1265
  store float %1266, float addrspace(3)* %1247, align 4, !tbaa !6
  %1267 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 4
  %1268 = load float, float addrspace(3)* %1267, align 16, !tbaa !6
  %1269 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 11), align 4, !tbaa !6
  %1270 = fmul contract float %1268, %1269
  %1271 = fsub contract float %1266, %1270
  store float %1271, float addrspace(3)* %1247, align 4, !tbaa !6
  %1272 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 5
  %1273 = load float, float addrspace(3)* %1272, align 4, !tbaa !6
  %1274 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 11), align 4, !tbaa !6
  %1275 = fmul contract float %1273, %1274
  %1276 = fsub contract float %1271, %1275
  store float %1276, float addrspace(3)* %1247, align 4, !tbaa !6
  %1277 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 6
  %1278 = load float, float addrspace(3)* %1277, align 8, !tbaa !6
  %1279 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 11), align 4, !tbaa !6
  %1280 = fmul contract float %1278, %1279
  %1281 = fsub contract float %1276, %1280
  store float %1281, float addrspace(3)* %1247, align 4, !tbaa !6
  %1282 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 7
  %1283 = load float, float addrspace(3)* %1282, align 4, !tbaa !6
  %1284 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 11), align 4, !tbaa !6
  %1285 = fmul contract float %1283, %1284
  %1286 = fsub contract float %1281, %1285
  store float %1286, float addrspace(3)* %1247, align 4, !tbaa !6
  %1287 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 8
  %1288 = load float, float addrspace(3)* %1287, align 16, !tbaa !6
  %1289 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 11), align 4, !tbaa !6
  %1290 = fmul contract float %1288, %1289
  %1291 = fsub contract float %1286, %1290
  store float %1291, float addrspace(3)* %1247, align 4, !tbaa !6
  %1292 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 9
  %1293 = load float, float addrspace(3)* %1292, align 4, !tbaa !6
  %1294 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 11), align 4, !tbaa !6
  %1295 = fmul contract float %1293, %1294
  %1296 = fsub contract float %1291, %1295
  store float %1296, float addrspace(3)* %1247, align 4, !tbaa !6
  %1297 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 10
  %1298 = load float, float addrspace(3)* %1297, align 8, !tbaa !6
  %1299 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 11), align 4, !tbaa !6
  %1300 = fmul contract float %1298, %1299
  %1301 = fsub contract float %1296, %1300
  store float %1301, float addrspace(3)* %1247, align 4, !tbaa !6
  %1302 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 11), align 4, !tbaa !6
  %1303 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 11
  %1304 = fdiv contract float %1301, %1302
  store float %1304, float addrspace(3)* %1303, align 4, !tbaa !6
  %1305 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 12
  %1306 = load float, float addrspace(3)* %1305, align 16, !tbaa !6
  %1307 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 12), align 16, !tbaa !6
  %1308 = fmul contract float %941, %1307
  %1309 = fsub contract float %1306, %1308
  store float %1309, float addrspace(3)* %1305, align 16, !tbaa !6
  %1310 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %1311 = load float, float addrspace(3)* %1310, align 4, !tbaa !6
  %1312 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 12), align 16, !tbaa !6
  %1313 = fmul contract float %1311, %1312
  %1314 = fsub contract float %1309, %1313
  store float %1314, float addrspace(3)* %1305, align 16, !tbaa !6
  %1315 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 2
  %1316 = load float, float addrspace(3)* %1315, align 8, !tbaa !6
  %1317 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 12), align 16, !tbaa !6
  %1318 = fmul contract float %1316, %1317
  %1319 = fsub contract float %1314, %1318
  store float %1319, float addrspace(3)* %1305, align 16, !tbaa !6
  %1320 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 3
  %1321 = load float, float addrspace(3)* %1320, align 4, !tbaa !6
  %1322 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 12), align 16, !tbaa !6
  %1323 = fmul contract float %1321, %1322
  %1324 = fsub contract float %1319, %1323
  store float %1324, float addrspace(3)* %1305, align 16, !tbaa !6
  %1325 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 4
  %1326 = load float, float addrspace(3)* %1325, align 16, !tbaa !6
  %1327 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 12), align 16, !tbaa !6
  %1328 = fmul contract float %1326, %1327
  %1329 = fsub contract float %1324, %1328
  store float %1329, float addrspace(3)* %1305, align 16, !tbaa !6
  %1330 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 5
  %1331 = load float, float addrspace(3)* %1330, align 4, !tbaa !6
  %1332 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 12), align 16, !tbaa !6
  %1333 = fmul contract float %1331, %1332
  %1334 = fsub contract float %1329, %1333
  store float %1334, float addrspace(3)* %1305, align 16, !tbaa !6
  %1335 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 6
  %1336 = load float, float addrspace(3)* %1335, align 8, !tbaa !6
  %1337 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 12), align 16, !tbaa !6
  %1338 = fmul contract float %1336, %1337
  %1339 = fsub contract float %1334, %1338
  store float %1339, float addrspace(3)* %1305, align 16, !tbaa !6
  %1340 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 7
  %1341 = load float, float addrspace(3)* %1340, align 4, !tbaa !6
  %1342 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 12), align 16, !tbaa !6
  %1343 = fmul contract float %1341, %1342
  %1344 = fsub contract float %1339, %1343
  store float %1344, float addrspace(3)* %1305, align 16, !tbaa !6
  %1345 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 8
  %1346 = load float, float addrspace(3)* %1345, align 16, !tbaa !6
  %1347 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 12), align 16, !tbaa !6
  %1348 = fmul contract float %1346, %1347
  %1349 = fsub contract float %1344, %1348
  store float %1349, float addrspace(3)* %1305, align 16, !tbaa !6
  %1350 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 9
  %1351 = load float, float addrspace(3)* %1350, align 4, !tbaa !6
  %1352 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 12), align 16, !tbaa !6
  %1353 = fmul contract float %1351, %1352
  %1354 = fsub contract float %1349, %1353
  store float %1354, float addrspace(3)* %1305, align 16, !tbaa !6
  %1355 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 10
  %1356 = load float, float addrspace(3)* %1355, align 8, !tbaa !6
  %1357 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 12), align 16, !tbaa !6
  %1358 = fmul contract float %1356, %1357
  %1359 = fsub contract float %1354, %1358
  store float %1359, float addrspace(3)* %1305, align 16, !tbaa !6
  %1360 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 11
  %1361 = load float, float addrspace(3)* %1360, align 4, !tbaa !6
  %1362 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 12), align 16, !tbaa !6
  %1363 = fmul contract float %1361, %1362
  %1364 = fsub contract float %1359, %1363
  store float %1364, float addrspace(3)* %1305, align 16, !tbaa !6
  %1365 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 12), align 16, !tbaa !6
  %1366 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 12
  %1367 = fdiv contract float %1364, %1365
  store float %1367, float addrspace(3)* %1366, align 16, !tbaa !6
  %1368 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 13
  %1369 = load float, float addrspace(3)* %1368, align 4, !tbaa !6
  %1370 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 13), align 4, !tbaa !6
  %1371 = fmul contract float %941, %1370
  %1372 = fsub contract float %1369, %1371
  store float %1372, float addrspace(3)* %1368, align 4, !tbaa !6
  %1373 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %1374 = load float, float addrspace(3)* %1373, align 4, !tbaa !6
  %1375 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 13), align 4, !tbaa !6
  %1376 = fmul contract float %1374, %1375
  %1377 = fsub contract float %1372, %1376
  store float %1377, float addrspace(3)* %1368, align 4, !tbaa !6
  %1378 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 2
  %1379 = load float, float addrspace(3)* %1378, align 8, !tbaa !6
  %1380 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 13), align 4, !tbaa !6
  %1381 = fmul contract float %1379, %1380
  %1382 = fsub contract float %1377, %1381
  store float %1382, float addrspace(3)* %1368, align 4, !tbaa !6
  %1383 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 3
  %1384 = load float, float addrspace(3)* %1383, align 4, !tbaa !6
  %1385 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 13), align 4, !tbaa !6
  %1386 = fmul contract float %1384, %1385
  %1387 = fsub contract float %1382, %1386
  store float %1387, float addrspace(3)* %1368, align 4, !tbaa !6
  %1388 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 4
  %1389 = load float, float addrspace(3)* %1388, align 16, !tbaa !6
  %1390 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 13), align 4, !tbaa !6
  %1391 = fmul contract float %1389, %1390
  %1392 = fsub contract float %1387, %1391
  store float %1392, float addrspace(3)* %1368, align 4, !tbaa !6
  %1393 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 5
  %1394 = load float, float addrspace(3)* %1393, align 4, !tbaa !6
  %1395 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 13), align 4, !tbaa !6
  %1396 = fmul contract float %1394, %1395
  %1397 = fsub contract float %1392, %1396
  store float %1397, float addrspace(3)* %1368, align 4, !tbaa !6
  %1398 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 6
  %1399 = load float, float addrspace(3)* %1398, align 8, !tbaa !6
  %1400 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 13), align 4, !tbaa !6
  %1401 = fmul contract float %1399, %1400
  %1402 = fsub contract float %1397, %1401
  store float %1402, float addrspace(3)* %1368, align 4, !tbaa !6
  %1403 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 7
  %1404 = load float, float addrspace(3)* %1403, align 4, !tbaa !6
  %1405 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 13), align 4, !tbaa !6
  %1406 = fmul contract float %1404, %1405
  %1407 = fsub contract float %1402, %1406
  store float %1407, float addrspace(3)* %1368, align 4, !tbaa !6
  %1408 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 8
  %1409 = load float, float addrspace(3)* %1408, align 16, !tbaa !6
  %1410 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 13), align 4, !tbaa !6
  %1411 = fmul contract float %1409, %1410
  %1412 = fsub contract float %1407, %1411
  store float %1412, float addrspace(3)* %1368, align 4, !tbaa !6
  %1413 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 9
  %1414 = load float, float addrspace(3)* %1413, align 4, !tbaa !6
  %1415 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 13), align 4, !tbaa !6
  %1416 = fmul contract float %1414, %1415
  %1417 = fsub contract float %1412, %1416
  store float %1417, float addrspace(3)* %1368, align 4, !tbaa !6
  %1418 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 10
  %1419 = load float, float addrspace(3)* %1418, align 8, !tbaa !6
  %1420 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 13), align 4, !tbaa !6
  %1421 = fmul contract float %1419, %1420
  %1422 = fsub contract float %1417, %1421
  store float %1422, float addrspace(3)* %1368, align 4, !tbaa !6
  %1423 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 11
  %1424 = load float, float addrspace(3)* %1423, align 4, !tbaa !6
  %1425 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 13), align 4, !tbaa !6
  %1426 = fmul contract float %1424, %1425
  %1427 = fsub contract float %1422, %1426
  store float %1427, float addrspace(3)* %1368, align 4, !tbaa !6
  %1428 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 12
  %1429 = load float, float addrspace(3)* %1428, align 16, !tbaa !6
  %1430 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 13), align 4, !tbaa !6
  %1431 = fmul contract float %1429, %1430
  %1432 = fsub contract float %1427, %1431
  store float %1432, float addrspace(3)* %1368, align 4, !tbaa !6
  %1433 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 13), align 4, !tbaa !6
  %1434 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 13
  %1435 = fdiv contract float %1432, %1433
  store float %1435, float addrspace(3)* %1434, align 4, !tbaa !6
  %1436 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 14
  %1437 = load float, float addrspace(3)* %1436, align 8, !tbaa !6
  %1438 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 14), align 8, !tbaa !6
  %1439 = fmul contract float %941, %1438
  %1440 = fsub contract float %1437, %1439
  store float %1440, float addrspace(3)* %1436, align 8, !tbaa !6
  %1441 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %1442 = load float, float addrspace(3)* %1441, align 4, !tbaa !6
  %1443 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 14), align 8, !tbaa !6
  %1444 = fmul contract float %1442, %1443
  %1445 = fsub contract float %1440, %1444
  store float %1445, float addrspace(3)* %1436, align 8, !tbaa !6
  %1446 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 2
  %1447 = load float, float addrspace(3)* %1446, align 8, !tbaa !6
  %1448 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 14), align 8, !tbaa !6
  %1449 = fmul contract float %1447, %1448
  %1450 = fsub contract float %1445, %1449
  store float %1450, float addrspace(3)* %1436, align 8, !tbaa !6
  %1451 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 3
  %1452 = load float, float addrspace(3)* %1451, align 4, !tbaa !6
  %1453 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 14), align 8, !tbaa !6
  %1454 = fmul contract float %1452, %1453
  %1455 = fsub contract float %1450, %1454
  store float %1455, float addrspace(3)* %1436, align 8, !tbaa !6
  %1456 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 4
  %1457 = load float, float addrspace(3)* %1456, align 16, !tbaa !6
  %1458 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 14), align 8, !tbaa !6
  %1459 = fmul contract float %1457, %1458
  %1460 = fsub contract float %1455, %1459
  store float %1460, float addrspace(3)* %1436, align 8, !tbaa !6
  %1461 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 5
  %1462 = load float, float addrspace(3)* %1461, align 4, !tbaa !6
  %1463 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 14), align 8, !tbaa !6
  %1464 = fmul contract float %1462, %1463
  %1465 = fsub contract float %1460, %1464
  store float %1465, float addrspace(3)* %1436, align 8, !tbaa !6
  %1466 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 6
  %1467 = load float, float addrspace(3)* %1466, align 8, !tbaa !6
  %1468 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 14), align 8, !tbaa !6
  %1469 = fmul contract float %1467, %1468
  %1470 = fsub contract float %1465, %1469
  store float %1470, float addrspace(3)* %1436, align 8, !tbaa !6
  %1471 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 7
  %1472 = load float, float addrspace(3)* %1471, align 4, !tbaa !6
  %1473 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 14), align 8, !tbaa !6
  %1474 = fmul contract float %1472, %1473
  %1475 = fsub contract float %1470, %1474
  store float %1475, float addrspace(3)* %1436, align 8, !tbaa !6
  %1476 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 8
  %1477 = load float, float addrspace(3)* %1476, align 16, !tbaa !6
  %1478 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 14), align 8, !tbaa !6
  %1479 = fmul contract float %1477, %1478
  %1480 = fsub contract float %1475, %1479
  store float %1480, float addrspace(3)* %1436, align 8, !tbaa !6
  %1481 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 9
  %1482 = load float, float addrspace(3)* %1481, align 4, !tbaa !6
  %1483 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 14), align 8, !tbaa !6
  %1484 = fmul contract float %1482, %1483
  %1485 = fsub contract float %1480, %1484
  store float %1485, float addrspace(3)* %1436, align 8, !tbaa !6
  %1486 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 10
  %1487 = load float, float addrspace(3)* %1486, align 8, !tbaa !6
  %1488 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 14), align 8, !tbaa !6
  %1489 = fmul contract float %1487, %1488
  %1490 = fsub contract float %1485, %1489
  store float %1490, float addrspace(3)* %1436, align 8, !tbaa !6
  %1491 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 11
  %1492 = load float, float addrspace(3)* %1491, align 4, !tbaa !6
  %1493 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 14), align 8, !tbaa !6
  %1494 = fmul contract float %1492, %1493
  %1495 = fsub contract float %1490, %1494
  store float %1495, float addrspace(3)* %1436, align 8, !tbaa !6
  %1496 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 12
  %1497 = load float, float addrspace(3)* %1496, align 16, !tbaa !6
  %1498 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 14), align 8, !tbaa !6
  %1499 = fmul contract float %1497, %1498
  %1500 = fsub contract float %1495, %1499
  store float %1500, float addrspace(3)* %1436, align 8, !tbaa !6
  %1501 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 13
  %1502 = load float, float addrspace(3)* %1501, align 4, !tbaa !6
  %1503 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 14), align 8, !tbaa !6
  %1504 = fmul contract float %1502, %1503
  %1505 = fsub contract float %1500, %1504
  store float %1505, float addrspace(3)* %1436, align 8, !tbaa !6
  %1506 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 14), align 8, !tbaa !6
  %1507 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 14
  %1508 = fdiv contract float %1505, %1506
  store float %1508, float addrspace(3)* %1507, align 8, !tbaa !6
  %1509 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 15
  %1510 = load float, float addrspace(3)* %1509, align 4, !tbaa !6
  %1511 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 0, i32 15), align 4, !tbaa !6
  %1512 = fmul contract float %941, %1511
  %1513 = fsub contract float %1510, %1512
  store float %1513, float addrspace(3)* %1509, align 4, !tbaa !6
  %1514 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 1
  %1515 = load float, float addrspace(3)* %1514, align 4, !tbaa !6
  %1516 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 1, i32 15), align 4, !tbaa !6
  %1517 = fmul contract float %1515, %1516
  %1518 = fsub contract float %1513, %1517
  store float %1518, float addrspace(3)* %1509, align 4, !tbaa !6
  %1519 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 2
  %1520 = load float, float addrspace(3)* %1519, align 8, !tbaa !6
  %1521 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 2, i32 15), align 4, !tbaa !6
  %1522 = fmul contract float %1520, %1521
  %1523 = fsub contract float %1518, %1522
  store float %1523, float addrspace(3)* %1509, align 4, !tbaa !6
  %1524 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 3
  %1525 = load float, float addrspace(3)* %1524, align 4, !tbaa !6
  %1526 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 3, i32 15), align 4, !tbaa !6
  %1527 = fmul contract float %1525, %1526
  %1528 = fsub contract float %1523, %1527
  store float %1528, float addrspace(3)* %1509, align 4, !tbaa !6
  %1529 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 4
  %1530 = load float, float addrspace(3)* %1529, align 16, !tbaa !6
  %1531 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 4, i32 15), align 4, !tbaa !6
  %1532 = fmul contract float %1530, %1531
  %1533 = fsub contract float %1528, %1532
  store float %1533, float addrspace(3)* %1509, align 4, !tbaa !6
  %1534 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 5
  %1535 = load float, float addrspace(3)* %1534, align 4, !tbaa !6
  %1536 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 5, i32 15), align 4, !tbaa !6
  %1537 = fmul contract float %1535, %1536
  %1538 = fsub contract float %1533, %1537
  store float %1538, float addrspace(3)* %1509, align 4, !tbaa !6
  %1539 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 6
  %1540 = load float, float addrspace(3)* %1539, align 8, !tbaa !6
  %1541 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 6, i32 15), align 4, !tbaa !6
  %1542 = fmul contract float %1540, %1541
  %1543 = fsub contract float %1538, %1542
  store float %1543, float addrspace(3)* %1509, align 4, !tbaa !6
  %1544 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 7
  %1545 = load float, float addrspace(3)* %1544, align 4, !tbaa !6
  %1546 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 7, i32 15), align 4, !tbaa !6
  %1547 = fmul contract float %1545, %1546
  %1548 = fsub contract float %1543, %1547
  store float %1548, float addrspace(3)* %1509, align 4, !tbaa !6
  %1549 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 8
  %1550 = load float, float addrspace(3)* %1549, align 16, !tbaa !6
  %1551 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 8, i32 15), align 4, !tbaa !6
  %1552 = fmul contract float %1550, %1551
  %1553 = fsub contract float %1548, %1552
  store float %1553, float addrspace(3)* %1509, align 4, !tbaa !6
  %1554 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 9
  %1555 = load float, float addrspace(3)* %1554, align 4, !tbaa !6
  %1556 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 9, i32 15), align 4, !tbaa !6
  %1557 = fmul contract float %1555, %1556
  %1558 = fsub contract float %1553, %1557
  store float %1558, float addrspace(3)* %1509, align 4, !tbaa !6
  %1559 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 10
  %1560 = load float, float addrspace(3)* %1559, align 8, !tbaa !6
  %1561 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 10, i32 15), align 4, !tbaa !6
  %1562 = fmul contract float %1560, %1561
  %1563 = fsub contract float %1558, %1562
  store float %1563, float addrspace(3)* %1509, align 4, !tbaa !6
  %1564 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 11
  %1565 = load float, float addrspace(3)* %1564, align 4, !tbaa !6
  %1566 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 11, i32 15), align 4, !tbaa !6
  %1567 = fmul contract float %1565, %1566
  %1568 = fsub contract float %1563, %1567
  store float %1568, float addrspace(3)* %1509, align 4, !tbaa !6
  %1569 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 12
  %1570 = load float, float addrspace(3)* %1569, align 16, !tbaa !6
  %1571 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 12, i32 15), align 4, !tbaa !6
  %1572 = fmul contract float %1570, %1571
  %1573 = fsub contract float %1568, %1572
  store float %1573, float addrspace(3)* %1509, align 4, !tbaa !6
  %1574 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 13
  %1575 = load float, float addrspace(3)* %1574, align 4, !tbaa !6
  %1576 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 13, i32 15), align 4, !tbaa !6
  %1577 = fmul contract float %1575, %1576
  %1578 = fsub contract float %1573, %1577
  store float %1578, float addrspace(3)* %1509, align 4, !tbaa !6
  %1579 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 14
  %1580 = load float, float addrspace(3)* %1579, align 8, !tbaa !6
  %1581 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 14, i32 15), align 4, !tbaa !6
  %1582 = fmul contract float %1580, %1581
  %1583 = fsub contract float %1578, %1582
  store float %1583, float addrspace(3)* %1509, align 4, !tbaa !6
  %1584 = load float, float addrspace(3)* getelementptr inbounds ([16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE3dia, i32 0, i32 15, i32 15), align 4, !tbaa !6
  %1585 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 %936, i32 15
  %1586 = fdiv contract float %1583, %1584
  store float %1586, float addrspace(3)* %1585, align 4, !tbaa !6
  br label %1587

1587:                                             ; preds = %935, %304
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %6, label %1588, label %1684

1588:                                             ; preds = %1587
  %1589 = add nsw i32 %2, 1
  %1590 = mul nsw i32 %1589, %1
  %1591 = add nsw i32 %1590, %2
  %1592 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %1593 = zext i32 %1592 to i64
  %1594 = shl nuw nsw i64 %1593, 4
  %1595 = add nuw nsw i64 %5, 16
  %1596 = add nuw nsw i64 %1595, %1594
  %1597 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 1, i32 %4
  %1598 = load float, float addrspace(3)* %1597, align 4, !tbaa !6
  %1599 = sext i32 %1591 to i64
  %1600 = add nsw i64 %1596, %1599
  %1601 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1600
  store float %1598, float addrspace(1)* %1601, align 4, !tbaa !6
  %1602 = add nsw i32 %1591, %1
  %1603 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 2, i32 %4
  %1604 = load float, float addrspace(3)* %1603, align 4, !tbaa !6
  %1605 = sext i32 %1602 to i64
  %1606 = add nsw i64 %1596, %1605
  %1607 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1606
  store float %1604, float addrspace(1)* %1607, align 4, !tbaa !6
  %1608 = add nsw i32 %1602, %1
  %1609 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 3, i32 %4
  %1610 = load float, float addrspace(3)* %1609, align 4, !tbaa !6
  %1611 = sext i32 %1608 to i64
  %1612 = add nsw i64 %1596, %1611
  %1613 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1612
  store float %1610, float addrspace(1)* %1613, align 4, !tbaa !6
  %1614 = add nsw i32 %1608, %1
  %1615 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 4, i32 %4
  %1616 = load float, float addrspace(3)* %1615, align 4, !tbaa !6
  %1617 = sext i32 %1614 to i64
  %1618 = add nsw i64 %1596, %1617
  %1619 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1618
  store float %1616, float addrspace(1)* %1619, align 4, !tbaa !6
  %1620 = add nsw i32 %1614, %1
  %1621 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 5, i32 %4
  %1622 = load float, float addrspace(3)* %1621, align 4, !tbaa !6
  %1623 = sext i32 %1620 to i64
  %1624 = add nsw i64 %1596, %1623
  %1625 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1624
  store float %1622, float addrspace(1)* %1625, align 4, !tbaa !6
  %1626 = add nsw i32 %1620, %1
  %1627 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 6, i32 %4
  %1628 = load float, float addrspace(3)* %1627, align 4, !tbaa !6
  %1629 = sext i32 %1626 to i64
  %1630 = add nsw i64 %1596, %1629
  %1631 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1630
  store float %1628, float addrspace(1)* %1631, align 4, !tbaa !6
  %1632 = add nsw i32 %1626, %1
  %1633 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 7, i32 %4
  %1634 = load float, float addrspace(3)* %1633, align 4, !tbaa !6
  %1635 = sext i32 %1632 to i64
  %1636 = add nsw i64 %1596, %1635
  %1637 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1636
  store float %1634, float addrspace(1)* %1637, align 4, !tbaa !6
  %1638 = add nsw i32 %1632, %1
  %1639 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 8, i32 %4
  %1640 = load float, float addrspace(3)* %1639, align 4, !tbaa !6
  %1641 = sext i32 %1638 to i64
  %1642 = add nsw i64 %1596, %1641
  %1643 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1642
  store float %1640, float addrspace(1)* %1643, align 4, !tbaa !6
  %1644 = add nsw i32 %1638, %1
  %1645 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 9, i32 %4
  %1646 = load float, float addrspace(3)* %1645, align 4, !tbaa !6
  %1647 = sext i32 %1644 to i64
  %1648 = add nsw i64 %1596, %1647
  %1649 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1648
  store float %1646, float addrspace(1)* %1649, align 4, !tbaa !6
  %1650 = add nsw i32 %1644, %1
  %1651 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 10, i32 %4
  %1652 = load float, float addrspace(3)* %1651, align 4, !tbaa !6
  %1653 = sext i32 %1650 to i64
  %1654 = add nsw i64 %1596, %1653
  %1655 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1654
  store float %1652, float addrspace(1)* %1655, align 4, !tbaa !6
  %1656 = add nsw i32 %1650, %1
  %1657 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 11, i32 %4
  %1658 = load float, float addrspace(3)* %1657, align 4, !tbaa !6
  %1659 = sext i32 %1656 to i64
  %1660 = add nsw i64 %1596, %1659
  %1661 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1660
  store float %1658, float addrspace(1)* %1661, align 4, !tbaa !6
  %1662 = add nsw i32 %1656, %1
  %1663 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 12, i32 %4
  %1664 = load float, float addrspace(3)* %1663, align 4, !tbaa !6
  %1665 = sext i32 %1662 to i64
  %1666 = add nsw i64 %1596, %1665
  %1667 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1666
  store float %1664, float addrspace(1)* %1667, align 4, !tbaa !6
  %1668 = add nsw i32 %1662, %1
  %1669 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 13, i32 %4
  %1670 = load float, float addrspace(3)* %1669, align 4, !tbaa !6
  %1671 = sext i32 %1668 to i64
  %1672 = add nsw i64 %1596, %1671
  %1673 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1672
  store float %1670, float addrspace(1)* %1673, align 4, !tbaa !6
  %1674 = add nsw i32 %1668, %1
  %1675 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 14, i32 %4
  %1676 = load float, float addrspace(3)* %1675, align 4, !tbaa !6
  %1677 = sext i32 %1674 to i64
  %1678 = add nsw i64 %1596, %1677
  %1679 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1678
  store float %1676, float addrspace(1)* %1679, align 4, !tbaa !6
  %1680 = add nsw i32 %1674, %1
  %1681 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_row, i32 0, i32 15, i32 %4
  %1682 = sext i32 %1680 to i64
  %1683 = add nsw i64 %1596, %1682
  br label %1785

1684:                                             ; preds = %1587
  %1685 = add nsw i32 %4, -16
  %1686 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %1687 = shl i32 %1686, 4
  %1688 = add i32 %2, 16
  %1689 = add i32 %1688, %1687
  %1690 = mul i32 %1689, %1
  %1691 = add i32 %1690, %2
  %1692 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 0, i32 %1685
  %1693 = load float, float addrspace(3)* %1692, align 4, !tbaa !6
  %1694 = add nsw i32 %1691, %1685
  %1695 = sext i32 %1694 to i64
  %1696 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1695
  store float %1693, float addrspace(1)* %1696, align 4, !tbaa !6
  %1697 = add nsw i32 %1691, %1
  %1698 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 1, i32 %1685
  %1699 = load float, float addrspace(3)* %1698, align 4, !tbaa !6
  %1700 = add nsw i32 %1697, %1685
  %1701 = sext i32 %1700 to i64
  %1702 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1701
  store float %1699, float addrspace(1)* %1702, align 4, !tbaa !6
  %1703 = add nsw i32 %1697, %1
  %1704 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 2, i32 %1685
  %1705 = load float, float addrspace(3)* %1704, align 4, !tbaa !6
  %1706 = add nsw i32 %1703, %1685
  %1707 = sext i32 %1706 to i64
  %1708 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1707
  store float %1705, float addrspace(1)* %1708, align 4, !tbaa !6
  %1709 = add nsw i32 %1703, %1
  %1710 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 3, i32 %1685
  %1711 = load float, float addrspace(3)* %1710, align 4, !tbaa !6
  %1712 = add nsw i32 %1709, %1685
  %1713 = sext i32 %1712 to i64
  %1714 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1713
  store float %1711, float addrspace(1)* %1714, align 4, !tbaa !6
  %1715 = add nsw i32 %1709, %1
  %1716 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 4, i32 %1685
  %1717 = load float, float addrspace(3)* %1716, align 4, !tbaa !6
  %1718 = add nsw i32 %1715, %1685
  %1719 = sext i32 %1718 to i64
  %1720 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1719
  store float %1717, float addrspace(1)* %1720, align 4, !tbaa !6
  %1721 = add nsw i32 %1715, %1
  %1722 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 5, i32 %1685
  %1723 = load float, float addrspace(3)* %1722, align 4, !tbaa !6
  %1724 = add nsw i32 %1721, %1685
  %1725 = sext i32 %1724 to i64
  %1726 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1725
  store float %1723, float addrspace(1)* %1726, align 4, !tbaa !6
  %1727 = add nsw i32 %1721, %1
  %1728 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 6, i32 %1685
  %1729 = load float, float addrspace(3)* %1728, align 4, !tbaa !6
  %1730 = add nsw i32 %1727, %1685
  %1731 = sext i32 %1730 to i64
  %1732 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1731
  store float %1729, float addrspace(1)* %1732, align 4, !tbaa !6
  %1733 = add nsw i32 %1727, %1
  %1734 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 7, i32 %1685
  %1735 = load float, float addrspace(3)* %1734, align 4, !tbaa !6
  %1736 = add nsw i32 %1733, %1685
  %1737 = sext i32 %1736 to i64
  %1738 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1737
  store float %1735, float addrspace(1)* %1738, align 4, !tbaa !6
  %1739 = add nsw i32 %1733, %1
  %1740 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 8, i32 %1685
  %1741 = load float, float addrspace(3)* %1740, align 4, !tbaa !6
  %1742 = add nsw i32 %1739, %1685
  %1743 = sext i32 %1742 to i64
  %1744 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1743
  store float %1741, float addrspace(1)* %1744, align 4, !tbaa !6
  %1745 = add nsw i32 %1739, %1
  %1746 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 9, i32 %1685
  %1747 = load float, float addrspace(3)* %1746, align 4, !tbaa !6
  %1748 = add nsw i32 %1745, %1685
  %1749 = sext i32 %1748 to i64
  %1750 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1749
  store float %1747, float addrspace(1)* %1750, align 4, !tbaa !6
  %1751 = add nsw i32 %1745, %1
  %1752 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 10, i32 %1685
  %1753 = load float, float addrspace(3)* %1752, align 4, !tbaa !6
  %1754 = add nsw i32 %1751, %1685
  %1755 = sext i32 %1754 to i64
  %1756 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1755
  store float %1753, float addrspace(1)* %1756, align 4, !tbaa !6
  %1757 = add nsw i32 %1751, %1
  %1758 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 11, i32 %1685
  %1759 = load float, float addrspace(3)* %1758, align 4, !tbaa !6
  %1760 = add nsw i32 %1757, %1685
  %1761 = sext i32 %1760 to i64
  %1762 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1761
  store float %1759, float addrspace(1)* %1762, align 4, !tbaa !6
  %1763 = add nsw i32 %1757, %1
  %1764 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 12, i32 %1685
  %1765 = load float, float addrspace(3)* %1764, align 4, !tbaa !6
  %1766 = add nsw i32 %1763, %1685
  %1767 = sext i32 %1766 to i64
  %1768 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1767
  store float %1765, float addrspace(1)* %1768, align 4, !tbaa !6
  %1769 = add nsw i32 %1763, %1
  %1770 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 13, i32 %1685
  %1771 = load float, float addrspace(3)* %1770, align 4, !tbaa !6
  %1772 = add nsw i32 %1769, %1685
  %1773 = sext i32 %1772 to i64
  %1774 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1773
  store float %1771, float addrspace(1)* %1774, align 4, !tbaa !6
  %1775 = add nsw i32 %1769, %1
  %1776 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 14, i32 %1685
  %1777 = load float, float addrspace(3)* %1776, align 4, !tbaa !6
  %1778 = add nsw i32 %1775, %1685
  %1779 = sext i32 %1778 to i64
  %1780 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1779
  store float %1777, float addrspace(1)* %1780, align 4, !tbaa !6
  %1781 = add nsw i32 %1775, %1
  %1782 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ13lud_perimeterPfiiE8peri_col, i32 0, i32 15, i32 %1685
  %1783 = add nsw i32 %1781, %1685
  %1784 = sext i32 %1783 to i64
  br label %1785

1785:                                             ; preds = %1684, %1588
  %1786 = phi i64 [ %1784, %1684 ], [ %1683, %1588 ]
  %1787 = phi float addrspace(3)* [ %1782, %1684 ], [ %1681, %1588 ]
  %1788 = load float, float addrspace(3)* %1787, align 4, !tbaa !6
  %1789 = getelementptr inbounds float, float addrspace(1)* %0, i64 %1786
  store float %1788, float addrspace(1)* %1789, align 4, !tbaa !6
  ret void
}

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z12lud_internalPfii(float addrspace(1)* nocapture %0, i32 %1, i32 %2) local_unnamed_addr #0 {
  %4 = sext i32 %2 to i64
  %5 = tail call i32 @llvm.amdgcn.workgroup.id.y() #3
  %6 = shl i32 %5, 4
  %7 = add i32 %2, 16
  %8 = add i32 %7, %6
  %9 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %10 = shl i32 %9, 4
  %11 = add i32 %7, %10
  %12 = tail call i32 @llvm.amdgcn.workitem.id.y() #3, !range !5
  %13 = zext i32 %12 to i64
  %14 = add nsw i64 %4, %13
  %15 = sext i32 %1 to i64
  %16 = mul i64 %14, %15
  %17 = sext i32 %11 to i64
  %18 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %19 = zext i32 %18 to i64
  %20 = add nsw i64 %17, %19
  %21 = add i64 %20, %16
  %22 = getelementptr inbounds float, float addrspace(1)* %0, i64 %21
  %23 = load float, float addrspace(1)* %22, align 4, !tbaa !6
  %24 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 %12, i32 %18
  store float %23, float addrspace(3)* %24, align 4, !tbaa !6
  %25 = sext i32 %8 to i64
  %26 = add nsw i64 %25, %13
  %27 = mul i64 %26, %15
  %28 = add i64 %27, %19
  %29 = add i64 %28, %4
  %30 = getelementptr inbounds float, float addrspace(1)* %0, i64 %29
  %31 = load float, float addrspace(1)* %30, align 4, !tbaa !6
  %32 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 %18
  store float %31, float addrspace(3)* %32, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %33 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 0
  %34 = load float, float addrspace(3)* %33, align 16, !tbaa !6
  %35 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 0, i32 %18
  %36 = load float, float addrspace(3)* %35, align 4, !tbaa !6
  %37 = fmul contract float %34, %36
  %38 = fadd contract float %37, 0.000000e+00
  %39 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 1
  %40 = load float, float addrspace(3)* %39, align 4, !tbaa !6
  %41 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 1, i32 %18
  %42 = load float, float addrspace(3)* %41, align 4, !tbaa !6
  %43 = fmul contract float %40, %42
  %44 = fadd contract float %38, %43
  %45 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 2
  %46 = load float, float addrspace(3)* %45, align 8, !tbaa !6
  %47 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 2, i32 %18
  %48 = load float, float addrspace(3)* %47, align 4, !tbaa !6
  %49 = fmul contract float %46, %48
  %50 = fadd contract float %44, %49
  %51 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 3
  %52 = load float, float addrspace(3)* %51, align 4, !tbaa !6
  %53 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 3, i32 %18
  %54 = load float, float addrspace(3)* %53, align 4, !tbaa !6
  %55 = fmul contract float %52, %54
  %56 = fadd contract float %50, %55
  %57 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 4
  %58 = load float, float addrspace(3)* %57, align 16, !tbaa !6
  %59 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 4, i32 %18
  %60 = load float, float addrspace(3)* %59, align 4, !tbaa !6
  %61 = fmul contract float %58, %60
  %62 = fadd contract float %56, %61
  %63 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 5
  %64 = load float, float addrspace(3)* %63, align 4, !tbaa !6
  %65 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 5, i32 %18
  %66 = load float, float addrspace(3)* %65, align 4, !tbaa !6
  %67 = fmul contract float %64, %66
  %68 = fadd contract float %62, %67
  %69 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 6
  %70 = load float, float addrspace(3)* %69, align 8, !tbaa !6
  %71 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 6, i32 %18
  %72 = load float, float addrspace(3)* %71, align 4, !tbaa !6
  %73 = fmul contract float %70, %72
  %74 = fadd contract float %68, %73
  %75 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 7
  %76 = load float, float addrspace(3)* %75, align 4, !tbaa !6
  %77 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 7, i32 %18
  %78 = load float, float addrspace(3)* %77, align 4, !tbaa !6
  %79 = fmul contract float %76, %78
  %80 = fadd contract float %74, %79
  %81 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 8
  %82 = load float, float addrspace(3)* %81, align 16, !tbaa !6
  %83 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 8, i32 %18
  %84 = load float, float addrspace(3)* %83, align 4, !tbaa !6
  %85 = fmul contract float %82, %84
  %86 = fadd contract float %80, %85
  %87 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 9
  %88 = load float, float addrspace(3)* %87, align 4, !tbaa !6
  %89 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 9, i32 %18
  %90 = load float, float addrspace(3)* %89, align 4, !tbaa !6
  %91 = fmul contract float %88, %90
  %92 = fadd contract float %86, %91
  %93 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 10
  %94 = load float, float addrspace(3)* %93, align 8, !tbaa !6
  %95 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 10, i32 %18
  %96 = load float, float addrspace(3)* %95, align 4, !tbaa !6
  %97 = fmul contract float %94, %96
  %98 = fadd contract float %92, %97
  %99 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 11
  %100 = load float, float addrspace(3)* %99, align 4, !tbaa !6
  %101 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 11, i32 %18
  %102 = load float, float addrspace(3)* %101, align 4, !tbaa !6
  %103 = fmul contract float %100, %102
  %104 = fadd contract float %98, %103
  %105 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 12
  %106 = load float, float addrspace(3)* %105, align 16, !tbaa !6
  %107 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 12, i32 %18
  %108 = load float, float addrspace(3)* %107, align 4, !tbaa !6
  %109 = fmul contract float %106, %108
  %110 = fadd contract float %104, %109
  %111 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 13
  %112 = load float, float addrspace(3)* %111, align 4, !tbaa !6
  %113 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 13, i32 %18
  %114 = load float, float addrspace(3)* %113, align 4, !tbaa !6
  %115 = fmul contract float %112, %114
  %116 = fadd contract float %110, %115
  %117 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 14
  %118 = load float, float addrspace(3)* %117, align 8, !tbaa !6
  %119 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 14, i32 %18
  %120 = load float, float addrspace(3)* %119, align 4, !tbaa !6
  %121 = fmul contract float %118, %120
  %122 = fadd contract float %116, %121
  %123 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_col, i32 0, i32 %12, i32 15
  %124 = load float, float addrspace(3)* %123, align 4, !tbaa !6
  %125 = getelementptr inbounds [16 x [16 x float]], [16 x [16 x float]] addrspace(3)* @_ZZ12lud_internalPfiiE8peri_row, i32 0, i32 15, i32 %18
  %126 = load float, float addrspace(3)* %125, align 4, !tbaa !6
  %127 = fmul contract float %124, %126
  %128 = fadd contract float %122, %127
  %129 = add i64 %20, %27
  %130 = getelementptr inbounds float, float addrspace(1)* %0, i64 %129
  %131 = load float, float addrspace(1)* %130, align 4, !tbaa !6
  %132 = fsub contract float %131, %128
  store float %132, float addrspace(1)* %130, align 4, !tbaa !6
  ret void
}

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.y() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.y() #2

attributes #0 = { convergent norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { convergent nounwind willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i32 0, i32 1024}
!6 = !{!7, !7, i64 0}
!7 = !{!"float", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C++ TBAA"}
