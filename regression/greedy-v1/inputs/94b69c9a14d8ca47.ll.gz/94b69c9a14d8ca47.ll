; ModuleID = '/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-repro.XpJFTn/BIT32/compat.ll'
source_filename = "/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-benchmarks/benchmarks/BIT/bitonic_sort.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" = type { i8 }

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = comdat any

@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" undef, comdat, align 1
@shared = external hidden local_unnamed_addr addrspace(3) global [0 x i32], align 4

; Function Attrs: convergent norecurse nounwind
define amdgpu_kernel void @_ZL11bitonicSortPi(i32 addrspace(1)* nocapture %0) local_unnamed_addr #0 {
  %2 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %3 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %4 = shl i32 %3, 5
  %5 = add i32 %4, %2
  %6 = zext i32 %5 to i64
  %7 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %6
  %8 = load i32, i32 addrspace(1)* %7, align 4, !tbaa !6
  %9 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %2
  store i32 %8, i32 addrspace(3)* %9, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %10 = xor i32 %2, 1
  %11 = icmp ugt i32 %10, %2
  %12 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %10
  %13 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %10
  br i1 %11, label %14, label %27

14:                                               ; preds = %1
  %15 = and i32 %2, 2
  %16 = icmp eq i32 %15, 0
  br i1 %16, label %17, label %22

17:                                               ; preds = %14
  %18 = load i32, i32 addrspace(3)* %13, align 4, !tbaa !6
  %19 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  %20 = icmp slt i32 %18, %19
  br i1 %20, label %21, label %27

21:                                               ; preds = %17
  store i32 %18, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %19, i32 addrspace(3)* %13, align 4, !tbaa !6
  br label %27

22:                                               ; preds = %14
  %23 = load i32, i32 addrspace(3)* %12, align 4, !tbaa !6
  %24 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  %25 = icmp sgt i32 %23, %24
  br i1 %25, label %26, label %27

26:                                               ; preds = %22
  store i32 %23, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %24, i32 addrspace(3)* %12, align 4, !tbaa !6
  br label %27

27:                                               ; preds = %26, %22, %21, %17, %1
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %28 = and i32 %2, 4
  %29 = icmp eq i32 %28, 0
  %30 = xor i32 %2, 2
  %31 = icmp ugt i32 %30, %2
  br i1 %31, label %32, label %42

32:                                               ; preds = %27
  %33 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %30
  %34 = load i32, i32 addrspace(3)* %33, align 4, !tbaa !6
  %35 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %29, label %39, label %36

36:                                               ; preds = %32
  %37 = icmp sgt i32 %34, %35
  br i1 %37, label %38, label %42

38:                                               ; preds = %36
  store i32 %34, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %35, i32 addrspace(3)* %33, align 4, !tbaa !6
  br label %42

39:                                               ; preds = %32
  %40 = icmp slt i32 %34, %35
  br i1 %40, label %41, label %42

41:                                               ; preds = %39
  store i32 %34, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %35, i32 addrspace(3)* %33, align 4, !tbaa !6
  br label %42

42:                                               ; preds = %41, %39, %38, %36, %27
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %43 = xor i32 %2, 1
  %44 = icmp ugt i32 %43, %2
  br i1 %44, label %204, label %214

45:                                               ; preds = %214
  %46 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %217
  %47 = load i32, i32 addrspace(3)* %46, align 4, !tbaa !6
  %48 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %216, label %52, label %49

49:                                               ; preds = %45
  %50 = icmp sgt i32 %47, %48
  br i1 %50, label %51, label %55

51:                                               ; preds = %49
  store i32 %47, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %48, i32 addrspace(3)* %46, align 4, !tbaa !6
  br label %55

52:                                               ; preds = %45
  %53 = icmp slt i32 %47, %48
  br i1 %53, label %54, label %55

54:                                               ; preds = %52
  store i32 %47, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %48, i32 addrspace(3)* %46, align 4, !tbaa !6
  br label %55

55:                                               ; preds = %214, %54, %52, %51, %49
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %56 = xor i32 %2, 2
  %57 = icmp ugt i32 %56, %2
  br i1 %57, label %176, label %186

58:                                               ; preds = %199
  %59 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %202
  %60 = load i32, i32 addrspace(3)* %59, align 4, !tbaa !6
  %61 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %201, label %65, label %62

62:                                               ; preds = %58
  %63 = icmp sgt i32 %60, %61
  br i1 %63, label %64, label %68

64:                                               ; preds = %62
  store i32 %60, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %61, i32 addrspace(3)* %59, align 4, !tbaa !6
  br label %68

65:                                               ; preds = %58
  %66 = icmp slt i32 %60, %61
  br i1 %66, label %67, label %68

67:                                               ; preds = %65
  store i32 %60, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %61, i32 addrspace(3)* %59, align 4, !tbaa !6
  br label %68

68:                                               ; preds = %199, %67, %65, %64, %62
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %69 = xor i32 %2, 4
  %70 = icmp ugt i32 %69, %2
  br i1 %70, label %135, label %145

71:                                               ; preds = %171
  %72 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %174
  %73 = load i32, i32 addrspace(3)* %72, align 4, !tbaa !6
  %74 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %173, label %78, label %75

75:                                               ; preds = %71
  %76 = icmp sgt i32 %73, %74
  br i1 %76, label %77, label %81

77:                                               ; preds = %75
  store i32 %73, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %74, i32 addrspace(3)* %72, align 4, !tbaa !6
  br label %81

78:                                               ; preds = %71
  %79 = icmp slt i32 %73, %74
  br i1 %79, label %80, label %81

80:                                               ; preds = %78
  store i32 %73, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %74, i32 addrspace(3)* %72, align 4, !tbaa !6
  br label %81

81:                                               ; preds = %171, %80, %78, %77, %75
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %82 = xor i32 %2, 8
  %83 = icmp ugt i32 %82, %2
  br i1 %83, label %84, label %94

84:                                               ; preds = %81
  %85 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %82
  %86 = load i32, i32 addrspace(3)* %85, align 4, !tbaa !6
  %87 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %173, label %91, label %88

88:                                               ; preds = %84
  %89 = icmp sgt i32 %86, %87
  br i1 %89, label %90, label %94

90:                                               ; preds = %88
  store i32 %86, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %87, i32 addrspace(3)* %85, align 4, !tbaa !6
  br label %94

91:                                               ; preds = %84
  %92 = icmp slt i32 %86, %87
  br i1 %92, label %93, label %94

93:                                               ; preds = %91
  store i32 %86, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %87, i32 addrspace(3)* %85, align 4, !tbaa !6
  br label %94

94:                                               ; preds = %93, %91, %90, %88, %81
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %95 = xor i32 %2, 4
  %96 = icmp ugt i32 %95, %2
  br i1 %96, label %97, label %107

97:                                               ; preds = %94
  %98 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %95
  %99 = load i32, i32 addrspace(3)* %98, align 4, !tbaa !6
  %100 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %173, label %104, label %101

101:                                              ; preds = %97
  %102 = icmp sgt i32 %99, %100
  br i1 %102, label %103, label %107

103:                                              ; preds = %101
  store i32 %99, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %100, i32 addrspace(3)* %98, align 4, !tbaa !6
  br label %107

104:                                              ; preds = %97
  %105 = icmp slt i32 %99, %100
  br i1 %105, label %106, label %107

106:                                              ; preds = %104
  store i32 %99, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %100, i32 addrspace(3)* %98, align 4, !tbaa !6
  br label %107

107:                                              ; preds = %106, %104, %103, %101, %94
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %108 = xor i32 %2, 2
  %109 = icmp ugt i32 %108, %2
  br i1 %109, label %110, label %120

110:                                              ; preds = %107
  %111 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %108
  %112 = load i32, i32 addrspace(3)* %111, align 4, !tbaa !6
  %113 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %173, label %117, label %114

114:                                              ; preds = %110
  %115 = icmp sgt i32 %112, %113
  br i1 %115, label %116, label %120

116:                                              ; preds = %114
  store i32 %112, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %113, i32 addrspace(3)* %111, align 4, !tbaa !6
  br label %120

117:                                              ; preds = %110
  %118 = icmp slt i32 %112, %113
  br i1 %118, label %119, label %120

119:                                              ; preds = %117
  store i32 %112, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %113, i32 addrspace(3)* %111, align 4, !tbaa !6
  br label %120

120:                                              ; preds = %119, %117, %116, %114, %107
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %121 = xor i32 %2, 1
  %122 = icmp ugt i32 %121, %2
  br i1 %122, label %123, label %133

123:                                              ; preds = %120
  %124 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %121
  %125 = load i32, i32 addrspace(3)* %124, align 4, !tbaa !6
  %126 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %173, label %130, label %127

127:                                              ; preds = %123
  %128 = icmp sgt i32 %125, %126
  br i1 %128, label %129, label %133

129:                                              ; preds = %127
  store i32 %125, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %126, i32 addrspace(3)* %124, align 4, !tbaa !6
  br label %133

130:                                              ; preds = %123
  %131 = icmp slt i32 %125, %126
  br i1 %131, label %132, label %133

132:                                              ; preds = %130
  store i32 %125, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %126, i32 addrspace(3)* %124, align 4, !tbaa !6
  br label %133

133:                                              ; preds = %132, %130, %129, %127, %120
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %134 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %134, i32 addrspace(1)* %7, align 4, !tbaa !6
  ret void

135:                                              ; preds = %68
  %136 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %69
  %137 = load i32, i32 addrspace(3)* %136, align 4, !tbaa !6
  %138 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %201, label %142, label %139

139:                                              ; preds = %135
  %140 = icmp sgt i32 %137, %138
  br i1 %140, label %141, label %145

141:                                              ; preds = %139
  store i32 %137, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %138, i32 addrspace(3)* %136, align 4, !tbaa !6
  br label %145

142:                                              ; preds = %135
  %143 = icmp slt i32 %137, %138
  br i1 %143, label %144, label %145

144:                                              ; preds = %142
  store i32 %137, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %138, i32 addrspace(3)* %136, align 4, !tbaa !6
  br label %145

145:                                              ; preds = %144, %142, %141, %139, %68
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %146 = xor i32 %2, 2
  %147 = icmp ugt i32 %146, %2
  br i1 %147, label %148, label %158

148:                                              ; preds = %145
  %149 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %146
  %150 = load i32, i32 addrspace(3)* %149, align 4, !tbaa !6
  %151 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %201, label %155, label %152

152:                                              ; preds = %148
  %153 = icmp sgt i32 %150, %151
  br i1 %153, label %154, label %158

154:                                              ; preds = %152
  store i32 %150, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %151, i32 addrspace(3)* %149, align 4, !tbaa !6
  br label %158

155:                                              ; preds = %148
  %156 = icmp slt i32 %150, %151
  br i1 %156, label %157, label %158

157:                                              ; preds = %155
  store i32 %150, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %151, i32 addrspace(3)* %149, align 4, !tbaa !6
  br label %158

158:                                              ; preds = %157, %155, %154, %152, %145
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %159 = xor i32 %2, 1
  %160 = icmp ugt i32 %159, %2
  br i1 %160, label %161, label %171

161:                                              ; preds = %158
  %162 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %159
  %163 = load i32, i32 addrspace(3)* %162, align 4, !tbaa !6
  %164 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %201, label %168, label %165

165:                                              ; preds = %161
  %166 = icmp sgt i32 %163, %164
  br i1 %166, label %167, label %171

167:                                              ; preds = %165
  store i32 %163, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %164, i32 addrspace(3)* %162, align 4, !tbaa !6
  br label %171

168:                                              ; preds = %161
  %169 = icmp slt i32 %163, %164
  br i1 %169, label %170, label %171

170:                                              ; preds = %168
  store i32 %163, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %164, i32 addrspace(3)* %162, align 4, !tbaa !6
  br label %171

171:                                              ; preds = %170, %168, %167, %165, %158
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %172 = and i32 %2, 32
  %173 = icmp eq i32 %172, 0
  %174 = xor i32 %2, 16
  %175 = icmp ugt i32 %174, %2
  br i1 %175, label %71, label %81

176:                                              ; preds = %55
  %177 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %56
  %178 = load i32, i32 addrspace(3)* %177, align 4, !tbaa !6
  %179 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %216, label %183, label %180

180:                                              ; preds = %176
  %181 = icmp sgt i32 %178, %179
  br i1 %181, label %182, label %186

182:                                              ; preds = %180
  store i32 %178, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %179, i32 addrspace(3)* %177, align 4, !tbaa !6
  br label %186

183:                                              ; preds = %176
  %184 = icmp slt i32 %178, %179
  br i1 %184, label %185, label %186

185:                                              ; preds = %183
  store i32 %178, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %179, i32 addrspace(3)* %177, align 4, !tbaa !6
  br label %186

186:                                              ; preds = %185, %183, %182, %180, %55
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %187 = xor i32 %2, 1
  %188 = icmp ugt i32 %187, %2
  br i1 %188, label %189, label %199

189:                                              ; preds = %186
  %190 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %187
  %191 = load i32, i32 addrspace(3)* %190, align 4, !tbaa !6
  %192 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %216, label %196, label %193

193:                                              ; preds = %189
  %194 = icmp sgt i32 %191, %192
  br i1 %194, label %195, label %199

195:                                              ; preds = %193
  store i32 %191, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %192, i32 addrspace(3)* %190, align 4, !tbaa !6
  br label %199

196:                                              ; preds = %189
  %197 = icmp slt i32 %191, %192
  br i1 %197, label %198, label %199

198:                                              ; preds = %196
  store i32 %191, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %192, i32 addrspace(3)* %190, align 4, !tbaa !6
  br label %199

199:                                              ; preds = %198, %196, %195, %193, %186
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %200 = and i32 %2, 16
  %201 = icmp eq i32 %200, 0
  %202 = xor i32 %2, 8
  %203 = icmp ugt i32 %202, %2
  br i1 %203, label %58, label %68

204:                                              ; preds = %42
  %205 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @shared, i32 0, i32 %43
  %206 = load i32, i32 addrspace(3)* %205, align 4, !tbaa !6
  %207 = load i32, i32 addrspace(3)* %9, align 4, !tbaa !6
  br i1 %29, label %211, label %208

208:                                              ; preds = %204
  %209 = icmp sgt i32 %206, %207
  br i1 %209, label %210, label %214

210:                                              ; preds = %208
  store i32 %206, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %207, i32 addrspace(3)* %205, align 4, !tbaa !6
  br label %214

211:                                              ; preds = %204
  %212 = icmp slt i32 %206, %207
  br i1 %212, label %213, label %214

213:                                              ; preds = %211
  store i32 %206, i32 addrspace(3)* %9, align 4, !tbaa !6
  store i32 %207, i32 addrspace(3)* %205, align 4, !tbaa !6
  br label %214

214:                                              ; preds = %213, %211, %210, %208, %42
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %215 = and i32 %2, 8
  %216 = icmp eq i32 %215, 0
  %217 = xor i32 %2, 4
  %218 = icmp ugt i32 %217, %2
  br i1 %218, label %45, label %55
}

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

attributes #0 = { convergent norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { convergent nounwind willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i32 0, i32 1024}
!6 = !{!7, !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C++ TBAA"}
