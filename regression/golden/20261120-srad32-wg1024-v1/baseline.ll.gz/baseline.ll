; ModuleID = '/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-repro.XpJFTn/SRAD32/compat.ll'
source_filename = "/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-benchmarks/benchmarks/SRAD/srad.hip.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_GridDim>::Y" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_GridDim>::X" = type { i8 }

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1yE = comdat any

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1yE = comdat any

$_ZN17__HIP_CoordinatesI13__HIP_GridDimE1yE = comdat any

$_ZN17__HIP_CoordinatesI13__HIP_GridDimE1xE = comdat any

@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1yE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1yE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y" undef, comdat, align 1
@_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16
@_ZZ11srad_cuda_1PfS_S_S_S_S_iifE11temp_result = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16
@_ZZ11srad_cuda_1PfS_S_S_S_S_iifE5north = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16
@_ZZ11srad_cuda_1PfS_S_S_S_S_iifE5south = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16
@_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4east = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16
@_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4west = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16
@_ZN17__HIP_CoordinatesI13__HIP_GridDimE1yE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_GridDim>::Y" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI13__HIP_GridDimE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_GridDim>::X" undef, comdat, align 1
@_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE7south_c = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16
@_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE6east_c = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16
@_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE11c_cuda_temp = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16
@_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE13c_cuda_result = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16
@_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE4temp = internal unnamed_addr addrspace(3) global [32 x [32 x float]] undef, align 16

; Function Attrs: convergent norecurse nounwind willreturn
define protected amdgpu_kernel void @_Z11srad_cuda_1PfS_S_S_S_S_iif(float addrspace(1)* nocapture %0, float addrspace(1)* nocapture %1, float addrspace(1)* nocapture %2, float addrspace(1)* nocapture %3, float addrspace(1)* nocapture readonly %4, float addrspace(1)* nocapture %5, i32 %6, i32 %7, float %8) local_unnamed_addr #0 {
  %10 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %11 = tail call i32 @llvm.amdgcn.workgroup.id.y() #3
  %12 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %13 = tail call i32 @llvm.amdgcn.workitem.id.y() #3, !range !5
  %14 = shl nsw i32 %6, 5
  %15 = mul i32 %14, %11
  %16 = shl nsw i32 %10, 5
  %17 = add nsw i32 %15, %16
  %18 = mul nsw i32 %13, %6
  %19 = add nsw i32 %17, %18
  %20 = add nsw i32 %19, %12
  %21 = add i32 %17, %12
  %22 = sub i32 %21, %6
  %23 = add i32 %21, %14
  %24 = add nsw i32 %19, -1
  %25 = add nsw i32 %19, 32
  %26 = icmp sgt i32 %22, -1
  %27 = mul nsw i32 %7, %6
  %28 = icmp slt i32 %22, %27
  %29 = and i1 %26, %28
  br i1 %29, label %30, label %35

30:                                               ; preds = %9
  %31 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE5north, i32 0, i32 %13, i32 %12
  %32 = zext i32 %22 to i64
  %33 = getelementptr inbounds float, float addrspace(1)* %4, i64 %32
  %34 = load float, float addrspace(1)* %33, align 4, !tbaa !6
  store float %34, float addrspace(3)* %31, align 4, !tbaa !6
  br label %35

35:                                               ; preds = %30, %9
  %36 = icmp sgt i32 %23, -1
  %37 = icmp slt i32 %23, %27
  %38 = and i1 %36, %37
  br i1 %38, label %39, label %44

39:                                               ; preds = %35
  %40 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE5south, i32 0, i32 %13, i32 %12
  %41 = zext i32 %23 to i64
  %42 = getelementptr inbounds float, float addrspace(1)* %4, i64 %41
  %43 = load float, float addrspace(1)* %42, align 4, !tbaa !6
  store float %43, float addrspace(3)* %40, align 4, !tbaa !6
  br label %44

44:                                               ; preds = %39, %35
  %45 = icmp eq i32 %11, 0
  br i1 %45, label %46, label %49

46:                                               ; preds = %44
  %47 = add nsw i32 %16, %12
  %48 = sext i32 %47 to i64
  br label %71

49:                                               ; preds = %44
  %50 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %51 = getelementptr inbounds i8, i8 addrspace(4)* %50, i64 16
  %52 = bitcast i8 addrspace(4)* %51 to i32 addrspace(4)*
  %53 = load i32, i32 addrspace(4)* %52, align 8, !tbaa !10
  %54 = getelementptr i8, i8 addrspace(4)* %50, i64 6
  %55 = bitcast i8 addrspace(4)* %54 to i16 addrspace(4)*
  %56 = load i16, i16 addrspace(4)* %55, align 2, !range !19, !invariant.load !20
  %57 = zext i16 %56 to i32
  %58 = udiv i32 %53, %57
  %59 = mul i32 %58, %57
  %60 = icmp ugt i32 %53, %59
  %61 = zext i1 %60 to i32
  %62 = add i32 %58, -1
  %63 = add i32 %62, %61
  %64 = icmp eq i32 %11, %63
  br i1 %64, label %65, label %77

65:                                               ; preds = %49
  %66 = mul nsw i32 %6, 31
  %67 = add i32 %16, %12
  %68 = add i32 %67, %66
  %69 = add i32 %68, %15
  %70 = zext i32 %69 to i64
  br label %71

71:                                               ; preds = %65, %46
  %72 = phi i64 [ %70, %65 ], [ %48, %46 ]
  %73 = phi [32 x [32 x float]] addrspace(3)* [ @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE5south, %65 ], [ @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE5north, %46 ]
  %74 = getelementptr inbounds float, float addrspace(1)* %4, i64 %72
  %75 = load float, float addrspace(1)* %74, align 4, !tbaa !6
  %76 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* %73, i32 0, i32 %13, i32 %12
  store float %75, float addrspace(3)* %76, align 4, !tbaa !6
  br label %77

77:                                               ; preds = %71, %49
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %78 = icmp slt i32 %19, 1
  %79 = icmp sgt i32 %19, %27
  %80 = or i1 %78, %79
  br i1 %80, label %86, label %81

81:                                               ; preds = %77
  %82 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4west, i32 0, i32 %13, i32 %12
  %83 = sext i32 %24 to i64
  %84 = getelementptr inbounds float, float addrspace(1)* %4, i64 %83
  %85 = load float, float addrspace(1)* %84, align 4, !tbaa !6
  store float %85, float addrspace(3)* %82, align 4, !tbaa !6
  br label %86

86:                                               ; preds = %81, %77
  %87 = icmp sgt i32 %19, -33
  %88 = icmp slt i32 %25, %27
  %89 = and i1 %87, %88
  br i1 %89, label %90, label %95

90:                                               ; preds = %86
  %91 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4east, i32 0, i32 %13, i32 %12
  %92 = sext i32 %25 to i64
  %93 = getelementptr inbounds float, float addrspace(1)* %4, i64 %92
  %94 = load float, float addrspace(1)* %93, align 4, !tbaa !6
  store float %94, float addrspace(3)* %91, align 4, !tbaa !6
  br label %95

95:                                               ; preds = %90, %86
  %96 = icmp eq i32 %10, 0
  br i1 %96, label %97, label %103

97:                                               ; preds = %95
  %98 = add nsw i32 %15, %18
  %99 = sext i32 %98 to i64
  %100 = getelementptr inbounds float, float addrspace(1)* %4, i64 %99
  %101 = load float, float addrspace(1)* %100, align 4, !tbaa !6
  %102 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4west, i32 0, i32 %13, i32 %12
  store float %101, float addrspace(3)* %102, align 4, !tbaa !6
  br label %128

103:                                              ; preds = %95
  %104 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %105 = getelementptr inbounds i8, i8 addrspace(4)* %104, i64 12
  %106 = bitcast i8 addrspace(4)* %105 to i32 addrspace(4)*
  %107 = load i32, i32 addrspace(4)* %106, align 4, !tbaa !21
  %108 = getelementptr i8, i8 addrspace(4)* %104, i64 4
  %109 = bitcast i8 addrspace(4)* %108 to i16 addrspace(4)*
  %110 = load i16, i16 addrspace(4)* %109, align 4, !range !19, !invariant.load !20
  %111 = zext i16 %110 to i32
  %112 = udiv i32 %107, %111
  %113 = mul i32 %112, %111
  %114 = icmp ugt i32 %107, %113
  %115 = zext i1 %114 to i32
  %116 = add i32 %112, %115
  %117 = add i32 %116, -1
  %118 = icmp eq i32 %10, %117
  br i1 %118, label %119, label %128

119:                                              ; preds = %103
  %120 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4east, i32 0, i32 %13, i32 %12
  %121 = shl i32 %116, 5
  %122 = add i32 %15, %18
  %123 = add i32 %122, -1
  %124 = add i32 %123, %121
  %125 = zext i32 %124 to i64
  %126 = getelementptr inbounds float, float addrspace(1)* %4, i64 %125
  %127 = load float, float addrspace(1)* %126, align 4, !tbaa !6
  store float %127, float addrspace(3)* %120, align 4, !tbaa !6
  br label %128

128:                                              ; preds = %119, %103, %97
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %129 = sext i32 %20 to i64
  %130 = getelementptr inbounds float, float addrspace(1)* %4, i64 %129
  %131 = load float, float addrspace(1)* %130, align 4, !tbaa !6
  %132 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 %13, i32 %12
  store float %131, float addrspace(3)* %132, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %133 = load float, float addrspace(3)* %132, align 4, !tbaa !6
  %134 = icmp eq i32 %13, 0
  %135 = icmp eq i32 %12, 0
  %136 = or i32 %13, %12
  %137 = icmp eq i32 %136, 0
  br i1 %137, label %138, label %143

138:                                              ; preds = %128
  %139 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE5north, i32 0, i32 %13, i32 %12
  %140 = getelementptr [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 1, i32 %12
  %141 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4west, i32 0, i32 %13, i32 %12
  %142 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 %13, i32 1
  br label %191

143:                                              ; preds = %128
  %144 = icmp eq i32 %12, 31
  %145 = and i1 %134, %144
  br i1 %145, label %191, label %146

146:                                              ; preds = %143
  %147 = icmp eq i32 %13, 31
  %148 = and i1 %147, %144
  br i1 %148, label %191, label %149

149:                                              ; preds = %146
  %150 = and i1 %147, %135
  br i1 %150, label %191, label %151

151:                                              ; preds = %149
  br i1 %134, label %152, label %159

152:                                              ; preds = %151
  %153 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE5north, i32 0, i32 0, i32 %12
  %154 = getelementptr [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 1, i32 %12
  %155 = add nsw i32 %12, -1
  %156 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 0, i32 %155
  %157 = add nuw nsw i32 %12, 1
  %158 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 0, i32 %157
  br label %191

159:                                              ; preds = %151
  br i1 %144, label %160, label %167

160:                                              ; preds = %159
  %161 = add nsw i32 %13, -1
  %162 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 %161, i32 31
  %163 = add nuw nsw i32 %13, 1
  %164 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 %163, i32 31
  %165 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 %13, i32 30
  %166 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4east, i32 0, i32 %13, i32 31
  br label %191

167:                                              ; preds = %159
  br i1 %147, label %168, label %175

168:                                              ; preds = %167
  %169 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 30, i32 %12
  %170 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE5south, i32 0, i32 31, i32 %12
  %171 = add nsw i32 %12, -1
  %172 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 31, i32 %171
  %173 = add nuw nsw i32 %12, 1
  %174 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 31, i32 %173
  br label %191

175:                                              ; preds = %167
  %176 = add nsw i32 %13, -1
  br i1 %135, label %177, label %183

177:                                              ; preds = %175
  %178 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 %176, i32 0
  %179 = add nuw nsw i32 %13, 1
  %180 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 %179, i32 0
  %181 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4west, i32 0, i32 %13, i32 0
  %182 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 %13, i32 1
  br label %191

183:                                              ; preds = %175
  %184 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 %176, i32 %12
  %185 = add nuw nsw i32 %13, 1
  %186 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 %185, i32 %12
  %187 = add nsw i32 %12, -1
  %188 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 %13, i32 %187
  %189 = add nuw nsw i32 %12, 1
  %190 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 %13, i32 %189
  br label %191

191:                                              ; preds = %183, %177, %168, %160, %152, %149, %146, %143, %138
  %192 = phi float addrspace(3)* [ %140, %138 ], [ %154, %152 ], [ %164, %160 ], [ %170, %168 ], [ %180, %177 ], [ %186, %183 ], [ getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 1, i32 31), %143 ], [ getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE5south, i32 0, i32 31, i32 31), %146 ], [ getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE5south, i32 0, i32 31, i32 0), %149 ]
  %193 = phi float addrspace(3)* [ %142, %138 ], [ %158, %152 ], [ %166, %160 ], [ %174, %168 ], [ %182, %177 ], [ %190, %183 ], [ getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4east, i32 0, i32 0, i32 31), %143 ], [ getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4east, i32 0, i32 31, i32 31), %146 ], [ getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 31, i32 1), %149 ]
  %194 = phi float addrspace(3)* [ %141, %138 ], [ %156, %152 ], [ %165, %160 ], [ %172, %168 ], [ %181, %177 ], [ %188, %183 ], [ getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 0, i32 30), %143 ], [ getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 31, i32 30), %146 ], [ getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4west, i32 0, i32 31, i32 0), %149 ]
  %195 = phi float addrspace(3)* [ %139, %138 ], [ %153, %152 ], [ %162, %160 ], [ %169, %168 ], [ %178, %177 ], [ %184, %183 ], [ getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE5north, i32 0, i32 0, i32 31), %143 ], [ getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 30, i32 31), %146 ], [ getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE4temp, i32 0, i32 30, i32 0), %149 ]
  %196 = load float, float addrspace(3)* %195, align 4, !tbaa !6
  %197 = fsub contract float %196, %133
  %198 = load float, float addrspace(3)* %194, align 4, !tbaa !6
  %199 = fsub contract float %198, %133
  %200 = load float, float addrspace(3)* %193, align 4, !tbaa !6
  %201 = fsub contract float %200, %133
  %202 = load float, float addrspace(3)* %192, align 4, !tbaa !6
  %203 = fsub contract float %202, %133
  %204 = fmul contract float %197, %197
  %205 = fmul contract float %203, %203
  %206 = fadd contract float %204, %205
  %207 = fmul contract float %199, %199
  %208 = fadd contract float %207, %206
  %209 = fmul contract float %201, %201
  %210 = fadd contract float %209, %208
  %211 = fmul contract float %133, %133
  %212 = fdiv contract float %210, %211
  %213 = fadd contract float %197, %203
  %214 = fadd contract float %199, %213
  %215 = fadd contract float %201, %214
  %216 = fdiv contract float %215, %133
  %217 = fpext float %212 to double
  %218 = fmul contract double %217, 5.000000e-01
  %219 = fmul contract float %216, %216
  %220 = fpext float %219 to double
  %221 = fmul contract double %220, 6.250000e-02
  %222 = fsub contract double %218, %221
  %223 = fptrunc double %222 to float
  %224 = fpext float %216 to double
  %225 = fmul contract double %224, 2.500000e-01
  %226 = fadd contract double %225, 1.000000e+00
  %227 = fptrunc double %226 to float
  %228 = fmul contract float %227, %227
  %229 = fdiv contract float %223, %228
  %230 = fsub contract float %229, %8
  %231 = fadd contract float %8, 1.000000e+00
  %232 = fmul contract float %231, %8
  %233 = fdiv contract float %230, %232
  %234 = fpext float %233 to double
  %235 = fadd contract double %234, 1.000000e+00
  %236 = fdiv contract double 1.000000e+00, %235
  %237 = fptrunc double %236 to float
  %238 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_1PfS_S_S_S_S_iifE11temp_result, i32 0, i32 %13, i32 %12
  store float %237, float addrspace(3)* %238, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %239 = load float, float addrspace(3)* %238, align 4, !tbaa !6
  %240 = getelementptr inbounds float, float addrspace(1)* %5, i64 %129
  store float %239, float addrspace(1)* %240, align 4, !tbaa !6
  %241 = getelementptr inbounds float, float addrspace(1)* %0, i64 %129
  store float %201, float addrspace(1)* %241, align 4, !tbaa !6
  %242 = getelementptr inbounds float, float addrspace(1)* %1, i64 %129
  store float %199, float addrspace(1)* %242, align 4, !tbaa !6
  %243 = getelementptr inbounds float, float addrspace(1)* %3, i64 %129
  store float %203, float addrspace(1)* %243, align 4, !tbaa !6
  %244 = getelementptr inbounds float, float addrspace(1)* %2, i64 %129
  store float %197, float addrspace(1)* %244, align 4, !tbaa !6
  ret void
}

; Function Attrs: convergent norecurse nounwind willreturn
define protected amdgpu_kernel void @_Z11srad_cuda_2PfS_S_S_S_S_iiff(float addrspace(1)* nocapture readonly %0, float addrspace(1)* nocapture readonly %1, float addrspace(1)* nocapture readonly %2, float addrspace(1)* nocapture readonly %3, float addrspace(1)* nocapture %4, float addrspace(1)* nocapture readonly %5, i32 %6, i32 %7, float %8, float %9) local_unnamed_addr #0 {
  %11 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %12 = tail call i32 @llvm.amdgcn.workgroup.id.y() #3
  %13 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %14 = tail call i32 @llvm.amdgcn.workitem.id.y() #3, !range !5
  %15 = shl nsw i32 %6, 5
  %16 = mul i32 %15, %12
  %17 = shl nsw i32 %11, 5
  %18 = add nsw i32 %16, %17
  %19 = mul nsw i32 %14, %6
  %20 = add nsw i32 %18, %19
  %21 = add nsw i32 %20, %13
  %22 = add i32 %15, %13
  %23 = add i32 %22, %18
  %24 = add nsw i32 %20, 32
  %25 = sext i32 %21 to i64
  %26 = getelementptr inbounds float, float addrspace(1)* %4, i64 %25
  %27 = load float, float addrspace(1)* %26, align 4, !tbaa !6
  %28 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE4temp, i32 0, i32 %14, i32 %13
  store float %27, float addrspace(3)* %28, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %29 = icmp sgt i32 %23, -1
  %30 = mul nsw i32 %7, %6
  %31 = icmp slt i32 %23, %30
  %32 = and i1 %29, %31
  br i1 %32, label %33, label %38

33:                                               ; preds = %10
  %34 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE7south_c, i32 0, i32 %14, i32 %13
  %35 = zext i32 %23 to i64
  %36 = getelementptr inbounds float, float addrspace(1)* %5, i64 %35
  %37 = load float, float addrspace(1)* %36, align 4, !tbaa !6
  store float %37, float addrspace(3)* %34, align 4, !tbaa !6
  br label %38

38:                                               ; preds = %33, %10
  %39 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %40 = getelementptr inbounds i8, i8 addrspace(4)* %39, i64 16
  %41 = bitcast i8 addrspace(4)* %40 to i32 addrspace(4)*
  %42 = load i32, i32 addrspace(4)* %41, align 8, !tbaa !10
  %43 = getelementptr i8, i8 addrspace(4)* %39, i64 6
  %44 = bitcast i8 addrspace(4)* %43 to i16 addrspace(4)*
  %45 = load i16, i16 addrspace(4)* %44, align 2, !range !19, !invariant.load !20
  %46 = zext i16 %45 to i32
  %47 = udiv i32 %42, %46
  %48 = mul i32 %47, %46
  %49 = icmp ugt i32 %42, %48
  %50 = zext i1 %49 to i32
  %51 = add i32 %47, -1
  %52 = add i32 %51, %50
  %53 = icmp eq i32 %12, %52
  br i1 %53, label %54, label %63

54:                                               ; preds = %38
  %55 = mul nsw i32 %6, 31
  %56 = add i32 %17, %13
  %57 = add i32 %56, %55
  %58 = add i32 %57, %16
  %59 = zext i32 %58 to i64
  %60 = getelementptr inbounds float, float addrspace(1)* %5, i64 %59
  %61 = load float, float addrspace(1)* %60, align 4, !tbaa !6
  %62 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE7south_c, i32 0, i32 %14, i32 %13
  store float %61, float addrspace(3)* %62, align 4, !tbaa !6
  br label %63

63:                                               ; preds = %54, %38
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %64 = icmp sgt i32 %20, -33
  %65 = icmp slt i32 %24, %30
  %66 = and i1 %64, %65
  br i1 %66, label %67, label %72

67:                                               ; preds = %63
  %68 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE6east_c, i32 0, i32 %14, i32 %13
  %69 = sext i32 %24 to i64
  %70 = getelementptr inbounds float, float addrspace(1)* %5, i64 %69
  %71 = load float, float addrspace(1)* %70, align 4, !tbaa !6
  store float %71, float addrspace(3)* %68, align 4, !tbaa !6
  br label %72

72:                                               ; preds = %67, %63
  %73 = getelementptr inbounds i8, i8 addrspace(4)* %39, i64 12
  %74 = bitcast i8 addrspace(4)* %73 to i32 addrspace(4)*
  %75 = load i32, i32 addrspace(4)* %74, align 4, !tbaa !21
  %76 = getelementptr i8, i8 addrspace(4)* %39, i64 4
  %77 = bitcast i8 addrspace(4)* %76 to i16 addrspace(4)*
  %78 = load i16, i16 addrspace(4)* %77, align 4, !range !19, !invariant.load !20
  %79 = zext i16 %78 to i32
  %80 = udiv i32 %75, %79
  %81 = mul i32 %80, %79
  %82 = icmp ugt i32 %75, %81
  %83 = zext i1 %82 to i32
  %84 = add i32 %80, %83
  %85 = add i32 %84, -1
  %86 = icmp eq i32 %11, %85
  br i1 %86, label %87, label %96

87:                                               ; preds = %72
  %88 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE6east_c, i32 0, i32 %14, i32 %13
  %89 = shl i32 %84, 5
  %90 = add i32 %19, -1
  %91 = add i32 %90, %16
  %92 = add i32 %91, %89
  %93 = zext i32 %92 to i64
  %94 = getelementptr inbounds float, float addrspace(1)* %5, i64 %93
  %95 = load float, float addrspace(1)* %94, align 4, !tbaa !6
  store float %95, float addrspace(3)* %88, align 4, !tbaa !6
  br label %96

96:                                               ; preds = %87, %72
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %97 = getelementptr inbounds float, float addrspace(1)* %5, i64 %25
  %98 = load float, float addrspace(1)* %97, align 4, !tbaa !6
  %99 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE11c_cuda_temp, i32 0, i32 %14, i32 %13
  store float %98, float addrspace(3)* %99, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %100 = load float, float addrspace(3)* %99, align 4, !tbaa !6
  %101 = icmp eq i32 %14, 31
  %102 = icmp eq i32 %13, 31
  %103 = and i1 %101, %102
  br i1 %103, label %119, label %104

104:                                              ; preds = %96
  br i1 %102, label %105, label %109

105:                                              ; preds = %104
  %106 = add nuw nsw i32 %14, 1
  %107 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE11c_cuda_temp, i32 0, i32 %106, i32 31
  %108 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE6east_c, i32 0, i32 %14, i32 31
  br label %119

109:                                              ; preds = %104
  br i1 %101, label %110, label %114

110:                                              ; preds = %109
  %111 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE7south_c, i32 0, i32 31, i32 %13
  %112 = add nuw nsw i32 %13, 1
  %113 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE11c_cuda_temp, i32 0, i32 31, i32 %112
  br label %119

114:                                              ; preds = %109
  %115 = add nuw nsw i32 %14, 1
  %116 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE11c_cuda_temp, i32 0, i32 %115, i32 %13
  %117 = add nuw nsw i32 %13, 1
  %118 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE11c_cuda_temp, i32 0, i32 %14, i32 %117
  br label %119

119:                                              ; preds = %114, %110, %105, %96
  %120 = phi float addrspace(3)* [ %107, %105 ], [ %111, %110 ], [ %116, %114 ], [ getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE7south_c, i32 0, i32 31, i32 31), %96 ]
  %121 = phi float addrspace(3)* [ %108, %105 ], [ %113, %110 ], [ %118, %114 ], [ getelementptr inbounds ([32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE6east_c, i32 0, i32 31, i32 31), %96 ]
  %122 = load float, float addrspace(3)* %121, align 4, !tbaa !6
  %123 = load float, float addrspace(3)* %120, align 4, !tbaa !6
  %124 = getelementptr inbounds float, float addrspace(1)* %2, i64 %25
  %125 = load float, float addrspace(1)* %124, align 4, !tbaa !6
  %126 = fmul contract float %100, %125
  %127 = getelementptr inbounds float, float addrspace(1)* %3, i64 %25
  %128 = load float, float addrspace(1)* %127, align 4, !tbaa !6
  %129 = fmul contract float %123, %128
  %130 = fadd contract float %126, %129
  %131 = getelementptr inbounds float, float addrspace(1)* %1, i64 %25
  %132 = load float, float addrspace(1)* %131, align 4, !tbaa !6
  %133 = fmul contract float %100, %132
  %134 = fadd contract float %130, %133
  %135 = getelementptr inbounds float, float addrspace(1)* %0, i64 %25
  %136 = load float, float addrspace(1)* %135, align 4, !tbaa !6
  %137 = fmul contract float %122, %136
  %138 = fadd contract float %134, %137
  %139 = load float, float addrspace(3)* %28, align 4, !tbaa !6
  %140 = fpext float %139 to double
  %141 = fpext float %8 to double
  %142 = fmul contract double %141, 2.500000e-01
  %143 = fpext float %138 to double
  %144 = fmul contract double %142, %143
  %145 = fadd contract double %144, %140
  %146 = fptrunc double %145 to float
  %147 = getelementptr inbounds [32 x [32 x float]], [32 x [32 x float]] addrspace(3)* @_ZZ11srad_cuda_2PfS_S_S_S_S_iiffE13c_cuda_result, i32 0, i32 %14, i32 %13
  store float %146, float addrspace(3)* %147, align 4, !tbaa !6
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %148 = load float, float addrspace(3)* %147, align 4, !tbaa !6
  store float %148, float addrspace(1)* %26, align 4, !tbaa !6
  ret void
}

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.y() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.y() #2

attributes #0 = { convergent norecurse nounwind willreturn "amdgpu-flat-work-group-size"="1,1024" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { convergent nounwind willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i32 0, i32 1024}
!6 = !{!7, !7, i64 0}
!7 = !{!"float", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C++ TBAA"}
!10 = !{!11, !15, i64 16}
!11 = !{!"hsa_kernel_dispatch_packet_s", !12, i64 0, !12, i64 2, !12, i64 4, !12, i64 6, !12, i64 8, !12, i64 10, !15, i64 12, !15, i64 16, !15, i64 20, !15, i64 24, !15, i64 28, !16, i64 32, !17, i64 40, !16, i64 48, !18, i64 56}
!12 = !{!"short", !13, i64 0}
!13 = !{!"omnipotent char", !14, i64 0}
!14 = !{!"Simple C/C++ TBAA"}
!15 = !{!"int", !13, i64 0}
!16 = !{!"long", !13, i64 0}
!17 = !{!"any pointer", !13, i64 0}
!18 = !{!"hsa_signal_s", !16, i64 0}
!19 = !{i16 1, i16 1025}
!20 = !{}
!21 = !{!11, !15, i64 12}
