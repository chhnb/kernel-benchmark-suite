; ModuleID = '/data/home/chh/simplify-v2/build/simplify-fingerprint/inputs/MS32.ll'
source_filename = "/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-benchmarks/benchmarks/MS/mergesort.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

%struct.__HIP_Coordinates = type { i8 }
%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z" = type { i8 }
%struct.__HIP_Coordinates.0 = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z" = type { i8 }
%struct.dim3 = type { i32, i32, i32 }
%struct.__HIP_ThreadIdx = type { i8 }
%struct.__HIP_BlockIdx = type { i8 }

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1yE = comdat any

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1zE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1yE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1zE = comdat any

@.str = private unnamed_addr addrspace(4) constant [47 x i8] c"%s:%u: %s: Device-side assertion `%s' failed.\0A\00", align 1
@_ZL9threadIdx = internal addrspace(4) constant %struct.__HIP_Coordinates undef, align 1
@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1yE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1zE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z" undef, comdat, align 1
@_ZL8blockIdx = internal addrspace(4) constant %struct.__HIP_Coordinates.0 undef, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1yE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1zE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z" undef, comdat, align 1

; Function Attrs: convergent noinline nounwind
define weak hidden void @__assert_fail(i8* %0, i8* %1, i32 %2, i8* %3) #0 {
  %5 = alloca i8*, align 8, addrspace(5)
  %6 = addrspacecast i8* addrspace(5)* %5 to i8**
  %7 = alloca i8*, align 8, addrspace(5)
  %8 = addrspacecast i8* addrspace(5)* %7 to i8**
  %9 = alloca i32, align 4, addrspace(5)
  %10 = addrspacecast i32 addrspace(5)* %9 to i32*
  %11 = alloca i8*, align 8, addrspace(5)
  %12 = addrspacecast i8* addrspace(5)* %11 to i8**
  store i8* %0, i8** %6, align 8
  store i8* %1, i8** %8, align 8
  store i32 %2, i32* %10, align 4
  store i8* %3, i8** %12, align 8
  call void @_ZL6printfIJPKcjS1_S1_EEvS1_DpT_(i8* getelementptr inbounds ([47 x i8], [47 x i8]* addrspacecast ([47 x i8] addrspace(4)* @.str to [47 x i8]*), i64 0, i64 0), i8* %1, i32 %2, i8* %3, i8* %0) #6
  call void @llvm.trap()
  ret void
}

; Function Attrs: convergent noinline nounwind
define internal void @_ZL6printfIJPKcjS1_S1_EEvS1_DpT_(i8* %0, i8* %1, i32 %2, i8* %3, i8* %4) #0 {
  %6 = alloca i8*, align 8, addrspace(5)
  %7 = addrspacecast i8* addrspace(5)* %6 to i8**
  %8 = alloca i8*, align 8, addrspace(5)
  %9 = addrspacecast i8* addrspace(5)* %8 to i8**
  %10 = alloca i32, align 4, addrspace(5)
  %11 = addrspacecast i32 addrspace(5)* %10 to i32*
  %12 = alloca i8*, align 8, addrspace(5)
  %13 = addrspacecast i8* addrspace(5)* %12 to i8**
  %14 = alloca i8*, align 8, addrspace(5)
  %15 = addrspacecast i8* addrspace(5)* %14 to i8**
  store i8* %0, i8** %7, align 8
  store i8* %1, i8** %9, align 8
  store i32 %2, i32* %11, align 4
  store i8* %3, i8** %13, align 8
  store i8* %4, i8** %15, align 8
  ret void
}

; Function Attrs: cold noreturn nounwind
declare void @llvm.trap() #1

; Function Attrs: convergent noinline nounwind
define weak hidden void @__assertfail(i8* %0, i8* %1, i32 %2, i8* %3, i64 %4) #0 {
  %6 = alloca i8*, align 8, addrspace(5)
  %7 = addrspacecast i8* addrspace(5)* %6 to i8**
  %8 = alloca i8*, align 8, addrspace(5)
  %9 = addrspacecast i8* addrspace(5)* %8 to i8**
  %10 = alloca i32, align 4, addrspace(5)
  %11 = addrspacecast i32 addrspace(5)* %10 to i32*
  %12 = alloca i8*, align 8, addrspace(5)
  %13 = addrspacecast i8* addrspace(5)* %12 to i8**
  %14 = alloca i64, align 8, addrspace(5)
  %15 = addrspacecast i64 addrspace(5)* %14 to i64*
  store i8* %0, i8** %7, align 8
  store i8* %1, i8** %9, align 8
  store i32 %2, i32* %11, align 4
  store i8* %3, i8** %13, align 8
  store i64 %4, i64* %15, align 8
  call void @llvm.trap()
  ret void
}

; Function Attrs: alwaysinline convergent nounwind
define hidden i32 @_Z6getIdxP4dim3S0_(%struct.dim3* %0, %struct.dim3* %1) #2 {
  %3 = alloca %struct.__HIP_ThreadIdx*, align 8, addrspace(5)
  %4 = alloca i32, align 4, addrspace(5)
  %5 = alloca %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"*, align 8, addrspace(5)
  %6 = alloca %struct.__HIP_ThreadIdx, align 1, addrspace(5)
  %7 = alloca %struct.__HIP_ThreadIdx*, align 8, addrspace(5)
  %8 = alloca i32, align 4, addrspace(5)
  %9 = alloca %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"*, align 8, addrspace(5)
  %10 = alloca %struct.__HIP_ThreadIdx, align 1, addrspace(5)
  %11 = alloca %struct.__HIP_BlockIdx*, align 8, addrspace(5)
  %12 = alloca i32, align 4, addrspace(5)
  %13 = alloca %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"*, align 8, addrspace(5)
  %14 = alloca %struct.__HIP_BlockIdx, align 1, addrspace(5)
  %15 = alloca %struct.__HIP_BlockIdx*, align 8, addrspace(5)
  %16 = alloca i32, align 4, addrspace(5)
  %17 = alloca %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"*, align 8, addrspace(5)
  %18 = alloca %struct.__HIP_BlockIdx, align 1, addrspace(5)
  %19 = alloca %struct.__HIP_BlockIdx*, align 8, addrspace(5)
  %20 = alloca i32, align 4, addrspace(5)
  %21 = alloca %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"*, align 8, addrspace(5)
  %22 = alloca %struct.__HIP_BlockIdx, align 1, addrspace(5)
  %23 = alloca %struct.__HIP_ThreadIdx*, align 8, addrspace(5)
  %24 = alloca i32, align 4, addrspace(5)
  %25 = alloca %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"*, align 8, addrspace(5)
  %26 = alloca %struct.__HIP_ThreadIdx, align 1, addrspace(5)
  %27 = alloca %struct.dim3*, align 8, addrspace(5)
  %28 = addrspacecast %struct.dim3* addrspace(5)* %27 to %struct.dim3**
  %29 = alloca %struct.dim3*, align 8, addrspace(5)
  %30 = addrspacecast %struct.dim3* addrspace(5)* %29 to %struct.dim3**
  %31 = alloca i32, align 4, addrspace(5)
  %32 = addrspacecast i32 addrspace(5)* %31 to i32*
  store %struct.dim3* %0, %struct.dim3** %28, align 8
  store %struct.dim3* %1, %struct.dim3** %30, align 8
  %33 = bitcast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"* addrspace(5)* %25 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %33)
  %34 = bitcast %struct.__HIP_ThreadIdx addrspace(5)* %26 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %34)
  %35 = addrspacecast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"* addrspace(5)* %25 to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"**
  %36 = addrspacecast %struct.__HIP_ThreadIdx addrspace(5)* %26 to %struct.__HIP_ThreadIdx*
  store %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" addrspace(4)* @_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"*), %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"** %35, align 8
  %37 = bitcast %struct.__HIP_ThreadIdx* addrspace(5)* %23 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %37) #7
  %38 = bitcast i32 addrspace(5)* %24 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %38) #7
  %39 = addrspacecast %struct.__HIP_ThreadIdx* addrspace(5)* %23 to %struct.__HIP_ThreadIdx**
  %40 = addrspacecast i32 addrspace(5)* %24 to i32*
  store %struct.__HIP_ThreadIdx* %36, %struct.__HIP_ThreadIdx** %39, align 8
  store i32 0, i32* %40, align 4
  %41 = call i32 @llvm.amdgcn.workitem.id.x() #7, !range !5
  %42 = zext i32 %41 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %37) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %38) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %33)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %34)
  %43 = bitcast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"* addrspace(5)* %5 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %43)
  %44 = bitcast %struct.__HIP_ThreadIdx addrspace(5)* %6 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %44)
  %45 = addrspacecast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"* addrspace(5)* %5 to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"**
  %46 = addrspacecast %struct.__HIP_ThreadIdx addrspace(5)* %6 to %struct.__HIP_ThreadIdx*
  store %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y" addrspace(4)* @_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1yE to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"*), %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"** %45, align 8
  %47 = bitcast %struct.__HIP_ThreadIdx* addrspace(5)* %3 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %47) #7
  %48 = bitcast i32 addrspace(5)* %4 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %48) #7
  %49 = addrspacecast %struct.__HIP_ThreadIdx* addrspace(5)* %3 to %struct.__HIP_ThreadIdx**
  %50 = addrspacecast i32 addrspace(5)* %4 to i32*
  store %struct.__HIP_ThreadIdx* %46, %struct.__HIP_ThreadIdx** %49, align 8
  store i32 1, i32* %50, align 4
  %51 = call i32 @llvm.amdgcn.workitem.id.y() #7, !range !5
  %52 = zext i32 %51 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %47) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %48) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %43)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %44)
  %53 = getelementptr inbounds %struct.dim3, %struct.dim3* %0, i32 0, i32 0
  %54 = load i32, i32* %53, align 4
  store i32 %54, i32* %32, align 4
  %55 = mul i32 %51, %54
  %56 = add i32 %41, %55
  %57 = bitcast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"* addrspace(5)* %9 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %57)
  %58 = bitcast %struct.__HIP_ThreadIdx addrspace(5)* %10 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %58)
  %59 = addrspacecast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"* addrspace(5)* %9 to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"**
  %60 = addrspacecast %struct.__HIP_ThreadIdx addrspace(5)* %10 to %struct.__HIP_ThreadIdx*
  store %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z" addrspace(4)* @_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1zE to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"*), %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"** %59, align 8
  %61 = bitcast %struct.__HIP_ThreadIdx* addrspace(5)* %7 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %61) #7
  %62 = bitcast i32 addrspace(5)* %8 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %62) #7
  %63 = addrspacecast %struct.__HIP_ThreadIdx* addrspace(5)* %7 to %struct.__HIP_ThreadIdx**
  %64 = addrspacecast i32 addrspace(5)* %8 to i32*
  store %struct.__HIP_ThreadIdx* %60, %struct.__HIP_ThreadIdx** %63, align 8
  store i32 2, i32* %64, align 4
  %65 = call i32 @llvm.amdgcn.workitem.id.z() #7, !range !5
  %66 = zext i32 %65 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %61) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %62) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %57)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %58)
  %67 = getelementptr inbounds %struct.dim3, %struct.dim3* %0, i32 0, i32 1
  %68 = load i32, i32* %67, align 4
  %69 = mul i32 %54, %68
  store i32 %69, i32* %32, align 4
  %70 = mul i32 %65, %69
  %71 = add i32 %56, %70
  %72 = bitcast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"* addrspace(5)* %13 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %72)
  %73 = bitcast %struct.__HIP_BlockIdx addrspace(5)* %14 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %73)
  %74 = addrspacecast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"* addrspace(5)* %13 to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"**
  %75 = addrspacecast %struct.__HIP_BlockIdx addrspace(5)* %14 to %struct.__HIP_BlockIdx*
  store %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" addrspace(4)* @_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"*), %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"** %74, align 8
  %76 = bitcast %struct.__HIP_BlockIdx* addrspace(5)* %11 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %76) #7
  %77 = bitcast i32 addrspace(5)* %12 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %77) #7
  %78 = addrspacecast %struct.__HIP_BlockIdx* addrspace(5)* %11 to %struct.__HIP_BlockIdx**
  %79 = addrspacecast i32 addrspace(5)* %12 to i32*
  store %struct.__HIP_BlockIdx* %75, %struct.__HIP_BlockIdx** %78, align 8
  store i32 0, i32* %79, align 4
  %80 = call i32 @llvm.amdgcn.workgroup.id.x() #7
  %81 = zext i32 %80 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %76) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %77) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %72)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %73)
  %82 = getelementptr inbounds %struct.dim3, %struct.dim3* %0, i32 0, i32 2
  %83 = load i32, i32* %82, align 4
  %84 = mul i32 %69, %83
  store i32 %84, i32* %32, align 4
  %85 = mul i32 %80, %84
  %86 = add i32 %71, %85
  %87 = bitcast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"* addrspace(5)* %17 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %87)
  %88 = bitcast %struct.__HIP_BlockIdx addrspace(5)* %18 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %88)
  %89 = addrspacecast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"* addrspace(5)* %17 to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"**
  %90 = addrspacecast %struct.__HIP_BlockIdx addrspace(5)* %18 to %struct.__HIP_BlockIdx*
  store %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y" addrspace(4)* @_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1yE to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"*), %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"** %89, align 8
  %91 = bitcast %struct.__HIP_BlockIdx* addrspace(5)* %15 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %91) #7
  %92 = bitcast i32 addrspace(5)* %16 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %92) #7
  %93 = addrspacecast %struct.__HIP_BlockIdx* addrspace(5)* %15 to %struct.__HIP_BlockIdx**
  %94 = addrspacecast i32 addrspace(5)* %16 to i32*
  store %struct.__HIP_BlockIdx* %90, %struct.__HIP_BlockIdx** %93, align 8
  store i32 1, i32* %94, align 4
  %95 = call i32 @llvm.amdgcn.workgroup.id.y() #7
  %96 = zext i32 %95 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %91) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %92) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %87)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %88)
  %97 = getelementptr inbounds %struct.dim3, %struct.dim3* %1, i32 0, i32 2
  %98 = load i32, i32* %97, align 4
  %99 = mul i32 %84, %98
  store i32 %99, i32* %32, align 4
  %100 = mul i32 %95, %99
  %101 = add i32 %86, %100
  %102 = bitcast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"* addrspace(5)* %21 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %102)
  %103 = bitcast %struct.__HIP_BlockIdx addrspace(5)* %22 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %103)
  %104 = addrspacecast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"* addrspace(5)* %21 to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"**
  %105 = addrspacecast %struct.__HIP_BlockIdx addrspace(5)* %22 to %struct.__HIP_BlockIdx*
  store %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z" addrspace(4)* @_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1zE to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"*), %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"** %104, align 8
  %106 = bitcast %struct.__HIP_BlockIdx* addrspace(5)* %19 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %106) #7
  %107 = bitcast i32 addrspace(5)* %20 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %107) #7
  %108 = addrspacecast %struct.__HIP_BlockIdx* addrspace(5)* %19 to %struct.__HIP_BlockIdx**
  %109 = addrspacecast i32 addrspace(5)* %20 to i32*
  store %struct.__HIP_BlockIdx* %105, %struct.__HIP_BlockIdx** %108, align 8
  store i32 2, i32* %109, align 4
  %110 = call i32 @llvm.amdgcn.workgroup.id.z() #7
  %111 = zext i32 %110 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %106) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %107) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %102)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %103)
  %112 = getelementptr inbounds %struct.dim3, %struct.dim3* %1, i32 0, i32 1
  %113 = load i32, i32* %112, align 4
  %114 = mul i32 %99, %113
  store i32 %114, i32* %32, align 4
  %115 = mul i32 %110, %114
  %116 = add i32 %101, %115
  ret i32 %116
}

; Function Attrs: convergent noinline norecurse nounwind
define protected amdgpu_kernel void @_Z13gpu_mergesortPlS_lllP4dim3S1_(i64 addrspace(1)* %0, i64 addrspace(1)* %1, i64 %2, i64 %3, i64 %4, %struct.dim3 addrspace(1)* %5, %struct.dim3 addrspace(1)* %6) #3 {
  %8 = alloca i64, align 8, addrspace(5)
  %9 = addrspacecast i64 addrspace(5)* %8 to i64*
  %10 = alloca i64, align 8, addrspace(5)
  %11 = addrspacecast i64 addrspace(5)* %10 to i64*
  %12 = addrspacecast %struct.dim3 addrspace(1)* %5 to %struct.dim3*
  %13 = addrspacecast %struct.dim3 addrspace(1)* %6 to %struct.dim3*
  %14 = call i32 @llvm.amdgcn.workitem.id.x() #7, !range !5
  %15 = call i32 @llvm.amdgcn.workitem.id.y() #7, !range !5
  %16 = getelementptr inbounds %struct.dim3, %struct.dim3* %12, i64 0, i32 0
  %17 = load i32, i32* %16, align 4
  %18 = mul i32 %15, %17
  %19 = add i32 %14, %18
  %20 = call i32 @llvm.amdgcn.workitem.id.z() #7, !range !5
  %21 = getelementptr inbounds %struct.dim3, %struct.dim3* %12, i64 0, i32 1
  %22 = load i32, i32* %21, align 4
  %23 = mul i32 %17, %22
  %24 = mul i32 %20, %23
  %25 = add i32 %19, %24
  %26 = call i32 @llvm.amdgcn.workgroup.id.x() #7
  %27 = getelementptr inbounds %struct.dim3, %struct.dim3* %12, i64 0, i32 2
  %28 = load i32, i32* %27, align 4
  %29 = mul i32 %23, %28
  %30 = mul i32 %26, %29
  %31 = add i32 %25, %30
  %32 = call i32 @llvm.amdgcn.workgroup.id.y() #7
  %33 = getelementptr inbounds %struct.dim3, %struct.dim3* %13, i64 0, i32 2
  %34 = load i32, i32* %33, align 4
  %35 = mul i32 %29, %34
  %36 = mul i32 %32, %35
  %37 = add i32 %31, %36
  %38 = call i32 @llvm.amdgcn.workgroup.id.z() #7
  %39 = getelementptr inbounds %struct.dim3, %struct.dim3* %13, i64 0, i32 1
  %40 = load i32, i32* %39, align 4
  %41 = mul i32 %35, %40
  %42 = mul i32 %38, %41
  %43 = add i32 %37, %42
  %44 = zext i32 %43 to i64
  %45 = mul nsw i64 %44, %3
  %46 = mul nsw i64 %45, %4
  br label %47

47:                                               ; preds = %94, %7
  %48 = phi i64 [ %2, %7 ], [ %60, %94 ]
  %49 = phi i64 [ %46, %7 ], [ %58, %94 ]
  %50 = phi i64 [ 0, %7 ], [ %95, %94 ]
  %51 = icmp slt i64 %50, %4
  br i1 %51, label %52, label %96

52:                                               ; preds = %47
  %.not = icmp slt i64 %49, %48
  br i1 %.not, label %53, label %96

53:                                               ; preds = %52
  %54 = ashr i64 %3, 1
  %55 = add nsw i64 %49, %54
  %56 = icmp slt i64 %55, %48
  %57 = select i1 %56, i64 %55, i64 %48
  %58 = add nsw i64 %49, %3
  %59 = icmp slt i64 %58, %48
  %60 = select i1 %59, i64 %48, i64 %2
  %61 = select i1 %59, i64 %58, i64 %2
  store i64 %49, i64* %9, align 8
  store i64 %57, i64* %11, align 8
  br label %62

62:                                               ; preds = %merged.branch.split, %53
  %63 = phi i64 [ %57, %53 ], [ %89, %merged.branch.split ]
  %64 = phi i64 [ %49, %53 ], [ %90, %merged.branch.split ]
  %65 = phi i64 [ %57, %53 ], [ %91, %merged.branch.split ]
  %66 = phi i64 [ %49, %53 ], [ %92, %merged.branch.split ]
  %67 = phi i64 [ %49, %53 ], [ %93, %merged.branch.split ]
  %68 = icmp slt i64 %67, %61
  br i1 %68, label %69, label %94

69:                                               ; preds = %62
  %70 = icmp slt i64 %66, %57
  br i1 %70, label %71, label %unify.bb

71:                                               ; preds = %69
  %.not1 = icmp slt i64 %65, %61
  br i1 %.not1, label %72, label %unify.bb

72:                                               ; preds = %71
  %73 = getelementptr inbounds i64, i64 addrspace(1)* %0, i64 %64
  %74 = addrspacecast i64 addrspace(1)* %73 to i64*
  %75 = load i64, i64* %74, align 8
  %76 = getelementptr inbounds i64, i64 addrspace(1)* %0, i64 %63
  %77 = addrspacecast i64 addrspace(1)* %76 to i64*
  %78 = load i64, i64* %77, align 8
  %79 = icmp slt i64 %75, %78
  br label %unify.bb

unify.bb:                                         ; preds = %71, %72, %69
  %80 = phi i64 [ %65, %69 ], [ %65, %71 ], [ %63, %72 ]
  %81 = phi i64 [ %66, %69 ], [ %66, %71 ], [ %64, %72 ]
  %82 = phi i1 [ false, %69 ], [ true, %71 ], [ %79, %72 ]
  %merged.select1 = select i1 %82, i64 %64, i64 %63
  %83 = getelementptr inbounds i64, i64 addrspace(1)* %0, i64 %merged.select1
  %84 = addrspacecast i64 addrspace(1)* %83 to i64*
  %85 = load i64, i64* %84, align 8
  %86 = getelementptr inbounds i64, i64 addrspace(1)* %1, i64 %67
  %87 = addrspacecast i64 addrspace(1)* %86 to i64*
  store i64 %85, i64* %87, align 8
  %88 = add nsw i64 %merged.select1, 1
  %merged.select4 = select i1 %82, i64* %9, i64* %11
  store i64 %88, i64* %merged.select4, align 8
  br i1 %82, label %merged.branch.split, label %merged.branch.split5

merged.branch.split:                              ; preds = %unify.bb, %merged.branch.split5
  %89 = phi i64 [ %63, %unify.bb ], [ %88, %merged.branch.split5 ]
  %90 = phi i64 [ %88, %unify.bb ], [ %64, %merged.branch.split5 ]
  %91 = phi i64 [ %80, %unify.bb ], [ %88, %merged.branch.split5 ]
  %92 = phi i64 [ %88, %unify.bb ], [ %81, %merged.branch.split5 ]
  %93 = add nsw i64 %67, 1
  br label %62, !llvm.loop !6

94:                                               ; preds = %62
  %95 = add nuw nsw i64 %50, 1
  br label %47, !llvm.loop !8

96:                                               ; preds = %52, %47
  ret void

merged.branch.split5:                             ; preds = %unify.bb
  br label %merged.branch.split
}

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #4

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.y() #4

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.z() #4

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #4

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.y() #4

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.z() #4

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p5i8(i64 immarg, i8 addrspace(5)* nocapture) #5

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p5i8(i64 immarg, i8 addrspace(5)* nocapture) #5

attributes #0 = { convergent noinline nounwind "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="all" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { cold noreturn nounwind }
attributes #2 = { alwaysinline convergent nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="all" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+add-no-carry-insts,+aperture-regs,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+ds-src2-insts,+enable-ds128,+enable-prt-strict-null,+fast-denormal-f32,+fast-fmaf,+flat-address-space,+flat-for-global,+flat-global-insts,+flat-inst-offsets,+flat-scratch-insts,+fma-mix-insts,+fp64,+gcn3-encoding,+gfx7-gfx8-gfx9-insts,+gfx8-insts,+gfx9,+gfx9-insts,+half-rate-64-ops,+image-gather4-d16-bug,+int-clamp-insts,+inv-2pi-inline-imm,+ldsbankcount32,+load-store-opt,+localmemorysize65536,+mad-mac-f32-insts,+promote-alloca,+r128-a16,+s-memrealtime,+s-memtime-inst,+scalar-atomics,+scalar-flat-scratch-insts,+scalar-stores,+sdwa,+sdwa-omod,+sdwa-scalar,+sdwa-sdst,+sramecc-support,+trap-handler,+unaligned-access-mode,+unaligned-buffer-access,+unaligned-ds-access,+vgpr-index-mode,+vop3p,-wavefrontsize16,-wavefrontsize32,+wavefrontsize64,+xnack-support" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #3 = { convergent noinline norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="all" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #4 = { nounwind readnone speculatable willreturn }
attributes #5 = { argmemonly nofree nosync nounwind willreturn }
attributes #6 = { convergent nounwind }
attributes #7 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3}
!opencl.ocl.version = !{!4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!3 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!4 = !{i32 2, i32 0}
!5 = !{i32 0, i32 1024}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
