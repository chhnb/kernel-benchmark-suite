; ModuleID = '/data/home/chh/simplify-v2/build/b2b-layouts/anchor-ablation/heldout/HiPIMS-George/active/trial-20/fused.ll'
source_filename = "/data/home/chh/simplify-v2/build/b2b-layouts/anchor-ablation/heldout/HiPIMS-George/kernel.cu"
target datalayout = "e-i64:64-i128:128-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

%"class.GC::ShortDualHandle.48.51" = type { %"class.GC::ShortDualFlag.49.52" }
%"class.GC::ShortDualFlag.49.52" = type { i32 }
%"struct.GC::Vector2.50.53" = type { double, double }

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0i8(i64 immarg, i8* nocapture) #0

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0i8(i64 immarg, i8* nocapture) #0

; Function Attrs: convergent norecurse nounwind
define dso_local void @_ZN2GC2fv36cuAdvectionSWEsGeorgeCartesianKernelEPdS1_S1_S1_S1_PNS_7Vector2ES3_jPNS_15ShortDualHandleEjS1_S1_S3_(double* nocapture readonly %0, double* nocapture readonly %1, double* nocapture readonly %2, double* nocapture readonly %3, double* nocapture readonly %4, %"struct.GC::Vector2.50.53"* nocapture readonly %5, %"struct.GC::Vector2.50.53"* nocapture readonly %6, i32 %7, %"class.GC::ShortDualHandle.48.51"* nocapture readonly %8, i32 %9, double* nocapture readonly %10, double* nocapture %11, %"struct.GC::Vector2.50.53"* nocapture %12) local_unnamed_addr #1 {
  %14 = alloca [4 x %"struct.GC::Vector2.50.53"], align 8
  %15 = alloca [4 x %"struct.GC::Vector2.50.53"], align 8
  %16 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #5, !range !5
  %17 = tail call i32 @llvm.nvvm.read.ptx.sreg.tid.x() #5, !range !6
  %18 = bitcast [4 x %"struct.GC::Vector2.50.53"]* %14 to i8*
  call void @llvm.lifetime.start.p0i8(i64 64, i8* nonnull %18) #5
  %19 = tail call i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #5, !range !7
  %20 = mul i32 %19, %16
  %21 = add i32 %20, %17
  %22 = bitcast [4 x %"struct.GC::Vector2.50.53"]* %15 to i8*
  call void @llvm.lifetime.start.p0i8(i64 64, i8* nonnull %22) #5
  %23 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %14, i64 0, i64 0, i32 0
  store double 0.000000e+00, double* %23, align 8, !tbaa.struct !8
  %24 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %14, i64 0, i64 0, i32 1
  store double -1.000000e+00, double* %24, align 8, !tbaa.struct !13
  %25 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %14, i64 0, i64 1, i32 0
  store double 1.000000e+00, double* %25, align 8, !tbaa.struct !8
  %26 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %14, i64 0, i64 1, i32 1
  store double 0.000000e+00, double* %26, align 8, !tbaa.struct !13
  %27 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %14, i64 0, i64 2, i32 0
  store double 0.000000e+00, double* %27, align 8, !tbaa.struct !8
  %28 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %14, i64 0, i64 2, i32 1
  store double 1.000000e+00, double* %28, align 8, !tbaa.struct !13
  %29 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %14, i64 0, i64 3, i32 0
  store double -1.000000e+00, double* %29, align 8, !tbaa.struct !8
  %30 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %14, i64 0, i64 3, i32 1
  store double 0.000000e+00, double* %30, align 8, !tbaa.struct !13
  %31 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %15, i64 0, i64 0, i32 0
  store double 1.000000e+00, double* %31, align 8, !tbaa.struct !8
  %32 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %15, i64 0, i64 0, i32 1
  store double 0.000000e+00, double* %32, align 8, !tbaa.struct !13
  %33 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %15, i64 0, i64 1, i32 0
  store double 0.000000e+00, double* %33, align 8, !tbaa.struct !8
  %34 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %15, i64 0, i64 1, i32 1
  store double 1.000000e+00, double* %34, align 8, !tbaa.struct !13
  %35 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %15, i64 0, i64 2, i32 0
  store double -1.000000e+00, double* %35, align 8, !tbaa.struct !8
  %36 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %15, i64 0, i64 2, i32 1
  store double 0.000000e+00, double* %36, align 8, !tbaa.struct !13
  %37 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %15, i64 0, i64 3, i32 0
  store double 0.000000e+00, double* %37, align 8, !tbaa.struct !8
  %38 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %15, i64 0, i64 3, i32 1
  store double -1.000000e+00, double* %38, align 8, !tbaa.struct !13
  %39 = icmp ult i32 %21, %7
  br i1 %39, label %.preheader58, label %.loopexit59

.preheader58:                                     ; preds = %63, %13
  %40 = phi i32 [ %21, %13 ], [ %69, %63 ]
  %41 = zext i32 %40 to i64
  %42 = getelementptr inbounds double, double* %0, i64 %41
  %43 = load double, double* %42, align 8, !tbaa !9
  %44 = getelementptr inbounds double, double* %1, i64 %41
  %45 = load double, double* %44, align 8, !tbaa !9
  %46 = getelementptr inbounds double, double* %3, i64 %41
  %47 = load double, double* %46, align 8, !tbaa !9
  %48 = fcmp olt double %45, 1.000000e-10
  br i1 %48, label %56, label %49

49:                                               ; preds = %.preheader58
  %50 = getelementptr inbounds %"struct.GC::Vector2.50.53", %"struct.GC::Vector2.50.53"* %5, i64 %41, i32 1
  %51 = getelementptr inbounds %"struct.GC::Vector2.50.53", %"struct.GC::Vector2.50.53"* %5, i64 %41, i32 0
  %52 = load double, double* %50, align 8, !tbaa.struct !13
  %53 = load double, double* %51, align 8, !tbaa.struct !8
  %54 = fdiv double %53, %45
  %55 = fdiv double %52, %45
  br label %56

56:                                               ; preds = %49, %.preheader58
  %57 = phi double [ 0.000000e+00, %.preheader58 ], [ %54, %49 ]
  %58 = phi double [ 0.000000e+00, %.preheader58 ], [ %55, %49 ]
  %59 = getelementptr inbounds double, double* %10, i64 %41
  %60 = load double, double* %59, align 8, !tbaa !9
  %61 = tail call double @llvm.sqrt.f64(double %60) #5
  %62 = fcmp ogt double %45, 1.000000e-10
  br label %71

63:                                               ; preds = %4116
  %64 = getelementptr inbounds double, double* %11, i64 %41
  store double %4119, double* %64, align 8, !tbaa !9
  %65 = getelementptr inbounds %"struct.GC::Vector2.50.53", %"struct.GC::Vector2.50.53"* %12, i64 %41, i32 0
  store double %4117, double* %65, align 8, !tbaa.struct !8
  %66 = getelementptr inbounds %"struct.GC::Vector2.50.53", %"struct.GC::Vector2.50.53"* %12, i64 %41, i32 1
  store double %4118, double* %66, align 8, !tbaa.struct !13
  tail call void @llvm.nvvm.barrier0()
  %67 = tail call i32 @llvm.nvvm.read.ptx.sreg.nctaid.x() #5, !range !14
  %68 = mul i32 %67, %19
  %69 = add i32 %68, %40
  %70 = icmp ult i32 %69, %7
  br i1 %70, label %.preheader58, label %.loopexit59, !llvm.loop !15

71:                                               ; preds = %4116, %56
  %72 = phi double [ 0.000000e+00, %56 ], [ %4119, %4116 ]
  %73 = phi i32 [ 0, %56 ], [ %4120, %4116 ]
  %74 = phi double [ 0.000000e+00, %56 ], [ %4118, %4116 ]
  %75 = phi double [ 0.000000e+00, %56 ], [ %4117, %4116 ]
  %76 = zext i32 %73 to i64
  %77 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %14, i64 0, i64 %76, i32 0
  %78 = load double, double* %77, align 8, !tbaa.struct !8
  %79 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %14, i64 0, i64 %76, i32 1
  %80 = load double, double* %79, align 8, !tbaa.struct !13
  %81 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %15, i64 0, i64 %76, i32 0
  %82 = load double, double* %81, align 8, !tbaa.struct !8
  %83 = getelementptr inbounds [4 x %"struct.GC::Vector2.50.53"], [4 x %"struct.GC::Vector2.50.53"]* %15, i64 0, i64 %76, i32 1
  %84 = load double, double* %83, align 8, !tbaa.struct !13
  %85 = mul i32 %73, %9
  %86 = add i32 %85, %40
  %87 = zext i32 %86 to i64
  %88 = getelementptr inbounds %"class.GC::ShortDualHandle.48.51", %"class.GC::ShortDualHandle.48.51"* %8, i64 %87, i32 0, i32 0
  %89 = load i32, i32* %88, align 4
  %90 = and i32 %89, 7
  %91 = icmp eq i32 %90, 0
  %92 = lshr i32 %89, 3
  %93 = zext i32 %92 to i64
  br i1 %91, label %97, label %94

94:                                               ; preds = %71
  %95 = getelementptr inbounds double, double* %0, i64 %93
  %96 = load double, double* %95, align 8, !tbaa !9
  br label %97

97:                                               ; preds = %94, %71
  %98 = phi double* [ %2, %71 ], [ %1, %94 ]
  %99 = phi double* [ %4, %71 ], [ %3, %94 ]
  %100 = phi %"struct.GC::Vector2.50.53"* [ %6, %71 ], [ %5, %94 ]
  %101 = phi double [ %43, %71 ], [ %96, %94 ]
  %102 = getelementptr inbounds double, double* %98, i64 %93
  %103 = getelementptr inbounds double, double* %99, i64 %93
  %104 = getelementptr inbounds %"struct.GC::Vector2.50.53", %"struct.GC::Vector2.50.53"* %100, i64 %93, i32 1
  %105 = load double, double* %103, align 8, !tbaa !9
  %106 = load double, double* %102, align 8, !tbaa !9
  %107 = load double, double* %104, align 8
  %108 = getelementptr inbounds %"struct.GC::Vector2.50.53", %"struct.GC::Vector2.50.53"* %100, i64 %93, i32 0
  %109 = load double, double* %108, align 8
  %110 = fcmp olt double %106, 1.000000e-10
  %111 = and i1 %48, %110
  br i1 %111, label %4116, label %112

112:                                              ; preds = %97
  br i1 %110, label %116, label %113

113:                                              ; preds = %112
  %114 = fdiv double %109, %106
  %115 = fdiv double %107, %106
  br label %116

116:                                              ; preds = %113, %112
  %117 = phi double [ 0.000000e+00, %112 ], [ %114, %113 ]
  %118 = phi double [ 0.000000e+00, %112 ], [ %115, %113 ]
  %119 = fmul double %57, %78
  %120 = fmul double %58, %80
  %121 = fadd double %119, %120
  %122 = fmul double %57, %82
  %123 = fmul double %58, %84
  %124 = fadd double %122, %123
  %125 = fmul double %78, %117
  %126 = fmul double %80, %118
  %127 = fadd double %125, %126
  %128 = fadd double %43, %101
  %129 = fmul double %128, 5.000000e-01
  %130 = fmul double %45, %121
  %131 = fmul double %45, %124
  %132 = fmul double %106, %127
  %133 = fcmp ogt double %106, 1.000000e-10
  br i1 %133, label %134, label %147

134:                                              ; preds = %116
  %135 = fmul double %82, %117
  %136 = fmul double %84, %118
  %137 = fadd double %135, %136
  %138 = fmul double %106, %137
  %139 = fdiv double %132, %106
  %140 = fdiv double %138, %106
  %141 = fmul double %129, 5.000000e-01
  %142 = fmul double %106, %141
  %143 = fmul double %106, %142
  %144 = fmul double %132, %132
  %145 = fdiv double %144, %106
  %146 = fadd double %143, %145
  br label %147

147:                                              ; preds = %134, %116
  %148 = phi double [ 0.000000e+00, %116 ], [ %140, %134 ]
  %149 = phi double [ 0.000000e+00, %116 ], [ %146, %134 ]
  %150 = phi double [ 0.000000e+00, %116 ], [ %139, %134 ]
  %151 = phi double [ 0.000000e+00, %116 ], [ %132, %134 ]
  %152 = phi double [ 0.000000e+00, %116 ], [ %106, %134 ]
  br i1 %62, label %153, label %162

153:                                              ; preds = %147
  %154 = fdiv double %130, %45
  %155 = fdiv double %131, %45
  %156 = fmul double %129, 5.000000e-01
  %157 = fmul double %45, %156
  %158 = fmul double %45, %157
  %159 = fmul double %130, %130
  %160 = fdiv double %159, %45
  %161 = fadd double %160, %158
  br label %162

162:                                              ; preds = %153, %147
  %163 = phi double [ 0.000000e+00, %147 ], [ %155, %153 ]
  %164 = phi double [ 0.000000e+00, %147 ], [ %161, %153 ]
  %165 = phi double [ 0.000000e+00, %147 ], [ %154, %153 ]
  %166 = phi double [ 0.000000e+00, %147 ], [ %130, %153 ]
  %167 = phi double [ 0.000000e+00, %147 ], [ %45, %153 ]
  %168 = fcmp olt double %152, 1.000000e-10
  br i1 %168, label %169, label %1375

169:                                              ; preds = %162
  %170 = fneg double %165
  %171 = fsub double %170, %165
  %172 = fcmp olt double %167, 1.000000e-10
  br i1 %172, label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit.i, label %173

173:                                              ; preds = %169
  %174 = fmul double %129, %167
  %175 = tail call double @llvm.sqrt.f64(double %174) #5
  %176 = fsub double %175, %175
  %177 = fmul double %176, 2.000000e+00
  %178 = fadd double %171, %177
  %179 = fsub double %167, %167
  %180 = fmul double %129, 5.000000e-01
  %181 = fadd double %167, %167
  %182 = fmul double %180, %181
  %183 = fmul double %167, %167
  %184 = fdiv double %182, %183
  %185 = tail call double @llvm.sqrt.f64(double %184) #5
  %186 = fmul double %179, %185
  %187 = fadd double %171, %186
  %188 = fcmp ogt double %178, 0.000000e+00
  br i1 %188, label %189, label %417

189:                                              ; preds = %173
  %190 = fmul double %129, 1.600000e+01
  %191 = fdiv double 1.000000e+00, %190
  %192 = fadd double %175, %175
  %193 = fmul double %192, 2.000000e+00
  %194 = fsub double %193, %171
  %195 = tail call double @llvm.maxnum.f64(double %194, double 0.000000e+00) #5
  %196 = tail call i32 @llvm.nvvm.d2i.hi(double %195) #5
  %197 = tail call i32 @llvm.nvvm.d2i.hi(double 2.000000e+00) #5
  %198 = and i32 %197, 2146435072
  %199 = icmp eq i32 %198, 1062207488
  %200 = tail call double @llvm.fabs.f64(double %195) #5
  %201 = tail call i32 @llvm.nvvm.d2i.hi(double %200) #5
  %202 = tail call i32 @llvm.nvvm.d2i.lo(double %200) #5
  %203 = lshr i32 %201, 20
  %204 = icmp eq i32 %203, 0
  %205 = fmul double %200, 0x4350000000000000
  br i1 %204, label %206, label %211

206:                                              ; preds = %189
  %207 = tail call i32 @llvm.nvvm.d2i.hi(double %205) #5
  %208 = tail call i32 @llvm.nvvm.d2i.lo(double %205) #5
  %209 = lshr i32 %207, 20
  %210 = add nsw i32 %209, -54
  br label %211

211:                                              ; preds = %206, %189
  %212 = phi i32 [ %202, %189 ], [ %208, %206 ]
  %213 = phi i32 [ %201, %189 ], [ %207, %206 ]
  %214 = phi i32 [ %203, %189 ], [ %210, %206 ]
  %215 = add nsw i32 %214, -1023
  %216 = and i32 %213, -2146435073
  %217 = or i32 %216, 1072693248
  %218 = tail call double @llvm.nvvm.lohi.i2d(i32 %212, i32 %217) #5
  %219 = icmp ugt i32 %217, 1073127582
  br i1 %219, label %220, label %226

220:                                              ; preds = %211
  %221 = add nsw i32 %214, -1022
  %222 = tail call i32 @llvm.nvvm.d2i.lo(double %218) #5
  %223 = tail call i32 @llvm.nvvm.d2i.hi(double %218) #5
  %224 = add i32 %223, -1048576
  %225 = tail call double @llvm.nvvm.lohi.i2d(i32 %222, i32 %224) #5
  br label %226

226:                                              ; preds = %220, %211
  %227 = phi double [ %218, %211 ], [ %225, %220 ]
  %228 = phi i32 [ %215, %211 ], [ %221, %220 ]
  %229 = fadd double %227, -1.000000e+00
  %230 = fadd double %227, 1.000000e+00
  %231 = tail call double @llvm.nvvm.rcp.approx.ftz.d(double %230) #5
  %232 = fneg double %230
  %233 = tail call double @llvm.fma.f64(double %232, double %231, double 1.000000e+00) #5
  %234 = tail call double @llvm.fma.f64(double %233, double %233, double %233) #5
  %235 = tail call double @llvm.fma.f64(double %234, double %231, double %231) #5
  %236 = fmul double %229, %235
  %237 = fadd double %236, %236
  %238 = fmul double %237, %237
  %239 = tail call double @llvm.fma.f64(double %238, double 0x3EB0F5FF7D2CAFE2, double 0x3ED0F5D241AD3B5A) #5
  %240 = tail call double @llvm.fma.f64(double %239, double %238, double 0x3EF3B20A75488A3F) #5
  %241 = tail call double @llvm.fma.f64(double %240, double %238, double 0x3F1745CDE4FAECD5) #5
  %242 = tail call double @llvm.fma.f64(double %241, double %238, double 0x3F3C71C7258A578B) #5
  %243 = tail call double @llvm.fma.f64(double %242, double %238, double 0x3F6249249242B910) #5
  %244 = tail call double @llvm.fma.f64(double %243, double %238, double 0x3F89999999999DFB) #5
  %245 = fmul double %238, %244
  %246 = fsub double %229, %237
  %247 = fmul double %246, 2.000000e+00
  %248 = fneg double %237
  %249 = tail call double @llvm.fma.f64(double %248, double %229, double %247) #5
  %250 = fmul double %235, %249
  %251 = fadd double %245, 0x3FB5555555555555
  %252 = fsub double 0x3FB5555555555555, %251
  %253 = fadd double %245, %252
  %254 = fadd double %253, 0.000000e+00
  %255 = fadd double %254, 0xBC46A4CB00B9E7B0
  %256 = fadd double %251, %255
  %257 = fsub double %251, %256
  %258 = fadd double %255, %257
  %259 = fneg double %238
  %260 = tail call double @llvm.fma.f64(double %237, double %237, double %259) #5
  %261 = tail call i32 @llvm.nvvm.d2i.lo(double %250) #5
  %262 = tail call i32 @llvm.nvvm.d2i.hi(double %250) #5
  %263 = add i32 %262, 1048576
  %264 = tail call double @llvm.nvvm.lohi.i2d(i32 %261, i32 %263) #5
  %265 = tail call double @llvm.fma.f64(double %237, double %264, double %260) #5
  %266 = fmul double %237, %238
  %267 = fneg double %266
  %268 = tail call double @llvm.fma.f64(double %238, double %237, double %267) #5
  %269 = tail call double @llvm.fma.f64(double %238, double %250, double %268) #5
  %270 = tail call double @llvm.fma.f64(double %265, double %237, double %269) #5
  %271 = fmul double %266, %256
  %272 = fneg double %271
  %273 = tail call double @llvm.fma.f64(double %256, double %266, double %272) #5
  %274 = tail call double @llvm.fma.f64(double %256, double %270, double %273) #5
  %275 = tail call double @llvm.fma.f64(double %258, double %266, double %274) #5
  %276 = fadd double %271, %275
  %277 = fsub double %271, %276
  %278 = fadd double %275, %277
  %279 = fadd double %237, %276
  %280 = fsub double %237, %279
  %281 = fadd double %276, %280
  %282 = fadd double %278, %281
  %283 = fadd double %250, %282
  %284 = fadd double %279, %283
  %285 = fsub double %279, %284
  %286 = fadd double %283, %285
  %287 = xor i32 %228, -2147483648
  %288 = tail call double @llvm.nvvm.lohi.i2d(i32 %287, i32 1127219200) #5
  %289 = tail call double @llvm.nvvm.lohi.i2d(i32 -2147483648, i32 1127219200) #5
  %290 = fsub double %288, %289
  %291 = tail call double @llvm.fma.f64(double %290, double 0x3FE62E42FEFA39EF, double %284) #5
  %292 = fneg double %290
  %293 = tail call double @llvm.fma.f64(double %292, double 0x3FE62E42FEFA39EF, double %291) #5
  %294 = fsub double %293, %284
  %295 = fsub double %286, %294
  %296 = tail call double @llvm.fma.f64(double %290, double 0x3C7ABC9E3B39803F, double %295) #5
  %297 = fadd double %291, %296
  %298 = fsub double %291, %297
  %299 = fadd double %296, %298
  %300 = tail call i32 @llvm.nvvm.d2i.lo(double 2.000000e+00) #5
  %301 = shl i32 %197, 1
  %302 = icmp ugt i32 %301, -33554433
  %303 = and i32 %197, -15728641
  %304 = select i1 %302, i32 %303, i32 %197
  %305 = tail call double @llvm.nvvm.lohi.i2d(i32 %300, i32 %304) #5
  %306 = fmul double %305, %297
  %307 = fneg double %306
  %308 = tail call double @llvm.fma.f64(double %297, double %305, double %307) #5
  %309 = tail call double @llvm.fma.f64(double %299, double %305, double %308) #5
  %310 = fadd double %306, %309
  %311 = tail call double @llvm.fma.f64(double %310, double 0x3FF71547652B82FE, double 0x4338000000000000) #5
  %312 = tail call i32 @llvm.nvvm.d2i.lo(double %311) #5
  %313 = fadd double %311, 0xC338000000000000
  %314 = tail call double @llvm.fma.f64(double %313, double 0xBFE62E42FEFA39EF, double %310) #5
  %315 = tail call double @llvm.fma.f64(double %313, double 0xBC7ABC9E3B39803F, double %314) #5
  %316 = tail call double @llvm.fma.f64(double %315, double 0x3E5ADE1569CE2BDF, double 0x3E928AF3FCA213EA) #5
  %317 = tail call double @llvm.fma.f64(double %316, double %315, double 0x3EC71DEE62401315) #5
  %318 = tail call double @llvm.fma.f64(double %317, double %315, double 0x3EFA01997C89EB71) #5
  %319 = tail call double @llvm.fma.f64(double %318, double %315, double 0x3F2A01A014761F65) #5
  %320 = tail call double @llvm.fma.f64(double %319, double %315, double 0x3F56C16C1852B7AF) #5
  %321 = tail call double @llvm.fma.f64(double %320, double %315, double 0x3F81111111122322) #5
  %322 = tail call double @llvm.fma.f64(double %321, double %315, double 0x3FA55555555502A1) #5
  %323 = tail call double @llvm.fma.f64(double %322, double %315, double 0x3FC5555555555511) #5
  %324 = tail call double @llvm.fma.f64(double %323, double %315, double 0x3FE000000000000B) #5
  %325 = tail call double @llvm.fma.f64(double %324, double %315, double 1.000000e+00) #5
  %326 = tail call double @llvm.fma.f64(double %325, double %315, double 1.000000e+00) #5
  %327 = tail call i32 @llvm.nvvm.d2i.lo(double %326) #5
  %328 = tail call i32 @llvm.nvvm.d2i.hi(double %326) #5
  %329 = shl i32 %312, 20
  %330 = add i32 %328, %329
  %331 = tail call double @llvm.nvvm.lohi.i2d(i32 %327, i32 %330) #5
  %332 = tail call i32 @llvm.nvvm.d2i.hi(double %310) #5
  %333 = bitcast i32 %332 to float
  %334 = tail call float @llvm.fabs.f32(float %333) #5
  %335 = fcmp olt float %334, 0x4010C46560000000
  br i1 %335, label %__internal_accurate_pow.exit, label %336

336:                                              ; preds = %226
  %337 = fcmp olt double %310, 0.000000e+00
  %338 = fadd double %310, 0x7FF0000000000000
  %339 = select i1 %337, double 0.000000e+00, double %338
  %340 = fcmp olt float %334, 0x4010E90000000000
  br i1 %340, label %341, label %__internal_accurate_pow.exit

341:                                              ; preds = %336
  %342 = sdiv i32 %312, 2
  %343 = shl i32 %342, 20
  %344 = add i32 %328, %343
  %345 = tail call double @llvm.nvvm.lohi.i2d(i32 %327, i32 %344) #5
  %346 = sub nsw i32 %312, %342
  %347 = shl i32 %346, 20
  %348 = add nsw i32 %347, 1072693248
  %349 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %348) #5
  %350 = fmul double %345, %349
  br label %__internal_accurate_pow.exit

__internal_accurate_pow.exit:                     ; preds = %341, %336, %226
  %351 = phi double [ %331, %226 ], [ %339, %336 ], [ %350, %341 ]
  %352 = fsub double %306, %310
  %353 = fadd double %309, %352
  %354 = tail call i32 @llvm.nvvm.d2i.lo(double %351) #5
  %355 = tail call i32 @llvm.nvvm.d2i.hi(double %351) #5
  %356 = and i32 %355, 2147483647
  %357 = icmp eq i32 %356, 2146435072
  %358 = icmp eq i32 %354, 0
  %359 = and i1 %358, %357
  %360 = tail call double @llvm.fma.f64(double %351, double %353, double %351) #5
  %361 = select i1 %359, double %351, double %360
  %362 = icmp slt i32 %196, 0
  %363 = and i1 %362, %199
  br i1 %363, label %364, label %369

364:                                              ; preds = %__internal_accurate_pow.exit
  %365 = tail call i32 @llvm.nvvm.d2i.hi(double %361) #5
  %366 = tail call i32 @llvm.nvvm.d2i.lo(double %361) #5
  %367 = xor i32 %365, -2147483648
  %368 = tail call double @llvm.nvvm.lohi.i2d(i32 %366, i32 %367) #5
  br label %369

369:                                              ; preds = %364, %__internal_accurate_pow.exit
  %370 = phi double [ %361, %__internal_accurate_pow.exit ], [ %368, %364 ]
  %371 = fcmp oeq double %195, 0.000000e+00
  %372 = select i1 %199, i32 %196, i32 0
  br i1 %371, label %373, label %378

373:                                              ; preds = %369
  %374 = icmp slt i32 %197, 0
  %375 = or i32 %372, 2146435072
  %376 = select i1 %374, i32 %375, i32 %372
  %377 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %376) #5
  br label %378

378:                                              ; preds = %373, %369
  %379 = phi double [ %370, %369 ], [ %377, %373 ]
  %380 = fadd double %195, 2.000000e+00
  %381 = tail call i32 @llvm.nvvm.d2i.hi(double %380) #5
  %382 = and i32 %381, 2146435072
  %383 = icmp eq i32 %382, 2146435072
  br i1 %383, label %384, label %412

384:                                              ; preds = %378
  %385 = fcmp ugt double %200, 0x7FF0000000000000
  br i1 %385, label %412, label %386

386:                                              ; preds = %384
  %387 = and i32 %197, 2147483647
  %388 = icmp eq i32 %387, 2146435072
  %389 = icmp eq i32 %300, 0
  %390 = and i1 %388, %389
  br i1 %390, label %391, label %398

391:                                              ; preds = %386
  %392 = fcmp ogt double %200, 1.000000e+00
  %393 = select i1 %392, i32 2146435072, i32 0
  %394 = icmp slt i32 %197, 0
  %395 = xor i32 %393, 2146435072
  %396 = select i1 %394, i32 %395, i32 %393
  %397 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %396) #5
  br label %412

398:                                              ; preds = %386
  %399 = tail call i32 @llvm.nvvm.d2i.lo(double %195) #5
  %400 = and i32 %196, 2147483647
  %401 = icmp eq i32 %400, 2146435072
  %402 = icmp eq i32 %399, 0
  %403 = and i1 %401, %402
  %404 = icmp slt i32 %197, 0
  %405 = select i1 %404, i32 0, i32 2146435072
  br i1 %403, label %406, label %412

406:                                              ; preds = %398
  %407 = icmp ne i32 %387, 1071644672
  %408 = and i1 %407, %363
  %409 = or i32 %405, -2147483648
  %410 = select i1 %408, i32 %409, i32 %405
  %411 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %410) #5
  br label %412

412:                                              ; preds = %406, %398, %391, %384, %378
  %413 = phi double [ %379, %378 ], [ %380, %384 ], [ %397, %391 ], [ %379, %398 ], [ %411, %406 ]
  %414 = fcmp oeq double %195, 1.000000e+00
  %415 = select i1 %414, double 1.000000e+00, double %413
  %416 = fmul double %191, %415
  br label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit.i

417:                                              ; preds = %173
  %418 = fcmp olt double %187, 0.000000e+00
  %419 = fdiv double 1.000000e+00, %167
  br i1 %418, label %420, label %.preheader180

420:                                              ; preds = %417
  %421 = tail call i32 @llvm.nvvm.d2i.hi(double 2.000000e+00) #5
  %422 = and i32 %421, 2146435072
  %423 = icmp eq i32 %422, 1062207488
  %424 = icmp slt i32 %421, 0
  %425 = and i32 %421, 2147483647
  %426 = icmp eq i32 %425, 2146435072
  %427 = select i1 %424, i32 0, i32 2146435072
  %428 = icmp ne i32 %425, 1071644672
  %429 = or i32 %427, -2147483648
  br i1 %423, label %.preheader52, label %673

.preheader52:                                     ; preds = %420
  %430 = tail call double @llvm.nvvm.lohi.i2d(i32 -2147483648, i32 1127219200) #5
  %431 = tail call i32 @llvm.nvvm.d2i.lo(double 2.000000e+00) #5
  br i1 %424, label %.preheader52.split.us.preheader, label %.preheader52.split.preheader

.preheader52.split.preheader:                     ; preds = %.preheader52
  %432 = icmp ugt i32 %421, 2130706431
  %433 = and i32 %421, -15728641
  %434 = select i1 %432, i32 %433, i32 %421
  %435 = tail call double @llvm.nvvm.lohi.i2d(i32 %431, i32 %434) #5
  %436 = icmp eq i32 %431, 0
  %437 = and i1 %426, %436
  br label %.preheader52.split

.preheader52.split.us.preheader:                  ; preds = %.preheader52
  %438 = shl i32 %421, 1
  %439 = icmp ugt i32 %438, -33554433
  %440 = and i32 %421, -15728641
  %441 = select i1 %439, i32 %440, i32 %421
  %442 = tail call double @llvm.nvvm.lohi.i2d(i32 %431, i32 %441) #5
  %443 = icmp eq i32 %431, 0
  %444 = and i1 %426, %443
  br label %.preheader52.split.us

.preheader52.split.us:                            ; preds = %661, %.preheader52.split.us.preheader
  %445 = phi double [ %167, %.preheader52.split.us.preheader ], [ %664, %661 ]
  %446 = phi i32 [ 0, %.preheader52.split.us.preheader ], [ %672, %661 ]
  %447 = fdiv double 1.000000e+00, %445
  %448 = fadd double %419, %447
  %449 = fmul double %180, %448
  %450 = tail call double @llvm.sqrt.f64(double %449) #5
  %451 = fsub double %445, %167
  %452 = fmul double %451, %450
  %453 = fadd double %171, %452
  %454 = fadd double %452, %453
  %455 = fmul double %129, %451
  %456 = fmul double %445, %445
  %457 = fmul double %456, 4.000000e+00
  %458 = fmul double %457, %450
  %459 = fdiv double %455, %458
  %460 = fsub double %450, %459
  %461 = fadd double %450, %460
  %462 = fsub double %461, %459
  %463 = tail call double @llvm.sqrt.f64(double %445) #5
  %464 = fmul double %463, 2.000000e+00
  %465 = fmul double %464, %462
  %466 = fdiv double %454, %465
  %467 = fsub double %463, %466
  %468 = tail call i32 @llvm.nvvm.d2i.hi(double %467) #5
  %469 = tail call double @llvm.fabs.f64(double %467) #5
  %470 = tail call i32 @llvm.nvvm.d2i.hi(double %469) #5
  %471 = tail call i32 @llvm.nvvm.d2i.lo(double %469) #5
  %472 = lshr i32 %470, 20
  %473 = icmp eq i32 %472, 0
  %474 = fmul double %469, 0x4350000000000000
  br i1 %473, label %475, label %480

475:                                              ; preds = %.preheader52.split.us
  %476 = tail call i32 @llvm.nvvm.d2i.hi(double %474) #5
  %477 = tail call i32 @llvm.nvvm.d2i.lo(double %474) #5
  %478 = lshr i32 %476, 20
  %479 = add nsw i32 %478, -54
  br label %480

480:                                              ; preds = %475, %.preheader52.split.us
  %481 = phi i32 [ %471, %.preheader52.split.us ], [ %477, %475 ]
  %482 = phi i32 [ %470, %.preheader52.split.us ], [ %476, %475 ]
  %483 = phi i32 [ %472, %.preheader52.split.us ], [ %479, %475 ]
  %484 = add nsw i32 %483, -1023
  %485 = and i32 %482, -2146435073
  %486 = or i32 %485, 1072693248
  %487 = tail call double @llvm.nvvm.lohi.i2d(i32 %481, i32 %486) #5
  %488 = icmp ugt i32 %486, 1073127582
  br i1 %488, label %489, label %495

489:                                              ; preds = %480
  %490 = add nsw i32 %483, -1022
  %491 = tail call i32 @llvm.nvvm.d2i.lo(double %487) #5
  %492 = tail call i32 @llvm.nvvm.d2i.hi(double %487) #5
  %493 = add i32 %492, -1048576
  %494 = tail call double @llvm.nvvm.lohi.i2d(i32 %491, i32 %493) #5
  br label %495

495:                                              ; preds = %489, %480
  %496 = phi double [ %487, %480 ], [ %494, %489 ]
  %497 = phi i32 [ %484, %480 ], [ %490, %489 ]
  %498 = fadd double %496, -1.000000e+00
  %499 = fadd double %496, 1.000000e+00
  %500 = tail call double @llvm.nvvm.rcp.approx.ftz.d(double %499) #5
  %501 = fneg double %499
  %502 = tail call double @llvm.fma.f64(double %501, double %500, double 1.000000e+00) #5
  %503 = tail call double @llvm.fma.f64(double %502, double %502, double %502) #5
  %504 = tail call double @llvm.fma.f64(double %503, double %500, double %500) #5
  %505 = fmul double %498, %504
  %506 = fadd double %505, %505
  %507 = fmul double %506, %506
  %508 = tail call double @llvm.fma.f64(double %507, double 0x3EB0F5FF7D2CAFE2, double 0x3ED0F5D241AD3B5A) #5
  %509 = tail call double @llvm.fma.f64(double %508, double %507, double 0x3EF3B20A75488A3F) #5
  %510 = tail call double @llvm.fma.f64(double %509, double %507, double 0x3F1745CDE4FAECD5) #5
  %511 = tail call double @llvm.fma.f64(double %510, double %507, double 0x3F3C71C7258A578B) #5
  %512 = tail call double @llvm.fma.f64(double %511, double %507, double 0x3F6249249242B910) #5
  %513 = tail call double @llvm.fma.f64(double %512, double %507, double 0x3F89999999999DFB) #5
  %514 = fmul double %507, %513
  %515 = fsub double %498, %506
  %516 = fmul double %515, 2.000000e+00
  %517 = fneg double %506
  %518 = tail call double @llvm.fma.f64(double %517, double %498, double %516) #5
  %519 = fmul double %504, %518
  %520 = fadd double %514, 0x3FB5555555555555
  %521 = fsub double 0x3FB5555555555555, %520
  %522 = fadd double %514, %521
  %523 = fadd double %522, 0.000000e+00
  %524 = fadd double %523, 0xBC46A4CB00B9E7B0
  %525 = fadd double %520, %524
  %526 = fsub double %520, %525
  %527 = fadd double %524, %526
  %528 = fneg double %507
  %529 = tail call double @llvm.fma.f64(double %506, double %506, double %528) #5
  %530 = tail call i32 @llvm.nvvm.d2i.lo(double %519) #5
  %531 = tail call i32 @llvm.nvvm.d2i.hi(double %519) #5
  %532 = add i32 %531, 1048576
  %533 = tail call double @llvm.nvvm.lohi.i2d(i32 %530, i32 %532) #5
  %534 = tail call double @llvm.fma.f64(double %506, double %533, double %529) #5
  %535 = fmul double %506, %507
  %536 = fneg double %535
  %537 = tail call double @llvm.fma.f64(double %507, double %506, double %536) #5
  %538 = tail call double @llvm.fma.f64(double %507, double %519, double %537) #5
  %539 = tail call double @llvm.fma.f64(double %534, double %506, double %538) #5
  %540 = fmul double %535, %525
  %541 = fneg double %540
  %542 = tail call double @llvm.fma.f64(double %525, double %535, double %541) #5
  %543 = tail call double @llvm.fma.f64(double %525, double %539, double %542) #5
  %544 = tail call double @llvm.fma.f64(double %527, double %535, double %543) #5
  %545 = fadd double %540, %544
  %546 = fsub double %540, %545
  %547 = fadd double %544, %546
  %548 = fadd double %506, %545
  %549 = fsub double %506, %548
  %550 = fadd double %545, %549
  %551 = fadd double %547, %550
  %552 = fadd double %519, %551
  %553 = fadd double %548, %552
  %554 = fsub double %548, %553
  %555 = fadd double %552, %554
  %556 = xor i32 %497, -2147483648
  %557 = tail call double @llvm.nvvm.lohi.i2d(i32 %556, i32 1127219200) #5
  %558 = fsub double %557, %430
  %559 = tail call double @llvm.fma.f64(double %558, double 0x3FE62E42FEFA39EF, double %553) #5
  %560 = fneg double %558
  %561 = tail call double @llvm.fma.f64(double %560, double 0x3FE62E42FEFA39EF, double %559) #5
  %562 = fsub double %561, %553
  %563 = fsub double %555, %562
  %564 = tail call double @llvm.fma.f64(double %558, double 0x3C7ABC9E3B39803F, double %563) #5
  %565 = fadd double %559, %564
  %566 = fsub double %559, %565
  %567 = fadd double %564, %566
  %568 = fmul double %442, %565
  %569 = fneg double %568
  %570 = tail call double @llvm.fma.f64(double %565, double %442, double %569) #5
  %571 = tail call double @llvm.fma.f64(double %567, double %442, double %570) #5
  %572 = fadd double %568, %571
  %573 = tail call double @llvm.fma.f64(double %572, double 0x3FF71547652B82FE, double 0x4338000000000000) #5
  %574 = tail call i32 @llvm.nvvm.d2i.lo(double %573) #5
  %575 = fadd double %573, 0xC338000000000000
  %576 = tail call double @llvm.fma.f64(double %575, double 0xBFE62E42FEFA39EF, double %572) #5
  %577 = tail call double @llvm.fma.f64(double %575, double 0xBC7ABC9E3B39803F, double %576) #5
  %578 = tail call double @llvm.fma.f64(double %577, double 0x3E5ADE1569CE2BDF, double 0x3E928AF3FCA213EA) #5
  %579 = tail call double @llvm.fma.f64(double %578, double %577, double 0x3EC71DEE62401315) #5
  %580 = tail call double @llvm.fma.f64(double %579, double %577, double 0x3EFA01997C89EB71) #5
  %581 = tail call double @llvm.fma.f64(double %580, double %577, double 0x3F2A01A014761F65) #5
  %582 = tail call double @llvm.fma.f64(double %581, double %577, double 0x3F56C16C1852B7AF) #5
  %583 = tail call double @llvm.fma.f64(double %582, double %577, double 0x3F81111111122322) #5
  %584 = tail call double @llvm.fma.f64(double %583, double %577, double 0x3FA55555555502A1) #5
  %585 = tail call double @llvm.fma.f64(double %584, double %577, double 0x3FC5555555555511) #5
  %586 = tail call double @llvm.fma.f64(double %585, double %577, double 0x3FE000000000000B) #5
  %587 = tail call double @llvm.fma.f64(double %586, double %577, double 1.000000e+00) #5
  %588 = tail call double @llvm.fma.f64(double %587, double %577, double 1.000000e+00) #5
  %589 = tail call i32 @llvm.nvvm.d2i.lo(double %588) #5
  %590 = tail call i32 @llvm.nvvm.d2i.hi(double %588) #5
  %591 = shl i32 %574, 20
  %592 = add i32 %590, %591
  %593 = tail call double @llvm.nvvm.lohi.i2d(i32 %589, i32 %592) #5
  %594 = tail call i32 @llvm.nvvm.d2i.hi(double %572) #5
  %595 = bitcast i32 %594 to float
  %596 = tail call float @llvm.fabs.f32(float %595) #5
  %597 = fcmp olt float %596, 0x4010C46560000000
  br i1 %597, label %__internal_accurate_pow.exit14, label %598

598:                                              ; preds = %495
  %599 = fcmp olt double %572, 0.000000e+00
  %600 = fadd double %572, 0x7FF0000000000000
  %601 = select i1 %599, double 0.000000e+00, double %600
  %602 = fcmp olt float %596, 0x4010E90000000000
  br i1 %602, label %603, label %__internal_accurate_pow.exit14

603:                                              ; preds = %598
  %604 = sdiv i32 %574, 2
  %605 = shl i32 %604, 20
  %606 = add i32 %590, %605
  %607 = tail call double @llvm.nvvm.lohi.i2d(i32 %589, i32 %606) #5
  %608 = sub nsw i32 %574, %604
  %609 = shl i32 %608, 20
  %610 = add nsw i32 %609, 1072693248
  %611 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %610) #5
  %612 = fmul double %607, %611
  br label %__internal_accurate_pow.exit14

__internal_accurate_pow.exit14:                   ; preds = %603, %598, %495
  %613 = phi double [ %593, %495 ], [ %601, %598 ], [ %612, %603 ]
  %614 = fsub double %568, %572
  %615 = fadd double %571, %614
  %616 = tail call i32 @llvm.nvvm.d2i.lo(double %613) #5
  %617 = tail call i32 @llvm.nvvm.d2i.hi(double %613) #5
  %618 = and i32 %617, 2147483647
  %619 = icmp eq i32 %618, 2146435072
  %620 = icmp eq i32 %616, 0
  %621 = and i1 %620, %619
  %622 = tail call double @llvm.fma.f64(double %613, double %615, double %613) #5
  %623 = select i1 %621, double %613, double %622
  %624 = icmp slt i32 %468, 0
  br i1 %624, label %625, label %630

625:                                              ; preds = %__internal_accurate_pow.exit14
  %626 = tail call i32 @llvm.nvvm.d2i.hi(double %623) #5
  %627 = tail call i32 @llvm.nvvm.d2i.lo(double %623) #5
  %628 = xor i32 %626, -2147483648
  %629 = tail call double @llvm.nvvm.lohi.i2d(i32 %627, i32 %628) #5
  br label %630

630:                                              ; preds = %625, %__internal_accurate_pow.exit14
  %631 = phi double [ %623, %__internal_accurate_pow.exit14 ], [ %629, %625 ]
  %632 = fcmp oeq double %467, 0.000000e+00
  br i1 %632, label %633, label %636

633:                                              ; preds = %630
  %634 = or i32 %468, 2146435072
  %635 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %634) #5
  br label %636

636:                                              ; preds = %633, %630
  %637 = phi double [ %631, %630 ], [ %635, %633 ]
  %638 = fadd double %467, 2.000000e+00
  %639 = tail call i32 @llvm.nvvm.d2i.hi(double %638) #5
  %640 = and i32 %639, 2146435072
  %641 = icmp eq i32 %640, 2146435072
  br i1 %641, label %642, label %661

642:                                              ; preds = %636
  %643 = fcmp ugt double %469, 0x7FF0000000000000
  br i1 %643, label %661, label %644

644:                                              ; preds = %642
  br i1 %444, label %655, label %645

645:                                              ; preds = %644
  %646 = tail call i32 @llvm.nvvm.d2i.lo(double %467) #5
  %647 = and i32 %468, 2147483647
  %648 = icmp eq i32 %647, 2146435072
  %649 = icmp eq i32 %646, 0
  %650 = and i1 %648, %649
  br i1 %650, label %651, label %661

651:                                              ; preds = %645
  %652 = and i1 %428, %624
  %653 = select i1 %652, i32 %429, i32 %427
  %654 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %653) #5
  br label %661

655:                                              ; preds = %644
  %656 = fcmp ogt double %469, 1.000000e+00
  %657 = select i1 %656, i32 0, i32 2146435072
  %658 = fcmp oeq double %467, -1.000000e+00
  %659 = select i1 %658, i32 1072693248, i32 %657
  %660 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %659) #5
  br label %661

661:                                              ; preds = %655, %651, %645, %642, %636
  %662 = phi double [ %637, %636 ], [ %638, %642 ], [ %637, %645 ], [ %654, %651 ], [ %660, %655 ]
  %663 = fcmp oeq double %467, 1.000000e+00
  %664 = select i1 %663, double 1.000000e+00, double %662
  %665 = fsub double %445, %664
  %666 = tail call double @llvm.fabs.f64(double %665) #5
  %667 = tail call double @llvm.fabs.f64(double %445) #5
  %668 = fmul double %667, 1.000000e-04
  %669 = fcmp ole double %666, %668
  %670 = icmp ugt i32 %446, 9
  %671 = or i1 %670, %669
  %672 = add nuw nsw i32 %446, 1
  br i1 %671, label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit.i, label %.preheader52.split.us

673:                                              ; preds = %420
  %674 = select i1 %424, i32 2146435072, i32 0
  %675 = tail call double @llvm.nvvm.lohi.i2d(i32 -2147483648, i32 1127219200) #5
  %676 = tail call i32 @llvm.nvvm.d2i.lo(double 2.000000e+00) #5
  %677 = shl i32 %421, 1
  %678 = icmp ugt i32 %677, -33554433
  %679 = and i32 %421, -15728641
  %680 = select i1 %678, i32 %679, i32 %421
  %681 = tail call double @llvm.nvvm.lohi.i2d(i32 %676, i32 %680) #5
  br i1 %426, label %.split75.us.preheader, label %.split75

.split75.us.preheader:                            ; preds = %673
  %682 = icmp eq i32 %676, 0
  br label %.split75.us

.split75.us:                                      ; preds = %890, %.split75.us.preheader
  %683 = phi double [ %167, %.split75.us.preheader ], [ %893, %890 ]
  %684 = phi i32 [ 0, %.split75.us.preheader ], [ %901, %890 ]
  %685 = fdiv double 1.000000e+00, %683
  %686 = fadd double %419, %685
  %687 = fmul double %180, %686
  %688 = tail call double @llvm.sqrt.f64(double %687) #5
  %689 = fsub double %683, %167
  %690 = fmul double %689, %688
  %691 = fadd double %171, %690
  %692 = fadd double %690, %691
  %693 = fmul double %129, %689
  %694 = fmul double %683, %683
  %695 = fmul double %694, 4.000000e+00
  %696 = fmul double %695, %688
  %697 = fdiv double %693, %696
  %698 = fsub double %688, %697
  %699 = fadd double %688, %698
  %700 = fsub double %699, %697
  %701 = tail call double @llvm.sqrt.f64(double %683) #5
  %702 = fmul double %701, 2.000000e+00
  %703 = fmul double %702, %700
  %704 = fdiv double %692, %703
  %705 = fsub double %701, %704
  %706 = tail call i32 @llvm.nvvm.d2i.hi(double %705) #5
  %707 = tail call double @llvm.fabs.f64(double %705) #5
  %708 = tail call i32 @llvm.nvvm.d2i.hi(double %707) #5
  %709 = tail call i32 @llvm.nvvm.d2i.lo(double %707) #5
  %710 = lshr i32 %708, 20
  %711 = icmp eq i32 %710, 0
  %712 = fmul double %707, 0x4350000000000000
  br i1 %711, label %713, label %718

713:                                              ; preds = %.split75.us
  %714 = tail call i32 @llvm.nvvm.d2i.hi(double %712) #5
  %715 = tail call i32 @llvm.nvvm.d2i.lo(double %712) #5
  %716 = lshr i32 %714, 20
  %717 = add nsw i32 %716, -54
  br label %718

718:                                              ; preds = %713, %.split75.us
  %719 = phi i32 [ %709, %.split75.us ], [ %715, %713 ]
  %720 = phi i32 [ %708, %.split75.us ], [ %714, %713 ]
  %721 = phi i32 [ %710, %.split75.us ], [ %717, %713 ]
  %722 = add nsw i32 %721, -1023
  %723 = and i32 %720, -2146435073
  %724 = or i32 %723, 1072693248
  %725 = tail call double @llvm.nvvm.lohi.i2d(i32 %719, i32 %724) #5
  %726 = icmp ugt i32 %724, 1073127582
  br i1 %726, label %727, label %733

727:                                              ; preds = %718
  %728 = add nsw i32 %721, -1022
  %729 = tail call i32 @llvm.nvvm.d2i.lo(double %725) #5
  %730 = tail call i32 @llvm.nvvm.d2i.hi(double %725) #5
  %731 = add i32 %730, -1048576
  %732 = tail call double @llvm.nvvm.lohi.i2d(i32 %729, i32 %731) #5
  br label %733

733:                                              ; preds = %727, %718
  %734 = phi double [ %725, %718 ], [ %732, %727 ]
  %735 = phi i32 [ %722, %718 ], [ %728, %727 ]
  %736 = fadd double %734, -1.000000e+00
  %737 = fadd double %734, 1.000000e+00
  %738 = tail call double @llvm.nvvm.rcp.approx.ftz.d(double %737) #5
  %739 = fneg double %737
  %740 = tail call double @llvm.fma.f64(double %739, double %738, double 1.000000e+00) #5
  %741 = tail call double @llvm.fma.f64(double %740, double %740, double %740) #5
  %742 = tail call double @llvm.fma.f64(double %741, double %738, double %738) #5
  %743 = fmul double %736, %742
  %744 = fadd double %743, %743
  %745 = fmul double %744, %744
  %746 = tail call double @llvm.fma.f64(double %745, double 0x3EB0F5FF7D2CAFE2, double 0x3ED0F5D241AD3B5A) #5
  %747 = tail call double @llvm.fma.f64(double %746, double %745, double 0x3EF3B20A75488A3F) #5
  %748 = tail call double @llvm.fma.f64(double %747, double %745, double 0x3F1745CDE4FAECD5) #5
  %749 = tail call double @llvm.fma.f64(double %748, double %745, double 0x3F3C71C7258A578B) #5
  %750 = tail call double @llvm.fma.f64(double %749, double %745, double 0x3F6249249242B910) #5
  %751 = tail call double @llvm.fma.f64(double %750, double %745, double 0x3F89999999999DFB) #5
  %752 = fmul double %745, %751
  %753 = fsub double %736, %744
  %754 = fmul double %753, 2.000000e+00
  %755 = fneg double %744
  %756 = tail call double @llvm.fma.f64(double %755, double %736, double %754) #5
  %757 = fmul double %742, %756
  %758 = fadd double %752, 0x3FB5555555555555
  %759 = fsub double 0x3FB5555555555555, %758
  %760 = fadd double %752, %759
  %761 = fadd double %760, 0.000000e+00
  %762 = fadd double %761, 0xBC46A4CB00B9E7B0
  %763 = fadd double %758, %762
  %764 = fsub double %758, %763
  %765 = fadd double %762, %764
  %766 = fneg double %745
  %767 = tail call double @llvm.fma.f64(double %744, double %744, double %766) #5
  %768 = tail call i32 @llvm.nvvm.d2i.lo(double %757) #5
  %769 = tail call i32 @llvm.nvvm.d2i.hi(double %757) #5
  %770 = add i32 %769, 1048576
  %771 = tail call double @llvm.nvvm.lohi.i2d(i32 %768, i32 %770) #5
  %772 = tail call double @llvm.fma.f64(double %744, double %771, double %767) #5
  %773 = fmul double %744, %745
  %774 = fneg double %773
  %775 = tail call double @llvm.fma.f64(double %745, double %744, double %774) #5
  %776 = tail call double @llvm.fma.f64(double %745, double %757, double %775) #5
  %777 = tail call double @llvm.fma.f64(double %772, double %744, double %776) #5
  %778 = fmul double %773, %763
  %779 = fneg double %778
  %780 = tail call double @llvm.fma.f64(double %763, double %773, double %779) #5
  %781 = tail call double @llvm.fma.f64(double %763, double %777, double %780) #5
  %782 = tail call double @llvm.fma.f64(double %765, double %773, double %781) #5
  %783 = fadd double %778, %782
  %784 = fsub double %778, %783
  %785 = fadd double %782, %784
  %786 = fadd double %744, %783
  %787 = fsub double %744, %786
  %788 = fadd double %783, %787
  %789 = fadd double %785, %788
  %790 = fadd double %757, %789
  %791 = fadd double %786, %790
  %792 = fsub double %786, %791
  %793 = fadd double %790, %792
  %794 = xor i32 %735, -2147483648
  %795 = tail call double @llvm.nvvm.lohi.i2d(i32 %794, i32 1127219200) #5
  %796 = fsub double %795, %675
  %797 = tail call double @llvm.fma.f64(double %796, double 0x3FE62E42FEFA39EF, double %791) #5
  %798 = fneg double %796
  %799 = tail call double @llvm.fma.f64(double %798, double 0x3FE62E42FEFA39EF, double %797) #5
  %800 = fsub double %799, %791
  %801 = fsub double %793, %800
  %802 = tail call double @llvm.fma.f64(double %796, double 0x3C7ABC9E3B39803F, double %801) #5
  %803 = fadd double %797, %802
  %804 = fsub double %797, %803
  %805 = fadd double %802, %804
  %806 = fmul double %681, %803
  %807 = fneg double %806
  %808 = tail call double @llvm.fma.f64(double %803, double %681, double %807) #5
  %809 = tail call double @llvm.fma.f64(double %805, double %681, double %808) #5
  %810 = fadd double %806, %809
  %811 = tail call double @llvm.fma.f64(double %810, double 0x3FF71547652B82FE, double 0x4338000000000000) #5
  %812 = tail call i32 @llvm.nvvm.d2i.lo(double %811) #5
  %813 = fadd double %811, 0xC338000000000000
  %814 = tail call double @llvm.fma.f64(double %813, double 0xBFE62E42FEFA39EF, double %810) #5
  %815 = tail call double @llvm.fma.f64(double %813, double 0xBC7ABC9E3B39803F, double %814) #5
  %816 = tail call double @llvm.fma.f64(double %815, double 0x3E5ADE1569CE2BDF, double 0x3E928AF3FCA213EA) #5
  %817 = tail call double @llvm.fma.f64(double %816, double %815, double 0x3EC71DEE62401315) #5
  %818 = tail call double @llvm.fma.f64(double %817, double %815, double 0x3EFA01997C89EB71) #5
  %819 = tail call double @llvm.fma.f64(double %818, double %815, double 0x3F2A01A014761F65) #5
  %820 = tail call double @llvm.fma.f64(double %819, double %815, double 0x3F56C16C1852B7AF) #5
  %821 = tail call double @llvm.fma.f64(double %820, double %815, double 0x3F81111111122322) #5
  %822 = tail call double @llvm.fma.f64(double %821, double %815, double 0x3FA55555555502A1) #5
  %823 = tail call double @llvm.fma.f64(double %822, double %815, double 0x3FC5555555555511) #5
  %824 = tail call double @llvm.fma.f64(double %823, double %815, double 0x3FE000000000000B) #5
  %825 = tail call double @llvm.fma.f64(double %824, double %815, double 1.000000e+00) #5
  %826 = tail call double @llvm.fma.f64(double %825, double %815, double 1.000000e+00) #5
  %827 = tail call i32 @llvm.nvvm.d2i.lo(double %826) #5
  %828 = tail call i32 @llvm.nvvm.d2i.hi(double %826) #5
  %829 = shl i32 %812, 20
  %830 = add i32 %828, %829
  %831 = tail call double @llvm.nvvm.lohi.i2d(i32 %827, i32 %830) #5
  %832 = tail call i32 @llvm.nvvm.d2i.hi(double %810) #5
  %833 = bitcast i32 %832 to float
  %834 = tail call float @llvm.fabs.f32(float %833) #5
  %835 = fcmp olt float %834, 0x4010C46560000000
  br i1 %835, label %__internal_accurate_pow.exit13, label %836

836:                                              ; preds = %733
  %837 = fcmp olt double %810, 0.000000e+00
  %838 = fadd double %810, 0x7FF0000000000000
  %839 = select i1 %837, double 0.000000e+00, double %838
  %840 = fcmp olt float %834, 0x4010E90000000000
  br i1 %840, label %841, label %__internal_accurate_pow.exit13

841:                                              ; preds = %836
  %842 = sdiv i32 %812, 2
  %843 = shl i32 %842, 20
  %844 = add i32 %828, %843
  %845 = tail call double @llvm.nvvm.lohi.i2d(i32 %827, i32 %844) #5
  %846 = sub nsw i32 %812, %842
  %847 = shl i32 %846, 20
  %848 = add nsw i32 %847, 1072693248
  %849 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %848) #5
  %850 = fmul double %845, %849
  br label %__internal_accurate_pow.exit13

__internal_accurate_pow.exit13:                   ; preds = %841, %836, %733
  %851 = phi double [ %831, %733 ], [ %839, %836 ], [ %850, %841 ]
  %852 = fsub double %806, %810
  %853 = fadd double %809, %852
  %854 = tail call i32 @llvm.nvvm.d2i.lo(double %851) #5
  %855 = tail call i32 @llvm.nvvm.d2i.hi(double %851) #5
  %856 = and i32 %855, 2147483647
  %857 = icmp eq i32 %856, 2146435072
  %858 = icmp eq i32 %854, 0
  %859 = and i1 %858, %857
  %860 = tail call double @llvm.fma.f64(double %851, double %853, double %851) #5
  %861 = select i1 %859, double %851, double %860
  %862 = fcmp oeq double %705, 0.000000e+00
  br i1 %862, label %863, label %865

863:                                              ; preds = %__internal_accurate_pow.exit13
  %864 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %674) #5
  br label %865

865:                                              ; preds = %863, %__internal_accurate_pow.exit13
  %866 = phi double [ %861, %__internal_accurate_pow.exit13 ], [ %864, %863 ]
  %867 = fadd double %705, 2.000000e+00
  %868 = tail call i32 @llvm.nvvm.d2i.hi(double %867) #5
  %869 = and i32 %868, 2146435072
  %870 = icmp eq i32 %869, 2146435072
  br i1 %870, label %871, label %890

871:                                              ; preds = %865
  %872 = fcmp ugt double %707, 0x7FF0000000000000
  br i1 %872, label %890, label %873

873:                                              ; preds = %871
  br i1 %682, label %882, label %874

874:                                              ; preds = %873
  %875 = tail call i32 @llvm.nvvm.d2i.lo(double %705) #5
  %876 = and i32 %706, 2147483647
  %877 = icmp eq i32 %876, 2146435072
  %878 = icmp eq i32 %875, 0
  %879 = and i1 %877, %878
  br i1 %879, label %880, label %890

880:                                              ; preds = %874
  %881 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %427) #5
  br label %890

882:                                              ; preds = %873
  %883 = fcmp ogt double %707, 1.000000e+00
  %884 = select i1 %883, i32 2146435072, i32 0
  %885 = xor i32 %884, 2146435072
  %886 = select i1 %424, i32 %885, i32 %884
  %887 = fcmp oeq double %705, -1.000000e+00
  %888 = select i1 %887, i32 1072693248, i32 %886
  %889 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %888) #5
  br label %890

890:                                              ; preds = %882, %880, %874, %871, %865
  %891 = phi double [ %866, %865 ], [ %867, %871 ], [ %866, %874 ], [ %881, %880 ], [ %889, %882 ]
  %892 = fcmp oeq double %705, 1.000000e+00
  %893 = select i1 %892, double 1.000000e+00, double %891
  %894 = fsub double %683, %893
  %895 = tail call double @llvm.fabs.f64(double %894) #5
  %896 = tail call double @llvm.fabs.f64(double %683) #5
  %897 = fmul double %896, 1.000000e-04
  %898 = fcmp ole double %895, %897
  %899 = icmp ugt i32 %684, 9
  %900 = or i1 %899, %898
  %901 = add nuw nsw i32 %684, 1
  br i1 %900, label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit.i, label %.split75.us

.preheader52.split:                               ; preds = %1117, %.preheader52.split.preheader
  %902 = phi double [ %167, %.preheader52.split.preheader ], [ %1120, %1117 ]
  %903 = phi i32 [ 0, %.preheader52.split.preheader ], [ %1128, %1117 ]
  %904 = fdiv double 1.000000e+00, %902
  %905 = fadd double %419, %904
  %906 = fmul double %180, %905
  %907 = tail call double @llvm.sqrt.f64(double %906) #5
  %908 = fsub double %902, %167
  %909 = fmul double %908, %907
  %910 = fadd double %171, %909
  %911 = fadd double %909, %910
  %912 = fmul double %129, %908
  %913 = fmul double %902, %902
  %914 = fmul double %913, 4.000000e+00
  %915 = fmul double %914, %907
  %916 = fdiv double %912, %915
  %917 = fsub double %907, %916
  %918 = fadd double %907, %917
  %919 = fsub double %918, %916
  %920 = tail call double @llvm.sqrt.f64(double %902) #5
  %921 = fmul double %920, 2.000000e+00
  %922 = fmul double %921, %919
  %923 = fdiv double %911, %922
  %924 = fsub double %920, %923
  %925 = tail call i32 @llvm.nvvm.d2i.hi(double %924) #5
  %926 = tail call double @llvm.fabs.f64(double %924) #5
  %927 = tail call i32 @llvm.nvvm.d2i.hi(double %926) #5
  %928 = tail call i32 @llvm.nvvm.d2i.lo(double %926) #5
  %929 = lshr i32 %927, 20
  %930 = icmp eq i32 %929, 0
  %931 = fmul double %926, 0x4350000000000000
  br i1 %930, label %932, label %937

932:                                              ; preds = %.preheader52.split
  %933 = tail call i32 @llvm.nvvm.d2i.hi(double %931) #5
  %934 = tail call i32 @llvm.nvvm.d2i.lo(double %931) #5
  %935 = lshr i32 %933, 20
  %936 = add nsw i32 %935, -54
  br label %937

937:                                              ; preds = %932, %.preheader52.split
  %938 = phi i32 [ %928, %.preheader52.split ], [ %934, %932 ]
  %939 = phi i32 [ %927, %.preheader52.split ], [ %933, %932 ]
  %940 = phi i32 [ %929, %.preheader52.split ], [ %936, %932 ]
  %941 = add nsw i32 %940, -1023
  %942 = and i32 %939, -2146435073
  %943 = or i32 %942, 1072693248
  %944 = tail call double @llvm.nvvm.lohi.i2d(i32 %938, i32 %943) #5
  %945 = icmp ugt i32 %943, 1073127582
  br i1 %945, label %946, label %952

946:                                              ; preds = %937
  %947 = add nsw i32 %940, -1022
  %948 = tail call i32 @llvm.nvvm.d2i.lo(double %944) #5
  %949 = tail call i32 @llvm.nvvm.d2i.hi(double %944) #5
  %950 = add i32 %949, -1048576
  %951 = tail call double @llvm.nvvm.lohi.i2d(i32 %948, i32 %950) #5
  br label %952

952:                                              ; preds = %946, %937
  %953 = phi double [ %944, %937 ], [ %951, %946 ]
  %954 = phi i32 [ %941, %937 ], [ %947, %946 ]
  %955 = fadd double %953, -1.000000e+00
  %956 = fadd double %953, 1.000000e+00
  %957 = tail call double @llvm.nvvm.rcp.approx.ftz.d(double %956) #5
  %958 = fneg double %956
  %959 = tail call double @llvm.fma.f64(double %958, double %957, double 1.000000e+00) #5
  %960 = tail call double @llvm.fma.f64(double %959, double %959, double %959) #5
  %961 = tail call double @llvm.fma.f64(double %960, double %957, double %957) #5
  %962 = fmul double %955, %961
  %963 = fadd double %962, %962
  %964 = fmul double %963, %963
  %965 = tail call double @llvm.fma.f64(double %964, double 0x3EB0F5FF7D2CAFE2, double 0x3ED0F5D241AD3B5A) #5
  %966 = tail call double @llvm.fma.f64(double %965, double %964, double 0x3EF3B20A75488A3F) #5
  %967 = tail call double @llvm.fma.f64(double %966, double %964, double 0x3F1745CDE4FAECD5) #5
  %968 = tail call double @llvm.fma.f64(double %967, double %964, double 0x3F3C71C7258A578B) #5
  %969 = tail call double @llvm.fma.f64(double %968, double %964, double 0x3F6249249242B910) #5
  %970 = tail call double @llvm.fma.f64(double %969, double %964, double 0x3F89999999999DFB) #5
  %971 = fmul double %964, %970
  %972 = fsub double %955, %963
  %973 = fmul double %972, 2.000000e+00
  %974 = fneg double %963
  %975 = tail call double @llvm.fma.f64(double %974, double %955, double %973) #5
  %976 = fmul double %961, %975
  %977 = fadd double %971, 0x3FB5555555555555
  %978 = fsub double 0x3FB5555555555555, %977
  %979 = fadd double %971, %978
  %980 = fadd double %979, 0.000000e+00
  %981 = fadd double %980, 0xBC46A4CB00B9E7B0
  %982 = fadd double %977, %981
  %983 = fsub double %977, %982
  %984 = fadd double %981, %983
  %985 = fneg double %964
  %986 = tail call double @llvm.fma.f64(double %963, double %963, double %985) #5
  %987 = tail call i32 @llvm.nvvm.d2i.lo(double %976) #5
  %988 = tail call i32 @llvm.nvvm.d2i.hi(double %976) #5
  %989 = add i32 %988, 1048576
  %990 = tail call double @llvm.nvvm.lohi.i2d(i32 %987, i32 %989) #5
  %991 = tail call double @llvm.fma.f64(double %963, double %990, double %986) #5
  %992 = fmul double %963, %964
  %993 = fneg double %992
  %994 = tail call double @llvm.fma.f64(double %964, double %963, double %993) #5
  %995 = tail call double @llvm.fma.f64(double %964, double %976, double %994) #5
  %996 = tail call double @llvm.fma.f64(double %991, double %963, double %995) #5
  %997 = fmul double %992, %982
  %998 = fneg double %997
  %999 = tail call double @llvm.fma.f64(double %982, double %992, double %998) #5
  %1000 = tail call double @llvm.fma.f64(double %982, double %996, double %999) #5
  %1001 = tail call double @llvm.fma.f64(double %984, double %992, double %1000) #5
  %1002 = fadd double %997, %1001
  %1003 = fsub double %997, %1002
  %1004 = fadd double %1001, %1003
  %1005 = fadd double %963, %1002
  %1006 = fsub double %963, %1005
  %1007 = fadd double %1002, %1006
  %1008 = fadd double %1004, %1007
  %1009 = fadd double %976, %1008
  %1010 = fadd double %1005, %1009
  %1011 = fsub double %1005, %1010
  %1012 = fadd double %1009, %1011
  %1013 = xor i32 %954, -2147483648
  %1014 = tail call double @llvm.nvvm.lohi.i2d(i32 %1013, i32 1127219200) #5
  %1015 = fsub double %1014, %430
  %1016 = tail call double @llvm.fma.f64(double %1015, double 0x3FE62E42FEFA39EF, double %1010) #5
  %1017 = fneg double %1015
  %1018 = tail call double @llvm.fma.f64(double %1017, double 0x3FE62E42FEFA39EF, double %1016) #5
  %1019 = fsub double %1018, %1010
  %1020 = fsub double %1012, %1019
  %1021 = tail call double @llvm.fma.f64(double %1015, double 0x3C7ABC9E3B39803F, double %1020) #5
  %1022 = fadd double %1016, %1021
  %1023 = fsub double %1016, %1022
  %1024 = fadd double %1021, %1023
  %1025 = fmul double %435, %1022
  %1026 = fneg double %1025
  %1027 = tail call double @llvm.fma.f64(double %1022, double %435, double %1026) #5
  %1028 = tail call double @llvm.fma.f64(double %1024, double %435, double %1027) #5
  %1029 = fadd double %1025, %1028
  %1030 = tail call double @llvm.fma.f64(double %1029, double 0x3FF71547652B82FE, double 0x4338000000000000) #5
  %1031 = tail call i32 @llvm.nvvm.d2i.lo(double %1030) #5
  %1032 = fadd double %1030, 0xC338000000000000
  %1033 = tail call double @llvm.fma.f64(double %1032, double 0xBFE62E42FEFA39EF, double %1029) #5
  %1034 = tail call double @llvm.fma.f64(double %1032, double 0xBC7ABC9E3B39803F, double %1033) #5
  %1035 = tail call double @llvm.fma.f64(double %1034, double 0x3E5ADE1569CE2BDF, double 0x3E928AF3FCA213EA) #5
  %1036 = tail call double @llvm.fma.f64(double %1035, double %1034, double 0x3EC71DEE62401315) #5
  %1037 = tail call double @llvm.fma.f64(double %1036, double %1034, double 0x3EFA01997C89EB71) #5
  %1038 = tail call double @llvm.fma.f64(double %1037, double %1034, double 0x3F2A01A014761F65) #5
  %1039 = tail call double @llvm.fma.f64(double %1038, double %1034, double 0x3F56C16C1852B7AF) #5
  %1040 = tail call double @llvm.fma.f64(double %1039, double %1034, double 0x3F81111111122322) #5
  %1041 = tail call double @llvm.fma.f64(double %1040, double %1034, double 0x3FA55555555502A1) #5
  %1042 = tail call double @llvm.fma.f64(double %1041, double %1034, double 0x3FC5555555555511) #5
  %1043 = tail call double @llvm.fma.f64(double %1042, double %1034, double 0x3FE000000000000B) #5
  %1044 = tail call double @llvm.fma.f64(double %1043, double %1034, double 1.000000e+00) #5
  %1045 = tail call double @llvm.fma.f64(double %1044, double %1034, double 1.000000e+00) #5
  %1046 = tail call i32 @llvm.nvvm.d2i.lo(double %1045) #5
  %1047 = tail call i32 @llvm.nvvm.d2i.hi(double %1045) #5
  %1048 = shl i32 %1031, 20
  %1049 = add i32 %1047, %1048
  %1050 = tail call double @llvm.nvvm.lohi.i2d(i32 %1046, i32 %1049) #5
  %1051 = tail call i32 @llvm.nvvm.d2i.hi(double %1029) #5
  %1052 = bitcast i32 %1051 to float
  %1053 = tail call float @llvm.fabs.f32(float %1052) #5
  %1054 = fcmp olt float %1053, 0x4010C46560000000
  br i1 %1054, label %__internal_accurate_pow.exit12, label %1055

1055:                                             ; preds = %952
  %1056 = fcmp olt double %1029, 0.000000e+00
  %1057 = fadd double %1029, 0x7FF0000000000000
  %1058 = select i1 %1056, double 0.000000e+00, double %1057
  %1059 = fcmp olt float %1053, 0x4010E90000000000
  br i1 %1059, label %1060, label %__internal_accurate_pow.exit12

1060:                                             ; preds = %1055
  %1061 = sdiv i32 %1031, 2
  %1062 = shl i32 %1061, 20
  %1063 = add i32 %1047, %1062
  %1064 = tail call double @llvm.nvvm.lohi.i2d(i32 %1046, i32 %1063) #5
  %1065 = sub nsw i32 %1031, %1061
  %1066 = shl i32 %1065, 20
  %1067 = add nsw i32 %1066, 1072693248
  %1068 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1067) #5
  %1069 = fmul double %1064, %1068
  br label %__internal_accurate_pow.exit12

__internal_accurate_pow.exit12:                   ; preds = %1060, %1055, %952
  %1070 = phi double [ %1050, %952 ], [ %1058, %1055 ], [ %1069, %1060 ]
  %1071 = fsub double %1025, %1029
  %1072 = fadd double %1028, %1071
  %1073 = tail call i32 @llvm.nvvm.d2i.lo(double %1070) #5
  %1074 = tail call i32 @llvm.nvvm.d2i.hi(double %1070) #5
  %1075 = and i32 %1074, 2147483647
  %1076 = icmp eq i32 %1075, 2146435072
  %1077 = icmp eq i32 %1073, 0
  %1078 = and i1 %1077, %1076
  %1079 = tail call double @llvm.fma.f64(double %1070, double %1072, double %1070) #5
  %1080 = select i1 %1078, double %1070, double %1079
  %1081 = icmp slt i32 %925, 0
  br i1 %1081, label %1082, label %1087

1082:                                             ; preds = %__internal_accurate_pow.exit12
  %1083 = tail call i32 @llvm.nvvm.d2i.hi(double %1080) #5
  %1084 = tail call i32 @llvm.nvvm.d2i.lo(double %1080) #5
  %1085 = xor i32 %1083, -2147483648
  %1086 = tail call double @llvm.nvvm.lohi.i2d(i32 %1084, i32 %1085) #5
  br label %1087

1087:                                             ; preds = %1082, %__internal_accurate_pow.exit12
  %1088 = phi double [ %1080, %__internal_accurate_pow.exit12 ], [ %1086, %1082 ]
  %1089 = fcmp oeq double %924, 0.000000e+00
  br i1 %1089, label %1090, label %1092

1090:                                             ; preds = %1087
  %1091 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %925) #5
  br label %1092

1092:                                             ; preds = %1090, %1087
  %1093 = phi double [ %1088, %1087 ], [ %1091, %1090 ]
  %1094 = fadd double %924, 2.000000e+00
  %1095 = tail call i32 @llvm.nvvm.d2i.hi(double %1094) #5
  %1096 = and i32 %1095, 2146435072
  %1097 = icmp eq i32 %1096, 2146435072
  br i1 %1097, label %1098, label %1117

1098:                                             ; preds = %1092
  %1099 = fcmp ugt double %926, 0x7FF0000000000000
  br i1 %1099, label %1117, label %1100

1100:                                             ; preds = %1098
  br i1 %437, label %1111, label %1101

1101:                                             ; preds = %1100
  %1102 = tail call i32 @llvm.nvvm.d2i.lo(double %924) #5
  %1103 = and i32 %925, 2147483647
  %1104 = icmp eq i32 %1103, 2146435072
  %1105 = icmp eq i32 %1102, 0
  %1106 = and i1 %1104, %1105
  br i1 %1106, label %1107, label %1117

1107:                                             ; preds = %1101
  %1108 = and i1 %428, %1081
  %1109 = select i1 %1108, i32 %429, i32 %427
  %1110 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1109) #5
  br label %1117

1111:                                             ; preds = %1100
  %1112 = fcmp ogt double %926, 1.000000e+00
  %1113 = select i1 %1112, i32 2146435072, i32 0
  %1114 = fcmp oeq double %924, -1.000000e+00
  %1115 = select i1 %1114, i32 1072693248, i32 %1113
  %1116 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1115) #5
  br label %1117

1117:                                             ; preds = %1111, %1107, %1101, %1098, %1092
  %1118 = phi double [ %1093, %1092 ], [ %1094, %1098 ], [ %1093, %1101 ], [ %1110, %1107 ], [ %1116, %1111 ]
  %1119 = fcmp oeq double %924, 1.000000e+00
  %1120 = select i1 %1119, double 1.000000e+00, double %1118
  %1121 = fsub double %902, %1120
  %1122 = tail call double @llvm.fabs.f64(double %1121) #5
  %1123 = tail call double @llvm.fabs.f64(double %902) #5
  %1124 = fmul double %1123, 1.000000e-04
  %1125 = fcmp ole double %1122, %1124
  %1126 = icmp ugt i32 %903, 9
  %1127 = or i1 %1126, %1125
  %1128 = add nuw nsw i32 %903, 1
  br i1 %1127, label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit.i, label %.preheader52.split

.split75:                                         ; preds = %1327, %673
  %1129 = phi double [ %167, %673 ], [ %1330, %1327 ]
  %1130 = phi i32 [ 0, %673 ], [ %1338, %1327 ]
  %1131 = fdiv double 1.000000e+00, %1129
  %1132 = fadd double %419, %1131
  %1133 = fmul double %180, %1132
  %1134 = tail call double @llvm.sqrt.f64(double %1133) #5
  %1135 = fsub double %1129, %167
  %1136 = fmul double %1135, %1134
  %1137 = fadd double %171, %1136
  %1138 = fadd double %1136, %1137
  %1139 = fmul double %129, %1135
  %1140 = fmul double %1129, %1129
  %1141 = fmul double %1140, 4.000000e+00
  %1142 = fmul double %1141, %1134
  %1143 = fdiv double %1139, %1142
  %1144 = fsub double %1134, %1143
  %1145 = fadd double %1134, %1144
  %1146 = fsub double %1145, %1143
  %1147 = tail call double @llvm.sqrt.f64(double %1129) #5
  %1148 = fmul double %1147, 2.000000e+00
  %1149 = fmul double %1148, %1146
  %1150 = fdiv double %1138, %1149
  %1151 = fsub double %1147, %1150
  %1152 = tail call i32 @llvm.nvvm.d2i.hi(double %1151) #5
  %1153 = tail call double @llvm.fabs.f64(double %1151) #5
  %1154 = tail call i32 @llvm.nvvm.d2i.hi(double %1153) #5
  %1155 = tail call i32 @llvm.nvvm.d2i.lo(double %1153) #5
  %1156 = lshr i32 %1154, 20
  %1157 = icmp eq i32 %1156, 0
  %1158 = fmul double %1153, 0x4350000000000000
  br i1 %1157, label %1159, label %1164

1159:                                             ; preds = %.split75
  %1160 = tail call i32 @llvm.nvvm.d2i.hi(double %1158) #5
  %1161 = tail call i32 @llvm.nvvm.d2i.lo(double %1158) #5
  %1162 = lshr i32 %1160, 20
  %1163 = add nsw i32 %1162, -54
  br label %1164

1164:                                             ; preds = %1159, %.split75
  %1165 = phi i32 [ %1155, %.split75 ], [ %1161, %1159 ]
  %1166 = phi i32 [ %1154, %.split75 ], [ %1160, %1159 ]
  %1167 = phi i32 [ %1156, %.split75 ], [ %1163, %1159 ]
  %1168 = add nsw i32 %1167, -1023
  %1169 = and i32 %1166, -2146435073
  %1170 = or i32 %1169, 1072693248
  %1171 = tail call double @llvm.nvvm.lohi.i2d(i32 %1165, i32 %1170) #5
  %1172 = icmp ugt i32 %1170, 1073127582
  br i1 %1172, label %1173, label %1179

1173:                                             ; preds = %1164
  %1174 = add nsw i32 %1167, -1022
  %1175 = tail call i32 @llvm.nvvm.d2i.lo(double %1171) #5
  %1176 = tail call i32 @llvm.nvvm.d2i.hi(double %1171) #5
  %1177 = add i32 %1176, -1048576
  %1178 = tail call double @llvm.nvvm.lohi.i2d(i32 %1175, i32 %1177) #5
  br label %1179

1179:                                             ; preds = %1173, %1164
  %1180 = phi double [ %1171, %1164 ], [ %1178, %1173 ]
  %1181 = phi i32 [ %1168, %1164 ], [ %1174, %1173 ]
  %1182 = fadd double %1180, -1.000000e+00
  %1183 = fadd double %1180, 1.000000e+00
  %1184 = tail call double @llvm.nvvm.rcp.approx.ftz.d(double %1183) #5
  %1185 = fneg double %1183
  %1186 = tail call double @llvm.fma.f64(double %1185, double %1184, double 1.000000e+00) #5
  %1187 = tail call double @llvm.fma.f64(double %1186, double %1186, double %1186) #5
  %1188 = tail call double @llvm.fma.f64(double %1187, double %1184, double %1184) #5
  %1189 = fmul double %1182, %1188
  %1190 = fadd double %1189, %1189
  %1191 = fmul double %1190, %1190
  %1192 = tail call double @llvm.fma.f64(double %1191, double 0x3EB0F5FF7D2CAFE2, double 0x3ED0F5D241AD3B5A) #5
  %1193 = tail call double @llvm.fma.f64(double %1192, double %1191, double 0x3EF3B20A75488A3F) #5
  %1194 = tail call double @llvm.fma.f64(double %1193, double %1191, double 0x3F1745CDE4FAECD5) #5
  %1195 = tail call double @llvm.fma.f64(double %1194, double %1191, double 0x3F3C71C7258A578B) #5
  %1196 = tail call double @llvm.fma.f64(double %1195, double %1191, double 0x3F6249249242B910) #5
  %1197 = tail call double @llvm.fma.f64(double %1196, double %1191, double 0x3F89999999999DFB) #5
  %1198 = fmul double %1191, %1197
  %1199 = fsub double %1182, %1190
  %1200 = fmul double %1199, 2.000000e+00
  %1201 = fneg double %1190
  %1202 = tail call double @llvm.fma.f64(double %1201, double %1182, double %1200) #5
  %1203 = fmul double %1188, %1202
  %1204 = fadd double %1198, 0x3FB5555555555555
  %1205 = fsub double 0x3FB5555555555555, %1204
  %1206 = fadd double %1198, %1205
  %1207 = fadd double %1206, 0.000000e+00
  %1208 = fadd double %1207, 0xBC46A4CB00B9E7B0
  %1209 = fadd double %1204, %1208
  %1210 = fsub double %1204, %1209
  %1211 = fadd double %1208, %1210
  %1212 = fneg double %1191
  %1213 = tail call double @llvm.fma.f64(double %1190, double %1190, double %1212) #5
  %1214 = tail call i32 @llvm.nvvm.d2i.lo(double %1203) #5
  %1215 = tail call i32 @llvm.nvvm.d2i.hi(double %1203) #5
  %1216 = add i32 %1215, 1048576
  %1217 = tail call double @llvm.nvvm.lohi.i2d(i32 %1214, i32 %1216) #5
  %1218 = tail call double @llvm.fma.f64(double %1190, double %1217, double %1213) #5
  %1219 = fmul double %1190, %1191
  %1220 = fneg double %1219
  %1221 = tail call double @llvm.fma.f64(double %1191, double %1190, double %1220) #5
  %1222 = tail call double @llvm.fma.f64(double %1191, double %1203, double %1221) #5
  %1223 = tail call double @llvm.fma.f64(double %1218, double %1190, double %1222) #5
  %1224 = fmul double %1219, %1209
  %1225 = fneg double %1224
  %1226 = tail call double @llvm.fma.f64(double %1209, double %1219, double %1225) #5
  %1227 = tail call double @llvm.fma.f64(double %1209, double %1223, double %1226) #5
  %1228 = tail call double @llvm.fma.f64(double %1211, double %1219, double %1227) #5
  %1229 = fadd double %1224, %1228
  %1230 = fsub double %1224, %1229
  %1231 = fadd double %1228, %1230
  %1232 = fadd double %1190, %1229
  %1233 = fsub double %1190, %1232
  %1234 = fadd double %1229, %1233
  %1235 = fadd double %1231, %1234
  %1236 = fadd double %1203, %1235
  %1237 = fadd double %1232, %1236
  %1238 = fsub double %1232, %1237
  %1239 = fadd double %1236, %1238
  %1240 = xor i32 %1181, -2147483648
  %1241 = tail call double @llvm.nvvm.lohi.i2d(i32 %1240, i32 1127219200) #5
  %1242 = fsub double %1241, %675
  %1243 = tail call double @llvm.fma.f64(double %1242, double 0x3FE62E42FEFA39EF, double %1237) #5
  %1244 = fneg double %1242
  %1245 = tail call double @llvm.fma.f64(double %1244, double 0x3FE62E42FEFA39EF, double %1243) #5
  %1246 = fsub double %1245, %1237
  %1247 = fsub double %1239, %1246
  %1248 = tail call double @llvm.fma.f64(double %1242, double 0x3C7ABC9E3B39803F, double %1247) #5
  %1249 = fadd double %1243, %1248
  %1250 = fsub double %1243, %1249
  %1251 = fadd double %1248, %1250
  %1252 = fmul double %681, %1249
  %1253 = fneg double %1252
  %1254 = tail call double @llvm.fma.f64(double %1249, double %681, double %1253) #5
  %1255 = tail call double @llvm.fma.f64(double %1251, double %681, double %1254) #5
  %1256 = fadd double %1252, %1255
  %1257 = tail call double @llvm.fma.f64(double %1256, double 0x3FF71547652B82FE, double 0x4338000000000000) #5
  %1258 = tail call i32 @llvm.nvvm.d2i.lo(double %1257) #5
  %1259 = fadd double %1257, 0xC338000000000000
  %1260 = tail call double @llvm.fma.f64(double %1259, double 0xBFE62E42FEFA39EF, double %1256) #5
  %1261 = tail call double @llvm.fma.f64(double %1259, double 0xBC7ABC9E3B39803F, double %1260) #5
  %1262 = tail call double @llvm.fma.f64(double %1261, double 0x3E5ADE1569CE2BDF, double 0x3E928AF3FCA213EA) #5
  %1263 = tail call double @llvm.fma.f64(double %1262, double %1261, double 0x3EC71DEE62401315) #5
  %1264 = tail call double @llvm.fma.f64(double %1263, double %1261, double 0x3EFA01997C89EB71) #5
  %1265 = tail call double @llvm.fma.f64(double %1264, double %1261, double 0x3F2A01A014761F65) #5
  %1266 = tail call double @llvm.fma.f64(double %1265, double %1261, double 0x3F56C16C1852B7AF) #5
  %1267 = tail call double @llvm.fma.f64(double %1266, double %1261, double 0x3F81111111122322) #5
  %1268 = tail call double @llvm.fma.f64(double %1267, double %1261, double 0x3FA55555555502A1) #5
  %1269 = tail call double @llvm.fma.f64(double %1268, double %1261, double 0x3FC5555555555511) #5
  %1270 = tail call double @llvm.fma.f64(double %1269, double %1261, double 0x3FE000000000000B) #5
  %1271 = tail call double @llvm.fma.f64(double %1270, double %1261, double 1.000000e+00) #5
  %1272 = tail call double @llvm.fma.f64(double %1271, double %1261, double 1.000000e+00) #5
  %1273 = tail call i32 @llvm.nvvm.d2i.lo(double %1272) #5
  %1274 = tail call i32 @llvm.nvvm.d2i.hi(double %1272) #5
  %1275 = shl i32 %1258, 20
  %1276 = add i32 %1274, %1275
  %1277 = tail call double @llvm.nvvm.lohi.i2d(i32 %1273, i32 %1276) #5
  %1278 = tail call i32 @llvm.nvvm.d2i.hi(double %1256) #5
  %1279 = bitcast i32 %1278 to float
  %1280 = tail call float @llvm.fabs.f32(float %1279) #5
  %1281 = fcmp olt float %1280, 0x4010C46560000000
  br i1 %1281, label %__internal_accurate_pow.exit11, label %1282

1282:                                             ; preds = %1179
  %1283 = fcmp olt double %1256, 0.000000e+00
  %1284 = fadd double %1256, 0x7FF0000000000000
  %1285 = select i1 %1283, double 0.000000e+00, double %1284
  %1286 = fcmp olt float %1280, 0x4010E90000000000
  br i1 %1286, label %1287, label %__internal_accurate_pow.exit11

1287:                                             ; preds = %1282
  %1288 = sdiv i32 %1258, 2
  %1289 = shl i32 %1288, 20
  %1290 = add i32 %1274, %1289
  %1291 = tail call double @llvm.nvvm.lohi.i2d(i32 %1273, i32 %1290) #5
  %1292 = sub nsw i32 %1258, %1288
  %1293 = shl i32 %1292, 20
  %1294 = add nsw i32 %1293, 1072693248
  %1295 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1294) #5
  %1296 = fmul double %1291, %1295
  br label %__internal_accurate_pow.exit11

__internal_accurate_pow.exit11:                   ; preds = %1287, %1282, %1179
  %1297 = phi double [ %1277, %1179 ], [ %1285, %1282 ], [ %1296, %1287 ]
  %1298 = fsub double %1252, %1256
  %1299 = fadd double %1255, %1298
  %1300 = tail call i32 @llvm.nvvm.d2i.lo(double %1297) #5
  %1301 = tail call i32 @llvm.nvvm.d2i.hi(double %1297) #5
  %1302 = and i32 %1301, 2147483647
  %1303 = icmp eq i32 %1302, 2146435072
  %1304 = icmp eq i32 %1300, 0
  %1305 = and i1 %1304, %1303
  %1306 = tail call double @llvm.fma.f64(double %1297, double %1299, double %1297) #5
  %1307 = select i1 %1305, double %1297, double %1306
  %1308 = fcmp oeq double %1151, 0.000000e+00
  br i1 %1308, label %1309, label %1311

1309:                                             ; preds = %__internal_accurate_pow.exit11
  %1310 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %674) #5
  br label %1311

1311:                                             ; preds = %1309, %__internal_accurate_pow.exit11
  %1312 = phi double [ %1307, %__internal_accurate_pow.exit11 ], [ %1310, %1309 ]
  %1313 = fadd double %1151, 2.000000e+00
  %1314 = tail call i32 @llvm.nvvm.d2i.hi(double %1313) #5
  %1315 = and i32 %1314, 2146435072
  %1316 = icmp eq i32 %1315, 2146435072
  br i1 %1316, label %1317, label %1327

1317:                                             ; preds = %1311
  %1318 = fcmp ugt double %1153, 0x7FF0000000000000
  br i1 %1318, label %1327, label %1319

1319:                                             ; preds = %1317
  %1320 = tail call i32 @llvm.nvvm.d2i.lo(double %1151) #5
  %1321 = and i32 %1152, 2147483647
  %1322 = icmp eq i32 %1321, 2146435072
  %1323 = icmp eq i32 %1320, 0
  %1324 = and i1 %1322, %1323
  br i1 %1324, label %1325, label %1327

1325:                                             ; preds = %1319
  %1326 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %427) #5
  br label %1327

1327:                                             ; preds = %1325, %1319, %1317, %1311
  %1328 = phi double [ %1312, %1311 ], [ %1313, %1317 ], [ %1312, %1319 ], [ %1326, %1325 ]
  %1329 = fcmp oeq double %1151, 1.000000e+00
  %1330 = select i1 %1329, double 1.000000e+00, double %1328
  %1331 = fsub double %1129, %1330
  %1332 = tail call double @llvm.fabs.f64(double %1331) #5
  %1333 = tail call double @llvm.fabs.f64(double %1129) #5
  %1334 = fmul double %1333, 1.000000e-04
  %1335 = fcmp ole double %1332, %1334
  %1336 = icmp ugt i32 %1130, 9
  %1337 = or i1 %1336, %1335
  %1338 = add nuw nsw i32 %1130, 1
  br i1 %1337, label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit.i, label %.split75

.preheader180:                                    ; preds = %.preheader180, %417
  %1339 = phi double [ %167, %417 ], [ %1356, %.preheader180 ]
  %1340 = phi i32 [ 0, %417 ], [ %1364, %.preheader180 ]
  %1341 = fmul double %129, %1339
  %1342 = tail call double @llvm.sqrt.f64(double %1341) #5
  %1343 = fsub double %1342, %175
  %1344 = fmul double %1343, 2.000000e+00
  %1345 = fadd double %171, %1344
  %1346 = fsub double %1339, %167
  %1347 = fdiv double 1.000000e+00, %1339
  %1348 = fadd double %419, %1347
  %1349 = fmul double %180, %1348
  %1350 = tail call double @llvm.sqrt.f64(double %1349) #5
  %1351 = fmul double %1346, %1350
  %1352 = fadd double %1345, %1351
  %1353 = fsub double %187, %1352
  %1354 = fdiv double %1353, %179
  %1355 = fdiv double %1352, %1354
  %1356 = fsub double %1339, %1355
  %1357 = fsub double %1339, %1356
  %1358 = tail call double @llvm.fabs.f64(double %1357) #5
  %1359 = tail call double @llvm.fabs.f64(double %1339) #5
  %1360 = fmul double %1359, 1.000000e-04
  %1361 = fcmp ole double %1358, %1360
  %1362 = icmp ugt i32 %1340, 9
  %1363 = or i1 %1362, %1361
  %1364 = add nuw nsw i32 %1340, 1
  br i1 %1363, label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit.i, label %.preheader180

_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit.i: ; preds = %.preheader180, %1327, %1117, %890, %661, %412, %169
  %1365 = phi double [ 0.000000e+00, %169 ], [ %416, %412 ], [ %445, %661 ], [ %683, %890 ], [ %902, %1117 ], [ %1129, %1327 ], [ %1339, %.preheader180 ]
  %1366 = tail call double @llvm.maxnum.f64(double %167, double %1365) #5
  %1367 = fadd double %47, %1366
  %1368 = fcmp olt double %1367, %105
  br i1 %1368, label %1369, label %1371

1369:                                             ; preds = %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit.i
  %1370 = fneg double %166
  br label %2581

1371:                                             ; preds = %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit.i
  %1372 = fadd double %47, %167
  %1373 = fcmp olt double %1372, %105
  br i1 %1373, label %1374, label %2581

1374:                                             ; preds = %1371
  br label %2581

1375:                                             ; preds = %162
  %1376 = fcmp olt double %167, 1.000000e-10
  br i1 %1376, label %1377, label %2581

1377:                                             ; preds = %1375
  %1378 = fneg double %150
  %1379 = fadd double %150, %150
  %1380 = fmul double %129, %152
  %1381 = tail call double @llvm.sqrt.f64(double %1380) #5
  %1382 = fsub double %1381, %1381
  %1383 = fmul double %1382, 2.000000e+00
  %1384 = fadd double %1379, %1383
  %1385 = fsub double %152, %152
  %1386 = fmul double %129, 5.000000e-01
  %1387 = fadd double %152, %152
  %1388 = fmul double %1386, %1387
  %1389 = fmul double %152, %152
  %1390 = fdiv double %1388, %1389
  %1391 = tail call double @llvm.sqrt.f64(double %1390) #5
  %1392 = fmul double %1385, %1391
  %1393 = fadd double %1379, %1392
  %1394 = fcmp ogt double %1384, 0.000000e+00
  br i1 %1394, label %1395, label %1623

1395:                                             ; preds = %1377
  %1396 = fmul double %129, 1.600000e+01
  %1397 = fdiv double 1.000000e+00, %1396
  %1398 = fadd double %1381, %1381
  %1399 = fmul double %1398, 2.000000e+00
  %1400 = fsub double %1399, %1379
  %1401 = tail call double @llvm.maxnum.f64(double %1400, double 0.000000e+00) #5
  %1402 = tail call i32 @llvm.nvvm.d2i.hi(double %1401) #5
  %1403 = tail call i32 @llvm.nvvm.d2i.hi(double 2.000000e+00) #5
  %1404 = and i32 %1403, 2146435072
  %1405 = icmp eq i32 %1404, 1062207488
  %1406 = tail call double @llvm.fabs.f64(double %1401) #5
  %1407 = tail call i32 @llvm.nvvm.d2i.hi(double %1406) #5
  %1408 = tail call i32 @llvm.nvvm.d2i.lo(double %1406) #5
  %1409 = lshr i32 %1407, 20
  %1410 = icmp eq i32 %1409, 0
  %1411 = fmul double %1406, 0x4350000000000000
  br i1 %1410, label %1412, label %1417

1412:                                             ; preds = %1395
  %1413 = tail call i32 @llvm.nvvm.d2i.hi(double %1411) #5
  %1414 = tail call i32 @llvm.nvvm.d2i.lo(double %1411) #5
  %1415 = lshr i32 %1413, 20
  %1416 = add nsw i32 %1415, -54
  br label %1417

1417:                                             ; preds = %1412, %1395
  %1418 = phi i32 [ %1408, %1395 ], [ %1414, %1412 ]
  %1419 = phi i32 [ %1407, %1395 ], [ %1413, %1412 ]
  %1420 = phi i32 [ %1409, %1395 ], [ %1416, %1412 ]
  %1421 = add nsw i32 %1420, -1023
  %1422 = and i32 %1419, -2146435073
  %1423 = or i32 %1422, 1072693248
  %1424 = tail call double @llvm.nvvm.lohi.i2d(i32 %1418, i32 %1423) #5
  %1425 = icmp ugt i32 %1423, 1073127582
  br i1 %1425, label %1426, label %1432

1426:                                             ; preds = %1417
  %1427 = add nsw i32 %1420, -1022
  %1428 = tail call i32 @llvm.nvvm.d2i.lo(double %1424) #5
  %1429 = tail call i32 @llvm.nvvm.d2i.hi(double %1424) #5
  %1430 = add i32 %1429, -1048576
  %1431 = tail call double @llvm.nvvm.lohi.i2d(i32 %1428, i32 %1430) #5
  br label %1432

1432:                                             ; preds = %1426, %1417
  %1433 = phi double [ %1424, %1417 ], [ %1431, %1426 ]
  %1434 = phi i32 [ %1421, %1417 ], [ %1427, %1426 ]
  %1435 = fadd double %1433, -1.000000e+00
  %1436 = fadd double %1433, 1.000000e+00
  %1437 = tail call double @llvm.nvvm.rcp.approx.ftz.d(double %1436) #5
  %1438 = fneg double %1436
  %1439 = tail call double @llvm.fma.f64(double %1438, double %1437, double 1.000000e+00) #5
  %1440 = tail call double @llvm.fma.f64(double %1439, double %1439, double %1439) #5
  %1441 = tail call double @llvm.fma.f64(double %1440, double %1437, double %1437) #5
  %1442 = fmul double %1435, %1441
  %1443 = fadd double %1442, %1442
  %1444 = fmul double %1443, %1443
  %1445 = tail call double @llvm.fma.f64(double %1444, double 0x3EB0F5FF7D2CAFE2, double 0x3ED0F5D241AD3B5A) #5
  %1446 = tail call double @llvm.fma.f64(double %1445, double %1444, double 0x3EF3B20A75488A3F) #5
  %1447 = tail call double @llvm.fma.f64(double %1446, double %1444, double 0x3F1745CDE4FAECD5) #5
  %1448 = tail call double @llvm.fma.f64(double %1447, double %1444, double 0x3F3C71C7258A578B) #5
  %1449 = tail call double @llvm.fma.f64(double %1448, double %1444, double 0x3F6249249242B910) #5
  %1450 = tail call double @llvm.fma.f64(double %1449, double %1444, double 0x3F89999999999DFB) #5
  %1451 = fmul double %1444, %1450
  %1452 = fsub double %1435, %1443
  %1453 = fmul double %1452, 2.000000e+00
  %1454 = fneg double %1443
  %1455 = tail call double @llvm.fma.f64(double %1454, double %1435, double %1453) #5
  %1456 = fmul double %1441, %1455
  %1457 = fadd double %1451, 0x3FB5555555555555
  %1458 = fsub double 0x3FB5555555555555, %1457
  %1459 = fadd double %1451, %1458
  %1460 = fadd double %1459, 0.000000e+00
  %1461 = fadd double %1460, 0xBC46A4CB00B9E7B0
  %1462 = fadd double %1457, %1461
  %1463 = fsub double %1457, %1462
  %1464 = fadd double %1461, %1463
  %1465 = fneg double %1444
  %1466 = tail call double @llvm.fma.f64(double %1443, double %1443, double %1465) #5
  %1467 = tail call i32 @llvm.nvvm.d2i.lo(double %1456) #5
  %1468 = tail call i32 @llvm.nvvm.d2i.hi(double %1456) #5
  %1469 = add i32 %1468, 1048576
  %1470 = tail call double @llvm.nvvm.lohi.i2d(i32 %1467, i32 %1469) #5
  %1471 = tail call double @llvm.fma.f64(double %1443, double %1470, double %1466) #5
  %1472 = fmul double %1443, %1444
  %1473 = fneg double %1472
  %1474 = tail call double @llvm.fma.f64(double %1444, double %1443, double %1473) #5
  %1475 = tail call double @llvm.fma.f64(double %1444, double %1456, double %1474) #5
  %1476 = tail call double @llvm.fma.f64(double %1471, double %1443, double %1475) #5
  %1477 = fmul double %1472, %1462
  %1478 = fneg double %1477
  %1479 = tail call double @llvm.fma.f64(double %1462, double %1472, double %1478) #5
  %1480 = tail call double @llvm.fma.f64(double %1462, double %1476, double %1479) #5
  %1481 = tail call double @llvm.fma.f64(double %1464, double %1472, double %1480) #5
  %1482 = fadd double %1477, %1481
  %1483 = fsub double %1477, %1482
  %1484 = fadd double %1481, %1483
  %1485 = fadd double %1443, %1482
  %1486 = fsub double %1443, %1485
  %1487 = fadd double %1482, %1486
  %1488 = fadd double %1484, %1487
  %1489 = fadd double %1456, %1488
  %1490 = fadd double %1485, %1489
  %1491 = fsub double %1485, %1490
  %1492 = fadd double %1489, %1491
  %1493 = xor i32 %1434, -2147483648
  %1494 = tail call double @llvm.nvvm.lohi.i2d(i32 %1493, i32 1127219200) #5
  %1495 = tail call double @llvm.nvvm.lohi.i2d(i32 -2147483648, i32 1127219200) #5
  %1496 = fsub double %1494, %1495
  %1497 = tail call double @llvm.fma.f64(double %1496, double 0x3FE62E42FEFA39EF, double %1490) #5
  %1498 = fneg double %1496
  %1499 = tail call double @llvm.fma.f64(double %1498, double 0x3FE62E42FEFA39EF, double %1497) #5
  %1500 = fsub double %1499, %1490
  %1501 = fsub double %1492, %1500
  %1502 = tail call double @llvm.fma.f64(double %1496, double 0x3C7ABC9E3B39803F, double %1501) #5
  %1503 = fadd double %1497, %1502
  %1504 = fsub double %1497, %1503
  %1505 = fadd double %1502, %1504
  %1506 = tail call i32 @llvm.nvvm.d2i.lo(double 2.000000e+00) #5
  %1507 = shl i32 %1403, 1
  %1508 = icmp ugt i32 %1507, -33554433
  %1509 = and i32 %1403, -15728641
  %1510 = select i1 %1508, i32 %1509, i32 %1403
  %1511 = tail call double @llvm.nvvm.lohi.i2d(i32 %1506, i32 %1510) #5
  %1512 = fmul double %1511, %1503
  %1513 = fneg double %1512
  %1514 = tail call double @llvm.fma.f64(double %1503, double %1511, double %1513) #5
  %1515 = tail call double @llvm.fma.f64(double %1505, double %1511, double %1514) #5
  %1516 = fadd double %1512, %1515
  %1517 = tail call double @llvm.fma.f64(double %1516, double 0x3FF71547652B82FE, double 0x4338000000000000) #5
  %1518 = tail call i32 @llvm.nvvm.d2i.lo(double %1517) #5
  %1519 = fadd double %1517, 0xC338000000000000
  %1520 = tail call double @llvm.fma.f64(double %1519, double 0xBFE62E42FEFA39EF, double %1516) #5
  %1521 = tail call double @llvm.fma.f64(double %1519, double 0xBC7ABC9E3B39803F, double %1520) #5
  %1522 = tail call double @llvm.fma.f64(double %1521, double 0x3E5ADE1569CE2BDF, double 0x3E928AF3FCA213EA) #5
  %1523 = tail call double @llvm.fma.f64(double %1522, double %1521, double 0x3EC71DEE62401315) #5
  %1524 = tail call double @llvm.fma.f64(double %1523, double %1521, double 0x3EFA01997C89EB71) #5
  %1525 = tail call double @llvm.fma.f64(double %1524, double %1521, double 0x3F2A01A014761F65) #5
  %1526 = tail call double @llvm.fma.f64(double %1525, double %1521, double 0x3F56C16C1852B7AF) #5
  %1527 = tail call double @llvm.fma.f64(double %1526, double %1521, double 0x3F81111111122322) #5
  %1528 = tail call double @llvm.fma.f64(double %1527, double %1521, double 0x3FA55555555502A1) #5
  %1529 = tail call double @llvm.fma.f64(double %1528, double %1521, double 0x3FC5555555555511) #5
  %1530 = tail call double @llvm.fma.f64(double %1529, double %1521, double 0x3FE000000000000B) #5
  %1531 = tail call double @llvm.fma.f64(double %1530, double %1521, double 1.000000e+00) #5
  %1532 = tail call double @llvm.fma.f64(double %1531, double %1521, double 1.000000e+00) #5
  %1533 = tail call i32 @llvm.nvvm.d2i.lo(double %1532) #5
  %1534 = tail call i32 @llvm.nvvm.d2i.hi(double %1532) #5
  %1535 = shl i32 %1518, 20
  %1536 = add i32 %1534, %1535
  %1537 = tail call double @llvm.nvvm.lohi.i2d(i32 %1533, i32 %1536) #5
  %1538 = tail call i32 @llvm.nvvm.d2i.hi(double %1516) #5
  %1539 = bitcast i32 %1538 to float
  %1540 = tail call float @llvm.fabs.f32(float %1539) #5
  %1541 = fcmp olt float %1540, 0x4010C46560000000
  br i1 %1541, label %__internal_accurate_pow.exit10, label %1542

1542:                                             ; preds = %1432
  %1543 = fcmp olt double %1516, 0.000000e+00
  %1544 = fadd double %1516, 0x7FF0000000000000
  %1545 = select i1 %1543, double 0.000000e+00, double %1544
  %1546 = fcmp olt float %1540, 0x4010E90000000000
  br i1 %1546, label %1547, label %__internal_accurate_pow.exit10

1547:                                             ; preds = %1542
  %1548 = sdiv i32 %1518, 2
  %1549 = shl i32 %1548, 20
  %1550 = add i32 %1534, %1549
  %1551 = tail call double @llvm.nvvm.lohi.i2d(i32 %1533, i32 %1550) #5
  %1552 = sub nsw i32 %1518, %1548
  %1553 = shl i32 %1552, 20
  %1554 = add nsw i32 %1553, 1072693248
  %1555 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1554) #5
  %1556 = fmul double %1551, %1555
  br label %__internal_accurate_pow.exit10

__internal_accurate_pow.exit10:                   ; preds = %1547, %1542, %1432
  %1557 = phi double [ %1537, %1432 ], [ %1545, %1542 ], [ %1556, %1547 ]
  %1558 = fsub double %1512, %1516
  %1559 = fadd double %1515, %1558
  %1560 = tail call i32 @llvm.nvvm.d2i.lo(double %1557) #5
  %1561 = tail call i32 @llvm.nvvm.d2i.hi(double %1557) #5
  %1562 = and i32 %1561, 2147483647
  %1563 = icmp eq i32 %1562, 2146435072
  %1564 = icmp eq i32 %1560, 0
  %1565 = and i1 %1564, %1563
  %1566 = tail call double @llvm.fma.f64(double %1557, double %1559, double %1557) #5
  %1567 = select i1 %1565, double %1557, double %1566
  %1568 = icmp slt i32 %1402, 0
  %1569 = and i1 %1568, %1405
  br i1 %1569, label %1570, label %1575

1570:                                             ; preds = %__internal_accurate_pow.exit10
  %1571 = tail call i32 @llvm.nvvm.d2i.hi(double %1567) #5
  %1572 = tail call i32 @llvm.nvvm.d2i.lo(double %1567) #5
  %1573 = xor i32 %1571, -2147483648
  %1574 = tail call double @llvm.nvvm.lohi.i2d(i32 %1572, i32 %1573) #5
  br label %1575

1575:                                             ; preds = %1570, %__internal_accurate_pow.exit10
  %1576 = phi double [ %1567, %__internal_accurate_pow.exit10 ], [ %1574, %1570 ]
  %1577 = fcmp oeq double %1401, 0.000000e+00
  %1578 = select i1 %1405, i32 %1402, i32 0
  br i1 %1577, label %1579, label %1584

1579:                                             ; preds = %1575
  %1580 = icmp slt i32 %1403, 0
  %1581 = or i32 %1578, 2146435072
  %1582 = select i1 %1580, i32 %1581, i32 %1578
  %1583 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1582) #5
  br label %1584

1584:                                             ; preds = %1579, %1575
  %1585 = phi double [ %1576, %1575 ], [ %1583, %1579 ]
  %1586 = fadd double %1401, 2.000000e+00
  %1587 = tail call i32 @llvm.nvvm.d2i.hi(double %1586) #5
  %1588 = and i32 %1587, 2146435072
  %1589 = icmp eq i32 %1588, 2146435072
  br i1 %1589, label %1590, label %1618

1590:                                             ; preds = %1584
  %1591 = fcmp ugt double %1406, 0x7FF0000000000000
  br i1 %1591, label %1618, label %1592

1592:                                             ; preds = %1590
  %1593 = and i32 %1403, 2147483647
  %1594 = icmp eq i32 %1593, 2146435072
  %1595 = icmp eq i32 %1506, 0
  %1596 = and i1 %1594, %1595
  br i1 %1596, label %1597, label %1604

1597:                                             ; preds = %1592
  %1598 = fcmp ogt double %1406, 1.000000e+00
  %1599 = select i1 %1598, i32 2146435072, i32 0
  %1600 = icmp slt i32 %1403, 0
  %1601 = xor i32 %1599, 2146435072
  %1602 = select i1 %1600, i32 %1601, i32 %1599
  %1603 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1602) #5
  br label %1618

1604:                                             ; preds = %1592
  %1605 = tail call i32 @llvm.nvvm.d2i.lo(double %1401) #5
  %1606 = and i32 %1402, 2147483647
  %1607 = icmp eq i32 %1606, 2146435072
  %1608 = icmp eq i32 %1605, 0
  %1609 = and i1 %1607, %1608
  %1610 = icmp slt i32 %1403, 0
  %1611 = select i1 %1610, i32 0, i32 2146435072
  br i1 %1609, label %1612, label %1618

1612:                                             ; preds = %1604
  %1613 = icmp ne i32 %1593, 1071644672
  %1614 = and i1 %1613, %1569
  %1615 = or i32 %1611, -2147483648
  %1616 = select i1 %1614, i32 %1615, i32 %1611
  %1617 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1616) #5
  br label %1618

1618:                                             ; preds = %1612, %1604, %1597, %1590, %1584
  %1619 = phi double [ %1585, %1584 ], [ %1586, %1590 ], [ %1603, %1597 ], [ %1585, %1604 ], [ %1617, %1612 ]
  %1620 = fcmp oeq double %1401, 1.000000e+00
  %1621 = select i1 %1620, double 1.000000e+00, double %1619
  %1622 = fmul double %1397, %1621
  br label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit1.i

1623:                                             ; preds = %1377
  %1624 = fcmp olt double %1393, 0.000000e+00
  %1625 = fdiv double 1.000000e+00, %152
  br i1 %1624, label %1626, label %.preheader185

1626:                                             ; preds = %1623
  %1627 = tail call i32 @llvm.nvvm.d2i.hi(double 2.000000e+00) #5
  %1628 = and i32 %1627, 2146435072
  %1629 = icmp eq i32 %1628, 1062207488
  %1630 = icmp slt i32 %1627, 0
  %1631 = and i32 %1627, 2147483647
  %1632 = icmp eq i32 %1631, 2146435072
  %1633 = select i1 %1630, i32 0, i32 2146435072
  %1634 = icmp ne i32 %1631, 1071644672
  %1635 = or i32 %1633, -2147483648
  br i1 %1629, label %.preheader55, label %1879

.preheader55:                                     ; preds = %1626
  %1636 = tail call double @llvm.nvvm.lohi.i2d(i32 -2147483648, i32 1127219200) #5
  %1637 = tail call i32 @llvm.nvvm.d2i.lo(double 2.000000e+00) #5
  br i1 %1630, label %.preheader55.split.us.preheader, label %.preheader55.split.preheader

.preheader55.split.preheader:                     ; preds = %.preheader55
  %1638 = icmp ugt i32 %1627, 2130706431
  %1639 = and i32 %1627, -15728641
  %1640 = select i1 %1638, i32 %1639, i32 %1627
  %1641 = tail call double @llvm.nvvm.lohi.i2d(i32 %1637, i32 %1640) #5
  %1642 = icmp eq i32 %1637, 0
  %1643 = and i1 %1632, %1642
  br label %.preheader55.split

.preheader55.split.us.preheader:                  ; preds = %.preheader55
  %1644 = shl i32 %1627, 1
  %1645 = icmp ugt i32 %1644, -33554433
  %1646 = and i32 %1627, -15728641
  %1647 = select i1 %1645, i32 %1646, i32 %1627
  %1648 = tail call double @llvm.nvvm.lohi.i2d(i32 %1637, i32 %1647) #5
  %1649 = icmp eq i32 %1637, 0
  %1650 = and i1 %1632, %1649
  br label %.preheader55.split.us

.preheader55.split.us:                            ; preds = %1867, %.preheader55.split.us.preheader
  %1651 = phi double [ %152, %.preheader55.split.us.preheader ], [ %1870, %1867 ]
  %1652 = phi i32 [ 0, %.preheader55.split.us.preheader ], [ %1878, %1867 ]
  %1653 = fdiv double 1.000000e+00, %1651
  %1654 = fadd double %1625, %1653
  %1655 = fmul double %1386, %1654
  %1656 = tail call double @llvm.sqrt.f64(double %1655) #5
  %1657 = fsub double %1651, %152
  %1658 = fmul double %1657, %1656
  %1659 = fadd double %1379, %1658
  %1660 = fadd double %1658, %1659
  %1661 = fmul double %129, %1657
  %1662 = fmul double %1651, %1651
  %1663 = fmul double %1662, 4.000000e+00
  %1664 = fmul double %1663, %1656
  %1665 = fdiv double %1661, %1664
  %1666 = fsub double %1656, %1665
  %1667 = fadd double %1656, %1666
  %1668 = fsub double %1667, %1665
  %1669 = tail call double @llvm.sqrt.f64(double %1651) #5
  %1670 = fmul double %1669, 2.000000e+00
  %1671 = fmul double %1670, %1668
  %1672 = fdiv double %1660, %1671
  %1673 = fsub double %1669, %1672
  %1674 = tail call i32 @llvm.nvvm.d2i.hi(double %1673) #5
  %1675 = tail call double @llvm.fabs.f64(double %1673) #5
  %1676 = tail call i32 @llvm.nvvm.d2i.hi(double %1675) #5
  %1677 = tail call i32 @llvm.nvvm.d2i.lo(double %1675) #5
  %1678 = lshr i32 %1676, 20
  %1679 = icmp eq i32 %1678, 0
  %1680 = fmul double %1675, 0x4350000000000000
  br i1 %1679, label %1681, label %1686

1681:                                             ; preds = %.preheader55.split.us
  %1682 = tail call i32 @llvm.nvvm.d2i.hi(double %1680) #5
  %1683 = tail call i32 @llvm.nvvm.d2i.lo(double %1680) #5
  %1684 = lshr i32 %1682, 20
  %1685 = add nsw i32 %1684, -54
  br label %1686

1686:                                             ; preds = %1681, %.preheader55.split.us
  %1687 = phi i32 [ %1677, %.preheader55.split.us ], [ %1683, %1681 ]
  %1688 = phi i32 [ %1676, %.preheader55.split.us ], [ %1682, %1681 ]
  %1689 = phi i32 [ %1678, %.preheader55.split.us ], [ %1685, %1681 ]
  %1690 = add nsw i32 %1689, -1023
  %1691 = and i32 %1688, -2146435073
  %1692 = or i32 %1691, 1072693248
  %1693 = tail call double @llvm.nvvm.lohi.i2d(i32 %1687, i32 %1692) #5
  %1694 = icmp ugt i32 %1692, 1073127582
  br i1 %1694, label %1695, label %1701

1695:                                             ; preds = %1686
  %1696 = add nsw i32 %1689, -1022
  %1697 = tail call i32 @llvm.nvvm.d2i.lo(double %1693) #5
  %1698 = tail call i32 @llvm.nvvm.d2i.hi(double %1693) #5
  %1699 = add i32 %1698, -1048576
  %1700 = tail call double @llvm.nvvm.lohi.i2d(i32 %1697, i32 %1699) #5
  br label %1701

1701:                                             ; preds = %1695, %1686
  %1702 = phi double [ %1693, %1686 ], [ %1700, %1695 ]
  %1703 = phi i32 [ %1690, %1686 ], [ %1696, %1695 ]
  %1704 = fadd double %1702, -1.000000e+00
  %1705 = fadd double %1702, 1.000000e+00
  %1706 = tail call double @llvm.nvvm.rcp.approx.ftz.d(double %1705) #5
  %1707 = fneg double %1705
  %1708 = tail call double @llvm.fma.f64(double %1707, double %1706, double 1.000000e+00) #5
  %1709 = tail call double @llvm.fma.f64(double %1708, double %1708, double %1708) #5
  %1710 = tail call double @llvm.fma.f64(double %1709, double %1706, double %1706) #5
  %1711 = fmul double %1704, %1710
  %1712 = fadd double %1711, %1711
  %1713 = fmul double %1712, %1712
  %1714 = tail call double @llvm.fma.f64(double %1713, double 0x3EB0F5FF7D2CAFE2, double 0x3ED0F5D241AD3B5A) #5
  %1715 = tail call double @llvm.fma.f64(double %1714, double %1713, double 0x3EF3B20A75488A3F) #5
  %1716 = tail call double @llvm.fma.f64(double %1715, double %1713, double 0x3F1745CDE4FAECD5) #5
  %1717 = tail call double @llvm.fma.f64(double %1716, double %1713, double 0x3F3C71C7258A578B) #5
  %1718 = tail call double @llvm.fma.f64(double %1717, double %1713, double 0x3F6249249242B910) #5
  %1719 = tail call double @llvm.fma.f64(double %1718, double %1713, double 0x3F89999999999DFB) #5
  %1720 = fmul double %1713, %1719
  %1721 = fsub double %1704, %1712
  %1722 = fmul double %1721, 2.000000e+00
  %1723 = fneg double %1712
  %1724 = tail call double @llvm.fma.f64(double %1723, double %1704, double %1722) #5
  %1725 = fmul double %1710, %1724
  %1726 = fadd double %1720, 0x3FB5555555555555
  %1727 = fsub double 0x3FB5555555555555, %1726
  %1728 = fadd double %1720, %1727
  %1729 = fadd double %1728, 0.000000e+00
  %1730 = fadd double %1729, 0xBC46A4CB00B9E7B0
  %1731 = fadd double %1726, %1730
  %1732 = fsub double %1726, %1731
  %1733 = fadd double %1730, %1732
  %1734 = fneg double %1713
  %1735 = tail call double @llvm.fma.f64(double %1712, double %1712, double %1734) #5
  %1736 = tail call i32 @llvm.nvvm.d2i.lo(double %1725) #5
  %1737 = tail call i32 @llvm.nvvm.d2i.hi(double %1725) #5
  %1738 = add i32 %1737, 1048576
  %1739 = tail call double @llvm.nvvm.lohi.i2d(i32 %1736, i32 %1738) #5
  %1740 = tail call double @llvm.fma.f64(double %1712, double %1739, double %1735) #5
  %1741 = fmul double %1712, %1713
  %1742 = fneg double %1741
  %1743 = tail call double @llvm.fma.f64(double %1713, double %1712, double %1742) #5
  %1744 = tail call double @llvm.fma.f64(double %1713, double %1725, double %1743) #5
  %1745 = tail call double @llvm.fma.f64(double %1740, double %1712, double %1744) #5
  %1746 = fmul double %1741, %1731
  %1747 = fneg double %1746
  %1748 = tail call double @llvm.fma.f64(double %1731, double %1741, double %1747) #5
  %1749 = tail call double @llvm.fma.f64(double %1731, double %1745, double %1748) #5
  %1750 = tail call double @llvm.fma.f64(double %1733, double %1741, double %1749) #5
  %1751 = fadd double %1746, %1750
  %1752 = fsub double %1746, %1751
  %1753 = fadd double %1750, %1752
  %1754 = fadd double %1712, %1751
  %1755 = fsub double %1712, %1754
  %1756 = fadd double %1751, %1755
  %1757 = fadd double %1753, %1756
  %1758 = fadd double %1725, %1757
  %1759 = fadd double %1754, %1758
  %1760 = fsub double %1754, %1759
  %1761 = fadd double %1758, %1760
  %1762 = xor i32 %1703, -2147483648
  %1763 = tail call double @llvm.nvvm.lohi.i2d(i32 %1762, i32 1127219200) #5
  %1764 = fsub double %1763, %1636
  %1765 = tail call double @llvm.fma.f64(double %1764, double 0x3FE62E42FEFA39EF, double %1759) #5
  %1766 = fneg double %1764
  %1767 = tail call double @llvm.fma.f64(double %1766, double 0x3FE62E42FEFA39EF, double %1765) #5
  %1768 = fsub double %1767, %1759
  %1769 = fsub double %1761, %1768
  %1770 = tail call double @llvm.fma.f64(double %1764, double 0x3C7ABC9E3B39803F, double %1769) #5
  %1771 = fadd double %1765, %1770
  %1772 = fsub double %1765, %1771
  %1773 = fadd double %1770, %1772
  %1774 = fmul double %1648, %1771
  %1775 = fneg double %1774
  %1776 = tail call double @llvm.fma.f64(double %1771, double %1648, double %1775) #5
  %1777 = tail call double @llvm.fma.f64(double %1773, double %1648, double %1776) #5
  %1778 = fadd double %1774, %1777
  %1779 = tail call double @llvm.fma.f64(double %1778, double 0x3FF71547652B82FE, double 0x4338000000000000) #5
  %1780 = tail call i32 @llvm.nvvm.d2i.lo(double %1779) #5
  %1781 = fadd double %1779, 0xC338000000000000
  %1782 = tail call double @llvm.fma.f64(double %1781, double 0xBFE62E42FEFA39EF, double %1778) #5
  %1783 = tail call double @llvm.fma.f64(double %1781, double 0xBC7ABC9E3B39803F, double %1782) #5
  %1784 = tail call double @llvm.fma.f64(double %1783, double 0x3E5ADE1569CE2BDF, double 0x3E928AF3FCA213EA) #5
  %1785 = tail call double @llvm.fma.f64(double %1784, double %1783, double 0x3EC71DEE62401315) #5
  %1786 = tail call double @llvm.fma.f64(double %1785, double %1783, double 0x3EFA01997C89EB71) #5
  %1787 = tail call double @llvm.fma.f64(double %1786, double %1783, double 0x3F2A01A014761F65) #5
  %1788 = tail call double @llvm.fma.f64(double %1787, double %1783, double 0x3F56C16C1852B7AF) #5
  %1789 = tail call double @llvm.fma.f64(double %1788, double %1783, double 0x3F81111111122322) #5
  %1790 = tail call double @llvm.fma.f64(double %1789, double %1783, double 0x3FA55555555502A1) #5
  %1791 = tail call double @llvm.fma.f64(double %1790, double %1783, double 0x3FC5555555555511) #5
  %1792 = tail call double @llvm.fma.f64(double %1791, double %1783, double 0x3FE000000000000B) #5
  %1793 = tail call double @llvm.fma.f64(double %1792, double %1783, double 1.000000e+00) #5
  %1794 = tail call double @llvm.fma.f64(double %1793, double %1783, double 1.000000e+00) #5
  %1795 = tail call i32 @llvm.nvvm.d2i.lo(double %1794) #5
  %1796 = tail call i32 @llvm.nvvm.d2i.hi(double %1794) #5
  %1797 = shl i32 %1780, 20
  %1798 = add i32 %1796, %1797
  %1799 = tail call double @llvm.nvvm.lohi.i2d(i32 %1795, i32 %1798) #5
  %1800 = tail call i32 @llvm.nvvm.d2i.hi(double %1778) #5
  %1801 = bitcast i32 %1800 to float
  %1802 = tail call float @llvm.fabs.f32(float %1801) #5
  %1803 = fcmp olt float %1802, 0x4010C46560000000
  br i1 %1803, label %__internal_accurate_pow.exit9, label %1804

1804:                                             ; preds = %1701
  %1805 = fcmp olt double %1778, 0.000000e+00
  %1806 = fadd double %1778, 0x7FF0000000000000
  %1807 = select i1 %1805, double 0.000000e+00, double %1806
  %1808 = fcmp olt float %1802, 0x4010E90000000000
  br i1 %1808, label %1809, label %__internal_accurate_pow.exit9

1809:                                             ; preds = %1804
  %1810 = sdiv i32 %1780, 2
  %1811 = shl i32 %1810, 20
  %1812 = add i32 %1796, %1811
  %1813 = tail call double @llvm.nvvm.lohi.i2d(i32 %1795, i32 %1812) #5
  %1814 = sub nsw i32 %1780, %1810
  %1815 = shl i32 %1814, 20
  %1816 = add nsw i32 %1815, 1072693248
  %1817 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1816) #5
  %1818 = fmul double %1813, %1817
  br label %__internal_accurate_pow.exit9

__internal_accurate_pow.exit9:                    ; preds = %1809, %1804, %1701
  %1819 = phi double [ %1799, %1701 ], [ %1807, %1804 ], [ %1818, %1809 ]
  %1820 = fsub double %1774, %1778
  %1821 = fadd double %1777, %1820
  %1822 = tail call i32 @llvm.nvvm.d2i.lo(double %1819) #5
  %1823 = tail call i32 @llvm.nvvm.d2i.hi(double %1819) #5
  %1824 = and i32 %1823, 2147483647
  %1825 = icmp eq i32 %1824, 2146435072
  %1826 = icmp eq i32 %1822, 0
  %1827 = and i1 %1826, %1825
  %1828 = tail call double @llvm.fma.f64(double %1819, double %1821, double %1819) #5
  %1829 = select i1 %1827, double %1819, double %1828
  %1830 = icmp slt i32 %1674, 0
  br i1 %1830, label %1831, label %1836

1831:                                             ; preds = %__internal_accurate_pow.exit9
  %1832 = tail call i32 @llvm.nvvm.d2i.hi(double %1829) #5
  %1833 = tail call i32 @llvm.nvvm.d2i.lo(double %1829) #5
  %1834 = xor i32 %1832, -2147483648
  %1835 = tail call double @llvm.nvvm.lohi.i2d(i32 %1833, i32 %1834) #5
  br label %1836

1836:                                             ; preds = %1831, %__internal_accurate_pow.exit9
  %1837 = phi double [ %1829, %__internal_accurate_pow.exit9 ], [ %1835, %1831 ]
  %1838 = fcmp oeq double %1673, 0.000000e+00
  br i1 %1838, label %1839, label %1842

1839:                                             ; preds = %1836
  %1840 = or i32 %1674, 2146435072
  %1841 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1840) #5
  br label %1842

1842:                                             ; preds = %1839, %1836
  %1843 = phi double [ %1837, %1836 ], [ %1841, %1839 ]
  %1844 = fadd double %1673, 2.000000e+00
  %1845 = tail call i32 @llvm.nvvm.d2i.hi(double %1844) #5
  %1846 = and i32 %1845, 2146435072
  %1847 = icmp eq i32 %1846, 2146435072
  br i1 %1847, label %1848, label %1867

1848:                                             ; preds = %1842
  %1849 = fcmp ugt double %1675, 0x7FF0000000000000
  br i1 %1849, label %1867, label %1850

1850:                                             ; preds = %1848
  br i1 %1650, label %1861, label %1851

1851:                                             ; preds = %1850
  %1852 = tail call i32 @llvm.nvvm.d2i.lo(double %1673) #5
  %1853 = and i32 %1674, 2147483647
  %1854 = icmp eq i32 %1853, 2146435072
  %1855 = icmp eq i32 %1852, 0
  %1856 = and i1 %1854, %1855
  br i1 %1856, label %1857, label %1867

1857:                                             ; preds = %1851
  %1858 = and i1 %1634, %1830
  %1859 = select i1 %1858, i32 %1635, i32 %1633
  %1860 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1859) #5
  br label %1867

1861:                                             ; preds = %1850
  %1862 = fcmp ogt double %1675, 1.000000e+00
  %1863 = select i1 %1862, i32 0, i32 2146435072
  %1864 = fcmp oeq double %1673, -1.000000e+00
  %1865 = select i1 %1864, i32 1072693248, i32 %1863
  %1866 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1865) #5
  br label %1867

1867:                                             ; preds = %1861, %1857, %1851, %1848, %1842
  %1868 = phi double [ %1843, %1842 ], [ %1844, %1848 ], [ %1843, %1851 ], [ %1860, %1857 ], [ %1866, %1861 ]
  %1869 = fcmp oeq double %1673, 1.000000e+00
  %1870 = select i1 %1869, double 1.000000e+00, double %1868
  %1871 = fsub double %1651, %1870
  %1872 = tail call double @llvm.fabs.f64(double %1871) #5
  %1873 = tail call double @llvm.fabs.f64(double %1651) #5
  %1874 = fmul double %1873, 1.000000e-04
  %1875 = fcmp ole double %1872, %1874
  %1876 = icmp ugt i32 %1652, 9
  %1877 = or i1 %1876, %1875
  %1878 = add nuw nsw i32 %1652, 1
  br i1 %1877, label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit1.i, label %.preheader55.split.us

1879:                                             ; preds = %1626
  %1880 = select i1 %1630, i32 2146435072, i32 0
  %1881 = tail call double @llvm.nvvm.lohi.i2d(i32 -2147483648, i32 1127219200) #5
  %1882 = tail call i32 @llvm.nvvm.d2i.lo(double 2.000000e+00) #5
  %1883 = shl i32 %1627, 1
  %1884 = icmp ugt i32 %1883, -33554433
  %1885 = and i32 %1627, -15728641
  %1886 = select i1 %1884, i32 %1885, i32 %1627
  %1887 = tail call double @llvm.nvvm.lohi.i2d(i32 %1882, i32 %1886) #5
  br i1 %1632, label %.split.us.preheader, label %.split

.split.us.preheader:                              ; preds = %1879
  %1888 = icmp eq i32 %1882, 0
  br label %.split.us

.split.us:                                        ; preds = %2096, %.split.us.preheader
  %1889 = phi double [ %152, %.split.us.preheader ], [ %2099, %2096 ]
  %1890 = phi i32 [ 0, %.split.us.preheader ], [ %2107, %2096 ]
  %1891 = fdiv double 1.000000e+00, %1889
  %1892 = fadd double %1625, %1891
  %1893 = fmul double %1386, %1892
  %1894 = tail call double @llvm.sqrt.f64(double %1893) #5
  %1895 = fsub double %1889, %152
  %1896 = fmul double %1895, %1894
  %1897 = fadd double %1379, %1896
  %1898 = fadd double %1896, %1897
  %1899 = fmul double %129, %1895
  %1900 = fmul double %1889, %1889
  %1901 = fmul double %1900, 4.000000e+00
  %1902 = fmul double %1901, %1894
  %1903 = fdiv double %1899, %1902
  %1904 = fsub double %1894, %1903
  %1905 = fadd double %1894, %1904
  %1906 = fsub double %1905, %1903
  %1907 = tail call double @llvm.sqrt.f64(double %1889) #5
  %1908 = fmul double %1907, 2.000000e+00
  %1909 = fmul double %1908, %1906
  %1910 = fdiv double %1898, %1909
  %1911 = fsub double %1907, %1910
  %1912 = tail call i32 @llvm.nvvm.d2i.hi(double %1911) #5
  %1913 = tail call double @llvm.fabs.f64(double %1911) #5
  %1914 = tail call i32 @llvm.nvvm.d2i.hi(double %1913) #5
  %1915 = tail call i32 @llvm.nvvm.d2i.lo(double %1913) #5
  %1916 = lshr i32 %1914, 20
  %1917 = icmp eq i32 %1916, 0
  %1918 = fmul double %1913, 0x4350000000000000
  br i1 %1917, label %1919, label %1924

1919:                                             ; preds = %.split.us
  %1920 = tail call i32 @llvm.nvvm.d2i.hi(double %1918) #5
  %1921 = tail call i32 @llvm.nvvm.d2i.lo(double %1918) #5
  %1922 = lshr i32 %1920, 20
  %1923 = add nsw i32 %1922, -54
  br label %1924

1924:                                             ; preds = %1919, %.split.us
  %1925 = phi i32 [ %1915, %.split.us ], [ %1921, %1919 ]
  %1926 = phi i32 [ %1914, %.split.us ], [ %1920, %1919 ]
  %1927 = phi i32 [ %1916, %.split.us ], [ %1923, %1919 ]
  %1928 = add nsw i32 %1927, -1023
  %1929 = and i32 %1926, -2146435073
  %1930 = or i32 %1929, 1072693248
  %1931 = tail call double @llvm.nvvm.lohi.i2d(i32 %1925, i32 %1930) #5
  %1932 = icmp ugt i32 %1930, 1073127582
  br i1 %1932, label %1933, label %1939

1933:                                             ; preds = %1924
  %1934 = add nsw i32 %1927, -1022
  %1935 = tail call i32 @llvm.nvvm.d2i.lo(double %1931) #5
  %1936 = tail call i32 @llvm.nvvm.d2i.hi(double %1931) #5
  %1937 = add i32 %1936, -1048576
  %1938 = tail call double @llvm.nvvm.lohi.i2d(i32 %1935, i32 %1937) #5
  br label %1939

1939:                                             ; preds = %1933, %1924
  %1940 = phi double [ %1931, %1924 ], [ %1938, %1933 ]
  %1941 = phi i32 [ %1928, %1924 ], [ %1934, %1933 ]
  %1942 = fadd double %1940, -1.000000e+00
  %1943 = fadd double %1940, 1.000000e+00
  %1944 = tail call double @llvm.nvvm.rcp.approx.ftz.d(double %1943) #5
  %1945 = fneg double %1943
  %1946 = tail call double @llvm.fma.f64(double %1945, double %1944, double 1.000000e+00) #5
  %1947 = tail call double @llvm.fma.f64(double %1946, double %1946, double %1946) #5
  %1948 = tail call double @llvm.fma.f64(double %1947, double %1944, double %1944) #5
  %1949 = fmul double %1942, %1948
  %1950 = fadd double %1949, %1949
  %1951 = fmul double %1950, %1950
  %1952 = tail call double @llvm.fma.f64(double %1951, double 0x3EB0F5FF7D2CAFE2, double 0x3ED0F5D241AD3B5A) #5
  %1953 = tail call double @llvm.fma.f64(double %1952, double %1951, double 0x3EF3B20A75488A3F) #5
  %1954 = tail call double @llvm.fma.f64(double %1953, double %1951, double 0x3F1745CDE4FAECD5) #5
  %1955 = tail call double @llvm.fma.f64(double %1954, double %1951, double 0x3F3C71C7258A578B) #5
  %1956 = tail call double @llvm.fma.f64(double %1955, double %1951, double 0x3F6249249242B910) #5
  %1957 = tail call double @llvm.fma.f64(double %1956, double %1951, double 0x3F89999999999DFB) #5
  %1958 = fmul double %1951, %1957
  %1959 = fsub double %1942, %1950
  %1960 = fmul double %1959, 2.000000e+00
  %1961 = fneg double %1950
  %1962 = tail call double @llvm.fma.f64(double %1961, double %1942, double %1960) #5
  %1963 = fmul double %1948, %1962
  %1964 = fadd double %1958, 0x3FB5555555555555
  %1965 = fsub double 0x3FB5555555555555, %1964
  %1966 = fadd double %1958, %1965
  %1967 = fadd double %1966, 0.000000e+00
  %1968 = fadd double %1967, 0xBC46A4CB00B9E7B0
  %1969 = fadd double %1964, %1968
  %1970 = fsub double %1964, %1969
  %1971 = fadd double %1968, %1970
  %1972 = fneg double %1951
  %1973 = tail call double @llvm.fma.f64(double %1950, double %1950, double %1972) #5
  %1974 = tail call i32 @llvm.nvvm.d2i.lo(double %1963) #5
  %1975 = tail call i32 @llvm.nvvm.d2i.hi(double %1963) #5
  %1976 = add i32 %1975, 1048576
  %1977 = tail call double @llvm.nvvm.lohi.i2d(i32 %1974, i32 %1976) #5
  %1978 = tail call double @llvm.fma.f64(double %1950, double %1977, double %1973) #5
  %1979 = fmul double %1950, %1951
  %1980 = fneg double %1979
  %1981 = tail call double @llvm.fma.f64(double %1951, double %1950, double %1980) #5
  %1982 = tail call double @llvm.fma.f64(double %1951, double %1963, double %1981) #5
  %1983 = tail call double @llvm.fma.f64(double %1978, double %1950, double %1982) #5
  %1984 = fmul double %1979, %1969
  %1985 = fneg double %1984
  %1986 = tail call double @llvm.fma.f64(double %1969, double %1979, double %1985) #5
  %1987 = tail call double @llvm.fma.f64(double %1969, double %1983, double %1986) #5
  %1988 = tail call double @llvm.fma.f64(double %1971, double %1979, double %1987) #5
  %1989 = fadd double %1984, %1988
  %1990 = fsub double %1984, %1989
  %1991 = fadd double %1988, %1990
  %1992 = fadd double %1950, %1989
  %1993 = fsub double %1950, %1992
  %1994 = fadd double %1989, %1993
  %1995 = fadd double %1991, %1994
  %1996 = fadd double %1963, %1995
  %1997 = fadd double %1992, %1996
  %1998 = fsub double %1992, %1997
  %1999 = fadd double %1996, %1998
  %2000 = xor i32 %1941, -2147483648
  %2001 = tail call double @llvm.nvvm.lohi.i2d(i32 %2000, i32 1127219200) #5
  %2002 = fsub double %2001, %1881
  %2003 = tail call double @llvm.fma.f64(double %2002, double 0x3FE62E42FEFA39EF, double %1997) #5
  %2004 = fneg double %2002
  %2005 = tail call double @llvm.fma.f64(double %2004, double 0x3FE62E42FEFA39EF, double %2003) #5
  %2006 = fsub double %2005, %1997
  %2007 = fsub double %1999, %2006
  %2008 = tail call double @llvm.fma.f64(double %2002, double 0x3C7ABC9E3B39803F, double %2007) #5
  %2009 = fadd double %2003, %2008
  %2010 = fsub double %2003, %2009
  %2011 = fadd double %2008, %2010
  %2012 = fmul double %1887, %2009
  %2013 = fneg double %2012
  %2014 = tail call double @llvm.fma.f64(double %2009, double %1887, double %2013) #5
  %2015 = tail call double @llvm.fma.f64(double %2011, double %1887, double %2014) #5
  %2016 = fadd double %2012, %2015
  %2017 = tail call double @llvm.fma.f64(double %2016, double 0x3FF71547652B82FE, double 0x4338000000000000) #5
  %2018 = tail call i32 @llvm.nvvm.d2i.lo(double %2017) #5
  %2019 = fadd double %2017, 0xC338000000000000
  %2020 = tail call double @llvm.fma.f64(double %2019, double 0xBFE62E42FEFA39EF, double %2016) #5
  %2021 = tail call double @llvm.fma.f64(double %2019, double 0xBC7ABC9E3B39803F, double %2020) #5
  %2022 = tail call double @llvm.fma.f64(double %2021, double 0x3E5ADE1569CE2BDF, double 0x3E928AF3FCA213EA) #5
  %2023 = tail call double @llvm.fma.f64(double %2022, double %2021, double 0x3EC71DEE62401315) #5
  %2024 = tail call double @llvm.fma.f64(double %2023, double %2021, double 0x3EFA01997C89EB71) #5
  %2025 = tail call double @llvm.fma.f64(double %2024, double %2021, double 0x3F2A01A014761F65) #5
  %2026 = tail call double @llvm.fma.f64(double %2025, double %2021, double 0x3F56C16C1852B7AF) #5
  %2027 = tail call double @llvm.fma.f64(double %2026, double %2021, double 0x3F81111111122322) #5
  %2028 = tail call double @llvm.fma.f64(double %2027, double %2021, double 0x3FA55555555502A1) #5
  %2029 = tail call double @llvm.fma.f64(double %2028, double %2021, double 0x3FC5555555555511) #5
  %2030 = tail call double @llvm.fma.f64(double %2029, double %2021, double 0x3FE000000000000B) #5
  %2031 = tail call double @llvm.fma.f64(double %2030, double %2021, double 1.000000e+00) #5
  %2032 = tail call double @llvm.fma.f64(double %2031, double %2021, double 1.000000e+00) #5
  %2033 = tail call i32 @llvm.nvvm.d2i.lo(double %2032) #5
  %2034 = tail call i32 @llvm.nvvm.d2i.hi(double %2032) #5
  %2035 = shl i32 %2018, 20
  %2036 = add i32 %2034, %2035
  %2037 = tail call double @llvm.nvvm.lohi.i2d(i32 %2033, i32 %2036) #5
  %2038 = tail call i32 @llvm.nvvm.d2i.hi(double %2016) #5
  %2039 = bitcast i32 %2038 to float
  %2040 = tail call float @llvm.fabs.f32(float %2039) #5
  %2041 = fcmp olt float %2040, 0x4010C46560000000
  br i1 %2041, label %__internal_accurate_pow.exit8, label %2042

2042:                                             ; preds = %1939
  %2043 = fcmp olt double %2016, 0.000000e+00
  %2044 = fadd double %2016, 0x7FF0000000000000
  %2045 = select i1 %2043, double 0.000000e+00, double %2044
  %2046 = fcmp olt float %2040, 0x4010E90000000000
  br i1 %2046, label %2047, label %__internal_accurate_pow.exit8

2047:                                             ; preds = %2042
  %2048 = sdiv i32 %2018, 2
  %2049 = shl i32 %2048, 20
  %2050 = add i32 %2034, %2049
  %2051 = tail call double @llvm.nvvm.lohi.i2d(i32 %2033, i32 %2050) #5
  %2052 = sub nsw i32 %2018, %2048
  %2053 = shl i32 %2052, 20
  %2054 = add nsw i32 %2053, 1072693248
  %2055 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %2054) #5
  %2056 = fmul double %2051, %2055
  br label %__internal_accurate_pow.exit8

__internal_accurate_pow.exit8:                    ; preds = %2047, %2042, %1939
  %2057 = phi double [ %2037, %1939 ], [ %2045, %2042 ], [ %2056, %2047 ]
  %2058 = fsub double %2012, %2016
  %2059 = fadd double %2015, %2058
  %2060 = tail call i32 @llvm.nvvm.d2i.lo(double %2057) #5
  %2061 = tail call i32 @llvm.nvvm.d2i.hi(double %2057) #5
  %2062 = and i32 %2061, 2147483647
  %2063 = icmp eq i32 %2062, 2146435072
  %2064 = icmp eq i32 %2060, 0
  %2065 = and i1 %2064, %2063
  %2066 = tail call double @llvm.fma.f64(double %2057, double %2059, double %2057) #5
  %2067 = select i1 %2065, double %2057, double %2066
  %2068 = fcmp oeq double %1911, 0.000000e+00
  br i1 %2068, label %2069, label %2071

2069:                                             ; preds = %__internal_accurate_pow.exit8
  %2070 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1880) #5
  br label %2071

2071:                                             ; preds = %2069, %__internal_accurate_pow.exit8
  %2072 = phi double [ %2067, %__internal_accurate_pow.exit8 ], [ %2070, %2069 ]
  %2073 = fadd double %1911, 2.000000e+00
  %2074 = tail call i32 @llvm.nvvm.d2i.hi(double %2073) #5
  %2075 = and i32 %2074, 2146435072
  %2076 = icmp eq i32 %2075, 2146435072
  br i1 %2076, label %2077, label %2096

2077:                                             ; preds = %2071
  %2078 = fcmp ugt double %1913, 0x7FF0000000000000
  br i1 %2078, label %2096, label %2079

2079:                                             ; preds = %2077
  br i1 %1888, label %2088, label %2080

2080:                                             ; preds = %2079
  %2081 = tail call i32 @llvm.nvvm.d2i.lo(double %1911) #5
  %2082 = and i32 %1912, 2147483647
  %2083 = icmp eq i32 %2082, 2146435072
  %2084 = icmp eq i32 %2081, 0
  %2085 = and i1 %2083, %2084
  br i1 %2085, label %2086, label %2096

2086:                                             ; preds = %2080
  %2087 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1633) #5
  br label %2096

2088:                                             ; preds = %2079
  %2089 = fcmp ogt double %1913, 1.000000e+00
  %2090 = select i1 %2089, i32 2146435072, i32 0
  %2091 = xor i32 %2090, 2146435072
  %2092 = select i1 %1630, i32 %2091, i32 %2090
  %2093 = fcmp oeq double %1911, -1.000000e+00
  %2094 = select i1 %2093, i32 1072693248, i32 %2092
  %2095 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %2094) #5
  br label %2096

2096:                                             ; preds = %2088, %2086, %2080, %2077, %2071
  %2097 = phi double [ %2072, %2071 ], [ %2073, %2077 ], [ %2072, %2080 ], [ %2087, %2086 ], [ %2095, %2088 ]
  %2098 = fcmp oeq double %1911, 1.000000e+00
  %2099 = select i1 %2098, double 1.000000e+00, double %2097
  %2100 = fsub double %1889, %2099
  %2101 = tail call double @llvm.fabs.f64(double %2100) #5
  %2102 = tail call double @llvm.fabs.f64(double %1889) #5
  %2103 = fmul double %2102, 1.000000e-04
  %2104 = fcmp ole double %2101, %2103
  %2105 = icmp ugt i32 %1890, 9
  %2106 = or i1 %2105, %2104
  %2107 = add nuw nsw i32 %1890, 1
  br i1 %2106, label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit1.i, label %.split.us

.preheader55.split:                               ; preds = %2323, %.preheader55.split.preheader
  %2108 = phi double [ %152, %.preheader55.split.preheader ], [ %2326, %2323 ]
  %2109 = phi i32 [ 0, %.preheader55.split.preheader ], [ %2334, %2323 ]
  %2110 = fdiv double 1.000000e+00, %2108
  %2111 = fadd double %1625, %2110
  %2112 = fmul double %1386, %2111
  %2113 = tail call double @llvm.sqrt.f64(double %2112) #5
  %2114 = fsub double %2108, %152
  %2115 = fmul double %2114, %2113
  %2116 = fadd double %1379, %2115
  %2117 = fadd double %2115, %2116
  %2118 = fmul double %129, %2114
  %2119 = fmul double %2108, %2108
  %2120 = fmul double %2119, 4.000000e+00
  %2121 = fmul double %2120, %2113
  %2122 = fdiv double %2118, %2121
  %2123 = fsub double %2113, %2122
  %2124 = fadd double %2113, %2123
  %2125 = fsub double %2124, %2122
  %2126 = tail call double @llvm.sqrt.f64(double %2108) #5
  %2127 = fmul double %2126, 2.000000e+00
  %2128 = fmul double %2127, %2125
  %2129 = fdiv double %2117, %2128
  %2130 = fsub double %2126, %2129
  %2131 = tail call i32 @llvm.nvvm.d2i.hi(double %2130) #5
  %2132 = tail call double @llvm.fabs.f64(double %2130) #5
  %2133 = tail call i32 @llvm.nvvm.d2i.hi(double %2132) #5
  %2134 = tail call i32 @llvm.nvvm.d2i.lo(double %2132) #5
  %2135 = lshr i32 %2133, 20
  %2136 = icmp eq i32 %2135, 0
  %2137 = fmul double %2132, 0x4350000000000000
  br i1 %2136, label %2138, label %2143

2138:                                             ; preds = %.preheader55.split
  %2139 = tail call i32 @llvm.nvvm.d2i.hi(double %2137) #5
  %2140 = tail call i32 @llvm.nvvm.d2i.lo(double %2137) #5
  %2141 = lshr i32 %2139, 20
  %2142 = add nsw i32 %2141, -54
  br label %2143

2143:                                             ; preds = %2138, %.preheader55.split
  %2144 = phi i32 [ %2134, %.preheader55.split ], [ %2140, %2138 ]
  %2145 = phi i32 [ %2133, %.preheader55.split ], [ %2139, %2138 ]
  %2146 = phi i32 [ %2135, %.preheader55.split ], [ %2142, %2138 ]
  %2147 = add nsw i32 %2146, -1023
  %2148 = and i32 %2145, -2146435073
  %2149 = or i32 %2148, 1072693248
  %2150 = tail call double @llvm.nvvm.lohi.i2d(i32 %2144, i32 %2149) #5
  %2151 = icmp ugt i32 %2149, 1073127582
  br i1 %2151, label %2152, label %2158

2152:                                             ; preds = %2143
  %2153 = add nsw i32 %2146, -1022
  %2154 = tail call i32 @llvm.nvvm.d2i.lo(double %2150) #5
  %2155 = tail call i32 @llvm.nvvm.d2i.hi(double %2150) #5
  %2156 = add i32 %2155, -1048576
  %2157 = tail call double @llvm.nvvm.lohi.i2d(i32 %2154, i32 %2156) #5
  br label %2158

2158:                                             ; preds = %2152, %2143
  %2159 = phi double [ %2150, %2143 ], [ %2157, %2152 ]
  %2160 = phi i32 [ %2147, %2143 ], [ %2153, %2152 ]
  %2161 = fadd double %2159, -1.000000e+00
  %2162 = fadd double %2159, 1.000000e+00
  %2163 = tail call double @llvm.nvvm.rcp.approx.ftz.d(double %2162) #5
  %2164 = fneg double %2162
  %2165 = tail call double @llvm.fma.f64(double %2164, double %2163, double 1.000000e+00) #5
  %2166 = tail call double @llvm.fma.f64(double %2165, double %2165, double %2165) #5
  %2167 = tail call double @llvm.fma.f64(double %2166, double %2163, double %2163) #5
  %2168 = fmul double %2161, %2167
  %2169 = fadd double %2168, %2168
  %2170 = fmul double %2169, %2169
  %2171 = tail call double @llvm.fma.f64(double %2170, double 0x3EB0F5FF7D2CAFE2, double 0x3ED0F5D241AD3B5A) #5
  %2172 = tail call double @llvm.fma.f64(double %2171, double %2170, double 0x3EF3B20A75488A3F) #5
  %2173 = tail call double @llvm.fma.f64(double %2172, double %2170, double 0x3F1745CDE4FAECD5) #5
  %2174 = tail call double @llvm.fma.f64(double %2173, double %2170, double 0x3F3C71C7258A578B) #5
  %2175 = tail call double @llvm.fma.f64(double %2174, double %2170, double 0x3F6249249242B910) #5
  %2176 = tail call double @llvm.fma.f64(double %2175, double %2170, double 0x3F89999999999DFB) #5
  %2177 = fmul double %2170, %2176
  %2178 = fsub double %2161, %2169
  %2179 = fmul double %2178, 2.000000e+00
  %2180 = fneg double %2169
  %2181 = tail call double @llvm.fma.f64(double %2180, double %2161, double %2179) #5
  %2182 = fmul double %2167, %2181
  %2183 = fadd double %2177, 0x3FB5555555555555
  %2184 = fsub double 0x3FB5555555555555, %2183
  %2185 = fadd double %2177, %2184
  %2186 = fadd double %2185, 0.000000e+00
  %2187 = fadd double %2186, 0xBC46A4CB00B9E7B0
  %2188 = fadd double %2183, %2187
  %2189 = fsub double %2183, %2188
  %2190 = fadd double %2187, %2189
  %2191 = fneg double %2170
  %2192 = tail call double @llvm.fma.f64(double %2169, double %2169, double %2191) #5
  %2193 = tail call i32 @llvm.nvvm.d2i.lo(double %2182) #5
  %2194 = tail call i32 @llvm.nvvm.d2i.hi(double %2182) #5
  %2195 = add i32 %2194, 1048576
  %2196 = tail call double @llvm.nvvm.lohi.i2d(i32 %2193, i32 %2195) #5
  %2197 = tail call double @llvm.fma.f64(double %2169, double %2196, double %2192) #5
  %2198 = fmul double %2169, %2170
  %2199 = fneg double %2198
  %2200 = tail call double @llvm.fma.f64(double %2170, double %2169, double %2199) #5
  %2201 = tail call double @llvm.fma.f64(double %2170, double %2182, double %2200) #5
  %2202 = tail call double @llvm.fma.f64(double %2197, double %2169, double %2201) #5
  %2203 = fmul double %2198, %2188
  %2204 = fneg double %2203
  %2205 = tail call double @llvm.fma.f64(double %2188, double %2198, double %2204) #5
  %2206 = tail call double @llvm.fma.f64(double %2188, double %2202, double %2205) #5
  %2207 = tail call double @llvm.fma.f64(double %2190, double %2198, double %2206) #5
  %2208 = fadd double %2203, %2207
  %2209 = fsub double %2203, %2208
  %2210 = fadd double %2207, %2209
  %2211 = fadd double %2169, %2208
  %2212 = fsub double %2169, %2211
  %2213 = fadd double %2208, %2212
  %2214 = fadd double %2210, %2213
  %2215 = fadd double %2182, %2214
  %2216 = fadd double %2211, %2215
  %2217 = fsub double %2211, %2216
  %2218 = fadd double %2215, %2217
  %2219 = xor i32 %2160, -2147483648
  %2220 = tail call double @llvm.nvvm.lohi.i2d(i32 %2219, i32 1127219200) #5
  %2221 = fsub double %2220, %1636
  %2222 = tail call double @llvm.fma.f64(double %2221, double 0x3FE62E42FEFA39EF, double %2216) #5
  %2223 = fneg double %2221
  %2224 = tail call double @llvm.fma.f64(double %2223, double 0x3FE62E42FEFA39EF, double %2222) #5
  %2225 = fsub double %2224, %2216
  %2226 = fsub double %2218, %2225
  %2227 = tail call double @llvm.fma.f64(double %2221, double 0x3C7ABC9E3B39803F, double %2226) #5
  %2228 = fadd double %2222, %2227
  %2229 = fsub double %2222, %2228
  %2230 = fadd double %2227, %2229
  %2231 = fmul double %1641, %2228
  %2232 = fneg double %2231
  %2233 = tail call double @llvm.fma.f64(double %2228, double %1641, double %2232) #5
  %2234 = tail call double @llvm.fma.f64(double %2230, double %1641, double %2233) #5
  %2235 = fadd double %2231, %2234
  %2236 = tail call double @llvm.fma.f64(double %2235, double 0x3FF71547652B82FE, double 0x4338000000000000) #5
  %2237 = tail call i32 @llvm.nvvm.d2i.lo(double %2236) #5
  %2238 = fadd double %2236, 0xC338000000000000
  %2239 = tail call double @llvm.fma.f64(double %2238, double 0xBFE62E42FEFA39EF, double %2235) #5
  %2240 = tail call double @llvm.fma.f64(double %2238, double 0xBC7ABC9E3B39803F, double %2239) #5
  %2241 = tail call double @llvm.fma.f64(double %2240, double 0x3E5ADE1569CE2BDF, double 0x3E928AF3FCA213EA) #5
  %2242 = tail call double @llvm.fma.f64(double %2241, double %2240, double 0x3EC71DEE62401315) #5
  %2243 = tail call double @llvm.fma.f64(double %2242, double %2240, double 0x3EFA01997C89EB71) #5
  %2244 = tail call double @llvm.fma.f64(double %2243, double %2240, double 0x3F2A01A014761F65) #5
  %2245 = tail call double @llvm.fma.f64(double %2244, double %2240, double 0x3F56C16C1852B7AF) #5
  %2246 = tail call double @llvm.fma.f64(double %2245, double %2240, double 0x3F81111111122322) #5
  %2247 = tail call double @llvm.fma.f64(double %2246, double %2240, double 0x3FA55555555502A1) #5
  %2248 = tail call double @llvm.fma.f64(double %2247, double %2240, double 0x3FC5555555555511) #5
  %2249 = tail call double @llvm.fma.f64(double %2248, double %2240, double 0x3FE000000000000B) #5
  %2250 = tail call double @llvm.fma.f64(double %2249, double %2240, double 1.000000e+00) #5
  %2251 = tail call double @llvm.fma.f64(double %2250, double %2240, double 1.000000e+00) #5
  %2252 = tail call i32 @llvm.nvvm.d2i.lo(double %2251) #5
  %2253 = tail call i32 @llvm.nvvm.d2i.hi(double %2251) #5
  %2254 = shl i32 %2237, 20
  %2255 = add i32 %2253, %2254
  %2256 = tail call double @llvm.nvvm.lohi.i2d(i32 %2252, i32 %2255) #5
  %2257 = tail call i32 @llvm.nvvm.d2i.hi(double %2235) #5
  %2258 = bitcast i32 %2257 to float
  %2259 = tail call float @llvm.fabs.f32(float %2258) #5
  %2260 = fcmp olt float %2259, 0x4010C46560000000
  br i1 %2260, label %__internal_accurate_pow.exit7, label %2261

2261:                                             ; preds = %2158
  %2262 = fcmp olt double %2235, 0.000000e+00
  %2263 = fadd double %2235, 0x7FF0000000000000
  %2264 = select i1 %2262, double 0.000000e+00, double %2263
  %2265 = fcmp olt float %2259, 0x4010E90000000000
  br i1 %2265, label %2266, label %__internal_accurate_pow.exit7

2266:                                             ; preds = %2261
  %2267 = sdiv i32 %2237, 2
  %2268 = shl i32 %2267, 20
  %2269 = add i32 %2253, %2268
  %2270 = tail call double @llvm.nvvm.lohi.i2d(i32 %2252, i32 %2269) #5
  %2271 = sub nsw i32 %2237, %2267
  %2272 = shl i32 %2271, 20
  %2273 = add nsw i32 %2272, 1072693248
  %2274 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %2273) #5
  %2275 = fmul double %2270, %2274
  br label %__internal_accurate_pow.exit7

__internal_accurate_pow.exit7:                    ; preds = %2266, %2261, %2158
  %2276 = phi double [ %2256, %2158 ], [ %2264, %2261 ], [ %2275, %2266 ]
  %2277 = fsub double %2231, %2235
  %2278 = fadd double %2234, %2277
  %2279 = tail call i32 @llvm.nvvm.d2i.lo(double %2276) #5
  %2280 = tail call i32 @llvm.nvvm.d2i.hi(double %2276) #5
  %2281 = and i32 %2280, 2147483647
  %2282 = icmp eq i32 %2281, 2146435072
  %2283 = icmp eq i32 %2279, 0
  %2284 = and i1 %2283, %2282
  %2285 = tail call double @llvm.fma.f64(double %2276, double %2278, double %2276) #5
  %2286 = select i1 %2284, double %2276, double %2285
  %2287 = icmp slt i32 %2131, 0
  br i1 %2287, label %2288, label %2293

2288:                                             ; preds = %__internal_accurate_pow.exit7
  %2289 = tail call i32 @llvm.nvvm.d2i.hi(double %2286) #5
  %2290 = tail call i32 @llvm.nvvm.d2i.lo(double %2286) #5
  %2291 = xor i32 %2289, -2147483648
  %2292 = tail call double @llvm.nvvm.lohi.i2d(i32 %2290, i32 %2291) #5
  br label %2293

2293:                                             ; preds = %2288, %__internal_accurate_pow.exit7
  %2294 = phi double [ %2286, %__internal_accurate_pow.exit7 ], [ %2292, %2288 ]
  %2295 = fcmp oeq double %2130, 0.000000e+00
  br i1 %2295, label %2296, label %2298

2296:                                             ; preds = %2293
  %2297 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %2131) #5
  br label %2298

2298:                                             ; preds = %2296, %2293
  %2299 = phi double [ %2294, %2293 ], [ %2297, %2296 ]
  %2300 = fadd double %2130, 2.000000e+00
  %2301 = tail call i32 @llvm.nvvm.d2i.hi(double %2300) #5
  %2302 = and i32 %2301, 2146435072
  %2303 = icmp eq i32 %2302, 2146435072
  br i1 %2303, label %2304, label %2323

2304:                                             ; preds = %2298
  %2305 = fcmp ugt double %2132, 0x7FF0000000000000
  br i1 %2305, label %2323, label %2306

2306:                                             ; preds = %2304
  br i1 %1643, label %2317, label %2307

2307:                                             ; preds = %2306
  %2308 = tail call i32 @llvm.nvvm.d2i.lo(double %2130) #5
  %2309 = and i32 %2131, 2147483647
  %2310 = icmp eq i32 %2309, 2146435072
  %2311 = icmp eq i32 %2308, 0
  %2312 = and i1 %2310, %2311
  br i1 %2312, label %2313, label %2323

2313:                                             ; preds = %2307
  %2314 = and i1 %1634, %2287
  %2315 = select i1 %2314, i32 %1635, i32 %1633
  %2316 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %2315) #5
  br label %2323

2317:                                             ; preds = %2306
  %2318 = fcmp ogt double %2132, 1.000000e+00
  %2319 = select i1 %2318, i32 2146435072, i32 0
  %2320 = fcmp oeq double %2130, -1.000000e+00
  %2321 = select i1 %2320, i32 1072693248, i32 %2319
  %2322 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %2321) #5
  br label %2323

2323:                                             ; preds = %2317, %2313, %2307, %2304, %2298
  %2324 = phi double [ %2299, %2298 ], [ %2300, %2304 ], [ %2299, %2307 ], [ %2316, %2313 ], [ %2322, %2317 ]
  %2325 = fcmp oeq double %2130, 1.000000e+00
  %2326 = select i1 %2325, double 1.000000e+00, double %2324
  %2327 = fsub double %2108, %2326
  %2328 = tail call double @llvm.fabs.f64(double %2327) #5
  %2329 = tail call double @llvm.fabs.f64(double %2108) #5
  %2330 = fmul double %2329, 1.000000e-04
  %2331 = fcmp ole double %2328, %2330
  %2332 = icmp ugt i32 %2109, 9
  %2333 = or i1 %2332, %2331
  %2334 = add nuw nsw i32 %2109, 1
  br i1 %2333, label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit1.i, label %.preheader55.split

.split:                                           ; preds = %2533, %1879
  %2335 = phi double [ %152, %1879 ], [ %2536, %2533 ]
  %2336 = phi i32 [ 0, %1879 ], [ %2544, %2533 ]
  %2337 = fdiv double 1.000000e+00, %2335
  %2338 = fadd double %1625, %2337
  %2339 = fmul double %1386, %2338
  %2340 = tail call double @llvm.sqrt.f64(double %2339) #5
  %2341 = fsub double %2335, %152
  %2342 = fmul double %2341, %2340
  %2343 = fadd double %1379, %2342
  %2344 = fadd double %2342, %2343
  %2345 = fmul double %129, %2341
  %2346 = fmul double %2335, %2335
  %2347 = fmul double %2346, 4.000000e+00
  %2348 = fmul double %2347, %2340
  %2349 = fdiv double %2345, %2348
  %2350 = fsub double %2340, %2349
  %2351 = fadd double %2340, %2350
  %2352 = fsub double %2351, %2349
  %2353 = tail call double @llvm.sqrt.f64(double %2335) #5
  %2354 = fmul double %2353, 2.000000e+00
  %2355 = fmul double %2354, %2352
  %2356 = fdiv double %2344, %2355
  %2357 = fsub double %2353, %2356
  %2358 = tail call i32 @llvm.nvvm.d2i.hi(double %2357) #5
  %2359 = tail call double @llvm.fabs.f64(double %2357) #5
  %2360 = tail call i32 @llvm.nvvm.d2i.hi(double %2359) #5
  %2361 = tail call i32 @llvm.nvvm.d2i.lo(double %2359) #5
  %2362 = lshr i32 %2360, 20
  %2363 = icmp eq i32 %2362, 0
  %2364 = fmul double %2359, 0x4350000000000000
  br i1 %2363, label %2365, label %2370

2365:                                             ; preds = %.split
  %2366 = tail call i32 @llvm.nvvm.d2i.hi(double %2364) #5
  %2367 = tail call i32 @llvm.nvvm.d2i.lo(double %2364) #5
  %2368 = lshr i32 %2366, 20
  %2369 = add nsw i32 %2368, -54
  br label %2370

2370:                                             ; preds = %2365, %.split
  %2371 = phi i32 [ %2361, %.split ], [ %2367, %2365 ]
  %2372 = phi i32 [ %2360, %.split ], [ %2366, %2365 ]
  %2373 = phi i32 [ %2362, %.split ], [ %2369, %2365 ]
  %2374 = add nsw i32 %2373, -1023
  %2375 = and i32 %2372, -2146435073
  %2376 = or i32 %2375, 1072693248
  %2377 = tail call double @llvm.nvvm.lohi.i2d(i32 %2371, i32 %2376) #5
  %2378 = icmp ugt i32 %2376, 1073127582
  br i1 %2378, label %2379, label %2385

2379:                                             ; preds = %2370
  %2380 = add nsw i32 %2373, -1022
  %2381 = tail call i32 @llvm.nvvm.d2i.lo(double %2377) #5
  %2382 = tail call i32 @llvm.nvvm.d2i.hi(double %2377) #5
  %2383 = add i32 %2382, -1048576
  %2384 = tail call double @llvm.nvvm.lohi.i2d(i32 %2381, i32 %2383) #5
  br label %2385

2385:                                             ; preds = %2379, %2370
  %2386 = phi double [ %2377, %2370 ], [ %2384, %2379 ]
  %2387 = phi i32 [ %2374, %2370 ], [ %2380, %2379 ]
  %2388 = fadd double %2386, -1.000000e+00
  %2389 = fadd double %2386, 1.000000e+00
  %2390 = tail call double @llvm.nvvm.rcp.approx.ftz.d(double %2389) #5
  %2391 = fneg double %2389
  %2392 = tail call double @llvm.fma.f64(double %2391, double %2390, double 1.000000e+00) #5
  %2393 = tail call double @llvm.fma.f64(double %2392, double %2392, double %2392) #5
  %2394 = tail call double @llvm.fma.f64(double %2393, double %2390, double %2390) #5
  %2395 = fmul double %2388, %2394
  %2396 = fadd double %2395, %2395
  %2397 = fmul double %2396, %2396
  %2398 = tail call double @llvm.fma.f64(double %2397, double 0x3EB0F5FF7D2CAFE2, double 0x3ED0F5D241AD3B5A) #5
  %2399 = tail call double @llvm.fma.f64(double %2398, double %2397, double 0x3EF3B20A75488A3F) #5
  %2400 = tail call double @llvm.fma.f64(double %2399, double %2397, double 0x3F1745CDE4FAECD5) #5
  %2401 = tail call double @llvm.fma.f64(double %2400, double %2397, double 0x3F3C71C7258A578B) #5
  %2402 = tail call double @llvm.fma.f64(double %2401, double %2397, double 0x3F6249249242B910) #5
  %2403 = tail call double @llvm.fma.f64(double %2402, double %2397, double 0x3F89999999999DFB) #5
  %2404 = fmul double %2397, %2403
  %2405 = fsub double %2388, %2396
  %2406 = fmul double %2405, 2.000000e+00
  %2407 = fneg double %2396
  %2408 = tail call double @llvm.fma.f64(double %2407, double %2388, double %2406) #5
  %2409 = fmul double %2394, %2408
  %2410 = fadd double %2404, 0x3FB5555555555555
  %2411 = fsub double 0x3FB5555555555555, %2410
  %2412 = fadd double %2404, %2411
  %2413 = fadd double %2412, 0.000000e+00
  %2414 = fadd double %2413, 0xBC46A4CB00B9E7B0
  %2415 = fadd double %2410, %2414
  %2416 = fsub double %2410, %2415
  %2417 = fadd double %2414, %2416
  %2418 = fneg double %2397
  %2419 = tail call double @llvm.fma.f64(double %2396, double %2396, double %2418) #5
  %2420 = tail call i32 @llvm.nvvm.d2i.lo(double %2409) #5
  %2421 = tail call i32 @llvm.nvvm.d2i.hi(double %2409) #5
  %2422 = add i32 %2421, 1048576
  %2423 = tail call double @llvm.nvvm.lohi.i2d(i32 %2420, i32 %2422) #5
  %2424 = tail call double @llvm.fma.f64(double %2396, double %2423, double %2419) #5
  %2425 = fmul double %2396, %2397
  %2426 = fneg double %2425
  %2427 = tail call double @llvm.fma.f64(double %2397, double %2396, double %2426) #5
  %2428 = tail call double @llvm.fma.f64(double %2397, double %2409, double %2427) #5
  %2429 = tail call double @llvm.fma.f64(double %2424, double %2396, double %2428) #5
  %2430 = fmul double %2425, %2415
  %2431 = fneg double %2430
  %2432 = tail call double @llvm.fma.f64(double %2415, double %2425, double %2431) #5
  %2433 = tail call double @llvm.fma.f64(double %2415, double %2429, double %2432) #5
  %2434 = tail call double @llvm.fma.f64(double %2417, double %2425, double %2433) #5
  %2435 = fadd double %2430, %2434
  %2436 = fsub double %2430, %2435
  %2437 = fadd double %2434, %2436
  %2438 = fadd double %2396, %2435
  %2439 = fsub double %2396, %2438
  %2440 = fadd double %2435, %2439
  %2441 = fadd double %2437, %2440
  %2442 = fadd double %2409, %2441
  %2443 = fadd double %2438, %2442
  %2444 = fsub double %2438, %2443
  %2445 = fadd double %2442, %2444
  %2446 = xor i32 %2387, -2147483648
  %2447 = tail call double @llvm.nvvm.lohi.i2d(i32 %2446, i32 1127219200) #5
  %2448 = fsub double %2447, %1881
  %2449 = tail call double @llvm.fma.f64(double %2448, double 0x3FE62E42FEFA39EF, double %2443) #5
  %2450 = fneg double %2448
  %2451 = tail call double @llvm.fma.f64(double %2450, double 0x3FE62E42FEFA39EF, double %2449) #5
  %2452 = fsub double %2451, %2443
  %2453 = fsub double %2445, %2452
  %2454 = tail call double @llvm.fma.f64(double %2448, double 0x3C7ABC9E3B39803F, double %2453) #5
  %2455 = fadd double %2449, %2454
  %2456 = fsub double %2449, %2455
  %2457 = fadd double %2454, %2456
  %2458 = fmul double %1887, %2455
  %2459 = fneg double %2458
  %2460 = tail call double @llvm.fma.f64(double %2455, double %1887, double %2459) #5
  %2461 = tail call double @llvm.fma.f64(double %2457, double %1887, double %2460) #5
  %2462 = fadd double %2458, %2461
  %2463 = tail call double @llvm.fma.f64(double %2462, double 0x3FF71547652B82FE, double 0x4338000000000000) #5
  %2464 = tail call i32 @llvm.nvvm.d2i.lo(double %2463) #5
  %2465 = fadd double %2463, 0xC338000000000000
  %2466 = tail call double @llvm.fma.f64(double %2465, double 0xBFE62E42FEFA39EF, double %2462) #5
  %2467 = tail call double @llvm.fma.f64(double %2465, double 0xBC7ABC9E3B39803F, double %2466) #5
  %2468 = tail call double @llvm.fma.f64(double %2467, double 0x3E5ADE1569CE2BDF, double 0x3E928AF3FCA213EA) #5
  %2469 = tail call double @llvm.fma.f64(double %2468, double %2467, double 0x3EC71DEE62401315) #5
  %2470 = tail call double @llvm.fma.f64(double %2469, double %2467, double 0x3EFA01997C89EB71) #5
  %2471 = tail call double @llvm.fma.f64(double %2470, double %2467, double 0x3F2A01A014761F65) #5
  %2472 = tail call double @llvm.fma.f64(double %2471, double %2467, double 0x3F56C16C1852B7AF) #5
  %2473 = tail call double @llvm.fma.f64(double %2472, double %2467, double 0x3F81111111122322) #5
  %2474 = tail call double @llvm.fma.f64(double %2473, double %2467, double 0x3FA55555555502A1) #5
  %2475 = tail call double @llvm.fma.f64(double %2474, double %2467, double 0x3FC5555555555511) #5
  %2476 = tail call double @llvm.fma.f64(double %2475, double %2467, double 0x3FE000000000000B) #5
  %2477 = tail call double @llvm.fma.f64(double %2476, double %2467, double 1.000000e+00) #5
  %2478 = tail call double @llvm.fma.f64(double %2477, double %2467, double 1.000000e+00) #5
  %2479 = tail call i32 @llvm.nvvm.d2i.lo(double %2478) #5
  %2480 = tail call i32 @llvm.nvvm.d2i.hi(double %2478) #5
  %2481 = shl i32 %2464, 20
  %2482 = add i32 %2480, %2481
  %2483 = tail call double @llvm.nvvm.lohi.i2d(i32 %2479, i32 %2482) #5
  %2484 = tail call i32 @llvm.nvvm.d2i.hi(double %2462) #5
  %2485 = bitcast i32 %2484 to float
  %2486 = tail call float @llvm.fabs.f32(float %2485) #5
  %2487 = fcmp olt float %2486, 0x4010C46560000000
  br i1 %2487, label %__internal_accurate_pow.exit6, label %2488

2488:                                             ; preds = %2385
  %2489 = fcmp olt double %2462, 0.000000e+00
  %2490 = fadd double %2462, 0x7FF0000000000000
  %2491 = select i1 %2489, double 0.000000e+00, double %2490
  %2492 = fcmp olt float %2486, 0x4010E90000000000
  br i1 %2492, label %2493, label %__internal_accurate_pow.exit6

2493:                                             ; preds = %2488
  %2494 = sdiv i32 %2464, 2
  %2495 = shl i32 %2494, 20
  %2496 = add i32 %2480, %2495
  %2497 = tail call double @llvm.nvvm.lohi.i2d(i32 %2479, i32 %2496) #5
  %2498 = sub nsw i32 %2464, %2494
  %2499 = shl i32 %2498, 20
  %2500 = add nsw i32 %2499, 1072693248
  %2501 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %2500) #5
  %2502 = fmul double %2497, %2501
  br label %__internal_accurate_pow.exit6

__internal_accurate_pow.exit6:                    ; preds = %2493, %2488, %2385
  %2503 = phi double [ %2483, %2385 ], [ %2491, %2488 ], [ %2502, %2493 ]
  %2504 = fsub double %2458, %2462
  %2505 = fadd double %2461, %2504
  %2506 = tail call i32 @llvm.nvvm.d2i.lo(double %2503) #5
  %2507 = tail call i32 @llvm.nvvm.d2i.hi(double %2503) #5
  %2508 = and i32 %2507, 2147483647
  %2509 = icmp eq i32 %2508, 2146435072
  %2510 = icmp eq i32 %2506, 0
  %2511 = and i1 %2510, %2509
  %2512 = tail call double @llvm.fma.f64(double %2503, double %2505, double %2503) #5
  %2513 = select i1 %2511, double %2503, double %2512
  %2514 = fcmp oeq double %2357, 0.000000e+00
  br i1 %2514, label %2515, label %2517

2515:                                             ; preds = %__internal_accurate_pow.exit6
  %2516 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1880) #5
  br label %2517

2517:                                             ; preds = %2515, %__internal_accurate_pow.exit6
  %2518 = phi double [ %2513, %__internal_accurate_pow.exit6 ], [ %2516, %2515 ]
  %2519 = fadd double %2357, 2.000000e+00
  %2520 = tail call i32 @llvm.nvvm.d2i.hi(double %2519) #5
  %2521 = and i32 %2520, 2146435072
  %2522 = icmp eq i32 %2521, 2146435072
  br i1 %2522, label %2523, label %2533

2523:                                             ; preds = %2517
  %2524 = fcmp ugt double %2359, 0x7FF0000000000000
  br i1 %2524, label %2533, label %2525

2525:                                             ; preds = %2523
  %2526 = tail call i32 @llvm.nvvm.d2i.lo(double %2357) #5
  %2527 = and i32 %2358, 2147483647
  %2528 = icmp eq i32 %2527, 2146435072
  %2529 = icmp eq i32 %2526, 0
  %2530 = and i1 %2528, %2529
  br i1 %2530, label %2531, label %2533

2531:                                             ; preds = %2525
  %2532 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %1633) #5
  br label %2533

2533:                                             ; preds = %2531, %2525, %2523, %2517
  %2534 = phi double [ %2518, %2517 ], [ %2519, %2523 ], [ %2518, %2525 ], [ %2532, %2531 ]
  %2535 = fcmp oeq double %2357, 1.000000e+00
  %2536 = select i1 %2535, double 1.000000e+00, double %2534
  %2537 = fsub double %2335, %2536
  %2538 = tail call double @llvm.fabs.f64(double %2537) #5
  %2539 = tail call double @llvm.fabs.f64(double %2335) #5
  %2540 = fmul double %2539, 1.000000e-04
  %2541 = fcmp ole double %2538, %2540
  %2542 = icmp ugt i32 %2336, 9
  %2543 = or i1 %2542, %2541
  %2544 = add nuw nsw i32 %2336, 1
  br i1 %2543, label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit1.i, label %.split

.preheader185:                                    ; preds = %.preheader185, %1623
  %2545 = phi double [ %152, %1623 ], [ %2562, %.preheader185 ]
  %2546 = phi i32 [ 0, %1623 ], [ %2570, %.preheader185 ]
  %2547 = fmul double %129, %2545
  %2548 = tail call double @llvm.sqrt.f64(double %2547) #5
  %2549 = fsub double %2548, %1381
  %2550 = fmul double %2549, 2.000000e+00
  %2551 = fadd double %1379, %2550
  %2552 = fsub double %2545, %152
  %2553 = fdiv double 1.000000e+00, %2545
  %2554 = fadd double %1625, %2553
  %2555 = fmul double %1386, %2554
  %2556 = tail call double @llvm.sqrt.f64(double %2555) #5
  %2557 = fmul double %2552, %2556
  %2558 = fadd double %2551, %2557
  %2559 = fsub double %1393, %2558
  %2560 = fdiv double %2559, %1385
  %2561 = fdiv double %2558, %2560
  %2562 = fsub double %2545, %2561
  %2563 = fsub double %2545, %2562
  %2564 = tail call double @llvm.fabs.f64(double %2563) #5
  %2565 = tail call double @llvm.fabs.f64(double %2545) #5
  %2566 = fmul double %2565, 1.000000e-04
  %2567 = fcmp ole double %2564, %2566
  %2568 = icmp ugt i32 %2546, 9
  %2569 = or i1 %2568, %2567
  %2570 = add nuw nsw i32 %2546, 1
  br i1 %2569, label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit1.i, label %.preheader185

_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit1.i: ; preds = %.preheader185, %2533, %2323, %2096, %1867, %1618
  %2571 = phi double [ %1622, %1618 ], [ %1651, %1867 ], [ %1889, %2096 ], [ %2108, %2323 ], [ %2335, %2533 ], [ %2545, %.preheader185 ]
  %2572 = tail call double @llvm.maxnum.f64(double %152, double %2571) #5
  %2573 = fadd double %105, %2572
  %2574 = fcmp olt double %2573, %47
  br i1 %2574, label %2575, label %2577

2575:                                             ; preds = %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit1.i
  %2576 = fneg double %151
  br label %2581

2577:                                             ; preds = %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit1.i
  %2578 = fadd double %105, %152
  %2579 = fcmp olt double %2578, %47
  br i1 %2579, label %2580, label %2581

2580:                                             ; preds = %2577
  br label %2581

2581:                                             ; preds = %2580, %2577, %2575, %1375, %1374, %1371, %1369
  %2582 = phi double [ 0.000000e+00, %1369 ], [ 1.000000e+00, %1371 ], [ 1.000000e+00, %1374 ], [ 1.000000e+00, %1375 ], [ 1.000000e+00, %2575 ], [ 1.000000e+00, %2577 ], [ 1.000000e+00, %2580 ]
  %2583 = phi double [ 0.000000e+00, %1369 ], [ 1.000000e+00, %1371 ], [ 1.000000e+00, %1374 ], [ 1.000000e+00, %1375 ], [ 0.000000e+00, %2575 ], [ 1.000000e+00, %2577 ], [ 1.000000e+00, %2580 ]
  %2584 = phi double [ 1.000000e+00, %1369 ], [ 1.000000e+00, %1371 ], [ 1.000000e+00, %1374 ], [ 1.000000e+00, %1375 ], [ 0.000000e+00, %2575 ], [ 1.000000e+00, %2577 ], [ 1.000000e+00, %2580 ]
  %2585 = phi double [ %163, %1369 ], [ %148, %1371 ], [ %148, %1374 ], [ %148, %1375 ], [ %148, %2575 ], [ %148, %2577 ], [ %148, %2580 ]
  %2586 = phi double [ %163, %1369 ], [ %163, %1371 ], [ %163, %1374 ], [ %163, %1375 ], [ %148, %2575 ], [ %163, %2577 ], [ %163, %2580 ]
  %2587 = phi double [ %164, %1369 ], [ %149, %1371 ], [ %149, %1374 ], [ %149, %1375 ], [ %149, %2575 ], [ %149, %2577 ], [ %149, %2580 ]
  %2588 = phi double [ %164, %1369 ], [ %164, %1371 ], [ %164, %1374 ], [ %164, %1375 ], [ %149, %2575 ], [ %164, %2577 ], [ %164, %2580 ]
  %2589 = phi double [ %47, %1369 ], [ %105, %1371 ], [ %1372, %1374 ], [ %105, %1375 ], [ %105, %2575 ], [ %105, %2577 ], [ %105, %2580 ]
  %2590 = phi double [ %47, %1369 ], [ %47, %1371 ], [ %47, %1374 ], [ %47, %1375 ], [ %105, %2575 ], [ %47, %2577 ], [ %2578, %2580 ]
  %2591 = phi double [ %165, %1369 ], [ %165, %1371 ], [ %165, %1374 ], [ %165, %1375 ], [ %1378, %2575 ], [ %165, %2577 ], [ %165, %2580 ]
  %2592 = phi double [ %170, %1369 ], [ %150, %1371 ], [ %150, %1374 ], [ %150, %1375 ], [ %150, %2575 ], [ %150, %2577 ], [ %150, %2580 ]
  %2593 = phi double [ %166, %1369 ], [ %166, %1371 ], [ %166, %1374 ], [ %166, %1375 ], [ %2576, %2575 ], [ %166, %2577 ], [ %166, %2580 ]
  %2594 = phi double [ %1370, %1369 ], [ %151, %1371 ], [ %151, %1374 ], [ %151, %1375 ], [ %151, %2575 ], [ %151, %2577 ], [ %151, %2580 ]
  %2595 = phi double [ %167, %1369 ], [ %167, %1371 ], [ %167, %1374 ], [ %167, %1375 ], [ %152, %2575 ], [ %167, %2577 ], [ %167, %2580 ]
  %2596 = phi double [ %167, %1369 ], [ %152, %1371 ], [ %152, %1374 ], [ %152, %1375 ], [ %152, %2575 ], [ %152, %2577 ], [ %152, %2580 ]
  %2597 = fmul double %129, %2595
  %2598 = tail call double @llvm.sqrt.f64(double %2597) #5
  %2599 = fsub double %2591, %2598
  %2600 = fmul double %129, %2596
  %2601 = tail call double @llvm.sqrt.f64(double %2600) #5
  %2602 = fadd double %2592, %2601
  %2603 = fmul double %2591, %2598
  %2604 = fmul double %2592, %2601
  %2605 = fadd double %2603, %2604
  %2606 = fadd double %2598, %2601
  %2607 = fdiv double %2605, %2606
  %2608 = fmul double %129, 5.000000e-01
  %2609 = fadd double %2595, %2596
  %2610 = fmul double %2608, %2609
  %2611 = tail call double @llvm.sqrt.f64(double %2610) #5
  %2612 = fsub double %2607, %2611
  %2613 = fadd double %2611, %2607
  %2614 = tail call double @llvm.minnum.f64(double %2599, double %2612) #5
  %2615 = tail call double @llvm.maxnum.f64(double %2602, double %2613) #5
  %2616 = tail call double @llvm.minnum.f64(double %2596, double %2595) #5
  %2617 = tail call double @llvm.maxnum.f64(double %2596, double %2595) #5
  %2618 = fsub double %2592, %2591
  %2619 = fcmp olt double %2616, 1.000000e-10
  br i1 %2619, label %2620, label %2626

2620:                                             ; preds = %2581
  %2621 = fadd double %2591, %2592
  %2622 = fmul double %2601, 2.000000e+00
  %2623 = fsub double %2621, %2622
  %2624 = fmul double %2598, 2.000000e+00
  %2625 = fadd double %2624, %2623
  br label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit2.i

2626:                                             ; preds = %2581
  %2627 = fmul double %129, %2616
  %2628 = tail call double @llvm.sqrt.f64(double %2627) #5
  %2629 = fmul double %129, %2617
  %2630 = tail call double @llvm.sqrt.f64(double %2629) #5
  %2631 = fsub double %2628, %2630
  %2632 = fmul double %2631, 2.000000e+00
  %2633 = fadd double %2618, %2632
  %2634 = fsub double %2617, %2616
  %2635 = fadd double %2617, %2616
  %2636 = fmul double %2608, %2635
  %2637 = fmul double %2617, %2616
  %2638 = fdiv double %2636, %2637
  %2639 = tail call double @llvm.sqrt.f64(double %2638) #5
  %2640 = fmul double %2634, %2639
  %2641 = fadd double %2618, %2640
  %2642 = fcmp ogt double %2633, 0.000000e+00
  br i1 %2642, label %2643, label %2879

2643:                                             ; preds = %2626
  %2644 = fmul double %129, 1.600000e+01
  %2645 = fdiv double 1.000000e+00, %2644
  %2646 = fmul double %2606, 2.000000e+00
  %2647 = fsub double %2646, %2618
  %2648 = tail call double @llvm.maxnum.f64(double %2647, double 0.000000e+00) #5
  %2649 = tail call i32 @llvm.nvvm.d2i.hi(double %2648) #5
  %2650 = tail call i32 @llvm.nvvm.d2i.hi(double 2.000000e+00) #5
  %2651 = and i32 %2650, 2146435072
  %2652 = icmp eq i32 %2651, 1062207488
  %2653 = tail call double @llvm.fabs.f64(double %2648) #5
  %2654 = tail call i32 @llvm.nvvm.d2i.hi(double %2653) #5
  %2655 = tail call i32 @llvm.nvvm.d2i.lo(double %2653) #5
  %2656 = lshr i32 %2654, 20
  %2657 = icmp eq i32 %2656, 0
  %2658 = fmul double %2653, 0x4350000000000000
  br i1 %2657, label %2659, label %2664

2659:                                             ; preds = %2643
  %2660 = tail call i32 @llvm.nvvm.d2i.hi(double %2658) #5
  %2661 = tail call i32 @llvm.nvvm.d2i.lo(double %2658) #5
  %2662 = lshr i32 %2660, 20
  %2663 = add nsw i32 %2662, -54
  br label %2664

2664:                                             ; preds = %2659, %2643
  %2665 = phi i32 [ %2655, %2643 ], [ %2661, %2659 ]
  %2666 = phi i32 [ %2654, %2643 ], [ %2660, %2659 ]
  %2667 = phi i32 [ %2656, %2643 ], [ %2663, %2659 ]
  %2668 = add nsw i32 %2667, -1023
  %2669 = and i32 %2666, -2146435073
  %2670 = or i32 %2669, 1072693248
  %2671 = tail call double @llvm.nvvm.lohi.i2d(i32 %2665, i32 %2670) #5
  %2672 = icmp ugt i32 %2670, 1073127582
  br i1 %2672, label %2673, label %2679

2673:                                             ; preds = %2664
  %2674 = add nsw i32 %2667, -1022
  %2675 = tail call i32 @llvm.nvvm.d2i.lo(double %2671) #5
  %2676 = tail call i32 @llvm.nvvm.d2i.hi(double %2671) #5
  %2677 = add i32 %2676, -1048576
  %2678 = tail call double @llvm.nvvm.lohi.i2d(i32 %2675, i32 %2677) #5
  br label %2679

2679:                                             ; preds = %2673, %2664
  %2680 = phi double [ %2671, %2664 ], [ %2678, %2673 ]
  %2681 = phi i32 [ %2668, %2664 ], [ %2674, %2673 ]
  %2682 = fadd double %2680, -1.000000e+00
  %2683 = fadd double %2680, 1.000000e+00
  %2684 = tail call double @llvm.nvvm.rcp.approx.ftz.d(double %2683) #5
  %2685 = fneg double %2683
  %2686 = tail call double @llvm.fma.f64(double %2685, double %2684, double 1.000000e+00) #5
  %2687 = tail call double @llvm.fma.f64(double %2686, double %2686, double %2686) #5
  %2688 = tail call double @llvm.fma.f64(double %2687, double %2684, double %2684) #5
  %2689 = fmul double %2682, %2688
  %2690 = fadd double %2689, %2689
  %2691 = fmul double %2690, %2690
  %2692 = tail call double @llvm.fma.f64(double %2691, double 0x3EB0F5FF7D2CAFE2, double 0x3ED0F5D241AD3B5A) #5
  %2693 = tail call double @llvm.fma.f64(double %2692, double %2691, double 0x3EF3B20A75488A3F) #5
  %2694 = tail call double @llvm.fma.f64(double %2693, double %2691, double 0x3F1745CDE4FAECD5) #5
  %2695 = tail call double @llvm.fma.f64(double %2694, double %2691, double 0x3F3C71C7258A578B) #5
  %2696 = tail call double @llvm.fma.f64(double %2695, double %2691, double 0x3F6249249242B910) #5
  %2697 = tail call double @llvm.fma.f64(double %2696, double %2691, double 0x3F89999999999DFB) #5
  %2698 = fmul double %2691, %2697
  %2699 = fsub double %2682, %2690
  %2700 = fmul double %2699, 2.000000e+00
  %2701 = fneg double %2690
  %2702 = tail call double @llvm.fma.f64(double %2701, double %2682, double %2700) #5
  %2703 = fmul double %2688, %2702
  %2704 = fadd double %2698, 0x3FB5555555555555
  %2705 = fsub double 0x3FB5555555555555, %2704
  %2706 = fadd double %2698, %2705
  %2707 = fadd double %2706, 0.000000e+00
  %2708 = fadd double %2707, 0xBC46A4CB00B9E7B0
  %2709 = fadd double %2704, %2708
  %2710 = fsub double %2704, %2709
  %2711 = fadd double %2708, %2710
  %2712 = fneg double %2691
  %2713 = tail call double @llvm.fma.f64(double %2690, double %2690, double %2712) #5
  %2714 = tail call i32 @llvm.nvvm.d2i.lo(double %2703) #5
  %2715 = tail call i32 @llvm.nvvm.d2i.hi(double %2703) #5
  %2716 = add i32 %2715, 1048576
  %2717 = tail call double @llvm.nvvm.lohi.i2d(i32 %2714, i32 %2716) #5
  %2718 = tail call double @llvm.fma.f64(double %2690, double %2717, double %2713) #5
  %2719 = fmul double %2690, %2691
  %2720 = fneg double %2719
  %2721 = tail call double @llvm.fma.f64(double %2691, double %2690, double %2720) #5
  %2722 = tail call double @llvm.fma.f64(double %2691, double %2703, double %2721) #5
  %2723 = tail call double @llvm.fma.f64(double %2718, double %2690, double %2722) #5
  %2724 = fmul double %2719, %2709
  %2725 = fneg double %2724
  %2726 = tail call double @llvm.fma.f64(double %2709, double %2719, double %2725) #5
  %2727 = tail call double @llvm.fma.f64(double %2709, double %2723, double %2726) #5
  %2728 = tail call double @llvm.fma.f64(double %2711, double %2719, double %2727) #5
  %2729 = fadd double %2724, %2728
  %2730 = fsub double %2724, %2729
  %2731 = fadd double %2728, %2730
  %2732 = fadd double %2690, %2729
  %2733 = fsub double %2690, %2732
  %2734 = fadd double %2729, %2733
  %2735 = fadd double %2731, %2734
  %2736 = fadd double %2703, %2735
  %2737 = fadd double %2732, %2736
  %2738 = fsub double %2732, %2737
  %2739 = fadd double %2736, %2738
  %2740 = xor i32 %2681, -2147483648
  %2741 = tail call double @llvm.nvvm.lohi.i2d(i32 %2740, i32 1127219200) #5
  %2742 = tail call double @llvm.nvvm.lohi.i2d(i32 -2147483648, i32 1127219200) #5
  %2743 = fsub double %2741, %2742
  %2744 = tail call double @llvm.fma.f64(double %2743, double 0x3FE62E42FEFA39EF, double %2737) #5
  %2745 = fneg double %2743
  %2746 = tail call double @llvm.fma.f64(double %2745, double 0x3FE62E42FEFA39EF, double %2744) #5
  %2747 = fsub double %2746, %2737
  %2748 = fsub double %2739, %2747
  %2749 = tail call double @llvm.fma.f64(double %2743, double 0x3C7ABC9E3B39803F, double %2748) #5
  %2750 = fadd double %2744, %2749
  %2751 = fsub double %2744, %2750
  %2752 = fadd double %2749, %2751
  %2753 = tail call i32 @llvm.nvvm.d2i.lo(double 2.000000e+00) #5
  %2754 = shl i32 %2650, 1
  %2755 = icmp ugt i32 %2754, -33554433
  %2756 = and i32 %2650, -15728641
  %2757 = select i1 %2755, i32 %2756, i32 %2650
  %2758 = tail call double @llvm.nvvm.lohi.i2d(i32 %2753, i32 %2757) #5
  %2759 = fmul double %2758, %2750
  %2760 = fneg double %2759
  %2761 = tail call double @llvm.fma.f64(double %2750, double %2758, double %2760) #5
  %2762 = tail call double @llvm.fma.f64(double %2752, double %2758, double %2761) #5
  %2763 = fadd double %2759, %2762
  %2764 = tail call double @llvm.fma.f64(double %2763, double 0x3FF71547652B82FE, double 0x4338000000000000) #5
  %2765 = tail call i32 @llvm.nvvm.d2i.lo(double %2764) #5
  %2766 = fadd double %2764, 0xC338000000000000
  %2767 = tail call double @llvm.fma.f64(double %2766, double 0xBFE62E42FEFA39EF, double %2763) #5
  %2768 = tail call double @llvm.fma.f64(double %2766, double 0xBC7ABC9E3B39803F, double %2767) #5
  %2769 = tail call double @llvm.fma.f64(double %2768, double 0x3E5ADE1569CE2BDF, double 0x3E928AF3FCA213EA) #5
  %2770 = tail call double @llvm.fma.f64(double %2769, double %2768, double 0x3EC71DEE62401315) #5
  %2771 = tail call double @llvm.fma.f64(double %2770, double %2768, double 0x3EFA01997C89EB71) #5
  %2772 = tail call double @llvm.fma.f64(double %2771, double %2768, double 0x3F2A01A014761F65) #5
  %2773 = tail call double @llvm.fma.f64(double %2772, double %2768, double 0x3F56C16C1852B7AF) #5
  %2774 = tail call double @llvm.fma.f64(double %2773, double %2768, double 0x3F81111111122322) #5
  %2775 = tail call double @llvm.fma.f64(double %2774, double %2768, double 0x3FA55555555502A1) #5
  %2776 = tail call double @llvm.fma.f64(double %2775, double %2768, double 0x3FC5555555555511) #5
  %2777 = tail call double @llvm.fma.f64(double %2776, double %2768, double 0x3FE000000000000B) #5
  %2778 = tail call double @llvm.fma.f64(double %2777, double %2768, double 1.000000e+00) #5
  %2779 = tail call double @llvm.fma.f64(double %2778, double %2768, double 1.000000e+00) #5
  %2780 = tail call i32 @llvm.nvvm.d2i.lo(double %2779) #5
  %2781 = tail call i32 @llvm.nvvm.d2i.hi(double %2779) #5
  %2782 = shl i32 %2765, 20
  %2783 = add i32 %2781, %2782
  %2784 = tail call double @llvm.nvvm.lohi.i2d(i32 %2780, i32 %2783) #5
  %2785 = tail call i32 @llvm.nvvm.d2i.hi(double %2763) #5
  %2786 = bitcast i32 %2785 to float
  %2787 = tail call float @llvm.fabs.f32(float %2786) #5
  %2788 = fcmp olt float %2787, 0x4010C46560000000
  br i1 %2788, label %__internal_accurate_pow.exit5, label %2789

2789:                                             ; preds = %2679
  %2790 = fcmp olt double %2763, 0.000000e+00
  %2791 = fadd double %2763, 0x7FF0000000000000
  %2792 = select i1 %2790, double 0.000000e+00, double %2791
  %2793 = fcmp olt float %2787, 0x4010E90000000000
  br i1 %2793, label %2794, label %__internal_accurate_pow.exit5

2794:                                             ; preds = %2789
  %2795 = sdiv i32 %2765, 2
  %2796 = shl i32 %2795, 20
  %2797 = add i32 %2781, %2796
  %2798 = tail call double @llvm.nvvm.lohi.i2d(i32 %2780, i32 %2797) #5
  %2799 = sub nsw i32 %2765, %2795
  %2800 = shl i32 %2799, 20
  %2801 = add nsw i32 %2800, 1072693248
  %2802 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %2801) #5
  %2803 = fmul double %2798, %2802
  br label %__internal_accurate_pow.exit5

__internal_accurate_pow.exit5:                    ; preds = %2794, %2789, %2679
  %2804 = phi double [ %2784, %2679 ], [ %2792, %2789 ], [ %2803, %2794 ]
  %2805 = fsub double %2759, %2763
  %2806 = fadd double %2762, %2805
  %2807 = tail call i32 @llvm.nvvm.d2i.lo(double %2804) #5
  %2808 = tail call i32 @llvm.nvvm.d2i.hi(double %2804) #5
  %2809 = and i32 %2808, 2147483647
  %2810 = icmp eq i32 %2809, 2146435072
  %2811 = icmp eq i32 %2807, 0
  %2812 = and i1 %2811, %2810
  %2813 = tail call double @llvm.fma.f64(double %2804, double %2806, double %2804) #5
  %2814 = select i1 %2812, double %2804, double %2813
  %2815 = icmp slt i32 %2649, 0
  %2816 = and i1 %2815, %2652
  br i1 %2816, label %2817, label %2822

2817:                                             ; preds = %__internal_accurate_pow.exit5
  %2818 = tail call i32 @llvm.nvvm.d2i.hi(double %2814) #5
  %2819 = tail call i32 @llvm.nvvm.d2i.lo(double %2814) #5
  %2820 = xor i32 %2818, -2147483648
  %2821 = tail call double @llvm.nvvm.lohi.i2d(i32 %2819, i32 %2820) #5
  br label %2822

2822:                                             ; preds = %2817, %__internal_accurate_pow.exit5
  %2823 = phi double [ %2814, %__internal_accurate_pow.exit5 ], [ %2821, %2817 ]
  %2824 = fcmp oeq double %2648, 0.000000e+00
  %2825 = select i1 %2652, i32 %2649, i32 0
  br i1 %2824, label %2826, label %2831

2826:                                             ; preds = %2822
  %2827 = icmp slt i32 %2650, 0
  %2828 = or i32 %2825, 2146435072
  %2829 = select i1 %2827, i32 %2828, i32 %2825
  %2830 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %2829) #5
  br label %2831

2831:                                             ; preds = %2826, %2822
  %2832 = phi double [ %2823, %2822 ], [ %2830, %2826 ]
  %2833 = fadd double %2648, 2.000000e+00
  %2834 = tail call i32 @llvm.nvvm.d2i.hi(double %2833) #5
  %2835 = and i32 %2834, 2146435072
  %2836 = icmp eq i32 %2835, 2146435072
  br i1 %2836, label %2837, label %2865

2837:                                             ; preds = %2831
  %2838 = fcmp ugt double %2653, 0x7FF0000000000000
  br i1 %2838, label %2865, label %2839

2839:                                             ; preds = %2837
  %2840 = and i32 %2650, 2147483647
  %2841 = icmp eq i32 %2840, 2146435072
  %2842 = icmp eq i32 %2753, 0
  %2843 = and i1 %2841, %2842
  br i1 %2843, label %2844, label %2851

2844:                                             ; preds = %2839
  %2845 = fcmp ogt double %2653, 1.000000e+00
  %2846 = select i1 %2845, i32 2146435072, i32 0
  %2847 = icmp slt i32 %2650, 0
  %2848 = xor i32 %2846, 2146435072
  %2849 = select i1 %2847, i32 %2848, i32 %2846
  %2850 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %2849) #5
  br label %2865

2851:                                             ; preds = %2839
  %2852 = tail call i32 @llvm.nvvm.d2i.lo(double %2648) #5
  %2853 = and i32 %2649, 2147483647
  %2854 = icmp eq i32 %2853, 2146435072
  %2855 = icmp eq i32 %2852, 0
  %2856 = and i1 %2854, %2855
  %2857 = icmp slt i32 %2650, 0
  %2858 = select i1 %2857, i32 0, i32 2146435072
  br i1 %2856, label %2859, label %2865

2859:                                             ; preds = %2851
  %2860 = icmp ne i32 %2840, 1071644672
  %2861 = and i1 %2860, %2816
  %2862 = or i32 %2858, -2147483648
  %2863 = select i1 %2861, i32 %2862, i32 %2858
  %2864 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %2863) #5
  br label %2865

2865:                                             ; preds = %2859, %2851, %2844, %2837, %2831
  %2866 = phi double [ %2832, %2831 ], [ %2833, %2837 ], [ %2850, %2844 ], [ %2832, %2851 ], [ %2864, %2859 ]
  %2867 = fcmp oeq double %2648, 1.000000e+00
  %2868 = select i1 %2867, double 1.000000e+00, double %2866
  %2869 = fmul double %2645, %2868
  %2870 = fmul double %129, %2869
  %2871 = fmul double %2598, 2.000000e+00
  %2872 = fadd double %2591, %2871
  %2873 = tail call double @llvm.sqrt.f64(double %2870) #5
  %2874 = fmul double %2873, 3.000000e+00
  %2875 = fsub double %2872, %2874
  %2876 = fmul double %2601, 2.000000e+00
  %2877 = fsub double %2592, %2876
  %2878 = fadd double %2877, %2874
  br label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit2.i

2879:                                             ; preds = %2626
  %2880 = fcmp olt double %2641, 0.000000e+00
  br i1 %2880, label %2883, label %2881

2881:                                             ; preds = %2879
  %2882 = fdiv double 1.000000e+00, %2616
  br label %3845

2883:                                             ; preds = %2879
  %2884 = fdiv double 1.000000e+00, %2595
  %2885 = fdiv double 1.000000e+00, %2596
  %2886 = tail call i32 @llvm.nvvm.d2i.hi(double 2.000000e+00) #5
  %2887 = and i32 %2886, 2146435072
  %2888 = icmp eq i32 %2887, 1062207488
  %2889 = icmp slt i32 %2886, 0
  %2890 = and i32 %2886, 2147483647
  %2891 = icmp eq i32 %2890, 2146435072
  %2892 = select i1 %2889, i32 0, i32 2146435072
  %2893 = icmp ne i32 %2890, 1071644672
  %2894 = or i32 %2892, -2147483648
  br i1 %2888, label %.preheader, label %3146

.preheader:                                       ; preds = %2883
  %2895 = tail call double @llvm.nvvm.lohi.i2d(i32 -2147483648, i32 1127219200) #5
  %2896 = tail call i32 @llvm.nvvm.d2i.lo(double 2.000000e+00) #5
  br i1 %2889, label %.preheader.split.us.preheader, label %.preheader.split.preheader

.preheader.split.preheader:                       ; preds = %.preheader
  %2897 = icmp ugt i32 %2886, 2130706431
  %2898 = and i32 %2886, -15728641
  %2899 = select i1 %2897, i32 %2898, i32 %2886
  %2900 = tail call double @llvm.nvvm.lohi.i2d(i32 %2896, i32 %2899) #5
  %2901 = icmp eq i32 %2896, 0
  %2902 = and i1 %2891, %2901
  br label %.preheader.split

.preheader.split.us.preheader:                    ; preds = %.preheader
  %2903 = shl i32 %2886, 1
  %2904 = icmp ugt i32 %2903, -33554433
  %2905 = and i32 %2886, -15728641
  %2906 = select i1 %2904, i32 %2905, i32 %2886
  %2907 = tail call double @llvm.nvvm.lohi.i2d(i32 %2896, i32 %2906) #5
  %2908 = icmp eq i32 %2896, 0
  %2909 = and i1 %2891, %2908
  br label %.preheader.split.us

.preheader.split.us:                              ; preds = %3134, %.preheader.split.us.preheader
  %2910 = phi double [ %2617, %.preheader.split.us.preheader ], [ %3137, %3134 ]
  %2911 = phi i32 [ 0, %.preheader.split.us.preheader ], [ %3145, %3134 ]
  %2912 = fdiv double 1.000000e+00, %2910
  %2913 = fadd double %2884, %2912
  %2914 = fmul double %2608, %2913
  %2915 = tail call double @llvm.sqrt.f64(double %2914) #5
  %2916 = fadd double %2885, %2912
  %2917 = fmul double %2608, %2916
  %2918 = tail call double @llvm.sqrt.f64(double %2917) #5
  %2919 = fsub double %2910, %2595
  %2920 = fmul double %2919, %2915
  %2921 = fadd double %2618, %2920
  %2922 = fsub double %2910, %2596
  %2923 = fmul double %2922, %2918
  %2924 = fadd double %2923, %2921
  %2925 = fmul double %129, %2919
  %2926 = fmul double %2910, %2910
  %2927 = fmul double %2926, 4.000000e+00
  %2928 = fmul double %2927, %2915
  %2929 = fdiv double %2925, %2928
  %2930 = fsub double %2915, %2929
  %2931 = fadd double %2918, %2930
  %2932 = fmul double %129, %2922
  %2933 = fmul double %2927, %2918
  %2934 = fdiv double %2932, %2933
  %2935 = fsub double %2931, %2934
  %2936 = tail call double @llvm.sqrt.f64(double %2910) #5
  %2937 = fmul double %2936, 2.000000e+00
  %2938 = fmul double %2937, %2935
  %2939 = fdiv double %2924, %2938
  %2940 = fsub double %2936, %2939
  %2941 = tail call i32 @llvm.nvvm.d2i.hi(double %2940) #5
  %2942 = tail call double @llvm.fabs.f64(double %2940) #5
  %2943 = tail call i32 @llvm.nvvm.d2i.hi(double %2942) #5
  %2944 = tail call i32 @llvm.nvvm.d2i.lo(double %2942) #5
  %2945 = lshr i32 %2943, 20
  %2946 = icmp eq i32 %2945, 0
  %2947 = fmul double %2942, 0x4350000000000000
  br i1 %2946, label %2948, label %2953

2948:                                             ; preds = %.preheader.split.us
  %2949 = tail call i32 @llvm.nvvm.d2i.hi(double %2947) #5
  %2950 = tail call i32 @llvm.nvvm.d2i.lo(double %2947) #5
  %2951 = lshr i32 %2949, 20
  %2952 = add nsw i32 %2951, -54
  br label %2953

2953:                                             ; preds = %2948, %.preheader.split.us
  %2954 = phi i32 [ %2944, %.preheader.split.us ], [ %2950, %2948 ]
  %2955 = phi i32 [ %2943, %.preheader.split.us ], [ %2949, %2948 ]
  %2956 = phi i32 [ %2945, %.preheader.split.us ], [ %2952, %2948 ]
  %2957 = add nsw i32 %2956, -1023
  %2958 = and i32 %2955, -2146435073
  %2959 = or i32 %2958, 1072693248
  %2960 = tail call double @llvm.nvvm.lohi.i2d(i32 %2954, i32 %2959) #5
  %2961 = icmp ugt i32 %2959, 1073127582
  br i1 %2961, label %2962, label %2968

2962:                                             ; preds = %2953
  %2963 = add nsw i32 %2956, -1022
  %2964 = tail call i32 @llvm.nvvm.d2i.lo(double %2960) #5
  %2965 = tail call i32 @llvm.nvvm.d2i.hi(double %2960) #5
  %2966 = add i32 %2965, -1048576
  %2967 = tail call double @llvm.nvvm.lohi.i2d(i32 %2964, i32 %2966) #5
  br label %2968

2968:                                             ; preds = %2962, %2953
  %2969 = phi double [ %2960, %2953 ], [ %2967, %2962 ]
  %2970 = phi i32 [ %2957, %2953 ], [ %2963, %2962 ]
  %2971 = fadd double %2969, -1.000000e+00
  %2972 = fadd double %2969, 1.000000e+00
  %2973 = tail call double @llvm.nvvm.rcp.approx.ftz.d(double %2972) #5
  %2974 = fneg double %2972
  %2975 = tail call double @llvm.fma.f64(double %2974, double %2973, double 1.000000e+00) #5
  %2976 = tail call double @llvm.fma.f64(double %2975, double %2975, double %2975) #5
  %2977 = tail call double @llvm.fma.f64(double %2976, double %2973, double %2973) #5
  %2978 = fmul double %2971, %2977
  %2979 = fadd double %2978, %2978
  %2980 = fmul double %2979, %2979
  %2981 = tail call double @llvm.fma.f64(double %2980, double 0x3EB0F5FF7D2CAFE2, double 0x3ED0F5D241AD3B5A) #5
  %2982 = tail call double @llvm.fma.f64(double %2981, double %2980, double 0x3EF3B20A75488A3F) #5
  %2983 = tail call double @llvm.fma.f64(double %2982, double %2980, double 0x3F1745CDE4FAECD5) #5
  %2984 = tail call double @llvm.fma.f64(double %2983, double %2980, double 0x3F3C71C7258A578B) #5
  %2985 = tail call double @llvm.fma.f64(double %2984, double %2980, double 0x3F6249249242B910) #5
  %2986 = tail call double @llvm.fma.f64(double %2985, double %2980, double 0x3F89999999999DFB) #5
  %2987 = fmul double %2980, %2986
  %2988 = fsub double %2971, %2979
  %2989 = fmul double %2988, 2.000000e+00
  %2990 = fneg double %2979
  %2991 = tail call double @llvm.fma.f64(double %2990, double %2971, double %2989) #5
  %2992 = fmul double %2977, %2991
  %2993 = fadd double %2987, 0x3FB5555555555555
  %2994 = fsub double 0x3FB5555555555555, %2993
  %2995 = fadd double %2987, %2994
  %2996 = fadd double %2995, 0.000000e+00
  %2997 = fadd double %2996, 0xBC46A4CB00B9E7B0
  %2998 = fadd double %2993, %2997
  %2999 = fsub double %2993, %2998
  %3000 = fadd double %2997, %2999
  %3001 = fneg double %2980
  %3002 = tail call double @llvm.fma.f64(double %2979, double %2979, double %3001) #5
  %3003 = tail call i32 @llvm.nvvm.d2i.lo(double %2992) #5
  %3004 = tail call i32 @llvm.nvvm.d2i.hi(double %2992) #5
  %3005 = add i32 %3004, 1048576
  %3006 = tail call double @llvm.nvvm.lohi.i2d(i32 %3003, i32 %3005) #5
  %3007 = tail call double @llvm.fma.f64(double %2979, double %3006, double %3002) #5
  %3008 = fmul double %2979, %2980
  %3009 = fneg double %3008
  %3010 = tail call double @llvm.fma.f64(double %2980, double %2979, double %3009) #5
  %3011 = tail call double @llvm.fma.f64(double %2980, double %2992, double %3010) #5
  %3012 = tail call double @llvm.fma.f64(double %3007, double %2979, double %3011) #5
  %3013 = fmul double %3008, %2998
  %3014 = fneg double %3013
  %3015 = tail call double @llvm.fma.f64(double %2998, double %3008, double %3014) #5
  %3016 = tail call double @llvm.fma.f64(double %2998, double %3012, double %3015) #5
  %3017 = tail call double @llvm.fma.f64(double %3000, double %3008, double %3016) #5
  %3018 = fadd double %3013, %3017
  %3019 = fsub double %3013, %3018
  %3020 = fadd double %3017, %3019
  %3021 = fadd double %2979, %3018
  %3022 = fsub double %2979, %3021
  %3023 = fadd double %3018, %3022
  %3024 = fadd double %3020, %3023
  %3025 = fadd double %2992, %3024
  %3026 = fadd double %3021, %3025
  %3027 = fsub double %3021, %3026
  %3028 = fadd double %3025, %3027
  %3029 = xor i32 %2970, -2147483648
  %3030 = tail call double @llvm.nvvm.lohi.i2d(i32 %3029, i32 1127219200) #5
  %3031 = fsub double %3030, %2895
  %3032 = tail call double @llvm.fma.f64(double %3031, double 0x3FE62E42FEFA39EF, double %3026) #5
  %3033 = fneg double %3031
  %3034 = tail call double @llvm.fma.f64(double %3033, double 0x3FE62E42FEFA39EF, double %3032) #5
  %3035 = fsub double %3034, %3026
  %3036 = fsub double %3028, %3035
  %3037 = tail call double @llvm.fma.f64(double %3031, double 0x3C7ABC9E3B39803F, double %3036) #5
  %3038 = fadd double %3032, %3037
  %3039 = fsub double %3032, %3038
  %3040 = fadd double %3037, %3039
  %3041 = fmul double %2907, %3038
  %3042 = fneg double %3041
  %3043 = tail call double @llvm.fma.f64(double %3038, double %2907, double %3042) #5
  %3044 = tail call double @llvm.fma.f64(double %3040, double %2907, double %3043) #5
  %3045 = fadd double %3041, %3044
  %3046 = tail call double @llvm.fma.f64(double %3045, double 0x3FF71547652B82FE, double 0x4338000000000000) #5
  %3047 = tail call i32 @llvm.nvvm.d2i.lo(double %3046) #5
  %3048 = fadd double %3046, 0xC338000000000000
  %3049 = tail call double @llvm.fma.f64(double %3048, double 0xBFE62E42FEFA39EF, double %3045) #5
  %3050 = tail call double @llvm.fma.f64(double %3048, double 0xBC7ABC9E3B39803F, double %3049) #5
  %3051 = tail call double @llvm.fma.f64(double %3050, double 0x3E5ADE1569CE2BDF, double 0x3E928AF3FCA213EA) #5
  %3052 = tail call double @llvm.fma.f64(double %3051, double %3050, double 0x3EC71DEE62401315) #5
  %3053 = tail call double @llvm.fma.f64(double %3052, double %3050, double 0x3EFA01997C89EB71) #5
  %3054 = tail call double @llvm.fma.f64(double %3053, double %3050, double 0x3F2A01A014761F65) #5
  %3055 = tail call double @llvm.fma.f64(double %3054, double %3050, double 0x3F56C16C1852B7AF) #5
  %3056 = tail call double @llvm.fma.f64(double %3055, double %3050, double 0x3F81111111122322) #5
  %3057 = tail call double @llvm.fma.f64(double %3056, double %3050, double 0x3FA55555555502A1) #5
  %3058 = tail call double @llvm.fma.f64(double %3057, double %3050, double 0x3FC5555555555511) #5
  %3059 = tail call double @llvm.fma.f64(double %3058, double %3050, double 0x3FE000000000000B) #5
  %3060 = tail call double @llvm.fma.f64(double %3059, double %3050, double 1.000000e+00) #5
  %3061 = tail call double @llvm.fma.f64(double %3060, double %3050, double 1.000000e+00) #5
  %3062 = tail call i32 @llvm.nvvm.d2i.lo(double %3061) #5
  %3063 = tail call i32 @llvm.nvvm.d2i.hi(double %3061) #5
  %3064 = shl i32 %3047, 20
  %3065 = add i32 %3063, %3064
  %3066 = tail call double @llvm.nvvm.lohi.i2d(i32 %3062, i32 %3065) #5
  %3067 = tail call i32 @llvm.nvvm.d2i.hi(double %3045) #5
  %3068 = bitcast i32 %3067 to float
  %3069 = tail call float @llvm.fabs.f32(float %3068) #5
  %3070 = fcmp olt float %3069, 0x4010C46560000000
  br i1 %3070, label %__internal_accurate_pow.exit4, label %3071

3071:                                             ; preds = %2968
  %3072 = fcmp olt double %3045, 0.000000e+00
  %3073 = fadd double %3045, 0x7FF0000000000000
  %3074 = select i1 %3072, double 0.000000e+00, double %3073
  %3075 = fcmp olt float %3069, 0x4010E90000000000
  br i1 %3075, label %3076, label %__internal_accurate_pow.exit4

3076:                                             ; preds = %3071
  %3077 = sdiv i32 %3047, 2
  %3078 = shl i32 %3077, 20
  %3079 = add i32 %3063, %3078
  %3080 = tail call double @llvm.nvvm.lohi.i2d(i32 %3062, i32 %3079) #5
  %3081 = sub nsw i32 %3047, %3077
  %3082 = shl i32 %3081, 20
  %3083 = add nsw i32 %3082, 1072693248
  %3084 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %3083) #5
  %3085 = fmul double %3080, %3084
  br label %__internal_accurate_pow.exit4

__internal_accurate_pow.exit4:                    ; preds = %3076, %3071, %2968
  %3086 = phi double [ %3066, %2968 ], [ %3074, %3071 ], [ %3085, %3076 ]
  %3087 = fsub double %3041, %3045
  %3088 = fadd double %3044, %3087
  %3089 = tail call i32 @llvm.nvvm.d2i.lo(double %3086) #5
  %3090 = tail call i32 @llvm.nvvm.d2i.hi(double %3086) #5
  %3091 = and i32 %3090, 2147483647
  %3092 = icmp eq i32 %3091, 2146435072
  %3093 = icmp eq i32 %3089, 0
  %3094 = and i1 %3093, %3092
  %3095 = tail call double @llvm.fma.f64(double %3086, double %3088, double %3086) #5
  %3096 = select i1 %3094, double %3086, double %3095
  %3097 = icmp slt i32 %2941, 0
  br i1 %3097, label %3098, label %3103

3098:                                             ; preds = %__internal_accurate_pow.exit4
  %3099 = tail call i32 @llvm.nvvm.d2i.hi(double %3096) #5
  %3100 = tail call i32 @llvm.nvvm.d2i.lo(double %3096) #5
  %3101 = xor i32 %3099, -2147483648
  %3102 = tail call double @llvm.nvvm.lohi.i2d(i32 %3100, i32 %3101) #5
  br label %3103

3103:                                             ; preds = %3098, %__internal_accurate_pow.exit4
  %3104 = phi double [ %3096, %__internal_accurate_pow.exit4 ], [ %3102, %3098 ]
  %3105 = fcmp oeq double %2940, 0.000000e+00
  br i1 %3105, label %3106, label %3109

3106:                                             ; preds = %3103
  %3107 = or i32 %2941, 2146435072
  %3108 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %3107) #5
  br label %3109

3109:                                             ; preds = %3106, %3103
  %3110 = phi double [ %3104, %3103 ], [ %3108, %3106 ]
  %3111 = fadd double %2940, 2.000000e+00
  %3112 = tail call i32 @llvm.nvvm.d2i.hi(double %3111) #5
  %3113 = and i32 %3112, 2146435072
  %3114 = icmp eq i32 %3113, 2146435072
  br i1 %3114, label %3115, label %3134

3115:                                             ; preds = %3109
  %3116 = fcmp ugt double %2942, 0x7FF0000000000000
  br i1 %3116, label %3134, label %3117

3117:                                             ; preds = %3115
  br i1 %2909, label %3128, label %3118

3118:                                             ; preds = %3117
  %3119 = tail call i32 @llvm.nvvm.d2i.lo(double %2940) #5
  %3120 = and i32 %2941, 2147483647
  %3121 = icmp eq i32 %3120, 2146435072
  %3122 = icmp eq i32 %3119, 0
  %3123 = and i1 %3121, %3122
  br i1 %3123, label %3124, label %3134

3124:                                             ; preds = %3118
  %3125 = and i1 %2893, %3097
  %3126 = select i1 %3125, i32 %2894, i32 %2892
  %3127 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %3126) #5
  br label %3134

3128:                                             ; preds = %3117
  %3129 = fcmp ogt double %2942, 1.000000e+00
  %3130 = select i1 %3129, i32 0, i32 2146435072
  %3131 = fcmp oeq double %2940, -1.000000e+00
  %3132 = select i1 %3131, i32 1072693248, i32 %3130
  %3133 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %3132) #5
  br label %3134

3134:                                             ; preds = %3128, %3124, %3118, %3115, %3109
  %3135 = phi double [ %3110, %3109 ], [ %3111, %3115 ], [ %3110, %3118 ], [ %3127, %3124 ], [ %3133, %3128 ]
  %3136 = fcmp oeq double %2940, 1.000000e+00
  %3137 = select i1 %3136, double 1.000000e+00, double %3135
  %3138 = fsub double %2910, %3137
  %3139 = tail call double @llvm.fabs.f64(double %3138) #5
  %3140 = tail call double @llvm.fabs.f64(double %2910) #5
  %3141 = fmul double %3140, 1.000000e-04
  %3142 = fcmp ole double %3139, %3141
  %3143 = icmp ugt i32 %2911, 9
  %3144 = or i1 %3143, %3142
  %3145 = add nuw nsw i32 %2911, 1
  br i1 %3144, label %.loopexit, label %.preheader.split.us

3146:                                             ; preds = %2883
  %3147 = select i1 %2889, i32 2146435072, i32 0
  %3148 = tail call double @llvm.nvvm.lohi.i2d(i32 -2147483648, i32 1127219200) #5
  %3149 = tail call i32 @llvm.nvvm.d2i.lo(double 2.000000e+00) #5
  %3150 = shl i32 %2886, 1
  %3151 = icmp ugt i32 %3150, -33554433
  %3152 = and i32 %2886, -15728641
  %3153 = select i1 %3151, i32 %3152, i32 %2886
  %3154 = tail call double @llvm.nvvm.lohi.i2d(i32 %3149, i32 %3153) #5
  br i1 %2891, label %.split76.us.preheader, label %.split76

.split76.us.preheader:                            ; preds = %3146
  %3155 = icmp eq i32 %3149, 0
  br label %.split76.us

.split76.us:                                      ; preds = %3371, %.split76.us.preheader
  %3156 = phi double [ %2617, %.split76.us.preheader ], [ %3374, %3371 ]
  %3157 = phi i32 [ 0, %.split76.us.preheader ], [ %3382, %3371 ]
  %3158 = fdiv double 1.000000e+00, %3156
  %3159 = fadd double %2884, %3158
  %3160 = fmul double %2608, %3159
  %3161 = tail call double @llvm.sqrt.f64(double %3160) #5
  %3162 = fadd double %2885, %3158
  %3163 = fmul double %2608, %3162
  %3164 = tail call double @llvm.sqrt.f64(double %3163) #5
  %3165 = fsub double %3156, %2595
  %3166 = fmul double %3165, %3161
  %3167 = fadd double %2618, %3166
  %3168 = fsub double %3156, %2596
  %3169 = fmul double %3168, %3164
  %3170 = fadd double %3169, %3167
  %3171 = fmul double %129, %3165
  %3172 = fmul double %3156, %3156
  %3173 = fmul double %3172, 4.000000e+00
  %3174 = fmul double %3173, %3161
  %3175 = fdiv double %3171, %3174
  %3176 = fsub double %3161, %3175
  %3177 = fadd double %3164, %3176
  %3178 = fmul double %129, %3168
  %3179 = fmul double %3173, %3164
  %3180 = fdiv double %3178, %3179
  %3181 = fsub double %3177, %3180
  %3182 = tail call double @llvm.sqrt.f64(double %3156) #5
  %3183 = fmul double %3182, 2.000000e+00
  %3184 = fmul double %3183, %3181
  %3185 = fdiv double %3170, %3184
  %3186 = fsub double %3182, %3185
  %3187 = tail call i32 @llvm.nvvm.d2i.hi(double %3186) #5
  %3188 = tail call double @llvm.fabs.f64(double %3186) #5
  %3189 = tail call i32 @llvm.nvvm.d2i.hi(double %3188) #5
  %3190 = tail call i32 @llvm.nvvm.d2i.lo(double %3188) #5
  %3191 = lshr i32 %3189, 20
  %3192 = icmp eq i32 %3191, 0
  %3193 = fmul double %3188, 0x4350000000000000
  br i1 %3192, label %3194, label %3199

3194:                                             ; preds = %.split76.us
  %3195 = tail call i32 @llvm.nvvm.d2i.hi(double %3193) #5
  %3196 = tail call i32 @llvm.nvvm.d2i.lo(double %3193) #5
  %3197 = lshr i32 %3195, 20
  %3198 = add nsw i32 %3197, -54
  br label %3199

3199:                                             ; preds = %3194, %.split76.us
  %3200 = phi i32 [ %3190, %.split76.us ], [ %3196, %3194 ]
  %3201 = phi i32 [ %3189, %.split76.us ], [ %3195, %3194 ]
  %3202 = phi i32 [ %3191, %.split76.us ], [ %3198, %3194 ]
  %3203 = add nsw i32 %3202, -1023
  %3204 = and i32 %3201, -2146435073
  %3205 = or i32 %3204, 1072693248
  %3206 = tail call double @llvm.nvvm.lohi.i2d(i32 %3200, i32 %3205) #5
  %3207 = icmp ugt i32 %3205, 1073127582
  br i1 %3207, label %3208, label %3214

3208:                                             ; preds = %3199
  %3209 = add nsw i32 %3202, -1022
  %3210 = tail call i32 @llvm.nvvm.d2i.lo(double %3206) #5
  %3211 = tail call i32 @llvm.nvvm.d2i.hi(double %3206) #5
  %3212 = add i32 %3211, -1048576
  %3213 = tail call double @llvm.nvvm.lohi.i2d(i32 %3210, i32 %3212) #5
  br label %3214

3214:                                             ; preds = %3208, %3199
  %3215 = phi double [ %3206, %3199 ], [ %3213, %3208 ]
  %3216 = phi i32 [ %3203, %3199 ], [ %3209, %3208 ]
  %3217 = fadd double %3215, -1.000000e+00
  %3218 = fadd double %3215, 1.000000e+00
  %3219 = tail call double @llvm.nvvm.rcp.approx.ftz.d(double %3218) #5
  %3220 = fneg double %3218
  %3221 = tail call double @llvm.fma.f64(double %3220, double %3219, double 1.000000e+00) #5
  %3222 = tail call double @llvm.fma.f64(double %3221, double %3221, double %3221) #5
  %3223 = tail call double @llvm.fma.f64(double %3222, double %3219, double %3219) #5
  %3224 = fmul double %3217, %3223
  %3225 = fadd double %3224, %3224
  %3226 = fmul double %3225, %3225
  %3227 = tail call double @llvm.fma.f64(double %3226, double 0x3EB0F5FF7D2CAFE2, double 0x3ED0F5D241AD3B5A) #5
  %3228 = tail call double @llvm.fma.f64(double %3227, double %3226, double 0x3EF3B20A75488A3F) #5
  %3229 = tail call double @llvm.fma.f64(double %3228, double %3226, double 0x3F1745CDE4FAECD5) #5
  %3230 = tail call double @llvm.fma.f64(double %3229, double %3226, double 0x3F3C71C7258A578B) #5
  %3231 = tail call double @llvm.fma.f64(double %3230, double %3226, double 0x3F6249249242B910) #5
  %3232 = tail call double @llvm.fma.f64(double %3231, double %3226, double 0x3F89999999999DFB) #5
  %3233 = fmul double %3226, %3232
  %3234 = fsub double %3217, %3225
  %3235 = fmul double %3234, 2.000000e+00
  %3236 = fneg double %3225
  %3237 = tail call double @llvm.fma.f64(double %3236, double %3217, double %3235) #5
  %3238 = fmul double %3223, %3237
  %3239 = fadd double %3233, 0x3FB5555555555555
  %3240 = fsub double 0x3FB5555555555555, %3239
  %3241 = fadd double %3233, %3240
  %3242 = fadd double %3241, 0.000000e+00
  %3243 = fadd double %3242, 0xBC46A4CB00B9E7B0
  %3244 = fadd double %3239, %3243
  %3245 = fsub double %3239, %3244
  %3246 = fadd double %3243, %3245
  %3247 = fneg double %3226
  %3248 = tail call double @llvm.fma.f64(double %3225, double %3225, double %3247) #5
  %3249 = tail call i32 @llvm.nvvm.d2i.lo(double %3238) #5
  %3250 = tail call i32 @llvm.nvvm.d2i.hi(double %3238) #5
  %3251 = add i32 %3250, 1048576
  %3252 = tail call double @llvm.nvvm.lohi.i2d(i32 %3249, i32 %3251) #5
  %3253 = tail call double @llvm.fma.f64(double %3225, double %3252, double %3248) #5
  %3254 = fmul double %3225, %3226
  %3255 = fneg double %3254
  %3256 = tail call double @llvm.fma.f64(double %3226, double %3225, double %3255) #5
  %3257 = tail call double @llvm.fma.f64(double %3226, double %3238, double %3256) #5
  %3258 = tail call double @llvm.fma.f64(double %3253, double %3225, double %3257) #5
  %3259 = fmul double %3254, %3244
  %3260 = fneg double %3259
  %3261 = tail call double @llvm.fma.f64(double %3244, double %3254, double %3260) #5
  %3262 = tail call double @llvm.fma.f64(double %3244, double %3258, double %3261) #5
  %3263 = tail call double @llvm.fma.f64(double %3246, double %3254, double %3262) #5
  %3264 = fadd double %3259, %3263
  %3265 = fsub double %3259, %3264
  %3266 = fadd double %3263, %3265
  %3267 = fadd double %3225, %3264
  %3268 = fsub double %3225, %3267
  %3269 = fadd double %3264, %3268
  %3270 = fadd double %3266, %3269
  %3271 = fadd double %3238, %3270
  %3272 = fadd double %3267, %3271
  %3273 = fsub double %3267, %3272
  %3274 = fadd double %3271, %3273
  %3275 = xor i32 %3216, -2147483648
  %3276 = tail call double @llvm.nvvm.lohi.i2d(i32 %3275, i32 1127219200) #5
  %3277 = fsub double %3276, %3148
  %3278 = tail call double @llvm.fma.f64(double %3277, double 0x3FE62E42FEFA39EF, double %3272) #5
  %3279 = fneg double %3277
  %3280 = tail call double @llvm.fma.f64(double %3279, double 0x3FE62E42FEFA39EF, double %3278) #5
  %3281 = fsub double %3280, %3272
  %3282 = fsub double %3274, %3281
  %3283 = tail call double @llvm.fma.f64(double %3277, double 0x3C7ABC9E3B39803F, double %3282) #5
  %3284 = fadd double %3278, %3283
  %3285 = fsub double %3278, %3284
  %3286 = fadd double %3283, %3285
  %3287 = fmul double %3154, %3284
  %3288 = fneg double %3287
  %3289 = tail call double @llvm.fma.f64(double %3284, double %3154, double %3288) #5
  %3290 = tail call double @llvm.fma.f64(double %3286, double %3154, double %3289) #5
  %3291 = fadd double %3287, %3290
  %3292 = tail call double @llvm.fma.f64(double %3291, double 0x3FF71547652B82FE, double 0x4338000000000000) #5
  %3293 = tail call i32 @llvm.nvvm.d2i.lo(double %3292) #5
  %3294 = fadd double %3292, 0xC338000000000000
  %3295 = tail call double @llvm.fma.f64(double %3294, double 0xBFE62E42FEFA39EF, double %3291) #5
  %3296 = tail call double @llvm.fma.f64(double %3294, double 0xBC7ABC9E3B39803F, double %3295) #5
  %3297 = tail call double @llvm.fma.f64(double %3296, double 0x3E5ADE1569CE2BDF, double 0x3E928AF3FCA213EA) #5
  %3298 = tail call double @llvm.fma.f64(double %3297, double %3296, double 0x3EC71DEE62401315) #5
  %3299 = tail call double @llvm.fma.f64(double %3298, double %3296, double 0x3EFA01997C89EB71) #5
  %3300 = tail call double @llvm.fma.f64(double %3299, double %3296, double 0x3F2A01A014761F65) #5
  %3301 = tail call double @llvm.fma.f64(double %3300, double %3296, double 0x3F56C16C1852B7AF) #5
  %3302 = tail call double @llvm.fma.f64(double %3301, double %3296, double 0x3F81111111122322) #5
  %3303 = tail call double @llvm.fma.f64(double %3302, double %3296, double 0x3FA55555555502A1) #5
  %3304 = tail call double @llvm.fma.f64(double %3303, double %3296, double 0x3FC5555555555511) #5
  %3305 = tail call double @llvm.fma.f64(double %3304, double %3296, double 0x3FE000000000000B) #5
  %3306 = tail call double @llvm.fma.f64(double %3305, double %3296, double 1.000000e+00) #5
  %3307 = tail call double @llvm.fma.f64(double %3306, double %3296, double 1.000000e+00) #5
  %3308 = tail call i32 @llvm.nvvm.d2i.lo(double %3307) #5
  %3309 = tail call i32 @llvm.nvvm.d2i.hi(double %3307) #5
  %3310 = shl i32 %3293, 20
  %3311 = add i32 %3309, %3310
  %3312 = tail call double @llvm.nvvm.lohi.i2d(i32 %3308, i32 %3311) #5
  %3313 = tail call i32 @llvm.nvvm.d2i.hi(double %3291) #5
  %3314 = bitcast i32 %3313 to float
  %3315 = tail call float @llvm.fabs.f32(float %3314) #5
  %3316 = fcmp olt float %3315, 0x4010C46560000000
  br i1 %3316, label %__internal_accurate_pow.exit3, label %3317

3317:                                             ; preds = %3214
  %3318 = fcmp olt double %3291, 0.000000e+00
  %3319 = fadd double %3291, 0x7FF0000000000000
  %3320 = select i1 %3318, double 0.000000e+00, double %3319
  %3321 = fcmp olt float %3315, 0x4010E90000000000
  br i1 %3321, label %3322, label %__internal_accurate_pow.exit3

3322:                                             ; preds = %3317
  %3323 = sdiv i32 %3293, 2
  %3324 = shl i32 %3323, 20
  %3325 = add i32 %3309, %3324
  %3326 = tail call double @llvm.nvvm.lohi.i2d(i32 %3308, i32 %3325) #5
  %3327 = sub nsw i32 %3293, %3323
  %3328 = shl i32 %3327, 20
  %3329 = add nsw i32 %3328, 1072693248
  %3330 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %3329) #5
  %3331 = fmul double %3326, %3330
  br label %__internal_accurate_pow.exit3

__internal_accurate_pow.exit3:                    ; preds = %3322, %3317, %3214
  %3332 = phi double [ %3312, %3214 ], [ %3320, %3317 ], [ %3331, %3322 ]
  %3333 = fsub double %3287, %3291
  %3334 = fadd double %3290, %3333
  %3335 = tail call i32 @llvm.nvvm.d2i.lo(double %3332) #5
  %3336 = tail call i32 @llvm.nvvm.d2i.hi(double %3332) #5
  %3337 = and i32 %3336, 2147483647
  %3338 = icmp eq i32 %3337, 2146435072
  %3339 = icmp eq i32 %3335, 0
  %3340 = and i1 %3339, %3338
  %3341 = tail call double @llvm.fma.f64(double %3332, double %3334, double %3332) #5
  %3342 = select i1 %3340, double %3332, double %3341
  %3343 = fcmp oeq double %3186, 0.000000e+00
  br i1 %3343, label %3344, label %3346

3344:                                             ; preds = %__internal_accurate_pow.exit3
  %3345 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %3147) #5
  br label %3346

3346:                                             ; preds = %3344, %__internal_accurate_pow.exit3
  %3347 = phi double [ %3342, %__internal_accurate_pow.exit3 ], [ %3345, %3344 ]
  %3348 = fadd double %3186, 2.000000e+00
  %3349 = tail call i32 @llvm.nvvm.d2i.hi(double %3348) #5
  %3350 = and i32 %3349, 2146435072
  %3351 = icmp eq i32 %3350, 2146435072
  br i1 %3351, label %3352, label %3371

3352:                                             ; preds = %3346
  %3353 = fcmp ugt double %3188, 0x7FF0000000000000
  br i1 %3353, label %3371, label %3354

3354:                                             ; preds = %3352
  br i1 %3155, label %3363, label %3355

3355:                                             ; preds = %3354
  %3356 = tail call i32 @llvm.nvvm.d2i.lo(double %3186) #5
  %3357 = and i32 %3187, 2147483647
  %3358 = icmp eq i32 %3357, 2146435072
  %3359 = icmp eq i32 %3356, 0
  %3360 = and i1 %3358, %3359
  br i1 %3360, label %3361, label %3371

3361:                                             ; preds = %3355
  %3362 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %2892) #5
  br label %3371

3363:                                             ; preds = %3354
  %3364 = fcmp ogt double %3188, 1.000000e+00
  %3365 = select i1 %3364, i32 2146435072, i32 0
  %3366 = xor i32 %3365, 2146435072
  %3367 = select i1 %2889, i32 %3366, i32 %3365
  %3368 = fcmp oeq double %3186, -1.000000e+00
  %3369 = select i1 %3368, i32 1072693248, i32 %3367
  %3370 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %3369) #5
  br label %3371

3371:                                             ; preds = %3363, %3361, %3355, %3352, %3346
  %3372 = phi double [ %3347, %3346 ], [ %3348, %3352 ], [ %3347, %3355 ], [ %3362, %3361 ], [ %3370, %3363 ]
  %3373 = fcmp oeq double %3186, 1.000000e+00
  %3374 = select i1 %3373, double 1.000000e+00, double %3372
  %3375 = fsub double %3156, %3374
  %3376 = tail call double @llvm.fabs.f64(double %3375) #5
  %3377 = tail call double @llvm.fabs.f64(double %3156) #5
  %3378 = fmul double %3377, 1.000000e-04
  %3379 = fcmp ole double %3376, %3378
  %3380 = icmp ugt i32 %3157, 9
  %3381 = or i1 %3380, %3379
  %3382 = add nuw nsw i32 %3157, 1
  br i1 %3381, label %.loopexit, label %.split76.us

.preheader.split:                                 ; preds = %3606, %.preheader.split.preheader
  %3383 = phi double [ %2617, %.preheader.split.preheader ], [ %3609, %3606 ]
  %3384 = phi i32 [ 0, %.preheader.split.preheader ], [ %3617, %3606 ]
  %3385 = fdiv double 1.000000e+00, %3383
  %3386 = fadd double %2884, %3385
  %3387 = fmul double %2608, %3386
  %3388 = tail call double @llvm.sqrt.f64(double %3387) #5
  %3389 = fadd double %2885, %3385
  %3390 = fmul double %2608, %3389
  %3391 = tail call double @llvm.sqrt.f64(double %3390) #5
  %3392 = fsub double %3383, %2595
  %3393 = fmul double %3392, %3388
  %3394 = fadd double %2618, %3393
  %3395 = fsub double %3383, %2596
  %3396 = fmul double %3395, %3391
  %3397 = fadd double %3396, %3394
  %3398 = fmul double %129, %3392
  %3399 = fmul double %3383, %3383
  %3400 = fmul double %3399, 4.000000e+00
  %3401 = fmul double %3400, %3388
  %3402 = fdiv double %3398, %3401
  %3403 = fsub double %3388, %3402
  %3404 = fadd double %3391, %3403
  %3405 = fmul double %129, %3395
  %3406 = fmul double %3400, %3391
  %3407 = fdiv double %3405, %3406
  %3408 = fsub double %3404, %3407
  %3409 = tail call double @llvm.sqrt.f64(double %3383) #5
  %3410 = fmul double %3409, 2.000000e+00
  %3411 = fmul double %3410, %3408
  %3412 = fdiv double %3397, %3411
  %3413 = fsub double %3409, %3412
  %3414 = tail call i32 @llvm.nvvm.d2i.hi(double %3413) #5
  %3415 = tail call double @llvm.fabs.f64(double %3413) #5
  %3416 = tail call i32 @llvm.nvvm.d2i.hi(double %3415) #5
  %3417 = tail call i32 @llvm.nvvm.d2i.lo(double %3415) #5
  %3418 = lshr i32 %3416, 20
  %3419 = icmp eq i32 %3418, 0
  %3420 = fmul double %3415, 0x4350000000000000
  br i1 %3419, label %3421, label %3426

3421:                                             ; preds = %.preheader.split
  %3422 = tail call i32 @llvm.nvvm.d2i.hi(double %3420) #5
  %3423 = tail call i32 @llvm.nvvm.d2i.lo(double %3420) #5
  %3424 = lshr i32 %3422, 20
  %3425 = add nsw i32 %3424, -54
  br label %3426

3426:                                             ; preds = %3421, %.preheader.split
  %3427 = phi i32 [ %3417, %.preheader.split ], [ %3423, %3421 ]
  %3428 = phi i32 [ %3416, %.preheader.split ], [ %3422, %3421 ]
  %3429 = phi i32 [ %3418, %.preheader.split ], [ %3425, %3421 ]
  %3430 = add nsw i32 %3429, -1023
  %3431 = and i32 %3428, -2146435073
  %3432 = or i32 %3431, 1072693248
  %3433 = tail call double @llvm.nvvm.lohi.i2d(i32 %3427, i32 %3432) #5
  %3434 = icmp ugt i32 %3432, 1073127582
  br i1 %3434, label %3435, label %3441

3435:                                             ; preds = %3426
  %3436 = add nsw i32 %3429, -1022
  %3437 = tail call i32 @llvm.nvvm.d2i.lo(double %3433) #5
  %3438 = tail call i32 @llvm.nvvm.d2i.hi(double %3433) #5
  %3439 = add i32 %3438, -1048576
  %3440 = tail call double @llvm.nvvm.lohi.i2d(i32 %3437, i32 %3439) #5
  br label %3441

3441:                                             ; preds = %3435, %3426
  %3442 = phi double [ %3433, %3426 ], [ %3440, %3435 ]
  %3443 = phi i32 [ %3430, %3426 ], [ %3436, %3435 ]
  %3444 = fadd double %3442, -1.000000e+00
  %3445 = fadd double %3442, 1.000000e+00
  %3446 = tail call double @llvm.nvvm.rcp.approx.ftz.d(double %3445) #5
  %3447 = fneg double %3445
  %3448 = tail call double @llvm.fma.f64(double %3447, double %3446, double 1.000000e+00) #5
  %3449 = tail call double @llvm.fma.f64(double %3448, double %3448, double %3448) #5
  %3450 = tail call double @llvm.fma.f64(double %3449, double %3446, double %3446) #5
  %3451 = fmul double %3444, %3450
  %3452 = fadd double %3451, %3451
  %3453 = fmul double %3452, %3452
  %3454 = tail call double @llvm.fma.f64(double %3453, double 0x3EB0F5FF7D2CAFE2, double 0x3ED0F5D241AD3B5A) #5
  %3455 = tail call double @llvm.fma.f64(double %3454, double %3453, double 0x3EF3B20A75488A3F) #5
  %3456 = tail call double @llvm.fma.f64(double %3455, double %3453, double 0x3F1745CDE4FAECD5) #5
  %3457 = tail call double @llvm.fma.f64(double %3456, double %3453, double 0x3F3C71C7258A578B) #5
  %3458 = tail call double @llvm.fma.f64(double %3457, double %3453, double 0x3F6249249242B910) #5
  %3459 = tail call double @llvm.fma.f64(double %3458, double %3453, double 0x3F89999999999DFB) #5
  %3460 = fmul double %3453, %3459
  %3461 = fsub double %3444, %3452
  %3462 = fmul double %3461, 2.000000e+00
  %3463 = fneg double %3452
  %3464 = tail call double @llvm.fma.f64(double %3463, double %3444, double %3462) #5
  %3465 = fmul double %3450, %3464
  %3466 = fadd double %3460, 0x3FB5555555555555
  %3467 = fsub double 0x3FB5555555555555, %3466
  %3468 = fadd double %3460, %3467
  %3469 = fadd double %3468, 0.000000e+00
  %3470 = fadd double %3469, 0xBC46A4CB00B9E7B0
  %3471 = fadd double %3466, %3470
  %3472 = fsub double %3466, %3471
  %3473 = fadd double %3470, %3472
  %3474 = fneg double %3453
  %3475 = tail call double @llvm.fma.f64(double %3452, double %3452, double %3474) #5
  %3476 = tail call i32 @llvm.nvvm.d2i.lo(double %3465) #5
  %3477 = tail call i32 @llvm.nvvm.d2i.hi(double %3465) #5
  %3478 = add i32 %3477, 1048576
  %3479 = tail call double @llvm.nvvm.lohi.i2d(i32 %3476, i32 %3478) #5
  %3480 = tail call double @llvm.fma.f64(double %3452, double %3479, double %3475) #5
  %3481 = fmul double %3452, %3453
  %3482 = fneg double %3481
  %3483 = tail call double @llvm.fma.f64(double %3453, double %3452, double %3482) #5
  %3484 = tail call double @llvm.fma.f64(double %3453, double %3465, double %3483) #5
  %3485 = tail call double @llvm.fma.f64(double %3480, double %3452, double %3484) #5
  %3486 = fmul double %3481, %3471
  %3487 = fneg double %3486
  %3488 = tail call double @llvm.fma.f64(double %3471, double %3481, double %3487) #5
  %3489 = tail call double @llvm.fma.f64(double %3471, double %3485, double %3488) #5
  %3490 = tail call double @llvm.fma.f64(double %3473, double %3481, double %3489) #5
  %3491 = fadd double %3486, %3490
  %3492 = fsub double %3486, %3491
  %3493 = fadd double %3490, %3492
  %3494 = fadd double %3452, %3491
  %3495 = fsub double %3452, %3494
  %3496 = fadd double %3491, %3495
  %3497 = fadd double %3493, %3496
  %3498 = fadd double %3465, %3497
  %3499 = fadd double %3494, %3498
  %3500 = fsub double %3494, %3499
  %3501 = fadd double %3498, %3500
  %3502 = xor i32 %3443, -2147483648
  %3503 = tail call double @llvm.nvvm.lohi.i2d(i32 %3502, i32 1127219200) #5
  %3504 = fsub double %3503, %2895
  %3505 = tail call double @llvm.fma.f64(double %3504, double 0x3FE62E42FEFA39EF, double %3499) #5
  %3506 = fneg double %3504
  %3507 = tail call double @llvm.fma.f64(double %3506, double 0x3FE62E42FEFA39EF, double %3505) #5
  %3508 = fsub double %3507, %3499
  %3509 = fsub double %3501, %3508
  %3510 = tail call double @llvm.fma.f64(double %3504, double 0x3C7ABC9E3B39803F, double %3509) #5
  %3511 = fadd double %3505, %3510
  %3512 = fsub double %3505, %3511
  %3513 = fadd double %3510, %3512
  %3514 = fmul double %2900, %3511
  %3515 = fneg double %3514
  %3516 = tail call double @llvm.fma.f64(double %3511, double %2900, double %3515) #5
  %3517 = tail call double @llvm.fma.f64(double %3513, double %2900, double %3516) #5
  %3518 = fadd double %3514, %3517
  %3519 = tail call double @llvm.fma.f64(double %3518, double 0x3FF71547652B82FE, double 0x4338000000000000) #5
  %3520 = tail call i32 @llvm.nvvm.d2i.lo(double %3519) #5
  %3521 = fadd double %3519, 0xC338000000000000
  %3522 = tail call double @llvm.fma.f64(double %3521, double 0xBFE62E42FEFA39EF, double %3518) #5
  %3523 = tail call double @llvm.fma.f64(double %3521, double 0xBC7ABC9E3B39803F, double %3522) #5
  %3524 = tail call double @llvm.fma.f64(double %3523, double 0x3E5ADE1569CE2BDF, double 0x3E928AF3FCA213EA) #5
  %3525 = tail call double @llvm.fma.f64(double %3524, double %3523, double 0x3EC71DEE62401315) #5
  %3526 = tail call double @llvm.fma.f64(double %3525, double %3523, double 0x3EFA01997C89EB71) #5
  %3527 = tail call double @llvm.fma.f64(double %3526, double %3523, double 0x3F2A01A014761F65) #5
  %3528 = tail call double @llvm.fma.f64(double %3527, double %3523, double 0x3F56C16C1852B7AF) #5
  %3529 = tail call double @llvm.fma.f64(double %3528, double %3523, double 0x3F81111111122322) #5
  %3530 = tail call double @llvm.fma.f64(double %3529, double %3523, double 0x3FA55555555502A1) #5
  %3531 = tail call double @llvm.fma.f64(double %3530, double %3523, double 0x3FC5555555555511) #5
  %3532 = tail call double @llvm.fma.f64(double %3531, double %3523, double 0x3FE000000000000B) #5
  %3533 = tail call double @llvm.fma.f64(double %3532, double %3523, double 1.000000e+00) #5
  %3534 = tail call double @llvm.fma.f64(double %3533, double %3523, double 1.000000e+00) #5
  %3535 = tail call i32 @llvm.nvvm.d2i.lo(double %3534) #5
  %3536 = tail call i32 @llvm.nvvm.d2i.hi(double %3534) #5
  %3537 = shl i32 %3520, 20
  %3538 = add i32 %3536, %3537
  %3539 = tail call double @llvm.nvvm.lohi.i2d(i32 %3535, i32 %3538) #5
  %3540 = tail call i32 @llvm.nvvm.d2i.hi(double %3518) #5
  %3541 = bitcast i32 %3540 to float
  %3542 = tail call float @llvm.fabs.f32(float %3541) #5
  %3543 = fcmp olt float %3542, 0x4010C46560000000
  br i1 %3543, label %__internal_accurate_pow.exit2, label %3544

3544:                                             ; preds = %3441
  %3545 = fcmp olt double %3518, 0.000000e+00
  %3546 = fadd double %3518, 0x7FF0000000000000
  %3547 = select i1 %3545, double 0.000000e+00, double %3546
  %3548 = fcmp olt float %3542, 0x4010E90000000000
  br i1 %3548, label %3549, label %__internal_accurate_pow.exit2

3549:                                             ; preds = %3544
  %3550 = sdiv i32 %3520, 2
  %3551 = shl i32 %3550, 20
  %3552 = add i32 %3536, %3551
  %3553 = tail call double @llvm.nvvm.lohi.i2d(i32 %3535, i32 %3552) #5
  %3554 = sub nsw i32 %3520, %3550
  %3555 = shl i32 %3554, 20
  %3556 = add nsw i32 %3555, 1072693248
  %3557 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %3556) #5
  %3558 = fmul double %3553, %3557
  br label %__internal_accurate_pow.exit2

__internal_accurate_pow.exit2:                    ; preds = %3549, %3544, %3441
  %3559 = phi double [ %3539, %3441 ], [ %3547, %3544 ], [ %3558, %3549 ]
  %3560 = fsub double %3514, %3518
  %3561 = fadd double %3517, %3560
  %3562 = tail call i32 @llvm.nvvm.d2i.lo(double %3559) #5
  %3563 = tail call i32 @llvm.nvvm.d2i.hi(double %3559) #5
  %3564 = and i32 %3563, 2147483647
  %3565 = icmp eq i32 %3564, 2146435072
  %3566 = icmp eq i32 %3562, 0
  %3567 = and i1 %3566, %3565
  %3568 = tail call double @llvm.fma.f64(double %3559, double %3561, double %3559) #5
  %3569 = select i1 %3567, double %3559, double %3568
  %3570 = icmp slt i32 %3414, 0
  br i1 %3570, label %3571, label %3576

3571:                                             ; preds = %__internal_accurate_pow.exit2
  %3572 = tail call i32 @llvm.nvvm.d2i.hi(double %3569) #5
  %3573 = tail call i32 @llvm.nvvm.d2i.lo(double %3569) #5
  %3574 = xor i32 %3572, -2147483648
  %3575 = tail call double @llvm.nvvm.lohi.i2d(i32 %3573, i32 %3574) #5
  br label %3576

3576:                                             ; preds = %3571, %__internal_accurate_pow.exit2
  %3577 = phi double [ %3569, %__internal_accurate_pow.exit2 ], [ %3575, %3571 ]
  %3578 = fcmp oeq double %3413, 0.000000e+00
  br i1 %3578, label %3579, label %3581

3579:                                             ; preds = %3576
  %3580 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %3414) #5
  br label %3581

3581:                                             ; preds = %3579, %3576
  %3582 = phi double [ %3577, %3576 ], [ %3580, %3579 ]
  %3583 = fadd double %3413, 2.000000e+00
  %3584 = tail call i32 @llvm.nvvm.d2i.hi(double %3583) #5
  %3585 = and i32 %3584, 2146435072
  %3586 = icmp eq i32 %3585, 2146435072
  br i1 %3586, label %3587, label %3606

3587:                                             ; preds = %3581
  %3588 = fcmp ugt double %3415, 0x7FF0000000000000
  br i1 %3588, label %3606, label %3589

3589:                                             ; preds = %3587
  br i1 %2902, label %3600, label %3590

3590:                                             ; preds = %3589
  %3591 = tail call i32 @llvm.nvvm.d2i.lo(double %3413) #5
  %3592 = and i32 %3414, 2147483647
  %3593 = icmp eq i32 %3592, 2146435072
  %3594 = icmp eq i32 %3591, 0
  %3595 = and i1 %3593, %3594
  br i1 %3595, label %3596, label %3606

3596:                                             ; preds = %3590
  %3597 = and i1 %2893, %3570
  %3598 = select i1 %3597, i32 %2894, i32 %2892
  %3599 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %3598) #5
  br label %3606

3600:                                             ; preds = %3589
  %3601 = fcmp ogt double %3415, 1.000000e+00
  %3602 = select i1 %3601, i32 2146435072, i32 0
  %3603 = fcmp oeq double %3413, -1.000000e+00
  %3604 = select i1 %3603, i32 1072693248, i32 %3602
  %3605 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %3604) #5
  br label %3606

3606:                                             ; preds = %3600, %3596, %3590, %3587, %3581
  %3607 = phi double [ %3582, %3581 ], [ %3583, %3587 ], [ %3582, %3590 ], [ %3599, %3596 ], [ %3605, %3600 ]
  %3608 = fcmp oeq double %3413, 1.000000e+00
  %3609 = select i1 %3608, double 1.000000e+00, double %3607
  %3610 = fsub double %3383, %3609
  %3611 = tail call double @llvm.fabs.f64(double %3610) #5
  %3612 = tail call double @llvm.fabs.f64(double %3383) #5
  %3613 = fmul double %3612, 1.000000e-04
  %3614 = fcmp ole double %3611, %3613
  %3615 = icmp ugt i32 %3384, 9
  %3616 = or i1 %3615, %3614
  %3617 = add nuw nsw i32 %3384, 1
  br i1 %3616, label %.loopexit, label %.preheader.split

.split76:                                         ; preds = %3824, %3146
  %3618 = phi double [ %2617, %3146 ], [ %3827, %3824 ]
  %3619 = phi i32 [ 0, %3146 ], [ %3835, %3824 ]
  %3620 = fdiv double 1.000000e+00, %3618
  %3621 = fadd double %2884, %3620
  %3622 = fmul double %2608, %3621
  %3623 = tail call double @llvm.sqrt.f64(double %3622) #5
  %3624 = fadd double %2885, %3620
  %3625 = fmul double %2608, %3624
  %3626 = tail call double @llvm.sqrt.f64(double %3625) #5
  %3627 = fsub double %3618, %2595
  %3628 = fmul double %3627, %3623
  %3629 = fadd double %2618, %3628
  %3630 = fsub double %3618, %2596
  %3631 = fmul double %3630, %3626
  %3632 = fadd double %3631, %3629
  %3633 = fmul double %129, %3627
  %3634 = fmul double %3618, %3618
  %3635 = fmul double %3634, 4.000000e+00
  %3636 = fmul double %3635, %3623
  %3637 = fdiv double %3633, %3636
  %3638 = fsub double %3623, %3637
  %3639 = fadd double %3626, %3638
  %3640 = fmul double %129, %3630
  %3641 = fmul double %3635, %3626
  %3642 = fdiv double %3640, %3641
  %3643 = fsub double %3639, %3642
  %3644 = tail call double @llvm.sqrt.f64(double %3618) #5
  %3645 = fmul double %3644, 2.000000e+00
  %3646 = fmul double %3645, %3643
  %3647 = fdiv double %3632, %3646
  %3648 = fsub double %3644, %3647
  %3649 = tail call i32 @llvm.nvvm.d2i.hi(double %3648) #5
  %3650 = tail call double @llvm.fabs.f64(double %3648) #5
  %3651 = tail call i32 @llvm.nvvm.d2i.hi(double %3650) #5
  %3652 = tail call i32 @llvm.nvvm.d2i.lo(double %3650) #5
  %3653 = lshr i32 %3651, 20
  %3654 = icmp eq i32 %3653, 0
  %3655 = fmul double %3650, 0x4350000000000000
  br i1 %3654, label %3656, label %3661

3656:                                             ; preds = %.split76
  %3657 = tail call i32 @llvm.nvvm.d2i.hi(double %3655) #5
  %3658 = tail call i32 @llvm.nvvm.d2i.lo(double %3655) #5
  %3659 = lshr i32 %3657, 20
  %3660 = add nsw i32 %3659, -54
  br label %3661

3661:                                             ; preds = %3656, %.split76
  %3662 = phi i32 [ %3652, %.split76 ], [ %3658, %3656 ]
  %3663 = phi i32 [ %3651, %.split76 ], [ %3657, %3656 ]
  %3664 = phi i32 [ %3653, %.split76 ], [ %3660, %3656 ]
  %3665 = add nsw i32 %3664, -1023
  %3666 = and i32 %3663, -2146435073
  %3667 = or i32 %3666, 1072693248
  %3668 = tail call double @llvm.nvvm.lohi.i2d(i32 %3662, i32 %3667) #5
  %3669 = icmp ugt i32 %3667, 1073127582
  br i1 %3669, label %3670, label %3676

3670:                                             ; preds = %3661
  %3671 = add nsw i32 %3664, -1022
  %3672 = tail call i32 @llvm.nvvm.d2i.lo(double %3668) #5
  %3673 = tail call i32 @llvm.nvvm.d2i.hi(double %3668) #5
  %3674 = add i32 %3673, -1048576
  %3675 = tail call double @llvm.nvvm.lohi.i2d(i32 %3672, i32 %3674) #5
  br label %3676

3676:                                             ; preds = %3670, %3661
  %3677 = phi double [ %3668, %3661 ], [ %3675, %3670 ]
  %3678 = phi i32 [ %3665, %3661 ], [ %3671, %3670 ]
  %3679 = fadd double %3677, -1.000000e+00
  %3680 = fadd double %3677, 1.000000e+00
  %3681 = tail call double @llvm.nvvm.rcp.approx.ftz.d(double %3680) #5
  %3682 = fneg double %3680
  %3683 = tail call double @llvm.fma.f64(double %3682, double %3681, double 1.000000e+00) #5
  %3684 = tail call double @llvm.fma.f64(double %3683, double %3683, double %3683) #5
  %3685 = tail call double @llvm.fma.f64(double %3684, double %3681, double %3681) #5
  %3686 = fmul double %3679, %3685
  %3687 = fadd double %3686, %3686
  %3688 = fmul double %3687, %3687
  %3689 = tail call double @llvm.fma.f64(double %3688, double 0x3EB0F5FF7D2CAFE2, double 0x3ED0F5D241AD3B5A) #5
  %3690 = tail call double @llvm.fma.f64(double %3689, double %3688, double 0x3EF3B20A75488A3F) #5
  %3691 = tail call double @llvm.fma.f64(double %3690, double %3688, double 0x3F1745CDE4FAECD5) #5
  %3692 = tail call double @llvm.fma.f64(double %3691, double %3688, double 0x3F3C71C7258A578B) #5
  %3693 = tail call double @llvm.fma.f64(double %3692, double %3688, double 0x3F6249249242B910) #5
  %3694 = tail call double @llvm.fma.f64(double %3693, double %3688, double 0x3F89999999999DFB) #5
  %3695 = fmul double %3688, %3694
  %3696 = fsub double %3679, %3687
  %3697 = fmul double %3696, 2.000000e+00
  %3698 = fneg double %3687
  %3699 = tail call double @llvm.fma.f64(double %3698, double %3679, double %3697) #5
  %3700 = fmul double %3685, %3699
  %3701 = fadd double %3695, 0x3FB5555555555555
  %3702 = fsub double 0x3FB5555555555555, %3701
  %3703 = fadd double %3695, %3702
  %3704 = fadd double %3703, 0.000000e+00
  %3705 = fadd double %3704, 0xBC46A4CB00B9E7B0
  %3706 = fadd double %3701, %3705
  %3707 = fsub double %3701, %3706
  %3708 = fadd double %3705, %3707
  %3709 = fneg double %3688
  %3710 = tail call double @llvm.fma.f64(double %3687, double %3687, double %3709) #5
  %3711 = tail call i32 @llvm.nvvm.d2i.lo(double %3700) #5
  %3712 = tail call i32 @llvm.nvvm.d2i.hi(double %3700) #5
  %3713 = add i32 %3712, 1048576
  %3714 = tail call double @llvm.nvvm.lohi.i2d(i32 %3711, i32 %3713) #5
  %3715 = tail call double @llvm.fma.f64(double %3687, double %3714, double %3710) #5
  %3716 = fmul double %3687, %3688
  %3717 = fneg double %3716
  %3718 = tail call double @llvm.fma.f64(double %3688, double %3687, double %3717) #5
  %3719 = tail call double @llvm.fma.f64(double %3688, double %3700, double %3718) #5
  %3720 = tail call double @llvm.fma.f64(double %3715, double %3687, double %3719) #5
  %3721 = fmul double %3716, %3706
  %3722 = fneg double %3721
  %3723 = tail call double @llvm.fma.f64(double %3706, double %3716, double %3722) #5
  %3724 = tail call double @llvm.fma.f64(double %3706, double %3720, double %3723) #5
  %3725 = tail call double @llvm.fma.f64(double %3708, double %3716, double %3724) #5
  %3726 = fadd double %3721, %3725
  %3727 = fsub double %3721, %3726
  %3728 = fadd double %3725, %3727
  %3729 = fadd double %3687, %3726
  %3730 = fsub double %3687, %3729
  %3731 = fadd double %3726, %3730
  %3732 = fadd double %3728, %3731
  %3733 = fadd double %3700, %3732
  %3734 = fadd double %3729, %3733
  %3735 = fsub double %3729, %3734
  %3736 = fadd double %3733, %3735
  %3737 = xor i32 %3678, -2147483648
  %3738 = tail call double @llvm.nvvm.lohi.i2d(i32 %3737, i32 1127219200) #5
  %3739 = fsub double %3738, %3148
  %3740 = tail call double @llvm.fma.f64(double %3739, double 0x3FE62E42FEFA39EF, double %3734) #5
  %3741 = fneg double %3739
  %3742 = tail call double @llvm.fma.f64(double %3741, double 0x3FE62E42FEFA39EF, double %3740) #5
  %3743 = fsub double %3742, %3734
  %3744 = fsub double %3736, %3743
  %3745 = tail call double @llvm.fma.f64(double %3739, double 0x3C7ABC9E3B39803F, double %3744) #5
  %3746 = fadd double %3740, %3745
  %3747 = fsub double %3740, %3746
  %3748 = fadd double %3745, %3747
  %3749 = fmul double %3154, %3746
  %3750 = fneg double %3749
  %3751 = tail call double @llvm.fma.f64(double %3746, double %3154, double %3750) #5
  %3752 = tail call double @llvm.fma.f64(double %3748, double %3154, double %3751) #5
  %3753 = fadd double %3749, %3752
  %3754 = tail call double @llvm.fma.f64(double %3753, double 0x3FF71547652B82FE, double 0x4338000000000000) #5
  %3755 = tail call i32 @llvm.nvvm.d2i.lo(double %3754) #5
  %3756 = fadd double %3754, 0xC338000000000000
  %3757 = tail call double @llvm.fma.f64(double %3756, double 0xBFE62E42FEFA39EF, double %3753) #5
  %3758 = tail call double @llvm.fma.f64(double %3756, double 0xBC7ABC9E3B39803F, double %3757) #5
  %3759 = tail call double @llvm.fma.f64(double %3758, double 0x3E5ADE1569CE2BDF, double 0x3E928AF3FCA213EA) #5
  %3760 = tail call double @llvm.fma.f64(double %3759, double %3758, double 0x3EC71DEE62401315) #5
  %3761 = tail call double @llvm.fma.f64(double %3760, double %3758, double 0x3EFA01997C89EB71) #5
  %3762 = tail call double @llvm.fma.f64(double %3761, double %3758, double 0x3F2A01A014761F65) #5
  %3763 = tail call double @llvm.fma.f64(double %3762, double %3758, double 0x3F56C16C1852B7AF) #5
  %3764 = tail call double @llvm.fma.f64(double %3763, double %3758, double 0x3F81111111122322) #5
  %3765 = tail call double @llvm.fma.f64(double %3764, double %3758, double 0x3FA55555555502A1) #5
  %3766 = tail call double @llvm.fma.f64(double %3765, double %3758, double 0x3FC5555555555511) #5
  %3767 = tail call double @llvm.fma.f64(double %3766, double %3758, double 0x3FE000000000000B) #5
  %3768 = tail call double @llvm.fma.f64(double %3767, double %3758, double 1.000000e+00) #5
  %3769 = tail call double @llvm.fma.f64(double %3768, double %3758, double 1.000000e+00) #5
  %3770 = tail call i32 @llvm.nvvm.d2i.lo(double %3769) #5
  %3771 = tail call i32 @llvm.nvvm.d2i.hi(double %3769) #5
  %3772 = shl i32 %3755, 20
  %3773 = add i32 %3771, %3772
  %3774 = tail call double @llvm.nvvm.lohi.i2d(i32 %3770, i32 %3773) #5
  %3775 = tail call i32 @llvm.nvvm.d2i.hi(double %3753) #5
  %3776 = bitcast i32 %3775 to float
  %3777 = tail call float @llvm.fabs.f32(float %3776) #5
  %3778 = fcmp olt float %3777, 0x4010C46560000000
  br i1 %3778, label %__internal_accurate_pow.exit1, label %3779

3779:                                             ; preds = %3676
  %3780 = fcmp olt double %3753, 0.000000e+00
  %3781 = fadd double %3753, 0x7FF0000000000000
  %3782 = select i1 %3780, double 0.000000e+00, double %3781
  %3783 = fcmp olt float %3777, 0x4010E90000000000
  br i1 %3783, label %3784, label %__internal_accurate_pow.exit1

3784:                                             ; preds = %3779
  %3785 = sdiv i32 %3755, 2
  %3786 = shl i32 %3785, 20
  %3787 = add i32 %3771, %3786
  %3788 = tail call double @llvm.nvvm.lohi.i2d(i32 %3770, i32 %3787) #5
  %3789 = sub nsw i32 %3755, %3785
  %3790 = shl i32 %3789, 20
  %3791 = add nsw i32 %3790, 1072693248
  %3792 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %3791) #5
  %3793 = fmul double %3788, %3792
  br label %__internal_accurate_pow.exit1

__internal_accurate_pow.exit1:                    ; preds = %3784, %3779, %3676
  %3794 = phi double [ %3774, %3676 ], [ %3782, %3779 ], [ %3793, %3784 ]
  %3795 = fsub double %3749, %3753
  %3796 = fadd double %3752, %3795
  %3797 = tail call i32 @llvm.nvvm.d2i.lo(double %3794) #5
  %3798 = tail call i32 @llvm.nvvm.d2i.hi(double %3794) #5
  %3799 = and i32 %3798, 2147483647
  %3800 = icmp eq i32 %3799, 2146435072
  %3801 = icmp eq i32 %3797, 0
  %3802 = and i1 %3801, %3800
  %3803 = tail call double @llvm.fma.f64(double %3794, double %3796, double %3794) #5
  %3804 = select i1 %3802, double %3794, double %3803
  %3805 = fcmp oeq double %3648, 0.000000e+00
  br i1 %3805, label %3806, label %3808

3806:                                             ; preds = %__internal_accurate_pow.exit1
  %3807 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %3147) #5
  br label %3808

3808:                                             ; preds = %3806, %__internal_accurate_pow.exit1
  %3809 = phi double [ %3804, %__internal_accurate_pow.exit1 ], [ %3807, %3806 ]
  %3810 = fadd double %3648, 2.000000e+00
  %3811 = tail call i32 @llvm.nvvm.d2i.hi(double %3810) #5
  %3812 = and i32 %3811, 2146435072
  %3813 = icmp eq i32 %3812, 2146435072
  br i1 %3813, label %3814, label %3824

3814:                                             ; preds = %3808
  %3815 = fcmp ugt double %3650, 0x7FF0000000000000
  br i1 %3815, label %3824, label %3816

3816:                                             ; preds = %3814
  %3817 = tail call i32 @llvm.nvvm.d2i.lo(double %3648) #5
  %3818 = and i32 %3649, 2147483647
  %3819 = icmp eq i32 %3818, 2146435072
  %3820 = icmp eq i32 %3817, 0
  %3821 = and i1 %3819, %3820
  br i1 %3821, label %3822, label %3824

3822:                                             ; preds = %3816
  %3823 = tail call double @llvm.nvvm.lohi.i2d(i32 0, i32 %2892) #5
  br label %3824

3824:                                             ; preds = %3822, %3816, %3814, %3808
  %3825 = phi double [ %3809, %3808 ], [ %3810, %3814 ], [ %3809, %3816 ], [ %3823, %3822 ]
  %3826 = fcmp oeq double %3648, 1.000000e+00
  %3827 = select i1 %3826, double 1.000000e+00, double %3825
  %3828 = fsub double %3618, %3827
  %3829 = tail call double @llvm.fabs.f64(double %3828) #5
  %3830 = tail call double @llvm.fabs.f64(double %3618) #5
  %3831 = fmul double %3830, 1.000000e-04
  %3832 = fcmp ole double %3829, %3831
  %3833 = icmp ugt i32 %3619, 9
  %3834 = or i1 %3833, %3832
  %3835 = add nuw nsw i32 %3619, 1
  br i1 %3834, label %.loopexit, label %.split76

.loopexit:                                        ; preds = %3824, %3606, %3371, %3134
  %3836 = phi double [ %2910, %3134 ], [ %3156, %3371 ], [ %3383, %3606 ], [ %3618, %3824 ]
  %3837 = phi double [ %2920, %3134 ], [ %3166, %3371 ], [ %3393, %3606 ], [ %3628, %3824 ]
  %3838 = phi double [ %2923, %3134 ], [ %3169, %3371 ], [ %3396, %3606 ], [ %3631, %3824 ]
  %3839 = fsub double %2591, %3837
  %3840 = fadd double %2592, %3838
  %3841 = fmul double %129, %3836
  %3842 = tail call double @llvm.sqrt.f64(double %3841) #5
  %3843 = fsub double %3839, %3842
  %3844 = fadd double %3842, %3840
  br label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit2.i

3845:                                             ; preds = %3845, %2881
  %3846 = phi double [ %2616, %2881 ], [ %3863, %3845 ]
  %3847 = phi i32 [ 0, %2881 ], [ %3871, %3845 ]
  %3848 = fmul double %129, %3846
  %3849 = tail call double @llvm.sqrt.f64(double %3848) #5
  %3850 = fsub double %3849, %2630
  %3851 = fmul double %3850, 2.000000e+00
  %3852 = fadd double %2618, %3851
  %3853 = fsub double %3846, %2616
  %3854 = fdiv double 1.000000e+00, %3846
  %3855 = fadd double %2882, %3854
  %3856 = fmul double %2608, %3855
  %3857 = tail call double @llvm.sqrt.f64(double %3856) #5
  %3858 = fmul double %3853, %3857
  %3859 = fadd double %3852, %3858
  %3860 = fsub double %2641, %3859
  %3861 = fdiv double %3860, %2634
  %3862 = fdiv double %3859, %3861
  %3863 = fsub double %3846, %3862
  %3864 = fsub double %3846, %3863
  %3865 = tail call double @llvm.fabs.f64(double %3864) #5
  %3866 = tail call double @llvm.fabs.f64(double %3846) #5
  %3867 = fmul double %3866, 1.000000e-04
  %3868 = fcmp ole double %3865, %3867
  %3869 = icmp ugt i32 %3847, 9
  %3870 = or i1 %3869, %3868
  %3871 = add nuw nsw i32 %3847, 1
  br i1 %3870, label %fusion.common, label %3845

fusion.common:                                    ; preds = %3845
  %3872 = fcmp ogt double %2595, %2596
  %3873 = select i1 %3872, double %2598, double %2601
  %3874 = fmul double %3873, 2.000000e+00
  %3875 = fsub double %2592, %3874
  %3876 = fmul double %3849, 3.000000e+00
  %3877 = fadd double %3875, %3876
  %3878 = select i1 %3872, double poison, double %3877
  %3879 = select i1 %3872, double %2591, double %3875
  %3880 = select i1 %3872, double %3874, double %3849
  %3881 = fadd double %3879, %3880
  br i1 %3872, label %fusion.side1, label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit2.i

fusion.side1:                                     ; preds = %fusion.common
  %3882 = fsub double %3881, %3876
  %3883 = fsub double %3881, %3849
  br label %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit2.i

_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit2.i: ; preds = %fusion.side1, %fusion.common, %.loopexit, %2865, %2620
  %3884 = phi double [ %2625, %2620 ], [ %2878, %2865 ], [ %3844, %.loopexit ], [ %3878, %fusion.common ], [ %3883, %fusion.side1 ]
  %3885 = phi double [ %2625, %2620 ], [ %2875, %2865 ], [ %3843, %.loopexit ], [ %3881, %fusion.common ], [ %3882, %fusion.side1 ]
  %3886 = tail call double @llvm.minnum.f64(double %2614, double %3884) #5
  %3887 = tail call double @llvm.maxnum.f64(double %2615, double %3885) #5
  %3888 = fsub double %2593, %2594
  %3889 = fmul double %2596, %3887
  %3890 = fadd double %3888, %3889
  %3891 = fmul double %2595, %3886
  %3892 = fsub double %3890, %3891
  %3893 = fsub double %3887, %3886
  %3894 = fdiv double %3892, %3893
  %3895 = fmul double %3886, %3886
  %3896 = fmul double %3887, %3887
  %3897 = fsub double %2594, %2593
  %3898 = fsub double %2589, %2590
  %3899 = tail call double @llvm.maxnum.f64(double %3894, double 0.000000e+00) #5
  %3900 = fmul double %2609, 5.000000e-01
  %3901 = tail call double @llvm.maxnum.f64(double %3900, double 0.000000e+00) #5
  %3902 = fadd double %2591, %2592
  %3903 = fmul double %3902, %3902
  %3904 = fmul double %3903, 2.500000e-01
  %3905 = fmul double %129, %3901
  %3906 = fsub double %3904, %3905
  %3907 = fmul double %2591, %2592
  %3908 = tail call double @llvm.maxnum.f64(double %3907, double 0.000000e+00) #5
  %3909 = fsub double %3908, %3905
  %3910 = tail call double @llvm.fabs.f64(double %3906) #5
  %3911 = fcmp olt double %3910, 0x3EB0C6F7A0B5ED8D
  %3912 = fmul double %3906, %3909
  %3913 = fcmp olt double %3912, 0x3EB0C6F7A0B5ED8D
  %3914 = or i1 %3913, %3911
  %3915 = fmul double %3906, %3886
  %3916 = fmul double %3915, %3887
  %3917 = fcmp olt double %3916, 0x3EB0C6F7A0B5ED8D
  %3918 = or i1 %3914, %3917
  %3919 = tail call double @llvm.fabs.f64(double %3886) #5
  %3920 = tail call double @llvm.fabs.f64(double %3887) #5
  %3921 = tail call double @llvm.minnum.f64(double %3919, double %3920) #5
  %3922 = fcmp olt double %3921, 0x3EB0C6F7A0B5ED8D
  %3923 = or i1 %3922, %3918
  %3924 = fcmp olt double %3886, 0.000000e+00
  %3925 = fcmp ogt double %3885, 0.000000e+00
  %3926 = and i1 %3924, %3925
  %3927 = or i1 %3926, %3923
  %3928 = fcmp ogt double %3887, 0.000000e+00
  %3929 = fcmp olt double %3884, 0.000000e+00
  %3930 = and i1 %3929, %3928
  %3931 = or i1 %3930, %3927
  %3932 = fadd double %2591, %2598
  %3933 = fmul double %3932, %2602
  %3934 = fcmp olt double %3933, 0.000000e+00
  %3935 = or i1 %3934, %3931
  %3936 = fsub double %2592, %2601
  %3937 = fmul double %2599, %3936
  %3938 = fcmp olt double %3937, 0.000000e+00
  %3939 = or i1 %3938, %3935
  %3940 = fneg double %3898
  %3941 = fmul double %129, %3898
  %3942 = fmul double %3941, %3901
  %3943 = fdiv double %3942, %3906
  %3944 = select i1 %3939, double %3940, double %3943
  %3945 = fcmp olt double %3886, 0xBEB0C6F7A0B5ED8D
  %3946 = fcmp ogt double %3887, 0x3EB0C6F7A0B5ED8D
  %3947 = and i1 %3945, %3946
  %3948 = fcmp oge double %3886, 0x3EB0C6F7A0B5ED8D
  %decision.take = or i1 %3947, %3948
  br i1 %decision.take, label %decision.dispatch, label %3956, !decision.condition_prefix !17

decision.dispatch:                                ; preds = %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit2.i
  %3949 = fmul double %3893, %3899
  %3950 = select i1 %3947, double %3887, double %3886
  %3951 = fdiv double %3949, %3950
  %3952 = tail call double @llvm.minnum.f64(double %3944, double %3951) #5
  %3953 = fdiv double %3949, %3886
  %3954 = fneg double %2595
  %fusion.paired = select i1 %3947, double %3953, double %3954
  %3955 = tail call double @llvm.maxnum.f64(double %3952, double %fusion.paired) #5
  br label %3963

3956:                                             ; preds = %_ZN2GC2fv17GeorgeRiemannTypeEddddddPdS1_S1_.exit2.i
  %3957 = fcmp ugt double %3887, 0xBEB0C6F7A0B5ED8D
  br i1 %3957, label %3963, label %3958

3958:                                             ; preds = %3956
  %3959 = tail call double @llvm.minnum.f64(double %3944, double %2596) #5
  %3960 = fmul double %3893, %3899
  %3961 = fdiv double %3960, %3887
  %3962 = tail call double @llvm.maxnum.f64(double %3959, double %3961) #5
  br label %3963

3963:                                             ; preds = %3958, %3956, %decision.dispatch
  %3964 = phi double [ %3955, %decision.dispatch ], [ %3944, %3956 ], [ %3962, %3958 ]
  %3965 = select i1 %3939, double %3901, double %129
  %.v = select i1 %3939, double %129, double %3898
  %3966 = fneg double %.v
  %3967 = fmul double %3965, %3966
  %3968 = fmul double %3898, %3967
  %3969 = fmul double %3967, %3901
  %3970 = fmul double %3969, %3909
  %3971 = fdiv double %3970, %3906
  %3972 = select i1 %3939, double %3968, double %3971
  %3973 = fadd double %3886, %3887
  %3974 = fmul double %3973, 5.000000e-01
  %3975 = fsub double %2587, %2588
  %3976 = fsub double %2596, %2595
  %3977 = fneg double %2595
  %3978 = fmul double %3898, %3977
  %3979 = fneg double %2596
  %3980 = fmul double %3898, %3979
  %3981 = tail call double @llvm.maxnum.f64(double %3978, double %3980) #5
  %3982 = fmul double %129, %3981
  %3983 = tail call double @llvm.minnum.f64(double %3972, double %3982) #5
  %3984 = tail call double @llvm.minnum.f64(double %3978, double %3980) #5
  %3985 = fmul double %129, %3984
  %3986 = tail call double @llvm.maxnum.f64(double %3983, double %3985) #5
  %3987 = fsub double %3976, %3964
  %3988 = fsub double %3975, %3986
  %3989 = fmul double %3896, 0.000000e+00
  %3990 = fsub double %3989, %3887
  %3991 = fmul double %3886, %3896
  %3992 = fmul double %3887, %3895
  %3993 = fsub double %3991, %3992
  %3994 = fmul double %3993, 0.000000e+00
  %3995 = fmul double %3895, 0.000000e+00
  %3996 = fsub double %3886, %3995
  %3997 = fsub double %3990, %3994
  %3998 = fadd double %3996, %3997
  %3999 = fmul double %3990, %3987
  %4000 = fmul double %3897, %3896
  %4001 = fmul double %3887, %3988
  %4002 = fsub double %4000, %4001
  %4003 = fmul double %4002, 0.000000e+00
  %4004 = fmul double %3988, 0.000000e+00
  %4005 = fsub double %3897, %4004
  %4006 = fsub double %3999, %4003
  %4007 = fadd double %4005, %4006
  %4008 = fdiv double %4007, %3998
  %4009 = fmul double %3993, %3987
  %4010 = fmul double %3886, %3988
  %4011 = fmul double %3897, %3895
  %4012 = fsub double %4010, %4011
  %4013 = fsub double %4002, %4009
  %4014 = fadd double %4012, %4013
  %4015 = fdiv double %4014, %3998
  %4016 = fsub double %4004, %3897
  %4017 = fmul double %4012, 0.000000e+00
  %4018 = fmul double %3996, %3987
  %4019 = fsub double %4016, %4017
  %4020 = fadd double %4018, %4019
  %4021 = fdiv double %4020, %3998
  %4022 = fmul double %3886, %4008
  %4023 = fmul double %3895, %4008
  %4024 = fmul double %4015, 0.000000e+00
  %4025 = fmul double %3887, %4021
  %4026 = fmul double %3896, %4021
  %4027 = fmul double %2586, %4022
  %4028 = fmul double %2585, %4025
  %4029 = fmul double %2592, %2596
  %4030 = fmul double %2585, %4029
  %4031 = fmul double %2591, %2595
  %4032 = fmul double %2586, %4031
  %4033 = fsub double %4030, %4032
  %4034 = fsub double %4033, %4027
  %4035 = fsub double %4034, %4028
  %4036 = fmul double %2584, %3886
  %4037 = fmul double %2584, %4022
  %4038 = fmul double %2584, %4023
  %4039 = fmul double %2584, %4027
  %4040 = fmul double %2583, %3974
  %4041 = fmul double %2583, %4024
  %4042 = fmul double %2583, %4015
  %4043 = fmul double %2583, %4035
  %4044 = fmul double %2582, %3887
  %4045 = fmul double %2582, %4025
  %4046 = fmul double %2582, %4026
  %4047 = fmul double %2582, %4028
  %4048 = fcmp olt double %4036, 0.000000e+00
  br i1 %4048, label %4049, label %4053

4049:                                             ; preds = %3963
  %4050 = fadd double %4037, 0.000000e+00
  %4051 = fadd double %4038, 0.000000e+00
  %4052 = fadd double %4039, 0.000000e+00
  br label %4062

4053:                                             ; preds = %3963
  %4054 = fcmp ogt double %4036, 0.000000e+00
  br i1 %4054, label %4062, label %4055

4055:                                             ; preds = %4053
  %4056 = fmul double %4037, 5.000000e-01
  %4057 = fadd double %4056, 0.000000e+00
  %4058 = fmul double %4038, 5.000000e-01
  %4059 = fadd double %4058, 0.000000e+00
  %4060 = fmul double %4039, 5.000000e-01
  %4061 = fadd double %4060, 0.000000e+00
  br label %4062

4062:                                             ; preds = %4055, %4053, %4049
  %4063 = phi double [ %4052, %4049 ], [ 0.000000e+00, %4053 ], [ %4061, %4055 ]
  %4064 = phi double [ %4051, %4049 ], [ 0.000000e+00, %4053 ], [ %4059, %4055 ]
  %4065 = phi double [ %4050, %4049 ], [ 0.000000e+00, %4053 ], [ %4057, %4055 ]
  %4066 = fcmp olt double %4040, 0.000000e+00
  br i1 %4066, label %4076, label %4067

4067:                                             ; preds = %4062
  %4068 = fcmp ogt double %4040, 0.000000e+00
  br i1 %4068, label %4080, label %4069

4069:                                             ; preds = %4067
  %4070 = fmul double %4041, 5.000000e-01
  %4071 = fadd double %4070, %4065
  %4072 = fmul double %4042, 5.000000e-01
  %4073 = fadd double %4072, %4064
  %4074 = fmul double %4043, 5.000000e-01
  %4075 = fadd double %4074, %4063
  br label %4080

4076:                                             ; preds = %4062
  %4077 = fadd double %4041, %4065
  %4078 = fadd double %4042, %4064
  %4079 = fadd double %4043, %4063
  br label %4080

4080:                                             ; preds = %4076, %4069, %4067
  %4081 = phi double [ %4063, %4067 ], [ %4075, %4069 ], [ %4079, %4076 ]
  %4082 = phi double [ %4064, %4067 ], [ %4073, %4069 ], [ %4078, %4076 ]
  %4083 = phi double [ %4065, %4067 ], [ %4071, %4069 ], [ %4077, %4076 ]
  %4084 = fcmp olt double %4044, 0.000000e+00
  br i1 %4084, label %4094, label %4085

4085:                                             ; preds = %4080
  %4086 = fcmp ogt double %4044, 0.000000e+00
  br i1 %4086, label %_ZN2GC2fv25cuGeorgeRiemannSolverSWEsEdRKNS0_12RiemannStateIdEERKNS1_INS_7Vector3EEES4_.exit, label %4087

4087:                                             ; preds = %4085
  %4088 = fmul double %4045, 5.000000e-01
  %4089 = fadd double %4088, %4083
  %4090 = fmul double %4046, 5.000000e-01
  %4091 = fadd double %4090, %4082
  %4092 = fmul double %4047, 5.000000e-01
  %4093 = fadd double %4092, %4081
  br label %_ZN2GC2fv25cuGeorgeRiemannSolverSWEsEdRKNS0_12RiemannStateIdEERKNS1_INS_7Vector3EEES4_.exit

4094:                                             ; preds = %4080
  %4095 = fadd double %4045, %4083
  %4096 = fadd double %4046, %4082
  %4097 = fadd double %4047, %4081
  br label %_ZN2GC2fv25cuGeorgeRiemannSolverSWEsEdRKNS0_12RiemannStateIdEERKNS1_INS_7Vector3EEES4_.exit

_ZN2GC2fv25cuGeorgeRiemannSolverSWEsEdRKNS0_12RiemannStateIdEERKNS1_INS_7Vector3EEES4_.exit: ; preds = %4094, %4087, %4085
  %4098 = phi double [ %4081, %4085 ], [ %4093, %4087 ], [ %4097, %4094 ]
  %4099 = phi double [ %4082, %4085 ], [ %4091, %4087 ], [ %4096, %4094 ]
  %4100 = phi double [ %4083, %4085 ], [ %4089, %4087 ], [ %4095, %4094 ]
  %4101 = fmul double %78, %4099
  %4102 = fmul double %80, %4099
  %4103 = fmul double %82, %4098
  %4104 = fmul double %84, %4098
  %4105 = fadd double %4103, %4101
  %4106 = fadd double %4104, %4102
  %4107 = fmul double %61, %4100
  %4108 = fdiv double %4107, %60
  %4109 = fadd double %72, %4108
  %4110 = fmul double %61, %4105
  %4111 = fmul double %61, %4106
  %4112 = fdiv double %4110, %60
  %4113 = fdiv double %4111, %60
  %4114 = fadd double %75, %4112
  %4115 = fadd double %74, %4113
  br label %4116

4116:                                             ; preds = %_ZN2GC2fv25cuGeorgeRiemannSolverSWEsEdRKNS0_12RiemannStateIdEERKNS1_INS_7Vector3EEES4_.exit, %97
  %4117 = phi double [ %75, %97 ], [ %4114, %_ZN2GC2fv25cuGeorgeRiemannSolverSWEsEdRKNS0_12RiemannStateIdEERKNS1_INS_7Vector3EEES4_.exit ]
  %4118 = phi double [ %74, %97 ], [ %4115, %_ZN2GC2fv25cuGeorgeRiemannSolverSWEsEdRKNS0_12RiemannStateIdEERKNS1_INS_7Vector3EEES4_.exit ]
  %4119 = phi double [ %72, %97 ], [ %4109, %_ZN2GC2fv25cuGeorgeRiemannSolverSWEsEdRKNS0_12RiemannStateIdEERKNS1_INS_7Vector3EEES4_.exit ]
  %4120 = add nuw nsw i32 %73, 1
  %4121 = icmp eq i32 %4120, 4
  br i1 %4121, label %63, label %71, !llvm.loop !18

.loopexit59:                                      ; preds = %63, %13
  call void @llvm.lifetime.end.p0i8(i64 64, i8* nonnull %22) #5
  call void @llvm.lifetime.end.p0i8(i64 64, i8* nonnull %18) #5
  ret void
}

; Function Attrs: convergent nounwind
declare void @llvm.nvvm.barrier0() #2

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #3

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #3

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.tid.x() #3

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.nctaid.x() #3

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.d2i.hi(double) #3

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.d2i.lo(double) #3

; Function Attrs: nounwind readnone
declare double @llvm.nvvm.lohi.i2d(i32, i32) #3

; Function Attrs: nounwind readnone
declare double @llvm.nvvm.rcp.approx.ftz.d(double) #3

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #4

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.minnum.f64(double, double) #4

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.maxnum.f64(double, double) #4

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.sqrt.f64(double) #4

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #4

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.fabs.f32(float) #4

attributes #0 = { argmemonly nofree nosync nounwind willreturn }
attributes #1 = { convergent norecurse nounwind "disable-tail-calls"="false" "frame-pointer"="all" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="sm_70" "target-features"="+ptx32,+sm_70" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #2 = { convergent nounwind }
attributes #3 = { nounwind readnone }
attributes #4 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #5 = { nounwind }

!nvvm.annotations = !{!0}
!llvm.module.flags = !{!1, !2}
!llvm.ident = !{!3, !4}

!0 = !{void (double*, double*, double*, double*, double*, %"struct.GC::Vector2.50.53"*, %"struct.GC::Vector2.50.53"*, i32, %"class.GC::ShortDualHandle.48.51"*, i32, double*, double*, %"struct.GC::Vector2.50.53"*)* @_ZN2GC2fv36cuAdvectionSWEsGeorgeCartesianKernelEPdS1_S1_S1_S1_PNS_7Vector2ES3_jPNS_15ShortDualHandleEjS1_S1_S3_, !"kernel", i32 1}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 4, !"nvvm-reflect-ftz", i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 3.8.0 (tags/RELEASE_380/final)"}
!5 = !{i32 0, i32 2147483647}
!6 = !{i32 0, i32 1024}
!7 = !{i32 1, i32 1025}
!8 = !{i64 0, i64 8, !9, i64 8, i64 8, !9}
!9 = !{!10, !10, i64 0}
!10 = !{!"double", !11, i64 0}
!11 = !{!"omnipotent char", !12, i64 0}
!12 = !{!"Simple C++ TBAA"}
!13 = !{i64 0, i64 8, !9}
!14 = !{i32 1, i32 -2147483648}
!15 = distinct !{!15, !16}
!16 = !{!"llvm.loop.mustprogress"}
!17 = !{}
!18 = distinct !{!18, !16}
