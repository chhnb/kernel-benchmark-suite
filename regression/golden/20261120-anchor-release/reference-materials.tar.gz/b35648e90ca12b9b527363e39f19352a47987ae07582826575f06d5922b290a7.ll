; ModuleID = '/data/home/chh/simplify-v2/build/simplify-fingerprint/active/PCM32/trial-29/fused.ll'
source_filename = "/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-benchmarks/benchmarks/PCM/pcm.hip.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockDim>::X" = type { i8 }

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockDimE1xE = comdat any

@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockDimE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockDim>::X" undef, comdat, align 1
@_ZZ3pcmPiE2sR = internal unnamed_addr addrspace(3) global [8192 x i32] undef, align 16
@_ZZ3pcmPiE2sC = internal unnamed_addr addrspace(3) global [8192 x i32] undef, align 16

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z3pcmPi(i32 addrspace(1)* nocapture %0) local_unnamed_addr #0 {
fusion.common:
  %1 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %2 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %3 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %4 = getelementptr i8, i8 addrspace(4)* %3, i64 4
  %5 = bitcast i8 addrspace(4)* %4 to i16 addrspace(4)*
  %6 = load i16, i16 addrspace(4)* %5, align 4, !range !6, !invariant.load !7
  %7 = zext i16 %6 to i32
  %8 = mul i32 %2, %7
  %9 = add i32 %8, %1
  %10 = icmp slt i32 %9, 268435456
  %11 = shl nsw i32 %9, 8
  %12 = select i1 %10, i32 %11, i32 poison
  %13 = shl nuw nsw i32 %1, 8
  br i1 %10, label %14, label %129

14:                                               ; preds = %14, %fusion.common
  %15 = phi i32 [ 0, %fusion.common ], [ %127, %14 ]
  %16 = add nuw nsw i32 %15, %12
  %17 = sext i32 %16 to i64
  %18 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %17
  %19 = load i32, i32 addrspace(1)* %18, align 4, !tbaa !8
  %20 = add nuw nsw i32 %15, %13
  %21 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %20
  store i32 %19, i32 addrspace(3)* %21, align 16, !tbaa !8
  %22 = or i32 %15, 1
  %23 = add nuw nsw i32 %22, %12
  %24 = sext i32 %23 to i64
  %25 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %24
  %26 = load i32, i32 addrspace(1)* %25, align 4, !tbaa !8
  %27 = add nuw nsw i32 %22, %13
  %28 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %27
  store i32 %26, i32 addrspace(3)* %28, align 4, !tbaa !8
  %29 = or i32 %15, 2
  %30 = add nuw nsw i32 %29, %12
  %31 = sext i32 %30 to i64
  %32 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %31
  %33 = load i32, i32 addrspace(1)* %32, align 4, !tbaa !8
  %34 = add nuw nsw i32 %29, %13
  %35 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %34
  store i32 %33, i32 addrspace(3)* %35, align 8, !tbaa !8
  %36 = or i32 %15, 3
  %37 = add nuw nsw i32 %36, %12
  %38 = sext i32 %37 to i64
  %39 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %38
  %40 = load i32, i32 addrspace(1)* %39, align 4, !tbaa !8
  %41 = add nuw nsw i32 %36, %13
  %42 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %41
  store i32 %40, i32 addrspace(3)* %42, align 4, !tbaa !8
  %43 = or i32 %15, 4
  %44 = add nuw nsw i32 %43, %12
  %45 = sext i32 %44 to i64
  %46 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %45
  %47 = load i32, i32 addrspace(1)* %46, align 4, !tbaa !8
  %48 = add nuw nsw i32 %43, %13
  %49 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %48
  store i32 %47, i32 addrspace(3)* %49, align 16, !tbaa !8
  %50 = or i32 %15, 5
  %51 = add nuw nsw i32 %50, %12
  %52 = sext i32 %51 to i64
  %53 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %52
  %54 = load i32, i32 addrspace(1)* %53, align 4, !tbaa !8
  %55 = add nuw nsw i32 %50, %13
  %56 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %55
  store i32 %54, i32 addrspace(3)* %56, align 4, !tbaa !8
  %57 = or i32 %15, 6
  %58 = add nuw nsw i32 %57, %12
  %59 = sext i32 %58 to i64
  %60 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %59
  %61 = load i32, i32 addrspace(1)* %60, align 4, !tbaa !8
  %62 = add nuw nsw i32 %57, %13
  %63 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %62
  store i32 %61, i32 addrspace(3)* %63, align 8, !tbaa !8
  %64 = or i32 %15, 7
  %65 = add nuw nsw i32 %64, %12
  %66 = sext i32 %65 to i64
  %67 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %66
  %68 = load i32, i32 addrspace(1)* %67, align 4, !tbaa !8
  %69 = add nuw nsw i32 %64, %13
  %70 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %69
  store i32 %68, i32 addrspace(3)* %70, align 4, !tbaa !8
  %71 = or i32 %15, 8
  %72 = add nuw nsw i32 %71, %12
  %73 = sext i32 %72 to i64
  %74 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %73
  %75 = load i32, i32 addrspace(1)* %74, align 4, !tbaa !8
  %76 = add nuw nsw i32 %71, %13
  %77 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %76
  store i32 %75, i32 addrspace(3)* %77, align 16, !tbaa !8
  %78 = or i32 %15, 9
  %79 = add nuw nsw i32 %78, %12
  %80 = sext i32 %79 to i64
  %81 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %80
  %82 = load i32, i32 addrspace(1)* %81, align 4, !tbaa !8
  %83 = add nuw nsw i32 %78, %13
  %84 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %83
  store i32 %82, i32 addrspace(3)* %84, align 4, !tbaa !8
  %85 = or i32 %15, 10
  %86 = add nuw nsw i32 %85, %12
  %87 = sext i32 %86 to i64
  %88 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %87
  %89 = load i32, i32 addrspace(1)* %88, align 4, !tbaa !8
  %90 = add nuw nsw i32 %85, %13
  %91 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %90
  store i32 %89, i32 addrspace(3)* %91, align 8, !tbaa !8
  %92 = or i32 %15, 11
  %93 = add nuw nsw i32 %92, %12
  %94 = sext i32 %93 to i64
  %95 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %94
  %96 = load i32, i32 addrspace(1)* %95, align 4, !tbaa !8
  %97 = add nuw nsw i32 %92, %13
  %98 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %97
  store i32 %96, i32 addrspace(3)* %98, align 4, !tbaa !8
  %99 = or i32 %15, 12
  %100 = add nuw nsw i32 %99, %12
  %101 = sext i32 %100 to i64
  %102 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %101
  %103 = load i32, i32 addrspace(1)* %102, align 4, !tbaa !8
  %104 = add nuw nsw i32 %99, %13
  %105 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %104
  store i32 %103, i32 addrspace(3)* %105, align 16, !tbaa !8
  %106 = or i32 %15, 13
  %107 = add nuw nsw i32 %106, %12
  %108 = sext i32 %107 to i64
  %109 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %108
  %110 = load i32, i32 addrspace(1)* %109, align 4, !tbaa !8
  %111 = add nuw nsw i32 %106, %13
  %112 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %111
  store i32 %110, i32 addrspace(3)* %112, align 4, !tbaa !8
  %113 = or i32 %15, 14
  %114 = add nuw nsw i32 %113, %12
  %115 = sext i32 %114 to i64
  %116 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %115
  %117 = load i32, i32 addrspace(1)* %116, align 4, !tbaa !8
  %118 = add nuw nsw i32 %113, %13
  %119 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %118
  store i32 %117, i32 addrspace(3)* %119, align 8, !tbaa !8
  %120 = or i32 %15, 15
  %121 = add nuw nsw i32 %120, %12
  %122 = sext i32 %121 to i64
  %123 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %122
  %124 = load i32, i32 addrspace(1)* %123, align 4, !tbaa !8
  %125 = add nuw nsw i32 %120, %13
  %126 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %125
  store i32 %124, i32 addrspace(3)* %126, align 4, !tbaa !8
  %127 = add nuw nsw i32 %15, 16
  %128 = icmp eq i32 %127, 256
  br i1 %128, label %129, label %14, !llvm.loop !12

129:                                              ; preds = %14, %fusion.common
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %130 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sR, i32 0, i32 %13
  %131 = and i32 %1, 1
  %132 = icmp ne i32 %131, 0
  %133 = icmp ult i32 %1, 31
  %134 = xor i1 %132, true
  %135 = and i1 %133, %134
  %136 = add nsw i32 %13, -256
  %137 = add nuw nsw i32 %13, 256
  %138 = icmp ult i32 %1, 32
  %139 = and i1 %133, %132
  %140 = icmp eq i32 %1, 0
  br label %142

141:                                              ; preds = %816
  br i1 %10, label %819, label %934

142:                                              ; preds = %816, %129
  %143 = phi i32 [ 0, %129 ], [ %817, %816 ]
  br i1 %135, label %144, label %269

144:                                              ; preds = %144, %142
  %145 = phi i32 [ 0, %142 ], [ %267, %144 ]
  %146 = phi i32 [ 0, %142 ], [ %265, %144 ]
  %147 = phi i32 [ 0, %142 ], [ %263, %144 ]
  %148 = add nsw i32 %147, %13
  %149 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %148
  %150 = load i32, i32 addrspace(3)* %149, align 4, !tbaa !8
  %151 = add nsw i32 %137, %146
  %152 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %151
  %153 = load i32, i32 addrspace(3)* %152, align 4, !tbaa !8
  %154 = icmp sgt i32 %150, %153
  %155 = select i1 %154, i32 %153, i32 %150
  %156 = xor i1 %154, true
  %157 = zext i1 %156 to i32
  %158 = add nuw nsw i32 %147, %157
  %159 = zext i1 %154 to i32
  %160 = add nuw nsw i32 %146, %159
  %161 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %145
  store i32 %155, i32 addrspace(3)* %161, align 16
  %162 = or i32 %145, 1
  %163 = add nsw i32 %158, %13
  %164 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %163
  %165 = load i32, i32 addrspace(3)* %164, align 4, !tbaa !8
  %166 = add nsw i32 %137, %160
  %167 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %166
  %168 = load i32, i32 addrspace(3)* %167, align 4, !tbaa !8
  %169 = icmp sgt i32 %165, %168
  %170 = select i1 %169, i32 %168, i32 %165
  %171 = xor i1 %169, true
  %172 = zext i1 %171 to i32
  %173 = add nuw nsw i32 %158, %172
  %174 = zext i1 %169 to i32
  %175 = add nuw nsw i32 %160, %174
  %176 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %162
  store i32 %170, i32 addrspace(3)* %176, align 4
  %177 = or i32 %145, 2
  %178 = add nsw i32 %173, %13
  %179 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %178
  %180 = load i32, i32 addrspace(3)* %179, align 4, !tbaa !8
  %181 = add nsw i32 %137, %175
  %182 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %181
  %183 = load i32, i32 addrspace(3)* %182, align 4, !tbaa !8
  %184 = icmp sgt i32 %180, %183
  %185 = select i1 %184, i32 %183, i32 %180
  %186 = xor i1 %184, true
  %187 = zext i1 %186 to i32
  %188 = add nuw nsw i32 %173, %187
  %189 = zext i1 %184 to i32
  %190 = add nuw nsw i32 %175, %189
  %191 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %177
  store i32 %185, i32 addrspace(3)* %191, align 8
  %192 = or i32 %145, 3
  %193 = add nsw i32 %188, %13
  %194 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %193
  %195 = load i32, i32 addrspace(3)* %194, align 4, !tbaa !8
  %196 = add nsw i32 %137, %190
  %197 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %196
  %198 = load i32, i32 addrspace(3)* %197, align 4, !tbaa !8
  %199 = icmp sgt i32 %195, %198
  %200 = select i1 %199, i32 %198, i32 %195
  %201 = xor i1 %199, true
  %202 = zext i1 %201 to i32
  %203 = add nuw nsw i32 %188, %202
  %204 = zext i1 %199 to i32
  %205 = add nuw nsw i32 %190, %204
  %206 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %192
  store i32 %200, i32 addrspace(3)* %206, align 4
  %207 = or i32 %145, 4
  %208 = add nsw i32 %203, %13
  %209 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %208
  %210 = load i32, i32 addrspace(3)* %209, align 4, !tbaa !8
  %211 = add nsw i32 %137, %205
  %212 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %211
  %213 = load i32, i32 addrspace(3)* %212, align 4, !tbaa !8
  %214 = icmp sgt i32 %210, %213
  %215 = select i1 %214, i32 %213, i32 %210
  %216 = xor i1 %214, true
  %217 = zext i1 %216 to i32
  %218 = add nuw nsw i32 %203, %217
  %219 = zext i1 %214 to i32
  %220 = add nuw nsw i32 %205, %219
  %221 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %207
  store i32 %215, i32 addrspace(3)* %221, align 16
  %222 = or i32 %145, 5
  %223 = add nsw i32 %218, %13
  %224 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %223
  %225 = load i32, i32 addrspace(3)* %224, align 4, !tbaa !8
  %226 = add nsw i32 %137, %220
  %227 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %226
  %228 = load i32, i32 addrspace(3)* %227, align 4, !tbaa !8
  %229 = icmp sgt i32 %225, %228
  %230 = select i1 %229, i32 %228, i32 %225
  %231 = xor i1 %229, true
  %232 = zext i1 %231 to i32
  %233 = add nuw nsw i32 %218, %232
  %234 = zext i1 %229 to i32
  %235 = add nuw nsw i32 %220, %234
  %236 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %222
  store i32 %230, i32 addrspace(3)* %236, align 4
  %237 = or i32 %145, 6
  %238 = add nsw i32 %233, %13
  %239 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %238
  %240 = load i32, i32 addrspace(3)* %239, align 4, !tbaa !8
  %241 = add nsw i32 %137, %235
  %242 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %241
  %243 = load i32, i32 addrspace(3)* %242, align 4, !tbaa !8
  %244 = icmp sgt i32 %240, %243
  %245 = select i1 %244, i32 %243, i32 %240
  %246 = xor i1 %244, true
  %247 = zext i1 %246 to i32
  %248 = add nuw nsw i32 %233, %247
  %249 = zext i1 %244 to i32
  %250 = add nuw nsw i32 %235, %249
  %251 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %237
  store i32 %245, i32 addrspace(3)* %251, align 8
  %252 = or i32 %145, 7
  %253 = add nsw i32 %248, %13
  %254 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %253
  %255 = load i32, i32 addrspace(3)* %254, align 4, !tbaa !8
  %256 = add nsw i32 %137, %250
  %257 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %256
  %258 = load i32, i32 addrspace(3)* %257, align 4, !tbaa !8
  %259 = icmp sgt i32 %255, %258
  %260 = select i1 %259, i32 %258, i32 %255
  %261 = xor i1 %259, true
  %262 = zext i1 %261 to i32
  %263 = add nuw nsw i32 %248, %262
  %264 = zext i1 %259 to i32
  %265 = add nuw nsw i32 %250, %264
  %266 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %252
  store i32 %260, i32 addrspace(3)* %266, align 4
  %267 = add nuw nsw i32 %145, 8
  %268 = icmp eq i32 %267, 256
  br i1 %268, label %395, label %144, !llvm.loop !14

269:                                              ; preds = %269, %142
  %270 = phi i32 [ 0, %142 ], [ %393, %269 ]
  %271 = phi i32 [ 255, %142 ], [ %392, %269 ]
  %272 = phi i32 [ 255, %142 ], [ %391, %269 ]
  %273 = add nsw i32 %271, %13
  %274 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %273
  %275 = load i32, i32 addrspace(3)* %274, align 4, !tbaa !8
  %276 = add nsw i32 %136, %272
  %277 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %276
  %278 = load i32, i32 addrspace(3)* %277, align 4, !tbaa !8
  %279 = icmp sgt i32 %275, %278
  %280 = sub nuw nsw i32 255, %270
  %281 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %280
  %282 = freeze i1 %279
  %283 = select i1 %282, i32 %275, i32 %278
  store i32 %283, i32 addrspace(3)* %281, align 4, !tbaa !8
  %284 = select i1 %282, i32 %271, i32 %272
  %285 = add nsw i32 %284, -1
  %286 = select i1 %282, i32 %272, i32 %285
  %287 = select i1 %282, i32 %285, i32 %271
  %288 = add nsw i32 %287, %13
  %289 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %288
  %290 = load i32, i32 addrspace(3)* %289, align 4, !tbaa !8
  %291 = add nsw i32 %136, %286
  %292 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %291
  %293 = load i32, i32 addrspace(3)* %292, align 4, !tbaa !8
  %294 = icmp sgt i32 %290, %293
  %295 = sub nsw i32 254, %270
  %296 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %295
  %297 = freeze i1 %294
  %298 = select i1 %297, i32 %290, i32 %293
  store i32 %298, i32 addrspace(3)* %296, align 8, !tbaa !8
  %299 = select i1 %297, i32 %287, i32 %286
  %300 = add nsw i32 %299, -1
  %301 = select i1 %297, i32 %286, i32 %300
  %302 = select i1 %297, i32 %300, i32 %287
  %303 = add nsw i32 %302, %13
  %304 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %303
  %305 = load i32, i32 addrspace(3)* %304, align 4, !tbaa !8
  %306 = add nsw i32 %136, %301
  %307 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %306
  %308 = load i32, i32 addrspace(3)* %307, align 4, !tbaa !8
  %309 = icmp sgt i32 %305, %308
  %310 = sub nsw i32 253, %270
  %311 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %310
  %312 = freeze i1 %309
  %313 = select i1 %312, i32 %305, i32 %308
  store i32 %313, i32 addrspace(3)* %311, align 4, !tbaa !8
  %314 = select i1 %312, i32 %302, i32 %301
  %315 = add nsw i32 %314, -1
  %316 = select i1 %312, i32 %301, i32 %315
  %317 = select i1 %312, i32 %315, i32 %302
  %318 = add nsw i32 %317, %13
  %319 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %318
  %320 = load i32, i32 addrspace(3)* %319, align 4, !tbaa !8
  %321 = add nsw i32 %136, %316
  %322 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %321
  %323 = load i32, i32 addrspace(3)* %322, align 4, !tbaa !8
  %324 = icmp sgt i32 %320, %323
  %325 = sub nsw i32 252, %270
  %326 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %325
  %327 = freeze i1 %324
  %328 = select i1 %327, i32 %320, i32 %323
  store i32 %328, i32 addrspace(3)* %326, align 16, !tbaa !8
  %329 = select i1 %327, i32 %317, i32 %316
  %330 = add nsw i32 %329, -1
  %331 = select i1 %327, i32 %316, i32 %330
  %332 = select i1 %327, i32 %330, i32 %317
  %333 = add nsw i32 %332, %13
  %334 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %333
  %335 = load i32, i32 addrspace(3)* %334, align 4, !tbaa !8
  %336 = add nsw i32 %136, %331
  %337 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %336
  %338 = load i32, i32 addrspace(3)* %337, align 4, !tbaa !8
  %339 = icmp sgt i32 %335, %338
  %340 = sub nsw i32 251, %270
  %341 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %340
  %342 = freeze i1 %339
  %343 = select i1 %342, i32 %335, i32 %338
  store i32 %343, i32 addrspace(3)* %341, align 4, !tbaa !8
  %344 = select i1 %342, i32 %332, i32 %331
  %345 = add nsw i32 %344, -1
  %346 = select i1 %342, i32 %331, i32 %345
  %347 = select i1 %342, i32 %345, i32 %332
  %348 = add nsw i32 %347, %13
  %349 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %348
  %350 = load i32, i32 addrspace(3)* %349, align 4, !tbaa !8
  %351 = add nsw i32 %136, %346
  %352 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %351
  %353 = load i32, i32 addrspace(3)* %352, align 4, !tbaa !8
  %354 = icmp sgt i32 %350, %353
  %355 = sub nsw i32 250, %270
  %356 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %355
  %357 = freeze i1 %354
  %358 = select i1 %357, i32 %350, i32 %353
  store i32 %358, i32 addrspace(3)* %356, align 8, !tbaa !8
  %359 = select i1 %357, i32 %347, i32 %346
  %360 = add nsw i32 %359, -1
  %361 = select i1 %357, i32 %346, i32 %360
  %362 = select i1 %357, i32 %360, i32 %347
  %363 = add nsw i32 %362, %13
  %364 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %363
  %365 = load i32, i32 addrspace(3)* %364, align 4, !tbaa !8
  %366 = add nsw i32 %136, %361
  %367 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %366
  %368 = load i32, i32 addrspace(3)* %367, align 4, !tbaa !8
  %369 = icmp sgt i32 %365, %368
  %370 = sub nsw i32 249, %270
  %371 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %370
  %372 = freeze i1 %369
  %373 = select i1 %372, i32 %365, i32 %368
  store i32 %373, i32 addrspace(3)* %371, align 4, !tbaa !8
  %374 = select i1 %372, i32 %362, i32 %361
  %375 = add nsw i32 %374, -1
  %376 = select i1 %372, i32 %361, i32 %375
  %377 = select i1 %372, i32 %375, i32 %362
  %378 = add nsw i32 %377, %13
  %379 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %378
  %380 = load i32, i32 addrspace(3)* %379, align 4, !tbaa !8
  %381 = add nsw i32 %136, %376
  %382 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %381
  %383 = load i32, i32 addrspace(3)* %382, align 4, !tbaa !8
  %384 = icmp sgt i32 %380, %383
  %385 = sub nsw i32 248, %270
  %386 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %385
  %387 = freeze i1 %384
  %388 = select i1 %387, i32 %380, i32 %383
  store i32 %388, i32 addrspace(3)* %386, align 16, !tbaa !8
  %389 = select i1 %387, i32 %377, i32 %376
  %390 = add nsw i32 %389, -1
  %391 = select i1 %387, i32 %376, i32 %390
  %392 = select i1 %387, i32 %390, i32 %377
  %393 = add nuw nsw i32 %270, 8
  %394 = icmp eq i32 %393, 256
  br i1 %394, label %395, label %269, !llvm.loop !15

395:                                              ; preds = %269, %144
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %138, label %396, label %479

396:                                              ; preds = %396, %395
  %397 = phi i32 [ 0, %395 ], [ %477, %396 ]
  %398 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %397
  %399 = load i32, i32 addrspace(3)* %398, align 16, !tbaa !8
  %400 = add nuw nsw i32 %397, %13
  %401 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %400
  store i32 %399, i32 addrspace(3)* %401, align 16, !tbaa !8
  %402 = or i32 %397, 1
  %403 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %402
  %404 = load i32, i32 addrspace(3)* %403, align 4, !tbaa !8
  %405 = add nuw nsw i32 %402, %13
  %406 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %405
  store i32 %404, i32 addrspace(3)* %406, align 4, !tbaa !8
  %407 = or i32 %397, 2
  %408 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %407
  %409 = load i32, i32 addrspace(3)* %408, align 8, !tbaa !8
  %410 = add nuw nsw i32 %407, %13
  %411 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %410
  store i32 %409, i32 addrspace(3)* %411, align 8, !tbaa !8
  %412 = or i32 %397, 3
  %413 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %412
  %414 = load i32, i32 addrspace(3)* %413, align 4, !tbaa !8
  %415 = add nuw nsw i32 %412, %13
  %416 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %415
  store i32 %414, i32 addrspace(3)* %416, align 4, !tbaa !8
  %417 = or i32 %397, 4
  %418 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %417
  %419 = load i32, i32 addrspace(3)* %418, align 16, !tbaa !8
  %420 = add nuw nsw i32 %417, %13
  %421 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %420
  store i32 %419, i32 addrspace(3)* %421, align 16, !tbaa !8
  %422 = or i32 %397, 5
  %423 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %422
  %424 = load i32, i32 addrspace(3)* %423, align 4, !tbaa !8
  %425 = add nuw nsw i32 %422, %13
  %426 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %425
  store i32 %424, i32 addrspace(3)* %426, align 4, !tbaa !8
  %427 = or i32 %397, 6
  %428 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %427
  %429 = load i32, i32 addrspace(3)* %428, align 8, !tbaa !8
  %430 = add nuw nsw i32 %427, %13
  %431 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %430
  store i32 %429, i32 addrspace(3)* %431, align 8, !tbaa !8
  %432 = or i32 %397, 7
  %433 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %432
  %434 = load i32, i32 addrspace(3)* %433, align 4, !tbaa !8
  %435 = add nuw nsw i32 %432, %13
  %436 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %435
  store i32 %434, i32 addrspace(3)* %436, align 4, !tbaa !8
  %437 = or i32 %397, 8
  %438 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %437
  %439 = load i32, i32 addrspace(3)* %438, align 16, !tbaa !8
  %440 = add nuw nsw i32 %437, %13
  %441 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %440
  store i32 %439, i32 addrspace(3)* %441, align 16, !tbaa !8
  %442 = or i32 %397, 9
  %443 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %442
  %444 = load i32, i32 addrspace(3)* %443, align 4, !tbaa !8
  %445 = add nuw nsw i32 %442, %13
  %446 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %445
  store i32 %444, i32 addrspace(3)* %446, align 4, !tbaa !8
  %447 = or i32 %397, 10
  %448 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %447
  %449 = load i32, i32 addrspace(3)* %448, align 8, !tbaa !8
  %450 = add nuw nsw i32 %447, %13
  %451 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %450
  store i32 %449, i32 addrspace(3)* %451, align 8, !tbaa !8
  %452 = or i32 %397, 11
  %453 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %452
  %454 = load i32, i32 addrspace(3)* %453, align 4, !tbaa !8
  %455 = add nuw nsw i32 %452, %13
  %456 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %455
  store i32 %454, i32 addrspace(3)* %456, align 4, !tbaa !8
  %457 = or i32 %397, 12
  %458 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %457
  %459 = load i32, i32 addrspace(3)* %458, align 16, !tbaa !8
  %460 = add nuw nsw i32 %457, %13
  %461 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %460
  store i32 %459, i32 addrspace(3)* %461, align 16, !tbaa !8
  %462 = or i32 %397, 13
  %463 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %462
  %464 = load i32, i32 addrspace(3)* %463, align 4, !tbaa !8
  %465 = add nuw nsw i32 %462, %13
  %466 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %465
  store i32 %464, i32 addrspace(3)* %466, align 4, !tbaa !8
  %467 = or i32 %397, 14
  %468 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %467
  %469 = load i32, i32 addrspace(3)* %468, align 8, !tbaa !8
  %470 = add nuw nsw i32 %467, %13
  %471 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %470
  store i32 %469, i32 addrspace(3)* %471, align 8, !tbaa !8
  %472 = or i32 %397, 15
  %473 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %472
  %474 = load i32, i32 addrspace(3)* %473, align 4, !tbaa !8
  %475 = add nuw nsw i32 %472, %13
  %476 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %475
  store i32 %474, i32 addrspace(3)* %476, align 4, !tbaa !8
  %477 = add nuw nsw i32 %397, 16
  %478 = icmp eq i32 %477, 256
  br i1 %478, label %479, label %396, !llvm.loop !16

479:                                              ; preds = %396, %395
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %139, label %480, label %605

480:                                              ; preds = %480, %479
  %481 = phi i32 [ 0, %479 ], [ %603, %480 ]
  %482 = phi i32 [ 0, %479 ], [ %601, %480 ]
  %483 = phi i32 [ 0, %479 ], [ %599, %480 ]
  %484 = add nsw i32 %483, %13
  %485 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %484
  %486 = load i32, i32 addrspace(3)* %485, align 4, !tbaa !8
  %487 = add nsw i32 %137, %482
  %488 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %487
  %489 = load i32, i32 addrspace(3)* %488, align 4, !tbaa !8
  %490 = icmp sgt i32 %486, %489
  %491 = select i1 %490, i32 %489, i32 %486
  %492 = xor i1 %490, true
  %493 = zext i1 %492 to i32
  %494 = add nuw nsw i32 %483, %493
  %495 = zext i1 %490 to i32
  %496 = add nuw nsw i32 %482, %495
  %497 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %481
  store i32 %491, i32 addrspace(3)* %497, align 16
  %498 = or i32 %481, 1
  %499 = add nsw i32 %494, %13
  %500 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %499
  %501 = load i32, i32 addrspace(3)* %500, align 4, !tbaa !8
  %502 = add nsw i32 %137, %496
  %503 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %502
  %504 = load i32, i32 addrspace(3)* %503, align 4, !tbaa !8
  %505 = icmp sgt i32 %501, %504
  %506 = select i1 %505, i32 %504, i32 %501
  %507 = xor i1 %505, true
  %508 = zext i1 %507 to i32
  %509 = add nuw nsw i32 %494, %508
  %510 = zext i1 %505 to i32
  %511 = add nuw nsw i32 %496, %510
  %512 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %498
  store i32 %506, i32 addrspace(3)* %512, align 4
  %513 = or i32 %481, 2
  %514 = add nsw i32 %509, %13
  %515 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %514
  %516 = load i32, i32 addrspace(3)* %515, align 4, !tbaa !8
  %517 = add nsw i32 %137, %511
  %518 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %517
  %519 = load i32, i32 addrspace(3)* %518, align 4, !tbaa !8
  %520 = icmp sgt i32 %516, %519
  %521 = select i1 %520, i32 %519, i32 %516
  %522 = xor i1 %520, true
  %523 = zext i1 %522 to i32
  %524 = add nuw nsw i32 %509, %523
  %525 = zext i1 %520 to i32
  %526 = add nuw nsw i32 %511, %525
  %527 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %513
  store i32 %521, i32 addrspace(3)* %527, align 8
  %528 = or i32 %481, 3
  %529 = add nsw i32 %524, %13
  %530 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %529
  %531 = load i32, i32 addrspace(3)* %530, align 4, !tbaa !8
  %532 = add nsw i32 %137, %526
  %533 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %532
  %534 = load i32, i32 addrspace(3)* %533, align 4, !tbaa !8
  %535 = icmp sgt i32 %531, %534
  %536 = select i1 %535, i32 %534, i32 %531
  %537 = xor i1 %535, true
  %538 = zext i1 %537 to i32
  %539 = add nuw nsw i32 %524, %538
  %540 = zext i1 %535 to i32
  %541 = add nuw nsw i32 %526, %540
  %542 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %528
  store i32 %536, i32 addrspace(3)* %542, align 4
  %543 = or i32 %481, 4
  %544 = add nsw i32 %539, %13
  %545 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %544
  %546 = load i32, i32 addrspace(3)* %545, align 4, !tbaa !8
  %547 = add nsw i32 %137, %541
  %548 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %547
  %549 = load i32, i32 addrspace(3)* %548, align 4, !tbaa !8
  %550 = icmp sgt i32 %546, %549
  %551 = select i1 %550, i32 %549, i32 %546
  %552 = xor i1 %550, true
  %553 = zext i1 %552 to i32
  %554 = add nuw nsw i32 %539, %553
  %555 = zext i1 %550 to i32
  %556 = add nuw nsw i32 %541, %555
  %557 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %543
  store i32 %551, i32 addrspace(3)* %557, align 16
  %558 = or i32 %481, 5
  %559 = add nsw i32 %554, %13
  %560 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %559
  %561 = load i32, i32 addrspace(3)* %560, align 4, !tbaa !8
  %562 = add nsw i32 %137, %556
  %563 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %562
  %564 = load i32, i32 addrspace(3)* %563, align 4, !tbaa !8
  %565 = icmp sgt i32 %561, %564
  %566 = select i1 %565, i32 %564, i32 %561
  %567 = xor i1 %565, true
  %568 = zext i1 %567 to i32
  %569 = add nuw nsw i32 %554, %568
  %570 = zext i1 %565 to i32
  %571 = add nuw nsw i32 %556, %570
  %572 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %558
  store i32 %566, i32 addrspace(3)* %572, align 4
  %573 = or i32 %481, 6
  %574 = add nsw i32 %569, %13
  %575 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %574
  %576 = load i32, i32 addrspace(3)* %575, align 4, !tbaa !8
  %577 = add nsw i32 %137, %571
  %578 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %577
  %579 = load i32, i32 addrspace(3)* %578, align 4, !tbaa !8
  %580 = icmp sgt i32 %576, %579
  %581 = select i1 %580, i32 %579, i32 %576
  %582 = xor i1 %580, true
  %583 = zext i1 %582 to i32
  %584 = add nuw nsw i32 %569, %583
  %585 = zext i1 %580 to i32
  %586 = add nuw nsw i32 %571, %585
  %587 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %573
  store i32 %581, i32 addrspace(3)* %587, align 8
  %588 = or i32 %481, 7
  %589 = add nsw i32 %584, %13
  %590 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %589
  %591 = load i32, i32 addrspace(3)* %590, align 4, !tbaa !8
  %592 = add nsw i32 %137, %586
  %593 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %592
  %594 = load i32, i32 addrspace(3)* %593, align 4, !tbaa !8
  %595 = icmp sgt i32 %591, %594
  %596 = select i1 %595, i32 %594, i32 %591
  %597 = xor i1 %595, true
  %598 = zext i1 %597 to i32
  %599 = add nuw nsw i32 %584, %598
  %600 = zext i1 %595 to i32
  %601 = add nuw nsw i32 %586, %600
  %602 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %588
  store i32 %596, i32 addrspace(3)* %602, align 4
  %603 = add nuw nsw i32 %481, 8
  %604 = icmp eq i32 %603, 256
  br i1 %604, label %732, label %480, !llvm.loop !17

605:                                              ; preds = %479
  br i1 %140, label %732, label %606

606:                                              ; preds = %606, %605
  %607 = phi i32 [ 0, %605 ], [ %730, %606 ]
  %608 = phi i32 [ 255, %605 ], [ %729, %606 ]
  %609 = phi i32 [ 255, %605 ], [ %728, %606 ]
  %610 = add nsw i32 %608, %13
  %611 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %610
  %612 = load i32, i32 addrspace(3)* %611, align 4, !tbaa !8
  %613 = add nsw i32 %136, %609
  %614 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %613
  %615 = load i32, i32 addrspace(3)* %614, align 4, !tbaa !8
  %616 = icmp sgt i32 %612, %615
  %617 = sub nuw nsw i32 255, %607
  %618 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %617
  %619 = freeze i1 %616
  %620 = select i1 %619, i32 %612, i32 %615
  store i32 %620, i32 addrspace(3)* %618, align 4, !tbaa !8
  %621 = select i1 %619, i32 %608, i32 %609
  %622 = add nsw i32 %621, -1
  %623 = select i1 %619, i32 %609, i32 %622
  %624 = select i1 %619, i32 %622, i32 %608
  %625 = add nsw i32 %624, %13
  %626 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %625
  %627 = load i32, i32 addrspace(3)* %626, align 4, !tbaa !8
  %628 = add nsw i32 %136, %623
  %629 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %628
  %630 = load i32, i32 addrspace(3)* %629, align 4, !tbaa !8
  %631 = icmp sgt i32 %627, %630
  %632 = sub nsw i32 254, %607
  %633 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %632
  %634 = freeze i1 %631
  %635 = select i1 %634, i32 %627, i32 %630
  store i32 %635, i32 addrspace(3)* %633, align 8, !tbaa !8
  %636 = select i1 %634, i32 %624, i32 %623
  %637 = add nsw i32 %636, -1
  %638 = select i1 %634, i32 %623, i32 %637
  %639 = select i1 %634, i32 %637, i32 %624
  %640 = add nsw i32 %639, %13
  %641 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %640
  %642 = load i32, i32 addrspace(3)* %641, align 4, !tbaa !8
  %643 = add nsw i32 %136, %638
  %644 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %643
  %645 = load i32, i32 addrspace(3)* %644, align 4, !tbaa !8
  %646 = icmp sgt i32 %642, %645
  %647 = sub nsw i32 253, %607
  %648 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %647
  %649 = freeze i1 %646
  %650 = select i1 %649, i32 %642, i32 %645
  store i32 %650, i32 addrspace(3)* %648, align 4, !tbaa !8
  %651 = select i1 %649, i32 %639, i32 %638
  %652 = add nsw i32 %651, -1
  %653 = select i1 %649, i32 %638, i32 %652
  %654 = select i1 %649, i32 %652, i32 %639
  %655 = add nsw i32 %654, %13
  %656 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %655
  %657 = load i32, i32 addrspace(3)* %656, align 4, !tbaa !8
  %658 = add nsw i32 %136, %653
  %659 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %658
  %660 = load i32, i32 addrspace(3)* %659, align 4, !tbaa !8
  %661 = icmp sgt i32 %657, %660
  %662 = sub nsw i32 252, %607
  %663 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %662
  %664 = freeze i1 %661
  %665 = select i1 %664, i32 %657, i32 %660
  store i32 %665, i32 addrspace(3)* %663, align 16, !tbaa !8
  %666 = select i1 %664, i32 %654, i32 %653
  %667 = add nsw i32 %666, -1
  %668 = select i1 %664, i32 %653, i32 %667
  %669 = select i1 %664, i32 %667, i32 %654
  %670 = add nsw i32 %669, %13
  %671 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %670
  %672 = load i32, i32 addrspace(3)* %671, align 4, !tbaa !8
  %673 = add nsw i32 %136, %668
  %674 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %673
  %675 = load i32, i32 addrspace(3)* %674, align 4, !tbaa !8
  %676 = icmp sgt i32 %672, %675
  %677 = sub nsw i32 251, %607
  %678 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %677
  %679 = freeze i1 %676
  %680 = select i1 %679, i32 %672, i32 %675
  store i32 %680, i32 addrspace(3)* %678, align 4, !tbaa !8
  %681 = select i1 %679, i32 %669, i32 %668
  %682 = add nsw i32 %681, -1
  %683 = select i1 %679, i32 %668, i32 %682
  %684 = select i1 %679, i32 %682, i32 %669
  %685 = add nsw i32 %684, %13
  %686 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %685
  %687 = load i32, i32 addrspace(3)* %686, align 4, !tbaa !8
  %688 = add nsw i32 %136, %683
  %689 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %688
  %690 = load i32, i32 addrspace(3)* %689, align 4, !tbaa !8
  %691 = icmp sgt i32 %687, %690
  %692 = sub nsw i32 250, %607
  %693 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %692
  %694 = freeze i1 %691
  %695 = select i1 %694, i32 %687, i32 %690
  store i32 %695, i32 addrspace(3)* %693, align 8, !tbaa !8
  %696 = select i1 %694, i32 %684, i32 %683
  %697 = add nsw i32 %696, -1
  %698 = select i1 %694, i32 %683, i32 %697
  %699 = select i1 %694, i32 %697, i32 %684
  %700 = add nsw i32 %699, %13
  %701 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %700
  %702 = load i32, i32 addrspace(3)* %701, align 4, !tbaa !8
  %703 = add nsw i32 %136, %698
  %704 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %703
  %705 = load i32, i32 addrspace(3)* %704, align 4, !tbaa !8
  %706 = icmp sgt i32 %702, %705
  %707 = sub nsw i32 249, %607
  %708 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %707
  %709 = freeze i1 %706
  %710 = select i1 %709, i32 %702, i32 %705
  store i32 %710, i32 addrspace(3)* %708, align 4, !tbaa !8
  %711 = select i1 %709, i32 %699, i32 %698
  %712 = add nsw i32 %711, -1
  %713 = select i1 %709, i32 %698, i32 %712
  %714 = select i1 %709, i32 %712, i32 %699
  %715 = add nsw i32 %714, %13
  %716 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %715
  %717 = load i32, i32 addrspace(3)* %716, align 4, !tbaa !8
  %718 = add nsw i32 %136, %713
  %719 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %718
  %720 = load i32, i32 addrspace(3)* %719, align 4, !tbaa !8
  %721 = icmp sgt i32 %717, %720
  %722 = sub nsw i32 248, %607
  %723 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %722
  %724 = freeze i1 %721
  %725 = select i1 %724, i32 %717, i32 %720
  store i32 %725, i32 addrspace(3)* %723, align 16, !tbaa !8
  %726 = select i1 %724, i32 %714, i32 %713
  %727 = add nsw i32 %726, -1
  %728 = select i1 %724, i32 %713, i32 %727
  %729 = select i1 %724, i32 %727, i32 %714
  %730 = add nuw nsw i32 %607, 8
  %731 = icmp eq i32 %730, 256
  br i1 %731, label %732, label %606, !llvm.loop !18

732:                                              ; preds = %606, %605, %480
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %138, label %733, label %816

733:                                              ; preds = %733, %732
  %734 = phi i32 [ 0, %732 ], [ %814, %733 ]
  %735 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %734
  %736 = load i32, i32 addrspace(3)* %735, align 16, !tbaa !8
  %737 = add nuw nsw i32 %734, %13
  %738 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %737
  store i32 %736, i32 addrspace(3)* %738, align 16, !tbaa !8
  %739 = or i32 %734, 1
  %740 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %739
  %741 = load i32, i32 addrspace(3)* %740, align 4, !tbaa !8
  %742 = add nuw nsw i32 %739, %13
  %743 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %742
  store i32 %741, i32 addrspace(3)* %743, align 4, !tbaa !8
  %744 = or i32 %734, 2
  %745 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %744
  %746 = load i32, i32 addrspace(3)* %745, align 8, !tbaa !8
  %747 = add nuw nsw i32 %744, %13
  %748 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %747
  store i32 %746, i32 addrspace(3)* %748, align 8, !tbaa !8
  %749 = or i32 %734, 3
  %750 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %749
  %751 = load i32, i32 addrspace(3)* %750, align 4, !tbaa !8
  %752 = add nuw nsw i32 %749, %13
  %753 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %752
  store i32 %751, i32 addrspace(3)* %753, align 4, !tbaa !8
  %754 = or i32 %734, 4
  %755 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %754
  %756 = load i32, i32 addrspace(3)* %755, align 16, !tbaa !8
  %757 = add nuw nsw i32 %754, %13
  %758 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %757
  store i32 %756, i32 addrspace(3)* %758, align 16, !tbaa !8
  %759 = or i32 %734, 5
  %760 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %759
  %761 = load i32, i32 addrspace(3)* %760, align 4, !tbaa !8
  %762 = add nuw nsw i32 %759, %13
  %763 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %762
  store i32 %761, i32 addrspace(3)* %763, align 4, !tbaa !8
  %764 = or i32 %734, 6
  %765 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %764
  %766 = load i32, i32 addrspace(3)* %765, align 8, !tbaa !8
  %767 = add nuw nsw i32 %764, %13
  %768 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %767
  store i32 %766, i32 addrspace(3)* %768, align 8, !tbaa !8
  %769 = or i32 %734, 7
  %770 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %769
  %771 = load i32, i32 addrspace(3)* %770, align 4, !tbaa !8
  %772 = add nuw nsw i32 %769, %13
  %773 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %772
  store i32 %771, i32 addrspace(3)* %773, align 4, !tbaa !8
  %774 = or i32 %734, 8
  %775 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %774
  %776 = load i32, i32 addrspace(3)* %775, align 16, !tbaa !8
  %777 = add nuw nsw i32 %774, %13
  %778 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %777
  store i32 %776, i32 addrspace(3)* %778, align 16, !tbaa !8
  %779 = or i32 %734, 9
  %780 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %779
  %781 = load i32, i32 addrspace(3)* %780, align 4, !tbaa !8
  %782 = add nuw nsw i32 %779, %13
  %783 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %782
  store i32 %781, i32 addrspace(3)* %783, align 4, !tbaa !8
  %784 = or i32 %734, 10
  %785 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %784
  %786 = load i32, i32 addrspace(3)* %785, align 8, !tbaa !8
  %787 = add nuw nsw i32 %784, %13
  %788 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %787
  store i32 %786, i32 addrspace(3)* %788, align 8, !tbaa !8
  %789 = or i32 %734, 11
  %790 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %789
  %791 = load i32, i32 addrspace(3)* %790, align 4, !tbaa !8
  %792 = add nuw nsw i32 %789, %13
  %793 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %792
  store i32 %791, i32 addrspace(3)* %793, align 4, !tbaa !8
  %794 = or i32 %734, 12
  %795 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %794
  %796 = load i32, i32 addrspace(3)* %795, align 16, !tbaa !8
  %797 = add nuw nsw i32 %794, %13
  %798 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %797
  store i32 %796, i32 addrspace(3)* %798, align 16, !tbaa !8
  %799 = or i32 %734, 13
  %800 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %799
  %801 = load i32, i32 addrspace(3)* %800, align 4, !tbaa !8
  %802 = add nuw nsw i32 %799, %13
  %803 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %802
  store i32 %801, i32 addrspace(3)* %803, align 4, !tbaa !8
  %804 = or i32 %734, 14
  %805 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %804
  %806 = load i32, i32 addrspace(3)* %805, align 8, !tbaa !8
  %807 = add nuw nsw i32 %804, %13
  %808 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %807
  store i32 %806, i32 addrspace(3)* %808, align 8, !tbaa !8
  %809 = or i32 %734, 15
  %810 = getelementptr inbounds i32, i32 addrspace(3)* %130, i32 %809
  %811 = load i32, i32 addrspace(3)* %810, align 4, !tbaa !8
  %812 = add nuw nsw i32 %809, %13
  %813 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %812
  store i32 %811, i32 addrspace(3)* %813, align 4, !tbaa !8
  %814 = add nuw nsw i32 %734, 16
  %815 = icmp eq i32 %814, 256
  br i1 %815, label %816, label %733, !llvm.loop !19

816:                                              ; preds = %733, %732
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %817 = add nuw nsw i32 %143, 1
  %818 = icmp eq i32 %817, 16
  br i1 %818, label %141, label %142, !llvm.loop !20

819:                                              ; preds = %819, %141
  %820 = phi i32 [ 0, %141 ], [ %932, %819 ]
  %821 = add nuw nsw i32 %820, %13
  %822 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %821
  %823 = load i32, i32 addrspace(3)* %822, align 16, !tbaa !8
  %824 = add nuw nsw i32 %820, %11
  %825 = sext i32 %824 to i64
  %826 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %825
  store i32 %823, i32 addrspace(1)* %826, align 4, !tbaa !8
  %827 = or i32 %820, 1
  %828 = add nuw nsw i32 %827, %13
  %829 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %828
  %830 = load i32, i32 addrspace(3)* %829, align 4, !tbaa !8
  %831 = add nuw nsw i32 %827, %11
  %832 = sext i32 %831 to i64
  %833 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %832
  store i32 %830, i32 addrspace(1)* %833, align 4, !tbaa !8
  %834 = or i32 %820, 2
  %835 = add nuw nsw i32 %834, %13
  %836 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %835
  %837 = load i32, i32 addrspace(3)* %836, align 8, !tbaa !8
  %838 = add nuw nsw i32 %834, %11
  %839 = sext i32 %838 to i64
  %840 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %839
  store i32 %837, i32 addrspace(1)* %840, align 4, !tbaa !8
  %841 = or i32 %820, 3
  %842 = add nuw nsw i32 %841, %13
  %843 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %842
  %844 = load i32, i32 addrspace(3)* %843, align 4, !tbaa !8
  %845 = add nuw nsw i32 %841, %11
  %846 = sext i32 %845 to i64
  %847 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %846
  store i32 %844, i32 addrspace(1)* %847, align 4, !tbaa !8
  %848 = or i32 %820, 4
  %849 = add nuw nsw i32 %848, %13
  %850 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %849
  %851 = load i32, i32 addrspace(3)* %850, align 16, !tbaa !8
  %852 = add nuw nsw i32 %848, %11
  %853 = sext i32 %852 to i64
  %854 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %853
  store i32 %851, i32 addrspace(1)* %854, align 4, !tbaa !8
  %855 = or i32 %820, 5
  %856 = add nuw nsw i32 %855, %13
  %857 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %856
  %858 = load i32, i32 addrspace(3)* %857, align 4, !tbaa !8
  %859 = add nuw nsw i32 %855, %11
  %860 = sext i32 %859 to i64
  %861 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %860
  store i32 %858, i32 addrspace(1)* %861, align 4, !tbaa !8
  %862 = or i32 %820, 6
  %863 = add nuw nsw i32 %862, %13
  %864 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %863
  %865 = load i32, i32 addrspace(3)* %864, align 8, !tbaa !8
  %866 = add nuw nsw i32 %862, %11
  %867 = sext i32 %866 to i64
  %868 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %867
  store i32 %865, i32 addrspace(1)* %868, align 4, !tbaa !8
  %869 = or i32 %820, 7
  %870 = add nuw nsw i32 %869, %13
  %871 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %870
  %872 = load i32, i32 addrspace(3)* %871, align 4, !tbaa !8
  %873 = add nuw nsw i32 %869, %11
  %874 = sext i32 %873 to i64
  %875 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %874
  store i32 %872, i32 addrspace(1)* %875, align 4, !tbaa !8
  %876 = or i32 %820, 8
  %877 = add nuw nsw i32 %876, %13
  %878 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %877
  %879 = load i32, i32 addrspace(3)* %878, align 16, !tbaa !8
  %880 = add nuw nsw i32 %876, %11
  %881 = sext i32 %880 to i64
  %882 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %881
  store i32 %879, i32 addrspace(1)* %882, align 4, !tbaa !8
  %883 = or i32 %820, 9
  %884 = add nuw nsw i32 %883, %13
  %885 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %884
  %886 = load i32, i32 addrspace(3)* %885, align 4, !tbaa !8
  %887 = add nuw nsw i32 %883, %11
  %888 = sext i32 %887 to i64
  %889 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %888
  store i32 %886, i32 addrspace(1)* %889, align 4, !tbaa !8
  %890 = or i32 %820, 10
  %891 = add nuw nsw i32 %890, %13
  %892 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %891
  %893 = load i32, i32 addrspace(3)* %892, align 8, !tbaa !8
  %894 = add nuw nsw i32 %890, %11
  %895 = sext i32 %894 to i64
  %896 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %895
  store i32 %893, i32 addrspace(1)* %896, align 4, !tbaa !8
  %897 = or i32 %820, 11
  %898 = add nuw nsw i32 %897, %13
  %899 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %898
  %900 = load i32, i32 addrspace(3)* %899, align 4, !tbaa !8
  %901 = add nuw nsw i32 %897, %11
  %902 = sext i32 %901 to i64
  %903 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %902
  store i32 %900, i32 addrspace(1)* %903, align 4, !tbaa !8
  %904 = or i32 %820, 12
  %905 = add nuw nsw i32 %904, %13
  %906 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %905
  %907 = load i32, i32 addrspace(3)* %906, align 16, !tbaa !8
  %908 = add nuw nsw i32 %904, %11
  %909 = sext i32 %908 to i64
  %910 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %909
  store i32 %907, i32 addrspace(1)* %910, align 4, !tbaa !8
  %911 = or i32 %820, 13
  %912 = add nuw nsw i32 %911, %13
  %913 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %912
  %914 = load i32, i32 addrspace(3)* %913, align 4, !tbaa !8
  %915 = add nuw nsw i32 %911, %11
  %916 = sext i32 %915 to i64
  %917 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %916
  store i32 %914, i32 addrspace(1)* %917, align 4, !tbaa !8
  %918 = or i32 %820, 14
  %919 = add nuw nsw i32 %918, %13
  %920 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %919
  %921 = load i32, i32 addrspace(3)* %920, align 8, !tbaa !8
  %922 = add nuw nsw i32 %918, %11
  %923 = sext i32 %922 to i64
  %924 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %923
  store i32 %921, i32 addrspace(1)* %924, align 4, !tbaa !8
  %925 = or i32 %820, 15
  %926 = add nuw nsw i32 %925, %13
  %927 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %926
  %928 = load i32, i32 addrspace(3)* %927, align 4, !tbaa !8
  %929 = add nuw nsw i32 %925, %11
  %930 = sext i32 %929 to i64
  %931 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %930
  store i32 %928, i32 addrspace(1)* %931, align 4, !tbaa !8
  %932 = add nuw nsw i32 %820, 16
  %933 = icmp eq i32 %932, 256
  br i1 %933, label %934, label %819, !llvm.loop !21

934:                                              ; preds = %819, %141
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  ret void
}

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

attributes #0 = { convergent norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { convergent nounwind willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i32 0, i32 1024}
!6 = !{i16 1, i16 1025}
!7 = !{}
!8 = !{!9, !9, i64 0}
!9 = !{!"int", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = distinct !{!12, !13}
!13 = !{!"llvm.loop.mustprogress"}
!14 = distinct !{!14, !13}
!15 = distinct !{!15, !13}
!16 = distinct !{!16, !13}
!17 = distinct !{!17, !13}
!18 = distinct !{!18, !13}
!19 = distinct !{!19, !13}
!20 = distinct !{!20, !13}
!21 = distinct !{!21, !13}
