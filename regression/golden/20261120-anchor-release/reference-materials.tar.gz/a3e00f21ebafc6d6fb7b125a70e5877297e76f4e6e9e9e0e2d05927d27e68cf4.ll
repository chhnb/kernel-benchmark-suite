; ModuleID = '/data/home/chh/simplify-v2/build/dp1-removal/stable-darm/SasPoint5/prepared-7-1-2.ll'
source_filename = "/data/home/chh/simplify-v2/cases/boost-saspoint5/source/kernel.cu"
target datalayout = "e-i64:64-i128:128-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P = internal local_unnamed_addr addrspace(4) constant [13 x double] [double 0x3FE45F306DC9C883, double 0x406B28D28834A1D2, double 0x40E10B4A1F6CF501, double 0x4149F72088DFB4E6, double 0x41AA2A2B1216B605, double 0x4201FEA8BB3BE600, double 0x4250E9DB94569883, double 0x4295367142D96C3E, double 0x42D0C7351C0FE465, double 0x42FDF1537961E7A8, double 0x4318FADA1D9742AD, double 0x431A6A62BB63A40C, double 0x42F7DD4E00E3184B], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q = internal local_unnamed_addr addrspace(4) constant [15 x double] [double 1.000000e+00, double 0x407554BBE33DF6D0, double 0x40EACD56D4D9BE96, double 0x415478A3A36859F4, double 0x41B4BEC095014516, double 0x420CDB326777C2EB, double 0x425BBC435F07A940, double 0x42A2357E7C0D108C, double 0x42DFC3D0B52A82F3, double 0x43119515C0126E89, double 0x4337006916401BF8, double 0x434F8D8E245D5F98, double 0x4352307314019A4E, double 0x433A78AB06FBD9E7, double 0x42F4F252E8C6C233], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FDBE1FDB85FCBFC, double 0x401C7FC4A4CD29B7, double 0x40441F91A172918F, double 0x40569F495083FE32, double 0x4052E785C1291E6C, double 0x402963DA5E858427, double 0xBFE51906626836E2], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x4033DCC50DCD8254, double 0x40631B677D5BB29F, double 0x4081D5A7BC4B586A, double 0x4090A232759E33CF, double 0x408C89486705C083, double 0x40702DF59FC94A86], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 = internal local_unnamed_addr addrspace(4) constant [8 x double] [double 0x3FD2EBDAE01A865A, double 0x4001E701431550F3, double 0x40140D55A266563C, double 0x40061BEABB9D2FFC, double 0x3FBE3E1608F6B264, double 0x3F948267DD4FFC5C, double 0xBF7EE20D1DA304B5, double 0x3F567E8E10E805D5], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 = internal local_unnamed_addr addrspace(4) constant [6 x double] [double 1.000000e+00, double 0x4024936FD6337035, double 0x4043419A7FE0209B, double 0x404EEC78CE96F318, double 0x4042DAE171B23F0E, double 0x4015ACB627173EB5], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FC5DB8AD965E90E, double 0x3FEAFCABC850EDD7, double 0x3FF65A44B7FDD998, double 0x3FEC06E8946EFB9F, double 0x3FC7D5630E234B35, double 0x3F7E240887A8C893, double 0xBF1B2EC29D8B2658], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x401AEF3DDBD087CA, double 0x40316DCC2BF05060, double 0x40359825CD283464, double 0x4029F6B804AEAD76, double 0x400B41AF064F350F, double 0x3FD1EF45AB10745B], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FB60B1E33F10647, double 0x3FC5B8636B0E3222, double 0x3FBC07DA7811D486, double 0x3F9C536ADCBF4A28, double 0x3F6411736D26FD34, double 0x3F057CF6442FA06A, double 0xBE91AFF35CC657D0], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x4008539DEC96056A, double 0x400C3466C3C7D450, double 0x3FFF2AD31AA58662, double 0x3FE0C440E94F34C7, double 0x3FAFB74D5C9C7495, double 0x3F62EDB894F212E5], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FA40A885E63F440, double 0x3FA4D8C2969E1484, double 0x3F8D5B4999760A8F, double 0x3F608452D391BA63, double 0x3F1A625FB47B3E5D, double 0x3EAFEDB5AFBF2767, double 0xBE2EA1B19268350A], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FFA3986886A7224, double 0x3FF09C23C029EA8F, double 0x3FD45C79F4902790, double 0x3FA8ACC143771083, double 0x3F6AA8DFF46DC0A1, double 0x3F126489EF16E3AC], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F90E6E15AE0A0B5, double 0x3F807EC586F8D6C3, double 0x3F5628C3995B9895, double 0x3F1815313F095300, double 0x3EC2BE8138C05760, double 0x3E46283600C31343, double 0xBDB56E517F96664C], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FE9EC7342A94DF8, double 0x3FD0446895858090, double 0x3FA3D20C0F793A99, double 0x3F67F69AED3331A7, double 0x3F19EDB2C6FDDBA7, double 0x3EB1F9FE5CE35DD4], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F7B09124BFF3246, double 0x3F5A1B509F6E6B7F, double 0x3F215B9A853FE1BC, double 0x3ED2AE3619D566E9, double 0x3E6CCC5CC17E6081, double 0x3DE0CED483645917, double 0xBD405E2A41165B21], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FDA44C156520F4B, double 0x3FB0B03579A0DD2F, double 0x3F74916FEE749C77, double 0x3F2921C431130861, double 0x3ECB75120A3FA3A9, double 0x3E5333ECBD8F94A3], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F64D5E29688B048, double 0x3F34521A788CC925, double 0x3EEB47C2C7618FAD, double 0x3E8D9FBD4F84DAEB, double 0x3E17053C44720DE3, double 0x3D7B01444FBF3B93, double 0xBCCAC1BB5B2D869C], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FCAC72D2F36E816, double 0x3F91595000B0EB93, double 0x3F45CFDE78902384, double 0x3EEB30C9CE3272DE, double 0x3E7E4D79F7AC44EB, double 0x3DF59B56446B4334], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F4F4BD6E99FF4E5, double 0x3F0EBAD7DF31FFFC, double 0x3EB4C3314DF7C43F, double 0x3E46AFD495CB1DD4, double 0x3DC1BAD3548A0AB8, double 0x3D14DED0BB7A816C, double 0xBC54EF99AFF7380B], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FBB218F9E698485, double 0x3F71D0F3147D5FAB, double 0x3F16B5EB6E086EA2, double 0x3EACB59E1205CC30, double 0x3E303913316A148C, double 0x3D9774482B0EAD22], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 0x3FC9884533D43651, double 0xBF93CB8214E9986F, double 0xBF814A78F15CF4A7, double 0x3F6C735355393978, double 0xBF3A917333BAF05A], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 1.000000e+00, double 0x3FE66E5F74B0D81B, double 0x3FD116080081EF83, double 0x3FAC405BB896DD07, double 0x3F7AA11B83649D74], align 8

; Function Attrs: nofree norecurse nounwind willreturn
define dso_local void @evaluate(double* nocapture readonly %0, double* nocapture %1, i32 %2) local_unnamed_addr #0 {
  %4 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #3, !range !5
  %5 = tail call i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #3, !range !6
  %6 = mul i32 %5, %4
  %7 = tail call i32 @llvm.nvvm.read.ptx.sreg.tid.x() #3, !range !7
  %8 = add i32 %6, %7
  %9 = icmp slt i32 %8, %2
  br i1 %9, label %10, label %111

10:                                               ; preds = %3
  %11 = sext i32 %8 to i64
  %12 = getelementptr inbounds double, double* %0, i64 %11
  %13 = load double, double* %12, align 8, !tbaa !8
  %14 = fcmp ord double %13, 0.000000e+00
  %15 = fcmp ule double %13, 0x7FEFFFFFFFFFFFFF
  %16 = fcmp uge double %13, 0xFFEFFFFFFFFFFFFF
  %17 = and i1 %15, %16
  %18 = and i1 %14, %17
  br i1 %18, label %19, label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

19:                                               ; preds = %10
  %20 = tail call double @llvm.fabs.f64(double %13) #3
  %21 = fcmp olt double %20, 1.250000e-01
  br i1 %21, label %22, label %105

22:                                               ; preds = %19
  %23 = fmul double %13, %13
  %24 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 12), align 8, !tbaa !8
  %25 = fmul double %23, %24
  %26 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 10), align 8, !tbaa !8
  %27 = fadd double %25, %26
  %28 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 11), align 8, !tbaa !8
  %29 = fmul double %23, %28
  %30 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 9), align 8, !tbaa !8
  %31 = fadd double %29, %30
  %32 = fmul double %23, %27
  %33 = fmul double %23, %31
  %34 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 8), align 8, !tbaa !8
  %35 = fadd double %32, %34
  %36 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 7), align 8, !tbaa !8
  %37 = fadd double %33, %36
  %38 = fmul double %23, %35
  %39 = fmul double %23, %37
  %40 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %41 = fadd double %38, %40
  %42 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %43 = fadd double %39, %42
  %44 = fmul double %23, %41
  %45 = fmul double %23, %43
  %46 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %47 = fadd double %44, %46
  %48 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %49 = fadd double %45, %48
  %50 = fmul double %23, %47
  %51 = fmul double %23, %49
  %52 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %53 = fadd double %50, %52
  %54 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %55 = fadd double %51, %54
  %56 = fmul double %23, %53
  %57 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %58 = fadd double %56, %57
  %59 = fmul double %20, %55
  %60 = fadd double %58, %59
  %61 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 14), align 8, !tbaa !8
  %62 = fmul double %23, %61
  %63 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 12), align 8, !tbaa !8
  %64 = fadd double %62, %63
  %65 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 13), align 8, !tbaa !8
  %66 = fmul double %23, %65
  %67 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 11), align 8, !tbaa !8
  %68 = fadd double %66, %67
  %69 = fmul double %23, %64
  %70 = fmul double %23, %68
  %71 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 10), align 8, !tbaa !8
  %72 = fadd double %69, %71
  %73 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 9), align 8, !tbaa !8
  %74 = fadd double %70, %73
  %75 = fmul double %23, %72
  %76 = fmul double %23, %74
  %77 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 8), align 8, !tbaa !8
  %78 = fadd double %75, %77
  %79 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 7), align 8, !tbaa !8
  %80 = fadd double %76, %79
  %81 = fmul double %23, %78
  %82 = fmul double %23, %80
  %83 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %84 = fadd double %81, %83
  %85 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %86 = fadd double %82, %85
  %87 = fmul double %23, %84
  %88 = fmul double %23, %86
  %89 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %90 = fadd double %87, %89
  %91 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %92 = fadd double %88, %91
  %93 = fmul double %23, %90
  %94 = fmul double %23, %92
  %95 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %96 = fadd double %93, %95
  %97 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %98 = fadd double %94, %97
  %99 = fmul double %23, %96
  %100 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %101 = fadd double %99, %100
  %102 = fmul double %20, %98
  %103 = fadd double %101, %102
  %104 = fdiv double %60, %103
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

105:                                              ; preds = %19
  %106 = fcmp olt double %20, 5.000000e-01
  %107 = fcmp uge double %20, 6.400000e+01
  %decision.take = or i1 %106, %107
  br i1 %decision.take, label %merged.bb, label %decision.dispatch, !decision.condition_prefix !12

decision.dispatch:                                ; preds = %105
  %108 = fcmp olt double %20, 3.200000e+01
  br i1 %108, label %predication.split, label %predication.tail

_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit: ; preds = %predication.join119, %predication.tail, %22, %10
  %109 = phi double [ 0x7FF8000000000000, %10 ], [ %104, %22 ], [ %236, %predication.tail ], [ %317, %predication.join119 ]
  %110 = getelementptr inbounds double, double* %1, i64 %11
  store double %109, double* %110, align 8, !tbaa !8
  br label %111

111:                                              ; preds = %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit, %3
  ret void

predication.split:                                ; preds = %decision.dispatch
  %112 = fcmp olt double %20, 8.000000e+00
  %113 = fcmp olt double %20, 2.000000e+00
  %114 = select i1 %113, double 1.000000e+00, double 4.000000e+00
  %115 = select i1 %112, i1 %113, i1 undef
  %116 = select i1 %112, double %114, double 1.600000e+01
  %117 = fcmp olt double %20, %116
  %118 = select i1 %115, double -5.000000e-01, double -2.000000e+00
  %119 = select i1 %115, double -1.000000e+00, double -4.000000e+00
  %120 = select i1 %112, double %118, double -8.000000e+00
  %121 = select i1 %112, double %119, double -1.600000e+01
  %122 = select i1 %117, double %120, double %121
  br label %predication.tail

predication.tail:                                 ; preds = %predication.split, %decision.dispatch
  %merged.select = phi double [ -3.200000e+01, %decision.dispatch ], [ %122, %predication.split ]
  %123 = phi i1 [ undef, %decision.dispatch ], [ %112, %predication.split ]
  %124 = phi i1 [ undef, %decision.dispatch ], [ %115, %predication.split ]
  %125 = phi i1 [ undef, %decision.dispatch ], [ %117, %predication.split ]
  %126 = fadd double %20, %merged.select
  %127 = fmul double %126, %126
  %128 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 6), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 6)
  %129 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 6), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 6)
  %130 = select i1 %123, double* %128, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 6)
  %131 = select i1 %123, double* %129, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 6)
  %132 = select i1 %125, double* %130, double* %131
  %merged.select1 = select i1 %108, double* %132, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 6)
  %133 = load double, double* %merged.select1, align 8, !tbaa !8
  %134 = fmul double %127, %133
  %135 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 4), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 4)
  %136 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 4), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 4)
  %137 = select i1 %123, double* %135, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 4)
  %138 = select i1 %123, double* %136, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 4)
  %139 = select i1 %125, double* %137, double* %138
  %merged.select2 = select i1 %108, double* %139, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 4)
  %140 = load double, double* %merged.select2, align 8, !tbaa !8
  %141 = fadd double %134, %140
  %142 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 5), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 5)
  %143 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 5), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 5)
  %144 = select i1 %123, double* %142, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 5)
  %145 = select i1 %123, double* %143, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 5)
  %146 = select i1 %125, double* %144, double* %145
  %merged.select3 = select i1 %108, double* %146, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 5)
  %147 = load double, double* %merged.select3, align 8, !tbaa !8
  %148 = fmul double %127, %147
  %149 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 3), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 3)
  %150 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 3), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 3)
  %151 = select i1 %123, double* %149, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 3)
  %152 = select i1 %123, double* %150, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 3)
  %153 = select i1 %125, double* %151, double* %152
  %merged.select4 = select i1 %108, double* %153, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 3)
  %154 = load double, double* %merged.select4, align 8, !tbaa !8
  %155 = fadd double %148, %154
  %156 = fmul double %127, %141
  %157 = fmul double %127, %155
  %158 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 2), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 2)
  %159 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 2), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 2)
  %160 = select i1 %123, double* %158, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 2)
  %161 = select i1 %123, double* %159, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 2)
  %162 = select i1 %125, double* %160, double* %161
  %merged.select5 = select i1 %108, double* %162, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 2)
  %163 = load double, double* %merged.select5, align 8, !tbaa !8
  %164 = fadd double %156, %163
  %165 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 1), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 1)
  %166 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 1), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 1)
  %167 = select i1 %123, double* %165, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 1)
  %168 = select i1 %123, double* %166, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 1)
  %169 = select i1 %125, double* %167, double* %168
  %merged.select6 = select i1 %108, double* %169, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 1)
  %170 = load double, double* %merged.select6, align 8, !tbaa !8
  %171 = fadd double %157, %170
  %172 = fmul double %127, %164
  %173 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 0), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 0)
  %174 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 0), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 0)
  %175 = select i1 %123, double* %173, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 0)
  %176 = select i1 %123, double* %174, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 0)
  %177 = select i1 %125, double* %175, double* %176
  %merged.select7 = select i1 %108, double* %177, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 0)
  %178 = load double, double* %merged.select7, align 8, !tbaa !8
  %179 = fadd double %172, %178
  %180 = fmul double %126, %171
  %181 = fadd double %179, %180
  %182 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 6), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 6)
  %183 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 6), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 6)
  %184 = select i1 %123, double* %182, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 6)
  %185 = select i1 %123, double* %183, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 6)
  %186 = select i1 %125, double* %184, double* %185
  %merged.select8 = select i1 %108, double* %186, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 6)
  %187 = load double, double* %merged.select8, align 8, !tbaa !8
  %188 = fmul double %127, %187
  %189 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 4), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 4)
  %190 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 4), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 4)
  %191 = select i1 %123, double* %189, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 4)
  %192 = select i1 %123, double* %190, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 4)
  %193 = select i1 %125, double* %191, double* %192
  %merged.select9 = select i1 %108, double* %193, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 4)
  %194 = load double, double* %merged.select9, align 8, !tbaa !8
  %195 = fadd double %188, %194
  %196 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 5), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 5)
  %197 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 5), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 5)
  %198 = select i1 %123, double* %196, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 5)
  %199 = select i1 %123, double* %197, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 5)
  %200 = select i1 %125, double* %198, double* %199
  %merged.select10 = select i1 %108, double* %200, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 5)
  %201 = load double, double* %merged.select10, align 8, !tbaa !8
  %202 = fmul double %127, %201
  %203 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 3), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 3)
  %204 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 3), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 3)
  %205 = select i1 %123, double* %203, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 3)
  %206 = select i1 %123, double* %204, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 3)
  %207 = select i1 %125, double* %205, double* %206
  %merged.select11 = select i1 %108, double* %207, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 3)
  %208 = load double, double* %merged.select11, align 8, !tbaa !8
  %209 = fadd double %202, %208
  %210 = fmul double %127, %195
  %211 = fmul double %127, %209
  %212 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 2), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 2)
  %213 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 2), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 2)
  %214 = select i1 %123, double* %212, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 2)
  %215 = select i1 %123, double* %213, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 2)
  %216 = select i1 %125, double* %214, double* %215
  %merged.select12 = select i1 %108, double* %216, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 2)
  %217 = load double, double* %merged.select12, align 8, !tbaa !8
  %218 = fadd double %210, %217
  %219 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 1), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 1)
  %220 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 1), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 1)
  %221 = select i1 %123, double* %219, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 1)
  %222 = select i1 %123, double* %220, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 1)
  %223 = select i1 %125, double* %221, double* %222
  %merged.select13 = select i1 %108, double* %223, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 1)
  %224 = load double, double* %merged.select13, align 8, !tbaa !8
  %225 = fadd double %211, %224
  %226 = fmul double %127, %218
  %227 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 0), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 0)
  %228 = select i1 %124, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 0), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 0)
  %229 = select i1 %123, double* %227, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 0)
  %230 = select i1 %123, double* %228, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 0)
  %231 = select i1 %125, double* %229, double* %230
  %merged.select14 = select i1 %108, double* %231, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 0)
  %232 = load double, double* %merged.select14, align 8, !tbaa !8
  %233 = fadd double %226, %232
  %234 = fmul double %126, %225
  %235 = fadd double %233, %234
  %236 = fdiv double %181, %235
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

merged.bb:                                        ; preds = %105
  %237 = fcmp olt double %20, 2.500000e-01
  %238 = select i1 %237, double -1.250000e-01, double -2.500000e-01
  %239 = tail call double @llvm.sqrt.f64(double %20) #3
  %guard.value = select i1 %106, i1 %237, i1 undef
  %guard.value71 = select i1 %106, double %238, double undef
  %240 = fadd double %20, %guard.value71
  %.op = fdiv double 1.000000e+00, %239
  %guard.value76 = select i1 %106, double %240, double undef
  %guard.result = select i1 %106, double %240, double %.op
  %241 = fmul double %guard.result, %guard.result
  %242 = select i1 %guard.value, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 6), double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 7)
  %merged.select43 = select i1 %106, double* %242, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 4)
  %243 = load double, double* %merged.select43, align 8, !tbaa !8
  %244 = fmul double %241, %243
  %245 = select i1 %guard.value, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 4), double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 5)
  %merged.select44 = select i1 %106, double* %245, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 2)
  %246 = load double, double* %merged.select44, align 8, !tbaa !8
  %247 = fadd double %244, %246
  br i1 %106, label %predication.split85, label %predication.tail86

predication.split85:                              ; preds = %merged.bb
  %248 = select i1 %guard.value, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 5), double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 6)
  %249 = load double, double* %248, align 8, !tbaa !8
  %250 = fmul double %241, %249
  %251 = select i1 %guard.value, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 3), double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 4)
  br label %predication.tail86

predication.tail86:                               ; preds = %predication.split85, %merged.bb
  %merged.select45 = phi double* [ getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 3), %merged.bb ], [ %251, %predication.split85 ]
  %252 = phi double [ undef, %merged.bb ], [ %250, %predication.split85 ]
  %253 = load double, double* %merged.select45, align 8, !tbaa !8
  %254 = fadd double %252, %253
  %merged.select46 = select i1 %106, double %254, double %253
  %255 = fmul double %241, %merged.select46
  br i1 %106, label %predication.split89, label %predication.tail90

predication.split89:                              ; preds = %predication.tail86
  %256 = fmul double %241, %247
  %257 = select i1 %guard.value, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 2), double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 3)
  %258 = load double, double* %257, align 8, !tbaa !8
  %259 = fadd double %256, %258
  %260 = select i1 %guard.value, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 1), double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 2)
  br label %predication.tail90

predication.tail90:                               ; preds = %predication.split89, %predication.tail86
  %merged.select62 = phi double [ %.op, %predication.tail86 ], [ %241, %predication.split89 ]
  %merged.select47 = phi double* [ getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 1), %predication.tail86 ], [ %260, %predication.split89 ]
  %261 = phi double [ undef, %predication.tail86 ], [ %259, %predication.split89 ]
  %262 = load double, double* %merged.select47, align 8, !tbaa !8
  %263 = fadd double %255, %262
  %264 = fmul double %241, %261
  %265 = select i1 %guard.value, double %261, double %263
  %266 = select i1 %106, double %264, double undef
  %merged.select48 = select i1 %106, double %265, double %247
  %267 = fmul double %241, %merged.select48
  %268 = select i1 %guard.value, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 0), double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 1)
  %merged.select49 = select i1 %106, double* %268, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 0)
  %269 = load double, double* %merged.select49, align 8, !tbaa !8
  %270 = fadd double %267, %269
  %271 = fmul double %guard.result, %263
  %272 = select i1 %guard.value, double %270, double %266
  %273 = select i1 %guard.value, double %271, double %269
  %merged.select51 = select i1 %106, double %272, double %270
  %merged.select52 = select i1 %106, double %273, double %271
  %274 = fadd double %merged.select51, %merged.select52
  %275 = select i1 %guard.value, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 6), double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 0)
  %merged.select53 = select i1 %106, double* %275, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 4)
  %276 = load double, double* %merged.select53, align 8, !tbaa !8
  %277 = fadd double %267, %276
  %278 = select i1 %guard.value, double %241, double %guard.value76
  %279 = select i1 %guard.value, double %276, double %274
  %merged.select54 = select i1 %106, double %278, double %241
  %merged.select55 = select i1 %106, double %279, double %276
  %280 = fmul double %merged.select54, %merged.select55
  %281 = fadd double %280, %277
  %282 = select i1 %guard.value, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 4), double* getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 5)
  %283 = select i1 %106, double %281, double undef
  %merged.select56 = select i1 %106, double* %282, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 2)
  %284 = load double, double* %merged.select56, align 8, !tbaa !8
  %285 = fadd double %280, %284
  %286 = select i1 %guard.value, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 5), double* getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 3)
  %merged.select57 = select i1 %106, double* %286, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 3)
  %287 = load double, double* %merged.select57, align 8, !tbaa !8
  %288 = fmul double %241, %287
  %289 = select i1 %guard.value, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 3), double* getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 4)
  %merged.select58 = select i1 %106, double* %289, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 1)
  %290 = load double, double* %merged.select58, align 8, !tbaa !8
  %291 = fadd double %288, %290
  %292 = fmul double %241, %285
  %293 = select i1 %guard.value, double %291, double %290
  %294 = select i1 %106, double %292, double undef
  %merged.select59 = select i1 %106, double %293, double %285
  %295 = fmul double %241, %merged.select59
  %296 = select i1 %guard.value, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 2), double* getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 2)
  %merged.select60 = select i1 %106, double* %296, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 0)
  %297 = load double, double* %merged.select60, align 8, !tbaa !8
  %298 = and i1 %106, %guard.value
  %merged.select61 = select i1 %298, double %294, double %295
  %299 = fadd double %merged.select61, %297
  %merged.select63 = select i1 %106, double %299, double %291
  %300 = fmul double %merged.select62, %merged.select63
  br i1 %106, label %predication.split115, label %predication.tail116

predication.split115:                             ; preds = %predication.tail90
  %301 = fmul double %241, %284
  %302 = fadd double %301, %287
  %303 = fmul double %241, %302
  %304 = select i1 %guard.value, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 1), double* getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 1)
  %305 = load double, double* %304, align 8, !tbaa !8
  %306 = select i1 %guard.value, double %295, double %303
  br label %predication.tail116

predication.tail116:                              ; preds = %predication.split115, %predication.tail90
  %merged.select65 = phi double [ %300, %predication.tail90 ], [ %305, %predication.split115 ]
  %merged.select64 = phi double [ %299, %predication.tail90 ], [ %306, %predication.split115 ]
  %307 = fadd double %merged.select64, %merged.select65
  br i1 %106, label %predication.first117, label %predication.second118

predication.first117:                             ; preds = %predication.tail116
  %308 = select i1 %guard.value, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 0), double* getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 0)
  %309 = load double, double* %308, align 8, !tbaa !8
  %310 = fadd double %300, %309
  br label %predication.join119

predication.second118:                            ; preds = %predication.tail116
  %311 = fdiv double %274, %307
  br label %predication.join119

predication.join119:                              ; preds = %predication.second118, %predication.first117
  %merged.select67 = phi double [ %307, %predication.first117 ], [ %311, %predication.second118 ]
  %guard.value120 = phi double [ %310, %predication.first117 ], [ undef, %predication.second118 ]
  %312 = fmul double %guard.result, %merged.select67
  %313 = select i1 %guard.value, double %guard.value120, double %312
  %314 = select i1 %guard.value, double %312, double %guard.value120
  %315 = fadd double %313, %314
  %316 = select i1 %guard.value, double %274, double %283
  %merged.select68 = select i1 %106, double %316, double %312
  %merged.select69 = select i1 %106, double %315, double %20
  %317 = fdiv double %merged.select68, %merged.select69
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit
}

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #1

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #1

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.tid.x() #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.sqrt.f64(double) #2

attributes #0 = { nofree norecurse nounwind willreturn "disable-tail-calls"="false" "frame-pointer"="all" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="sm_70" "target-features"="+ptx32,+sm_70" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nounwind readnone }
attributes #2 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!nvvm.annotations = !{!0}
!llvm.module.flags = !{!1, !2}
!llvm.ident = !{!3, !4}

!0 = !{void (double*, double*, i32)* @evaluate, !"kernel", i32 1}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 4, !"nvvm-reflect-ftz", i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 3.8.0 (tags/RELEASE_380/final)"}
!5 = !{i32 0, i32 2147483647}
!6 = !{i32 1, i32 1025}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = !{}
