; ModuleID = 'cases/cholla-hlld/source/src/riemann_solvers/hlld_cuda.cu'
source_filename = "cases/cholla-hlld/source/src/riemann_solvers/hlld_cuda.cu"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

; Function Attrs: nofree norecurse nounwind willreturn
define protected amdgpu_kernel void @_ZN3mhd26Calculate_HLLD_Fluxes_CUDAEPKdS1_S1_Pdidii(double addrspace(1)* nocapture readonly %0, double addrspace(1)* nocapture readonly %1, double addrspace(1)* nocapture readonly %2, double addrspace(1)* %3, i32 %4, double %5, i32 %6, i32 %7) local_unnamed_addr #0 {
  %9 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %10 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %11 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %12 = getelementptr i8, i8 addrspace(4)* %11, i64 4
  %13 = bitcast i8 addrspace(4)* %12 to i16 addrspace(4)*
  %14 = load i16, i16 addrspace(4)* %13, align 4, !range !6, !invariant.load !7
  %15 = zext i16 %14 to i32
  %16 = mul i32 %10, %15
  %17 = add i32 %16, %9
  %18 = icmp slt i32 %17, %4
  br i1 %18, label %19, label %745

19:                                               ; preds = %8
  switch i32 %6, label %22 [
    i32 2, label %21
    i32 1, label %20
  ]

20:                                               ; preds = %19
  br label %22

21:                                               ; preds = %19
  br label %22

22:                                               ; preds = %19, %21, %20
  %23 = phi i32 [ %6, %21 ], [ %6, %20 ], [ 3, %19 ]
  %24 = phi i32 [ 1, %21 ], [ 3, %20 ], [ 2, %19 ]
  %25 = phi i32 [ 3, %21 ], [ 2, %20 ], [ 1, %19 ]
  %26 = sext i32 %17 to i64
  %27 = getelementptr inbounds double, double addrspace(1)* %2, i64 %26
  %28 = load double, double addrspace(1)* %27, align 8, !tbaa !8
  %29 = getelementptr inbounds double, double addrspace(1)* %0, i64 %26
  %30 = load double, double addrspace(1)* %29, align 8, !tbaa !8
  %31 = tail call double @llvm.maxnum.f64(double %30, double 0x3BC79CA10C924223) #3
  %32 = mul nsw i32 %25, %4
  %33 = add nsw i32 %32, %17
  %34 = sext i32 %33 to i64
  %35 = getelementptr inbounds double, double addrspace(1)* %0, i64 %34
  %36 = load double, double addrspace(1)* %35, align 8, !tbaa !8
  %37 = fdiv double %36, %31
  %38 = mul nsw i32 %24, %4
  %39 = add nsw i32 %38, %17
  %40 = sext i32 %39 to i64
  %41 = getelementptr inbounds double, double addrspace(1)* %0, i64 %40
  %42 = load double, double addrspace(1)* %41, align 8, !tbaa !8
  %43 = fdiv double %42, %31
  %44 = mul nsw i32 %23, %4
  %45 = add nsw i32 %44, %17
  %46 = sext i32 %45 to i64
  %47 = getelementptr inbounds double, double addrspace(1)* %0, i64 %46
  %48 = load double, double addrspace(1)* %47, align 8, !tbaa !8
  %49 = fdiv double %48, %31
  %50 = shl nsw i32 %4, 2
  %51 = add nsw i32 %17, %50
  %52 = sext i32 %51 to i64
  %53 = getelementptr inbounds double, double addrspace(1)* %0, i64 %52
  %54 = load double, double addrspace(1)* %53, align 8, !tbaa !8
  %55 = tail call double @llvm.maxnum.f64(double %54, double 0x3BC79CA10C924223) #3
  %56 = mul nsw i32 %4, 5
  %57 = add nsw i32 %17, %56
  %58 = sext i32 %57 to i64
  %59 = getelementptr inbounds double, double addrspace(1)* %0, i64 %58
  %60 = load double, double addrspace(1)* %59, align 8, !tbaa !8
  %61 = mul nsw i32 %4, 6
  %62 = add nsw i32 %17, %61
  %63 = sext i32 %62 to i64
  %64 = getelementptr inbounds double, double addrspace(1)* %0, i64 %63
  %65 = load double, double addrspace(1)* %64, align 8, !tbaa !8
  %66 = fmul double %31, 5.000000e-01
  %67 = fmul double %37, %37
  %68 = fmul double %43, %43
  %69 = fmul double %49, %49
  %70 = fadd double %68, %69
  %71 = fadd double %67, %70
  %72 = fmul double %66, %71
  %73 = fsub double %55, %72
  %74 = fmul double %28, %28
  %75 = fmul double %60, %60
  %76 = fmul double %65, %65
  %77 = fadd double %75, %76
  %78 = fadd double %74, %77
  %79 = fmul double %78, 5.000000e-01
  %80 = fsub double %73, %79
  %81 = fadd double %5, -1.000000e+00
  %82 = fmul double %81, %80
  %83 = tail call double @llvm.maxnum.f64(double %82, double 0x3BC79CA10C924223) #3
  %84 = fadd double %79, %83
  %85 = tail call double @llvm.maxnum.f64(double %84, double 0x3BC79CA10C924223) #3
  %86 = getelementptr inbounds double, double addrspace(1)* %1, i64 %26
  %87 = load double, double addrspace(1)* %86, align 8, !tbaa !8
  %88 = tail call double @llvm.maxnum.f64(double %87, double 0x3BC79CA10C924223) #3
  %89 = getelementptr inbounds double, double addrspace(1)* %1, i64 %34
  %90 = load double, double addrspace(1)* %89, align 8, !tbaa !8
  %91 = fdiv double %90, %88
  %92 = getelementptr inbounds double, double addrspace(1)* %1, i64 %40
  %93 = load double, double addrspace(1)* %92, align 8, !tbaa !8
  %94 = fdiv double %93, %88
  %95 = getelementptr inbounds double, double addrspace(1)* %1, i64 %46
  %96 = load double, double addrspace(1)* %95, align 8, !tbaa !8
  %97 = fdiv double %96, %88
  %98 = getelementptr inbounds double, double addrspace(1)* %1, i64 %52
  %99 = load double, double addrspace(1)* %98, align 8, !tbaa !8
  %100 = tail call double @llvm.maxnum.f64(double %99, double 0x3BC79CA10C924223) #3
  %101 = getelementptr inbounds double, double addrspace(1)* %1, i64 %58
  %102 = load double, double addrspace(1)* %101, align 8, !tbaa !8
  %103 = getelementptr inbounds double, double addrspace(1)* %1, i64 %63
  %104 = load double, double addrspace(1)* %103, align 8, !tbaa !8
  %105 = fmul double %88, 5.000000e-01
  %106 = fmul double %91, %91
  %107 = fmul double %94, %94
  %108 = fmul double %97, %97
  %109 = fadd double %107, %108
  %110 = fadd double %106, %109
  %111 = fmul double %105, %110
  %112 = fsub double %100, %111
  %113 = fmul double %102, %102
  %114 = fmul double %104, %104
  %115 = fadd double %113, %114
  %116 = fadd double %74, %115
  %117 = fmul double %116, 5.000000e-01
  %118 = fsub double %112, %117
  %119 = fmul double %81, %118
  %120 = tail call double @llvm.maxnum.f64(double %119, double 0x3BC79CA10C924223) #3
  %121 = fadd double %117, %120
  %122 = tail call double @llvm.maxnum.f64(double %121, double 0x3BC79CA10C924223) #3
  %123 = fmul double %83, %5
  %124 = fadd double %78, %123
  %125 = fmul double %124, %124
  %126 = fmul double %5, 4.000000e+00
  %127 = fmul double %126, %83
  %128 = fmul double %74, %127
  %129 = fsub double %125, %128
  %130 = fcmp olt double %129, 0x1000000000000000
  %131 = select i1 %130, double 0x4FF0000000000000, double 1.000000e+00
  %132 = fmul double %129, %131
  %133 = tail call double @llvm.amdgcn.rsq.f64(double %132) #3
  %134 = fmul double %132, %133
  %135 = fmul double %133, 5.000000e-01
  %136 = fneg double %135
  %137 = tail call double @llvm.fma.f64(double %136, double %134, double 5.000000e-01) #3
  %138 = tail call double @llvm.fma.f64(double %135, double %137, double %135) #3
  %139 = tail call double @llvm.fma.f64(double %134, double %137, double %134) #3
  %140 = fneg double %139
  %141 = tail call double @llvm.fma.f64(double %140, double %139, double %132) #3
  %142 = tail call double @llvm.fma.f64(double %141, double %138, double %139) #3
  %143 = fneg double %142
  %144 = tail call double @llvm.fma.f64(double %143, double %142, double %132) #3
  %145 = tail call double @llvm.fma.f64(double %144, double %138, double %142) #3
  %146 = select i1 %130, double 0x37F0000000000000, double 1.000000e+00
  %147 = fmul double %146, %145
  %148 = fcmp oeq double %132, 0.000000e+00
  %149 = fcmp oeq double %132, 0x7FF0000000000000
  %150 = or i1 %148, %149
  %151 = select i1 %150, double %132, double %147
  %152 = fadd double %124, %151
  %153 = fmul double %31, 2.000000e+00
  %154 = fdiv double %152, %153
  %155 = fcmp olt double %154, 0x1000000000000000
  %156 = select i1 %155, double 0x4FF0000000000000, double 1.000000e+00
  %157 = fmul double %154, %156
  %158 = tail call double @llvm.amdgcn.rsq.f64(double %157) #3
  %159 = fmul double %157, %158
  %160 = fmul double %158, 5.000000e-01
  %161 = fneg double %160
  %162 = tail call double @llvm.fma.f64(double %161, double %159, double 5.000000e-01) #3
  %163 = tail call double @llvm.fma.f64(double %160, double %162, double %160) #3
  %164 = tail call double @llvm.fma.f64(double %159, double %162, double %159) #3
  %165 = fneg double %164
  %166 = tail call double @llvm.fma.f64(double %165, double %164, double %157) #3
  %167 = tail call double @llvm.fma.f64(double %166, double %163, double %164) #3
  %168 = fneg double %167
  %169 = tail call double @llvm.fma.f64(double %168, double %167, double %157) #3
  %170 = tail call double @llvm.fma.f64(double %169, double %163, double %167) #3
  %171 = select i1 %155, double 0x37F0000000000000, double 1.000000e+00
  %172 = fmul double %171, %170
  %173 = fcmp oeq double %157, 0.000000e+00
  %174 = fcmp oeq double %157, 0x7FF0000000000000
  %175 = or i1 %173, %174
  %176 = select i1 %175, double %157, double %172
  %177 = fmul double %120, %5
  %178 = fadd double %116, %177
  %179 = fmul double %178, %178
  %180 = fmul double %126, %120
  %181 = fmul double %74, %180
  %182 = fsub double %179, %181
  %183 = fcmp olt double %182, 0x1000000000000000
  %184 = select i1 %183, double 0x4FF0000000000000, double 1.000000e+00
  %185 = fmul double %182, %184
  %186 = tail call double @llvm.amdgcn.rsq.f64(double %185) #3
  %187 = fmul double %185, %186
  %188 = fmul double %186, 5.000000e-01
  %189 = fneg double %188
  %190 = tail call double @llvm.fma.f64(double %189, double %187, double 5.000000e-01) #3
  %191 = tail call double @llvm.fma.f64(double %188, double %190, double %188) #3
  %192 = tail call double @llvm.fma.f64(double %187, double %190, double %187) #3
  %193 = fneg double %192
  %194 = tail call double @llvm.fma.f64(double %193, double %192, double %185) #3
  %195 = tail call double @llvm.fma.f64(double %194, double %191, double %192) #3
  %196 = fneg double %195
  %197 = tail call double @llvm.fma.f64(double %196, double %195, double %185) #3
  %198 = tail call double @llvm.fma.f64(double %197, double %191, double %195) #3
  %199 = select i1 %183, double 0x37F0000000000000, double 1.000000e+00
  %200 = fmul double %199, %198
  %201 = fcmp oeq double %185, 0.000000e+00
  %202 = fcmp oeq double %185, 0x7FF0000000000000
  %203 = or i1 %201, %202
  %204 = select i1 %203, double %185, double %200
  %205 = fadd double %178, %204
  %206 = fmul double %88, 2.000000e+00
  %207 = fdiv double %205, %206
  %208 = fcmp olt double %207, 0x1000000000000000
  %209 = select i1 %208, double 0x4FF0000000000000, double 1.000000e+00
  %210 = fmul double %207, %209
  %211 = tail call double @llvm.amdgcn.rsq.f64(double %210) #3
  %212 = fmul double %210, %211
  %213 = fmul double %211, 5.000000e-01
  %214 = fneg double %213
  %215 = tail call double @llvm.fma.f64(double %214, double %212, double 5.000000e-01) #3
  %216 = tail call double @llvm.fma.f64(double %213, double %215, double %213) #3
  %217 = tail call double @llvm.fma.f64(double %212, double %215, double %212) #3
  %218 = fneg double %217
  %219 = tail call double @llvm.fma.f64(double %218, double %217, double %210) #3
  %220 = tail call double @llvm.fma.f64(double %219, double %216, double %217) #3
  %221 = fneg double %220
  %222 = tail call double @llvm.fma.f64(double %221, double %220, double %210) #3
  %223 = tail call double @llvm.fma.f64(double %222, double %216, double %220) #3
  %224 = select i1 %208, double 0x37F0000000000000, double 1.000000e+00
  %225 = fmul double %224, %223
  %226 = fcmp oeq double %210, 0.000000e+00
  %227 = fcmp oeq double %210, 0x7FF0000000000000
  %228 = or i1 %226, %227
  %229 = select i1 %228, double %210, double %225
  %230 = tail call double @llvm.maxnum.f64(double %176, double %229) #3
  %231 = tail call double @llvm.minnum.f64(double %37, double %91) #3
  %232 = fsub double %231, %230
  %233 = tail call double @llvm.maxnum.f64(double %37, double %91) #3
  %234 = fadd double %233, %230
  %235 = fmul double %31, %37
  %236 = fmul double %37, %235
  %237 = fadd double %236, %85
  %238 = fsub double %237, %74
  %239 = fmul double %235, %43
  %240 = fmul double %28, %60
  %241 = fsub double %239, %240
  %242 = fmul double %235, %49
  %243 = fmul double %28, %65
  %244 = fsub double %242, %243
  %245 = fmul double %37, %60
  %246 = fmul double %28, %43
  %247 = fsub double %245, %246
  %248 = fmul double %37, %65
  %249 = fmul double %28, %49
  %250 = fsub double %248, %249
  %251 = fadd double %55, %85
  %252 = fmul double %37, %251
  %253 = fmul double %28, %37
  %254 = fmul double %43, %60
  %255 = fmul double %49, %65
  %256 = fadd double %254, %255
  %257 = fadd double %253, %256
  %258 = fmul double %28, %257
  %259 = fsub double %252, %258
  %260 = fcmp ogt double %232, 0.000000e+00
  br i1 %260, label %261, label %269

261:                                              ; preds = %22
  %262 = getelementptr inbounds double, double addrspace(1)* %3, i64 %26
  store double %235, double addrspace(1)* %262, align 8, !tbaa !8
  %263 = getelementptr inbounds double, double addrspace(1)* %3, i64 %34
  store double %238, double addrspace(1)* %263, align 8, !tbaa !8
  %264 = getelementptr inbounds double, double addrspace(1)* %3, i64 %40
  store double %241, double addrspace(1)* %264, align 8, !tbaa !8
  %265 = getelementptr inbounds double, double addrspace(1)* %3, i64 %46
  store double %244, double addrspace(1)* %265, align 8, !tbaa !8
  %266 = getelementptr inbounds double, double addrspace(1)* %3, i64 %52
  store double %259, double addrspace(1)* %266, align 8, !tbaa !8
  %267 = getelementptr inbounds double, double addrspace(1)* %3, i64 %58
  store double %247, double addrspace(1)* %267, align 8, !tbaa !8
  %268 = getelementptr inbounds double, double addrspace(1)* %3, i64 %63
  store double %250, double addrspace(1)* %268, align 8, !tbaa !8
  br label %745

269:                                              ; preds = %22
  %270 = fmul double %88, %91
  %271 = fmul double %91, %270
  %272 = fadd double %271, %122
  %273 = fsub double %272, %74
  %274 = fmul double %270, %94
  %275 = fmul double %28, %102
  %276 = fsub double %274, %275
  %277 = fmul double %270, %97
  %278 = fmul double %28, %104
  %279 = fsub double %277, %278
  %280 = fmul double %91, %102
  %281 = fmul double %28, %94
  %282 = fsub double %280, %281
  %283 = fmul double %91, %104
  %284 = fmul double %28, %97
  %285 = fsub double %283, %284
  %286 = fadd double %100, %122
  %287 = fmul double %91, %286
  %288 = fmul double %28, %91
  %289 = fmul double %94, %102
  %290 = fmul double %97, %104
  %291 = fadd double %289, %290
  %292 = fadd double %288, %291
  %293 = fmul double %28, %292
  %294 = fsub double %287, %293
  %295 = fcmp olt double %234, 0.000000e+00
  br i1 %295, label %296, label %304

296:                                              ; preds = %269
  %297 = getelementptr inbounds double, double addrspace(1)* %3, i64 %26
  store double %270, double addrspace(1)* %297, align 8, !tbaa !8
  %298 = getelementptr inbounds double, double addrspace(1)* %3, i64 %34
  store double %273, double addrspace(1)* %298, align 8, !tbaa !8
  %299 = getelementptr inbounds double, double addrspace(1)* %3, i64 %40
  store double %276, double addrspace(1)* %299, align 8, !tbaa !8
  %300 = getelementptr inbounds double, double addrspace(1)* %3, i64 %46
  store double %279, double addrspace(1)* %300, align 8, !tbaa !8
  %301 = getelementptr inbounds double, double addrspace(1)* %3, i64 %52
  store double %294, double addrspace(1)* %301, align 8, !tbaa !8
  %302 = getelementptr inbounds double, double addrspace(1)* %3, i64 %58
  store double %282, double addrspace(1)* %302, align 8, !tbaa !8
  %303 = getelementptr inbounds double, double addrspace(1)* %3, i64 %63
  store double %285, double addrspace(1)* %303, align 8, !tbaa !8
  br label %745

304:                                              ; preds = %269
  %305 = fsub double %234, %91
  %306 = fsub double %232, %37
  %307 = fmul double %88, %305
  %308 = fmul double %91, %307
  %309 = fmul double %31, %306
  %310 = fmul double %37, %309
  %311 = fsub double %308, %310
  %312 = fsub double %311, %122
  %313 = fadd double %85, %312
  %314 = fsub double %307, %309
  %315 = fdiv double %313, %314
  %316 = fmul double %88, %85
  %317 = fmul double %316, %305
  %318 = fmul double %31, %122
  %319 = fmul double %318, %306
  %320 = fsub double %317, %319
  %321 = fmul double %31, %88
  %322 = fmul double %321, %305
  %323 = fmul double %306, %322
  %324 = fsub double %91, %37
  %325 = fmul double %324, %323
  %326 = fadd double %320, %325
  %327 = fdiv double %326, %314
  %328 = fsub double %232, %315
  %329 = fdiv double %309, %328
  %330 = fmul double %309, %328
  %331 = fsub double %330, %74
  %332 = tail call double @llvm.fabs.f64(double %331) #3
  %333 = fmul double %327, 1.000000e-08
  %334 = fcmp olt double %332, %333
  br i1 %334, label %352, label %335

335:                                              ; preds = %304
  %336 = fsub double %315, %37
  %337 = fmul double %28, %336
  %338 = fdiv double %337, %331
  %339 = fmul double %60, %338
  %340 = fsub double %43, %339
  %341 = fmul double %65, %338
  %342 = fsub double %49, %341
  %343 = fmul double %306, %306
  %344 = fmul double %31, %343
  %345 = fsub double %344, %74
  %346 = fdiv double %345, %331
  %347 = fmul double %60, %346
  %348 = fmul double %65, %346
  %349 = fmul double %340, %347
  %350 = fmul double %342, %348
  %351 = fadd double %349, %350
  br label %352

352:                                              ; preds = %304, %335
  %353 = phi double [ %256, %304 ], [ %351, %335 ]
  %354 = phi double [ %43, %304 ], [ %340, %335 ]
  %355 = phi double [ %49, %304 ], [ %342, %335 ]
  %356 = phi double [ %60, %304 ], [ %347, %335 ]
  %357 = phi double [ %65, %304 ], [ %348, %335 ]
  %358 = fmul double %55, %306
  %359 = fmul double %37, %85
  %360 = fsub double %358, %359
  %361 = fmul double %327, %315
  %362 = fadd double %360, %361
  %363 = fmul double %28, %315
  %364 = fadd double %363, %353
  %365 = fsub double %257, %364
  %366 = fmul double %28, %365
  %367 = fadd double %362, %366
  %368 = fdiv double %367, %328
  %369 = tail call double @llvm.fabs.f64(double %28) #3
  %370 = tail call double @llvm.maxnum.f64(double %329, double 0x3BC79CA10C924223) #3
  %371 = tail call double @llvm.amdgcn.rsq.f64(double %370) #3
  %372 = fmul double %370, %371
  %373 = fmul double %371, 5.000000e-01
  %374 = fneg double %373
  %375 = tail call double @llvm.fma.f64(double %374, double %372, double 5.000000e-01) #3
  %376 = tail call double @llvm.fma.f64(double %373, double %375, double %373) #3
  %377 = tail call double @llvm.fma.f64(double %372, double %375, double %372) #3
  %378 = fneg double %377
  %379 = tail call double @llvm.fma.f64(double %378, double %377, double %370) #3
  %380 = tail call double @llvm.fma.f64(double %379, double %376, double %377) #3
  %381 = fneg double %380
  %382 = tail call double @llvm.fma.f64(double %381, double %380, double %370) #3
  %383 = tail call double @llvm.fma.f64(double %382, double %376, double %380) #3
  %384 = fcmp oeq double %370, 0x7FF0000000000000
  %385 = select i1 %384, double %370, double %383
  %386 = fdiv double %369, %385
  %387 = fsub double %315, %386
  %388 = fcmp ule double %387, 0.000000e+00
  %389 = fcmp ugt double %232, 0.000000e+00
  %390 = or i1 %389, %388
  br i1 %390, label %425, label %391

391:                                              ; preds = %352
  %392 = fsub double %329, %31
  %393 = fmul double %232, %392
  %394 = fadd double %235, %393
  %395 = fmul double %315, %329
  %396 = fsub double %395, %235
  %397 = fmul double %232, %396
  %398 = fadd double %238, %397
  %399 = fmul double %329, %354
  %400 = fmul double %31, %43
  %401 = fsub double %399, %400
  %402 = fmul double %232, %401
  %403 = fadd double %241, %402
  %404 = fmul double %329, %355
  %405 = fmul double %31, %49
  %406 = fsub double %404, %405
  %407 = fmul double %232, %406
  %408 = fadd double %244, %407
  %409 = fsub double %368, %55
  %410 = fmul double %232, %409
  %411 = fadd double %259, %410
  %412 = fsub double %356, %60
  %413 = fmul double %232, %412
  %414 = fadd double %247, %413
  %415 = fsub double %357, %65
  %416 = fmul double %232, %415
  %417 = fadd double %250, %416
  %418 = getelementptr inbounds double, double addrspace(1)* %3, i64 %26
  store double %394, double addrspace(1)* %418, align 8, !tbaa !8
  %419 = getelementptr inbounds double, double addrspace(1)* %3, i64 %34
  store double %398, double addrspace(1)* %419, align 8, !tbaa !8
  %420 = getelementptr inbounds double, double addrspace(1)* %3, i64 %40
  store double %403, double addrspace(1)* %420, align 8, !tbaa !8
  %421 = getelementptr inbounds double, double addrspace(1)* %3, i64 %46
  store double %408, double addrspace(1)* %421, align 8, !tbaa !8
  %422 = getelementptr inbounds double, double addrspace(1)* %3, i64 %52
  store double %411, double addrspace(1)* %422, align 8, !tbaa !8
  %423 = getelementptr inbounds double, double addrspace(1)* %3, i64 %58
  store double %414, double addrspace(1)* %423, align 8, !tbaa !8
  %424 = getelementptr inbounds double, double addrspace(1)* %3, i64 %63
  store double %417, double addrspace(1)* %424, align 8, !tbaa !8
  br label %745

425:                                              ; preds = %352
  %426 = fsub double %234, %315
  %427 = fdiv double %307, %426
  %428 = fmul double %307, %426
  %429 = fsub double %428, %74
  %430 = tail call double @llvm.fabs.f64(double %429) #3
  %431 = fcmp olt double %430, %333
  br i1 %431, label %449, label %432

432:                                              ; preds = %425
  %433 = fsub double %315, %91
  %434 = fmul double %28, %433
  %435 = fdiv double %434, %429
  %436 = fmul double %102, %435
  %437 = fsub double %94, %436
  %438 = fmul double %104, %435
  %439 = fsub double %97, %438
  %440 = fmul double %305, %305
  %441 = fmul double %88, %440
  %442 = fsub double %441, %74
  %443 = fdiv double %442, %429
  %444 = fmul double %102, %443
  %445 = fmul double %104, %443
  %446 = fmul double %437, %444
  %447 = fmul double %439, %445
  %448 = fadd double %446, %447
  br label %449

449:                                              ; preds = %425, %432
  %450 = phi double [ %291, %425 ], [ %448, %432 ]
  %451 = phi double [ %94, %425 ], [ %437, %432 ]
  %452 = phi double [ %97, %425 ], [ %439, %432 ]
  %453 = phi double [ %102, %425 ], [ %444, %432 ]
  %454 = phi double [ %104, %425 ], [ %445, %432 ]
  %455 = fmul double %100, %305
  %456 = fmul double %91, %122
  %457 = fsub double %455, %456
  %458 = fadd double %457, %361
  %459 = fadd double %363, %450
  %460 = fsub double %292, %459
  %461 = fmul double %28, %460
  %462 = fadd double %458, %461
  %463 = fdiv double %462, %426
  %464 = tail call double @llvm.maxnum.f64(double %427, double 0x3BC79CA10C924223) #3
  %465 = tail call double @llvm.amdgcn.rsq.f64(double %464) #3
  %466 = fmul double %464, %465
  %467 = fmul double %465, 5.000000e-01
  %468 = fneg double %467
  %469 = tail call double @llvm.fma.f64(double %468, double %466, double 5.000000e-01) #3
  %470 = tail call double @llvm.fma.f64(double %467, double %469, double %467) #3
  %471 = tail call double @llvm.fma.f64(double %466, double %469, double %466) #3
  %472 = fneg double %471
  %473 = tail call double @llvm.fma.f64(double %472, double %471, double %464) #3
  %474 = tail call double @llvm.fma.f64(double %473, double %470, double %471) #3
  %475 = fneg double %474
  %476 = tail call double @llvm.fma.f64(double %475, double %474, double %464) #3
  %477 = tail call double @llvm.fma.f64(double %476, double %470, double %474) #3
  %478 = fcmp oeq double %464, 0x7FF0000000000000
  %479 = select i1 %478, double %464, double %477
  %480 = fdiv double %369, %479
  %481 = fadd double %315, %480
  %482 = fcmp ugt double %481, 0.000000e+00
  %483 = fcmp ult double %234, 0.000000e+00
  %484 = or i1 %483, %482
  br i1 %484, label %519, label %485

485:                                              ; preds = %449
  %486 = fsub double %427, %88
  %487 = fmul double %234, %486
  %488 = fadd double %270, %487
  %489 = fmul double %315, %427
  %490 = fsub double %489, %270
  %491 = fmul double %234, %490
  %492 = fadd double %273, %491
  %493 = fmul double %427, %451
  %494 = fmul double %88, %94
  %495 = fsub double %493, %494
  %496 = fmul double %234, %495
  %497 = fadd double %276, %496
  %498 = fmul double %427, %452
  %499 = fmul double %88, %97
  %500 = fsub double %498, %499
  %501 = fmul double %234, %500
  %502 = fadd double %279, %501
  %503 = fsub double %463, %100
  %504 = fmul double %234, %503
  %505 = fadd double %294, %504
  %506 = fsub double %453, %102
  %507 = fmul double %234, %506
  %508 = fadd double %282, %507
  %509 = fsub double %454, %104
  %510 = fmul double %234, %509
  %511 = fadd double %285, %510
  %512 = getelementptr inbounds double, double addrspace(1)* %3, i64 %26
  store double %488, double addrspace(1)* %512, align 8, !tbaa !8
  %513 = getelementptr inbounds double, double addrspace(1)* %3, i64 %34
  store double %492, double addrspace(1)* %513, align 8, !tbaa !8
  %514 = getelementptr inbounds double, double addrspace(1)* %3, i64 %40
  store double %497, double addrspace(1)* %514, align 8, !tbaa !8
  %515 = getelementptr inbounds double, double addrspace(1)* %3, i64 %46
  store double %502, double addrspace(1)* %515, align 8, !tbaa !8
  %516 = getelementptr inbounds double, double addrspace(1)* %3, i64 %52
  store double %505, double addrspace(1)* %516, align 8, !tbaa !8
  %517 = getelementptr inbounds double, double addrspace(1)* %3, i64 %58
  store double %508, double addrspace(1)* %517, align 8, !tbaa !8
  %518 = getelementptr inbounds double, double addrspace(1)* %3, i64 %63
  store double %511, double addrspace(1)* %518, align 8, !tbaa !8
  br label %745

519:                                              ; preds = %449
  %520 = fmul double %74, 5.000000e-01
  %521 = fcmp olt double %520, %333
  br i1 %521, label %522, label %525

522:                                              ; preds = %519
  %523 = fcmp ult double %315, 0.000000e+00
  br i1 %523, label %524, label %615

524:                                              ; preds = %522
  br label %615

525:                                              ; preds = %519
  %526 = fcmp olt double %329, 0x1000000000000000
  %527 = select i1 %526, double 0x4FF0000000000000, double 1.000000e+00
  %528 = fmul double %329, %527
  %529 = tail call double @llvm.amdgcn.rsq.f64(double %528) #3
  %530 = fmul double %528, %529
  %531 = fmul double %529, 5.000000e-01
  %532 = fneg double %531
  %533 = tail call double @llvm.fma.f64(double %532, double %530, double 5.000000e-01) #3
  %534 = tail call double @llvm.fma.f64(double %531, double %533, double %531) #3
  %535 = tail call double @llvm.fma.f64(double %530, double %533, double %530) #3
  %536 = fneg double %535
  %537 = tail call double @llvm.fma.f64(double %536, double %535, double %528) #3
  %538 = tail call double @llvm.fma.f64(double %537, double %534, double %535) #3
  %539 = fneg double %538
  %540 = tail call double @llvm.fma.f64(double %539, double %538, double %528) #3
  %541 = tail call double @llvm.fma.f64(double %540, double %534, double %538) #3
  %542 = select i1 %526, double 0x37F0000000000000, double 1.000000e+00
  %543 = fmul double %542, %541
  %544 = fcmp oeq double %528, 0.000000e+00
  %545 = fcmp oeq double %528, 0x7FF0000000000000
  %546 = or i1 %544, %545
  %547 = select i1 %546, double %528, double %543
  %548 = fcmp olt double %427, 0x1000000000000000
  %549 = select i1 %548, double 0x4FF0000000000000, double 1.000000e+00
  %550 = fmul double %427, %549
  %551 = tail call double @llvm.amdgcn.rsq.f64(double %550) #3
  %552 = fmul double %550, %551
  %553 = fmul double %551, 5.000000e-01
  %554 = fneg double %553
  %555 = tail call double @llvm.fma.f64(double %554, double %552, double 5.000000e-01) #3
  %556 = tail call double @llvm.fma.f64(double %553, double %555, double %553) #3
  %557 = tail call double @llvm.fma.f64(double %552, double %555, double %552) #3
  %558 = fneg double %557
  %559 = tail call double @llvm.fma.f64(double %558, double %557, double %550) #3
  %560 = tail call double @llvm.fma.f64(double %559, double %556, double %557) #3
  %561 = fneg double %560
  %562 = tail call double @llvm.fma.f64(double %561, double %560, double %550) #3
  %563 = tail call double @llvm.fma.f64(double %562, double %556, double %560) #3
  %564 = select i1 %548, double 0x37F0000000000000, double 1.000000e+00
  %565 = fmul double %564, %563
  %566 = fcmp oeq double %550, 0.000000e+00
  %567 = fcmp oeq double %550, 0x7FF0000000000000
  %568 = or i1 %566, %567
  %569 = select i1 %568, double %550, double %565
  %570 = fadd double %547, %569
  %571 = fdiv double 1.000000e+00, %570
  %572 = tail call double @llvm.copysign.f64(double 1.000000e+00, double %28) #3
  %573 = fmul double %547, %354
  %574 = fmul double %569, %451
  %575 = fadd double %573, %574
  %576 = fsub double %453, %356
  %577 = fmul double %572, %576
  %578 = fadd double %575, %577
  %579 = fmul double %571, %578
  %580 = fmul double %547, %355
  %581 = fmul double %569, %452
  %582 = fadd double %580, %581
  %583 = fsub double %454, %357
  %584 = fmul double %572, %583
  %585 = fadd double %582, %584
  %586 = fmul double %571, %585
  %587 = fmul double %547, %453
  %588 = fmul double %569, %356
  %589 = fadd double %588, %587
  %590 = fmul double %547, %569
  %591 = fmul double %572, %590
  %592 = fsub double %451, %354
  %593 = fmul double %591, %592
  %594 = fadd double %593, %589
  %595 = fmul double %571, %594
  %596 = fmul double %547, %454
  %597 = fmul double %569, %357
  %598 = fadd double %597, %596
  %599 = fsub double %452, %355
  %600 = fmul double %591, %599
  %601 = fadd double %600, %598
  %602 = fmul double %571, %601
  %603 = fmul double %579, %595
  %604 = fmul double %586, %602
  %605 = fadd double %603, %604
  %606 = fadd double %363, %605
  %607 = fmul double %572, %547
  %608 = fsub double %364, %606
  %609 = fmul double %607, %608
  %610 = fsub double %368, %609
  %611 = fmul double %572, %569
  %612 = fsub double %459, %606
  %613 = fmul double %611, %612
  %614 = fadd double %463, %613
  br label %615

615:                                              ; preds = %522, %524, %525
  %616 = phi double [ %451, %524 ], [ %579, %525 ], [ %354, %522 ]
  %617 = phi double [ %452, %524 ], [ %586, %525 ], [ %355, %522 ]
  %618 = phi double [ %453, %524 ], [ %595, %525 ], [ %356, %522 ]
  %619 = phi double [ %454, %524 ], [ %602, %525 ], [ %357, %522 ]
  %620 = phi double [ 0.000000e+00, %524 ], [ %610, %525 ], [ %368, %522 ]
  %621 = phi double [ %463, %524 ], [ %614, %525 ], [ 0.000000e+00, %522 ]
  %622 = fcmp ule double %315, 0.000000e+00
  %623 = fcmp ugt double %387, 0.000000e+00
  %624 = or i1 %622, %623
  br i1 %624, label %683, label %625

625:                                              ; preds = %615
  %626 = fsub double %387, %232
  %627 = fmul double %31, %232
  %628 = fsub double %235, %627
  %629 = fmul double %329, %626
  %630 = fsub double %628, %629
  %631 = fmul double %329, %387
  %632 = fadd double %631, %630
  %633 = fmul double %235, %232
  %634 = fsub double %238, %633
  %635 = fmul double %315, %329
  %636 = fmul double %635, %626
  %637 = fsub double %634, %636
  %638 = fmul double %635, %387
  %639 = fadd double %638, %637
  %640 = fmul double %31, %43
  %641 = fmul double %640, %232
  %642 = fsub double %241, %641
  %643 = fmul double %329, %354
  %644 = fmul double %626, %643
  %645 = fsub double %642, %644
  %646 = fmul double %329, %616
  %647 = fmul double %387, %646
  %648 = fadd double %645, %647
  %649 = fmul double %31, %49
  %650 = fmul double %649, %232
  %651 = fsub double %244, %650
  %652 = fmul double %329, %355
  %653 = fmul double %626, %652
  %654 = fsub double %651, %653
  %655 = fmul double %329, %617
  %656 = fmul double %387, %655
  %657 = fadd double %654, %656
  %658 = fmul double %55, %232
  %659 = fsub double %259, %658
  %660 = fmul double %626, %368
  %661 = fsub double %659, %660
  %662 = fmul double %387, %620
  %663 = fadd double %661, %662
  %664 = fmul double %60, %232
  %665 = fsub double %247, %664
  %666 = fmul double %626, %356
  %667 = fsub double %665, %666
  %668 = fmul double %387, %618
  %669 = fadd double %667, %668
  %670 = fmul double %65, %232
  %671 = fsub double %250, %670
  %672 = fmul double %626, %357
  %673 = fsub double %671, %672
  %674 = fmul double %387, %619
  %675 = fadd double %673, %674
  %676 = getelementptr inbounds double, double addrspace(1)* %3, i64 %26
  store double %632, double addrspace(1)* %676, align 8, !tbaa !8
  %677 = getelementptr inbounds double, double addrspace(1)* %3, i64 %34
  store double %639, double addrspace(1)* %677, align 8, !tbaa !8
  %678 = getelementptr inbounds double, double addrspace(1)* %3, i64 %40
  store double %648, double addrspace(1)* %678, align 8, !tbaa !8
  %679 = getelementptr inbounds double, double addrspace(1)* %3, i64 %46
  store double %657, double addrspace(1)* %679, align 8, !tbaa !8
  %680 = getelementptr inbounds double, double addrspace(1)* %3, i64 %52
  store double %663, double addrspace(1)* %680, align 8, !tbaa !8
  %681 = getelementptr inbounds double, double addrspace(1)* %3, i64 %58
  store double %669, double addrspace(1)* %681, align 8, !tbaa !8
  %682 = getelementptr inbounds double, double addrspace(1)* %3, i64 %63
  store double %675, double addrspace(1)* %682, align 8, !tbaa !8
  br label %745

683:                                              ; preds = %615
  %684 = fcmp ule double %481, 0.000000e+00
  %685 = fcmp ugt double %315, 0.000000e+00
  %686 = or i1 %685, %684
  br i1 %686, label %745, label %687

687:                                              ; preds = %683
  %688 = fsub double %481, %234
  %689 = fmul double %88, %234
  %690 = fsub double %270, %689
  %691 = fmul double %427, %688
  %692 = fsub double %690, %691
  %693 = fmul double %427, %481
  %694 = fadd double %693, %692
  %695 = fmul double %270, %234
  %696 = fsub double %273, %695
  %697 = fmul double %315, %427
  %698 = fmul double %697, %688
  %699 = fsub double %696, %698
  %700 = fmul double %697, %481
  %701 = fadd double %700, %699
  %702 = fmul double %88, %94
  %703 = fmul double %702, %234
  %704 = fsub double %276, %703
  %705 = fmul double %427, %451
  %706 = fmul double %688, %705
  %707 = fsub double %704, %706
  %708 = fmul double %427, %616
  %709 = fmul double %481, %708
  %710 = fadd double %707, %709
  %711 = fmul double %88, %97
  %712 = fmul double %711, %234
  %713 = fsub double %279, %712
  %714 = fmul double %427, %452
  %715 = fmul double %688, %714
  %716 = fsub double %713, %715
  %717 = fmul double %427, %617
  %718 = fmul double %481, %717
  %719 = fadd double %716, %718
  %720 = fmul double %100, %234
  %721 = fsub double %294, %720
  %722 = fmul double %688, %463
  %723 = fsub double %721, %722
  %724 = fmul double %481, %621
  %725 = fadd double %723, %724
  %726 = fmul double %102, %234
  %727 = fsub double %282, %726
  %728 = fmul double %688, %453
  %729 = fsub double %727, %728
  %730 = fmul double %481, %618
  %731 = fadd double %729, %730
  %732 = fmul double %104, %234
  %733 = fsub double %285, %732
  %734 = fmul double %688, %454
  %735 = fsub double %733, %734
  %736 = fmul double %481, %619
  %737 = fadd double %735, %736
  %738 = getelementptr inbounds double, double addrspace(1)* %3, i64 %26
  store double %694, double addrspace(1)* %738, align 8, !tbaa !8
  %739 = getelementptr inbounds double, double addrspace(1)* %3, i64 %34
  store double %701, double addrspace(1)* %739, align 8, !tbaa !8
  %740 = getelementptr inbounds double, double addrspace(1)* %3, i64 %40
  store double %710, double addrspace(1)* %740, align 8, !tbaa !8
  %741 = getelementptr inbounds double, double addrspace(1)* %3, i64 %46
  store double %719, double addrspace(1)* %741, align 8, !tbaa !8
  %742 = getelementptr inbounds double, double addrspace(1)* %3, i64 %52
  store double %725, double addrspace(1)* %742, align 8, !tbaa !8
  %743 = getelementptr inbounds double, double addrspace(1)* %3, i64 %58
  store double %731, double addrspace(1)* %743, align 8, !tbaa !8
  %744 = getelementptr inbounds double, double addrspace(1)* %3, i64 %63
  store double %737, double addrspace(1)* %744, align 8, !tbaa !8
  br label %745

745:                                              ; preds = %261, %391, %625, %687, %683, %485, %296, %8
  ret void
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.maxnum.f64(double, double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.minnum.f64(double, double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rsq.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

attributes #0 = { nofree norecurse nounwind willreturn "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i32 0, i32 1024}
!6 = !{i16 1, i16 1025}
!7 = !{}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = !{!13}
!13 = distinct !{!13, !14, !"_ZN3mhd8internal9loadStateEPKdRS1_S3_RKiS5_S5_S5_S5_: argument 0"}
!14 = distinct !{!14, !"_ZN3mhd8internal9loadStateEPKdRS1_S3_RKiS5_S5_S5_S5_"}
!15 = !{!16}
!16 = distinct !{!16, !17, !"_ZN3mhd8internal9loadStateEPKdRS1_S3_RKiS5_S5_S5_S5_: argument 0"}
!17 = distinct !{!17, !"_ZN3mhd8internal9loadStateEPKdRS1_S3_RKiS5_S5_S5_S5_"}
