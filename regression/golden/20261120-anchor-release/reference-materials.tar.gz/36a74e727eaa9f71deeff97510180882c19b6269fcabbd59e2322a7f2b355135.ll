; ModuleID = '/data/home/chh/simplify-v2/build/simplify-fingerprint/active/vllm/trial-1066/fused.ll'
source_filename = "llvm-link"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p5i8(i64 immarg, i8 addrspace(5)* nocapture) #0

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p5i8(i64 immarg, i8 addrspace(5)* nocapture) #0

; Function Attrs: norecurse nounwind
define protected amdgpu_kernel void @cache_eval(i16 addrspace(1)* nocapture readonly %key.coerce, i16 addrspace(1)* nocapture readonly %value.coerce, i64 addrspace(1)* nocapture readonly %slots.coerce, i8 addrspace(1)* nocapture %kd.coerce, i8 addrspace(1)* nocapture %vd.coerce, i8 addrspace(1)* nocapture %ks.coerce, i8 addrspace(1)* nocapture %vs.coerce, i32 %heads, i32 %dim, i32 %page, i32 %stride, float %kg, float %vg) local_unnamed_addr #1 {
entry:
  %code = alloca [2 x i8], align 1, addrspace(5)
  %0 = tail call i32 @llvm.amdgcn.workgroup.id.x() #4
  %idxprom = sext i32 %0 to i64
  %arrayidx330 = getelementptr inbounds i64, i64 addrspace(1)* %slots.coerce, i64 %idxprom
  %1 = load i64, i64 addrspace(1)* %arrayidx330, align 8, !tbaa !5
  %cmp = icmp slt i64 %1, 0
  br i1 %cmp, label %cleanup, label %if.end

if.end:                                           ; preds = %entry
  %conv = sext i32 %page to i64
  %.frozen = freeze i64 %1
  %conv.frozen = freeze i64 %conv
  %div = sdiv i64 %.frozen, %conv.frozen
  %2 = mul i64 %div, %conv.frozen
  %rem.decomposed = sub i64 %.frozen, %2
  %conv9 = trunc i64 %rem.decomposed to i32
  %div10 = sdiv i32 %dim, 16
  %mul = mul nsw i32 %div10, %heads
  %conv13 = sext i32 %stride to i64
  %mul14 = mul nsw i64 %conv13, %idxprom
  %3 = tail call i32 @llvm.amdgcn.workitem.id.x() #4, !range !9
  %cmp32418 = icmp slt i32 %3, %mul
  %4 = getelementptr inbounds [2 x i8], [2 x i8] addrspace(5)* %code, i32 0, i32 0
  %conv151 = sext i32 %heads to i64
  %mul152 = mul nsw i64 %div, %conv151
  %div159 = sdiv i32 %dim, 2
  %conv160 = sext i32 %div159 to i64
  %div194 = sdiv i32 %conv9, 4
  %mul195 = shl nsw i32 %div194, 2
  %div196 = sdiv i32 %dim, 64
  %rem202.decomposed = sub i32 %conv9, %mul195
  %conv215 = sext i32 %div10 to i64
  %5 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #4
  %6 = getelementptr i8, i8 addrspace(4)* %5, i64 4
  %7 = bitcast i8 addrspace(4)* %6 to i16 addrspace(4)*
  %8 = load i16, i16 addrspace(4)* %7, align 4
  %9 = zext i16 %8 to i32
  %arrayidx64340398.1 = getelementptr inbounds [2 x i8], [2 x i8] addrspace(5)* %code, i32 0, i32 1
  %div10.frozen = freeze i32 %div10
  %div196.frozen = freeze i32 %div196
  br label %for.body

for.body:                                         ; preds = %for.cond.cleanup33, %if.end
  %os.sroa.0.0 = phi <2 x float> [ undef, %if.end ], [ %os.sroa.0.1, %for.cond.cleanup33 ]
  %tobool.not = phi i1 [ true, %if.end ], [ false, %for.cond.cleanup33 ]
  %cond.v = select i1 %tobool.not, i16 addrspace(1)* %key.coerce, i16 addrspace(1)* %value.coerce
  %add.ptr331 = getelementptr inbounds i16, i16 addrspace(1)* %cond.v, i64 %mul14
  %cond19.v = select i1 %tobool.not, i8 addrspace(1)* %kd.coerce, i8 addrspace(1)* %vd.coerce
  %cond24.v = select i1 %tobool.not, i8 addrspace(1)* %ks.coerce, i8 addrspace(1)* %vs.coerce
  %cond29 = select i1 %tobool.not, float %kg, float %vg
  br i1 %cmp32418, label %for.body34.lr.ph, label %for.cond.cleanup33

for.body34.lr.ph:                                 ; preds = %for.body
  %div71 = fdiv float 1.000000e+00, %cond29
  br label %for.body34

for.cond.cleanup33:                               ; preds = %if.end204, %for.body
  %os.sroa.0.1 = phi <2 x float> [ %os.sroa.0.0, %for.body ], [ %os.sroa.0.6, %if.end204 ]
  br i1 %tobool.not, label %for.body, label %cleanup

for.body34:                                       ; preds = %if.end204, %for.body34.lr.ph
  %os.sroa.0.2 = phi <2 x float> [ %os.sroa.0.0, %for.body34.lr.ph ], [ %os.sroa.0.6, %if.end204 ]
  %g.0419 = phi i32 [ %3, %for.body34.lr.ph ], [ %add222, %if.end204 ]
  %g.0419.frozen = freeze i32 %g.0419
  %div35 = sdiv i32 %g.0419.frozen, %div10.frozen
  %10 = mul i32 %div35, %div10.frozen
  %rem36.decomposed = sub i32 %g.0419.frozen, %10
  %mul41 = mul nsw i32 %div35, %dim
  %mul42 = shl nsw i32 %rem36.decomposed, 4
  %add = add nsw i32 %mul42, %mul41
  %idxprom44 = sext i32 %add to i64
  %arrayidx45347 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44
  %11 = load i16, i16 addrspace(1)* %arrayidx45347, align 2, !tbaa !10
  %conv.i = zext i16 %11 to i32
  %shl.i = shl nuw i32 %conv.i, 16
  %12 = bitcast i32 %shl.i to float
  %13 = tail call float @llvm.fabs.f32(float %12) #4
  %14 = tail call float @llvm.maxnum.f32(float %13, float 0.000000e+00) #4
  %add43.1 = add nsw i32 %add, 1
  %idxprom44.1 = sext i32 %add43.1 to i64
  %arrayidx45347.1 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.1
  %15 = load i16, i16 addrspace(1)* %arrayidx45347.1, align 2, !tbaa !10
  %conv.i.1 = zext i16 %15 to i32
  %shl.i.1 = shl nuw i32 %conv.i.1, 16
  %16 = bitcast i32 %shl.i.1 to float
  %17 = tail call float @llvm.fabs.f32(float %16) #4
  %18 = tail call float @llvm.maxnum.f32(float %14, float %17) #4
  %add43.2 = add nsw i32 %add, 2
  %idxprom44.2 = sext i32 %add43.2 to i64
  %arrayidx45347.2 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.2
  %19 = load i16, i16 addrspace(1)* %arrayidx45347.2, align 2, !tbaa !10
  %conv.i.2 = zext i16 %19 to i32
  %shl.i.2 = shl nuw i32 %conv.i.2, 16
  %20 = bitcast i32 %shl.i.2 to float
  %21 = tail call float @llvm.fabs.f32(float %20) #4
  %22 = tail call float @llvm.maxnum.f32(float %18, float %21) #4
  %add43.3 = add nsw i32 %add, 3
  %idxprom44.3 = sext i32 %add43.3 to i64
  %arrayidx45347.3 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.3
  %23 = load i16, i16 addrspace(1)* %arrayidx45347.3, align 2, !tbaa !10
  %conv.i.3 = zext i16 %23 to i32
  %shl.i.3 = shl nuw i32 %conv.i.3, 16
  %24 = bitcast i32 %shl.i.3 to float
  %25 = tail call float @llvm.fabs.f32(float %24) #4
  %26 = tail call float @llvm.maxnum.f32(float %22, float %25) #4
  %add43.4 = add nsw i32 %add, 4
  %idxprom44.4 = sext i32 %add43.4 to i64
  %arrayidx45347.4 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.4
  %27 = load i16, i16 addrspace(1)* %arrayidx45347.4, align 2, !tbaa !10
  %conv.i.4 = zext i16 %27 to i32
  %shl.i.4 = shl nuw i32 %conv.i.4, 16
  %28 = bitcast i32 %shl.i.4 to float
  %29 = tail call float @llvm.fabs.f32(float %28) #4
  %30 = tail call float @llvm.maxnum.f32(float %26, float %29) #4
  %add43.5 = add nsw i32 %add, 5
  %idxprom44.5 = sext i32 %add43.5 to i64
  %arrayidx45347.5 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.5
  %31 = load i16, i16 addrspace(1)* %arrayidx45347.5, align 2, !tbaa !10
  %conv.i.5 = zext i16 %31 to i32
  %shl.i.5 = shl nuw i32 %conv.i.5, 16
  %32 = bitcast i32 %shl.i.5 to float
  %33 = tail call float @llvm.fabs.f32(float %32) #4
  %34 = tail call float @llvm.maxnum.f32(float %30, float %33) #4
  %add43.6 = add nsw i32 %add, 6
  %idxprom44.6 = sext i32 %add43.6 to i64
  %arrayidx45347.6 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.6
  %35 = load i16, i16 addrspace(1)* %arrayidx45347.6, align 2, !tbaa !10
  %conv.i.6 = zext i16 %35 to i32
  %shl.i.6 = shl nuw i32 %conv.i.6, 16
  %36 = bitcast i32 %shl.i.6 to float
  %37 = tail call float @llvm.fabs.f32(float %36) #4
  %38 = tail call float @llvm.maxnum.f32(float %34, float %37) #4
  %add43.7 = add nsw i32 %add, 7
  %idxprom44.7 = sext i32 %add43.7 to i64
  %arrayidx45347.7 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.7
  %39 = load i16, i16 addrspace(1)* %arrayidx45347.7, align 2, !tbaa !10
  %conv.i.7 = zext i16 %39 to i32
  %shl.i.7 = shl nuw i32 %conv.i.7, 16
  %40 = bitcast i32 %shl.i.7 to float
  %41 = tail call float @llvm.fabs.f32(float %40) #4
  %42 = tail call float @llvm.maxnum.f32(float %38, float %41) #4
  %add43.8 = add nsw i32 %add, 8
  %idxprom44.8 = sext i32 %add43.8 to i64
  %arrayidx45347.8 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.8
  %43 = load i16, i16 addrspace(1)* %arrayidx45347.8, align 2, !tbaa !10
  %conv.i.8 = zext i16 %43 to i32
  %shl.i.8 = shl nuw i32 %conv.i.8, 16
  %44 = bitcast i32 %shl.i.8 to float
  %45 = tail call float @llvm.fabs.f32(float %44) #4
  %46 = tail call float @llvm.maxnum.f32(float %42, float %45) #4
  %add43.9 = add nsw i32 %add, 9
  %idxprom44.9 = sext i32 %add43.9 to i64
  %arrayidx45347.9 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.9
  %47 = load i16, i16 addrspace(1)* %arrayidx45347.9, align 2, !tbaa !10
  %conv.i.9 = zext i16 %47 to i32
  %shl.i.9 = shl nuw i32 %conv.i.9, 16
  %48 = bitcast i32 %shl.i.9 to float
  %49 = tail call float @llvm.fabs.f32(float %48) #4
  %50 = tail call float @llvm.maxnum.f32(float %46, float %49) #4
  %add43.10 = add nsw i32 %add, 10
  %idxprom44.10 = sext i32 %add43.10 to i64
  %arrayidx45347.10 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.10
  %51 = load i16, i16 addrspace(1)* %arrayidx45347.10, align 2, !tbaa !10
  %conv.i.10 = zext i16 %51 to i32
  %shl.i.10 = shl nuw i32 %conv.i.10, 16
  %52 = bitcast i32 %shl.i.10 to float
  %53 = tail call float @llvm.fabs.f32(float %52) #4
  %54 = tail call float @llvm.maxnum.f32(float %50, float %53) #4
  %add43.11 = add nsw i32 %add, 11
  %idxprom44.11 = sext i32 %add43.11 to i64
  %arrayidx45347.11 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.11
  %55 = load i16, i16 addrspace(1)* %arrayidx45347.11, align 2, !tbaa !10
  %conv.i.11 = zext i16 %55 to i32
  %shl.i.11 = shl nuw i32 %conv.i.11, 16
  %56 = bitcast i32 %shl.i.11 to float
  %57 = tail call float @llvm.fabs.f32(float %56) #4
  %58 = tail call float @llvm.maxnum.f32(float %54, float %57) #4
  %add43.12 = add nsw i32 %add, 12
  %idxprom44.12 = sext i32 %add43.12 to i64
  %arrayidx45347.12 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.12
  %59 = load i16, i16 addrspace(1)* %arrayidx45347.12, align 2, !tbaa !10
  %conv.i.12 = zext i16 %59 to i32
  %shl.i.12 = shl nuw i32 %conv.i.12, 16
  %60 = bitcast i32 %shl.i.12 to float
  %61 = tail call float @llvm.fabs.f32(float %60) #4
  %62 = tail call float @llvm.maxnum.f32(float %58, float %61) #4
  %add43.13 = add nsw i32 %add, 13
  %idxprom44.13 = sext i32 %add43.13 to i64
  %arrayidx45347.13 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.13
  %63 = load i16, i16 addrspace(1)* %arrayidx45347.13, align 2, !tbaa !10
  %conv.i.13 = zext i16 %63 to i32
  %shl.i.13 = shl nuw i32 %conv.i.13, 16
  %64 = bitcast i32 %shl.i.13 to float
  %65 = tail call float @llvm.fabs.f32(float %64) #4
  %66 = tail call float @llvm.maxnum.f32(float %62, float %65) #4
  %add43.14 = add nsw i32 %add, 14
  %idxprom44.14 = sext i32 %add43.14 to i64
  %arrayidx45347.14 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.14
  %67 = load i16, i16 addrspace(1)* %arrayidx45347.14, align 2, !tbaa !10
  %add43.15 = add nsw i32 %add, 15
  %idxprom44.15 = sext i32 %add43.15 to i64
  %arrayidx45347.15 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.15
  %68 = load i16, i16 addrspace(1)* %arrayidx45347.15, align 2, !tbaa !10
  %69 = insertelement <2 x i16> undef, i16 %68, i32 0
  %70 = insertelement <2 x i16> %69, i16 %67, i32 1
  %71 = zext <2 x i16> %70 to <2 x i32>
  %72 = shl nuw <2 x i32> %71, <i32 16, i32 16>
  %73 = bitcast <2 x i32> %72 to <2 x float>
  %74 = extractelement <2 x float> %73, i32 1
  %75 = tail call float @llvm.fabs.f32(float %74) #4
  %76 = tail call float @llvm.maxnum.f32(float %66, float %75) #4
  %77 = extractelement <2 x float> %73, i32 0
  %78 = tail call float @llvm.fabs.f32(float %77) #4
  %79 = tail call float @llvm.maxnum.f32(float %76, float %78) #4
  call void @llvm.lifetime.start.p5i8(i64 2, i8 addrspace(5)* %4) #4
  %mul60 = fmul float %79, 0x3FC5555560000000
  %mul61 = fmul float %cond29, %mul60
  %cmp.i379 = fcmp ult float %mul61, 4.480000e+02
  br i1 %cmp.i379, label %_Z4dec8i.exit.i.2, label %_Z4enc8f.exit.thread396

_Z4enc8f.exit.thread396:                          ; preds = %for.body34
  store i8 126, i8 addrspace(5)* %4, align 1, !tbaa !12
  br label %cond.true.i

_Z4enc8f.exit.thread:                             ; preds = %_Z4dec8i.exit.i.2
  store i8 0, i8 addrspace(5)* %4, align 1, !tbaa !12
  br label %cond.false.i377

if.end9.i:                                        ; preds = %_Z4dec8i.exit.i.2
  %sub.i382 = add nsw i32 %lo.1.i.6, -1
  %shr.i62.i = ashr i32 %sub.i382, 3
  %and.i63.i = and i32 %sub.i382, 7
  %tobool.not.i64.i = icmp eq i32 %shr.i62.i, 0
  %conv1.i70.i = sitofp i32 %and.i63.i to float
  %mul.i66.i = fmul float %conv1.i70.i, 1.250000e-01
  %add.i67.i = fadd float %mul.i66.i, 1.000000e+00
  %sub.i68.i = add nsw i32 %shr.i62.i, -7
  %80 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i67.i, i32 %sub.i68.i) #4
  %mul2.i71.i = fmul float %conv1.i70.i, 0x3F60000000000000
  %cond.i73.i = select i1 %tobool.not.i64.i, float %mul2.i71.i, float %80
  %sub11.i = fsub float %mul61, %cond.i73.i
  %shr.i49.i657 = lshr i32 %lo.1.i.6, 3
  %and.i50.i = and i32 %lo.1.i.6, 7
  %tobool.not.i51.i = icmp eq i32 %shr.i49.i657, 0
  %conv1.i57.i = sitofp i32 %and.i50.i to float
  %mul.i53.i = fmul float %conv1.i57.i, 1.250000e-01
  %add.i54.i = fadd float %mul.i53.i, 1.000000e+00
  %sub.i55.i = add nsw i32 %shr.i49.i657, -7
  %81 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i54.i, i32 %sub.i55.i) #4
  %mul2.i58.i = fmul float %conv1.i57.i, 0x3F60000000000000
  %cond.i60.i = select i1 %tobool.not.i51.i, float %mul2.i58.i, float %81
  %sub13.i = fsub float %cond.i60.i, %mul61
  %cmp14.i = fcmp olt float %sub11.i, %sub13.i
  br i1 %cmp14.i, label %_Z4enc8f.exit, label %cond.false.i384

cond.false.i384:                                  ; preds = %if.end9.i
  %cmp16.i383 = fcmp olt float %sub13.i, %sub11.i
  %and.i385 = and i32 %lo.1.i.6, 1
  %tobool.not.i386 = icmp eq i32 %and.i385, 0
  %cond.i387 = select i1 %tobool.not.i386, i32 %lo.1.i.6, i32 %sub.i382
  br i1 %cmp16.i383, label %_Z4enc8f.exit, label %cond.false18.i

cond.false18.i:                                   ; preds = %cond.false.i384
  %.pre449 = and i32 %cond.i387, 7
  br label %_Z4enc8f.exit

_Z4enc8f.exit:                                    ; preds = %cond.false18.i, %cond.false.i384, %if.end9.i
  %and.i375.pre-phi = phi i32 [ %and.i63.i, %if.end9.i ], [ %and.i50.i, %cond.false.i384 ], [ %.pre449, %cond.false18.i ]
  %cond25.i = phi i32 [ %sub.i382, %if.end9.i ], [ %lo.1.i.6, %cond.false.i384 ], [ %cond.i387, %cond.false18.i ]
  %conv.i388 = trunc i32 %cond25.i to i8
  store i8 %conv.i388, i8 addrspace(5)* %4, align 1, !tbaa !12
  %conv67 = lshr i32 %cond25.i, 3
  %tobool.not.i = icmp eq i32 %conv67, 0
  br i1 %tobool.not.i, label %cond.false.i377, label %cond.true.i

cond.true.i:                                      ; preds = %_Z4enc8f.exit, %_Z4enc8f.exit.thread396
  %and.i375404 = phi i32 [ 6, %_Z4enc8f.exit.thread396 ], [ %and.i375.pre-phi, %_Z4enc8f.exit ]
  %shr.i374403 = phi i32 [ 15, %_Z4enc8f.exit.thread396 ], [ %conv67, %_Z4enc8f.exit ]
  %conv.i376 = sitofp i32 %and.i375404 to float
  %mul.i = fmul float %conv.i376, 1.250000e-01
  %add.i = fadd float %mul.i, 1.000000e+00
  %sub.i = add nsw i32 %shr.i374403, -7
  %82 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i, i32 %sub.i) #4
  br label %_Z4dec8i.exit

cond.false.i377:                                  ; preds = %_Z4enc8f.exit, %_Z4enc8f.exit.thread
  %and.i375395 = phi i32 [ 0, %_Z4enc8f.exit.thread ], [ %and.i375.pre-phi, %_Z4enc8f.exit ]
  %conv1.i = sitofp i32 %and.i375395 to float
  %mul2.i = fmul float %conv1.i, 0x3F60000000000000
  br label %_Z4dec8i.exit

_Z4dec8i.exit:                                    ; preds = %cond.false.i377, %cond.true.i
  %cond.i378 = phi float [ %82, %cond.true.i ], [ %mul2.i, %cond.false.i377 ]
  %cmp69 = fcmp une float %cond.i378, 0.000000e+00
  br i1 %cmp69, label %cond.end75, label %cond.end75.thread

cond.end75.thread:                                ; preds = %_Z4dec8i.exit
  %83 = insertelement <2 x float> %os.sroa.0.2, float 0.000000e+00, i32 0
  br label %if.then97.7

cond.end75:                                       ; preds = %_Z4dec8i.exit
  %mul72 = fmul float %div71, %cond.i378
  %div73 = fdiv float 1.000000e+00, %mul72
  %84 = insertelement <2 x float> %os.sroa.0.2, float %div73, i32 0
  %cmp81 = fcmp une float %div73, 0.000000e+00
  %div85 = fdiv float 1.000000e+00, %div73
  %cond88 = select i1 %cmp81, float %div85, float 0.000000e+00
  %cmp96 = fcmp oeq float %div73, 0.000000e+00
  br i1 %cmp96, label %if.then97.7, label %if.else.7

cond.false.i353:                                  ; preds = %for.inc138.7.1
  %cmp1.i352 = fcmp olt float %605, 7.500000e-01
  br i1 %cmp1.i352, label %_Z5pack4f.exit369, label %cond.false3.i355

cond.false3.i355:                                 ; preds = %cond.false.i353
  %cmp4.i354 = fcmp ugt float %605, 1.250000e+00
  br i1 %cmp4.i354, label %cond.false6.i357, label %_Z5pack4f.exit369

cond.false6.i357:                                 ; preds = %cond.false3.i355
  %cmp7.i356 = fcmp olt float %605, 1.750000e+00
  br i1 %cmp7.i356, label %_Z5pack4f.exit369, label %cond.false9.i359

cond.false9.i359:                                 ; preds = %cond.false6.i357
  %cmp10.i358 = fcmp ugt float %605, 2.500000e+00
  br i1 %cmp10.i358, label %cond.false12.i361, label %_Z5pack4f.exit369

cond.false12.i361:                                ; preds = %cond.false9.i359
  %cmp13.i360 = fcmp olt float %605, 3.500000e+00
  br i1 %cmp13.i360, label %_Z5pack4f.exit369, label %cond.false15.i364

cond.false15.i364:                                ; preds = %cond.false12.i361
  %cmp16.i362 = fcmp ole float %605, 5.000000e+00
  %cond.i363 = select i1 %cmp16.i362, i32 6, i32 7
  br label %_Z5pack4f.exit369

_Z5pack4f.exit369:                                ; preds = %for.inc138.7.1, %cond.false15.i364, %cond.false12.i361, %cond.false9.i359, %cond.false6.i357, %cond.false3.i355, %cond.false.i353
  %cond27.i365 = phi i32 [ 1, %cond.false.i353 ], [ 2, %cond.false3.i355 ], [ 3, %cond.false6.i357 ], [ 4, %cond.false9.i359 ], [ 5, %cond.false12.i361 ], [ %cond.i363, %cond.false15.i364 ], [ 0, %for.inc138.7.1 ]
  %85 = bitcast float %mul175 to i32
  %shr.i366 = lshr i32 %85, 28
  %and.i367 = and i32 %shr.i366, 8
  %or.i368 = or i32 %cond27.i365, %and.i367
  %mul183 = fmul float %604, %16
  %86 = tail call float @llvm.fabs.f32(float %mul183) #4
  %cmp.i = fcmp ugt float %86, 2.500000e-01
  br i1 %cmp.i, label %cond.false.i, label %_Z5pack4f.exit

cond.false.i:                                     ; preds = %_Z5pack4f.exit369
  %cmp1.i = fcmp olt float %86, 7.500000e-01
  br i1 %cmp1.i, label %_Z5pack4f.exit, label %cond.false3.i

cond.false3.i:                                    ; preds = %cond.false.i
  %cmp4.i = fcmp ugt float %86, 1.250000e+00
  br i1 %cmp4.i, label %cond.false6.i, label %_Z5pack4f.exit

cond.false6.i:                                    ; preds = %cond.false3.i
  %cmp7.i = fcmp olt float %86, 1.750000e+00
  br i1 %cmp7.i, label %_Z5pack4f.exit, label %cond.false9.i

cond.false9.i:                                    ; preds = %cond.false6.i
  %cmp10.i = fcmp ugt float %86, 2.500000e+00
  br i1 %cmp10.i, label %cond.false12.i, label %_Z5pack4f.exit

cond.false12.i:                                   ; preds = %cond.false9.i
  %cmp13.i = fcmp olt float %86, 3.500000e+00
  br i1 %cmp13.i, label %_Z5pack4f.exit, label %cond.false15.i

cond.false15.i:                                   ; preds = %cond.false12.i
  %cmp16.i = fcmp ole float %86, 5.000000e+00
  %cond.i = select i1 %cmp16.i, i32 6, i32 7
  br label %_Z5pack4f.exit

_Z5pack4f.exit:                                   ; preds = %cond.false15.i, %cond.false12.i, %cond.false9.i, %cond.false6.i, %cond.false3.i, %cond.false.i, %_Z5pack4f.exit369
  %cond27.i = phi i32 [ 0, %_Z5pack4f.exit369 ], [ 1, %cond.false.i ], [ 2, %cond.false3.i ], [ 3, %cond.false6.i ], [ 4, %cond.false9.i ], [ 5, %cond.false12.i ], [ %cond.i, %cond.false15.i ]
  %87 = bitcast float %mul183 to i32
  %shr.i = lshr i32 %87, 28
  %and.i = and i32 %shr.i, 8
  %or.i = or i32 %cond27.i, %and.i
  %shl = shl nuw nsw i32 %or.i, 4
  %or = or i32 %or.i368, %shl
  %conv185 = trunc i32 %or to i8
  %arrayidx188339 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add164
  store i8 %conv185, i8 addrspace(1)* %arrayidx188339, align 1, !tbaa !12
  %mul175.1 = fmul float %604, %20
  %88 = tail call float @llvm.fabs.f32(float %mul175.1) #4
  %cmp.i351.1 = fcmp ugt float %88, 2.500000e-01
  br i1 %cmp.i351.1, label %cond.false.i353.1, label %_Z5pack4f.exit369.1

if.then193:                                       ; preds = %_Z5pack4f.exit.7
  %div197 = sdiv i32 %rem36.decomposed, %div196.frozen
  %add198 = add nsw i32 %div197, %mul195
  %89 = mul i32 %div197, %div196.frozen
  %rem200.decomposed = sub i32 %rem36.decomposed, %89
  %mul201 = shl nsw i32 %rem200.decomposed, 2
  %add203 = add nsw i32 %rem202.decomposed, %mul201
  br label %if.end204

if.end204:                                        ; preds = %_Z5pack4f.exit.7, %if.then193
  %st.0 = phi i32 [ %add198, %if.then193 ], [ %conv9, %_Z5pack4f.exit.7 ]
  %ss.0 = phi i32 [ %add203, %if.then193 ], [ %rem36.decomposed, %_Z5pack4f.exit.7 ]
  %arrayidx206334 = getelementptr inbounds [2 x i8], [2 x i8] addrspace(5)* %code, i32 0, i32 %603
  %90 = load i8, i8 addrspace(5)* %arrayidx206334, align 1, !tbaa !12
  %conv213 = sext i32 %st.0 to i64
  %add214 = add nsw i64 %mul156, %conv213
  %mul216 = mul nsw i64 %add214, %conv215
  %conv217 = sext i32 %ss.0 to i64
  %add218 = add nsw i64 %mul216, %conv217
  %arrayidx219335 = getelementptr inbounds i8, i8 addrspace(1)* %cond24.v, i64 %add218
  store i8 %90, i8 addrspace(1)* %arrayidx219335, align 1, !tbaa !12
  call void @llvm.lifetime.end.p5i8(i64 2, i8 addrspace(5)* %4) #4
  %add222 = add i32 %g.0419, %9
  %cmp32 = icmp slt i32 %add222, %mul
  br i1 %cmp32, label %for.body34, label %for.cond.cleanup33

cleanup:                                          ; preds = %for.cond.cleanup33, %entry
  ret void

_Z4dec8i.exit.i.2:                                ; preds = %for.body34
  %cmp2.i = fcmp ogt float %mul61, 1.875000e+00
  %hi.1.i = select i1 %cmp2.i, i32 126, i32 63
  %lo.1.i = select i1 %cmp2.i, i32 64, i32 0
  %div.i.1 = select i1 %cmp2.i, i32 95, i32 31
  %91 = lshr i32 %div.i.1, 3
  %sub.i.i.1 = add nsw i32 %91, -7
  %92 = tail call float @llvm.amdgcn.ldexp.f32(float 1.875000e+00, i32 %sub.i.i.1) #4
  %cmp2.i.1 = fcmp olt float %92, %mul61
  %add4.i.1 = add nuw nsw i32 %div.i.1, 1
  %hi.1.i.1 = select i1 %cmp2.i.1, i32 %hi.1.i, i32 %div.i.1
  %lo.1.i.1 = select i1 %cmp2.i.1, i32 %add4.i.1, i32 %lo.1.i
  %add.i381.2 = add nuw nsw i32 %lo.1.i.1, %hi.1.i.1
  %div.i.2 = lshr i32 %add.i381.2, 1
  %93 = lshr i32 %add.i381.2, 4
  %sub.i.i.2 = add nsw i32 %93, -7
  %94 = tail call float @llvm.amdgcn.ldexp.f32(float 1.875000e+00, i32 %sub.i.i.2) #4
  %cmp2.i.2 = fcmp olt float %94, %mul61
  %add4.i.2 = add nuw nsw i32 %div.i.2, 1
  %hi.1.i.2 = select i1 %cmp2.i.2, i32 %hi.1.i.1, i32 %div.i.2
  %lo.1.i.2 = select i1 %cmp2.i.2, i32 %add4.i.2, i32 %lo.1.i.1
  %add.i381.3 = add nuw nsw i32 %lo.1.i.2, %hi.1.i.2
  %div.i.3 = lshr i32 %add.i381.3, 1
  %95 = lshr i32 %add.i381.3, 4
  %and.i.i.3 = and i32 %div.i.3, 7
  %tobool.not.i.i.3 = icmp eq i32 %95, 0
  %conv1.i.i.3 = sitofp i32 %and.i.i.3 to float
  %mul.i.i.3 = fmul float %conv1.i.i.3, 1.250000e-01
  %add.i.i.3 = fadd float %mul.i.i.3, 1.000000e+00
  %sub.i.i.3 = add nsw i32 %95, -7
  %96 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.3, i32 %sub.i.i.3) #4
  %mul2.i.i.3 = fmul float %conv1.i.i.3, 0x3F60000000000000
  %cond.i.i.3 = select i1 %tobool.not.i.i.3, float %mul2.i.i.3, float %96
  %cmp2.i.3 = fcmp olt float %cond.i.i.3, %mul61
  %add4.i.3 = add nuw nsw i32 %div.i.3, 1
  %hi.1.i.3 = select i1 %cmp2.i.3, i32 %hi.1.i.2, i32 %div.i.3
  %lo.1.i.3 = select i1 %cmp2.i.3, i32 %add4.i.3, i32 %lo.1.i.2
  %add.i381.4 = add nuw nsw i32 %lo.1.i.3, %hi.1.i.3
  %div.i.4 = lshr i32 %add.i381.4, 1
  %97 = lshr i32 %add.i381.4, 4
  %and.i.i.4 = and i32 %div.i.4, 7
  %tobool.not.i.i.4 = icmp eq i32 %97, 0
  %conv1.i.i.4 = sitofp i32 %and.i.i.4 to float
  %mul.i.i.4 = fmul float %conv1.i.i.4, 1.250000e-01
  %add.i.i.4 = fadd float %mul.i.i.4, 1.000000e+00
  %sub.i.i.4 = add nsw i32 %97, -7
  %98 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.4, i32 %sub.i.i.4) #4
  %mul2.i.i.4 = fmul float %conv1.i.i.4, 0x3F60000000000000
  %cond.i.i.4 = select i1 %tobool.not.i.i.4, float %mul2.i.i.4, float %98
  %cmp2.i.4 = fcmp olt float %cond.i.i.4, %mul61
  %add4.i.4 = add nuw nsw i32 %div.i.4, 1
  %hi.1.i.4 = select i1 %cmp2.i.4, i32 %hi.1.i.3, i32 %div.i.4
  %lo.1.i.4 = select i1 %cmp2.i.4, i32 %add4.i.4, i32 %lo.1.i.3
  %add.i381.5 = add nuw nsw i32 %lo.1.i.4, %hi.1.i.4
  %div.i.5 = sdiv i32 %add.i381.5, 2
  %shr.i.i.5 = ashr i32 %div.i.5, 3
  %and.i.i.5 = and i32 %div.i.5, 7
  %tobool.not.i.i.5 = icmp eq i32 %shr.i.i.5, 0
  %conv1.i.i.5 = sitofp i32 %and.i.i.5 to float
  %mul.i.i.5 = fmul float %conv1.i.i.5, 1.250000e-01
  %add.i.i.5 = fadd float %mul.i.i.5, 1.000000e+00
  %sub.i.i.5 = add nsw i32 %shr.i.i.5, -7
  %99 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.5, i32 %sub.i.i.5) #4
  %mul2.i.i.5 = fmul float %conv1.i.i.5, 0x3F60000000000000
  %cond.i.i.5 = select i1 %tobool.not.i.i.5, float %mul2.i.i.5, float %99
  %cmp2.i.5 = fcmp olt float %cond.i.i.5, %mul61
  %add4.i.5 = add nuw nsw i32 %div.i.5, 1
  %hi.1.i.5 = select i1 %cmp2.i.5, i32 %hi.1.i.4, i32 %div.i.5
  %lo.1.i.5 = select i1 %cmp2.i.5, i32 %add4.i.5, i32 %lo.1.i.4
  %add.i381.6 = add nuw nsw i32 %lo.1.i.5, %hi.1.i.5
  %div.i.6 = sdiv i32 %add.i381.6, 2
  %shr.i.i.6 = ashr i32 %div.i.6, 3
  %and.i.i.6 = and i32 %div.i.6, 7
  %tobool.not.i.i.6 = icmp eq i32 %shr.i.i.6, 0
  %conv1.i.i.6 = sitofp i32 %and.i.i.6 to float
  %mul.i.i.6 = fmul float %conv1.i.i.6, 1.250000e-01
  %add.i.i.6 = fadd float %mul.i.i.6, 1.000000e+00
  %sub.i.i.6 = add nsw i32 %shr.i.i.6, -7
  %100 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.6, i32 %sub.i.i.6) #4
  %mul2.i.i.6 = fmul float %conv1.i.i.6, 0x3F60000000000000
  %cond.i.i.6 = select i1 %tobool.not.i.i.6, float %mul2.i.i.6, float %100
  %cmp2.i.6 = fcmp olt float %cond.i.i.6, %mul61
  %add4.i.6 = add nuw nsw i32 %div.i.6, 1
  %lo.1.i.6 = select i1 %cmp2.i.6, i32 %add4.i.6, i32 %lo.1.i.5
  %cmp6.i = icmp eq i32 %lo.1.i.6, 0
  br i1 %cmp6.i, label %_Z4enc8f.exit.thread, label %if.end9.i

if.else.7:                                        ; preds = %cond.end75
  %mul116 = fmul float %div73, %12
  %101 = tail call float @llvm.fabs.f32(float %mul116) #4
  %decision.interval2 = fcmp ugt float %101, 2.500000e+00
  %102 = select i1 %decision.interval2, float 3.500000e+00, float 1.750000e+00
  %103 = fcmp olt float %101, %102
  %104 = select i1 %decision.interval2, float 5.000000e+00, float 1.250000e+00
  %105 = fcmp ugt float %101, %104
  %106 = select i1 %105, float 6.000000e+00, float 4.000000e+00
  %107 = fcmp olt float %101, 7.500000e-01
  %108 = fcmp ugt float %101, 2.500000e-01
  %109 = select i1 %108, float 5.000000e-01, float 0.000000e+00
  %110 = select i1 %107, float %109, float 1.000000e+00
  %111 = select i1 %105, float 1.500000e+00, float %110
  %112 = select i1 %decision.interval2, float 3.000000e+00, float %111
  %113 = select i1 %decision.interval2, float %106, float 2.000000e+00
  %114 = select i1 %103, float %112, float %113
  %115 = tail call float @llvm.copysign.f32(float %114, float %mul116) #4
  %mul118 = fmul float %cond88, %115
  %sub = fsub float %mul118, %12
  %mul126 = fmul float %div73, %16
  %116 = tail call float @llvm.fabs.f32(float %mul126) #4
  %decision.interval3 = fcmp ugt float %116, 2.500000e+00
  %117 = select i1 %decision.interval3, float 3.500000e+00, float 1.750000e+00
  %118 = fcmp olt float %116, %117
  %119 = select i1 %decision.interval3, float 5.000000e+00, float 1.250000e+00
  %120 = fcmp ugt float %116, %119
  %121 = select i1 %120, float 6.000000e+00, float 4.000000e+00
  %122 = fcmp olt float %116, 7.500000e-01
  %123 = fcmp ugt float %116, 2.500000e-01
  %124 = select i1 %123, float 5.000000e-01, float 0.000000e+00
  %125 = select i1 %122, float %124, float 1.000000e+00
  %126 = select i1 %120, float 1.500000e+00, float %125
  %127 = select i1 %decision.interval3, float 3.000000e+00, float %126
  %128 = select i1 %decision.interval3, float %121, float 2.000000e+00
  %129 = select i1 %118, float %127, float %128
  %130 = tail call float @llvm.copysign.f32(float %129, float %mul126) #4
  %mul128 = fmul float %cond88, %130
  %sub132 = fsub float %mul128, %16
  %mul133 = fmul float %sub, %sub
  %mul134 = fmul float %sub132, %sub132
  %add135 = fadd float %mul133, %mul134
  %e.1 = fadd float %add135, 0.000000e+00
  %mul116.1 = fmul float %div73, %20
  %131 = tail call float @llvm.fabs.f32(float %mul116.1) #4
  %decision.interval4 = fcmp ugt float %131, 2.500000e+00
  %132 = select i1 %decision.interval4, float 3.500000e+00, float 1.750000e+00
  %133 = fcmp olt float %131, %132
  %134 = select i1 %decision.interval4, float 5.000000e+00, float 1.250000e+00
  %135 = fcmp ugt float %131, %134
  %136 = select i1 %135, float 6.000000e+00, float 4.000000e+00
  %137 = fcmp olt float %131, 7.500000e-01
  %138 = fcmp ugt float %131, 2.500000e-01
  %139 = select i1 %138, float 5.000000e-01, float 0.000000e+00
  %140 = select i1 %137, float %139, float 1.000000e+00
  %141 = select i1 %135, float 1.500000e+00, float %140
  %142 = select i1 %decision.interval4, float 3.000000e+00, float %141
  %143 = select i1 %decision.interval4, float %136, float 2.000000e+00
  %144 = select i1 %133, float %142, float %143
  %145 = tail call float @llvm.copysign.f32(float %144, float %mul116.1) #4
  %mul118.1 = fmul float %cond88, %145
  %sub.1 = fsub float %mul118.1, %20
  %mul126.1 = fmul float %div73, %24
  %146 = tail call float @llvm.fabs.f32(float %mul126.1) #4
  %decision.interval5 = fcmp ugt float %146, 2.500000e+00
  %147 = select i1 %decision.interval5, float 3.500000e+00, float 1.750000e+00
  %148 = fcmp olt float %146, %147
  %149 = select i1 %decision.interval5, float 5.000000e+00, float 1.250000e+00
  %150 = fcmp ugt float %146, %149
  %151 = select i1 %150, float 6.000000e+00, float 4.000000e+00
  %152 = fcmp olt float %146, 7.500000e-01
  %153 = fcmp ugt float %146, 2.500000e-01
  %154 = select i1 %153, float 5.000000e-01, float 0.000000e+00
  %155 = select i1 %152, float %154, float 1.000000e+00
  %156 = select i1 %150, float 1.500000e+00, float %155
  %157 = select i1 %decision.interval5, float 3.000000e+00, float %156
  %158 = select i1 %decision.interval5, float %151, float 2.000000e+00
  %159 = select i1 %148, float %157, float %158
  %160 = tail call float @llvm.copysign.f32(float %159, float %mul126.1) #4
  %mul128.1 = fmul float %cond88, %160
  %sub132.1 = fsub float %mul128.1, %24
  %mul133.1 = fmul float %sub.1, %sub.1
  %mul134.1 = fmul float %sub132.1, %sub132.1
  %add135.1 = fadd float %mul133.1, %mul134.1
  %e.1.1 = fadd float %e.1, %add135.1
  %mul116.2 = fmul float %div73, %28
  %161 = tail call float @llvm.fabs.f32(float %mul116.2) #4
  %decision.interval6 = fcmp ugt float %161, 2.500000e+00
  %162 = select i1 %decision.interval6, float 3.500000e+00, float 1.750000e+00
  %163 = fcmp olt float %161, %162
  %164 = select i1 %decision.interval6, float 5.000000e+00, float 1.250000e+00
  %165 = fcmp ugt float %161, %164
  %166 = select i1 %165, float 6.000000e+00, float 4.000000e+00
  %167 = fcmp olt float %161, 7.500000e-01
  %168 = fcmp ugt float %161, 2.500000e-01
  %169 = select i1 %168, float 5.000000e-01, float 0.000000e+00
  %170 = select i1 %167, float %169, float 1.000000e+00
  %171 = select i1 %165, float 1.500000e+00, float %170
  %172 = select i1 %decision.interval6, float 3.000000e+00, float %171
  %173 = select i1 %decision.interval6, float %166, float 2.000000e+00
  %174 = select i1 %163, float %172, float %173
  %175 = tail call float @llvm.copysign.f32(float %174, float %mul116.2) #4
  %mul118.2 = fmul float %cond88, %175
  %sub.2 = fsub float %mul118.2, %28
  %mul126.2 = fmul float %div73, %32
  %176 = tail call float @llvm.fabs.f32(float %mul126.2) #4
  %decision.interval7 = fcmp ugt float %176, 2.500000e+00
  %177 = select i1 %decision.interval7, float 3.500000e+00, float 1.750000e+00
  %178 = fcmp olt float %176, %177
  %179 = select i1 %decision.interval7, float 5.000000e+00, float 1.250000e+00
  %180 = fcmp ugt float %176, %179
  %181 = select i1 %180, float 6.000000e+00, float 4.000000e+00
  %182 = fcmp olt float %176, 7.500000e-01
  %183 = fcmp ugt float %176, 2.500000e-01
  %184 = select i1 %183, float 5.000000e-01, float 0.000000e+00
  %185 = select i1 %182, float %184, float 1.000000e+00
  %186 = select i1 %180, float 1.500000e+00, float %185
  %187 = select i1 %decision.interval7, float 3.000000e+00, float %186
  %188 = select i1 %decision.interval7, float %181, float 2.000000e+00
  %189 = select i1 %178, float %187, float %188
  %190 = tail call float @llvm.copysign.f32(float %189, float %mul126.2) #4
  %mul128.2 = fmul float %cond88, %190
  %sub132.2 = fsub float %mul128.2, %32
  %mul133.2 = fmul float %sub.2, %sub.2
  %mul134.2 = fmul float %sub132.2, %sub132.2
  %add135.2 = fadd float %mul133.2, %mul134.2
  %e.1.2 = fadd float %e.1.1, %add135.2
  %mul116.3 = fmul float %div73, %36
  %191 = tail call float @llvm.fabs.f32(float %mul116.3) #4
  %decision.interval8 = fcmp ugt float %191, 2.500000e+00
  %192 = select i1 %decision.interval8, float 3.500000e+00, float 1.750000e+00
  %193 = fcmp olt float %191, %192
  %194 = select i1 %decision.interval8, float 5.000000e+00, float 1.250000e+00
  %195 = fcmp ugt float %191, %194
  %196 = select i1 %195, float 6.000000e+00, float 4.000000e+00
  %197 = fcmp olt float %191, 7.500000e-01
  %198 = fcmp ugt float %191, 2.500000e-01
  %199 = select i1 %198, float 5.000000e-01, float 0.000000e+00
  %200 = select i1 %197, float %199, float 1.000000e+00
  %201 = select i1 %195, float 1.500000e+00, float %200
  %202 = select i1 %decision.interval8, float 3.000000e+00, float %201
  %203 = select i1 %decision.interval8, float %196, float 2.000000e+00
  %204 = select i1 %193, float %202, float %203
  %205 = tail call float @llvm.copysign.f32(float %204, float %mul116.3) #4
  %mul118.3 = fmul float %cond88, %205
  %sub.3 = fsub float %mul118.3, %36
  %mul126.3 = fmul float %div73, %40
  %206 = tail call float @llvm.fabs.f32(float %mul126.3) #4
  %decision.interval9 = fcmp ugt float %206, 2.500000e+00
  %207 = select i1 %decision.interval9, float 3.500000e+00, float 1.750000e+00
  %208 = fcmp olt float %206, %207
  %209 = select i1 %decision.interval9, float 5.000000e+00, float 1.250000e+00
  %210 = fcmp ugt float %206, %209
  %211 = select i1 %210, float 6.000000e+00, float 4.000000e+00
  %212 = fcmp olt float %206, 7.500000e-01
  %213 = fcmp ugt float %206, 2.500000e-01
  %214 = select i1 %213, float 5.000000e-01, float 0.000000e+00
  %215 = select i1 %212, float %214, float 1.000000e+00
  %216 = select i1 %210, float 1.500000e+00, float %215
  %217 = select i1 %decision.interval9, float 3.000000e+00, float %216
  %218 = select i1 %decision.interval9, float %211, float 2.000000e+00
  %219 = select i1 %208, float %217, float %218
  %220 = tail call float @llvm.copysign.f32(float %219, float %mul126.3) #4
  %mul128.3 = fmul float %cond88, %220
  %sub132.3 = fsub float %mul128.3, %40
  %mul133.3 = fmul float %sub.3, %sub.3
  %mul134.3 = fmul float %sub132.3, %sub132.3
  %add135.3 = fadd float %mul133.3, %mul134.3
  %e.1.3 = fadd float %e.1.2, %add135.3
  %mul116.4 = fmul float %div73, %44
  %221 = tail call float @llvm.fabs.f32(float %mul116.4) #4
  %decision.interval10 = fcmp ugt float %221, 2.500000e+00
  %222 = select i1 %decision.interval10, float 3.500000e+00, float 1.750000e+00
  %223 = fcmp olt float %221, %222
  %224 = select i1 %decision.interval10, float 5.000000e+00, float 1.250000e+00
  %225 = fcmp ugt float %221, %224
  %226 = select i1 %225, float 6.000000e+00, float 4.000000e+00
  %227 = fcmp olt float %221, 7.500000e-01
  %228 = fcmp ugt float %221, 2.500000e-01
  %229 = select i1 %228, float 5.000000e-01, float 0.000000e+00
  %230 = select i1 %227, float %229, float 1.000000e+00
  %231 = select i1 %225, float 1.500000e+00, float %230
  %232 = select i1 %decision.interval10, float 3.000000e+00, float %231
  %233 = select i1 %decision.interval10, float %226, float 2.000000e+00
  %234 = select i1 %223, float %232, float %233
  %235 = tail call float @llvm.copysign.f32(float %234, float %mul116.4) #4
  %mul118.4 = fmul float %cond88, %235
  %sub.4 = fsub float %mul118.4, %44
  %mul126.4 = fmul float %div73, %48
  %236 = tail call float @llvm.fabs.f32(float %mul126.4) #4
  %decision.interval11 = fcmp ugt float %236, 2.500000e+00
  %237 = select i1 %decision.interval11, float 3.500000e+00, float 1.750000e+00
  %238 = fcmp olt float %236, %237
  %239 = select i1 %decision.interval11, float 5.000000e+00, float 1.250000e+00
  %240 = fcmp ugt float %236, %239
  %241 = select i1 %240, float 6.000000e+00, float 4.000000e+00
  %242 = fcmp olt float %236, 7.500000e-01
  %243 = fcmp ugt float %236, 2.500000e-01
  %244 = select i1 %243, float 5.000000e-01, float 0.000000e+00
  %245 = select i1 %242, float %244, float 1.000000e+00
  %246 = select i1 %240, float 1.500000e+00, float %245
  %247 = select i1 %decision.interval11, float 3.000000e+00, float %246
  %248 = select i1 %decision.interval11, float %241, float 2.000000e+00
  %249 = select i1 %238, float %247, float %248
  %250 = tail call float @llvm.copysign.f32(float %249, float %mul126.4) #4
  %mul128.4 = fmul float %cond88, %250
  %sub132.4 = fsub float %mul128.4, %48
  %mul133.4 = fmul float %sub.4, %sub.4
  %mul134.4 = fmul float %sub132.4, %sub132.4
  %add135.4 = fadd float %mul133.4, %mul134.4
  %e.1.4 = fadd float %e.1.3, %add135.4
  %mul116.5 = fmul float %div73, %52
  %251 = tail call float @llvm.fabs.f32(float %mul116.5) #4
  %decision.interval12 = fcmp ugt float %251, 2.500000e+00
  %252 = select i1 %decision.interval12, float 3.500000e+00, float 1.750000e+00
  %253 = fcmp olt float %251, %252
  %254 = select i1 %decision.interval12, float 5.000000e+00, float 1.250000e+00
  %255 = fcmp ugt float %251, %254
  %256 = select i1 %255, float 6.000000e+00, float 4.000000e+00
  %257 = fcmp olt float %251, 7.500000e-01
  %258 = fcmp ugt float %251, 2.500000e-01
  %259 = select i1 %258, float 5.000000e-01, float 0.000000e+00
  %260 = select i1 %257, float %259, float 1.000000e+00
  %261 = select i1 %255, float 1.500000e+00, float %260
  %262 = select i1 %decision.interval12, float 3.000000e+00, float %261
  %263 = select i1 %decision.interval12, float %256, float 2.000000e+00
  %264 = select i1 %253, float %262, float %263
  %265 = tail call float @llvm.copysign.f32(float %264, float %mul116.5) #4
  %mul118.5 = fmul float %cond88, %265
  %sub.5 = fsub float %mul118.5, %52
  %mul126.5 = fmul float %div73, %56
  %266 = tail call float @llvm.fabs.f32(float %mul126.5) #4
  %decision.interval13 = fcmp ugt float %266, 2.500000e+00
  %267 = select i1 %decision.interval13, float 3.500000e+00, float 1.750000e+00
  %268 = fcmp olt float %266, %267
  %269 = select i1 %decision.interval13, float 5.000000e+00, float 1.250000e+00
  %270 = fcmp ugt float %266, %269
  %271 = select i1 %270, float 6.000000e+00, float 4.000000e+00
  %272 = fcmp olt float %266, 7.500000e-01
  %273 = fcmp ugt float %266, 2.500000e-01
  %274 = select i1 %273, float 5.000000e-01, float 0.000000e+00
  %275 = select i1 %272, float %274, float 1.000000e+00
  %276 = select i1 %270, float 1.500000e+00, float %275
  %277 = select i1 %decision.interval13, float 3.000000e+00, float %276
  %278 = select i1 %decision.interval13, float %271, float 2.000000e+00
  %279 = select i1 %268, float %277, float %278
  %280 = tail call float @llvm.copysign.f32(float %279, float %mul126.5) #4
  %mul128.5 = fmul float %cond88, %280
  %sub132.5 = fsub float %mul128.5, %56
  %mul133.5 = fmul float %sub.5, %sub.5
  %mul134.5 = fmul float %sub132.5, %sub132.5
  %add135.5 = fadd float %mul133.5, %mul134.5
  %e.1.5 = fadd float %e.1.4, %add135.5
  %mul116.6 = fmul float %div73, %60
  %281 = tail call float @llvm.fabs.f32(float %mul116.6) #4
  %decision.interval14 = fcmp ugt float %281, 2.500000e+00
  %282 = select i1 %decision.interval14, float 3.500000e+00, float 1.750000e+00
  %283 = fcmp olt float %281, %282
  %284 = select i1 %decision.interval14, float 5.000000e+00, float 1.250000e+00
  %285 = fcmp ugt float %281, %284
  %286 = select i1 %285, float 6.000000e+00, float 4.000000e+00
  %287 = fcmp olt float %281, 7.500000e-01
  %288 = fcmp ugt float %281, 2.500000e-01
  %289 = select i1 %288, float 5.000000e-01, float 0.000000e+00
  %290 = select i1 %287, float %289, float 1.000000e+00
  %291 = select i1 %285, float 1.500000e+00, float %290
  %292 = select i1 %decision.interval14, float 3.000000e+00, float %291
  %293 = select i1 %decision.interval14, float %286, float 2.000000e+00
  %294 = select i1 %283, float %292, float %293
  %295 = tail call float @llvm.copysign.f32(float %294, float %mul116.6) #4
  %mul118.6 = fmul float %cond88, %295
  %sub.6 = fsub float %mul118.6, %60
  %mul126.6 = fmul float %div73, %64
  %296 = tail call float @llvm.fabs.f32(float %mul126.6) #4
  %decision.interval15 = fcmp ugt float %296, 2.500000e+00
  %297 = select i1 %decision.interval15, float 3.500000e+00, float 1.750000e+00
  %298 = fcmp olt float %296, %297
  %299 = select i1 %decision.interval15, float 5.000000e+00, float 1.250000e+00
  %300 = fcmp ugt float %296, %299
  %301 = select i1 %300, float 6.000000e+00, float 4.000000e+00
  %302 = fcmp olt float %296, 7.500000e-01
  %303 = fcmp ugt float %296, 2.500000e-01
  %304 = select i1 %303, float 5.000000e-01, float 0.000000e+00
  %305 = select i1 %302, float %304, float 1.000000e+00
  %306 = select i1 %300, float 1.500000e+00, float %305
  %307 = select i1 %decision.interval15, float 3.000000e+00, float %306
  %308 = select i1 %decision.interval15, float %301, float 2.000000e+00
  %309 = select i1 %298, float %307, float %308
  %310 = tail call float @llvm.copysign.f32(float %309, float %mul126.6) #4
  %mul128.6 = fmul float %cond88, %310
  %sub132.6 = fsub float %mul128.6, %64
  %mul133.6 = fmul float %sub.6, %sub.6
  %mul134.6 = fmul float %sub132.6, %sub132.6
  %add135.6 = fadd float %mul133.6, %mul134.6
  %e.1.6 = fadd float %e.1.5, %add135.6
  %mul116.7 = fmul float %div73, %74
  %311 = tail call float @llvm.fabs.f32(float %mul116.7) #4
  %decision.interval16 = fcmp ugt float %311, 2.500000e+00
  %312 = select i1 %decision.interval16, float 3.500000e+00, float 1.750000e+00
  %313 = fcmp olt float %311, %312
  %314 = select i1 %decision.interval16, float 5.000000e+00, float 1.250000e+00
  %315 = fcmp ugt float %311, %314
  %316 = select i1 %315, float 6.000000e+00, float 4.000000e+00
  %317 = fcmp olt float %311, 7.500000e-01
  %318 = fcmp ugt float %311, 2.500000e-01
  %319 = select i1 %318, float 5.000000e-01, float 0.000000e+00
  %320 = select i1 %317, float %319, float 1.000000e+00
  %321 = select i1 %315, float 1.500000e+00, float %320
  %322 = select i1 %decision.interval16, float 3.000000e+00, float %321
  %323 = select i1 %decision.interval16, float %316, float 2.000000e+00
  %324 = select i1 %313, float %322, float %323
  %325 = tail call float @llvm.copysign.f32(float %324, float %mul116.7) #4
  %mul118.7 = fmul float %cond88, %325
  %sub.7 = fsub float %mul118.7, %74
  %mul126.7 = fmul float %div73, %77
  %326 = tail call float @llvm.fabs.f32(float %mul126.7) #4
  %decision.interval17 = fcmp ugt float %326, 2.500000e+00
  %327 = select i1 %decision.interval17, float 3.500000e+00, float 1.750000e+00
  %328 = fcmp olt float %326, %327
  %329 = select i1 %decision.interval17, float 5.000000e+00, float 1.250000e+00
  %330 = fcmp ugt float %326, %329
  %331 = select i1 %330, float 6.000000e+00, float 4.000000e+00
  %332 = fcmp olt float %326, 7.500000e-01
  %333 = fcmp ugt float %326, 2.500000e-01
  %334 = select i1 %333, float 5.000000e-01, float 0.000000e+00
  %335 = select i1 %332, float %334, float 1.000000e+00
  %336 = select i1 %330, float 1.500000e+00, float %335
  %337 = select i1 %decision.interval17, float 3.000000e+00, float %336
  %338 = select i1 %decision.interval17, float %331, float 2.000000e+00
  %339 = select i1 %328, float %337, float %338
  %340 = tail call float @llvm.copysign.f32(float %339, float %mul126.7) #4
  %mul128.7 = fmul float %cond88, %340
  %sub132.7 = fsub float %mul128.7, %77
  %mul133.7 = fmul float %sub.7, %sub.7
  %mul134.7 = fmul float %sub132.7, %sub132.7
  br label %for.inc138.7

if.then97.7:                                      ; preds = %cond.end75, %cond.end75.thread
  %os.sroa.0.3 = phi <2 x float> [ %83, %cond.end75.thread ], [ %84, %cond.end75 ]
  %mul102 = fmul float %12, %12
  %mul109 = fmul float %16, %16
  %add110 = fadd float %mul102, %mul109
  %e.1478 = fadd float %add110, 0.000000e+00
  %mul102.1 = fmul float %20, %20
  %mul109.1 = fmul float %24, %24
  %add110.1 = fadd float %mul102.1, %mul109.1
  %e.1.1490 = fadd float %e.1478, %add110.1
  %mul102.2 = fmul float %28, %28
  %mul109.2 = fmul float %32, %32
  %add110.2 = fadd float %mul102.2, %mul109.2
  %e.1.2502 = fadd float %e.1.1490, %add110.2
  %mul102.3 = fmul float %36, %36
  %mul109.3 = fmul float %40, %40
  %add110.3 = fadd float %mul102.3, %mul109.3
  %e.1.3514 = fadd float %e.1.2502, %add110.3
  %mul102.4 = fmul float %44, %44
  %mul109.4 = fmul float %48, %48
  %add110.4 = fadd float %mul102.4, %mul109.4
  %e.1.4526 = fadd float %e.1.3514, %add110.4
  %mul102.5 = fmul float %52, %52
  %mul109.5 = fmul float %56, %56
  %add110.5 = fadd float %mul102.5, %mul109.5
  %e.1.5538 = fadd float %e.1.4526, %add110.5
  %mul102.6 = fmul float %60, %60
  %mul109.6 = fmul float %64, %64
  %add110.6 = fadd float %mul102.6, %mul109.6
  %e.1.6550 = fadd float %e.1.5538, %add110.6
  %mul102.7 = fmul float %74, %74
  %mul109.7 = fmul float %77, %77
  br label %for.inc138.7

for.inc138.7:                                     ; preds = %if.then97.7, %if.else.7
  %os.sroa.0.4 = phi <2 x float> [ %84, %if.else.7 ], [ %os.sroa.0.3, %if.then97.7 ]
  %mul109.7.sink = phi float [ %mul134.7, %if.else.7 ], [ %mul109.7, %if.then97.7 ]
  %mul102.7.sink = phi float [ %mul133.7, %if.else.7 ], [ %mul102.7, %if.then97.7 ]
  %e.1.6551 = phi float [ %e.1.6, %if.else.7 ], [ %e.1.6550, %if.then97.7 ]
  %add110.7 = fadd float %mul109.7.sink, %mul102.7.sink
  %e.1.7 = fadd float %e.1.6551, %add110.7
  %mul60.1 = fmul float %79, 2.500000e-01
  %mul61.1 = fmul float %cond29, %mul60.1
  %cmp.i379.1 = fcmp ult float %mul61.1, 4.480000e+02
  br i1 %cmp.i379.1, label %_Z4dec8i.exit.i.2.1, label %_Z4enc8f.exit.thread396.1

_Z4enc8f.exit.thread396.1:                        ; preds = %for.inc138.7
  store i8 126, i8 addrspace(5)* %arrayidx64340398.1, align 1, !tbaa !12
  br label %cond.true.i.1

_Z4dec8i.exit.i.2.1:                              ; preds = %for.inc138.7
  %cmp2.i.1424 = fcmp ogt float %mul61.1, 1.875000e+00
  %hi.1.i.1425 = select i1 %cmp2.i.1424, i32 126, i32 63
  %lo.1.i.1426 = select i1 %cmp2.i.1424, i32 64, i32 0
  %div.i.1.1 = select i1 %cmp2.i.1424, i32 95, i32 31
  %341 = lshr i32 %div.i.1.1, 3
  %sub.i.i.1.1 = add nsw i32 %341, -7
  %342 = tail call float @llvm.amdgcn.ldexp.f32(float 1.875000e+00, i32 %sub.i.i.1.1) #4
  %cmp2.i.1.1 = fcmp olt float %342, %mul61.1
  %add4.i.1.1 = add nuw nsw i32 %div.i.1.1, 1
  %hi.1.i.1.1 = select i1 %cmp2.i.1.1, i32 %hi.1.i.1425, i32 %div.i.1.1
  %lo.1.i.1.1 = select i1 %cmp2.i.1.1, i32 %add4.i.1.1, i32 %lo.1.i.1426
  %add.i381.2.1 = add nuw nsw i32 %lo.1.i.1.1, %hi.1.i.1.1
  %div.i.2.1 = lshr i32 %add.i381.2.1, 1
  %343 = lshr i32 %add.i381.2.1, 4
  %sub.i.i.2.1 = add nsw i32 %343, -7
  %344 = tail call float @llvm.amdgcn.ldexp.f32(float 1.875000e+00, i32 %sub.i.i.2.1) #4
  %cmp2.i.2.1 = fcmp olt float %344, %mul61.1
  %add4.i.2.1 = add nuw nsw i32 %div.i.2.1, 1
  %hi.1.i.2.1 = select i1 %cmp2.i.2.1, i32 %hi.1.i.1.1, i32 %div.i.2.1
  %lo.1.i.2.1 = select i1 %cmp2.i.2.1, i32 %add4.i.2.1, i32 %lo.1.i.1.1
  %add.i381.3.1 = add nuw nsw i32 %lo.1.i.2.1, %hi.1.i.2.1
  %div.i.3.1 = lshr i32 %add.i381.3.1, 1
  %345 = lshr i32 %add.i381.3.1, 4
  %and.i.i.3.1 = and i32 %div.i.3.1, 7
  %tobool.not.i.i.3.1 = icmp eq i32 %345, 0
  %conv1.i.i.3.1 = sitofp i32 %and.i.i.3.1 to float
  %mul.i.i.3.1 = fmul float %conv1.i.i.3.1, 1.250000e-01
  %add.i.i.3.1 = fadd float %mul.i.i.3.1, 1.000000e+00
  %sub.i.i.3.1 = add nsw i32 %345, -7
  %346 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.3.1, i32 %sub.i.i.3.1) #4
  %mul2.i.i.3.1 = fmul float %conv1.i.i.3.1, 0x3F60000000000000
  %cond.i.i.3.1 = select i1 %tobool.not.i.i.3.1, float %mul2.i.i.3.1, float %346
  %cmp2.i.3.1 = fcmp olt float %cond.i.i.3.1, %mul61.1
  %add4.i.3.1 = add nuw nsw i32 %div.i.3.1, 1
  %hi.1.i.3.1 = select i1 %cmp2.i.3.1, i32 %hi.1.i.2.1, i32 %div.i.3.1
  %lo.1.i.3.1 = select i1 %cmp2.i.3.1, i32 %add4.i.3.1, i32 %lo.1.i.2.1
  %add.i381.4.1 = add nuw nsw i32 %lo.1.i.3.1, %hi.1.i.3.1
  %div.i.4.1 = lshr i32 %add.i381.4.1, 1
  %347 = lshr i32 %add.i381.4.1, 4
  %and.i.i.4.1 = and i32 %div.i.4.1, 7
  %tobool.not.i.i.4.1 = icmp eq i32 %347, 0
  %conv1.i.i.4.1 = sitofp i32 %and.i.i.4.1 to float
  %mul.i.i.4.1 = fmul float %conv1.i.i.4.1, 1.250000e-01
  %add.i.i.4.1 = fadd float %mul.i.i.4.1, 1.000000e+00
  %sub.i.i.4.1 = add nsw i32 %347, -7
  %348 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.4.1, i32 %sub.i.i.4.1) #4
  %mul2.i.i.4.1 = fmul float %conv1.i.i.4.1, 0x3F60000000000000
  %cond.i.i.4.1 = select i1 %tobool.not.i.i.4.1, float %mul2.i.i.4.1, float %348
  %cmp2.i.4.1 = fcmp olt float %cond.i.i.4.1, %mul61.1
  %add4.i.4.1 = add nuw nsw i32 %div.i.4.1, 1
  %hi.1.i.4.1 = select i1 %cmp2.i.4.1, i32 %hi.1.i.3.1, i32 %div.i.4.1
  %lo.1.i.4.1 = select i1 %cmp2.i.4.1, i32 %add4.i.4.1, i32 %lo.1.i.3.1
  %add.i381.5.1 = add nuw nsw i32 %lo.1.i.4.1, %hi.1.i.4.1
  %div.i.5.1 = sdiv i32 %add.i381.5.1, 2
  %shr.i.i.5.1 = ashr i32 %div.i.5.1, 3
  %and.i.i.5.1 = and i32 %div.i.5.1, 7
  %tobool.not.i.i.5.1 = icmp eq i32 %shr.i.i.5.1, 0
  %conv1.i.i.5.1 = sitofp i32 %and.i.i.5.1 to float
  %mul.i.i.5.1 = fmul float %conv1.i.i.5.1, 1.250000e-01
  %add.i.i.5.1 = fadd float %mul.i.i.5.1, 1.000000e+00
  %sub.i.i.5.1 = add nsw i32 %shr.i.i.5.1, -7
  %349 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.5.1, i32 %sub.i.i.5.1) #4
  %mul2.i.i.5.1 = fmul float %conv1.i.i.5.1, 0x3F60000000000000
  %cond.i.i.5.1 = select i1 %tobool.not.i.i.5.1, float %mul2.i.i.5.1, float %349
  %cmp2.i.5.1 = fcmp olt float %cond.i.i.5.1, %mul61.1
  %add4.i.5.1 = add nuw nsw i32 %div.i.5.1, 1
  %hi.1.i.5.1 = select i1 %cmp2.i.5.1, i32 %hi.1.i.4.1, i32 %div.i.5.1
  %lo.1.i.5.1 = select i1 %cmp2.i.5.1, i32 %add4.i.5.1, i32 %lo.1.i.4.1
  %add.i381.6.1 = add nuw nsw i32 %lo.1.i.5.1, %hi.1.i.5.1
  %div.i.6.1 = sdiv i32 %add.i381.6.1, 2
  %shr.i.i.6.1 = ashr i32 %div.i.6.1, 3
  %and.i.i.6.1 = and i32 %div.i.6.1, 7
  %tobool.not.i.i.6.1 = icmp eq i32 %shr.i.i.6.1, 0
  %conv1.i.i.6.1 = sitofp i32 %and.i.i.6.1 to float
  %mul.i.i.6.1 = fmul float %conv1.i.i.6.1, 1.250000e-01
  %add.i.i.6.1 = fadd float %mul.i.i.6.1, 1.000000e+00
  %sub.i.i.6.1 = add nsw i32 %shr.i.i.6.1, -7
  %350 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.6.1, i32 %sub.i.i.6.1) #4
  %mul2.i.i.6.1 = fmul float %conv1.i.i.6.1, 0x3F60000000000000
  %cond.i.i.6.1 = select i1 %tobool.not.i.i.6.1, float %mul2.i.i.6.1, float %350
  %cmp2.i.6.1 = fcmp olt float %cond.i.i.6.1, %mul61.1
  %add4.i.6.1 = add nuw nsw i32 %div.i.6.1, 1
  %lo.1.i.6.1 = select i1 %cmp2.i.6.1, i32 %add4.i.6.1, i32 %lo.1.i.5.1
  %cmp6.i.1 = icmp eq i32 %lo.1.i.6.1, 0
  br i1 %cmp6.i.1, label %_Z4enc8f.exit.thread.1, label %if.end9.i.1

if.end9.i.1:                                      ; preds = %_Z4dec8i.exit.i.2.1
  %sub.i382.1 = add nsw i32 %lo.1.i.6.1, -1
  %shr.i62.i.1 = ashr i32 %sub.i382.1, 3
  %and.i63.i.1 = and i32 %sub.i382.1, 7
  %tobool.not.i64.i.1 = icmp eq i32 %shr.i62.i.1, 0
  %conv1.i70.i.1 = sitofp i32 %and.i63.i.1 to float
  %mul.i66.i.1 = fmul float %conv1.i70.i.1, 1.250000e-01
  %add.i67.i.1 = fadd float %mul.i66.i.1, 1.000000e+00
  %sub.i68.i.1 = add nsw i32 %shr.i62.i.1, -7
  %351 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i67.i.1, i32 %sub.i68.i.1) #4
  %mul2.i71.i.1 = fmul float %conv1.i70.i.1, 0x3F60000000000000
  %cond.i73.i.1 = select i1 %tobool.not.i64.i.1, float %mul2.i71.i.1, float %351
  %sub11.i.1 = fsub float %mul61.1, %cond.i73.i.1
  %shr.i49.i.1656 = lshr i32 %lo.1.i.6.1, 3
  %and.i50.i.1 = and i32 %lo.1.i.6.1, 7
  %tobool.not.i51.i.1 = icmp eq i32 %shr.i49.i.1656, 0
  %conv1.i57.i.1 = sitofp i32 %and.i50.i.1 to float
  %mul.i53.i.1 = fmul float %conv1.i57.i.1, 1.250000e-01
  %add.i54.i.1 = fadd float %mul.i53.i.1, 1.000000e+00
  %sub.i55.i.1 = add nsw i32 %shr.i49.i.1656, -7
  %352 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i54.i.1, i32 %sub.i55.i.1) #4
  %mul2.i58.i.1 = fmul float %conv1.i57.i.1, 0x3F60000000000000
  %cond.i60.i.1 = select i1 %tobool.not.i51.i.1, float %mul2.i58.i.1, float %352
  %sub13.i.1 = fsub float %cond.i60.i.1, %mul61.1
  %cmp14.i.1 = fcmp olt float %sub11.i.1, %sub13.i.1
  br i1 %cmp14.i.1, label %_Z4enc8f.exit.1, label %cond.false.i384.1

cond.false.i384.1:                                ; preds = %if.end9.i.1
  %cmp16.i383.1 = fcmp olt float %sub13.i.1, %sub11.i.1
  %and.i385.1 = and i32 %lo.1.i.6.1, 1
  %tobool.not.i386.1 = icmp eq i32 %and.i385.1, 0
  %cond.i387.1 = select i1 %tobool.not.i386.1, i32 %lo.1.i.6.1, i32 %sub.i382.1
  br i1 %cmp16.i383.1, label %_Z4enc8f.exit.1, label %cond.false18.i.1

cond.false18.i.1:                                 ; preds = %cond.false.i384.1
  %.pre = and i32 %cond.i387.1, 7
  br label %_Z4enc8f.exit.1

_Z4enc8f.exit.1:                                  ; preds = %cond.false18.i.1, %cond.false.i384.1, %if.end9.i.1
  %and.i375.1.pre-phi = phi i32 [ %and.i63.i.1, %if.end9.i.1 ], [ %and.i50.i.1, %cond.false.i384.1 ], [ %.pre, %cond.false18.i.1 ]
  %cond25.i.1 = phi i32 [ %sub.i382.1, %if.end9.i.1 ], [ %lo.1.i.6.1, %cond.false.i384.1 ], [ %cond.i387.1, %cond.false18.i.1 ]
  %conv.i388.1 = trunc i32 %cond25.i.1 to i8
  store i8 %conv.i388.1, i8 addrspace(5)* %arrayidx64340398.1, align 1, !tbaa !12
  %conv67.1 = lshr i32 %cond25.i.1, 3
  %tobool.not.i.1 = icmp eq i32 %conv67.1, 0
  br i1 %tobool.not.i.1, label %cond.false.i377.1, label %cond.true.i.1

cond.true.i.1:                                    ; preds = %_Z4enc8f.exit.1, %_Z4enc8f.exit.thread396.1
  %and.i375404.1 = phi i32 [ 6, %_Z4enc8f.exit.thread396.1 ], [ %and.i375.1.pre-phi, %_Z4enc8f.exit.1 ]
  %shr.i374403.1 = phi i32 [ 15, %_Z4enc8f.exit.thread396.1 ], [ %conv67.1, %_Z4enc8f.exit.1 ]
  %conv.i376.1 = sitofp i32 %and.i375404.1 to float
  %mul.i.1 = fmul float %conv.i376.1, 1.250000e-01
  %add.i.1 = fadd float %mul.i.1, 1.000000e+00
  %sub.i.1 = add nsw i32 %shr.i374403.1, -7
  %353 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.1, i32 %sub.i.1) #4
  br label %_Z4dec8i.exit.1

_Z4enc8f.exit.thread.1:                           ; preds = %_Z4dec8i.exit.i.2.1
  store i8 0, i8 addrspace(5)* %arrayidx64340398.1, align 1, !tbaa !12
  br label %cond.false.i377.1

cond.false.i377.1:                                ; preds = %_Z4enc8f.exit.thread.1, %_Z4enc8f.exit.1
  %and.i375395.1 = phi i32 [ %and.i375.1.pre-phi, %_Z4enc8f.exit.1 ], [ 0, %_Z4enc8f.exit.thread.1 ]
  %conv1.i.1 = sitofp i32 %and.i375395.1 to float
  %mul2.i.1 = fmul float %conv1.i.1, 0x3F60000000000000
  br label %_Z4dec8i.exit.1

_Z4dec8i.exit.1:                                  ; preds = %cond.false.i377.1, %cond.true.i.1
  %cond.i378.1 = phi float [ %353, %cond.true.i.1 ], [ %mul2.i.1, %cond.false.i377.1 ]
  %cmp69.1 = fcmp une float %cond.i378.1, 0.000000e+00
  br i1 %cmp69.1, label %cond.end75.1, label %cond.end75.1.thread

cond.end75.1.thread:                              ; preds = %_Z4dec8i.exit.1
  %354 = insertelement <2 x float> %os.sroa.0.4, float 0.000000e+00, i32 1
  br label %if.then97.7.1

cond.end75.1:                                     ; preds = %_Z4dec8i.exit.1
  %mul72.1 = fmul float %div71, %cond.i378.1
  %div73.1 = fdiv float 1.000000e+00, %mul72.1
  %355 = insertelement <2 x float> %os.sroa.0.4, float %div73.1, i32 1
  %cmp81.1 = fcmp une float %div73.1, 0.000000e+00
  %div85.1 = fdiv float 1.000000e+00, %div73.1
  %cond88.1 = select i1 %cmp81.1, float %div85.1, float 0.000000e+00
  %cmp96.1 = fcmp oeq float %div73.1, 0.000000e+00
  br i1 %cmp96.1, label %if.then97.7.1, label %if.else.7.1

if.else.7.1:                                      ; preds = %cond.end75.1
  %mul116.1429 = fmul float %div73.1, %12
  %356 = tail call float @llvm.fabs.f32(float %mul116.1429) #4
  %decision.interval18 = fcmp ugt float %356, 2.500000e+00
  %357 = select i1 %decision.interval18, float 3.500000e+00, float 1.750000e+00
  %358 = fcmp olt float %356, %357
  %359 = select i1 %decision.interval18, float 5.000000e+00, float 1.250000e+00
  %360 = fcmp ugt float %356, %359
  %361 = select i1 %360, float 6.000000e+00, float 4.000000e+00
  %362 = fcmp olt float %356, 7.500000e-01
  %363 = fcmp ugt float %356, 2.500000e-01
  %364 = select i1 %363, float 5.000000e-01, float 0.000000e+00
  %365 = select i1 %362, float %364, float 1.000000e+00
  %366 = select i1 %360, float 1.500000e+00, float %365
  %367 = select i1 %decision.interval18, float 3.000000e+00, float %366
  %368 = select i1 %decision.interval18, float %361, float 2.000000e+00
  %369 = select i1 %358, float %367, float %368
  %370 = tail call float @llvm.copysign.f32(float %369, float %mul116.1429) #4
  %mul118.1430 = fmul float %cond88.1, %370
  %sub.1431 = fsub float %mul118.1430, %12
  %mul126.1433 = fmul float %div73.1, %16
  %371 = tail call float @llvm.fabs.f32(float %mul126.1433) #4
  %decision.interval19 = fcmp ugt float %371, 2.500000e+00
  %372 = select i1 %decision.interval19, float 3.500000e+00, float 1.750000e+00
  %373 = fcmp olt float %371, %372
  %374 = select i1 %decision.interval19, float 5.000000e+00, float 1.250000e+00
  %375 = fcmp ugt float %371, %374
  %376 = select i1 %375, float 6.000000e+00, float 4.000000e+00
  %377 = fcmp olt float %371, 7.500000e-01
  %378 = fcmp ugt float %371, 2.500000e-01
  %379 = select i1 %378, float 5.000000e-01, float 0.000000e+00
  %380 = select i1 %377, float %379, float 1.000000e+00
  %381 = select i1 %375, float 1.500000e+00, float %380
  %382 = select i1 %decision.interval19, float 3.000000e+00, float %381
  %383 = select i1 %decision.interval19, float %376, float 2.000000e+00
  %384 = select i1 %373, float %382, float %383
  %385 = tail call float @llvm.copysign.f32(float %384, float %mul126.1433) #4
  %mul128.1434 = fmul float %cond88.1, %385
  %sub132.1435 = fsub float %mul128.1434, %16
  %mul133.1436 = fmul float %sub.1431, %sub.1431
  %mul134.1437 = fmul float %sub132.1435, %sub132.1435
  %add135.1438 = fadd float %mul133.1436, %mul134.1437
  %e.1.1447 = fadd float %add135.1438, 0.000000e+00
  %mul116.1.1 = fmul float %div73.1, %20
  %386 = tail call float @llvm.fabs.f32(float %mul116.1.1) #4
  %decision.interval20 = fcmp ugt float %386, 2.500000e+00
  %387 = select i1 %decision.interval20, float 3.500000e+00, float 1.750000e+00
  %388 = fcmp olt float %386, %387
  %389 = select i1 %decision.interval20, float 5.000000e+00, float 1.250000e+00
  %390 = fcmp ugt float %386, %389
  %391 = select i1 %390, float 6.000000e+00, float 4.000000e+00
  %392 = fcmp olt float %386, 7.500000e-01
  %393 = fcmp ugt float %386, 2.500000e-01
  %394 = select i1 %393, float 5.000000e-01, float 0.000000e+00
  %395 = select i1 %392, float %394, float 1.000000e+00
  %396 = select i1 %390, float 1.500000e+00, float %395
  %397 = select i1 %decision.interval20, float 3.000000e+00, float %396
  %398 = select i1 %decision.interval20, float %391, float 2.000000e+00
  %399 = select i1 %388, float %397, float %398
  %400 = tail call float @llvm.copysign.f32(float %399, float %mul116.1.1) #4
  %mul118.1.1 = fmul float %cond88.1, %400
  %sub.1.1 = fsub float %mul118.1.1, %20
  %mul126.1.1 = fmul float %div73.1, %24
  %401 = tail call float @llvm.fabs.f32(float %mul126.1.1) #4
  %decision.interval21 = fcmp ugt float %401, 2.500000e+00
  %402 = select i1 %decision.interval21, float 3.500000e+00, float 1.750000e+00
  %403 = fcmp olt float %401, %402
  %404 = select i1 %decision.interval21, float 5.000000e+00, float 1.250000e+00
  %405 = fcmp ugt float %401, %404
  %406 = select i1 %405, float 6.000000e+00, float 4.000000e+00
  %407 = fcmp olt float %401, 7.500000e-01
  %408 = fcmp ugt float %401, 2.500000e-01
  %409 = select i1 %408, float 5.000000e-01, float 0.000000e+00
  %410 = select i1 %407, float %409, float 1.000000e+00
  %411 = select i1 %405, float 1.500000e+00, float %410
  %412 = select i1 %decision.interval21, float 3.000000e+00, float %411
  %413 = select i1 %decision.interval21, float %406, float 2.000000e+00
  %414 = select i1 %403, float %412, float %413
  %415 = tail call float @llvm.copysign.f32(float %414, float %mul126.1.1) #4
  %mul128.1.1 = fmul float %cond88.1, %415
  %sub132.1.1 = fsub float %mul128.1.1, %24
  %mul133.1.1 = fmul float %sub.1.1, %sub.1.1
  %mul134.1.1 = fmul float %sub132.1.1, %sub132.1.1
  %add135.1.1 = fadd float %mul133.1.1, %mul134.1.1
  %e.1.1.1 = fadd float %e.1.1447, %add135.1.1
  %mul116.2.1 = fmul float %div73.1, %28
  %416 = tail call float @llvm.fabs.f32(float %mul116.2.1) #4
  %decision.interval22 = fcmp ugt float %416, 2.500000e+00
  %417 = select i1 %decision.interval22, float 3.500000e+00, float 1.750000e+00
  %418 = fcmp olt float %416, %417
  %419 = select i1 %decision.interval22, float 5.000000e+00, float 1.250000e+00
  %420 = fcmp ugt float %416, %419
  %421 = select i1 %420, float 6.000000e+00, float 4.000000e+00
  %422 = fcmp olt float %416, 7.500000e-01
  %423 = fcmp ugt float %416, 2.500000e-01
  %424 = select i1 %423, float 5.000000e-01, float 0.000000e+00
  %425 = select i1 %422, float %424, float 1.000000e+00
  %426 = select i1 %420, float 1.500000e+00, float %425
  %427 = select i1 %decision.interval22, float 3.000000e+00, float %426
  %428 = select i1 %decision.interval22, float %421, float 2.000000e+00
  %429 = select i1 %418, float %427, float %428
  %430 = tail call float @llvm.copysign.f32(float %429, float %mul116.2.1) #4
  %mul118.2.1 = fmul float %cond88.1, %430
  %sub.2.1 = fsub float %mul118.2.1, %28
  %mul126.2.1 = fmul float %div73.1, %32
  %431 = tail call float @llvm.fabs.f32(float %mul126.2.1) #4
  %decision.interval23 = fcmp ugt float %431, 2.500000e+00
  %432 = select i1 %decision.interval23, float 3.500000e+00, float 1.750000e+00
  %433 = fcmp olt float %431, %432
  %434 = select i1 %decision.interval23, float 5.000000e+00, float 1.250000e+00
  %435 = fcmp ugt float %431, %434
  %436 = select i1 %435, float 6.000000e+00, float 4.000000e+00
  %437 = fcmp olt float %431, 7.500000e-01
  %438 = fcmp ugt float %431, 2.500000e-01
  %439 = select i1 %438, float 5.000000e-01, float 0.000000e+00
  %440 = select i1 %437, float %439, float 1.000000e+00
  %441 = select i1 %435, float 1.500000e+00, float %440
  %442 = select i1 %decision.interval23, float 3.000000e+00, float %441
  %443 = select i1 %decision.interval23, float %436, float 2.000000e+00
  %444 = select i1 %433, float %442, float %443
  %445 = tail call float @llvm.copysign.f32(float %444, float %mul126.2.1) #4
  %mul128.2.1 = fmul float %cond88.1, %445
  %sub132.2.1 = fsub float %mul128.2.1, %32
  %mul133.2.1 = fmul float %sub.2.1, %sub.2.1
  %mul134.2.1 = fmul float %sub132.2.1, %sub132.2.1
  %add135.2.1 = fadd float %mul133.2.1, %mul134.2.1
  %e.1.2.1 = fadd float %e.1.1.1, %add135.2.1
  %mul116.3.1 = fmul float %div73.1, %36
  %446 = tail call float @llvm.fabs.f32(float %mul116.3.1) #4
  %decision.interval24 = fcmp ugt float %446, 2.500000e+00
  %447 = select i1 %decision.interval24, float 3.500000e+00, float 1.750000e+00
  %448 = fcmp olt float %446, %447
  %449 = select i1 %decision.interval24, float 5.000000e+00, float 1.250000e+00
  %450 = fcmp ugt float %446, %449
  %451 = select i1 %450, float 6.000000e+00, float 4.000000e+00
  %452 = fcmp olt float %446, 7.500000e-01
  %453 = fcmp ugt float %446, 2.500000e-01
  %454 = select i1 %453, float 5.000000e-01, float 0.000000e+00
  %455 = select i1 %452, float %454, float 1.000000e+00
  %456 = select i1 %450, float 1.500000e+00, float %455
  %457 = select i1 %decision.interval24, float 3.000000e+00, float %456
  %458 = select i1 %decision.interval24, float %451, float 2.000000e+00
  %459 = select i1 %448, float %457, float %458
  %460 = tail call float @llvm.copysign.f32(float %459, float %mul116.3.1) #4
  %mul118.3.1 = fmul float %cond88.1, %460
  %sub.3.1 = fsub float %mul118.3.1, %36
  %mul126.3.1 = fmul float %div73.1, %40
  %461 = tail call float @llvm.fabs.f32(float %mul126.3.1) #4
  %decision.interval25 = fcmp ugt float %461, 2.500000e+00
  %462 = select i1 %decision.interval25, float 3.500000e+00, float 1.750000e+00
  %463 = fcmp olt float %461, %462
  %464 = select i1 %decision.interval25, float 5.000000e+00, float 1.250000e+00
  %465 = fcmp ugt float %461, %464
  %466 = select i1 %465, float 6.000000e+00, float 4.000000e+00
  %467 = fcmp olt float %461, 7.500000e-01
  %468 = fcmp ugt float %461, 2.500000e-01
  %469 = select i1 %468, float 5.000000e-01, float 0.000000e+00
  %470 = select i1 %467, float %469, float 1.000000e+00
  %471 = select i1 %465, float 1.500000e+00, float %470
  %472 = select i1 %decision.interval25, float 3.000000e+00, float %471
  %473 = select i1 %decision.interval25, float %466, float 2.000000e+00
  %474 = select i1 %463, float %472, float %473
  %475 = tail call float @llvm.copysign.f32(float %474, float %mul126.3.1) #4
  %mul128.3.1 = fmul float %cond88.1, %475
  %sub132.3.1 = fsub float %mul128.3.1, %40
  %mul133.3.1 = fmul float %sub.3.1, %sub.3.1
  %mul134.3.1 = fmul float %sub132.3.1, %sub132.3.1
  %add135.3.1 = fadd float %mul133.3.1, %mul134.3.1
  %e.1.3.1 = fadd float %e.1.2.1, %add135.3.1
  %mul116.4.1 = fmul float %div73.1, %44
  %476 = tail call float @llvm.fabs.f32(float %mul116.4.1) #4
  %decision.interval26 = fcmp ugt float %476, 2.500000e+00
  %477 = select i1 %decision.interval26, float 3.500000e+00, float 1.750000e+00
  %478 = fcmp olt float %476, %477
  %479 = select i1 %decision.interval26, float 5.000000e+00, float 1.250000e+00
  %480 = fcmp ugt float %476, %479
  %481 = select i1 %480, float 6.000000e+00, float 4.000000e+00
  %482 = fcmp olt float %476, 7.500000e-01
  %483 = fcmp ugt float %476, 2.500000e-01
  %484 = select i1 %483, float 5.000000e-01, float 0.000000e+00
  %485 = select i1 %482, float %484, float 1.000000e+00
  %486 = select i1 %480, float 1.500000e+00, float %485
  %487 = select i1 %decision.interval26, float 3.000000e+00, float %486
  %488 = select i1 %decision.interval26, float %481, float 2.000000e+00
  %489 = select i1 %478, float %487, float %488
  %490 = tail call float @llvm.copysign.f32(float %489, float %mul116.4.1) #4
  %mul118.4.1 = fmul float %cond88.1, %490
  %sub.4.1 = fsub float %mul118.4.1, %44
  %mul126.4.1 = fmul float %div73.1, %48
  %491 = tail call float @llvm.fabs.f32(float %mul126.4.1) #4
  %decision.interval27 = fcmp ugt float %491, 2.500000e+00
  %492 = select i1 %decision.interval27, float 3.500000e+00, float 1.750000e+00
  %493 = fcmp olt float %491, %492
  %494 = select i1 %decision.interval27, float 5.000000e+00, float 1.250000e+00
  %495 = fcmp ugt float %491, %494
  %496 = select i1 %495, float 6.000000e+00, float 4.000000e+00
  %497 = fcmp olt float %491, 7.500000e-01
  %498 = fcmp ugt float %491, 2.500000e-01
  %499 = select i1 %498, float 5.000000e-01, float 0.000000e+00
  %500 = select i1 %497, float %499, float 1.000000e+00
  %501 = select i1 %495, float 1.500000e+00, float %500
  %502 = select i1 %decision.interval27, float 3.000000e+00, float %501
  %503 = select i1 %decision.interval27, float %496, float 2.000000e+00
  %504 = select i1 %493, float %502, float %503
  %505 = tail call float @llvm.copysign.f32(float %504, float %mul126.4.1) #4
  %mul128.4.1 = fmul float %cond88.1, %505
  %sub132.4.1 = fsub float %mul128.4.1, %48
  %mul133.4.1 = fmul float %sub.4.1, %sub.4.1
  %mul134.4.1 = fmul float %sub132.4.1, %sub132.4.1
  %add135.4.1 = fadd float %mul133.4.1, %mul134.4.1
  %e.1.4.1 = fadd float %e.1.3.1, %add135.4.1
  %mul116.5.1 = fmul float %div73.1, %52
  %506 = tail call float @llvm.fabs.f32(float %mul116.5.1) #4
  %decision.interval28 = fcmp ugt float %506, 2.500000e+00
  %507 = select i1 %decision.interval28, float 3.500000e+00, float 1.750000e+00
  %508 = fcmp olt float %506, %507
  %509 = select i1 %decision.interval28, float 5.000000e+00, float 1.250000e+00
  %510 = fcmp ugt float %506, %509
  %511 = select i1 %510, float 6.000000e+00, float 4.000000e+00
  %512 = fcmp olt float %506, 7.500000e-01
  %513 = fcmp ugt float %506, 2.500000e-01
  %514 = select i1 %513, float 5.000000e-01, float 0.000000e+00
  %515 = select i1 %512, float %514, float 1.000000e+00
  %516 = select i1 %510, float 1.500000e+00, float %515
  %517 = select i1 %decision.interval28, float 3.000000e+00, float %516
  %518 = select i1 %decision.interval28, float %511, float 2.000000e+00
  %519 = select i1 %508, float %517, float %518
  %520 = tail call float @llvm.copysign.f32(float %519, float %mul116.5.1) #4
  %mul118.5.1 = fmul float %cond88.1, %520
  %sub.5.1 = fsub float %mul118.5.1, %52
  %mul126.5.1 = fmul float %div73.1, %56
  %521 = tail call float @llvm.fabs.f32(float %mul126.5.1) #4
  %decision.interval29 = fcmp ugt float %521, 2.500000e+00
  %522 = select i1 %decision.interval29, float 3.500000e+00, float 1.750000e+00
  %523 = fcmp olt float %521, %522
  %524 = select i1 %decision.interval29, float 5.000000e+00, float 1.250000e+00
  %525 = fcmp ugt float %521, %524
  %526 = select i1 %525, float 6.000000e+00, float 4.000000e+00
  %527 = fcmp olt float %521, 7.500000e-01
  %528 = fcmp ugt float %521, 2.500000e-01
  %529 = select i1 %528, float 5.000000e-01, float 0.000000e+00
  %530 = select i1 %527, float %529, float 1.000000e+00
  %531 = select i1 %525, float 1.500000e+00, float %530
  %532 = select i1 %decision.interval29, float 3.000000e+00, float %531
  %533 = select i1 %decision.interval29, float %526, float 2.000000e+00
  %534 = select i1 %523, float %532, float %533
  %535 = tail call float @llvm.copysign.f32(float %534, float %mul126.5.1) #4
  %mul128.5.1 = fmul float %cond88.1, %535
  %sub132.5.1 = fsub float %mul128.5.1, %56
  %mul133.5.1 = fmul float %sub.5.1, %sub.5.1
  %mul134.5.1 = fmul float %sub132.5.1, %sub132.5.1
  %add135.5.1 = fadd float %mul133.5.1, %mul134.5.1
  %e.1.5.1 = fadd float %e.1.4.1, %add135.5.1
  %mul116.6.1 = fmul float %div73.1, %60
  %536 = tail call float @llvm.fabs.f32(float %mul116.6.1) #4
  %decision.interval30 = fcmp ugt float %536, 2.500000e+00
  %537 = select i1 %decision.interval30, float 3.500000e+00, float 1.750000e+00
  %538 = fcmp olt float %536, %537
  %539 = select i1 %decision.interval30, float 5.000000e+00, float 1.250000e+00
  %540 = fcmp ugt float %536, %539
  %541 = select i1 %540, float 6.000000e+00, float 4.000000e+00
  %542 = fcmp olt float %536, 7.500000e-01
  %543 = fcmp ugt float %536, 2.500000e-01
  %544 = select i1 %543, float 5.000000e-01, float 0.000000e+00
  %545 = select i1 %542, float %544, float 1.000000e+00
  %546 = select i1 %540, float 1.500000e+00, float %545
  %547 = select i1 %decision.interval30, float 3.000000e+00, float %546
  %548 = select i1 %decision.interval30, float %541, float 2.000000e+00
  %549 = select i1 %538, float %547, float %548
  %550 = tail call float @llvm.copysign.f32(float %549, float %mul116.6.1) #4
  %mul118.6.1 = fmul float %cond88.1, %550
  %sub.6.1 = fsub float %mul118.6.1, %60
  %mul126.6.1 = fmul float %div73.1, %64
  %551 = tail call float @llvm.fabs.f32(float %mul126.6.1) #4
  %decision.interval31 = fcmp ugt float %551, 2.500000e+00
  %552 = select i1 %decision.interval31, float 3.500000e+00, float 1.750000e+00
  %553 = fcmp olt float %551, %552
  %554 = select i1 %decision.interval31, float 5.000000e+00, float 1.250000e+00
  %555 = fcmp ugt float %551, %554
  %556 = select i1 %555, float 6.000000e+00, float 4.000000e+00
  %557 = fcmp olt float %551, 7.500000e-01
  %558 = fcmp ugt float %551, 2.500000e-01
  %559 = select i1 %558, float 5.000000e-01, float 0.000000e+00
  %560 = select i1 %557, float %559, float 1.000000e+00
  %561 = select i1 %555, float 1.500000e+00, float %560
  %562 = select i1 %decision.interval31, float 3.000000e+00, float %561
  %563 = select i1 %decision.interval31, float %556, float 2.000000e+00
  %564 = select i1 %553, float %562, float %563
  %565 = tail call float @llvm.copysign.f32(float %564, float %mul126.6.1) #4
  %mul128.6.1 = fmul float %cond88.1, %565
  %sub132.6.1 = fsub float %mul128.6.1, %64
  %mul133.6.1 = fmul float %sub.6.1, %sub.6.1
  %mul134.6.1 = fmul float %sub132.6.1, %sub132.6.1
  %add135.6.1 = fadd float %mul133.6.1, %mul134.6.1
  %e.1.6.1 = fadd float %e.1.5.1, %add135.6.1
  %mul116.7.1 = fmul float %div73.1, %74
  %566 = tail call float @llvm.fabs.f32(float %mul116.7.1) #4
  %decision.interval32 = fcmp ugt float %566, 2.500000e+00
  %567 = select i1 %decision.interval32, float 3.500000e+00, float 1.750000e+00
  %568 = fcmp olt float %566, %567
  %569 = select i1 %decision.interval32, float 5.000000e+00, float 1.250000e+00
  %570 = fcmp ugt float %566, %569
  %571 = select i1 %570, float 6.000000e+00, float 4.000000e+00
  %572 = fcmp olt float %566, 7.500000e-01
  %573 = fcmp ugt float %566, 2.500000e-01
  %574 = select i1 %573, float 5.000000e-01, float 0.000000e+00
  %575 = select i1 %572, float %574, float 1.000000e+00
  %576 = select i1 %570, float 1.500000e+00, float %575
  %577 = select i1 %decision.interval32, float 3.000000e+00, float %576
  %578 = select i1 %decision.interval32, float %571, float 2.000000e+00
  %579 = select i1 %568, float %577, float %578
  %580 = tail call float @llvm.copysign.f32(float %579, float %mul116.7.1) #4
  %mul118.7.1 = fmul float %cond88.1, %580
  %sub.7.1 = fsub float %mul118.7.1, %74
  %mul126.7.1 = fmul float %div73.1, %77
  %581 = tail call float @llvm.fabs.f32(float %mul126.7.1) #4
  %decision.interval33 = fcmp ugt float %581, 2.500000e+00
  %582 = select i1 %decision.interval33, float 3.500000e+00, float 1.750000e+00
  %583 = fcmp olt float %581, %582
  %584 = select i1 %decision.interval33, float 5.000000e+00, float 1.250000e+00
  %585 = fcmp ugt float %581, %584
  %586 = select i1 %585, float 6.000000e+00, float 4.000000e+00
  %587 = fcmp olt float %581, 7.500000e-01
  %588 = fcmp ugt float %581, 2.500000e-01
  %589 = select i1 %588, float 5.000000e-01, float 0.000000e+00
  %590 = select i1 %587, float %589, float 1.000000e+00
  %591 = select i1 %585, float 1.500000e+00, float %590
  %592 = select i1 %decision.interval33, float 3.000000e+00, float %591
  %593 = select i1 %decision.interval33, float %586, float 2.000000e+00
  %594 = select i1 %583, float %592, float %593
  %595 = tail call float @llvm.copysign.f32(float %594, float %mul126.7.1) #4
  %mul128.7.1 = fmul float %cond88.1, %595
  %sub132.7.1 = fsub float %mul128.7.1, %77
  %596 = insertelement <2 x float> undef, float %sub132.7.1, i32 0
  %597 = insertelement <2 x float> %596, float %sub.7.1, i32 1
  %598 = fmul <2 x float> %597, %597
  br label %for.inc138.7.1

if.then97.7.1:                                    ; preds = %cond.end75.1, %cond.end75.1.thread
  %os.sroa.0.5 = phi <2 x float> [ %354, %cond.end75.1.thread ], [ %355, %cond.end75.1 ]
  %mul102.1441 = fmul float %12, %12
  %mul109.1443 = fmul float %16, %16
  %add110.1444 = fadd float %mul102.1441, %mul109.1443
  %e.1.1447581 = fadd float %add110.1444, 0.000000e+00
  %mul102.1.1 = fmul float %20, %20
  %mul109.1.1 = fmul float %24, %24
  %add110.1.1 = fadd float %mul102.1.1, %mul109.1.1
  %e.1.1.1593 = fadd float %e.1.1447581, %add110.1.1
  %mul102.2.1 = fmul float %28, %28
  %mul109.2.1 = fmul float %32, %32
  %add110.2.1 = fadd float %mul102.2.1, %mul109.2.1
  %e.1.2.1605 = fadd float %e.1.1.1593, %add110.2.1
  %mul102.3.1 = fmul float %36, %36
  %mul109.3.1 = fmul float %40, %40
  %add110.3.1 = fadd float %mul102.3.1, %mul109.3.1
  %e.1.3.1617 = fadd float %e.1.2.1605, %add110.3.1
  %mul102.4.1 = fmul float %44, %44
  %mul109.4.1 = fmul float %48, %48
  %add110.4.1 = fadd float %mul102.4.1, %mul109.4.1
  %e.1.4.1629 = fadd float %e.1.3.1617, %add110.4.1
  %mul102.5.1 = fmul float %52, %52
  %mul109.5.1 = fmul float %56, %56
  %add110.5.1 = fadd float %mul102.5.1, %mul109.5.1
  %e.1.5.1641 = fadd float %e.1.4.1629, %add110.5.1
  %mul102.6.1 = fmul float %60, %60
  %mul109.6.1 = fmul float %64, %64
  %add110.6.1 = fadd float %mul102.6.1, %mul109.6.1
  %e.1.6.1653 = fadd float %e.1.5.1641, %add110.6.1
  %599 = fmul <2 x float> %73, %73
  br label %for.inc138.7.1

for.inc138.7.1:                                   ; preds = %if.then97.7.1, %if.else.7.1
  %os.sroa.0.6 = phi <2 x float> [ %355, %if.else.7.1 ], [ %os.sroa.0.5, %if.then97.7.1 ]
  %e.1.6.1654 = phi float [ %e.1.6.1, %if.else.7.1 ], [ %e.1.6.1653, %if.then97.7.1 ]
  %600 = phi <2 x float> [ %598, %if.else.7.1 ], [ %599, %if.then97.7.1 ]
  %601 = extractelement <2 x float> %600, i32 0
  %602 = extractelement <2 x float> %600, i32 1
  %add110.7.1 = fadd float %601, %602
  %e.1.7.1 = fadd float %e.1.6.1654, %add110.7.1
  %cmp149 = fcmp olt float %e.1.7.1, %e.1.7
  %conv153 = sext i32 %div35 to i64
  %add154 = add nsw i64 %mul152, %conv153
  %mul156 = mul nsw i64 %add154, %conv
  %add158 = add nsw i64 %mul156, %rem.decomposed
  %mul161 = mul nsw i64 %add158, %conv160
  %mul162 = shl nsw i32 %rem36.decomposed, 3
  %conv163 = sext i32 %mul162 to i64
  %add164 = add nsw i64 %mul161, %conv163
  %603 = zext i1 %cmp149 to i32
  %604 = extractelement <2 x float> %os.sroa.0.6, i32 %603
  %mul175 = fmul float %604, %12
  %605 = tail call float @llvm.fabs.f32(float %mul175) #4
  %cmp.i351 = fcmp ugt float %605, 2.500000e-01
  br i1 %cmp.i351, label %cond.false.i353, label %_Z5pack4f.exit369

cond.false.i353.1:                                ; preds = %_Z5pack4f.exit
  %cmp1.i352.1 = fcmp olt float %88, 7.500000e-01
  br i1 %cmp1.i352.1, label %_Z5pack4f.exit369.1, label %cond.false3.i355.1

cond.false3.i355.1:                               ; preds = %cond.false.i353.1
  %cmp4.i354.1 = fcmp ugt float %88, 1.250000e+00
  br i1 %cmp4.i354.1, label %cond.false6.i357.1, label %_Z5pack4f.exit369.1

cond.false6.i357.1:                               ; preds = %cond.false3.i355.1
  %cmp7.i356.1 = fcmp olt float %88, 1.750000e+00
  br i1 %cmp7.i356.1, label %_Z5pack4f.exit369.1, label %cond.false9.i359.1

cond.false9.i359.1:                               ; preds = %cond.false6.i357.1
  %cmp10.i358.1 = fcmp ugt float %88, 2.500000e+00
  br i1 %cmp10.i358.1, label %cond.false12.i361.1, label %_Z5pack4f.exit369.1

cond.false12.i361.1:                              ; preds = %cond.false9.i359.1
  %cmp13.i360.1 = fcmp olt float %88, 3.500000e+00
  br i1 %cmp13.i360.1, label %_Z5pack4f.exit369.1, label %cond.false15.i364.1

cond.false15.i364.1:                              ; preds = %cond.false12.i361.1
  %cmp16.i362.1 = fcmp ole float %88, 5.000000e+00
  %cond.i363.1 = select i1 %cmp16.i362.1, i32 6, i32 7
  br label %_Z5pack4f.exit369.1

_Z5pack4f.exit369.1:                              ; preds = %cond.false15.i364.1, %cond.false12.i361.1, %cond.false9.i359.1, %cond.false6.i357.1, %cond.false3.i355.1, %cond.false.i353.1, %_Z5pack4f.exit
  %cond27.i365.1 = phi i32 [ 0, %_Z5pack4f.exit ], [ 1, %cond.false.i353.1 ], [ 2, %cond.false3.i355.1 ], [ 3, %cond.false6.i357.1 ], [ 4, %cond.false9.i359.1 ], [ 5, %cond.false12.i361.1 ], [ %cond.i363.1, %cond.false15.i364.1 ]
  %606 = bitcast float %mul175.1 to i32
  %shr.i366.1 = lshr i32 %606, 28
  %and.i367.1 = and i32 %shr.i366.1, 8
  %or.i368.1 = or i32 %cond27.i365.1, %and.i367.1
  %mul183.1 = fmul float %604, %24
  %607 = tail call float @llvm.fabs.f32(float %mul183.1) #4
  %cmp.i.1 = fcmp ugt float %607, 2.500000e-01
  br i1 %cmp.i.1, label %cond.false.i.1, label %_Z5pack4f.exit.1

cond.false.i.1:                                   ; preds = %_Z5pack4f.exit369.1
  %cmp1.i.1 = fcmp olt float %607, 7.500000e-01
  br i1 %cmp1.i.1, label %_Z5pack4f.exit.1, label %cond.false3.i.1

cond.false3.i.1:                                  ; preds = %cond.false.i.1
  %cmp4.i.1 = fcmp ugt float %607, 1.250000e+00
  br i1 %cmp4.i.1, label %cond.false6.i.1, label %_Z5pack4f.exit.1

cond.false6.i.1:                                  ; preds = %cond.false3.i.1
  %cmp7.i.1 = fcmp olt float %607, 1.750000e+00
  br i1 %cmp7.i.1, label %_Z5pack4f.exit.1, label %cond.false9.i.1

cond.false9.i.1:                                  ; preds = %cond.false6.i.1
  %cmp10.i.1 = fcmp ugt float %607, 2.500000e+00
  br i1 %cmp10.i.1, label %cond.false12.i.1, label %_Z5pack4f.exit.1

cond.false12.i.1:                                 ; preds = %cond.false9.i.1
  %cmp13.i.1 = fcmp olt float %607, 3.500000e+00
  br i1 %cmp13.i.1, label %_Z5pack4f.exit.1, label %cond.false15.i.1

cond.false15.i.1:                                 ; preds = %cond.false12.i.1
  %cmp16.i.1 = fcmp ole float %607, 5.000000e+00
  %cond.i.1 = select i1 %cmp16.i.1, i32 6, i32 7
  br label %_Z5pack4f.exit.1

_Z5pack4f.exit.1:                                 ; preds = %cond.false15.i.1, %cond.false12.i.1, %cond.false9.i.1, %cond.false6.i.1, %cond.false3.i.1, %cond.false.i.1, %_Z5pack4f.exit369.1
  %cond27.i.1 = phi i32 [ 0, %_Z5pack4f.exit369.1 ], [ 1, %cond.false.i.1 ], [ 2, %cond.false3.i.1 ], [ 3, %cond.false6.i.1 ], [ 4, %cond.false9.i.1 ], [ 5, %cond.false12.i.1 ], [ %cond.i.1, %cond.false15.i.1 ]
  %608 = bitcast float %mul183.1 to i32
  %shr.i.1 = lshr i32 %608, 28
  %and.i.1 = and i32 %shr.i.1, 8
  %or.i.1 = or i32 %cond27.i.1, %and.i.1
  %shl.1 = shl nuw nsw i32 %or.i.1, 4
  %or.1 = or i32 %or.i368.1, %shl.1
  %conv185.1 = trunc i32 %or.1 to i8
  %add187.1 = add nsw i64 %add164, 1
  %arrayidx188339.1 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add187.1
  store i8 %conv185.1, i8 addrspace(1)* %arrayidx188339.1, align 1, !tbaa !12
  %mul175.2 = fmul float %604, %28
  %609 = tail call float @llvm.fabs.f32(float %mul175.2) #4
  %cmp.i351.2 = fcmp ugt float %609, 2.500000e-01
  br i1 %cmp.i351.2, label %cond.false.i353.2, label %_Z5pack4f.exit369.2

cond.false.i353.2:                                ; preds = %_Z5pack4f.exit.1
  %cmp1.i352.2 = fcmp olt float %609, 7.500000e-01
  br i1 %cmp1.i352.2, label %_Z5pack4f.exit369.2, label %cond.false3.i355.2

cond.false3.i355.2:                               ; preds = %cond.false.i353.2
  %cmp4.i354.2 = fcmp ugt float %609, 1.250000e+00
  br i1 %cmp4.i354.2, label %cond.false6.i357.2, label %_Z5pack4f.exit369.2

cond.false6.i357.2:                               ; preds = %cond.false3.i355.2
  %cmp7.i356.2 = fcmp olt float %609, 1.750000e+00
  br i1 %cmp7.i356.2, label %_Z5pack4f.exit369.2, label %cond.false9.i359.2

cond.false9.i359.2:                               ; preds = %cond.false6.i357.2
  %cmp10.i358.2 = fcmp ugt float %609, 2.500000e+00
  br i1 %cmp10.i358.2, label %cond.false12.i361.2, label %_Z5pack4f.exit369.2

cond.false12.i361.2:                              ; preds = %cond.false9.i359.2
  %cmp13.i360.2 = fcmp olt float %609, 3.500000e+00
  br i1 %cmp13.i360.2, label %_Z5pack4f.exit369.2, label %cond.false15.i364.2

cond.false15.i364.2:                              ; preds = %cond.false12.i361.2
  %cmp16.i362.2 = fcmp ole float %609, 5.000000e+00
  %cond.i363.2 = select i1 %cmp16.i362.2, i32 6, i32 7
  br label %_Z5pack4f.exit369.2

_Z5pack4f.exit369.2:                              ; preds = %cond.false15.i364.2, %cond.false12.i361.2, %cond.false9.i359.2, %cond.false6.i357.2, %cond.false3.i355.2, %cond.false.i353.2, %_Z5pack4f.exit.1
  %cond27.i365.2 = phi i32 [ 0, %_Z5pack4f.exit.1 ], [ 1, %cond.false.i353.2 ], [ 2, %cond.false3.i355.2 ], [ 3, %cond.false6.i357.2 ], [ 4, %cond.false9.i359.2 ], [ 5, %cond.false12.i361.2 ], [ %cond.i363.2, %cond.false15.i364.2 ]
  %610 = bitcast float %mul175.2 to i32
  %shr.i366.2 = lshr i32 %610, 28
  %and.i367.2 = and i32 %shr.i366.2, 8
  %or.i368.2 = or i32 %cond27.i365.2, %and.i367.2
  %mul183.2 = fmul float %604, %32
  %611 = tail call float @llvm.fabs.f32(float %mul183.2) #4
  %cmp.i.2 = fcmp ugt float %611, 2.500000e-01
  br i1 %cmp.i.2, label %cond.false.i.2, label %_Z5pack4f.exit.2

cond.false.i.2:                                   ; preds = %_Z5pack4f.exit369.2
  %cmp1.i.2 = fcmp olt float %611, 7.500000e-01
  br i1 %cmp1.i.2, label %_Z5pack4f.exit.2, label %cond.false3.i.2

cond.false3.i.2:                                  ; preds = %cond.false.i.2
  %cmp4.i.2 = fcmp ugt float %611, 1.250000e+00
  br i1 %cmp4.i.2, label %cond.false6.i.2, label %_Z5pack4f.exit.2

cond.false6.i.2:                                  ; preds = %cond.false3.i.2
  %cmp7.i.2 = fcmp olt float %611, 1.750000e+00
  br i1 %cmp7.i.2, label %_Z5pack4f.exit.2, label %cond.false9.i.2

cond.false9.i.2:                                  ; preds = %cond.false6.i.2
  %cmp10.i.2 = fcmp ugt float %611, 2.500000e+00
  br i1 %cmp10.i.2, label %cond.false12.i.2, label %_Z5pack4f.exit.2

cond.false12.i.2:                                 ; preds = %cond.false9.i.2
  %cmp13.i.2 = fcmp olt float %611, 3.500000e+00
  br i1 %cmp13.i.2, label %_Z5pack4f.exit.2, label %cond.false15.i.2

cond.false15.i.2:                                 ; preds = %cond.false12.i.2
  %cmp16.i.2 = fcmp ole float %611, 5.000000e+00
  %cond.i.2 = select i1 %cmp16.i.2, i32 6, i32 7
  br label %_Z5pack4f.exit.2

_Z5pack4f.exit.2:                                 ; preds = %cond.false15.i.2, %cond.false12.i.2, %cond.false9.i.2, %cond.false6.i.2, %cond.false3.i.2, %cond.false.i.2, %_Z5pack4f.exit369.2
  %cond27.i.2 = phi i32 [ 0, %_Z5pack4f.exit369.2 ], [ 1, %cond.false.i.2 ], [ 2, %cond.false3.i.2 ], [ 3, %cond.false6.i.2 ], [ 4, %cond.false9.i.2 ], [ 5, %cond.false12.i.2 ], [ %cond.i.2, %cond.false15.i.2 ]
  %612 = bitcast float %mul183.2 to i32
  %shr.i.2 = lshr i32 %612, 28
  %and.i.2 = and i32 %shr.i.2, 8
  %or.i.2 = or i32 %cond27.i.2, %and.i.2
  %shl.2 = shl nuw nsw i32 %or.i.2, 4
  %or.2 = or i32 %or.i368.2, %shl.2
  %conv185.2 = trunc i32 %or.2 to i8
  %add187.2 = add nsw i64 %add164, 2
  %arrayidx188339.2 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add187.2
  store i8 %conv185.2, i8 addrspace(1)* %arrayidx188339.2, align 1, !tbaa !12
  %mul175.3 = fmul float %604, %36
  %613 = tail call float @llvm.fabs.f32(float %mul175.3) #4
  %cmp.i351.3 = fcmp ugt float %613, 2.500000e-01
  br i1 %cmp.i351.3, label %cond.false.i353.3, label %_Z5pack4f.exit369.3

cond.false.i353.3:                                ; preds = %_Z5pack4f.exit.2
  %cmp1.i352.3 = fcmp olt float %613, 7.500000e-01
  br i1 %cmp1.i352.3, label %_Z5pack4f.exit369.3, label %cond.false3.i355.3

cond.false3.i355.3:                               ; preds = %cond.false.i353.3
  %cmp4.i354.3 = fcmp ugt float %613, 1.250000e+00
  br i1 %cmp4.i354.3, label %cond.false6.i357.3, label %_Z5pack4f.exit369.3

cond.false6.i357.3:                               ; preds = %cond.false3.i355.3
  %cmp7.i356.3 = fcmp olt float %613, 1.750000e+00
  br i1 %cmp7.i356.3, label %_Z5pack4f.exit369.3, label %cond.false9.i359.3

cond.false9.i359.3:                               ; preds = %cond.false6.i357.3
  %cmp10.i358.3 = fcmp ugt float %613, 2.500000e+00
  br i1 %cmp10.i358.3, label %cond.false12.i361.3, label %_Z5pack4f.exit369.3

cond.false12.i361.3:                              ; preds = %cond.false9.i359.3
  %cmp13.i360.3 = fcmp olt float %613, 3.500000e+00
  br i1 %cmp13.i360.3, label %_Z5pack4f.exit369.3, label %cond.false15.i364.3

cond.false15.i364.3:                              ; preds = %cond.false12.i361.3
  %cmp16.i362.3 = fcmp ole float %613, 5.000000e+00
  %cond.i363.3 = select i1 %cmp16.i362.3, i32 6, i32 7
  br label %_Z5pack4f.exit369.3

_Z5pack4f.exit369.3:                              ; preds = %cond.false15.i364.3, %cond.false12.i361.3, %cond.false9.i359.3, %cond.false6.i357.3, %cond.false3.i355.3, %cond.false.i353.3, %_Z5pack4f.exit.2
  %cond27.i365.3 = phi i32 [ 0, %_Z5pack4f.exit.2 ], [ 1, %cond.false.i353.3 ], [ 2, %cond.false3.i355.3 ], [ 3, %cond.false6.i357.3 ], [ 4, %cond.false9.i359.3 ], [ 5, %cond.false12.i361.3 ], [ %cond.i363.3, %cond.false15.i364.3 ]
  %614 = bitcast float %mul175.3 to i32
  %shr.i366.3 = lshr i32 %614, 28
  %and.i367.3 = and i32 %shr.i366.3, 8
  %or.i368.3 = or i32 %cond27.i365.3, %and.i367.3
  %mul183.3 = fmul float %604, %40
  %615 = tail call float @llvm.fabs.f32(float %mul183.3) #4
  %cmp.i.3 = fcmp ugt float %615, 2.500000e-01
  br i1 %cmp.i.3, label %cond.false.i.3, label %_Z5pack4f.exit.3

cond.false.i.3:                                   ; preds = %_Z5pack4f.exit369.3
  %cmp1.i.3 = fcmp olt float %615, 7.500000e-01
  br i1 %cmp1.i.3, label %_Z5pack4f.exit.3, label %cond.false3.i.3

cond.false3.i.3:                                  ; preds = %cond.false.i.3
  %cmp4.i.3 = fcmp ugt float %615, 1.250000e+00
  br i1 %cmp4.i.3, label %cond.false6.i.3, label %_Z5pack4f.exit.3

cond.false6.i.3:                                  ; preds = %cond.false3.i.3
  %cmp7.i.3 = fcmp olt float %615, 1.750000e+00
  br i1 %cmp7.i.3, label %_Z5pack4f.exit.3, label %cond.false9.i.3

cond.false9.i.3:                                  ; preds = %cond.false6.i.3
  %cmp10.i.3 = fcmp ugt float %615, 2.500000e+00
  br i1 %cmp10.i.3, label %cond.false12.i.3, label %_Z5pack4f.exit.3

cond.false12.i.3:                                 ; preds = %cond.false9.i.3
  %cmp13.i.3 = fcmp olt float %615, 3.500000e+00
  br i1 %cmp13.i.3, label %_Z5pack4f.exit.3, label %cond.false15.i.3

cond.false15.i.3:                                 ; preds = %cond.false12.i.3
  %cmp16.i.3 = fcmp ole float %615, 5.000000e+00
  %cond.i.3 = select i1 %cmp16.i.3, i32 6, i32 7
  br label %_Z5pack4f.exit.3

_Z5pack4f.exit.3:                                 ; preds = %cond.false15.i.3, %cond.false12.i.3, %cond.false9.i.3, %cond.false6.i.3, %cond.false3.i.3, %cond.false.i.3, %_Z5pack4f.exit369.3
  %cond27.i.3 = phi i32 [ 0, %_Z5pack4f.exit369.3 ], [ 1, %cond.false.i.3 ], [ 2, %cond.false3.i.3 ], [ 3, %cond.false6.i.3 ], [ 4, %cond.false9.i.3 ], [ 5, %cond.false12.i.3 ], [ %cond.i.3, %cond.false15.i.3 ]
  %616 = bitcast float %mul183.3 to i32
  %shr.i.3 = lshr i32 %616, 28
  %and.i.3 = and i32 %shr.i.3, 8
  %or.i.3 = or i32 %cond27.i.3, %and.i.3
  %shl.3 = shl nuw nsw i32 %or.i.3, 4
  %or.3 = or i32 %or.i368.3, %shl.3
  %conv185.3 = trunc i32 %or.3 to i8
  %add187.3 = add nsw i64 %add164, 3
  %arrayidx188339.3 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add187.3
  store i8 %conv185.3, i8 addrspace(1)* %arrayidx188339.3, align 1, !tbaa !12
  %mul175.4 = fmul float %604, %44
  %617 = tail call float @llvm.fabs.f32(float %mul175.4) #4
  %cmp.i351.4 = fcmp ugt float %617, 2.500000e-01
  br i1 %cmp.i351.4, label %cond.false.i353.4, label %_Z5pack4f.exit369.4

cond.false.i353.4:                                ; preds = %_Z5pack4f.exit.3
  %cmp1.i352.4 = fcmp olt float %617, 7.500000e-01
  br i1 %cmp1.i352.4, label %_Z5pack4f.exit369.4, label %cond.false3.i355.4

cond.false3.i355.4:                               ; preds = %cond.false.i353.4
  %cmp4.i354.4 = fcmp ugt float %617, 1.250000e+00
  br i1 %cmp4.i354.4, label %cond.false6.i357.4, label %_Z5pack4f.exit369.4

cond.false6.i357.4:                               ; preds = %cond.false3.i355.4
  %cmp7.i356.4 = fcmp olt float %617, 1.750000e+00
  br i1 %cmp7.i356.4, label %_Z5pack4f.exit369.4, label %cond.false9.i359.4

cond.false9.i359.4:                               ; preds = %cond.false6.i357.4
  %cmp10.i358.4 = fcmp ugt float %617, 2.500000e+00
  br i1 %cmp10.i358.4, label %cond.false12.i361.4, label %_Z5pack4f.exit369.4

cond.false12.i361.4:                              ; preds = %cond.false9.i359.4
  %cmp13.i360.4 = fcmp olt float %617, 3.500000e+00
  br i1 %cmp13.i360.4, label %_Z5pack4f.exit369.4, label %cond.false15.i364.4

cond.false15.i364.4:                              ; preds = %cond.false12.i361.4
  %cmp16.i362.4 = fcmp ole float %617, 5.000000e+00
  %cond.i363.4 = select i1 %cmp16.i362.4, i32 6, i32 7
  br label %_Z5pack4f.exit369.4

_Z5pack4f.exit369.4:                              ; preds = %cond.false15.i364.4, %cond.false12.i361.4, %cond.false9.i359.4, %cond.false6.i357.4, %cond.false3.i355.4, %cond.false.i353.4, %_Z5pack4f.exit.3
  %cond27.i365.4 = phi i32 [ 0, %_Z5pack4f.exit.3 ], [ 1, %cond.false.i353.4 ], [ 2, %cond.false3.i355.4 ], [ 3, %cond.false6.i357.4 ], [ 4, %cond.false9.i359.4 ], [ 5, %cond.false12.i361.4 ], [ %cond.i363.4, %cond.false15.i364.4 ]
  %618 = bitcast float %mul175.4 to i32
  %shr.i366.4 = lshr i32 %618, 28
  %and.i367.4 = and i32 %shr.i366.4, 8
  %or.i368.4 = or i32 %cond27.i365.4, %and.i367.4
  %mul183.4 = fmul float %604, %48
  %619 = tail call float @llvm.fabs.f32(float %mul183.4) #4
  %cmp.i.4 = fcmp ugt float %619, 2.500000e-01
  br i1 %cmp.i.4, label %cond.false.i.4, label %_Z5pack4f.exit.4

cond.false.i.4:                                   ; preds = %_Z5pack4f.exit369.4
  %cmp1.i.4 = fcmp olt float %619, 7.500000e-01
  br i1 %cmp1.i.4, label %_Z5pack4f.exit.4, label %cond.false3.i.4

cond.false3.i.4:                                  ; preds = %cond.false.i.4
  %cmp4.i.4 = fcmp ugt float %619, 1.250000e+00
  br i1 %cmp4.i.4, label %cond.false6.i.4, label %_Z5pack4f.exit.4

cond.false6.i.4:                                  ; preds = %cond.false3.i.4
  %cmp7.i.4 = fcmp olt float %619, 1.750000e+00
  br i1 %cmp7.i.4, label %_Z5pack4f.exit.4, label %cond.false9.i.4

cond.false9.i.4:                                  ; preds = %cond.false6.i.4
  %cmp10.i.4 = fcmp ugt float %619, 2.500000e+00
  br i1 %cmp10.i.4, label %cond.false12.i.4, label %_Z5pack4f.exit.4

cond.false12.i.4:                                 ; preds = %cond.false9.i.4
  %cmp13.i.4 = fcmp olt float %619, 3.500000e+00
  br i1 %cmp13.i.4, label %_Z5pack4f.exit.4, label %cond.false15.i.4

cond.false15.i.4:                                 ; preds = %cond.false12.i.4
  %cmp16.i.4 = fcmp ole float %619, 5.000000e+00
  %cond.i.4 = select i1 %cmp16.i.4, i32 6, i32 7
  br label %_Z5pack4f.exit.4

_Z5pack4f.exit.4:                                 ; preds = %cond.false15.i.4, %cond.false12.i.4, %cond.false9.i.4, %cond.false6.i.4, %cond.false3.i.4, %cond.false.i.4, %_Z5pack4f.exit369.4
  %cond27.i.4 = phi i32 [ 0, %_Z5pack4f.exit369.4 ], [ 1, %cond.false.i.4 ], [ 2, %cond.false3.i.4 ], [ 3, %cond.false6.i.4 ], [ 4, %cond.false9.i.4 ], [ 5, %cond.false12.i.4 ], [ %cond.i.4, %cond.false15.i.4 ]
  %620 = bitcast float %mul183.4 to i32
  %shr.i.4 = lshr i32 %620, 28
  %and.i.4 = and i32 %shr.i.4, 8
  %or.i.4 = or i32 %cond27.i.4, %and.i.4
  %shl.4 = shl nuw nsw i32 %or.i.4, 4
  %or.4 = or i32 %or.i368.4, %shl.4
  %conv185.4 = trunc i32 %or.4 to i8
  %add187.4 = add nsw i64 %add164, 4
  %arrayidx188339.4 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add187.4
  store i8 %conv185.4, i8 addrspace(1)* %arrayidx188339.4, align 1, !tbaa !12
  %mul175.5 = fmul float %604, %52
  %621 = tail call float @llvm.fabs.f32(float %mul175.5) #4
  %cmp.i351.5 = fcmp ugt float %621, 2.500000e-01
  br i1 %cmp.i351.5, label %cond.false.i353.5, label %_Z5pack4f.exit369.5

cond.false.i353.5:                                ; preds = %_Z5pack4f.exit.4
  %cmp1.i352.5 = fcmp olt float %621, 7.500000e-01
  br i1 %cmp1.i352.5, label %_Z5pack4f.exit369.5, label %cond.false3.i355.5

cond.false3.i355.5:                               ; preds = %cond.false.i353.5
  %cmp4.i354.5 = fcmp ugt float %621, 1.250000e+00
  br i1 %cmp4.i354.5, label %cond.false6.i357.5, label %_Z5pack4f.exit369.5

cond.false6.i357.5:                               ; preds = %cond.false3.i355.5
  %cmp7.i356.5 = fcmp olt float %621, 1.750000e+00
  br i1 %cmp7.i356.5, label %_Z5pack4f.exit369.5, label %cond.false9.i359.5

cond.false9.i359.5:                               ; preds = %cond.false6.i357.5
  %cmp10.i358.5 = fcmp ugt float %621, 2.500000e+00
  br i1 %cmp10.i358.5, label %cond.false12.i361.5, label %_Z5pack4f.exit369.5

cond.false12.i361.5:                              ; preds = %cond.false9.i359.5
  %cmp13.i360.5 = fcmp olt float %621, 3.500000e+00
  br i1 %cmp13.i360.5, label %_Z5pack4f.exit369.5, label %cond.false15.i364.5

cond.false15.i364.5:                              ; preds = %cond.false12.i361.5
  %cmp16.i362.5 = fcmp ole float %621, 5.000000e+00
  %cond.i363.5 = select i1 %cmp16.i362.5, i32 6, i32 7
  br label %_Z5pack4f.exit369.5

_Z5pack4f.exit369.5:                              ; preds = %cond.false15.i364.5, %cond.false12.i361.5, %cond.false9.i359.5, %cond.false6.i357.5, %cond.false3.i355.5, %cond.false.i353.5, %_Z5pack4f.exit.4
  %cond27.i365.5 = phi i32 [ 0, %_Z5pack4f.exit.4 ], [ 1, %cond.false.i353.5 ], [ 2, %cond.false3.i355.5 ], [ 3, %cond.false6.i357.5 ], [ 4, %cond.false9.i359.5 ], [ 5, %cond.false12.i361.5 ], [ %cond.i363.5, %cond.false15.i364.5 ]
  %622 = bitcast float %mul175.5 to i32
  %shr.i366.5 = lshr i32 %622, 28
  %and.i367.5 = and i32 %shr.i366.5, 8
  %or.i368.5 = or i32 %cond27.i365.5, %and.i367.5
  %mul183.5 = fmul float %604, %56
  %623 = tail call float @llvm.fabs.f32(float %mul183.5) #4
  %cmp.i.5 = fcmp ugt float %623, 2.500000e-01
  br i1 %cmp.i.5, label %cond.false.i.5, label %_Z5pack4f.exit.5

cond.false.i.5:                                   ; preds = %_Z5pack4f.exit369.5
  %cmp1.i.5 = fcmp olt float %623, 7.500000e-01
  br i1 %cmp1.i.5, label %_Z5pack4f.exit.5, label %cond.false3.i.5

cond.false3.i.5:                                  ; preds = %cond.false.i.5
  %cmp4.i.5 = fcmp ugt float %623, 1.250000e+00
  br i1 %cmp4.i.5, label %cond.false6.i.5, label %_Z5pack4f.exit.5

cond.false6.i.5:                                  ; preds = %cond.false3.i.5
  %cmp7.i.5 = fcmp olt float %623, 1.750000e+00
  br i1 %cmp7.i.5, label %_Z5pack4f.exit.5, label %cond.false9.i.5

cond.false9.i.5:                                  ; preds = %cond.false6.i.5
  %cmp10.i.5 = fcmp ugt float %623, 2.500000e+00
  br i1 %cmp10.i.5, label %cond.false12.i.5, label %_Z5pack4f.exit.5

cond.false12.i.5:                                 ; preds = %cond.false9.i.5
  %cmp13.i.5 = fcmp olt float %623, 3.500000e+00
  br i1 %cmp13.i.5, label %_Z5pack4f.exit.5, label %cond.false15.i.5

cond.false15.i.5:                                 ; preds = %cond.false12.i.5
  %cmp16.i.5 = fcmp ole float %623, 5.000000e+00
  %cond.i.5 = select i1 %cmp16.i.5, i32 6, i32 7
  br label %_Z5pack4f.exit.5

_Z5pack4f.exit.5:                                 ; preds = %cond.false15.i.5, %cond.false12.i.5, %cond.false9.i.5, %cond.false6.i.5, %cond.false3.i.5, %cond.false.i.5, %_Z5pack4f.exit369.5
  %cond27.i.5 = phi i32 [ 0, %_Z5pack4f.exit369.5 ], [ 1, %cond.false.i.5 ], [ 2, %cond.false3.i.5 ], [ 3, %cond.false6.i.5 ], [ 4, %cond.false9.i.5 ], [ 5, %cond.false12.i.5 ], [ %cond.i.5, %cond.false15.i.5 ]
  %624 = bitcast float %mul183.5 to i32
  %shr.i.5 = lshr i32 %624, 28
  %and.i.5 = and i32 %shr.i.5, 8
  %or.i.5 = or i32 %cond27.i.5, %and.i.5
  %shl.5 = shl nuw nsw i32 %or.i.5, 4
  %or.5 = or i32 %or.i368.5, %shl.5
  %conv185.5 = trunc i32 %or.5 to i8
  %add187.5 = add nsw i64 %add164, 5
  %arrayidx188339.5 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add187.5
  store i8 %conv185.5, i8 addrspace(1)* %arrayidx188339.5, align 1, !tbaa !12
  %mul175.6 = fmul float %604, %60
  %625 = tail call float @llvm.fabs.f32(float %mul175.6) #4
  %cmp.i351.6 = fcmp ugt float %625, 2.500000e-01
  br i1 %cmp.i351.6, label %cond.false.i353.6, label %_Z5pack4f.exit369.6

cond.false.i353.6:                                ; preds = %_Z5pack4f.exit.5
  %cmp1.i352.6 = fcmp olt float %625, 7.500000e-01
  br i1 %cmp1.i352.6, label %_Z5pack4f.exit369.6, label %cond.false3.i355.6

cond.false3.i355.6:                               ; preds = %cond.false.i353.6
  %cmp4.i354.6 = fcmp ugt float %625, 1.250000e+00
  br i1 %cmp4.i354.6, label %cond.false6.i357.6, label %_Z5pack4f.exit369.6

cond.false6.i357.6:                               ; preds = %cond.false3.i355.6
  %cmp7.i356.6 = fcmp olt float %625, 1.750000e+00
  br i1 %cmp7.i356.6, label %_Z5pack4f.exit369.6, label %cond.false9.i359.6

cond.false9.i359.6:                               ; preds = %cond.false6.i357.6
  %cmp10.i358.6 = fcmp ugt float %625, 2.500000e+00
  br i1 %cmp10.i358.6, label %cond.false12.i361.6, label %_Z5pack4f.exit369.6

cond.false12.i361.6:                              ; preds = %cond.false9.i359.6
  %cmp13.i360.6 = fcmp olt float %625, 3.500000e+00
  br i1 %cmp13.i360.6, label %_Z5pack4f.exit369.6, label %cond.false15.i364.6

cond.false15.i364.6:                              ; preds = %cond.false12.i361.6
  %cmp16.i362.6 = fcmp ole float %625, 5.000000e+00
  %cond.i363.6 = select i1 %cmp16.i362.6, i32 6, i32 7
  br label %_Z5pack4f.exit369.6

_Z5pack4f.exit369.6:                              ; preds = %cond.false15.i364.6, %cond.false12.i361.6, %cond.false9.i359.6, %cond.false6.i357.6, %cond.false3.i355.6, %cond.false.i353.6, %_Z5pack4f.exit.5
  %cond27.i365.6 = phi i32 [ 0, %_Z5pack4f.exit.5 ], [ 1, %cond.false.i353.6 ], [ 2, %cond.false3.i355.6 ], [ 3, %cond.false6.i357.6 ], [ 4, %cond.false9.i359.6 ], [ 5, %cond.false12.i361.6 ], [ %cond.i363.6, %cond.false15.i364.6 ]
  %626 = bitcast float %mul175.6 to i32
  %shr.i366.6 = lshr i32 %626, 28
  %and.i367.6 = and i32 %shr.i366.6, 8
  %or.i368.6 = or i32 %cond27.i365.6, %and.i367.6
  %mul183.6 = fmul float %604, %64
  %627 = tail call float @llvm.fabs.f32(float %mul183.6) #4
  %cmp.i.6 = fcmp ugt float %627, 2.500000e-01
  br i1 %cmp.i.6, label %cond.false.i.6, label %_Z5pack4f.exit.6

cond.false.i.6:                                   ; preds = %_Z5pack4f.exit369.6
  %cmp1.i.6 = fcmp olt float %627, 7.500000e-01
  br i1 %cmp1.i.6, label %_Z5pack4f.exit.6, label %cond.false3.i.6

cond.false3.i.6:                                  ; preds = %cond.false.i.6
  %cmp4.i.6 = fcmp ugt float %627, 1.250000e+00
  br i1 %cmp4.i.6, label %cond.false6.i.6, label %_Z5pack4f.exit.6

cond.false6.i.6:                                  ; preds = %cond.false3.i.6
  %cmp7.i.6 = fcmp olt float %627, 1.750000e+00
  br i1 %cmp7.i.6, label %_Z5pack4f.exit.6, label %cond.false9.i.6

cond.false9.i.6:                                  ; preds = %cond.false6.i.6
  %cmp10.i.6 = fcmp ugt float %627, 2.500000e+00
  br i1 %cmp10.i.6, label %cond.false12.i.6, label %_Z5pack4f.exit.6

cond.false12.i.6:                                 ; preds = %cond.false9.i.6
  %cmp13.i.6 = fcmp olt float %627, 3.500000e+00
  br i1 %cmp13.i.6, label %_Z5pack4f.exit.6, label %cond.false15.i.6

cond.false15.i.6:                                 ; preds = %cond.false12.i.6
  %cmp16.i.6 = fcmp ole float %627, 5.000000e+00
  %cond.i.6 = select i1 %cmp16.i.6, i32 6, i32 7
  br label %_Z5pack4f.exit.6

_Z5pack4f.exit.6:                                 ; preds = %cond.false15.i.6, %cond.false12.i.6, %cond.false9.i.6, %cond.false6.i.6, %cond.false3.i.6, %cond.false.i.6, %_Z5pack4f.exit369.6
  %cond27.i.6 = phi i32 [ 0, %_Z5pack4f.exit369.6 ], [ 1, %cond.false.i.6 ], [ 2, %cond.false3.i.6 ], [ 3, %cond.false6.i.6 ], [ 4, %cond.false9.i.6 ], [ 5, %cond.false12.i.6 ], [ %cond.i.6, %cond.false15.i.6 ]
  %628 = bitcast float %mul183.6 to i32
  %shr.i.6 = lshr i32 %628, 28
  %and.i.6 = and i32 %shr.i.6, 8
  %or.i.6 = or i32 %cond27.i.6, %and.i.6
  %shl.6 = shl nuw nsw i32 %or.i.6, 4
  %or.6 = or i32 %or.i368.6, %shl.6
  %conv185.6 = trunc i32 %or.6 to i8
  %add187.6 = add nsw i64 %add164, 6
  %arrayidx188339.6 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add187.6
  store i8 %conv185.6, i8 addrspace(1)* %arrayidx188339.6, align 1, !tbaa !12
  %mul175.7 = fmul float %604, %74
  %629 = tail call float @llvm.fabs.f32(float %mul175.7) #4
  %cmp.i351.7 = fcmp ugt float %629, 2.500000e-01
  br i1 %cmp.i351.7, label %cond.false.i353.7, label %_Z5pack4f.exit369.7

cond.false.i353.7:                                ; preds = %_Z5pack4f.exit.6
  %cmp1.i352.7 = fcmp olt float %629, 7.500000e-01
  br i1 %cmp1.i352.7, label %_Z5pack4f.exit369.7, label %cond.false3.i355.7

cond.false3.i355.7:                               ; preds = %cond.false.i353.7
  %cmp4.i354.7 = fcmp ugt float %629, 1.250000e+00
  br i1 %cmp4.i354.7, label %cond.false6.i357.7, label %_Z5pack4f.exit369.7

cond.false6.i357.7:                               ; preds = %cond.false3.i355.7
  %cmp7.i356.7 = fcmp olt float %629, 1.750000e+00
  br i1 %cmp7.i356.7, label %_Z5pack4f.exit369.7, label %cond.false9.i359.7

cond.false9.i359.7:                               ; preds = %cond.false6.i357.7
  %cmp10.i358.7 = fcmp ugt float %629, 2.500000e+00
  br i1 %cmp10.i358.7, label %cond.false12.i361.7, label %_Z5pack4f.exit369.7

cond.false12.i361.7:                              ; preds = %cond.false9.i359.7
  %cmp13.i360.7 = fcmp olt float %629, 3.500000e+00
  br i1 %cmp13.i360.7, label %_Z5pack4f.exit369.7, label %cond.false15.i364.7

cond.false15.i364.7:                              ; preds = %cond.false12.i361.7
  %cmp16.i362.7 = fcmp ole float %629, 5.000000e+00
  %cond.i363.7 = select i1 %cmp16.i362.7, i32 6, i32 7
  br label %_Z5pack4f.exit369.7

_Z5pack4f.exit369.7:                              ; preds = %cond.false15.i364.7, %cond.false12.i361.7, %cond.false9.i359.7, %cond.false6.i357.7, %cond.false3.i355.7, %cond.false.i353.7, %_Z5pack4f.exit.6
  %cond27.i365.7 = phi i32 [ 0, %_Z5pack4f.exit.6 ], [ 1, %cond.false.i353.7 ], [ 2, %cond.false3.i355.7 ], [ 3, %cond.false6.i357.7 ], [ 4, %cond.false9.i359.7 ], [ 5, %cond.false12.i361.7 ], [ %cond.i363.7, %cond.false15.i364.7 ]
  %630 = bitcast float %mul175.7 to i32
  %shr.i366.7 = lshr i32 %630, 28
  %and.i367.7 = and i32 %shr.i366.7, 8
  %or.i368.7 = or i32 %cond27.i365.7, %and.i367.7
  %mul183.7 = fmul float %604, %77
  %631 = tail call float @llvm.fabs.f32(float %mul183.7) #4
  %cmp.i.7 = fcmp ugt float %631, 2.500000e-01
  br i1 %cmp.i.7, label %cond.false.i.7, label %_Z5pack4f.exit.7

cond.false.i.7:                                   ; preds = %_Z5pack4f.exit369.7
  %cmp1.i.7 = fcmp olt float %631, 7.500000e-01
  br i1 %cmp1.i.7, label %_Z5pack4f.exit.7, label %cond.false3.i.7

cond.false3.i.7:                                  ; preds = %cond.false.i.7
  %cmp4.i.7 = fcmp ugt float %631, 1.250000e+00
  br i1 %cmp4.i.7, label %cond.false6.i.7, label %_Z5pack4f.exit.7

cond.false6.i.7:                                  ; preds = %cond.false3.i.7
  %cmp7.i.7 = fcmp olt float %631, 1.750000e+00
  br i1 %cmp7.i.7, label %_Z5pack4f.exit.7, label %cond.false9.i.7

cond.false9.i.7:                                  ; preds = %cond.false6.i.7
  %cmp10.i.7 = fcmp ugt float %631, 2.500000e+00
  br i1 %cmp10.i.7, label %cond.false12.i.7, label %_Z5pack4f.exit.7

cond.false12.i.7:                                 ; preds = %cond.false9.i.7
  %cmp13.i.7 = fcmp olt float %631, 3.500000e+00
  br i1 %cmp13.i.7, label %_Z5pack4f.exit.7, label %cond.false15.i.7

cond.false15.i.7:                                 ; preds = %cond.false12.i.7
  %cmp16.i.7 = fcmp ole float %631, 5.000000e+00
  %cond.i.7 = select i1 %cmp16.i.7, i32 6, i32 7
  br label %_Z5pack4f.exit.7

_Z5pack4f.exit.7:                                 ; preds = %cond.false15.i.7, %cond.false12.i.7, %cond.false9.i.7, %cond.false6.i.7, %cond.false3.i.7, %cond.false.i.7, %_Z5pack4f.exit369.7
  %cond27.i.7 = phi i32 [ 0, %_Z5pack4f.exit369.7 ], [ 1, %cond.false.i.7 ], [ 2, %cond.false3.i.7 ], [ 3, %cond.false6.i.7 ], [ 4, %cond.false9.i.7 ], [ 5, %cond.false12.i.7 ], [ %cond.i.7, %cond.false15.i.7 ]
  %632 = bitcast float %mul183.7 to i32
  %shr.i.7 = lshr i32 %632, 28
  %and.i.7 = and i32 %shr.i.7, 8
  %or.i.7 = or i32 %cond27.i.7, %and.i.7
  %shl.7 = shl nuw nsw i32 %or.i.7, 4
  %or.7 = or i32 %or.i368.7, %shl.7
  %conv185.7 = trunc i32 %or.7 to i8
  %add187.7 = add nsw i64 %add164, 7
  %arrayidx188339.7 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add187.7
  store i8 %conv185.7, i8 addrspace(1)* %arrayidx188339.7, align 1, !tbaa !12
  br i1 %tobool.not, label %if.end204, label %if.then193
}

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.fabs.f32(float) #3

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.maxnum.f32(float, float) #3

; Function Attrs: nounwind readnone speculatable willreturn
declare float @llvm.amdgcn.ldexp.f32(float, i32) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.copysign.f32(float, float) #3

attributes #0 = { argmemonly nofree nosync nounwind willreturn }
attributes #1 = { norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #4 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/charitha22/cgo22ae-darm-code.git e9bc0540325ad9806313d34e84fc901496fd8be6)"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{!6, !6, i64 0}
!6 = !{!"long", !7, i64 0}
!7 = !{!"omnipotent char", !8, i64 0}
!8 = !{!"Simple C++ TBAA"}
!9 = !{i32 0, i32 1024}
!10 = !{!11, !11, i64 0}
!11 = !{!"short", !7, i64 0}
!12 = !{!7, !7, i64 0}
