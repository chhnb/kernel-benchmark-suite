; ModuleID = '/data/home/chh/simplify-v2/build/simplify-fingerprint/active/MapAiry/trial-339/fused.ll'
source_filename = "/home/chh/kernel-benchmark-suite/cases/boost-mapairy/source/kernel.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

@_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 0x3FE428A2F98D728B, double 0x3FE965FEA53D6E3D, double 1.000000e+00, double 0x3FF428A2F98D728B, double 0x3FF965FEA53D6E3D], align 16

; Function Attrs: nofree norecurse nounwind
define protected amdgpu_kernel void @evaluate(double addrspace(1)* nocapture readonly %input.coerce, double addrspace(1)* nocapture %output.coerce, i32 %n) local_unnamed_addr #0 {
entry:
  %0 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %1 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %2 = getelementptr i8, i8 addrspace(4)* %1, i64 4
  %3 = bitcast i8 addrspace(4)* %2 to i16 addrspace(4)*
  %4 = load i16, i16 addrspace(4)* %3, align 4, !range !5, !invariant.load !6
  %5 = zext i16 %4 to i32
  %6 = mul i32 %0, %5
  %7 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !7
  %add = add i32 %6, %7
  %cmp = icmp slt i32 %add, %n
  br i1 %cmp, label %if.end8.i.i, label %if.end

if.end8.i.i:                                      ; preds = %entry
  %idxprom = sext i32 %add to i64
  %arrayidx11 = getelementptr inbounds double, double addrspace(1)* %input.coerce, i64 %idxprom
  %arrayidx.val = load double, double addrspace(1)* %arrayidx11, align 8, !tbaa !8
  %cmp.i3.i.i = fcmp olt double %arrayidx.val, 0.000000e+00
  %cmp1.i.i.i = fcmp ogt double %arrayidx.val, 1.000000e+00
  %or.cond.i.i.i = or i1 %cmp.i3.i.i, %cmp1.i.i.i
  br i1 %or.cond.i.i.i, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %lor.lhs.false2.i.i.i

lor.lhs.false2.i.i.i:                             ; preds = %if.end8.i.i
  %cmp.i.i.i.i.i = fcmp uno double %arrayidx.val, 0.000000e+00
  %cmp.i3.i.i.i.i = fcmp ogt double %arrayidx.val, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i4.i.i = fcmp olt double %arrayidx.val, 0xFFEFFFFFFFFFFFFF
  %lnot.i.i.i.i.not = or i1 %cmp.i3.i.i.i.i, %cmp1.i.i.i4.i.i
  %brmerge = or i1 %cmp.i.i.i.i.i, %lnot.i.i.i.i.not
  br i1 %brmerge, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %if.end14.i.i

if.end14.i.i:                                     ; preds = %lor.lhs.false2.i.i.i
  %cmp.i.i.i = fcmp ogt double %arrayidx.val, 5.000000e-01
  br i1 %cmp.i.i.i, label %if.then.i.i.i, label %cond.false7.i.i.i

if.then.i.i.i:                                    ; preds = %if.end14.i.i
  %sub.i.i.i = fsub double 1.000000e+00, %arrayidx.val
  %decision.interval = fcmp ult double %sub.i.i.i, 1.250000e-01
  br i1 %decision.interval, label %if.else9.i.i.i.i, label %decision.dispatch, !decision.condition_prefix !6

decision.dispatch:                                ; preds = %if.then.i.i.i
  %cmp.i.i.i.i = fcmp ult double %sub.i.i.i, 2.500000e-01
  %8 = select i1 %cmp.i.i.i.i, double -1.250000e-01, double -2.500000e-01
  %9 = fadd double %sub.i.i.i, %8
  %10 = fmul double %9, %9
  %11 = select i1 %cmp.i.i.i.i, double 0x409819CEF5B4E6C7, double 0x404567B47A5D8CA4
  %12 = fmul double %10, %11
  %13 = fsub double 0x405E69E51891A050, %12
  %14 = fadd double %12, 0xC096FC492E087B38
  %fusion.paired = select i1 %cmp.i.i.i.i, double %14, double %13
  %15 = select i1 %cmp.i.i.i.i, double 0x4051B7FD7FEEB259, double 0x4050AAC38C60A1E3
  %16 = fmul double %10, %15
  %17 = select i1 %cmp.i.i.i.i, double 0xC07E56261CB553E9, double 0x40548E4AE13E33D8
  %18 = fsub double %17, %16
  %19 = fmul double %10, %fusion.paired
  %20 = fmul double %10, %18
  %21 = select i1 %cmp.i.i.i.i, double 0x4036AD73494335DA, double 0xC04860792DC1D02E
  %22 = fadd double %19, %21
  %23 = select i1 %cmp.i.i.i.i, double 0x4034FFCB850049DF, double 0xC0407FAA65922A12
  %24 = fadd double %20, %23
  %25 = fmul double %10, %22
  %26 = select i1 %cmp.i.i.i.i, double 0x3FFB3E8B8B7EC8F9, double 0xC005F196AB7EF904
  %27 = fadd double %25, %26
  %28 = select i1 %cmp.i.i.i.i, double %24, double %27
  %29 = fmul double %9, %28
  %30 = select i1 %cmp.i.i.i.i, double 0x4071AEC837B9190D, double 0x3FF51F0306685285
  %31 = fmul double %10, %30
  %32 = select i1 %cmp.i.i.i.i, double 0x406A5A0FD2D4B901, double 0xBFEEB82FAA589934
  %33 = fsub double %32, %31
  br i1 %cmp.i.i.i.i, label %fusion.suffix1, label %fusion.side5

if.else9.i.i.i.i:                                 ; preds = %if.then.i.i.i
  %34 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %sub.i.i.i) #3
  %35 = add nsw i32 %34, -1
  %36 = fcmp uno double %sub.i.i.i, 0.000000e+00
  %37 = tail call double @llvm.fabs.f64(double %sub.i.i.i) #4
  %38 = fcmp oeq double %37, 0x7FF0000000000000
  %39 = or i1 %36, %38
  %40 = select i1 %39, i32 2147483647, i32 %35
  %41 = fcmp oeq double %sub.i.i.i, 0.000000e+00
  %42 = select i1 %41, i32 -2147483648, i32 %40
  %cmp11.i.i.i.i = icmp sgt i32 %42, -5
  br i1 %cmp11.i.i.i.i, label %if.then12.i.i.i.i, label %if.else21.i.i.i.i

if.then12.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %43 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 3) #3
  %44 = tail call double @llvm.amdgcn.frexp.mant.f64(double %43) #3
  %45 = fcmp olt double %44, 0x3FE5555555555555
  %46 = zext i1 %45 to i32
  %47 = tail call double @llvm.amdgcn.ldexp.f64(double %44, i32 %46) #3
  %48 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %43) #3
  %49 = sub nsw i32 %48, %46
  %50 = fadd double %47, -1.000000e+00
  %51 = fadd double %47, 1.000000e+00
  %52 = fsub double %51, %47
  %53 = fsub double %51, %52
  %54 = fsub double %47, %53
  %55 = fsub double 1.000000e+00, %52
  %56 = fadd double %55, %54
  %57 = tail call double @llvm.amdgcn.rcp.f64(double %51) #3
  %58 = fneg double %51
  %59 = tail call double @llvm.fma.f64(double %58, double %57, double 1.000000e+00) #3
  %60 = tail call double @llvm.fma.f64(double %59, double %57, double %57) #3
  %61 = tail call double @llvm.fma.f64(double %58, double %60, double 1.000000e+00) #3
  %62 = tail call double @llvm.fma.f64(double %61, double %60, double %60) #3
  %63 = fmul double %50, %62
  %64 = fmul double %51, %63
  %65 = fneg double %64
  %66 = tail call double @llvm.fma.f64(double %63, double %51, double %65) #3
  %67 = tail call double @llvm.fma.f64(double %63, double %56, double %66) #3
  %68 = fadd double %64, %67
  %69 = fsub double %68, %64
  %70 = fsub double %67, %69
  %71 = fsub double %50, %68
  %72 = fsub double %50, %71
  %73 = fsub double %72, %68
  %74 = fsub double %73, %70
  %75 = fadd double %71, %74
  %76 = fmul double %62, %75
  %77 = fadd double %63, %76
  %78 = fsub double %77, %63
  %79 = fsub double %76, %78
  %80 = fmul double %77, %77
  %81 = fneg double %80
  %82 = tail call double @llvm.fma.f64(double %77, double %77, double %81) #3
  %83 = fmul double %79, 2.000000e+00
  %84 = tail call double @llvm.fma.f64(double %77, double %83, double %82) #3
  %85 = tail call double @llvm.fma.f64(double %79, double %79, double %84) #3
  %86 = fadd double %80, %85
  %87 = fsub double %86, %80
  %88 = fsub double %85, %87
  %89 = tail call double @llvm.fma.f64(double %86, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %90 = tail call double @llvm.fma.f64(double %86, double %89, double 0x3FC7474DD7F4DF2E) #3
  %91 = tail call double @llvm.fma.f64(double %86, double %90, double 0x3FCC71C016291751) #3
  %92 = tail call double @llvm.fma.f64(double %86, double %91, double 0x3FD249249B27ACF1) #3
  %93 = tail call double @llvm.fma.f64(double %86, double %92, double 0x3FD99999998EF7B6) #3
  %94 = tail call double @llvm.fma.f64(double %86, double %93, double 0x3FE5555555555780) #3
  %95 = tail call double @llvm.amdgcn.ldexp.f64(double %77, i32 1) #3
  %96 = tail call double @llvm.amdgcn.ldexp.f64(double %79, i32 1) #3
  %97 = fmul double %77, %86
  %98 = fneg double %97
  %99 = tail call double @llvm.fma.f64(double %77, double %86, double %98) #3
  %100 = fmul double %79, %86
  %101 = tail call double @llvm.fma.f64(double %77, double %88, double %100) #3
  %102 = fadd double %99, %101
  %103 = fadd double %97, %102
  %104 = fsub double %103, %97
  %105 = fsub double %102, %104
  %106 = fmul double %103, %94
  %107 = fneg double %106
  %108 = tail call double @llvm.fma.f64(double %103, double %94, double %107) #3
  %109 = tail call double @llvm.fma.f64(double %105, double %94, double %108) #3
  %110 = fadd double %106, %109
  %111 = fsub double %110, %106
  %112 = fsub double %109, %111
  %113 = fadd double %95, %110
  %114 = fsub double %113, %95
  %115 = fsub double %113, %114
  %116 = fsub double %95, %115
  %117 = fsub double %110, %114
  %118 = fadd double %117, %116
  %119 = fadd double %96, %112
  %120 = fsub double %119, %96
  %121 = fsub double %119, %120
  %122 = fsub double %96, %121
  %123 = fsub double %112, %120
  %124 = fadd double %123, %122
  %125 = fadd double %119, %118
  %126 = fadd double %113, %125
  %127 = fsub double %126, %113
  %128 = fsub double %125, %127
  %129 = fadd double %124, %128
  %130 = fadd double %126, %129
  %131 = fsub double %130, %126
  %132 = fsub double %129, %131
  %133 = sitofp i32 %49 to double
  %134 = fmul double %130, 0x3FF71547652B82FE
  %135 = fneg double %134
  %136 = fmul double %130, 0x3C7777D0FFDA0D24
  %137 = insertelement <2 x double> undef, double %130, i32 0
  %138 = insertelement <2 x double> %137, double %132, i32 1
  %139 = insertelement <2 x double> undef, double %135, i32 0
  %140 = insertelement <2 x double> %139, double %136, i32 1
  %141 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %138, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %140) #3
  %142 = extractelement <2 x double> %141, i32 0
  %143 = extractelement <2 x double> %141, i32 1
  %144 = fadd double %142, %143
  %145 = fadd double %134, %144
  %146 = fsub double %145, %134
  %147 = fsub double %144, %146
  %148 = fadd double %145, %133
  %149 = fsub double %148, %133
  %150 = fsub double %149, %148
  %151 = fadd double %150, %133
  %152 = fsub double %145, %149
  %153 = fadd double %152, %151
  %154 = fadd double %147, %153
  %155 = fadd double %148, %154
  %156 = tail call double @llvm.fabs.f64(double %43) #4
  %157 = fcmp oeq double %156, 0x7FF0000000000000
  %158 = select i1 %157, double %43, double %155
  %159 = fcmp olt double %43, 0.000000e+00
  %160 = select i1 %159, double 0x7FF8000000000000, double %158
  %161 = fcmp oeq double %43, 0.000000e+00
  %162 = select i1 %161, double 0xFFF0000000000000, double %160
  %mul.i.i682.i.i.i.i = fmul double %162, %162
  %mul1.i.i683.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3ED3E1F985CBB733
  %add.i.i684.i.i.i.i = fadd double %mul1.i.i683.i.i.i.i, 0x3F385DA443F57737
  %mul5.i.i685.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F24E9382EAABDBB
  %add7.i.i686.i.i.i.i = fadd double %mul5.i.i685.i.i.i.i, 0x3F77E2A342AA4E3B
  %mul10.i.i687.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i684.i.i.i.i
  %mul12.i.i688.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i686.i.i.i.i
  %add15.i.i689.i.i.i.i = fadd double %mul10.i.i687.i.i.i.i, 0x3F9808F2B640E69B
  %add18.i.i690.i.i.i.i = fadd double %mul12.i.i688.i.i.i.i, 0x3F9DD5C523A6CF6D
  %mul20.i.i691.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i689.i.i.i.i
  %mul22.i.i692.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i690.i.i.i.i
  %add25.i.i693.i.i.i.i = fadd double %mul20.i.i691.i.i.i.i, 0x3FD3E6D375851610
  %add28.i.i694.i.i.i.i = fadd double %mul22.i.i692.i.i.i.i, 0x3FDB3E8B8B7EC8FA
  %163 = fmul double %162, %add25.i.i693.i.i.i.i
  %add33.i.i696.i.i.i.i = fsub double %add28.i.i694.i.i.i.i, %163
  %mul1.i.i668.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3EF03AD80F271435
  %add.i.i669.i.i.i.i = fadd double %mul1.i.i668.i.i.i.i, 0x3F577B23357A1929
  %mul5.i.i670.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F27C5B13F4BAFF2
  %add7.i.i671.i.i.i.i = fadd double %mul5.i.i670.i.i.i.i, 0x3F825620F70E4E86
  %mul10.i.i672.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i669.i.i.i.i
  %mul12.i.i673.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i671.i.i.i.i
  %add15.i.i674.i.i.i.i = fadd double %mul10.i.i672.i.i.i.i, 0x3FA38976FFA62DF3
  %add18.i.i675.i.i.i.i = fadd double %mul12.i.i673.i.i.i.i, 0x3FBACD3553111974
  %mul20.i.i676.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i674.i.i.i.i
  %mul22.i.i677.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i675.i.i.i.i
  %add25.i.i678.i.i.i.i = fadd double %mul20.i.i676.i.i.i.i, 0x3FDA8C1A7A09CF75
  %add28.i.i679.i.i.i.i = fadd double %mul22.i.i677.i.i.i.i, 1.000000e+00
  %164 = fmul double %162, %add25.i.i678.i.i.i.i
  %add33.i.i681.i.i.i.i = fsub double %add28.i.i679.i.i.i.i, %164
  %mul.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i590.i.i.i.i = fcmp ogt double %mul.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i591.i.i.i.i = fcmp oeq double %mul.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i592.i.i.i.i = or i1 %cmp.i.i.i.i590.i.i.i.i, %cmp.i.i.i591.i.i.i.i
  br i1 %or.cond.i.i.i592.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end.i.i.i594.i.i.i.i

if.end.i.i.i594.i.i.i.i:                          ; preds = %if.then12.i.i.i.i
  %cmp.i.i.i.i.i593.i.i.i.i = fcmp uno double %mul.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i593.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end7.i.i.i620.i.i.i.i

if.end7.i.i.i620.i.i.i.i:                         ; preds = %if.end.i.i.i594.i.i.i.i
  %165 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul.i.i.i.i) #3
  %166 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul.i.i.i.i) #3
  %167 = tail call i1 @llvm.amdgcn.class.f64(double %mul.i.i.i.i, i32 519) #3
  %168 = select i1 %167, i32 0, i32 %165
  %169 = select i1 %167, double %mul.i.i.i.i, double %166
  %mul.i.i.i.i.i606.i.i.i.i = fmul double %169, %169
  %mul1.i.i.i.i.i607.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i608.i.i.i.i = fadd double %mul1.i.i.i.i.i607.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i609.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FE479D17050CA47
  %170 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i609.i.i.i.i
  %mul10.i.i.i.i.i611.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %add.i.i.i.i.i608.i.i.i.i
  %mul12.i.i.i.i.i612.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %170
  %add15.i.i.i.i.i613.i.i.i.i = fadd double %mul10.i.i.i.i.i611.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i614.i.i.i.i = fadd double %mul12.i.i.i.i.i612.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i615.i.i.i.i = fmul double %169, %add15.i.i.i.i.i613.i.i.i.i
  %add23.i.i.i.i.i616.i.i.i.i = fadd double %add18.i.i.i.i.i614.i.i.i.i, %mul20.i.i.i.i.i615.i.i.i.i
  %.frozen = freeze i32 %168
  %div.i.i.i617.i.i.i.i = sdiv i32 %.frozen, 3
  %171 = call i32 @llvm.abs.i32(i32 %div.i.i.i617.i.i.i.i, i1 true)
  %cmp11.i.i.i619.i.i.i.i = icmp ult i32 %171, 64
  %172 = sub nsw i32 0, %div.i.i.i617.i.i.i.i
  %173 = icmp sgt i32 %168, 2
  %174 = select i1 %173, i32 %div.i.i.i617.i.i.i.i, i32 %172
  %175 = zext i32 %174 to i64
  %176 = shl nuw i64 1, %175
  %177 = uitofp i64 %176 to double
  %not.cmp11.i.i.i619.i.i.i.i = xor i1 %cmp11.i.i.i619.i.i.i.i, true
  %178 = or i1 %173, %not.cmp11.i.i.i619.i.i.i.i
  br i1 %178, label %merged.bb3, label %merged.bb4, !decision.merged_from !12, !decision.origin !13

do.body.i.i.i651.i.i.i.i:                         ; preds = %merged.bb5, %do.body.i.i.i651.i.i.i.i
  %guess.i.i.i589.i.i.i.i.1 = phi double [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ], [ %mul24.i.i.i638.i.i.i.i, %merged.bb5 ]
  %mul28.i.i.i641.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %guess.i.i.i589.i.i.i.i.1
  %mul29.i.i.i642.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %mul28.i.i.i641.i.i.i.i
  %add30.i.i.i643.i.i.i.i = fadd double %mul.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add31.i.i.i644.i.i.i.i = fadd double %mul.i.i.i.i, %add30.i.i.i643.i.i.i.i
  %add32.i.i.i645.i.i.i.i = fadd double %mul29.i.i.i642.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add33.i.i.i646.i.i.i.i = fadd double %mul.i.i.i.i, %add32.i.i.i645.i.i.i.i
  %div34.i.i.i647.i.i.i.i = fdiv double %add31.i.i.i644.i.i.i.i, %add33.i.i.i646.i.i.i.i
  %mul35.i.i.i648.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %div34.i.i.i647.i.i.i.i
  %sub36.i.i.i649.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i647.i.i.i.i
  %179 = tail call double @llvm.fabs.f64(double %sub36.i.i.i649.i.i.i.i) #3
  %cmp38.i.i.i650.i.i.i.i = fcmp ogt double %179, 0x3EC0000000000000
  br i1 %cmp38.i.i.i650.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

do.body40.i.i.i662.i.i.i.i:                       ; preds = %merged.bb5, %do.body40.i.i.i662.i.i.i.i
  %guess.i.i.i589.i.i.i.i.2 = phi double [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ], [ %mul24.i.i.i638.i.i.i.i, %merged.bb5 ]
  %mul41.i.i.i652.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, %guess.i.i.i589.i.i.i.i.2
  %div42.i.i.i653.i.i.i.i = fdiv double %mul.i.i.i.i, %guess.i.i.i589.i.i.i.i.2
  %sub43.i.i.i654.i.i.i.i = fsub double %mul41.i.i.i652.i.i.i.i, %div42.i.i.i653.i.i.i.i
  %mul44.i.i.i655.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i656.i.i.i.i = fdiv double %mul.i.i.i.i, %mul41.i.i.i652.i.i.i.i
  %add46.i.i.i657.i.i.i.i = fadd double %mul44.i.i.i655.i.i.i.i, %div45.i.i.i656.i.i.i.i
  %div47.i.i.i658.i.i.i.i = fdiv double %sub43.i.i.i654.i.i.i.i, %add46.i.i.i657.i.i.i.i
  %sub48.i.i.i659.i.i.i.i = fsub double %guess.i.i.i589.i.i.i.i.2, %div47.i.i.i658.i.i.i.i
  %mul50.i.i.i660.i.i.i.i = fmul double %sub48.i.i.i659.i.i.i.i, 0x3EC0000000000000
  %180 = tail call double @llvm.fabs.f64(double %div47.i.i.i658.i.i.i.i) #3
  %cmp52.i.i.i661.i.i.i.i = fcmp olt double %mul50.i.i.i660.i.i.i.i, %180
  br i1 %cmp52.i.i.i661.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i: ; preds = %do.body40.i.i.i662.i.i.i.i, %do.body.i.i.i651.i.i.i.i, %if.end.i.i.i594.i.i.i.i, %if.then12.i.i.i.i
  %retval.0.i.i.i665.i.i.i.i = phi double [ %mul.i.i.i.i, %if.then12.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i594.i.i.i.i ], [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ], [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ]
  %mul19.i.i.i.i = fmul double %add33.i.i681.i.i.i.i, %retval.0.i.i.i665.i.i.i.i
  %div20.i.i.i.i = fdiv double %add33.i.i696.i.i.i.i, %mul19.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else21.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %cmp23.i.i.i.i = icmp sgt i32 %42, -9
  br i1 %cmp23.i.i.i.i, label %if.then24.i.i.i.i, label %if.else35.i.i.i.i

if.then24.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %181 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 4) #3
  %182 = tail call double @llvm.amdgcn.frexp.mant.f64(double %181) #3
  %183 = fcmp olt double %182, 0x3FE5555555555555
  %184 = zext i1 %183 to i32
  %185 = tail call double @llvm.amdgcn.ldexp.f64(double %182, i32 %184) #3
  %186 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %181) #3
  %187 = sub nsw i32 %186, %184
  %188 = fadd double %185, -1.000000e+00
  %189 = fadd double %185, 1.000000e+00
  %190 = fsub double %189, %185
  %191 = fsub double %189, %190
  %192 = fsub double %185, %191
  %193 = fsub double 1.000000e+00, %190
  %194 = fadd double %193, %192
  %195 = tail call double @llvm.amdgcn.rcp.f64(double %189) #3
  %196 = fneg double %189
  %197 = tail call double @llvm.fma.f64(double %196, double %195, double 1.000000e+00) #3
  %198 = tail call double @llvm.fma.f64(double %197, double %195, double %195) #3
  %199 = tail call double @llvm.fma.f64(double %196, double %198, double 1.000000e+00) #3
  %200 = tail call double @llvm.fma.f64(double %199, double %198, double %198) #3
  %201 = fmul double %188, %200
  %202 = fmul double %189, %201
  %203 = fneg double %202
  %204 = tail call double @llvm.fma.f64(double %201, double %189, double %203) #3
  %205 = tail call double @llvm.fma.f64(double %201, double %194, double %204) #3
  %206 = fadd double %202, %205
  %207 = fsub double %206, %202
  %208 = fsub double %205, %207
  %209 = fsub double %188, %206
  %210 = fsub double %188, %209
  %211 = fsub double %210, %206
  %212 = fsub double %211, %208
  %213 = fadd double %209, %212
  %214 = fmul double %200, %213
  %215 = fadd double %201, %214
  %216 = fsub double %215, %201
  %217 = fsub double %214, %216
  %218 = fmul double %215, %215
  %219 = fneg double %218
  %220 = tail call double @llvm.fma.f64(double %215, double %215, double %219) #3
  %221 = fmul double %217, 2.000000e+00
  %222 = tail call double @llvm.fma.f64(double %215, double %221, double %220) #3
  %223 = tail call double @llvm.fma.f64(double %217, double %217, double %222) #3
  %224 = fadd double %218, %223
  %225 = fsub double %224, %218
  %226 = fsub double %223, %225
  %227 = tail call double @llvm.fma.f64(double %224, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %228 = tail call double @llvm.fma.f64(double %224, double %227, double 0x3FC7474DD7F4DF2E) #3
  %229 = tail call double @llvm.fma.f64(double %224, double %228, double 0x3FCC71C016291751) #3
  %230 = tail call double @llvm.fma.f64(double %224, double %229, double 0x3FD249249B27ACF1) #3
  %231 = tail call double @llvm.fma.f64(double %224, double %230, double 0x3FD99999998EF7B6) #3
  %232 = tail call double @llvm.fma.f64(double %224, double %231, double 0x3FE5555555555780) #3
  %233 = tail call double @llvm.amdgcn.ldexp.f64(double %215, i32 1) #3
  %234 = tail call double @llvm.amdgcn.ldexp.f64(double %217, i32 1) #3
  %235 = fmul double %215, %224
  %236 = fneg double %235
  %237 = tail call double @llvm.fma.f64(double %215, double %224, double %236) #3
  %238 = fmul double %217, %224
  %239 = tail call double @llvm.fma.f64(double %215, double %226, double %238) #3
  %240 = fadd double %237, %239
  %241 = fadd double %235, %240
  %242 = fsub double %241, %235
  %243 = fsub double %240, %242
  %244 = fmul double %241, %232
  %245 = fneg double %244
  %246 = tail call double @llvm.fma.f64(double %241, double %232, double %245) #3
  %247 = tail call double @llvm.fma.f64(double %243, double %232, double %246) #3
  %248 = fadd double %244, %247
  %249 = fsub double %248, %244
  %250 = fsub double %247, %249
  %251 = fadd double %233, %248
  %252 = fsub double %251, %233
  %253 = fsub double %251, %252
  %254 = fsub double %233, %253
  %255 = fsub double %248, %252
  %256 = fadd double %255, %254
  %257 = fadd double %234, %250
  %258 = fsub double %257, %234
  %259 = fsub double %257, %258
  %260 = fsub double %234, %259
  %261 = fsub double %250, %258
  %262 = fadd double %261, %260
  %263 = fadd double %257, %256
  %264 = fadd double %251, %263
  %265 = fsub double %264, %251
  %266 = fsub double %263, %265
  %267 = fadd double %262, %266
  %268 = fadd double %264, %267
  %269 = fsub double %268, %264
  %270 = fsub double %267, %269
  %271 = sitofp i32 %187 to double
  %272 = fmul double %268, 0x3FF71547652B82FE
  %273 = fneg double %272
  %274 = fmul double %268, 0x3C7777D0FFDA0D24
  %275 = insertelement <2 x double> undef, double %268, i32 0
  %276 = insertelement <2 x double> %275, double %270, i32 1
  %277 = insertelement <2 x double> undef, double %273, i32 0
  %278 = insertelement <2 x double> %277, double %274, i32 1
  %279 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %276, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %278) #3
  %280 = extractelement <2 x double> %279, i32 0
  %281 = extractelement <2 x double> %279, i32 1
  %282 = fadd double %280, %281
  %283 = fadd double %272, %282
  %284 = fsub double %283, %272
  %285 = fsub double %282, %284
  %286 = fadd double %283, %271
  %287 = fsub double %286, %271
  %288 = fsub double %287, %286
  %289 = fadd double %288, %271
  %290 = fsub double %283, %287
  %291 = fadd double %290, %289
  %292 = fadd double %285, %291
  %293 = fadd double %286, %292
  %294 = tail call double @llvm.fabs.f64(double %181) #4
  %295 = fcmp oeq double %294, 0x7FF0000000000000
  %296 = select i1 %295, double %181, double %293
  %297 = fcmp olt double %181, 0.000000e+00
  %298 = select i1 %297, double 0x7FF8000000000000, double %296
  %299 = fcmp oeq double %181, 0.000000e+00
  %300 = select i1 %299, double 0xFFF0000000000000, double %298
  %mul.i.i565.i.i.i.i = fmul double %300, %300
  %mul1.i.i566.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3E919A5BE1262808
  %add.i.i567.i.i.i.i = fadd double %mul1.i.i566.i.i.i.i, 0x3F07A5175B4661FC
  %mul5.i.i568.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3ED3058F91E15D9E
  %add7.i.i569.i.i.i.i = fadd double %mul5.i.i568.i.i.i.i, 0x3F360A6A52B6CEE1
  %mul10.i.i570.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i567.i.i.i.i
  %mul12.i.i571.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i569.i.i.i.i
  %add15.i.i572.i.i.i.i = fadd double %mul10.i.i570.i.i.i.i, 0x3F5C5B8FA36BAEC3
  %add18.i.i573.i.i.i.i = fadd double %mul12.i.i571.i.i.i.i, 0x3F80EDCAE3A5BFEE
  %mul20.i.i574.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i572.i.i.i.i
  %mul22.i.i575.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i573.i.i.i.i
  %add25.i.i576.i.i.i.i = fadd double %mul20.i.i574.i.i.i.i, 0x3F9A5E78F653B833
  %add28.i.i577.i.i.i.i = fadd double %mul22.i.i575.i.i.i.i, 0x3FB5AC2080A26513
  %mul30.i.i578.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i576.i.i.i.i
  %mul32.i.i579.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i577.i.i.i.i
  %add35.i.i580.i.i.i.i = fadd double %mul30.i.i578.i.i.i.i, 0x3FC65686F7A4EE22
  %add38.i.i581.i.i.i.i = fadd double %mul32.i.i579.i.i.i.i, 0x3FD3F40EF6582604
  %mul40.i.i582.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i580.i.i.i.i
  %add43.i.i583.i.i.i.i = fadd double %mul40.i.i582.i.i.i.i, 0x3FE03C236600AD0B
  %301 = fmul double %300, %add38.i.i581.i.i.i.i
  %add48.i.i585.i.i.i.i = fsub double %add43.i.i583.i.i.i.i, %301
  %mul1.i.i547.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EA0457562E8B20F
  %add.i.i548.i.i.i.i = fadd double %mul1.i.i547.i.i.i.i, 0x3F16154BBE28AEB9
  %mul5.i.i549.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EE174949F46ED05
  %add7.i.i550.i.i.i.i = fadd double %mul5.i.i549.i.i.i.i, 0x3F43E3B25F7FFBED
  %mul10.i.i551.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i548.i.i.i.i
  %mul12.i.i552.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i550.i.i.i.i
  %add15.i.i553.i.i.i.i = fadd double %mul10.i.i551.i.i.i.i, 0x3F6B2284D418EE28
  %add18.i.i554.i.i.i.i = fadd double %mul12.i.i552.i.i.i.i, 0x3F8DC663E91E38DD
  %mul20.i.i555.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i553.i.i.i.i
  %mul22.i.i556.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i554.i.i.i.i
  %add25.i.i557.i.i.i.i = fadd double %mul20.i.i555.i.i.i.i, 0x3FA9F261B3019817
  %add28.i.i558.i.i.i.i = fadd double %mul22.i.i556.i.i.i.i, 0x3FC29CC24A62017B
  %mul30.i.i559.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i557.i.i.i.i
  %mul32.i.i560.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i558.i.i.i.i
  %add35.i.i561.i.i.i.i = fadd double %mul30.i.i559.i.i.i.i, 0x3FD660DD0F65AD11
  %add38.i.i562.i.i.i.i = fadd double %mul32.i.i560.i.i.i.i, 0x3FE0E738E979F959
  %mul40.i.i563.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i561.i.i.i.i
  %add43.i.i564.i.i.i.i = fadd double %mul40.i.i563.i.i.i.i, 1.000000e+00
  %302 = fmul double %300, %add38.i.i562.i.i.i.i
  %add48.i.i.i.i.i.i = fsub double %add43.i.i564.i.i.i.i, %302
  %mul31.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i469.i.i.i.i = fcmp ogt double %mul31.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i470.i.i.i.i = fcmp oeq double %mul31.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i471.i.i.i.i = or i1 %cmp.i.i.i.i469.i.i.i.i, %cmp.i.i.i470.i.i.i.i
  br i1 %or.cond.i.i.i471.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end.i.i.i473.i.i.i.i

if.end.i.i.i473.i.i.i.i:                          ; preds = %if.then24.i.i.i.i
  %cmp.i.i.i.i.i472.i.i.i.i = fcmp uno double %mul31.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i472.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end7.i.i.i499.i.i.i.i

if.end7.i.i.i499.i.i.i.i:                         ; preds = %if.end.i.i.i473.i.i.i.i
  %303 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul31.i.i.i.i) #3
  %304 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul31.i.i.i.i) #3
  %305 = tail call i1 @llvm.amdgcn.class.f64(double %mul31.i.i.i.i, i32 519) #3
  %306 = select i1 %305, i32 0, i32 %303
  %307 = select i1 %305, double %mul31.i.i.i.i, double %304
  %mul.i.i.i.i.i485.i.i.i.i = fmul double %307, %307
  %mul1.i.i.i.i.i486.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i487.i.i.i.i = fadd double %mul1.i.i.i.i.i486.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i488.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FE479D17050CA47
  %308 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i488.i.i.i.i
  %mul10.i.i.i.i.i490.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %add.i.i.i.i.i487.i.i.i.i
  %mul12.i.i.i.i.i491.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %308
  %add15.i.i.i.i.i492.i.i.i.i = fadd double %mul10.i.i.i.i.i490.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i493.i.i.i.i = fadd double %mul12.i.i.i.i.i491.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i494.i.i.i.i = fmul double %307, %add15.i.i.i.i.i492.i.i.i.i
  %add23.i.i.i.i.i495.i.i.i.i = fadd double %add18.i.i.i.i.i493.i.i.i.i, %mul20.i.i.i.i.i494.i.i.i.i
  %.frozen209 = freeze i32 %306
  %div.i.i.i496.i.i.i.i = sdiv i32 %.frozen209, 3
  %309 = call i32 @llvm.abs.i32(i32 %div.i.i.i496.i.i.i.i, i1 true)
  %cmp11.i.i.i498.i.i.i.i = icmp ult i32 %309, 64
  %310 = sub nsw i32 0, %div.i.i.i496.i.i.i.i
  %311 = icmp sgt i32 %306, 2
  %312 = select i1 %311, i32 %div.i.i.i496.i.i.i.i, i32 %310
  %313 = zext i32 %312 to i64
  %314 = shl nuw i64 1, %313
  %315 = uitofp i64 %314 to double
  %not.cmp11.i.i.i498.i.i.i.i = xor i1 %cmp11.i.i.i498.i.i.i.i, true
  %316 = or i1 %311, %not.cmp11.i.i.i498.i.i.i.i
  br i1 %316, label %merged.bb6, label %merged.bb7, !decision.merged_from !14, !decision.origin !15

do.body.i.i.i530.i.i.i.i:                         ; preds = %merged.bb8, %do.body.i.i.i530.i.i.i.i
  %guess.i.i.i468.i.i.i.i.1 = phi double [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ], [ %mul24.i.i.i517.i.i.i.i, %merged.bb8 ]
  %mul28.i.i.i520.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %guess.i.i.i468.i.i.i.i.1
  %mul29.i.i.i521.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %mul28.i.i.i520.i.i.i.i
  %add30.i.i.i522.i.i.i.i = fadd double %mul31.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add31.i.i.i523.i.i.i.i = fadd double %mul31.i.i.i.i, %add30.i.i.i522.i.i.i.i
  %add32.i.i.i524.i.i.i.i = fadd double %mul29.i.i.i521.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add33.i.i.i525.i.i.i.i = fadd double %mul31.i.i.i.i, %add32.i.i.i524.i.i.i.i
  %div34.i.i.i526.i.i.i.i = fdiv double %add31.i.i.i523.i.i.i.i, %add33.i.i.i525.i.i.i.i
  %mul35.i.i.i527.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %div34.i.i.i526.i.i.i.i
  %sub36.i.i.i528.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i526.i.i.i.i
  %317 = tail call double @llvm.fabs.f64(double %sub36.i.i.i528.i.i.i.i) #3
  %cmp38.i.i.i529.i.i.i.i = fcmp ogt double %317, 0x3EC0000000000000
  br i1 %cmp38.i.i.i529.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

do.body40.i.i.i541.i.i.i.i:                       ; preds = %merged.bb8, %do.body40.i.i.i541.i.i.i.i
  %guess.i.i.i468.i.i.i.i.2 = phi double [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ], [ %mul24.i.i.i517.i.i.i.i, %merged.bb8 ]
  %mul41.i.i.i531.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, %guess.i.i.i468.i.i.i.i.2
  %div42.i.i.i532.i.i.i.i = fdiv double %mul31.i.i.i.i, %guess.i.i.i468.i.i.i.i.2
  %sub43.i.i.i533.i.i.i.i = fsub double %mul41.i.i.i531.i.i.i.i, %div42.i.i.i532.i.i.i.i
  %mul44.i.i.i534.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i535.i.i.i.i = fdiv double %mul31.i.i.i.i, %mul41.i.i.i531.i.i.i.i
  %add46.i.i.i536.i.i.i.i = fadd double %mul44.i.i.i534.i.i.i.i, %div45.i.i.i535.i.i.i.i
  %div47.i.i.i537.i.i.i.i = fdiv double %sub43.i.i.i533.i.i.i.i, %add46.i.i.i536.i.i.i.i
  %sub48.i.i.i538.i.i.i.i = fsub double %guess.i.i.i468.i.i.i.i.2, %div47.i.i.i537.i.i.i.i
  %mul50.i.i.i539.i.i.i.i = fmul double %sub48.i.i.i538.i.i.i.i, 0x3EC0000000000000
  %318 = tail call double @llvm.fabs.f64(double %div47.i.i.i537.i.i.i.i) #3
  %cmp52.i.i.i540.i.i.i.i = fcmp olt double %mul50.i.i.i539.i.i.i.i, %318
  br i1 %cmp52.i.i.i540.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i: ; preds = %do.body40.i.i.i541.i.i.i.i, %do.body.i.i.i530.i.i.i.i, %if.end.i.i.i473.i.i.i.i, %if.then24.i.i.i.i
  %retval.0.i.i.i544.i.i.i.i = phi double [ %mul31.i.i.i.i, %if.then24.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i473.i.i.i.i ], [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ], [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ]
  %mul33.i.i.i.i = fmul double %add48.i.i.i.i.i.i, %retval.0.i.i.i544.i.i.i.i
  %div34.i.i.i.i = fdiv double %add48.i.i585.i.i.i.i, %mul33.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else35.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %cmp37.i.i.i.i = icmp sgt i32 %42, -17
  br i1 %cmp37.i.i.i.i, label %if.then38.i.i.i.i, label %if.else49.i.i.i.i

if.then38.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %319 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 8) #3
  %320 = tail call double @llvm.amdgcn.frexp.mant.f64(double %319) #3
  %321 = fcmp olt double %320, 0x3FE5555555555555
  %322 = zext i1 %321 to i32
  %323 = tail call double @llvm.amdgcn.ldexp.f64(double %320, i32 %322) #3
  %324 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %319) #3
  %325 = sub nsw i32 %324, %322
  %326 = fadd double %323, -1.000000e+00
  %327 = fadd double %323, 1.000000e+00
  %328 = fsub double %327, %323
  %329 = fsub double %327, %328
  %330 = fsub double %323, %329
  %331 = fsub double 1.000000e+00, %328
  %332 = fadd double %331, %330
  %333 = tail call double @llvm.amdgcn.rcp.f64(double %327) #3
  %334 = fneg double %327
  %335 = tail call double @llvm.fma.f64(double %334, double %333, double 1.000000e+00) #3
  %336 = tail call double @llvm.fma.f64(double %335, double %333, double %333) #3
  %337 = tail call double @llvm.fma.f64(double %334, double %336, double 1.000000e+00) #3
  %338 = tail call double @llvm.fma.f64(double %337, double %336, double %336) #3
  %339 = fmul double %326, %338
  %340 = fmul double %327, %339
  %341 = fneg double %340
  %342 = tail call double @llvm.fma.f64(double %339, double %327, double %341) #3
  %343 = tail call double @llvm.fma.f64(double %339, double %332, double %342) #3
  %344 = fadd double %340, %343
  %345 = fsub double %344, %340
  %346 = fsub double %343, %345
  %347 = fsub double %326, %344
  %348 = fsub double %326, %347
  %349 = fsub double %348, %344
  %350 = fsub double %349, %346
  %351 = fadd double %347, %350
  %352 = fmul double %338, %351
  %353 = fadd double %339, %352
  %354 = fsub double %353, %339
  %355 = fsub double %352, %354
  %356 = fmul double %353, %353
  %357 = fneg double %356
  %358 = tail call double @llvm.fma.f64(double %353, double %353, double %357) #3
  %359 = fmul double %355, 2.000000e+00
  %360 = tail call double @llvm.fma.f64(double %353, double %359, double %358) #3
  %361 = tail call double @llvm.fma.f64(double %355, double %355, double %360) #3
  %362 = fadd double %356, %361
  %363 = fsub double %362, %356
  %364 = fsub double %361, %363
  %365 = tail call double @llvm.fma.f64(double %362, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %366 = tail call double @llvm.fma.f64(double %362, double %365, double 0x3FC7474DD7F4DF2E) #3
  %367 = tail call double @llvm.fma.f64(double %362, double %366, double 0x3FCC71C016291751) #3
  %368 = tail call double @llvm.fma.f64(double %362, double %367, double 0x3FD249249B27ACF1) #3
  %369 = tail call double @llvm.fma.f64(double %362, double %368, double 0x3FD99999998EF7B6) #3
  %370 = tail call double @llvm.fma.f64(double %362, double %369, double 0x3FE5555555555780) #3
  %371 = tail call double @llvm.amdgcn.ldexp.f64(double %353, i32 1) #3
  %372 = tail call double @llvm.amdgcn.ldexp.f64(double %355, i32 1) #3
  %373 = fmul double %353, %362
  %374 = fneg double %373
  %375 = tail call double @llvm.fma.f64(double %353, double %362, double %374) #3
  %376 = fmul double %355, %362
  %377 = tail call double @llvm.fma.f64(double %353, double %364, double %376) #3
  %378 = fadd double %375, %377
  %379 = fadd double %373, %378
  %380 = fsub double %379, %373
  %381 = fsub double %378, %380
  %382 = fmul double %379, %370
  %383 = fneg double %382
  %384 = tail call double @llvm.fma.f64(double %379, double %370, double %383) #3
  %385 = tail call double @llvm.fma.f64(double %381, double %370, double %384) #3
  %386 = fadd double %382, %385
  %387 = fsub double %386, %382
  %388 = fsub double %385, %387
  %389 = fadd double %371, %386
  %390 = fsub double %389, %371
  %391 = fsub double %389, %390
  %392 = fsub double %371, %391
  %393 = fsub double %386, %390
  %394 = fadd double %393, %392
  %395 = fadd double %372, %388
  %396 = fsub double %395, %372
  %397 = fsub double %395, %396
  %398 = fsub double %372, %397
  %399 = fsub double %388, %396
  %400 = fadd double %399, %398
  %401 = fadd double %395, %394
  %402 = fadd double %389, %401
  %403 = fsub double %402, %389
  %404 = fsub double %401, %403
  %405 = fadd double %400, %404
  %406 = fadd double %402, %405
  %407 = fsub double %406, %402
  %408 = fsub double %405, %407
  %409 = sitofp i32 %325 to double
  %410 = fmul double %406, 0x3FF71547652B82FE
  %411 = fneg double %410
  %412 = fmul double %406, 0x3C7777D0FFDA0D24
  %413 = insertelement <2 x double> undef, double %406, i32 0
  %414 = insertelement <2 x double> %413, double %408, i32 1
  %415 = insertelement <2 x double> undef, double %411, i32 0
  %416 = insertelement <2 x double> %415, double %412, i32 1
  %417 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %414, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %416) #3
  %418 = extractelement <2 x double> %417, i32 0
  %419 = extractelement <2 x double> %417, i32 1
  %420 = fadd double %418, %419
  %421 = fadd double %410, %420
  %422 = fsub double %421, %410
  %423 = fsub double %420, %422
  %424 = fadd double %421, %409
  %425 = fsub double %424, %409
  %426 = fsub double %425, %424
  %427 = fadd double %426, %409
  %428 = fsub double %421, %425
  %429 = fadd double %428, %427
  %430 = fadd double %423, %429
  %431 = fadd double %424, %430
  %432 = tail call double @llvm.fabs.f64(double %319) #4
  %433 = fcmp oeq double %432, 0x7FF0000000000000
  %434 = select i1 %433, double %319, double %431
  %435 = fcmp olt double %319, 0.000000e+00
  %436 = select i1 %435, double 0x7FF8000000000000, double %434
  %437 = fcmp oeq double %319, 0.000000e+00
  %438 = select i1 %437, double 0xFFF0000000000000, double %436
  %mul.i.i450.i.i.i.i = fmul double %438, %438
  %mul1.i.i451.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3D1C49F35743D651
  %add.i.i452.i.i.i.i = fadd double %mul1.i.i451.i.i.i.i, 0x3EC5BDF8ABE0C4D2
  %mul5.i.i453.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E74DE722017F09B
  %add7.i.i454.i.i.i.i = fadd double %mul5.i.i453.i.i.i.i, 0x3F08B20867234AE0
  %mul10.i.i455.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i452.i.i.i.i
  %mul12.i.i456.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i454.i.i.i.i
  %add15.i.i457.i.i.i.i = fadd double %mul10.i.i455.i.i.i.i, 0x3F43291C59111954
  %add18.i.i458.i.i.i.i = fadd double %mul12.i.i456.i.i.i.i, 0x3F7555F81DC90AE6
  %mul20.i.i459.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i457.i.i.i.i
  %mul22.i.i460.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i458.i.i.i.i
  %add25.i.i461.i.i.i.i = fadd double %mul20.i.i459.i.i.i.i, 0x3FA118409603E368
  %add28.i.i462.i.i.i.i = fadd double %mul22.i.i460.i.i.i.i, 0x3FC2F812CF93403D
  %mul30.i.i463.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i461.i.i.i.i
  %mul32.i.i.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add28.i.i462.i.i.i.i
  %add35.i.i.i.i.i.i = fadd double %mul30.i.i463.i.i.i.i, 0x3FDA4ECF31EE23E1
  %add38.i.i464.i.i.i.i = fadd double %mul32.i.i.i.i.i.i, 0x3FE15637BD9C1C6C
  %439 = fmul double %438, %add35.i.i.i.i.i.i
  %add43.i.i.i.i.i.i = fsub double %add38.i.i464.i.i.i.i, %439
  %mul1.i.i434.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E834146FFF39045
  %add.i.i435.i.i.i.i = fadd double %mul1.i.i434.i.i.i.i, 0x3F16C942D4A0C545
  %mul5.i.i436.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3ED40F287F6755C5
  %add7.i.i437.i.i.i.i = fadd double %mul5.i.i436.i.i.i.i, 0x3F51AD434F5D94BA
  %mul10.i.i438.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i435.i.i.i.i
  %mul12.i.i439.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i437.i.i.i.i
  %add15.i.i440.i.i.i.i = fadd double %mul10.i.i438.i.i.i.i, 0x3F83AFF5A756295F
  %add18.i.i441.i.i.i.i = fadd double %mul12.i.i439.i.i.i.i, 0x3FAF8A313C5B71D0
  %mul20.i.i442.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i440.i.i.i.i
  %mul22.i.i443.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i441.i.i.i.i
  %add25.i.i444.i.i.i.i = fadd double %mul20.i.i442.i.i.i.i, 0x3FD1813788B6276A
  %add28.i.i445.i.i.i.i = fadd double %mul22.i.i443.i.i.i.i, 0x3FE84455F48DB67F
  %mul30.i.i446.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i444.i.i.i.i
  %add33.i.i447.i.i.i.i = fadd double %mul30.i.i446.i.i.i.i, 1.000000e+00
  %440 = fmul double %438, %add28.i.i445.i.i.i.i
  %add38.i.i449.i.i.i.i = fsub double %add33.i.i447.i.i.i.i, %440
  %mul45.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i356.i.i.i.i = fcmp ogt double %mul45.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i357.i.i.i.i = fcmp oeq double %mul45.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i358.i.i.i.i = or i1 %cmp.i.i.i.i356.i.i.i.i, %cmp.i.i.i357.i.i.i.i
  br i1 %or.cond.i.i.i358.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end.i.i.i360.i.i.i.i

if.end.i.i.i360.i.i.i.i:                          ; preds = %if.then38.i.i.i.i
  %cmp.i.i.i.i.i359.i.i.i.i = fcmp uno double %mul45.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i359.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end7.i.i.i386.i.i.i.i

if.end7.i.i.i386.i.i.i.i:                         ; preds = %if.end.i.i.i360.i.i.i.i
  %441 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul45.i.i.i.i) #3
  %442 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul45.i.i.i.i) #3
  %443 = tail call i1 @llvm.amdgcn.class.f64(double %mul45.i.i.i.i, i32 519) #3
  %444 = select i1 %443, i32 0, i32 %441
  %445 = select i1 %443, double %mul45.i.i.i.i, double %442
  %mul.i.i.i.i.i372.i.i.i.i = fmul double %445, %445
  %mul1.i.i.i.i.i373.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i374.i.i.i.i = fadd double %mul1.i.i.i.i.i373.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i375.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FE479D17050CA47
  %446 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i375.i.i.i.i
  %mul10.i.i.i.i.i377.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %add.i.i.i.i.i374.i.i.i.i
  %mul12.i.i.i.i.i378.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %446
  %add15.i.i.i.i.i379.i.i.i.i = fadd double %mul10.i.i.i.i.i377.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i380.i.i.i.i = fadd double %mul12.i.i.i.i.i378.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i381.i.i.i.i = fmul double %445, %add15.i.i.i.i.i379.i.i.i.i
  %add23.i.i.i.i.i382.i.i.i.i = fadd double %add18.i.i.i.i.i380.i.i.i.i, %mul20.i.i.i.i.i381.i.i.i.i
  %.frozen210 = freeze i32 %444
  %div.i.i.i383.i.i.i.i = sdiv i32 %.frozen210, 3
  %447 = call i32 @llvm.abs.i32(i32 %div.i.i.i383.i.i.i.i, i1 true)
  %cmp11.i.i.i385.i.i.i.i = icmp ult i32 %447, 64
  %448 = sub nsw i32 0, %div.i.i.i383.i.i.i.i
  %449 = icmp sgt i32 %444, 2
  %450 = select i1 %449, i32 %div.i.i.i383.i.i.i.i, i32 %448
  %451 = zext i32 %450 to i64
  %452 = shl nuw i64 1, %451
  %453 = uitofp i64 %452 to double
  %not.cmp11.i.i.i385.i.i.i.i = xor i1 %cmp11.i.i.i385.i.i.i.i, true
  %454 = or i1 %449, %not.cmp11.i.i.i385.i.i.i.i
  br i1 %454, label %merged.bb9, label %merged.bb10, !decision.merged_from !16, !decision.origin !17

do.body.i.i.i417.i.i.i.i:                         ; preds = %merged.bb11, %do.body.i.i.i417.i.i.i.i
  %guess.i.i.i355.i.i.i.i.1 = phi double [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ], [ %mul24.i.i.i404.i.i.i.i, %merged.bb11 ]
  %mul28.i.i.i407.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %guess.i.i.i355.i.i.i.i.1
  %mul29.i.i.i408.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %mul28.i.i.i407.i.i.i.i
  %add30.i.i.i409.i.i.i.i = fadd double %mul45.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add31.i.i.i410.i.i.i.i = fadd double %mul45.i.i.i.i, %add30.i.i.i409.i.i.i.i
  %add32.i.i.i411.i.i.i.i = fadd double %mul29.i.i.i408.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add33.i.i.i412.i.i.i.i = fadd double %mul45.i.i.i.i, %add32.i.i.i411.i.i.i.i
  %div34.i.i.i413.i.i.i.i = fdiv double %add31.i.i.i410.i.i.i.i, %add33.i.i.i412.i.i.i.i
  %mul35.i.i.i414.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %div34.i.i.i413.i.i.i.i
  %sub36.i.i.i415.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i413.i.i.i.i
  %455 = tail call double @llvm.fabs.f64(double %sub36.i.i.i415.i.i.i.i) #3
  %cmp38.i.i.i416.i.i.i.i = fcmp ogt double %455, 0x3EC0000000000000
  br i1 %cmp38.i.i.i416.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

do.body40.i.i.i428.i.i.i.i:                       ; preds = %merged.bb11, %do.body40.i.i.i428.i.i.i.i
  %guess.i.i.i355.i.i.i.i.2 = phi double [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ], [ %mul24.i.i.i404.i.i.i.i, %merged.bb11 ]
  %mul41.i.i.i418.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, %guess.i.i.i355.i.i.i.i.2
  %div42.i.i.i419.i.i.i.i = fdiv double %mul45.i.i.i.i, %guess.i.i.i355.i.i.i.i.2
  %sub43.i.i.i420.i.i.i.i = fsub double %mul41.i.i.i418.i.i.i.i, %div42.i.i.i419.i.i.i.i
  %mul44.i.i.i421.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i422.i.i.i.i = fdiv double %mul45.i.i.i.i, %mul41.i.i.i418.i.i.i.i
  %add46.i.i.i423.i.i.i.i = fadd double %mul44.i.i.i421.i.i.i.i, %div45.i.i.i422.i.i.i.i
  %div47.i.i.i424.i.i.i.i = fdiv double %sub43.i.i.i420.i.i.i.i, %add46.i.i.i423.i.i.i.i
  %sub48.i.i.i425.i.i.i.i = fsub double %guess.i.i.i355.i.i.i.i.2, %div47.i.i.i424.i.i.i.i
  %mul50.i.i.i426.i.i.i.i = fmul double %sub48.i.i.i425.i.i.i.i, 0x3EC0000000000000
  %456 = tail call double @llvm.fabs.f64(double %div47.i.i.i424.i.i.i.i) #3
  %cmp52.i.i.i427.i.i.i.i = fcmp olt double %mul50.i.i.i426.i.i.i.i, %456
  br i1 %cmp52.i.i.i427.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i: ; preds = %do.body40.i.i.i428.i.i.i.i, %do.body.i.i.i417.i.i.i.i, %if.end.i.i.i360.i.i.i.i, %if.then38.i.i.i.i
  %retval.0.i.i.i431.i.i.i.i = phi double [ %mul45.i.i.i.i, %if.then38.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i360.i.i.i.i ], [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ], [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ]
  %mul47.i.i.i.i = fmul double %add38.i.i449.i.i.i.i, %retval.0.i.i.i431.i.i.i.i
  %div48.i.i.i.i = fdiv double %add43.i.i.i.i.i.i, %mul47.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else49.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %cmp51.i.i.i.i = icmp sgt i32 %42, -33
  br i1 %cmp51.i.i.i.i, label %if.then52.i.i.i.i, label %if.else63.i.i.i.i

if.then52.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %457 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 16) #3
  %458 = tail call double @llvm.amdgcn.frexp.mant.f64(double %457) #3
  %459 = fcmp olt double %458, 0x3FE5555555555555
  %460 = zext i1 %459 to i32
  %461 = tail call double @llvm.amdgcn.ldexp.f64(double %458, i32 %460) #3
  %462 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %457) #3
  %463 = sub nsw i32 %462, %460
  %464 = fadd double %461, -1.000000e+00
  %465 = fadd double %461, 1.000000e+00
  %466 = fsub double %465, %461
  %467 = fsub double %465, %466
  %468 = fsub double %461, %467
  %469 = fsub double 1.000000e+00, %466
  %470 = fadd double %469, %468
  %471 = tail call double @llvm.amdgcn.rcp.f64(double %465) #3
  %472 = fneg double %465
  %473 = tail call double @llvm.fma.f64(double %472, double %471, double 1.000000e+00) #3
  %474 = tail call double @llvm.fma.f64(double %473, double %471, double %471) #3
  %475 = tail call double @llvm.fma.f64(double %472, double %474, double 1.000000e+00) #3
  %476 = tail call double @llvm.fma.f64(double %475, double %474, double %474) #3
  %477 = fmul double %464, %476
  %478 = fmul double %465, %477
  %479 = fneg double %478
  %480 = tail call double @llvm.fma.f64(double %477, double %465, double %479) #3
  %481 = tail call double @llvm.fma.f64(double %477, double %470, double %480) #3
  %482 = fadd double %478, %481
  %483 = fsub double %482, %478
  %484 = fsub double %481, %483
  %485 = fsub double %464, %482
  %486 = fsub double %464, %485
  %487 = fsub double %486, %482
  %488 = fsub double %487, %484
  %489 = fadd double %485, %488
  %490 = fmul double %476, %489
  %491 = fadd double %477, %490
  %492 = fsub double %491, %477
  %493 = fsub double %490, %492
  %494 = fmul double %491, %491
  %495 = fneg double %494
  %496 = tail call double @llvm.fma.f64(double %491, double %491, double %495) #3
  %497 = fmul double %493, 2.000000e+00
  %498 = tail call double @llvm.fma.f64(double %491, double %497, double %496) #3
  %499 = tail call double @llvm.fma.f64(double %493, double %493, double %498) #3
  %500 = fadd double %494, %499
  %501 = fsub double %500, %494
  %502 = fsub double %499, %501
  %503 = tail call double @llvm.fma.f64(double %500, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %504 = tail call double @llvm.fma.f64(double %500, double %503, double 0x3FC7474DD7F4DF2E) #3
  %505 = tail call double @llvm.fma.f64(double %500, double %504, double 0x3FCC71C016291751) #3
  %506 = tail call double @llvm.fma.f64(double %500, double %505, double 0x3FD249249B27ACF1) #3
  %507 = tail call double @llvm.fma.f64(double %500, double %506, double 0x3FD99999998EF7B6) #3
  %508 = tail call double @llvm.fma.f64(double %500, double %507, double 0x3FE5555555555780) #3
  %509 = tail call double @llvm.amdgcn.ldexp.f64(double %491, i32 1) #3
  %510 = tail call double @llvm.amdgcn.ldexp.f64(double %493, i32 1) #3
  %511 = fmul double %491, %500
  %512 = fneg double %511
  %513 = tail call double @llvm.fma.f64(double %491, double %500, double %512) #3
  %514 = fmul double %493, %500
  %515 = tail call double @llvm.fma.f64(double %491, double %502, double %514) #3
  %516 = fadd double %513, %515
  %517 = fadd double %511, %516
  %518 = fsub double %517, %511
  %519 = fsub double %516, %518
  %520 = fmul double %517, %508
  %521 = fneg double %520
  %522 = tail call double @llvm.fma.f64(double %517, double %508, double %521) #3
  %523 = tail call double @llvm.fma.f64(double %519, double %508, double %522) #3
  %524 = fadd double %520, %523
  %525 = fsub double %524, %520
  %526 = fsub double %523, %525
  %527 = fadd double %509, %524
  %528 = fsub double %527, %509
  %529 = fsub double %527, %528
  %530 = fsub double %509, %529
  %531 = fsub double %524, %528
  %532 = fadd double %531, %530
  %533 = fadd double %510, %526
  %534 = fsub double %533, %510
  %535 = fsub double %533, %534
  %536 = fsub double %510, %535
  %537 = fsub double %526, %534
  %538 = fadd double %537, %536
  %539 = fadd double %533, %532
  %540 = fadd double %527, %539
  %541 = fsub double %540, %527
  %542 = fsub double %539, %541
  %543 = fadd double %538, %542
  %544 = fadd double %540, %543
  %545 = fsub double %544, %540
  %546 = fsub double %543, %545
  %547 = sitofp i32 %463 to double
  %548 = fmul double %544, 0x3FF71547652B82FE
  %549 = fneg double %548
  %550 = fmul double %544, 0x3C7777D0FFDA0D24
  %551 = insertelement <2 x double> undef, double %544, i32 0
  %552 = insertelement <2 x double> %551, double %546, i32 1
  %553 = insertelement <2 x double> undef, double %549, i32 0
  %554 = insertelement <2 x double> %553, double %550, i32 1
  %555 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %552, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %554) #3
  %556 = extractelement <2 x double> %555, i32 0
  %557 = extractelement <2 x double> %555, i32 1
  %558 = fadd double %556, %557
  %559 = fadd double %548, %558
  %560 = fsub double %559, %548
  %561 = fsub double %558, %560
  %562 = fadd double %559, %547
  %563 = fsub double %562, %547
  %564 = fsub double %563, %562
  %565 = fadd double %564, %547
  %566 = fsub double %559, %563
  %567 = fadd double %566, %565
  %568 = fadd double %561, %567
  %569 = fadd double %562, %568
  %570 = tail call double @llvm.fabs.f64(double %457) #4
  %571 = fcmp oeq double %570, 0x7FF0000000000000
  %572 = select i1 %571, double %457, double %569
  %573 = fcmp olt double %457, 0.000000e+00
  %574 = select i1 %573, double 0x7FF8000000000000, double %572
  %575 = fcmp oeq double %457, 0.000000e+00
  %576 = select i1 %575, double 0xFFF0000000000000, double %574
  %mul.i.i335.i.i.i.i = fmul double %576, %576
  %mul1.i.i336.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EBF7344DBF5E403
  %add.i.i337.i.i.i.i = fadd double %mul1.i.i336.i.i.i.i, 0x3F2CFF1E2D54E4E7
  %mul5.i.i338.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EEF8CF23CAED047
  %add7.i.i339.i.i.i.i = fadd double %mul5.i.i338.i.i.i.i, 0x3F5CF8F0FF9B6F59
  %mul10.i.i340.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i337.i.i.i.i
  %mul12.i.i341.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i339.i.i.i.i
  %add15.i.i342.i.i.i.i = fadd double %mul10.i.i340.i.i.i.i, 0x3F8857AD74D33625
  %add18.i.i343.i.i.i.i = fadd double %mul12.i.i341.i.i.i.i, 0x3FAE52179C3AEDE6
  %mul20.i.i344.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i342.i.i.i.i
  %mul22.i.i345.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i343.i.i.i.i
  %add25.i.i346.i.i.i.i = fadd double %mul20.i.i344.i.i.i.i, 0x3FCB21A22303D8FC
  %add28.i.i347.i.i.i.i = fadd double %mul22.i.i345.i.i.i.i, 0x3FDF29CE00A8804B
  %mul30.i.i348.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i346.i.i.i.i
  %add33.i.i349.i.i.i.i = fadd double %mul30.i.i348.i.i.i.i, 0x3FE15775564555E5
  %577 = fmul double %576, %add28.i.i347.i.i.i.i
  %add38.i.i351.i.i.i.i = fsub double %add33.i.i349.i.i.i.i, %577
  %mul1.i.i321.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3ECD04621671DBCE
  %add.i.i322.i.i.i.i = fadd double %mul1.i.i321.i.i.i.i, 0x3F3AC0D433DC2A4E
  %mul5.i.i323.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EFD1C12EAA62BE9
  %add7.i.i324.i.i.i.i = fadd double %mul5.i.i323.i.i.i.i, 0x3F6ABB215A001E96
  %mul10.i.i325.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i322.i.i.i.i
  %mul12.i.i326.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i324.i.i.i.i
  %add15.i.i327.i.i.i.i = fadd double %mul10.i.i325.i.i.i.i, 0x3F967590758A1B1A
  %add18.i.i328.i.i.i.i = fadd double %mul12.i.i326.i.i.i.i, 0x3FBBF9941AE7DFDE
  %mul20.i.i329.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i327.i.i.i.i
  %mul22.i.i330.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i328.i.i.i.i
  %add25.i.i331.i.i.i.i = fadd double %mul20.i.i329.i.i.i.i, 0x3FD90848F242167F
  %add28.i.i332.i.i.i.i = fadd double %mul22.i.i330.i.i.i.i, 0x3FECC09A37BCEE76
  %mul30.i.i333.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i331.i.i.i.i
  %add33.i.i334.i.i.i.i = fadd double %mul30.i.i333.i.i.i.i, 1.000000e+00
  %578 = fmul double %576, %add28.i.i332.i.i.i.i
  %add38.i.i.i.i.i.i = fsub double %add33.i.i334.i.i.i.i, %578
  %mul59.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i243.i.i.i.i = fcmp ogt double %mul59.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i244.i.i.i.i = fcmp oeq double %mul59.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i245.i.i.i.i = or i1 %cmp.i.i.i.i243.i.i.i.i, %cmp.i.i.i244.i.i.i.i
  br i1 %or.cond.i.i.i245.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end.i.i.i247.i.i.i.i

if.end.i.i.i247.i.i.i.i:                          ; preds = %if.then52.i.i.i.i
  %cmp.i.i.i.i.i246.i.i.i.i = fcmp uno double %mul59.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i246.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end7.i.i.i273.i.i.i.i

if.end7.i.i.i273.i.i.i.i:                         ; preds = %if.end.i.i.i247.i.i.i.i
  %579 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul59.i.i.i.i) #3
  %580 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul59.i.i.i.i) #3
  %581 = tail call i1 @llvm.amdgcn.class.f64(double %mul59.i.i.i.i, i32 519) #3
  %582 = select i1 %581, i32 0, i32 %579
  %583 = select i1 %581, double %mul59.i.i.i.i, double %580
  %mul.i.i.i.i.i259.i.i.i.i = fmul double %583, %583
  %mul1.i.i.i.i.i260.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i261.i.i.i.i = fadd double %mul1.i.i.i.i.i260.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i262.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FE479D17050CA47
  %584 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i262.i.i.i.i
  %mul10.i.i.i.i.i264.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %add.i.i.i.i.i261.i.i.i.i
  %mul12.i.i.i.i.i265.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %584
  %add15.i.i.i.i.i266.i.i.i.i = fadd double %mul10.i.i.i.i.i264.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i267.i.i.i.i = fadd double %mul12.i.i.i.i.i265.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i268.i.i.i.i = fmul double %583, %add15.i.i.i.i.i266.i.i.i.i
  %add23.i.i.i.i.i269.i.i.i.i = fadd double %add18.i.i.i.i.i267.i.i.i.i, %mul20.i.i.i.i.i268.i.i.i.i
  %.frozen211 = freeze i32 %582
  %div.i.i.i270.i.i.i.i = sdiv i32 %.frozen211, 3
  %585 = call i32 @llvm.abs.i32(i32 %div.i.i.i270.i.i.i.i, i1 true)
  %cmp11.i.i.i272.i.i.i.i = icmp ult i32 %585, 64
  %586 = sub nsw i32 0, %div.i.i.i270.i.i.i.i
  %587 = icmp sgt i32 %582, 2
  %588 = select i1 %587, i32 %div.i.i.i270.i.i.i.i, i32 %586
  %589 = zext i32 %588 to i64
  %590 = shl nuw i64 1, %589
  %591 = uitofp i64 %590 to double
  %not.cmp11.i.i.i272.i.i.i.i = xor i1 %cmp11.i.i.i272.i.i.i.i, true
  %592 = or i1 %587, %not.cmp11.i.i.i272.i.i.i.i
  br i1 %592, label %merged.bb12, label %merged.bb13, !decision.merged_from !18, !decision.origin !19

do.body.i.i.i304.i.i.i.i:                         ; preds = %merged.bb14, %do.body.i.i.i304.i.i.i.i
  %guess.i.i.i242.i.i.i.i.1 = phi double [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ], [ %mul24.i.i.i291.i.i.i.i, %merged.bb14 ]
  %mul28.i.i.i294.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %guess.i.i.i242.i.i.i.i.1
  %mul29.i.i.i295.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %mul28.i.i.i294.i.i.i.i
  %add30.i.i.i296.i.i.i.i = fadd double %mul59.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add31.i.i.i297.i.i.i.i = fadd double %mul59.i.i.i.i, %add30.i.i.i296.i.i.i.i
  %add32.i.i.i298.i.i.i.i = fadd double %mul29.i.i.i295.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add33.i.i.i299.i.i.i.i = fadd double %mul59.i.i.i.i, %add32.i.i.i298.i.i.i.i
  %div34.i.i.i300.i.i.i.i = fdiv double %add31.i.i.i297.i.i.i.i, %add33.i.i.i299.i.i.i.i
  %mul35.i.i.i301.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %div34.i.i.i300.i.i.i.i
  %sub36.i.i.i302.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i300.i.i.i.i
  %593 = tail call double @llvm.fabs.f64(double %sub36.i.i.i302.i.i.i.i) #3
  %cmp38.i.i.i303.i.i.i.i = fcmp ogt double %593, 0x3EC0000000000000
  br i1 %cmp38.i.i.i303.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

do.body40.i.i.i315.i.i.i.i:                       ; preds = %merged.bb14, %do.body40.i.i.i315.i.i.i.i
  %guess.i.i.i242.i.i.i.i.2 = phi double [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ], [ %mul24.i.i.i291.i.i.i.i, %merged.bb14 ]
  %mul41.i.i.i305.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, %guess.i.i.i242.i.i.i.i.2
  %div42.i.i.i306.i.i.i.i = fdiv double %mul59.i.i.i.i, %guess.i.i.i242.i.i.i.i.2
  %sub43.i.i.i307.i.i.i.i = fsub double %mul41.i.i.i305.i.i.i.i, %div42.i.i.i306.i.i.i.i
  %mul44.i.i.i308.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i309.i.i.i.i = fdiv double %mul59.i.i.i.i, %mul41.i.i.i305.i.i.i.i
  %add46.i.i.i310.i.i.i.i = fadd double %mul44.i.i.i308.i.i.i.i, %div45.i.i.i309.i.i.i.i
  %div47.i.i.i311.i.i.i.i = fdiv double %sub43.i.i.i307.i.i.i.i, %add46.i.i.i310.i.i.i.i
  %sub48.i.i.i312.i.i.i.i = fsub double %guess.i.i.i242.i.i.i.i.2, %div47.i.i.i311.i.i.i.i
  %mul50.i.i.i313.i.i.i.i = fmul double %sub48.i.i.i312.i.i.i.i, 0x3EC0000000000000
  %594 = tail call double @llvm.fabs.f64(double %div47.i.i.i311.i.i.i.i) #3
  %cmp52.i.i.i314.i.i.i.i = fcmp olt double %mul50.i.i.i313.i.i.i.i, %594
  br i1 %cmp52.i.i.i314.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i: ; preds = %do.body40.i.i.i315.i.i.i.i, %do.body.i.i.i304.i.i.i.i, %if.end.i.i.i247.i.i.i.i, %if.then52.i.i.i.i
  %retval.0.i.i.i318.i.i.i.i = phi double [ %mul59.i.i.i.i, %if.then52.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i247.i.i.i.i ], [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ], [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ]
  %mul61.i.i.i.i = fmul double %add38.i.i.i.i.i.i, %retval.0.i.i.i318.i.i.i.i
  %div62.i.i.i.i = fdiv double %add38.i.i351.i.i.i.i, %mul61.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else63.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %mul64.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp1.i.i.i.i.i = fcmp oge double %mul64.i.i.i.i, 0x10000000000000
  %cmp2.i.i.i.i.i = fcmp ole double %mul64.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %595 = and i1 %cmp1.i.i.i.i.i, %cmp2.i.i.i.i.i
  br i1 %595, label %if.then66.i.i.i.i, label %if.else71.i.i.i.i

if.then66.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %mul68.i.i.i.i = fmul double %mul64.i.i.i.i, 0x401921FB54442D18
  %cmp.i.i.i.i162.i.i.i.i = fcmp ogt double %mul68.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i163.i.i.i.i = fcmp oeq double %mul68.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i164.i.i.i.i = or i1 %cmp.i.i.i.i162.i.i.i.i, %cmp.i.i.i163.i.i.i.i
  br i1 %or.cond.i.i.i164.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end.i.i.i166.i.i.i.i

if.end.i.i.i166.i.i.i.i:                          ; preds = %if.then66.i.i.i.i
  %cmp.i.i.i.i.i165.i.i.i.i = fcmp uno double %mul68.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i165.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end7.i.i.i192.i.i.i.i

if.end7.i.i.i192.i.i.i.i:                         ; preds = %if.end.i.i.i166.i.i.i.i
  %596 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul68.i.i.i.i) #3
  %597 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul68.i.i.i.i) #3
  %598 = tail call i1 @llvm.amdgcn.class.f64(double %mul68.i.i.i.i, i32 519) #3
  %599 = select i1 %598, i32 0, i32 %596
  %600 = select i1 %598, double %mul68.i.i.i.i, double %597
  %mul.i.i.i.i.i178.i.i.i.i = fmul double %600, %600
  %mul1.i.i.i.i.i179.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i180.i.i.i.i = fadd double %mul1.i.i.i.i.i179.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i181.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FE479D17050CA47
  %601 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i181.i.i.i.i
  %mul10.i.i.i.i.i183.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %add.i.i.i.i.i180.i.i.i.i
  %mul12.i.i.i.i.i184.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %601
  %add15.i.i.i.i.i185.i.i.i.i = fadd double %mul10.i.i.i.i.i183.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i186.i.i.i.i = fadd double %mul12.i.i.i.i.i184.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i187.i.i.i.i = fmul double %600, %add15.i.i.i.i.i185.i.i.i.i
  %add23.i.i.i.i.i188.i.i.i.i = fadd double %add18.i.i.i.i.i186.i.i.i.i, %mul20.i.i.i.i.i187.i.i.i.i
  %.frozen212 = freeze i32 %599
  %div.i.i.i189.i.i.i.i = sdiv i32 %.frozen212, 3
  %602 = call i32 @llvm.abs.i32(i32 %div.i.i.i189.i.i.i.i, i1 true)
  %cmp11.i.i.i191.i.i.i.i = icmp ult i32 %602, 64
  %603 = sub nsw i32 0, %div.i.i.i189.i.i.i.i
  %604 = icmp sgt i32 %599, 2
  %605 = select i1 %604, i32 %div.i.i.i189.i.i.i.i, i32 %603
  %606 = zext i32 %605 to i64
  %607 = shl nuw i64 1, %606
  %608 = uitofp i64 %607 to double
  %not.cmp11.i.i.i191.i.i.i.i = xor i1 %cmp11.i.i.i191.i.i.i.i, true
  %609 = or i1 %604, %not.cmp11.i.i.i191.i.i.i.i
  br i1 %609, label %merged.bb15, label %merged.bb16, !decision.merged_from !20, !decision.origin !21

do.body.i.i.i223.i.i.i.i:                         ; preds = %merged.bb17, %do.body.i.i.i223.i.i.i.i
  %guess.i.i.i161.i.i.i.i.1 = phi double [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ], [ %mul24.i.i.i210.i.i.i.i, %merged.bb17 ]
  %mul28.i.i.i213.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %guess.i.i.i161.i.i.i.i.1
  %mul29.i.i.i214.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %mul28.i.i.i213.i.i.i.i
  %add30.i.i.i215.i.i.i.i = fadd double %mul68.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add31.i.i.i216.i.i.i.i = fadd double %mul68.i.i.i.i, %add30.i.i.i215.i.i.i.i
  %add32.i.i.i217.i.i.i.i = fadd double %mul29.i.i.i214.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add33.i.i.i218.i.i.i.i = fadd double %mul68.i.i.i.i, %add32.i.i.i217.i.i.i.i
  %div34.i.i.i219.i.i.i.i = fdiv double %add31.i.i.i216.i.i.i.i, %add33.i.i.i218.i.i.i.i
  %mul35.i.i.i220.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %div34.i.i.i219.i.i.i.i
  %sub36.i.i.i221.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i219.i.i.i.i
  %610 = tail call double @llvm.fabs.f64(double %sub36.i.i.i221.i.i.i.i) #3
  %cmp38.i.i.i222.i.i.i.i = fcmp ogt double %610, 0x3EC0000000000000
  br i1 %cmp38.i.i.i222.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

do.body40.i.i.i234.i.i.i.i:                       ; preds = %merged.bb17, %do.body40.i.i.i234.i.i.i.i
  %guess.i.i.i161.i.i.i.i.2 = phi double [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ], [ %mul24.i.i.i210.i.i.i.i, %merged.bb17 ]
  %mul41.i.i.i224.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, %guess.i.i.i161.i.i.i.i.2
  %div42.i.i.i225.i.i.i.i = fdiv double %mul68.i.i.i.i, %guess.i.i.i161.i.i.i.i.2
  %sub43.i.i.i226.i.i.i.i = fsub double %mul41.i.i.i224.i.i.i.i, %div42.i.i.i225.i.i.i.i
  %mul44.i.i.i227.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i228.i.i.i.i = fdiv double %mul68.i.i.i.i, %mul41.i.i.i224.i.i.i.i
  %add46.i.i.i229.i.i.i.i = fadd double %mul44.i.i.i227.i.i.i.i, %div45.i.i.i228.i.i.i.i
  %div47.i.i.i230.i.i.i.i = fdiv double %sub43.i.i.i226.i.i.i.i, %add46.i.i.i229.i.i.i.i
  %sub48.i.i.i231.i.i.i.i = fsub double %guess.i.i.i161.i.i.i.i.2, %div47.i.i.i230.i.i.i.i
  %mul50.i.i.i232.i.i.i.i = fmul double %sub48.i.i.i231.i.i.i.i, 0x3EC0000000000000
  %611 = tail call double @llvm.fabs.f64(double %div47.i.i.i230.i.i.i.i) #3
  %cmp52.i.i.i233.i.i.i.i = fcmp olt double %mul50.i.i.i232.i.i.i.i, %611
  br i1 %cmp52.i.i.i233.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i: ; preds = %do.body40.i.i.i234.i.i.i.i, %do.body.i.i.i223.i.i.i.i, %if.end.i.i.i166.i.i.i.i, %if.then66.i.i.i.i
  %retval.0.i.i.i237.i.i.i.i = phi double [ %mul68.i.i.i.i, %if.then66.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i166.i.i.i.i ], [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ], [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ]
  %div70.i.i.i.i = fdiv double 1.000000e+00, %retval.0.i.i.i237.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else71.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %cmp72.i.i.i.i = fcmp ogt double %sub.i.i.i, 0.000000e+00
  br i1 %cmp72.i.i.i.i, label %if.then73.i.i.i.i, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.then73.i.i.i.i:                                ; preds = %if.else71.i.i.i.i
  %cmp.i.i.i.i79.i.i.i.i = fcmp ogt double %sub.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i.i80.i.i.i.i = fcmp olt double %sub.i.i.i, 0xFFEFFFFFFFFFFFFF
  %612 = or i1 %cmp.i.i.i.i79.i.i.i.i, %cmp1.i.i.i.i80.i.i.i.i
  %or.cond.i.i.i82.i.i.i.i = or i1 %41, %612
  %brmerge170 = or i1 %36, %or.cond.i.i.i82.i.i.i.i
  %sub.i.i.i.mux = select i1 %or.cond.i.i.i82.i.i.i.i, double %sub.i.i.i, double 0x7FF8000000000000
  br i1 %brmerge170, label %if.end7.i.i.i.i.i.i.i, label %if.end4.i.i.i92.i.i.i.i

if.end4.i.i.i92.i.i.i.i:                          ; preds = %if.then73.i.i.i.i
  %cmp5.i.i.i91.i.i.i.i = fcmp olt double %sub.i.i.i, 0.000000e+00
  %fneg.i.i.i93.i.i.i.i = fneg double %sub.i.i.i
  %z.addr.i.i.i76.i.i.i.i.0 = select i1 %cmp5.i.i.i91.i.i.i.i, double %fneg.i.i.i93.i.i.i.i, double %sub.i.i.i
  %613 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %614 = tail call double @llvm.amdgcn.frexp.mant.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %615 = tail call i1 @llvm.amdgcn.class.f64(double %z.addr.i.i.i76.i.i.i.i.0, i32 519) #3
  %616 = select i1 %615, i32 0, i32 %613
  %617 = select i1 %615, double %z.addr.i.i.i76.i.i.i.i.0, double %614
  %mul.i.i.i.i.i97.i.i.i.i = fmul double %617, %617
  %mul1.i.i.i.i.i98.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i99.i.i.i.i = fadd double %mul1.i.i.i.i.i98.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i100.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FE479D17050CA47
  %618 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i100.i.i.i.i
  %mul10.i.i.i.i.i102.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %add.i.i.i.i.i99.i.i.i.i
  %mul12.i.i.i.i.i103.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %618
  %add15.i.i.i.i.i104.i.i.i.i = fadd double %mul10.i.i.i.i.i102.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i105.i.i.i.i = fadd double %mul12.i.i.i.i.i103.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i106.i.i.i.i = fmul double %617, %add15.i.i.i.i.i104.i.i.i.i
  %add23.i.i.i.i.i107.i.i.i.i = fadd double %add18.i.i.i.i.i105.i.i.i.i, %mul20.i.i.i.i.i106.i.i.i.i
  %.frozen213 = freeze i32 %616
  %div.i.i.i108.i.i.i.i = sdiv i32 %.frozen213, 3
  %619 = sub nsw i32 0, %div.i.i.i108.i.i.i.i
  %620 = call i32 @llvm.abs.i32(i32 %div.i.i.i108.i.i.i.i, i1 true)
  %cmp11.i.i.i110.i.i.i.i = icmp ult i32 %620, 64
  %621 = icmp sgt i32 %616, 2
  %622 = select i1 %621, i32 %div.i.i.i108.i.i.i.i, i32 %619
  %623 = zext i32 %622 to i64
  %624 = shl nuw i64 1, %623
  %625 = uitofp i64 %624 to double
  %not.cmp11.i.i.i110.i.i.i.i = xor i1 %cmp11.i.i.i110.i.i.i.i, true
  %626 = or i1 %621, %not.cmp11.i.i.i110.i.i.i.i
  br i1 %626, label %merged.bb18, label %merged.bb19, !decision.merged_from !22, !decision.origin !23

if.then12.i.i.i32.i.i.i.i:                        ; preds = %merged.bb23
  br i1 %621, label %if.then14.i.i.i37.i.i.i.i, label %if.else.i.i.i43.i.i.i.i, !decision.merged_from !24, !decision.origin !25

if.then14.i.i.i37.i.i.i.i:                        ; preds = %if.then12.i.i.i32.i.i.i.i
  %mul.i.i.i36.i.i.i.i = fmul double %add23.i.i.i.i.i107.i.i.i.i, %625
  br label %if.end23.i.i.i50.i.i.i.i

if.else.i.i.i43.i.i.i.i:                          ; preds = %if.then12.i.i.i32.i.i.i.i
  %div19.i.i.i42.i.i.i.i = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %625
  br label %if.end23.i.i.i50.i.i.i.i

if.else21.i.i.i44.i.i.i.i:                        ; preds = %merged.bb23
  %627 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  br label %if.end23.i.i.i50.i.i.i.i

if.end23.i.i.i50.i.i.i.i:                         ; preds = %if.else21.i.i.i44.i.i.i.i, %if.else.i.i.i43.i.i.i.i, %if.then14.i.i.i37.i.i.i.i
  %guess.i.i.i10.i.i.i.i.0 = phi double [ %mul.i.i.i36.i.i.i.i, %if.then14.i.i.i37.i.i.i.i ], [ %div19.i.i.i42.i.i.i.i, %if.else.i.i.i43.i.i.i.i ], [ %627, %if.else21.i.i.i44.i.i.i.i ]
  %mul24.i.i.i48.i.i.i.i = fmul double %1141, %guess.i.i.i10.i.i.i.i.0
  br label %merged.bb

if.end7.i.i.i.i.i.i.i:                            ; preds = %merged.bb21, %if.then73.i.i.i.i
  %retval.0.i.i.i156.i.i.i.i162 = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %1185, %merged.bb21 ]
  %retval.0.i.i.i.i.i.i.i = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %1163, %merged.bb21 ]
  %mul76.i.i.i.i = fmul double %retval.0.i.i.i156.i.i.i.i162, %retval.0.i.i.i.i.i.i.i
  %mul79.i.i.i.i = fmul double %mul76.i.i.i.i, 0x3FFD8639FDCB60EB
  %div80.i.i.i.i = fdiv double 1.000000e+00, %mul79.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

cond.false7.i.i.i:                                ; preds = %if.end14.i.i
  %decision.interval2 = fcmp ult double %arrayidx.val, 2.500000e-01
  br i1 %decision.interval2, label %if.else9.i28.i.i.i, label %decision.dispatch1, !decision.condition_prefix !6

decision.dispatch1:                               ; preds = %cond.false7.i.i.i
  %cmp.i4.i.i.i = fcmp ult double %arrayidx.val, 3.750000e-01
  %628 = select i1 %cmp.i4.i.i.i, double -2.500000e-01, double -3.750000e-01
  %629 = fadd double %arrayidx.val, %628
  %630 = fmul double %629, %629
  %631 = select i1 %cmp.i4.i.i.i, double 0x402A50B00A1E7B86, double 0x40132BDEE3243B58
  %632 = fmul double %630, %631
  %633 = select i1 %cmp.i4.i.i.i, double 0xC03EAAFBAB179207, double 0xC0360FDD97954BA2
  %634 = fadd double %632, %633
  %635 = select i1 %cmp.i4.i.i.i, double 0x403CBAD71AE3B29A, double 0x401CB5EDEDB31A3B
  %636 = fmul double %630, %635
  %637 = fadd double %636, 0xC017CB97C9E45E0D
  %638 = fsub double 0x4040A8BCD7811DE4, %636
  %fusion.paired2 = select i1 %cmp.i4.i.i.i, double %638, double %637
  %639 = fmul double %630, %634
  %640 = fmul double %630, %fusion.paired2
  %641 = select i1 %cmp.i4.i.i.i, double 0x402CB09090084637, double 0x4027FEF192CFFD80
  %642 = fadd double %639, %641
  %643 = select i1 %cmp.i4.i.i.i, double 0xC013B1AD6B90733F, double 0x3FF83BDAD25D5F48
  %644 = fadd double %640, %643
  %645 = fmul double %630, %642
  %646 = select i1 %cmp.i4.i.i.i, double 0xBFFA1FFFE7A41296, double 0xBFF2C5AD0DCDC29A
  %647 = fadd double %645, %646
  %648 = fmul double %629, %644
  %649 = fadd double %648, %647
  %650 = select i1 %cmp.i4.i.i.i, double 0x40296F06194D60C2, double 0x3FF693D2420640AD
  %651 = fmul double %630, %650
  %652 = fsub double 0x401B5545C0CB5BDA, %651
  %653 = fmul double %630, 0x40074E9A9F865729
  %654 = select i1 %cmp.i4.i.i.i, double %651, double %653
  %655 = select i1 %cmp.i4.i.i.i, double 0xC030F25386AA802B, double 0xC016B372910B83AB
  %656 = fadd double %654, %655
  %657 = select i1 %cmp.i4.i.i.i, double 0x40199996D51EE9B7, double %652
  %658 = fmul double %630, %657
  %659 = fsub double 0x40034649FCCCF81F, %658
  %660 = fmul double %630, %656
  %661 = fadd double %658, 0xC0138A29DF206C0B
  %662 = select i1 %cmp.i4.i.i.i, double 0x40158CEB587D3265, double 0x3FFC33F0B4C09D66
  %663 = fadd double %660, %662
  %664 = select i1 %cmp.i4.i.i.i, double %659, double %661
  %fusion.paired8 = fmul double %630, %664
  %665 = fadd double %fusion.paired8, 1.000000e+00
  %666 = fmul double %629, %663
  %667 = select i1 %cmp.i4.i.i.i, double %665, double %666
  %668 = select i1 %cmp.i4.i.i.i, double %666, double %665
  %669 = fadd double %667, %668
  %670 = fdiv double %649, %669
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else9.i28.i.i.i:                               ; preds = %cond.false7.i.i.i
  %cmp10.i.i.i.i = fcmp ult double %arrayidx.val, 1.250000e-01
  %671 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %arrayidx.val) #3
  %672 = add nsw i32 %671, -1
  %673 = tail call double @llvm.fabs.f64(double %arrayidx.val) #4
  %674 = fcmp oeq double %673, 0x7FF0000000000000
  %675 = select i1 %674, i32 2147483647, i32 %672
  %676 = fcmp oeq double %arrayidx.val, 0.000000e+00
  %677 = select i1 %676, i32 -2147483648, i32 %675
  %cmp19.i.i.i.i = icmp slt i32 %677, -4
  %decision.value = select i1 %cmp10.i.i.i.i, i32 %677, i32 undef
  %678 = and i1 %cmp10.i.i.i.i, %cmp19.i.i.i.i
  br i1 %678, label %if.else27.i.i.i.i, label %decision.dispatch3, !decision.short_gate !6

if.then11.i.i.i.i:                                ; preds = %decision.dispatch3
  %sub13.i.i.i.i = fadd double %arrayidx.val, -1.250000e-01
  %mul.i.i270.i.i.i.i = fmul double %sub13.i.i.i.i, %sub13.i.i.i.i
  %mul1.i.i271.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x406D392CDE09E490
  %679 = fsub double 0x408C7AAA9D225E9A, %mul1.i.i271.i.i.i.i
  %mul5.i.i273.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x408B6249334DA816
  %680 = fsub double 0x408C1B9BAF952B96, %mul5.i.i273.i.i.i.i
  %mul10.i.i275.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %679
  %mul12.i.i276.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %680
  %add15.i.i277.i.i.i.i = fadd double %mul10.i.i275.i.i.i.i, 0xC05E9BCF5C362E51
  %add18.i.i278.i.i.i.i = fadd double %mul12.i.i276.i.i.i.i, 0xC066A4A24A4E1713
  %mul20.i.i279.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add15.i.i277.i.i.i.i
  %mul22.i.i280.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add18.i.i278.i.i.i.i
  %add25.i.i281.i.i.i.i = fadd double %mul20.i.i279.i.i.i.i, 0xC04249A2BD20D346
  %add28.i.i282.i.i.i.i = fadd double %mul22.i.i280.i.i.i.i, 0xC001804F92FE2A82
  %mul30.i.i283.i.i.i.i = fmul double %sub13.i.i.i.i, %add25.i.i281.i.i.i.i
  %add33.i.i284.i.i.i.i = fadd double %add28.i.i282.i.i.i.i, %mul30.i.i283.i.i.i.i
  %mul1.i.i256.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x405E5232607614DB
  %add.i.i257.i.i.i.i = fadd double %mul1.i.i256.i.i.i.i, 0xC0809E1D789AFFE5
  %mul5.i.i258.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, 0x404C078043CB129C
  %681 = fsub double 0xC0320C17B7F0ED52, %mul5.i.i258.i.i.i.i
  %mul10.i.i260.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add.i.i257.i.i.i.i
  %mul12.i.i261.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %681
  %add15.i.i262.i.i.i.i = fadd double %mul10.i.i260.i.i.i.i, 0x4071A64A34042F35
  %add18.i.i263.i.i.i.i = fadd double %mul12.i.i261.i.i.i.i, 0x405F12CC60181A8F
  %mul20.i.i264.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add15.i.i262.i.i.i.i
  %mul22.i.i265.i.i.i.i = fmul double %mul.i.i270.i.i.i.i, %add18.i.i263.i.i.i.i
  %add25.i.i266.i.i.i.i = fadd double %mul20.i.i264.i.i.i.i, 0x40332E0500972875
  %add28.i.i267.i.i.i.i = fadd double %mul22.i.i265.i.i.i.i, 1.000000e+00
  %mul30.i.i268.i.i.i.i = fmul double %sub13.i.i.i.i, %add25.i.i266.i.i.i.i
  %add33.i.i269.i.i.i.i = fadd double %add28.i.i267.i.i.i.i, %mul30.i.i268.i.i.i.i
  br label %fusion.suffix

decision.dispatch3:                               ; preds = %if.else9.i28.i.i.i
  br i1 %cmp10.i.i.i.i, label %if.then20.i.i.i.i, label %if.then11.i.i.i.i, !decision.merged_from !26, !decision.origin !27

if.then20.i.i.i.i:                                ; preds = %decision.dispatch3
  %682 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 3) #3
  %683 = tail call double @llvm.amdgcn.frexp.mant.f64(double %682) #3
  %684 = fcmp olt double %683, 0x3FE5555555555555
  %685 = zext i1 %684 to i32
  %686 = tail call double @llvm.amdgcn.ldexp.f64(double %683, i32 %685) #3
  %687 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %682) #3
  %688 = sub nsw i32 %687, %685
  %689 = fadd double %686, -1.000000e+00
  %690 = fadd double %686, 1.000000e+00
  %691 = fsub double %690, %686
  %692 = fsub double %690, %691
  %693 = fsub double %686, %692
  %694 = fsub double 1.000000e+00, %691
  %695 = fadd double %694, %693
  %696 = tail call double @llvm.amdgcn.rcp.f64(double %690) #3
  %697 = fneg double %690
  %698 = tail call double @llvm.fma.f64(double %697, double %696, double 1.000000e+00) #3
  %699 = tail call double @llvm.fma.f64(double %698, double %696, double %696) #3
  %700 = tail call double @llvm.fma.f64(double %697, double %699, double 1.000000e+00) #3
  %701 = tail call double @llvm.fma.f64(double %700, double %699, double %699) #3
  %702 = fmul double %689, %701
  %703 = fmul double %690, %702
  %704 = fneg double %703
  %705 = tail call double @llvm.fma.f64(double %702, double %690, double %704) #3
  %706 = tail call double @llvm.fma.f64(double %702, double %695, double %705) #3
  %707 = fadd double %703, %706
  %708 = fsub double %707, %703
  %709 = fsub double %706, %708
  %710 = fsub double %689, %707
  %711 = fsub double %689, %710
  %712 = fsub double %711, %707
  %713 = fsub double %712, %709
  %714 = fadd double %710, %713
  %715 = fmul double %701, %714
  %716 = fadd double %702, %715
  %717 = fsub double %716, %702
  %718 = fsub double %715, %717
  %719 = fmul double %716, %716
  %720 = fneg double %719
  %721 = tail call double @llvm.fma.f64(double %716, double %716, double %720) #3
  %722 = fmul double %718, 2.000000e+00
  %723 = tail call double @llvm.fma.f64(double %716, double %722, double %721) #3
  %724 = tail call double @llvm.fma.f64(double %718, double %718, double %723) #3
  %725 = fadd double %719, %724
  %726 = fsub double %725, %719
  %727 = fsub double %724, %726
  %728 = tail call double @llvm.fma.f64(double %725, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %729 = tail call double @llvm.fma.f64(double %725, double %728, double 0x3FC7474DD7F4DF2E) #3
  %730 = tail call double @llvm.fma.f64(double %725, double %729, double 0x3FCC71C016291751) #3
  %731 = tail call double @llvm.fma.f64(double %725, double %730, double 0x3FD249249B27ACF1) #3
  %732 = tail call double @llvm.fma.f64(double %725, double %731, double 0x3FD99999998EF7B6) #3
  %733 = tail call double @llvm.fma.f64(double %725, double %732, double 0x3FE5555555555780) #3
  %734 = tail call double @llvm.amdgcn.ldexp.f64(double %716, i32 1) #3
  %735 = tail call double @llvm.amdgcn.ldexp.f64(double %718, i32 1) #3
  %736 = fmul double %716, %725
  %737 = fneg double %736
  %738 = tail call double @llvm.fma.f64(double %716, double %725, double %737) #3
  %739 = fmul double %718, %725
  %740 = tail call double @llvm.fma.f64(double %716, double %727, double %739) #3
  %741 = fadd double %738, %740
  %742 = fadd double %736, %741
  %743 = fsub double %742, %736
  %744 = fsub double %741, %743
  %745 = fmul double %742, %733
  %746 = fneg double %745
  %747 = tail call double @llvm.fma.f64(double %742, double %733, double %746) #3
  %748 = tail call double @llvm.fma.f64(double %744, double %733, double %747) #3
  %749 = fadd double %745, %748
  %750 = fsub double %749, %745
  %751 = fsub double %748, %750
  %752 = fadd double %734, %749
  %753 = fsub double %752, %734
  %754 = fsub double %752, %753
  %755 = fsub double %734, %754
  %756 = fsub double %749, %753
  %757 = fadd double %756, %755
  %758 = fadd double %735, %751
  %759 = fsub double %758, %735
  %760 = fsub double %758, %759
  %761 = fsub double %735, %760
  %762 = fsub double %751, %759
  %763 = fadd double %762, %761
  %764 = fadd double %758, %757
  %765 = fadd double %752, %764
  %766 = fsub double %765, %752
  %767 = fsub double %764, %766
  %768 = fadd double %763, %767
  %769 = fadd double %765, %768
  %770 = fsub double %769, %765
  %771 = fsub double %768, %770
  %772 = sitofp i32 %688 to double
  %773 = fmul double %769, 0x3FF71547652B82FE
  %774 = fneg double %773
  %775 = fmul double %769, 0x3C7777D0FFDA0D24
  %776 = insertelement <2 x double> undef, double %769, i32 0
  %777 = insertelement <2 x double> %776, double %771, i32 1
  %778 = insertelement <2 x double> undef, double %774, i32 0
  %779 = insertelement <2 x double> %778, double %775, i32 1
  %780 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %777, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %779) #3
  %781 = extractelement <2 x double> %780, i32 0
  %782 = extractelement <2 x double> %780, i32 1
  %783 = fadd double %781, %782
  %784 = fadd double %773, %783
  %785 = fsub double %784, %773
  %786 = fsub double %783, %785
  %787 = fadd double %784, %772
  %788 = fsub double %787, %772
  %789 = fsub double %788, %787
  %790 = fadd double %789, %772
  %791 = fsub double %784, %788
  %792 = fadd double %791, %790
  %793 = fadd double %786, %792
  %794 = fadd double %787, %793
  %795 = tail call double @llvm.fabs.f64(double %682) #4
  %796 = fcmp oeq double %795, 0x7FF0000000000000
  %797 = select i1 %796, double %682, double %794
  %798 = fcmp olt double %682, 0.000000e+00
  %799 = select i1 %798, double 0x7FF8000000000000, double %797
  %800 = fcmp oeq double %682, 0.000000e+00
  %801 = select i1 %800, double 0xFFF0000000000000, double %799
  %mul.i.i244.i.i.i.i = fmul double %801, %801
  %mul1.i.i245.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F1989D450BBA5CA
  %802 = fsub double 0xBFBD94CCEC41CB08, %mul1.i.i245.i.i.i.i
  %mul5.i.i247.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F7B3A00DD9C9429
  %803 = fsub double 0xBFE8DDD719DA7D3E, %mul5.i.i247.i.i.i.i
  %mul10.i.i249.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %802
  %mul12.i.i250.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %803
  %add15.i.i251.i.i.i.i = fadd double %mul10.i.i249.i.i.i.i, 0xC001974D2C397C76
  %add18.i.i252.i.i.i.i = fadd double %mul12.i.i250.i.i.i.i, 0xC001804F92FE2A82
  %804 = fmul double %801, %add15.i.i251.i.i.i.i
  %add23.i.i254.i.i.i.i = fsub double %add18.i.i252.i.i.i.i, %804
  %mul1.i.i234.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3EDBEC7AF5AC0D6F
  %add.i.i235.i.i.i.i = fadd double %mul1.i.i234.i.i.i.i, 0x3F98BA1DB321D0E9
  %mul5.i.i236.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, 0x3F4ED662BB480251
  %add7.i.i237.i.i.i.i = fadd double %mul5.i.i236.i.i.i.i, 0x3FCBD444F5D4FCC2
  %mul10.i.i238.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %add.i.i235.i.i.i.i
  %mul12.i.i239.i.i.i.i = fmul double %mul.i.i244.i.i.i.i, %add7.i.i237.i.i.i.i
  %add15.i.i240.i.i.i.i = fadd double %mul10.i.i238.i.i.i.i, 0x3FE957680773BEB6
  %add18.i.i241.i.i.i.i = fadd double %mul12.i.i239.i.i.i.i, 1.000000e+00
  %805 = fmul double %801, %add15.i.i240.i.i.i.i
  %add23.i.i243.i.i.i.i = fsub double %add18.i.i241.i.i.i.i, %805
  br label %fusion.suffix

if.else27.i.i.i.i:                                ; preds = %if.else9.i28.i.i.i
  %cmp106.i.i.i.i = icmp sgt i32 %decision.value, -1025
  br i1 %cmp106.i.i.i.i, label %decision.dispatch2, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, !decision.condition_prefix !6

decision.dispatch2:                               ; preds = %if.else27.i.i.i.i
  %cmp84.i.i.i.i = icmp sgt i32 %decision.value, -257
  %806 = icmp sgt i32 %decision.value, -65
  %807 = icmp sgt i32 %decision.value, -17
  %808 = select i1 %807, i32 -9, i32 -33
  %809 = select i1 %806, i32 %808, i32 -129
  %810 = select i1 %cmp84.i.i.i.i, i1 %806, i1 undef
  %811 = select i1 %806, i1 %807, i1 undef
  %merged.select = select i1 %cmp84.i.i.i.i, i32 %809, i32 -513
  %812 = icmp sgt i32 %decision.value, %merged.select
  %813 = select i1 %811, i32 4, i32 16
  %814 = select i1 %811, i32 8, i32 32
  %815 = select i1 %810, i32 %813, i32 64
  %816 = select i1 %810, i32 %814, i32 128
  %merged.select64 = select i1 %cmp84.i.i.i.i, i32 %815, i32 256
  %merged.select65 = select i1 %cmp84.i.i.i.i, i32 %816, i32 512
  %817 = select i1 %812, i32 %merged.select64, i32 %merged.select65
  %818 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %817) #3
  %819 = tail call double @llvm.amdgcn.frexp.mant.f64(double %818) #3
  %820 = fcmp olt double %819, 0x3FE5555555555555
  %821 = zext i1 %820 to i32
  %822 = tail call double @llvm.amdgcn.ldexp.f64(double %819, i32 %821) #3
  %823 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %818) #3
  %824 = sub nsw i32 %823, %821
  %825 = fadd double %822, -1.000000e+00
  %826 = fadd double %822, 1.000000e+00
  %827 = fsub double %826, %822
  %828 = fsub double %826, %827
  %829 = fsub double %822, %828
  %830 = fsub double 1.000000e+00, %827
  %831 = fadd double %830, %829
  %832 = tail call double @llvm.amdgcn.rcp.f64(double %826) #3
  %833 = fneg double %826
  %834 = tail call double @llvm.fma.f64(double %833, double %832, double 1.000000e+00) #3
  %835 = tail call double @llvm.fma.f64(double %834, double %832, double %832) #3
  %836 = tail call double @llvm.fma.f64(double %833, double %835, double 1.000000e+00) #3
  %837 = tail call double @llvm.fma.f64(double %836, double %835, double %835) #3
  %838 = fmul double %825, %837
  %839 = fmul double %826, %838
  %840 = fneg double %839
  %841 = tail call double @llvm.fma.f64(double %838, double %826, double %840) #3
  %842 = tail call double @llvm.fma.f64(double %838, double %831, double %841) #3
  %843 = fadd double %839, %842
  %844 = fsub double %843, %839
  %845 = fsub double %842, %844
  %846 = fsub double %825, %843
  %847 = fsub double %825, %846
  %848 = fsub double %847, %843
  %849 = fsub double %848, %845
  %850 = fadd double %846, %849
  %851 = fmul double %837, %850
  %852 = fadd double %838, %851
  %853 = fsub double %852, %838
  %854 = fsub double %851, %853
  %855 = fmul double %852, %852
  %856 = fneg double %855
  %857 = tail call double @llvm.fma.f64(double %852, double %852, double %856) #3
  %858 = fmul double %854, 2.000000e+00
  %859 = tail call double @llvm.fma.f64(double %852, double %858, double %857) #3
  %860 = tail call double @llvm.fma.f64(double %854, double %854, double %859) #3
  %861 = fadd double %855, %860
  %862 = fsub double %861, %855
  %863 = fsub double %860, %862
  %864 = tail call double @llvm.fma.f64(double %861, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %865 = tail call double @llvm.fma.f64(double %861, double %864, double 0x3FC7474DD7F4DF2E) #3
  %866 = tail call double @llvm.fma.f64(double %861, double %865, double 0x3FCC71C016291751) #3
  %867 = tail call double @llvm.fma.f64(double %861, double %866, double 0x3FD249249B27ACF1) #3
  %868 = tail call double @llvm.fma.f64(double %861, double %867, double 0x3FD99999998EF7B6) #3
  %869 = tail call double @llvm.fma.f64(double %861, double %868, double 0x3FE5555555555780) #3
  %870 = tail call double @llvm.amdgcn.ldexp.f64(double %852, i32 1) #3
  %871 = tail call double @llvm.amdgcn.ldexp.f64(double %854, i32 1) #3
  %872 = fmul double %852, %861
  %873 = fneg double %872
  %874 = tail call double @llvm.fma.f64(double %852, double %861, double %873) #3
  %875 = fmul double %854, %861
  %876 = tail call double @llvm.fma.f64(double %852, double %863, double %875) #3
  %877 = fadd double %874, %876
  %878 = fadd double %872, %877
  %879 = fsub double %878, %872
  %880 = fsub double %877, %879
  %881 = fmul double %878, %869
  %882 = fneg double %881
  %883 = tail call double @llvm.fma.f64(double %878, double %869, double %882) #3
  %884 = tail call double @llvm.fma.f64(double %880, double %869, double %883) #3
  %885 = fadd double %881, %884
  %886 = fsub double %885, %881
  %887 = fsub double %884, %886
  %888 = fadd double %870, %885
  %889 = fsub double %888, %870
  %890 = fsub double %888, %889
  %891 = fsub double %870, %890
  %892 = fsub double %885, %889
  %893 = fadd double %892, %891
  %894 = fadd double %871, %887
  %895 = fsub double %894, %871
  %896 = fsub double %894, %895
  %897 = fsub double %871, %896
  %898 = fsub double %887, %895
  %899 = fadd double %898, %897
  %900 = fadd double %894, %893
  %901 = fadd double %888, %900
  %902 = fsub double %901, %888
  %903 = fsub double %900, %902
  %904 = fadd double %899, %903
  %905 = fadd double %901, %904
  %906 = fsub double %905, %901
  %907 = fsub double %904, %906
  %908 = sitofp i32 %824 to double
  %909 = fmul double %905, 0x3FF71547652B82FE
  %910 = fneg double %909
  %911 = fmul double %905, 0x3C7777D0FFDA0D24
  br i1 %812, label %fusion.side, label %fusion.side1

fusion.side5:                                     ; preds = %decision.dispatch
  %912 = fmul double %10, %24
  %913 = fadd double %912, 0x3FDED118296B2018
  %914 = fmul double %10, 0x3FEFDC5AEE1525E4
  %915 = fsub double 0x4043A793DEC20DEB, %914
  %916 = fmul double %10, %915
  %917 = fadd double %916, 0xC04B158FF790C730
  br label %fusion.suffix1

fusion.suffix1:                                   ; preds = %fusion.side5, %decision.dispatch
  %918 = phi double [ %33, %decision.dispatch ], [ %917, %fusion.side5 ]
  %919 = phi double [ 0x407BA4300BFE5087, %decision.dispatch ], [ 0xC02E8C55CA7195EF, %fusion.side5 ]
  %920 = phi double [ 0x4063AA2F5D62DCD3, %decision.dispatch ], [ 0x403058D46A8EC004, %fusion.side5 ]
  %921 = phi double [ 0x40354F2A1256B431, %decision.dispatch ], [ 0x4020675EC4F85A38, %fusion.side5 ]
  %922 = phi double [ 0xC083E59B9D34A0F1, %decision.dispatch ], [ 0x401A11C0BB0DC22E, %fusion.side5 ]
  %923 = phi double [ 0x406113A5A6902AC1, %decision.dispatch ], [ %33, %fusion.side5 ]
  %924 = phi double [ %27, %decision.dispatch ], [ %29, %fusion.side5 ]
  %925 = phi double [ %29, %decision.dispatch ], [ %913, %fusion.side5 ]
  %926 = fadd double %925, %924
  %927 = fmul double %10, %923
  %928 = fadd double %927, %922
  %929 = fmul double %10, %928
  %930 = fmul double %10, %918
  %931 = fadd double %929, %919
  %932 = fadd double %930, %920
  %933 = fmul double %10, %931
  %934 = fmul double %10, %932
  %935 = fadd double %933, %921
  %936 = fadd double %934, 1.000000e+00
  %937 = fmul double %9, %935
  %938 = fadd double %936, %937
  %939 = fdiv double %926, %938
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

fusion.suffix:                                    ; preds = %if.then20.i.i.i.i, %if.then11.i.i.i.i
  %940 = phi double [ %add33.i.i269.i.i.i.i, %if.then11.i.i.i.i ], [ %add23.i.i243.i.i.i.i, %if.then20.i.i.i.i ]
  %941 = phi double [ %add33.i.i284.i.i.i.i, %if.then11.i.i.i.i ], [ %add23.i.i254.i.i.i.i, %if.then20.i.i.i.i ]
  %942 = fdiv double %941, %940
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i: ; preds = %fusion.common, %fusion.suffix, %fusion.suffix1, %if.else27.i.i.i.i, %decision.dispatch1, %if.end7.i.i.i.i.i.i.i, %if.else71.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i
  %retval.0.i.i.i = phi double [ %div20.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i ], [ %div34.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i ], [ %div48.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i ], [ %div62.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i ], [ %div70.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i ], [ 0x7FF0000000000000, %if.else71.i.i.i.i ], [ %div80.i.i.i.i, %if.end7.i.i.i.i.i.i.i ], [ %670, %decision.dispatch1 ], [ 0xFFF0000000000000, %if.else27.i.i.i.i ], [ %939, %fusion.suffix1 ], [ %942, %fusion.suffix ], [ %1099, %fusion.common ]
  %add.i.i = fadd double %retval.0.i.i.i, 0.000000e+00
  br label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit

_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit: ; preds = %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, %lor.lhs.false2.i.i.i, %if.end8.i.i
  %retval.0.i.i = phi double [ 0x7FF8000000000000, %if.end8.i.i ], [ 0x7FF8000000000000, %lor.lhs.false2.i.i.i ], [ %add.i.i, %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i ]
  %arrayidx712 = getelementptr inbounds double, double addrspace(1)* %output.coerce, i64 %idxprom
  store double %retval.0.i.i, double addrspace(1)* %arrayidx712, align 8, !tbaa !8
  br label %if.end

if.end:                                           ; preds = %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, %entry
  ret void

fusion.side:                                      ; preds = %decision.dispatch2
  %943 = insertelement <2 x double> undef, double %905, i32 0
  %944 = insertelement <2 x double> %943, double %907, i32 1
  %945 = insertelement <2 x double> undef, double %910, i32 0
  %946 = insertelement <2 x double> %945, double %911, i32 1
  br label %fusion.common

fusion.side1:                                     ; preds = %decision.dispatch2
  %947 = insertelement <2 x double> undef, double %905, i32 0
  %948 = insertelement <2 x double> %947, double %907, i32 1
  %949 = insertelement <2 x double> undef, double %910, i32 0
  %950 = insertelement <2 x double> %949, double %911, i32 1
  br label %fusion.common

fusion.common:                                    ; preds = %fusion.side1, %fusion.side
  %951 = phi double [ 0x3F86397D81A61D6E, %fusion.side ], [ 0x3F762C8C65771E78, %fusion.side1 ]
  %952 = phi double [ 0x3F0730EC426E6E84, %fusion.side ], [ 0x3EE71602E8EA99F3, %fusion.side1 ]
  %953 = phi double [ 0x3E768F19E4302EF3, %fusion.side ], [ 0x3E46680C94743FD9, %fusion.side1 ]
  %954 = phi double [ 0x3D1ED0326F0CBDDC, %fusion.side ], [ 0x3CCE78F4A7F13C7D, %fusion.side1 ]
  %955 = phi double [ 0x3DD49301DA58AEFA, %fusion.side ], [ 0x3D9463E48A976F97, %fusion.side1 ]
  %956 = phi double [ 0x3C495387D39D2504, %fusion.side ], [ 0x3BE8FEBB5A4047D7, %fusion.side1 ]
  %957 = phi double [ 0xC02A92BAF87A7B72, %fusion.side ], [ 0xC030CB31255FFA09, %fusion.side1 ]
  %958 = phi double [ 0xBFC4B5F131A679CC, %fusion.side ], [ 0xBFBA19EDB555D8AD, %fusion.side1 ]
  %959 = phi double [ 0xBF48C2CA21FD14A5, %fusion.side ], [ 0xBF2F1E266EB4C824, %fusion.side1 ]
  %960 = phi double [ 0xBEBC6E261AE99633, %fusion.side ], [ 0xBE91D0F7FEBA5A35, %fusion.side1 ]
  %961 = phi double [ 0xBE2007A65CA14E38, %fusion.side ], [ 0xBDE40A018263D493, %fusion.side1 ]
  %962 = phi double [ 0x3CA5D280D4B5A285, %fusion.side ], [ 0x3C4B275AC5F91B68, %fusion.side1 ]
  %963 = phi double [ 0xBD7021DF3392EE60, %fusion.side ], [ 0xBD241E51766A91FB, %fusion.side1 ]
  %964 = phi double [ 0x3BAA9A26E0297ED8, %fusion.side ], [ 0x3B408480D3491A50, %fusion.side1 ]
  %965 = phi double [ 0x3FC6B0CE3157BCB1, %fusion.side ], [ 0x3FB68627D1A51CB5, %fusion.side1 ]
  %966 = phi double [ 0x3F882FD20DA34F30, %fusion.side ], [ 0x3F67D3564F778B21, %fusion.side1 ]
  %967 = phi double [ 0x3F380B62C1407B15, %fusion.side ], [ 0x3F077F4625619D43, %fusion.side1 ]
  %968 = phi double [ 0x3E6129D961D79065, %fusion.side ], [ 0x3E107ECF99D6009A, %fusion.side1 ]
  %969 = phi double [ 0x3ED66AFC954DE682, %fusion.side ], [ 0x3E95BA568EDD3BFB, %fusion.side1 ]
  %970 = phi double [ 0x3DCCD7C812F40049, %fusion.side ], [ 0x3D6B7BD497A2CD17, %fusion.side1 ]
  %971 = phi double [ 0xC013B000D66B8269, %fusion.side ], [ 0xC019A861C808DCFC, %fusion.side1 ]
  %972 = phi double [ 0xBFEFD66AE54A0BCB, %fusion.side ], [ 0xBFE46D859460DB51, %fusion.side1 ]
  %973 = phi double [ 0xBFB3B5B6F694BB9E, %fusion.side ], [ 0xBF98ED20B1D6A6D8, %fusion.side1 ]
  %974 = phi double [ 0xBF676495E4B7EAAA, %fusion.side ], [ 0xBF3D2E78945F9AC6, %fusion.side1 ]
  %975 = phi double [ 0xBF0B3634004E0F5C, %fusion.side ], [ 0xBED0C1E92AD969EF, %fusion.side1 ]
  %976 = phi double [ 0x3E1390C28573DB0F, %fusion.side ], [ 0x3DB79116B58241AA, %fusion.side1 ]
  %977 = phi double [ 0xBE9C2F1FFD2FFECD, %fusion.side ], [ 0xBE512769C01EA7C5, %fusion.side1 ]
  %978 = phi double [ 0x3D5866A3E6D0F156, %fusion.side ], [ 0x3CED1FCD2AD8841F, %fusion.side1 ]
  %979 = phi double [ 0x3FE7235AE26E3A60, %fusion.side ], [ 0x3FD6E5B7AB236028, %fusion.side1 ]
  %980 = phi double [ 0x3FC92E7DCCD1B70C, %fusion.side ], [ 0x3FA8A45F1AE4ADBE, %fusion.side1 ]
  %981 = phi double [ 0x3F999857B526C821, %fusion.side ], [ 0x3F68BF137C253BD1, %fusion.side1 ]
  %982 = phi double [ 0x3F0330822740ADF9, %fusion.side ], [ 0x3EB20E304F6E5BCE, %fusion.side1 ]
  %983 = phi double [ 0x3F586FC94B9EAD30, %fusion.side ], [ 0x3F1751EF5755C229, %fusion.side1 ]
  %984 = phi double [ 0x3E9090FBB4B042AE, %fusion.side ], [ 0x3E2EB2F3F6504F32, %fusion.side1 ]
  %985 = phi double [ 0xC004C929A952DE48, %fusion.side ], [ 0xC00D636ADAEC3C05, %fusion.side1 ]
  %986 = phi double [ 0xC001F1CD6A03BCAA, %fusion.side ], [ 0xBFF8595CA25899FD, %fusion.side1 ]
  %987 = phi double [ 0xBFE78F054AC7A90B, %fusion.side ], [ 0xBFCED54905311121, %fusion.side1 ]
  %988 = phi double [ 0xBFBD7935AC58B5B5, %fusion.side ], [ 0xBF92AE2345C460A0, %fusion.side1 ]
  %989 = phi double [ 0xBF81F96D17A7115B, %fusion.side ], [ 0xBF4625660A41D7B1, %fusion.side1 ]
  %990 = phi double [ 0x3ECBFD524C94F258, %fusion.side ], [ 0x3E70731CF2A765F0, %fusion.side1 ]
  %991 = phi double [ 0xBF336C13BBA203F3, %fusion.side ], [ 0xBEE755F1646665DB, %fusion.side1 ]
  %992 = phi double [ 0x3E32022ABCFF5DE7, %fusion.side ], [ 0x3DC4C8BD76453064, %fusion.side1 ]
  %993 = phi double [ 0x3C819FA1E5E36C20, %fusion.side ], [ 0x3C158FD8B3C1B0C0, %fusion.side1 ]
  %994 = phi double [ 0xBE050B1B8007F8FF, %fusion.side ], [ 0xBDB9FC7E20BD04CC, %fusion.side1 ]
  %995 = phi double [ 0x3D5CB3C39661DD79, %fusion.side ], [ 0x3D01A287ED1019B8, %fusion.side1 ]
  %996 = phi double [ 0xBE94B8A80FB81310, %fusion.side ], [ 0xBE59BA2A0439E4A9, %fusion.side1 ]
  %997 = phi double [ 0xBF1232A95F4E8466, %fusion.side ], [ 0xBEE6B9C7BCE39403, %fusion.side1 ]
  %998 = phi double [ 0xBF7F5FDEC6827012, %fusion.side ], [ 0xBF63B612102F3C24, %fusion.side1 ]
  %999 = phi double [ 0xBFD9F6368DFEFDDF, %fusion.side ], [ 0xBFD06A8AF4A3FC55, %fusion.side1 ]
  %1000 = phi double [ 0xC0207852FA1731C0, %fusion.side ], [ 0xC024F817DD06EE79, %fusion.side1 ]
  %1001 = phi double [ 0x3D0A81E9CB6A1EA5, %fusion.side ], [ 0x3CA9D032740CF69A, %fusion.side1 ]
  %1002 = phi double [ 0x3E553724D72BE5C7, %fusion.side ], [ 0x3E14D76BE5BA042B, %fusion.side1 ]
  %1003 = phi double [ 0x3DC001D96C7E2C9D, %fusion.side ], [ 0x3D6F4FAB0C90F842, %fusion.side1 ]
  %1004 = phi double [ 0x3ED71590B83839D8, %fusion.side ], [ 0x3EA6C7746378848A, %fusion.side1 ]
  %1005 = phi double [ 0x3F478C82425FFDCE, %fusion.side ], [ 0x3F275783E6F9B4DA, %fusion.side1 ]
  %1006 = phi double [ 0x3FA66506CA3FCEB3, %fusion.side ], [ 0x3F964BEF3074CF28, %fusion.side1 ]
  %fusion.paired3 = phi <2 x double> [ %944, %fusion.side ], [ %948, %fusion.side1 ]
  %fusion.paired4 = phi <2 x double> [ %946, %fusion.side ], [ %950, %fusion.side1 ]
  %1007 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %fusion.paired3, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %fusion.paired4) #3
  %1008 = extractelement <2 x double> %1007, i32 0
  %1009 = extractelement <2 x double> %1007, i32 1
  %1010 = fadd double %1008, %1009
  %1011 = fadd double %909, %1010
  %1012 = fsub double %1011, %909
  %1013 = fsub double %1010, %1012
  %1014 = fadd double %1011, %908
  %1015 = fsub double %1014, %908
  %1016 = fsub double %1015, %1014
  %1017 = fadd double %1016, %908
  %1018 = fsub double %1011, %1015
  %1019 = fadd double %1018, %1017
  %1020 = fadd double %1013, %1019
  %1021 = fadd double %1014, %1020
  %1022 = tail call double @llvm.fabs.f64(double %818) #4
  %leaf.enter.demorgan = and i1 %cmp84.i.i.i.i, %810
  %1023 = fcmp oeq double %1022, 0x7FF0000000000000
  %1024 = select i1 %1023, double %818, double %1021
  %1025 = fcmp olt double %818, 0.000000e+00
  %1026 = select i1 %1025, double 0x7FF8000000000000, double %1024
  %1027 = fcmp oeq double %818, 0.000000e+00
  %1028 = select i1 %1027, double 0xFFF0000000000000, double %1026
  %1029 = fmul double %1028, %1028
  %1030 = select i1 %leaf.enter.demorgan, i1 %811, i1 %cmp84.i.i.i.i
  %1031 = select i1 %leaf.enter.demorgan, double %992, double %993
  %1032 = select i1 %leaf.enter.demorgan, double %978, double %964
  %1033 = select i1 %1030, double %1031, double %1032
  %1034 = fmul double %1029, %1033
  %1035 = select i1 %leaf.enter.demorgan, double %991, double %994
  %1036 = select i1 %leaf.enter.demorgan, double %977, double %963
  %1037 = select i1 %1030, double %1035, double %1036
  %1038 = fsub double %1037, %1034
  %1039 = select i1 %leaf.enter.demorgan, double %990, double %995
  %1040 = select i1 %leaf.enter.demorgan, double %976, double %962
  %1041 = select i1 %1030, double %1039, double %1040
  %1042 = fmul double %1029, %1041
  %1043 = select i1 %leaf.enter.demorgan, double %989, double %996
  %1044 = select i1 %leaf.enter.demorgan, double %975, double %961
  %1045 = select i1 %1030, double %1043, double %1044
  %1046 = fsub double %1045, %1042
  %1047 = fmul double %1029, %1038
  %1048 = fmul double %1029, %1046
  %1049 = select i1 %leaf.enter.demorgan, double %988, double %997
  %1050 = select i1 %leaf.enter.demorgan, double %974, double %960
  %1051 = select i1 %1030, double %1049, double %1050
  %1052 = fadd double %1047, %1051
  %1053 = select i1 %leaf.enter.demorgan, double %987, double %998
  %1054 = select i1 %leaf.enter.demorgan, double %973, double %959
  %1055 = select i1 %1030, double %1053, double %1054
  %1056 = fadd double %1048, %1055
  %1057 = fmul double %1029, %1052
  %1058 = fmul double %1029, %1056
  %1059 = select i1 %leaf.enter.demorgan, double %986, double %999
  %1060 = select i1 %leaf.enter.demorgan, double %972, double %958
  %1061 = select i1 %1030, double %1059, double %1060
  %1062 = fadd double %1057, %1061
  %1063 = select i1 %leaf.enter.demorgan, double %985, double %1000
  %1064 = select i1 %leaf.enter.demorgan, double %971, double %957
  %1065 = select i1 %1030, double %1063, double %1064
  %1066 = fadd double %1058, %1065
  %1067 = fmul double %1028, %1062
  %1068 = fsub double %1066, %1067
  %1069 = select i1 %leaf.enter.demorgan, double %984, double %1001
  %1070 = select i1 %leaf.enter.demorgan, double %970, double %956
  %1071 = select i1 %1030, double %1069, double %1070
  %1072 = fmul double %1029, %1071
  %1073 = select i1 %leaf.enter.demorgan, double %983, double %1002
  %1074 = select i1 %leaf.enter.demorgan, double %969, double %955
  %1075 = select i1 %1030, double %1073, double %1074
  %1076 = fadd double %1072, %1075
  %1077 = select i1 %leaf.enter.demorgan, double %982, double %1003
  %1078 = select i1 %leaf.enter.demorgan, double %968, double %954
  %1079 = select i1 %1030, double %1077, double %1078
  %1080 = fmul double %1029, %1079
  %1081 = select i1 %leaf.enter.demorgan, double %981, double %1004
  %1082 = select i1 %leaf.enter.demorgan, double %967, double %953
  %1083 = select i1 %1030, double %1081, double %1082
  %1084 = fadd double %1080, %1083
  %1085 = fmul double %1029, %1076
  %1086 = fmul double %1029, %1084
  %1087 = select i1 %leaf.enter.demorgan, double %980, double %1005
  %1088 = select i1 %leaf.enter.demorgan, double %966, double %952
  %1089 = select i1 %1030, double %1087, double %1088
  %1090 = fadd double %1085, %1089
  %1091 = select i1 %leaf.enter.demorgan, double %979, double %1006
  %1092 = select i1 %leaf.enter.demorgan, double %965, double %951
  %1093 = select i1 %1030, double %1091, double %1092
  %1094 = fadd double %1086, %1093
  %1095 = fmul double %1029, %1090
  %1096 = fadd double %1095, 1.000000e+00
  %1097 = fmul double %1028, %1094
  %1098 = fsub double %1096, %1097
  %1099 = fdiv double %1068, %1098
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

merged.bb3:                                       ; preds = %if.end7.i.i.i620.i.i.i.i
  %1100 = fmul double %add23.i.i.i.i.i616.i.i.i.i, %177
  %1101 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i616.i.i.i.i, i32 %div.i.i.i617.i.i.i.i) #3
  %guard.value = select i1 %cmp11.i.i.i619.i.i.i.i, double %1100, double undef
  %guard.value8 = select i1 %cmp11.i.i.i619.i.i.i.i, double undef, double %1101
  br label %merged.bb5

merged.bb4:                                       ; preds = %if.end7.i.i.i620.i.i.i.i
  %1102 = fdiv double %add23.i.i.i.i.i616.i.i.i.i, %177
  br label %merged.bb5

merged.bb5:                                       ; preds = %merged.bb4, %merged.bb3
  %1103 = phi double [ %guard.value, %merged.bb3 ], [ %1102, %merged.bb4 ]
  %1104 = phi double [ %guard.value8, %merged.bb3 ], [ undef, %merged.bb4 ]
  %guess.i.i.i589.i.i.i.i.0 = select i1 %cmp11.i.i.i619.i.i.i.i, double %1103, double %1104
  %.neg6 = mul nsw i32 %div.i.i.i617.i.i.i.i, -3
  %rem.i.i.i635.i.i.i.i.decomposed = add i32 %.frozen, 2
  %add.i.i.i636.i.i.i.i = add i32 %rem.i.i.i635.i.i.i.i.decomposed, %.neg6
  %1105 = zext i32 %add.i.i.i636.i.i.i.i to i64
  %arrayidx1.i.i.i637.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %1105
  %1106 = load double, double addrspace(4)* %arrayidx1.i.i.i637.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i638.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.0, %1106
  %cmp26.i.i.i639.i.i.i.i = icmp slt i32 %168, 1021
  br i1 %cmp26.i.i.i639.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i

merged.bb6:                                       ; preds = %if.end7.i.i.i499.i.i.i.i
  %1107 = fmul double %add23.i.i.i.i.i495.i.i.i.i, %315
  %1108 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i495.i.i.i.i, i32 %div.i.i.i496.i.i.i.i) #3
  %guard.value11 = select i1 %cmp11.i.i.i498.i.i.i.i, double %1107, double undef
  %guard.value12 = select i1 %cmp11.i.i.i498.i.i.i.i, double undef, double %1108
  br label %merged.bb8

merged.bb7:                                       ; preds = %if.end7.i.i.i499.i.i.i.i
  %1109 = fdiv double %add23.i.i.i.i.i495.i.i.i.i, %315
  br label %merged.bb8

merged.bb8:                                       ; preds = %merged.bb7, %merged.bb6
  %1110 = phi double [ %guard.value11, %merged.bb6 ], [ %1109, %merged.bb7 ]
  %1111 = phi double [ %guard.value12, %merged.bb6 ], [ undef, %merged.bb7 ]
  %guess.i.i.i468.i.i.i.i.0 = select i1 %cmp11.i.i.i498.i.i.i.i, double %1110, double %1111
  %.neg5 = mul nsw i32 %div.i.i.i496.i.i.i.i, -3
  %rem.i.i.i514.i.i.i.i.decomposed = add i32 %.frozen209, 2
  %add.i.i.i515.i.i.i.i = add i32 %rem.i.i.i514.i.i.i.i.decomposed, %.neg5
  %1112 = zext i32 %add.i.i.i515.i.i.i.i to i64
  %arrayidx1.i.i.i516.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %1112
  %1113 = load double, double addrspace(4)* %arrayidx1.i.i.i516.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i517.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.0, %1113
  %cmp26.i.i.i518.i.i.i.i = icmp slt i32 %306, 1021
  br i1 %cmp26.i.i.i518.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i

merged.bb9:                                       ; preds = %if.end7.i.i.i386.i.i.i.i
  %1114 = fmul double %add23.i.i.i.i.i382.i.i.i.i, %453
  %1115 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i382.i.i.i.i, i32 %div.i.i.i383.i.i.i.i) #3
  %guard.value14 = select i1 %cmp11.i.i.i385.i.i.i.i, double %1114, double undef
  %guard.value15 = select i1 %cmp11.i.i.i385.i.i.i.i, double undef, double %1115
  br label %merged.bb11

merged.bb10:                                      ; preds = %if.end7.i.i.i386.i.i.i.i
  %1116 = fdiv double %add23.i.i.i.i.i382.i.i.i.i, %453
  br label %merged.bb11

merged.bb11:                                      ; preds = %merged.bb10, %merged.bb9
  %1117 = phi double [ %guard.value14, %merged.bb9 ], [ %1116, %merged.bb10 ]
  %1118 = phi double [ %guard.value15, %merged.bb9 ], [ undef, %merged.bb10 ]
  %guess.i.i.i355.i.i.i.i.0 = select i1 %cmp11.i.i.i385.i.i.i.i, double %1117, double %1118
  %.neg4 = mul nsw i32 %div.i.i.i383.i.i.i.i, -3
  %rem.i.i.i401.i.i.i.i.decomposed = add i32 %.frozen210, 2
  %add.i.i.i402.i.i.i.i = add i32 %rem.i.i.i401.i.i.i.i.decomposed, %.neg4
  %1119 = zext i32 %add.i.i.i402.i.i.i.i to i64
  %arrayidx1.i.i.i403.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %1119
  %1120 = load double, double addrspace(4)* %arrayidx1.i.i.i403.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i404.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.0, %1120
  %cmp26.i.i.i405.i.i.i.i = icmp slt i32 %444, 1021
  br i1 %cmp26.i.i.i405.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i

merged.bb12:                                      ; preds = %if.end7.i.i.i273.i.i.i.i
  %1121 = fmul double %add23.i.i.i.i.i269.i.i.i.i, %591
  %1122 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i269.i.i.i.i, i32 %div.i.i.i270.i.i.i.i) #3
  %guard.value17 = select i1 %cmp11.i.i.i272.i.i.i.i, double %1121, double undef
  %guard.value18 = select i1 %cmp11.i.i.i272.i.i.i.i, double undef, double %1122
  br label %merged.bb14

merged.bb13:                                      ; preds = %if.end7.i.i.i273.i.i.i.i
  %1123 = fdiv double %add23.i.i.i.i.i269.i.i.i.i, %591
  br label %merged.bb14

merged.bb14:                                      ; preds = %merged.bb13, %merged.bb12
  %1124 = phi double [ %guard.value17, %merged.bb12 ], [ %1123, %merged.bb13 ]
  %1125 = phi double [ %guard.value18, %merged.bb12 ], [ undef, %merged.bb13 ]
  %guess.i.i.i242.i.i.i.i.0 = select i1 %cmp11.i.i.i272.i.i.i.i, double %1124, double %1125
  %.neg3 = mul nsw i32 %div.i.i.i270.i.i.i.i, -3
  %rem.i.i.i288.i.i.i.i.decomposed = add i32 %.frozen211, 2
  %add.i.i.i289.i.i.i.i = add i32 %rem.i.i.i288.i.i.i.i.decomposed, %.neg3
  %1126 = zext i32 %add.i.i.i289.i.i.i.i to i64
  %arrayidx1.i.i.i290.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %1126
  %1127 = load double, double addrspace(4)* %arrayidx1.i.i.i290.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i291.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.0, %1127
  %cmp26.i.i.i292.i.i.i.i = icmp slt i32 %582, 1021
  br i1 %cmp26.i.i.i292.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i

merged.bb15:                                      ; preds = %if.end7.i.i.i192.i.i.i.i
  %1128 = fmul double %add23.i.i.i.i.i188.i.i.i.i, %608
  %1129 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i188.i.i.i.i, i32 %div.i.i.i189.i.i.i.i) #3
  %guard.value20 = select i1 %cmp11.i.i.i191.i.i.i.i, double %1128, double undef
  %guard.value21 = select i1 %cmp11.i.i.i191.i.i.i.i, double undef, double %1129
  br label %merged.bb17

merged.bb16:                                      ; preds = %if.end7.i.i.i192.i.i.i.i
  %1130 = fdiv double %add23.i.i.i.i.i188.i.i.i.i, %608
  br label %merged.bb17

merged.bb17:                                      ; preds = %merged.bb16, %merged.bb15
  %1131 = phi double [ %guard.value20, %merged.bb15 ], [ %1130, %merged.bb16 ]
  %1132 = phi double [ %guard.value21, %merged.bb15 ], [ undef, %merged.bb16 ]
  %guess.i.i.i161.i.i.i.i.0 = select i1 %cmp11.i.i.i191.i.i.i.i, double %1131, double %1132
  %.neg2 = mul nsw i32 %div.i.i.i189.i.i.i.i, -3
  %rem.i.i.i207.i.i.i.i.decomposed = add i32 %.frozen212, 2
  %add.i.i.i208.i.i.i.i = add i32 %rem.i.i.i207.i.i.i.i.decomposed, %.neg2
  %1133 = zext i32 %add.i.i.i208.i.i.i.i to i64
  %arrayidx1.i.i.i209.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %1133
  %1134 = load double, double addrspace(4)* %arrayidx1.i.i.i209.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i210.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.0, %1134
  %cmp26.i.i.i211.i.i.i.i = icmp slt i32 %599, 1021
  br i1 %cmp26.i.i.i211.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i

merged.bb18:                                      ; preds = %if.end4.i.i.i92.i.i.i.i
  %1135 = fmul double %add23.i.i.i.i.i107.i.i.i.i, %625
  %1136 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  %guard.value23 = select i1 %cmp11.i.i.i110.i.i.i.i, double %1135, double undef
  %guard.value24 = select i1 %cmp11.i.i.i110.i.i.i.i, double undef, double %1136
  br label %merged.bb20

merged.bb19:                                      ; preds = %if.end4.i.i.i92.i.i.i.i
  %1137 = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %625
  br label %merged.bb20

merged.bb20:                                      ; preds = %merged.bb19, %merged.bb18
  %1138 = phi double [ %guard.value23, %merged.bb18 ], [ %1137, %merged.bb19 ]
  %1139 = phi double [ %guard.value24, %merged.bb18 ], [ undef, %merged.bb19 ]
  %guess.i.i.i78.i.i.i.i.0 = select i1 %cmp11.i.i.i110.i.i.i.i, double %1138, double %1139
  %.neg = mul nsw i32 %div.i.i.i108.i.i.i.i, -3
  %rem.i.i.i126.i.i.i.i.decomposed = add i32 %.frozen213, 2
  %add.i.i.i127.i.i.i.i = add i32 %rem.i.i.i126.i.i.i.i.decomposed, %.neg
  %1140 = zext i32 %add.i.i.i127.i.i.i.i to i64
  %arrayidx1.i.i.i128.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %1140
  %1141 = load double, double addrspace(4)* %arrayidx1.i.i.i128.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i129.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.0, %1141
  %cmp26.i.i.i130.i.i.i.i = icmp slt i32 %616, 1021
  br label %merged.bb22

merged.bb:                                        ; preds = %predication.join, %if.end23.i.i.i50.i.i.i.i
  %1142 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %1157, %predication.join ]
  %1143 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %1156, %predication.join ]
  %merged.select22 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1142, double %1143
  %1144 = fmul double %merged.select22, %merged.select22
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.tail, label %predication.split

predication.split:                                ; preds = %merged.bb
  %1145 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %1143
  %1146 = fsub double %1144, %1145
  br label %predication.tail

predication.tail:                                 ; preds = %predication.split, %merged.bb
  %merged.select25 = phi double [ %1144, %merged.bb ], [ 2.000000e+00, %predication.split ]
  %1147 = phi double [ undef, %merged.bb ], [ %1146, %predication.split ]
  %1148 = fmul double %merged.select22, %merged.select25
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.first, label %predication.second

predication.first:                                ; preds = %predication.tail
  %1149 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %1148
  %1150 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %1149
  %1151 = fadd double %1148, %1148
  br label %predication.join

predication.second:                               ; preds = %predication.tail
  %1152 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %1144
  br label %predication.join

predication.join:                                 ; preds = %predication.second, %predication.first
  %merged.select28 = phi double [ %1150, %predication.first ], [ %1147, %predication.second ]
  %merged.select26 = phi double [ %z.addr.i.i.i76.i.i.i.i.0, %predication.first ], [ %1148, %predication.second ]
  %guard.result = phi double [ %1151, %predication.first ], [ %1152, %predication.second ]
  %1153 = fadd double %merged.select26, %guard.result
  %1154 = fdiv double %merged.select28, %1153
  %1155 = fsub double %1143, %1154
  %1156 = select i1 %cmp26.i.i.i130.i.i.i.i, double undef, double %1155
  %merged.select29 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1142, double %1155
  %merged.select30 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1154, double 0x3EC0000000000000
  %1157 = fmul double %merged.select29, %merged.select30
  %1158 = fsub double 1.000000e+00, %1154
  %merged.select31 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1158, double %1154
  %1159 = tail call double @llvm.fabs.f64(double %merged.select31) #3
  %1160 = fcmp ogt double %1159, 0x3EC0000000000000
  %1161 = fcmp olt double %1157, %1159
  %guard.result45 = select i1 %cmp26.i.i.i130.i.i.i.i, i1 %1160, i1 %1161
  br i1 %guard.result45, label %merged.bb, label %merged.bb21

merged.bb21:                                      ; preds = %predication.join
  %guess.i.i.i10.i.i.i.i.3 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1157, double %1155
  %1162 = fneg double %guess.i.i.i10.i.i.i.i.3
  %1163 = select i1 %cmp5.i.i.i91.i.i.i.i, double %1162, double %guess.i.i.i10.i.i.i.i.3
  br label %if.end7.i.i.i.i.i.i.i

merged.bb22:                                      ; preds = %predication.join45, %merged.bb20
  %1164 = phi double [ %mul24.i.i.i129.i.i.i.i, %merged.bb20 ], [ %1179, %predication.join45 ]
  %1165 = phi double [ %mul24.i.i.i129.i.i.i.i, %merged.bb20 ], [ %1178, %predication.join45 ]
  %merged.select24 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1164, double %1165
  %1166 = fmul double %merged.select24, %merged.select24
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.tail42, label %predication.split41

predication.split41:                              ; preds = %merged.bb22
  %1167 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %1165
  %1168 = fsub double %1166, %1167
  br label %predication.tail42

predication.tail42:                               ; preds = %predication.split41, %merged.bb22
  %merged.select33 = phi double [ %1166, %merged.bb22 ], [ 2.000000e+00, %predication.split41 ]
  %1169 = phi double [ undef, %merged.bb22 ], [ %1168, %predication.split41 ]
  %1170 = fmul double %merged.select24, %merged.select33
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.first43, label %predication.second44

predication.first43:                              ; preds = %predication.tail42
  %1171 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %1170
  %1172 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %1171
  %1173 = fadd double %1170, %1170
  br label %predication.join45

predication.second44:                             ; preds = %predication.tail42
  %1174 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %1166
  br label %predication.join45

predication.join45:                               ; preds = %predication.second44, %predication.first43
  %merged.select36 = phi double [ %1172, %predication.first43 ], [ %1169, %predication.second44 ]
  %merged.select34 = phi double [ %z.addr.i.i.i76.i.i.i.i.0, %predication.first43 ], [ %1170, %predication.second44 ]
  %guard.result49 = phi double [ %1173, %predication.first43 ], [ %1174, %predication.second44 ]
  %1175 = fadd double %merged.select34, %guard.result49
  %1176 = fdiv double %merged.select36, %1175
  %1177 = fsub double %1165, %1176
  %1178 = select i1 %cmp26.i.i.i130.i.i.i.i, double undef, double %1177
  %merged.select37 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1164, double %1177
  %merged.select38 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1176, double 0x3EC0000000000000
  %1179 = fmul double %merged.select37, %merged.select38
  %1180 = fsub double 1.000000e+00, %1176
  %merged.select39 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1180, double %1176
  %1181 = tail call double @llvm.fabs.f64(double %merged.select39) #3
  %1182 = fcmp ogt double %1181, 0x3EC0000000000000
  %1183 = fcmp olt double %1179, %1181
  %guard.result59 = select i1 %cmp26.i.i.i130.i.i.i.i, i1 %1182, i1 %1183
  br i1 %guard.result59, label %merged.bb22, label %merged.bb23

merged.bb23:                                      ; preds = %predication.join45
  %guess.i.i.i78.i.i.i.i.3 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1179, double %1177
  %1184 = fneg double %guess.i.i.i78.i.i.i.i.3
  %1185 = select i1 %cmp5.i.i.i91.i.i.i.i, double %1184, double %guess.i.i.i78.i.i.i.i.3
  br i1 %cmp11.i.i.i110.i.i.i.i, label %if.then12.i.i.i32.i.i.i.i, label %if.else21.i.i.i44.i.i.i.i
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.frexp.exp.i32.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.frexp.mant.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i1 @llvm.amdgcn.class.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.ldexp.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rcp.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fma.v2f64(<2 x double>, <2 x double>, <2 x double>) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.abs.i32(i32, i1 immarg) #1

attributes #0 = { nofree norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="128" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }
attributes #4 = { nounwind readnone }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/charitha22/cgo22ae-darm-code.git e9bc0540325ad9806313d34e84fc901496fd8be6)"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i16 1, i16 1025}
!6 = !{}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = !{!"evaluate:%if.then14.i.i.i627.i.i.i.i", !"evaluate:%if.else.i.i.i633.i.i.i.i"}
!13 = !{!"merge(evaluate:%if.then14.i.i.i627.i.i.i.i,evaluate:%if.else.i.i.i633.i.i.i.i)"}
!14 = !{!"evaluate:%if.then14.i.i.i506.i.i.i.i", !"evaluate:%if.else.i.i.i512.i.i.i.i"}
!15 = !{!"merge(evaluate:%if.then14.i.i.i506.i.i.i.i,evaluate:%if.else.i.i.i512.i.i.i.i)"}
!16 = !{!"evaluate:%if.then14.i.i.i393.i.i.i.i", !"evaluate:%if.else.i.i.i399.i.i.i.i"}
!17 = !{!"merge(evaluate:%if.then14.i.i.i393.i.i.i.i,evaluate:%if.else.i.i.i399.i.i.i.i)"}
!18 = !{!"evaluate:%if.then14.i.i.i280.i.i.i.i", !"evaluate:%if.else.i.i.i286.i.i.i.i"}
!19 = !{!"merge(evaluate:%if.then14.i.i.i280.i.i.i.i,evaluate:%if.else.i.i.i286.i.i.i.i)"}
!20 = !{!"evaluate:%if.then14.i.i.i199.i.i.i.i", !"evaluate:%if.else.i.i.i205.i.i.i.i"}
!21 = !{!"merge(evaluate:%if.then14.i.i.i199.i.i.i.i,evaluate:%if.else.i.i.i205.i.i.i.i)"}
!22 = !{!"evaluate:%if.then14.i.i.i118.i.i.i.i", !"evaluate:%if.else.i.i.i124.i.i.i.i"}
!23 = !{!"merge(evaluate:%if.then14.i.i.i118.i.i.i.i,evaluate:%if.else.i.i.i124.i.i.i.i)"}
!24 = !{!"evaluate:%if.then14.i.i.i37.i.i.i.i", !"evaluate:%if.else.i.i.i43.i.i.i.i"}
!25 = !{!"merge(evaluate:%if.then14.i.i.i37.i.i.i.i,evaluate:%if.else.i.i.i43.i.i.i.i)"}
!26 = !{!"evaluate:%if.then11.i.i.i.i", !"evaluate:%if.then20.i.i.i.i"}
!27 = !{!"merge(evaluate:%if.then11.i.i.i.i,evaluate:%if.then20.i.i.i.i)"}
