; ModuleID = 'build/b2b-layouts/anchor-ablation/heldout/SasPoint5/front.ll'
source_filename = "/data/home/chh/simplify-v2/cases/boost-saspoint5/source/kernel.cu"
target datalayout = "e-i64:64-i128:128-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P = internal local_unnamed_addr addrspace(4) constant [13 x double] [double 0x3FE45F306DC9C883, double 0x406B28D28834A1D2, double 0x40E10B4A1F6CF501, double 0x4149F72088DFB4E6, double 0x41AA2A2B1216B605, double 0x4201FEA8BB3BE600, double 0x4250E9DB94569883, double 0x4295367142D96C3E, double 0x42D0C7351C0FE465, double 0x42FDF1537961E7A8, double 0x4318FADA1D9742AD, double 0x431A6A62BB63A40C, double 0x42F7DD4E00E3184B], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q = internal local_unnamed_addr addrspace(4) constant [15 x double] [double 1.000000e+00, double 0x407554BBE33DF6D0, double 0x40EACD56D4D9BE96, double 0x415478A3A36859F4, double 0x41B4BEC095014516, double 0x420CDB326777C2EB, double 0x425BBC435F07A940, double 0x42A2357E7C0D108C, double 0x42DFC3D0B52A82F3, double 0x43119515C0126E89, double 0x4337006916401BF8, double 0x434F8D8E245D5F98, double 0x4352307314019A4E, double 0x433A78AB06FBD9E7, double 0x42F4F252E8C6C233], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FDBE1FDB85FCBFC, double 0x401C7FC4A4CD29B7, double 0x40441F91A172918F, double 0x40569F495083FE32, double 0x4052E785C1291E6C, double 0x402963DA5E858427, double 0xBFE51906626836E2], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x4033DCC50DCD8254, double 0x40631B677D5BB29F, double 0x4081D5A7BC4B586A, double 0x4090A232759E33CF, double 0x408C89486705C083, double 0x40702DF59FC94A86], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 = internal local_unnamed_addr addrspace(4) constant [8 x double] [double 0x3FD2EBDAE01A865A, double 0x4001E701431550F3, double 0x40140D55A266563C, double 0x40061BEABB9D2FFC, double 0x3FBE3E1608F6B264, double 0x3F948267DD4FFC5C, double 0xBF7EE20D1DA304B5, double 0x3F567E8E10E805D5], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 = internal local_unnamed_addr addrspace(4) constant [6 x double] [double 1.000000e+00, double 0x4024936FD6337035, double 0x4043419A7FE0209B, double 0x404EEC78CE96F318, double 0x4042DAE171B23F0E, double 0x4015ACB627173EB5], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FC5DB8AD965E90E, double 0x3FEAFCABC850EDD7, double 0x3FF65A44B7FDD998, double 0x3FEC06E8946EFB9F, double 0x3FC7D5630E234B35, double 0x3F7E240887A8C893, double 0xBF1B2EC29D8B2658], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x401AEF3DDBD087CA, double 0x40316DCC2BF05060, double 0x40359825CD283464, double 0x4029F6B804AEAD76, double 0x400B41AF064F350F, double 0x3FD1EF45AB10745B], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FB60B1E33F10647, double 0x3FC5B8636B0E3222, double 0x3FBC07DA7811D486, double 0x3F9C536ADCBF4A28, double 0x3F6411736D26FD34, double 0x3F057CF6442FA06A, double 0xBE91AFF35CC657D0], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x4008539DEC96056A, double 0x400C3466C3C7D450, double 0x3FFF2AD31AA58662, double 0x3FE0C440E94F34C7, double 0x3FAFB74D5C9C7495, double 0x3F62EDB894F212E5], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FA40A885E63F440, double 0x3FA4D8C2969E1484, double 0x3F8D5B4999760A8F, double 0x3F608452D391BA63, double 0x3F1A625FB47B3E5D, double 0x3EAFEDB5AFBF2767, double 0xBE2EA1B19268350A], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FFA3986886A7224, double 0x3FF09C23C029EA8F, double 0x3FD45C79F4902790, double 0x3FA8ACC143771083, double 0x3F6AA8DFF46DC0A1, double 0x3F126489EF16E3AC], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F90E6E15AE0A0B5, double 0x3F807EC586F8D6C3, double 0x3F5628C3995B9895, double 0x3F1815313F095300, double 0x3EC2BE8138C05760, double 0x3E46283600C31343, double 0xBDB56E517F96664C], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FE9EC7342A94DF8, double 0x3FD0446895858090, double 0x3FA3D20C0F793A99, double 0x3F67F69AED3331A7, double 0x3F19EDB2C6FDDBA7, double 0x3EB1F9FE5CE35DD4], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F7B09124BFF3246, double 0x3F5A1B509F6E6B7F, double 0x3F215B9A853FE1BC, double 0x3ED2AE3619D566E9, double 0x3E6CCC5CC17E6081, double 0x3DE0CED483645917, double 0xBD405E2A41165B21], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FDA44C156520F4B, double 0x3FB0B03579A0DD2F, double 0x3F74916FEE749C77, double 0x3F2921C431130861, double 0x3ECB75120A3FA3A9, double 0x3E5333ECBD8F94A3], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F64D5E29688B048, double 0x3F34521A788CC925, double 0x3EEB47C2C7618FAD, double 0x3E8D9FBD4F84DAEB, double 0x3E17053C44720DE3, double 0x3D7B01444FBF3B93, double 0xBCCAC1BB5B2D869C], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FCAC72D2F36E816, double 0x3F91595000B0EB93, double 0x3F45CFDE78902384, double 0x3EEB30C9CE3272DE, double 0x3E7E4D79F7AC44EB, double 0x3DF59B56446B4334], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F4F4BD6E99FF4E5, double 0x3F0EBAD7DF31FFFC, double 0x3EB4C3314DF7C43F, double 0x3E46AFD495CB1DD4, double 0x3DC1BAD3548A0AB8, double 0x3D14DED0BB7A816C, double 0xBC54EF99AFF7380B], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FBB218F9E698485, double 0x3F71D0F3147D5FAB, double 0x3F16B5EB6E086EA2, double 0x3EACB59E1205CC30, double 0x3E303913316A148C, double 0x3D9774482B0EAD22], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 0x3FC9884533D43651, double 0xBF93CB8214E9986F, double 0xBF814A78F15CF4A7, double 0x3F6C735355393978, double 0xBF3A917333BAF05A], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 1.000000e+00, double 0x3FE66E5F74B0D81B, double 0x3FD116080081EF83, double 0x3FAC405BB896DD07, double 0x3F7AA11B83649D74], align 8

; Function Attrs: nofree norecurse nounwind willreturn
define dso_local void @evaluate(double* nocapture readonly %0, double* nocapture %1, i32 %2) local_unnamed_addr #0 {
  %4 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #3, !range !5
  %5 = tail call i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #3, !range !6
  %6 = mul i32 %5, %4
  %7 = tail call i32 @llvm.nvvm.read.ptx.sreg.tid.x() #3, !range !7
  %8 = add i32 %6, %7
  %9 = icmp slt i32 %8, %2
  br i1 %9, label %10, label %536

10:                                               ; preds = %3
  %11 = sext i32 %8 to i64
  %12 = getelementptr inbounds double, double* %0, i64 %11
  %13 = load double, double* %12, align 8, !tbaa !8
  %14 = fcmp ord double %13, 0.000000e+00
  %15 = fcmp ule double %13, 0x7FEFFFFFFFFFFFFF
  %16 = fcmp uge double %13, 0xFFEFFFFFFFFFFFFF
  %17 = and i1 %15, %16
  %18 = and i1 %14, %17
  br i1 %18, label %19, label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

19:                                               ; preds = %10
  %20 = tail call double @llvm.fabs.f64(double %13) #3
  %21 = fcmp olt double %20, 1.250000e-01
  br i1 %21, label %22, label %105

22:                                               ; preds = %19
  %23 = fmul double %13, %13
  %24 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 12), align 8, !tbaa !8
  %25 = fmul double %23, %24
  %26 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 10), align 8, !tbaa !8
  %27 = fadd double %25, %26
  %28 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 11), align 8, !tbaa !8
  %29 = fmul double %23, %28
  %30 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 9), align 8, !tbaa !8
  %31 = fadd double %29, %30
  %32 = fmul double %23, %27
  %33 = fmul double %23, %31
  %34 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 8), align 8, !tbaa !8
  %35 = fadd double %32, %34
  %36 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 7), align 8, !tbaa !8
  %37 = fadd double %33, %36
  %38 = fmul double %23, %35
  %39 = fmul double %23, %37
  %40 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %41 = fadd double %38, %40
  %42 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %43 = fadd double %39, %42
  %44 = fmul double %23, %41
  %45 = fmul double %23, %43
  %46 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %47 = fadd double %44, %46
  %48 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %49 = fadd double %45, %48
  %50 = fmul double %23, %47
  %51 = fmul double %23, %49
  %52 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %53 = fadd double %50, %52
  %54 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %55 = fadd double %51, %54
  %56 = fmul double %23, %53
  %57 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %58 = fadd double %56, %57
  %59 = fmul double %20, %55
  %60 = fadd double %58, %59
  %61 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 14), align 8, !tbaa !8
  %62 = fmul double %23, %61
  %63 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 12), align 8, !tbaa !8
  %64 = fadd double %62, %63
  %65 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 13), align 8, !tbaa !8
  %66 = fmul double %23, %65
  %67 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 11), align 8, !tbaa !8
  %68 = fadd double %66, %67
  %69 = fmul double %23, %64
  %70 = fmul double %23, %68
  %71 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 10), align 8, !tbaa !8
  %72 = fadd double %69, %71
  %73 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 9), align 8, !tbaa !8
  %74 = fadd double %70, %73
  %75 = fmul double %23, %72
  %76 = fmul double %23, %74
  %77 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 8), align 8, !tbaa !8
  %78 = fadd double %75, %77
  %79 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 7), align 8, !tbaa !8
  %80 = fadd double %76, %79
  %81 = fmul double %23, %78
  %82 = fmul double %23, %80
  %83 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %84 = fadd double %81, %83
  %85 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %86 = fadd double %82, %85
  %87 = fmul double %23, %84
  %88 = fmul double %23, %86
  %89 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %90 = fadd double %87, %89
  %91 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %92 = fadd double %88, %91
  %93 = fmul double %23, %90
  %94 = fmul double %23, %92
  %95 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %96 = fadd double %93, %95
  %97 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %98 = fadd double %94, %97
  %99 = fmul double %23, %96
  %100 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %101 = fadd double %99, %100
  %102 = fmul double %20, %98
  %103 = fadd double %101, %102
  %104 = fdiv double %60, %103
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

105:                                              ; preds = %19
  %106 = fcmp olt double %20, 2.500000e-01
  br i1 %106, label %107, label %149

107:                                              ; preds = %105
  %108 = fadd double %20, -1.250000e-01
  %109 = fmul double %108, %108
  %110 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %111 = fmul double %109, %110
  %112 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %113 = fadd double %111, %112
  %114 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %115 = fmul double %109, %114
  %116 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %117 = fadd double %115, %116
  %118 = fmul double %109, %113
  %119 = fmul double %109, %117
  %120 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %121 = fadd double %118, %120
  %122 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %123 = fadd double %119, %122
  %124 = fmul double %109, %121
  %125 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %126 = fadd double %124, %125
  %127 = fmul double %108, %123
  %128 = fadd double %126, %127
  %129 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %130 = fmul double %109, %129
  %131 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %132 = fadd double %130, %131
  %133 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %134 = fmul double %109, %133
  %135 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %136 = fadd double %134, %135
  %137 = fmul double %109, %132
  %138 = fmul double %109, %136
  %139 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %140 = fadd double %137, %139
  %141 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %142 = fadd double %138, %141
  %143 = fmul double %109, %140
  %144 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %145 = fadd double %143, %144
  %146 = fmul double %108, %142
  %147 = fadd double %145, %146
  %148 = fdiv double %128, %147
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

149:                                              ; preds = %105
  %150 = fcmp olt double %20, 5.000000e-01
  br i1 %150, label %151, label %193

151:                                              ; preds = %149
  %152 = fadd double %20, -2.500000e-01
  %153 = fmul double %152, %152
  %154 = load double, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 7), align 8, !tbaa !8
  %155 = fmul double %153, %154
  %156 = load double, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %157 = fadd double %155, %156
  %158 = load double, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %159 = fmul double %153, %158
  %160 = load double, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %161 = fadd double %159, %160
  %162 = fmul double %153, %157
  %163 = fmul double %153, %161
  %164 = load double, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %165 = fadd double %162, %164
  %166 = load double, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %167 = fadd double %163, %166
  %168 = fmul double %153, %165
  %169 = fmul double %153, %167
  %170 = load double, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %171 = fadd double %168, %170
  %172 = load double, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %173 = fadd double %169, %172
  %174 = fmul double %152, %171
  %175 = fadd double %174, %173
  %176 = load double, double* getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %177 = fmul double %153, %176
  %178 = load double, double* getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %179 = fadd double %177, %178
  %180 = load double, double* getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %181 = fmul double %153, %180
  %182 = load double, double* getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %183 = fadd double %181, %182
  %184 = fmul double %153, %179
  %185 = fmul double %153, %183
  %186 = load double, double* getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %187 = fadd double %184, %186
  %188 = load double, double* getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %189 = fadd double %185, %188
  %190 = fmul double %152, %187
  %191 = fadd double %190, %189
  %192 = fdiv double %175, %191
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

193:                                              ; preds = %149
  %194 = fcmp olt double %20, 1.000000e+00
  br i1 %194, label %195, label %237

195:                                              ; preds = %193
  %196 = fadd double %20, -5.000000e-01
  %197 = fmul double %196, %196
  %198 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %199 = fmul double %197, %198
  %200 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %201 = fadd double %199, %200
  %202 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %203 = fmul double %197, %202
  %204 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %205 = fadd double %203, %204
  %206 = fmul double %197, %201
  %207 = fmul double %197, %205
  %208 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %209 = fadd double %206, %208
  %210 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %211 = fadd double %207, %210
  %212 = fmul double %197, %209
  %213 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %214 = fadd double %212, %213
  %215 = fmul double %196, %211
  %216 = fadd double %214, %215
  %217 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %218 = fmul double %197, %217
  %219 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %220 = fadd double %218, %219
  %221 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %222 = fmul double %197, %221
  %223 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %224 = fadd double %222, %223
  %225 = fmul double %197, %220
  %226 = fmul double %197, %224
  %227 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %228 = fadd double %225, %227
  %229 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %230 = fadd double %226, %229
  %231 = fmul double %197, %228
  %232 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %233 = fadd double %231, %232
  %234 = fmul double %196, %230
  %235 = fadd double %233, %234
  %236 = fdiv double %216, %235
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

237:                                              ; preds = %193
  %238 = fcmp olt double %20, 2.000000e+00
  br i1 %238, label %239, label %281

239:                                              ; preds = %237
  %240 = fadd double %20, -1.000000e+00
  %241 = fmul double %240, %240
  %242 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %243 = fmul double %241, %242
  %244 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %245 = fadd double %243, %244
  %246 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %247 = fmul double %241, %246
  %248 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %249 = fadd double %247, %248
  %250 = fmul double %241, %245
  %251 = fmul double %241, %249
  %252 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %253 = fadd double %250, %252
  %254 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %255 = fadd double %251, %254
  %256 = fmul double %241, %253
  %257 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %258 = fadd double %256, %257
  %259 = fmul double %240, %255
  %260 = fadd double %258, %259
  %261 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %262 = fmul double %241, %261
  %263 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %264 = fadd double %262, %263
  %265 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %266 = fmul double %241, %265
  %267 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %268 = fadd double %266, %267
  %269 = fmul double %241, %264
  %270 = fmul double %241, %268
  %271 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %272 = fadd double %269, %271
  %273 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %274 = fadd double %270, %273
  %275 = fmul double %241, %272
  %276 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %277 = fadd double %275, %276
  %278 = fmul double %240, %274
  %279 = fadd double %277, %278
  %280 = fdiv double %260, %279
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

281:                                              ; preds = %237
  %282 = fcmp olt double %20, 4.000000e+00
  br i1 %282, label %283, label %325

283:                                              ; preds = %281
  %284 = fadd double %20, -2.000000e+00
  %285 = fmul double %284, %284
  %286 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %287 = fmul double %285, %286
  %288 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %289 = fadd double %287, %288
  %290 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %291 = fmul double %285, %290
  %292 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %293 = fadd double %291, %292
  %294 = fmul double %285, %289
  %295 = fmul double %285, %293
  %296 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %297 = fadd double %294, %296
  %298 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %299 = fadd double %295, %298
  %300 = fmul double %285, %297
  %301 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %302 = fadd double %300, %301
  %303 = fmul double %284, %299
  %304 = fadd double %302, %303
  %305 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %306 = fmul double %285, %305
  %307 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %308 = fadd double %306, %307
  %309 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %310 = fmul double %285, %309
  %311 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %312 = fadd double %310, %311
  %313 = fmul double %285, %308
  %314 = fmul double %285, %312
  %315 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %316 = fadd double %313, %315
  %317 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %318 = fadd double %314, %317
  %319 = fmul double %285, %316
  %320 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %321 = fadd double %319, %320
  %322 = fmul double %284, %318
  %323 = fadd double %321, %322
  %324 = fdiv double %304, %323
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

325:                                              ; preds = %281
  %326 = fcmp olt double %20, 8.000000e+00
  br i1 %326, label %327, label %369

327:                                              ; preds = %325
  %328 = fadd double %20, -4.000000e+00
  %329 = fmul double %328, %328
  %330 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %331 = fmul double %329, %330
  %332 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %333 = fadd double %331, %332
  %334 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %335 = fmul double %329, %334
  %336 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %337 = fadd double %335, %336
  %338 = fmul double %329, %333
  %339 = fmul double %329, %337
  %340 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %341 = fadd double %338, %340
  %342 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %343 = fadd double %339, %342
  %344 = fmul double %329, %341
  %345 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %346 = fadd double %344, %345
  %347 = fmul double %328, %343
  %348 = fadd double %346, %347
  %349 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %350 = fmul double %329, %349
  %351 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %352 = fadd double %350, %351
  %353 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %354 = fmul double %329, %353
  %355 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %356 = fadd double %354, %355
  %357 = fmul double %329, %352
  %358 = fmul double %329, %356
  %359 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %360 = fadd double %357, %359
  %361 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %362 = fadd double %358, %361
  %363 = fmul double %329, %360
  %364 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %365 = fadd double %363, %364
  %366 = fmul double %328, %362
  %367 = fadd double %365, %366
  %368 = fdiv double %348, %367
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

369:                                              ; preds = %325
  %370 = fcmp olt double %20, 1.600000e+01
  br i1 %370, label %371, label %413

371:                                              ; preds = %369
  %372 = fadd double %20, -8.000000e+00
  %373 = fmul double %372, %372
  %374 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %375 = fmul double %373, %374
  %376 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %377 = fadd double %375, %376
  %378 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %379 = fmul double %373, %378
  %380 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %381 = fadd double %379, %380
  %382 = fmul double %373, %377
  %383 = fmul double %373, %381
  %384 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %385 = fadd double %382, %384
  %386 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %387 = fadd double %383, %386
  %388 = fmul double %373, %385
  %389 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %390 = fadd double %388, %389
  %391 = fmul double %372, %387
  %392 = fadd double %390, %391
  %393 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %394 = fmul double %373, %393
  %395 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %396 = fadd double %394, %395
  %397 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %398 = fmul double %373, %397
  %399 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %400 = fadd double %398, %399
  %401 = fmul double %373, %396
  %402 = fmul double %373, %400
  %403 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %404 = fadd double %401, %403
  %405 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %406 = fadd double %402, %405
  %407 = fmul double %373, %404
  %408 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %409 = fadd double %407, %408
  %410 = fmul double %372, %406
  %411 = fadd double %409, %410
  %412 = fdiv double %392, %411
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

413:                                              ; preds = %369
  %414 = fcmp olt double %20, 3.200000e+01
  br i1 %414, label %415, label %457

415:                                              ; preds = %413
  %416 = fadd double %20, -1.600000e+01
  %417 = fmul double %416, %416
  %418 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %419 = fmul double %417, %418
  %420 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %421 = fadd double %419, %420
  %422 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %423 = fmul double %417, %422
  %424 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %425 = fadd double %423, %424
  %426 = fmul double %417, %421
  %427 = fmul double %417, %425
  %428 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %429 = fadd double %426, %428
  %430 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %431 = fadd double %427, %430
  %432 = fmul double %417, %429
  %433 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %434 = fadd double %432, %433
  %435 = fmul double %416, %431
  %436 = fadd double %434, %435
  %437 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %438 = fmul double %417, %437
  %439 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %440 = fadd double %438, %439
  %441 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %442 = fmul double %417, %441
  %443 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %444 = fadd double %442, %443
  %445 = fmul double %417, %440
  %446 = fmul double %417, %444
  %447 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %448 = fadd double %445, %447
  %449 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %450 = fadd double %446, %449
  %451 = fmul double %417, %448
  %452 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %453 = fadd double %451, %452
  %454 = fmul double %416, %450
  %455 = fadd double %453, %454
  %456 = fdiv double %436, %455
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

457:                                              ; preds = %413
  %458 = fcmp olt double %20, 6.400000e+01
  br i1 %458, label %459, label %501

459:                                              ; preds = %457
  %460 = fadd double %20, -3.200000e+01
  %461 = fmul double %460, %460
  %462 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %463 = fmul double %461, %462
  %464 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %465 = fadd double %463, %464
  %466 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %467 = fmul double %461, %466
  %468 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %469 = fadd double %467, %468
  %470 = fmul double %461, %465
  %471 = fmul double %461, %469
  %472 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %473 = fadd double %470, %472
  %474 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %475 = fadd double %471, %474
  %476 = fmul double %461, %473
  %477 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %478 = fadd double %476, %477
  %479 = fmul double %460, %475
  %480 = fadd double %478, %479
  %481 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %482 = fmul double %461, %481
  %483 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %484 = fadd double %482, %483
  %485 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %486 = fmul double %461, %485
  %487 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %488 = fadd double %486, %487
  %489 = fmul double %461, %484
  %490 = fmul double %461, %488
  %491 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %492 = fadd double %489, %491
  %493 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %494 = fadd double %490, %493
  %495 = fmul double %461, %492
  %496 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %497 = fadd double %495, %496
  %498 = fmul double %460, %494
  %499 = fadd double %497, %498
  %500 = fdiv double %480, %499
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

501:                                              ; preds = %457
  %502 = tail call double @llvm.sqrt.f64(double %20) #3
  %503 = fdiv double 1.000000e+00, %502
  %504 = fmul double %503, %503
  %505 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %506 = fmul double %504, %505
  %507 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %508 = fadd double %506, %507
  %509 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %510 = fmul double %504, %509
  %511 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %512 = fadd double %510, %511
  %513 = fmul double %504, %508
  %514 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %515 = fadd double %513, %514
  %516 = fmul double %503, %512
  %517 = fadd double %515, %516
  %518 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %519 = fmul double %504, %518
  %520 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %521 = fadd double %519, %520
  %522 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %523 = fmul double %504, %522
  %524 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %525 = fadd double %523, %524
  %526 = fmul double %504, %521
  %527 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %528 = fadd double %526, %527
  %529 = fmul double %503, %525
  %530 = fadd double %528, %529
  %531 = fdiv double %517, %530
  %532 = fmul double %503, %531
  %533 = fdiv double %532, %20
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit: ; preds = %501, %459, %415, %371, %327, %283, %239, %195, %151, %107, %22, %10
  %534 = phi double [ 0x7FF8000000000000, %10 ], [ %104, %22 ], [ %148, %107 ], [ %192, %151 ], [ %236, %195 ], [ %280, %239 ], [ %324, %283 ], [ %368, %327 ], [ %412, %371 ], [ %456, %415 ], [ %500, %459 ], [ %533, %501 ]
  %535 = getelementptr inbounds double, double* %1, i64 %11
  store double %534, double* %535, align 8, !tbaa !8
  br label %536

536:                                              ; preds = %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit, %3
  ret void
}

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #1

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #1

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.tid.x() #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.sqrt.f64(double) #2

attributes #0 = { nofree norecurse nounwind willreturn "disable-tail-calls"="false" "frame-pointer"="all" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="sm_70" "target-features"="+ptx32,+sm_70" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nounwind readnone }
attributes #2 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!nvvm.annotations = !{!0}
!llvm.module.flags = !{!1, !2}
!llvm.ident = !{!3, !4}

!0 = !{void (double*, double*, i32)* @evaluate, !"kernel", i32 1}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 4, !"nvvm-reflect-ftz", i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 3.8.0 (tags/RELEASE_380/final)"}
!5 = !{i32 0, i32 2147483647}
!6 = !{i32 1, i32 1025}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
