; ModuleID = '/data/home/chh/simplify-v2/build/simplify-fingerprint/active/HLLD/trial-28/fused.ll'
source_filename = "cases/cholla-hlld/source/src/riemann_solvers/hlld_cuda.cu"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

; Function Attrs: nofree norecurse nounwind willreturn
define protected amdgpu_kernel void @_ZN3mhd26Calculate_HLLD_Fluxes_CUDAEPKdS1_S1_Pdidii(double addrspace(1)* nocapture readonly %0, double addrspace(1)* nocapture readonly %1, double addrspace(1)* nocapture readonly %2, double addrspace(1)* %3, i32 %4, double %5, i32 %6, i32 %7) local_unnamed_addr #0 {
  %9 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %10 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %11 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %12 = getelementptr i8, i8 addrspace(4)* %11, i64 4
  %13 = bitcast i8 addrspace(4)* %12 to i16 addrspace(4)*
  %14 = load i16, i16 addrspace(4)* %13, align 4, !range !6, !invariant.load !7
  %15 = zext i16 %14 to i32
  %16 = mul i32 %10, %15
  %17 = add i32 %16, %9
  %18 = icmp slt i32 %17, %4
  br i1 %18, label %19, label %merged.branch.split

19:                                               ; preds = %8
  switch i32 %6, label %unify.bb [
    i32 2, label %21
    i32 1, label %20
  ]

20:                                               ; preds = %19
  br label %unify.bb

21:                                               ; preds = %19
  br label %unify.bb

unify.bb:                                         ; preds = %21, %20, %19
  %22 = phi i32 [ 3, %19 ], [ %6, %20 ], [ %6, %21 ]
  %23 = phi i32 [ 2, %19 ], [ 3, %20 ], [ 1, %21 ]
  %24 = phi i32 [ 1, %19 ], [ 2, %20 ], [ 3, %21 ]
  %25 = sext i32 %17 to i64
  %26 = getelementptr inbounds double, double addrspace(1)* %2, i64 %25
  %27 = load double, double addrspace(1)* %26, align 8, !tbaa !8
  %28 = getelementptr inbounds double, double addrspace(1)* %0, i64 %25
  %29 = load double, double addrspace(1)* %28, align 8, !tbaa !8
  %30 = tail call double @llvm.maxnum.f64(double %29, double 0x3BC79CA10C924223) #3
  %31 = mul nsw i32 %24, %4
  %32 = add nsw i32 %31, %17
  %33 = sext i32 %32 to i64
  %34 = getelementptr inbounds double, double addrspace(1)* %0, i64 %33
  %35 = load double, double addrspace(1)* %34, align 8, !tbaa !8
  %36 = fdiv double %35, %30
  %37 = mul nsw i32 %23, %4
  %38 = add nsw i32 %37, %17
  %39 = sext i32 %38 to i64
  %40 = getelementptr inbounds double, double addrspace(1)* %0, i64 %39
  %41 = load double, double addrspace(1)* %40, align 8, !tbaa !8
  %42 = fdiv double %41, %30
  %43 = mul nsw i32 %22, %4
  %44 = add nsw i32 %43, %17
  %45 = sext i32 %44 to i64
  %46 = getelementptr inbounds double, double addrspace(1)* %0, i64 %45
  %47 = load double, double addrspace(1)* %46, align 8, !tbaa !8
  %48 = fdiv double %47, %30
  %49 = shl nsw i32 %4, 2
  %50 = add nsw i32 %17, %49
  %51 = sext i32 %50 to i64
  %52 = getelementptr inbounds double, double addrspace(1)* %0, i64 %51
  %53 = load double, double addrspace(1)* %52, align 8, !tbaa !8
  %54 = tail call double @llvm.maxnum.f64(double %53, double 0x3BC79CA10C924223) #3
  %55 = mul nsw i32 %4, 5
  %56 = add nsw i32 %17, %55
  %57 = sext i32 %56 to i64
  %58 = getelementptr inbounds double, double addrspace(1)* %0, i64 %57
  %59 = load double, double addrspace(1)* %58, align 8, !tbaa !8
  %60 = mul nsw i32 %4, 6
  %61 = add nsw i32 %17, %60
  %62 = sext i32 %61 to i64
  %63 = getelementptr inbounds double, double addrspace(1)* %0, i64 %62
  %64 = load double, double addrspace(1)* %63, align 8, !tbaa !8
  %65 = fmul double %30, 5.000000e-01
  %66 = fmul double %36, %36
  %67 = fmul double %42, %42
  %68 = fmul double %48, %48
  %69 = fadd double %67, %68
  %70 = fadd double %66, %69
  %71 = fmul double %65, %70
  %72 = fsub double %54, %71
  %73 = fmul double %27, %27
  %74 = fmul double %59, %59
  %75 = fmul double %64, %64
  %76 = fadd double %74, %75
  %77 = fadd double %73, %76
  %78 = fmul double %77, 5.000000e-01
  %79 = fsub double %72, %78
  %80 = fadd double %5, -1.000000e+00
  %81 = fmul double %80, %79
  %82 = tail call double @llvm.maxnum.f64(double %81, double 0x3BC79CA10C924223) #3
  %83 = fadd double %78, %82
  %84 = tail call double @llvm.maxnum.f64(double %83, double 0x3BC79CA10C924223) #3
  %85 = getelementptr inbounds double, double addrspace(1)* %1, i64 %25
  %86 = load double, double addrspace(1)* %85, align 8, !tbaa !8
  %87 = tail call double @llvm.maxnum.f64(double %86, double 0x3BC79CA10C924223) #3
  %88 = getelementptr inbounds double, double addrspace(1)* %1, i64 %33
  %89 = load double, double addrspace(1)* %88, align 8, !tbaa !8
  %90 = fdiv double %89, %87
  %91 = getelementptr inbounds double, double addrspace(1)* %1, i64 %39
  %92 = load double, double addrspace(1)* %91, align 8, !tbaa !8
  %93 = fdiv double %92, %87
  %94 = getelementptr inbounds double, double addrspace(1)* %1, i64 %45
  %95 = load double, double addrspace(1)* %94, align 8, !tbaa !8
  %96 = fdiv double %95, %87
  %97 = getelementptr inbounds double, double addrspace(1)* %1, i64 %51
  %98 = load double, double addrspace(1)* %97, align 8, !tbaa !8
  %99 = tail call double @llvm.maxnum.f64(double %98, double 0x3BC79CA10C924223) #3
  %100 = getelementptr inbounds double, double addrspace(1)* %1, i64 %57
  %101 = load double, double addrspace(1)* %100, align 8, !tbaa !8
  %102 = getelementptr inbounds double, double addrspace(1)* %1, i64 %62
  %103 = load double, double addrspace(1)* %102, align 8, !tbaa !8
  %104 = fmul double %87, 5.000000e-01
  %105 = fmul double %90, %90
  %106 = fmul double %93, %93
  %107 = fmul double %96, %96
  %108 = fadd double %106, %107
  %109 = fadd double %105, %108
  %110 = fmul double %104, %109
  %111 = fsub double %99, %110
  %112 = fmul double %101, %101
  %113 = fmul double %103, %103
  %114 = fadd double %112, %113
  %115 = fadd double %73, %114
  %116 = fmul double %115, 5.000000e-01
  %117 = fsub double %111, %116
  %118 = fmul double %80, %117
  %119 = tail call double @llvm.maxnum.f64(double %118, double 0x3BC79CA10C924223) #3
  %120 = fadd double %116, %119
  %121 = tail call double @llvm.maxnum.f64(double %120, double 0x3BC79CA10C924223) #3
  %122 = fmul double %82, %5
  %123 = fadd double %77, %122
  %124 = fmul double %123, %123
  %125 = fmul double %5, 4.000000e+00
  %126 = fmul double %125, %82
  %127 = fmul double %73, %126
  %128 = fsub double %124, %127
  %129 = fcmp olt double %128, 0x1000000000000000
  %130 = select i1 %129, double 0x4FF0000000000000, double 1.000000e+00
  %131 = fmul double %128, %130
  %132 = tail call double @llvm.amdgcn.rsq.f64(double %131) #3
  %133 = fmul double %131, %132
  %134 = fmul double %132, 5.000000e-01
  %135 = fneg double %134
  %136 = tail call double @llvm.fma.f64(double %135, double %133, double 5.000000e-01) #3
  %137 = tail call double @llvm.fma.f64(double %134, double %136, double %134) #3
  %138 = tail call double @llvm.fma.f64(double %133, double %136, double %133) #3
  %139 = fneg double %138
  %140 = tail call double @llvm.fma.f64(double %139, double %138, double %131) #3
  %141 = tail call double @llvm.fma.f64(double %140, double %137, double %138) #3
  %142 = fneg double %141
  %143 = tail call double @llvm.fma.f64(double %142, double %141, double %131) #3
  %144 = tail call double @llvm.fma.f64(double %143, double %137, double %141) #3
  %145 = select i1 %129, double 0x37F0000000000000, double 1.000000e+00
  %146 = fmul double %145, %144
  %147 = fcmp oeq double %131, 0.000000e+00
  %148 = fcmp oeq double %131, 0x7FF0000000000000
  %149 = or i1 %147, %148
  %150 = select i1 %149, double %131, double %146
  %151 = fadd double %123, %150
  %152 = fmul double %30, 2.000000e+00
  %153 = fdiv double %151, %152
  %154 = fcmp olt double %153, 0x1000000000000000
  %155 = select i1 %154, double 0x4FF0000000000000, double 1.000000e+00
  %156 = fmul double %153, %155
  %157 = tail call double @llvm.amdgcn.rsq.f64(double %156) #3
  %158 = fmul double %156, %157
  %159 = fmul double %157, 5.000000e-01
  %160 = fneg double %159
  %161 = tail call double @llvm.fma.f64(double %160, double %158, double 5.000000e-01) #3
  %162 = tail call double @llvm.fma.f64(double %159, double %161, double %159) #3
  %163 = tail call double @llvm.fma.f64(double %158, double %161, double %158) #3
  %164 = fneg double %163
  %165 = tail call double @llvm.fma.f64(double %164, double %163, double %156) #3
  %166 = tail call double @llvm.fma.f64(double %165, double %162, double %163) #3
  %167 = fneg double %166
  %168 = tail call double @llvm.fma.f64(double %167, double %166, double %156) #3
  %169 = tail call double @llvm.fma.f64(double %168, double %162, double %166) #3
  %170 = select i1 %154, double 0x37F0000000000000, double 1.000000e+00
  %171 = fmul double %170, %169
  %172 = fcmp oeq double %156, 0.000000e+00
  %173 = fcmp oeq double %156, 0x7FF0000000000000
  %174 = or i1 %172, %173
  %175 = select i1 %174, double %156, double %171
  %176 = fmul double %119, %5
  %177 = fadd double %115, %176
  %178 = fmul double %177, %177
  %179 = fmul double %125, %119
  %180 = fmul double %73, %179
  %181 = fsub double %178, %180
  %182 = fcmp olt double %181, 0x1000000000000000
  %183 = select i1 %182, double 0x4FF0000000000000, double 1.000000e+00
  %184 = fmul double %181, %183
  %185 = tail call double @llvm.amdgcn.rsq.f64(double %184) #3
  %186 = fmul double %184, %185
  %187 = fmul double %185, 5.000000e-01
  %188 = fneg double %187
  %189 = tail call double @llvm.fma.f64(double %188, double %186, double 5.000000e-01) #3
  %190 = tail call double @llvm.fma.f64(double %187, double %189, double %187) #3
  %191 = tail call double @llvm.fma.f64(double %186, double %189, double %186) #3
  %192 = fneg double %191
  %193 = tail call double @llvm.fma.f64(double %192, double %191, double %184) #3
  %194 = tail call double @llvm.fma.f64(double %193, double %190, double %191) #3
  %195 = fneg double %194
  %196 = tail call double @llvm.fma.f64(double %195, double %194, double %184) #3
  %197 = tail call double @llvm.fma.f64(double %196, double %190, double %194) #3
  %198 = select i1 %182, double 0x37F0000000000000, double 1.000000e+00
  %199 = fmul double %198, %197
  %200 = fcmp oeq double %184, 0.000000e+00
  %201 = fcmp oeq double %184, 0x7FF0000000000000
  %202 = or i1 %200, %201
  %203 = select i1 %202, double %184, double %199
  %204 = fadd double %177, %203
  %205 = fmul double %87, 2.000000e+00
  %206 = fdiv double %204, %205
  %207 = fcmp olt double %206, 0x1000000000000000
  %208 = select i1 %207, double 0x4FF0000000000000, double 1.000000e+00
  %209 = fmul double %206, %208
  %210 = tail call double @llvm.amdgcn.rsq.f64(double %209) #3
  %211 = fmul double %209, %210
  %212 = fmul double %210, 5.000000e-01
  %213 = fneg double %212
  %214 = tail call double @llvm.fma.f64(double %213, double %211, double 5.000000e-01) #3
  %215 = tail call double @llvm.fma.f64(double %212, double %214, double %212) #3
  %216 = tail call double @llvm.fma.f64(double %211, double %214, double %211) #3
  %217 = fneg double %216
  %218 = tail call double @llvm.fma.f64(double %217, double %216, double %209) #3
  %219 = tail call double @llvm.fma.f64(double %218, double %215, double %216) #3
  %220 = fneg double %219
  %221 = tail call double @llvm.fma.f64(double %220, double %219, double %209) #3
  %222 = tail call double @llvm.fma.f64(double %221, double %215, double %219) #3
  %223 = select i1 %207, double 0x37F0000000000000, double 1.000000e+00
  %224 = fmul double %223, %222
  %225 = fcmp oeq double %209, 0.000000e+00
  %226 = fcmp oeq double %209, 0x7FF0000000000000
  %227 = or i1 %225, %226
  %228 = select i1 %227, double %209, double %224
  %229 = tail call double @llvm.maxnum.f64(double %175, double %228) #3
  %230 = tail call double @llvm.minnum.f64(double %36, double %90) #3
  %231 = fsub double %230, %229
  %232 = tail call double @llvm.maxnum.f64(double %36, double %90) #3
  %233 = fadd double %232, %229
  %234 = fmul double %30, %36
  %235 = fmul double %36, %234
  %236 = fadd double %235, %84
  %237 = fsub double %236, %73
  %238 = fmul double %234, %42
  %239 = fmul double %27, %59
  %240 = fsub double %238, %239
  %241 = fmul double %234, %48
  %242 = fmul double %27, %64
  %243 = fsub double %241, %242
  %244 = fmul double %36, %59
  %245 = fmul double %27, %42
  %246 = fsub double %244, %245
  %247 = fmul double %36, %64
  %248 = fmul double %27, %48
  %249 = fsub double %247, %248
  %250 = fadd double %54, %84
  %251 = fmul double %36, %250
  %252 = fmul double %27, %36
  %253 = fmul double %42, %59
  %254 = fmul double %48, %64
  %255 = fadd double %253, %254
  %256 = fadd double %252, %255
  %257 = fmul double %27, %256
  %258 = fsub double %251, %257
  %259 = fcmp ogt double %231, 0.000000e+00
  %260 = fmul double %87, %90
  %261 = fmul double %90, %260
  %262 = fadd double %261, %121
  %263 = fsub double %262, %73
  %264 = fmul double %260, %93
  %265 = fmul double %27, %101
  %266 = fsub double %264, %265
  %267 = fmul double %260, %96
  %268 = fmul double %27, %103
  %269 = fsub double %267, %268
  %270 = fmul double %90, %101
  %271 = fmul double %27, %93
  %272 = fsub double %270, %271
  %273 = fmul double %90, %103
  %274 = fmul double %27, %96
  %275 = fsub double %273, %274
  %276 = fadd double %99, %121
  %277 = fmul double %90, %276
  %278 = fmul double %27, %90
  %279 = fmul double %93, %101
  %280 = fmul double %96, %103
  %281 = fadd double %279, %280
  %282 = fadd double %278, %281
  %283 = fmul double %27, %282
  %284 = fsub double %277, %283
  %285 = fcmp olt double %233, 0.000000e+00
  %286 = or i1 %259, %285
  br i1 %286, label %merged.bb, label %merged.bb73

merged.branch.split:                              ; preds = %8
  ret void

merged.bb:                                        ; preds = %unify.bb
  %287 = getelementptr inbounds double, double addrspace(1)* %3, i64 %25
  %merged.select = select i1 %259, double %234, double %260
  store double %merged.select, double addrspace(1)* %287, align 8, !tbaa !8
  %288 = getelementptr inbounds double, double addrspace(1)* %3, i64 %33
  %merged.select90 = select i1 %259, double %237, double %263
  store double %merged.select90, double addrspace(1)* %288, align 8, !tbaa !8
  %289 = getelementptr inbounds double, double addrspace(1)* %3, i64 %39
  %merged.select91 = select i1 %259, double %240, double %266
  store double %merged.select91, double addrspace(1)* %289, align 8, !tbaa !8
  %290 = getelementptr inbounds double, double addrspace(1)* %3, i64 %45
  %merged.select92 = select i1 %259, double %243, double %269
  store double %merged.select92, double addrspace(1)* %290, align 8, !tbaa !8
  %291 = getelementptr inbounds double, double addrspace(1)* %3, i64 %51
  %merged.select93 = select i1 %259, double %258, double %284
  store double %merged.select93, double addrspace(1)* %291, align 8, !tbaa !8
  %292 = getelementptr inbounds double, double addrspace(1)* %3, i64 %57
  %merged.select94 = select i1 %259, double %246, double %272
  store double %merged.select94, double addrspace(1)* %292, align 8, !tbaa !8
  %293 = getelementptr inbounds double, double addrspace(1)* %3, i64 %62
  %merged.select95 = select i1 %259, double %249, double %275
  store double %merged.select95, double addrspace(1)* %293, align 8, !tbaa !8
  ret void

merged.bb73:                                      ; preds = %unify.bb
  %294 = fsub double %233, %90
  %295 = fsub double %231, %36
  %296 = fmul double %87, %294
  %297 = fmul double %90, %296
  %298 = fmul double %30, %295
  %299 = fmul double %36, %298
  %300 = fsub double %297, %299
  %301 = fsub double %300, %121
  %302 = fadd double %84, %301
  %303 = fsub double %296, %298
  %304 = fdiv double %302, %303
  %305 = fmul double %87, %84
  %306 = fmul double %305, %294
  %307 = fmul double %30, %121
  %308 = fmul double %307, %295
  %309 = fsub double %306, %308
  %310 = fmul double %30, %87
  %311 = fmul double %310, %294
  %312 = fmul double %295, %311
  %313 = fsub double %90, %36
  %314 = fmul double %313, %312
  %315 = fadd double %309, %314
  %316 = fdiv double %315, %303
  %317 = fsub double %231, %304
  %318 = fdiv double %298, %317
  %319 = fmul double %298, %317
  %320 = fsub double %319, %73
  %321 = tail call double @llvm.fabs.f64(double %320) #3
  %322 = fmul double %316, 1.000000e-08
  %323 = fcmp olt double %321, %322
  br i1 %323, label %merged.bb75, label %merged.bb76

merged.bb75:                                      ; preds = %merged.bb76, %merged.bb73
  %324 = phi double [ %255, %merged.bb73 ], [ %377, %merged.bb76 ]
  %325 = phi double [ %42, %merged.bb73 ], [ %366, %merged.bb76 ]
  %326 = phi double [ %48, %merged.bb73 ], [ %368, %merged.bb76 ]
  %327 = phi double [ %59, %merged.bb73 ], [ %373, %merged.bb76 ]
  %328 = phi double [ %64, %merged.bb73 ], [ %374, %merged.bb76 ]
  %329 = fmul double %54, %295
  %330 = fmul double %36, %84
  %331 = fsub double %329, %330
  %332 = fmul double %316, %304
  %333 = fadd double %331, %332
  %334 = fmul double %27, %304
  %335 = fadd double %334, %324
  %336 = fsub double %256, %335
  %337 = fmul double %27, %336
  %338 = fadd double %333, %337
  %339 = fdiv double %338, %317
  %340 = tail call double @llvm.fabs.f64(double %27) #3
  %341 = tail call double @llvm.maxnum.f64(double %318, double 0x3BC79CA10C924223) #3
  %342 = tail call double @llvm.amdgcn.rsq.f64(double %341) #3
  %343 = fmul double %341, %342
  %344 = fmul double %342, 5.000000e-01
  %345 = fneg double %344
  %346 = tail call double @llvm.fma.f64(double %345, double %343, double 5.000000e-01) #3
  %347 = tail call double @llvm.fma.f64(double %344, double %346, double %344) #3
  %348 = tail call double @llvm.fma.f64(double %343, double %346, double %343) #3
  %349 = fneg double %348
  %350 = tail call double @llvm.fma.f64(double %349, double %348, double %341) #3
  %351 = tail call double @llvm.fma.f64(double %350, double %347, double %348) #3
  %352 = fneg double %351
  %353 = tail call double @llvm.fma.f64(double %352, double %351, double %341) #3
  %354 = tail call double @llvm.fma.f64(double %353, double %347, double %351) #3
  %355 = fcmp oeq double %341, 0x7FF0000000000000
  %356 = select i1 %355, double %341, double %354
  %357 = fdiv double %340, %356
  %358 = fsub double %304, %357
  %359 = fcmp ule double %358, 0.000000e+00
  %360 = fcmp ugt double %231, 0.000000e+00
  %361 = or i1 %360, %359
  br i1 %361, label %merged.bb77, label %merged.bb27

merged.bb76:                                      ; preds = %merged.bb73
  %362 = fsub double %304, %36
  %363 = fmul double %27, %362
  %364 = fdiv double %363, %320
  %365 = fmul double %59, %364
  %366 = fsub double %42, %365
  %367 = fmul double %64, %364
  %368 = fsub double %48, %367
  %369 = fmul double %295, %295
  %370 = fmul double %30, %369
  %371 = fsub double %370, %73
  %372 = fdiv double %371, %320
  %373 = fmul double %59, %372
  %374 = fmul double %64, %372
  %375 = fmul double %366, %373
  %376 = fmul double %368, %374
  %377 = fadd double %375, %376
  br label %merged.bb75

merged.bb77:                                      ; preds = %merged.bb75
  %378 = fsub double %233, %304
  %379 = fdiv double %296, %378
  %380 = fmul double %296, %378
  %381 = fsub double %380, %73
  %382 = tail call double @llvm.fabs.f64(double %381) #3
  %383 = fcmp olt double %382, %322
  br i1 %383, label %merged.bb27, label %merged.bb80

merged.bb80:                                      ; preds = %merged.bb77
  %384 = fsub double %304, %90
  %385 = fmul double %27, %384
  %386 = fdiv double %385, %381
  %387 = fmul double %101, %386
  %388 = fsub double %93, %387
  %389 = fmul double %103, %386
  %390 = fsub double %96, %389
  %391 = fmul double %294, %294
  %392 = fmul double %87, %391
  %393 = fsub double %392, %73
  %394 = fdiv double %393, %381
  %395 = fmul double %101, %394
  %396 = fmul double %103, %394
  %397 = fmul double %388, %395
  %398 = fmul double %390, %396
  %399 = fadd double %397, %398
  br label %merged.bb27

merged.bb27:                                      ; preds = %merged.bb80, %merged.bb77, %merged.bb75
  %merged.select65 = phi double [ %328, %merged.bb75 ], [ %103, %merged.bb77 ], [ %396, %merged.bb80 ]
  %merged.select61 = phi double [ %327, %merged.bb75 ], [ %101, %merged.bb77 ], [ %395, %merged.bb80 ]
  %merged.select52 = phi double [ %326, %merged.bb75 ], [ %96, %merged.bb77 ], [ %390, %merged.bb80 ]
  %merged.select46 = phi double [ %325, %merged.bb75 ], [ %93, %merged.bb77 ], [ %388, %merged.bb80 ]
  %merged.select37 = phi double [ %318, %merged.bb75 ], [ %379, %merged.bb77 ], [ %379, %merged.bb80 ]
  %unify.phi25 = phi double [ undef, %merged.bb75 ], [ %379, %merged.bb77 ], [ %379, %merged.bb80 ]
  %unify.phi = phi double [ undef, %merged.bb75 ], [ %378, %merged.bb77 ], [ %378, %merged.bb80 ]
  %moved.phi24 = phi double [ undef, %merged.bb75 ], [ %103, %merged.bb77 ], [ %396, %merged.bb80 ]
  %moved.phi23 = phi double [ undef, %merged.bb75 ], [ %101, %merged.bb77 ], [ %395, %merged.bb80 ]
  %moved.phi22 = phi double [ undef, %merged.bb75 ], [ %96, %merged.bb77 ], [ %390, %merged.bb80 ]
  %moved.phi21 = phi double [ undef, %merged.bb75 ], [ %93, %merged.bb77 ], [ %388, %merged.bb80 ]
  %moved.phi = phi double [ undef, %merged.bb75 ], [ %281, %merged.bb77 ], [ %399, %merged.bb80 ]
  %400 = fmul double %99, %294
  %401 = fmul double %90, %121
  %402 = fsub double %400, %401
  %403 = fadd double %402, %332
  %404 = fadd double %334, %moved.phi
  %405 = fsub double %282, %404
  %406 = fmul double %27, %405
  %407 = fadd double %403, %406
  %408 = fdiv double %407, %unify.phi
  %409 = tail call double @llvm.maxnum.f64(double %unify.phi25, double 0x3BC79CA10C924223) #3
  %410 = tail call double @llvm.amdgcn.rsq.f64(double %409) #3
  %411 = fmul double %409, %410
  %412 = fmul double %410, 5.000000e-01
  %413 = fneg double %412
  %414 = tail call double @llvm.fma.f64(double %413, double %411, double 5.000000e-01) #3
  %415 = tail call double @llvm.fma.f64(double %412, double %414, double %412) #3
  %416 = tail call double @llvm.fma.f64(double %411, double %414, double %411) #3
  %417 = fneg double %416
  %418 = tail call double @llvm.fma.f64(double %417, double %416, double %409) #3
  %419 = tail call double @llvm.fma.f64(double %418, double %415, double %416) #3
  %420 = fneg double %419
  %421 = tail call double @llvm.fma.f64(double %420, double %419, double %409) #3
  %422 = tail call double @llvm.fma.f64(double %421, double %415, double %419) #3
  %423 = fcmp oeq double %409, 0x7FF0000000000000
  %424 = select i1 %423, double %409, double %422
  %425 = fdiv double %340, %424
  %426 = fadd double %304, %425
  %427 = fcmp ugt double %426, 0.000000e+00
  %428 = fcmp ult double %233, 0.000000e+00
  %429 = or i1 %428, %427
  %430 = and i1 %361, %429
  br i1 %430, label %merged.bb28, label %merged.bb10

merged.bb28:                                      ; preds = %merged.bb27
  %431 = fmul double %73, 5.000000e-01
  %432 = fcmp uge double %431, %322
  %433 = fcmp ult double %304, 0.000000e+00
  %leaf.enter = or i1 %432, %433
  br i1 %leaf.enter, label %leaf.union, label %merged.bb10, !fusion.logical.arm !12

leaf.union:                                       ; preds = %merged.bb28
  br i1 %432, label %merged.bb31, label %merged.bb10

merged.bb31:                                      ; preds = %leaf.union
  %434 = fcmp olt double %318, 0x1000000000000000
  %435 = select i1 %434, double 0x4FF0000000000000, double 1.000000e+00
  %436 = fmul double %318, %435
  %437 = tail call double @llvm.amdgcn.rsq.f64(double %436) #3
  %438 = fmul double %436, %437
  %439 = fmul double %437, 5.000000e-01
  %440 = fneg double %439
  %441 = tail call double @llvm.fma.f64(double %440, double %438, double 5.000000e-01) #3
  %442 = tail call double @llvm.fma.f64(double %439, double %441, double %439) #3
  %443 = tail call double @llvm.fma.f64(double %438, double %441, double %438) #3
  %444 = fneg double %443
  %445 = tail call double @llvm.fma.f64(double %444, double %443, double %436) #3
  %446 = tail call double @llvm.fma.f64(double %445, double %442, double %443) #3
  %447 = fneg double %446
  %448 = tail call double @llvm.fma.f64(double %447, double %446, double %436) #3
  %449 = tail call double @llvm.fma.f64(double %448, double %442, double %446) #3
  %450 = select i1 %434, double 0x37F0000000000000, double 1.000000e+00
  %451 = fmul double %450, %449
  %452 = fcmp oeq double %436, 0.000000e+00
  %453 = fcmp oeq double %436, 0x7FF0000000000000
  %454 = or i1 %452, %453
  %455 = select i1 %454, double %436, double %451
  %456 = fcmp olt double %unify.phi25, 0x1000000000000000
  %457 = select i1 %456, double 0x4FF0000000000000, double 1.000000e+00
  %458 = fmul double %unify.phi25, %457
  %459 = tail call double @llvm.amdgcn.rsq.f64(double %458) #3
  %460 = fmul double %458, %459
  %461 = fmul double %459, 5.000000e-01
  %462 = fneg double %461
  %463 = tail call double @llvm.fma.f64(double %462, double %460, double 5.000000e-01) #3
  %464 = tail call double @llvm.fma.f64(double %461, double %463, double %461) #3
  %465 = tail call double @llvm.fma.f64(double %460, double %463, double %460) #3
  %466 = fneg double %465
  %467 = tail call double @llvm.fma.f64(double %466, double %465, double %458) #3
  %468 = tail call double @llvm.fma.f64(double %467, double %464, double %465) #3
  %469 = fneg double %468
  %470 = tail call double @llvm.fma.f64(double %469, double %468, double %458) #3
  %471 = tail call double @llvm.fma.f64(double %470, double %464, double %468) #3
  %472 = select i1 %456, double 0x37F0000000000000, double 1.000000e+00
  %473 = fmul double %472, %471
  %474 = fcmp oeq double %458, 0.000000e+00
  %475 = fcmp oeq double %458, 0x7FF0000000000000
  %476 = or i1 %474, %475
  %477 = select i1 %476, double %458, double %473
  %478 = fadd double %455, %477
  %479 = fdiv double 1.000000e+00, %478
  %480 = tail call double @llvm.copysign.f64(double 1.000000e+00, double %27) #3
  %481 = fmul double %455, %325
  %482 = fmul double %477, %moved.phi21
  %483 = fadd double %481, %482
  %484 = fsub double %moved.phi23, %327
  %485 = fmul double %480, %484
  %486 = fadd double %483, %485
  %487 = fmul double %479, %486
  %488 = fmul double %455, %326
  %489 = fmul double %477, %moved.phi22
  %490 = fadd double %488, %489
  %491 = fsub double %moved.phi24, %328
  %492 = fmul double %480, %491
  %493 = fadd double %490, %492
  %494 = fmul double %479, %493
  %495 = fmul double %455, %moved.phi23
  %496 = fmul double %477, %327
  %497 = fadd double %496, %495
  %498 = fmul double %455, %477
  %499 = fmul double %480, %498
  %500 = fsub double %moved.phi21, %325
  %501 = fmul double %499, %500
  %502 = fadd double %501, %497
  %503 = fmul double %479, %502
  %504 = fmul double %455, %moved.phi24
  %505 = fmul double %477, %328
  %506 = fadd double %505, %504
  %507 = fsub double %moved.phi22, %326
  %508 = fmul double %499, %507
  %509 = fadd double %508, %506
  %510 = fmul double %479, %509
  %511 = fmul double %487, %503
  %512 = fmul double %494, %510
  %513 = fadd double %511, %512
  %514 = fadd double %334, %513
  %515 = fmul double %480, %455
  %516 = fsub double %335, %514
  %517 = fmul double %515, %516
  %518 = fsub double %339, %517
  %519 = fmul double %480, %477
  %520 = fsub double %404, %514
  %521 = fmul double %519, %520
  %522 = fadd double %408, %521
  br label %merged.bb10

merged.bb9:                                       ; preds = %merged.bb11, %merged.bb10
  ret void

merged.bb10:                                      ; preds = %leaf.union, %merged.bb31, %merged.bb28, %merged.bb27
  %moved.phi8 = phi double [ undef, %merged.bb27 ], [ 0.000000e+00, %merged.bb28 ], [ %522, %merged.bb31 ], [ %408, %leaf.union ]
  %moved.phi7 = phi double [ undef, %merged.bb27 ], [ %339, %merged.bb28 ], [ %518, %merged.bb31 ], [ 0.000000e+00, %leaf.union ]
  %moved.phi6 = phi double [ undef, %merged.bb27 ], [ %328, %merged.bb28 ], [ %510, %merged.bb31 ], [ %moved.phi24, %leaf.union ]
  %moved.phi5 = phi double [ undef, %merged.bb27 ], [ %327, %merged.bb28 ], [ %503, %merged.bb31 ], [ %moved.phi23, %leaf.union ]
  %moved.phi4 = phi double [ undef, %merged.bb27 ], [ %326, %merged.bb28 ], [ %494, %merged.bb31 ], [ %moved.phi22, %leaf.union ]
  %moved.phi3 = phi double [ undef, %merged.bb27 ], [ %325, %merged.bb28 ], [ %487, %merged.bb31 ], [ %moved.phi21, %leaf.union ]
  %523 = fcmp ule double %304, 0.000000e+00
  %524 = fcmp ugt double %358, 0.000000e+00
  %525 = or i1 %523, %524
  %.demorgan = or i1 %523, %524
  %526 = xor i1 %.demorgan, true
  %527 = fcmp ogt double %426, 0.000000e+00
  %528 = fcmp ole double %304, 0.000000e+00
  %529 = and i1 %528, %527
  %530 = or i1 %529, %526
  %not. = xor i1 %430, true
  %531 = or i1 %530, %not.
  br i1 %531, label %merged.bb11, label %merged.bb9, !fusion.logical.arm !13

merged.bb11:                                      ; preds = %merged.bb10
  %532 = select i1 %525, double %426, double %358
  %533 = select i1 %430, double %532, double undef
  %merged.select14 = select i1 %430, i1 %525, i1 %361
  %merged.select15 = select i1 %430, double %233, double %87
  %merged.select16 = select i1 %430, double %231, double %30
  %534 = select i1 %merged.select14, double %merged.select15, double %merged.select16
  %merged.select17 = select i1 %430, double %532, double %merged.select37
  %535 = fsub double %merged.select17, %534
  %merged.select19 = select i1 %430, double %87, double %233
  %merged.select20 = select i1 %430, double %30, double %231
  %536 = select i1 %merged.select14, double %merged.select19, double %merged.select20
  %merged.select21 = select i1 %430, double %534, double %535
  %537 = fmul double %536, %merged.select21
  %538 = select i1 %525, double %260, double %234
  %539 = fsub double %538, %537
  %540 = select i1 %430, double %538, double undef
  %merged.select23 = select i1 %430, double %unify.phi25, double %260
  %merged.select24 = select i1 %430, double %318, double %234
  %541 = select i1 %merged.select14, double %merged.select23, double %merged.select24
  %542 = fmul double %541, %535
  %543 = fsub double %539, %542
  %544 = fmul double %541, %532
  %merged.select25 = select i1 %430, double %544, double %541
  %merged.select26 = select i1 %430, double %543, double %537
  %545 = fadd double %merged.select25, %merged.select26
  %546 = fmul double %540, %534
  %547 = select i1 %525, double %263, double %237
  %548 = fsub double %547, %546
  %549 = fmul double %304, %541
  %merged.select27 = select i1 %430, double %549, double %304
  %merged.select28 = select i1 %430, double %535, double %merged.select37
  %550 = fmul double %merged.select27, %merged.select28
  %merged.select29 = select i1 %430, double %548, double %550
  %merged.select30 = select i1 %430, double %550, double %541
  %551 = fsub double %merged.select29, %merged.select30
  %merged.select31 = select i1 %430, double %549, double %536
  %merged.select32 = select i1 %430, double %532, double %551
  %552 = fmul double %merged.select31, %merged.select32
  %merged.select34 = select i1 %430, double %93, double %263
  %merged.select35 = select i1 %430, double %42, double %237
  %553 = select i1 %merged.select14, double %merged.select34, double %merged.select35
  %554 = fmul double %536, %553
  %merged.select36 = select i1 %430, double %554, double %merged.select37
  %merged.select41 = select i1 %430, double %534, double %merged.select46
  %555 = fmul double %merged.select36, %merged.select41
  %556 = select i1 %525, double %266, double %240
  %557 = fsub double %556, %555
  %merged.select43 = select i1 %430, double %moved.phi21, double %93
  %merged.select45 = select i1 %430, double %325, double %42
  %558 = select i1 %merged.select14, double %merged.select43, double %merged.select45
  %559 = fmul double %541, %558
  %merged.select47 = select i1 %430, double %535, double %534
  %merged.select49 = select i1 %430, double %559, double %558
  %560 = fmul double %merged.select47, %merged.select49
  %merged.select51 = select i1 %430, double %557, double %555
  %561 = fsub double %merged.select51, %560
  %merged.select53 = select i1 %430, double %541, double %536
  %merged.select55 = select i1 %430, double %moved.phi3, double %561
  %562 = fmul double %merged.select53, %merged.select55
  %563 = fmul double %532, %562
  %564 = select i1 %361, double %266, double %240
  %merged.select59 = select i1 %430, double %561, double %564
  %merged.select63 = select i1 %430, double %563, double %562
  %565 = fadd double %merged.select59, %merged.select63
  %566 = select i1 %525, double %96, double %48
  %567 = fmul double %536, %566
  %merged.select67 = select i1 %430, double %567, double %merged.select37
  %merged.select69 = select i1 %430, double %534, double %merged.select52
  %568 = fmul double %merged.select67, %merged.select69
  %569 = select i1 %525, double %269, double %243
  %570 = fsub double %569, %568
  %merged.select71 = select i1 %430, double %moved.phi22, double %96
  %merged.select72 = select i1 %430, double %326, double %48
  %571 = select i1 %merged.select14, double %merged.select71, double %merged.select72
  %572 = fmul double %541, %571
  %merged.select74 = select i1 %430, double %572, double %571
  %573 = fmul double %merged.select47, %merged.select74
  %merged.select75 = select i1 %430, double %570, double %568
  %574 = fsub double %merged.select75, %573
  %merged.select77 = select i1 %430, double %moved.phi4, double %574
  %575 = fmul double %merged.select53, %merged.select77
  %576 = fmul double %532, %575
  %577 = select i1 %361, double %269, double %243
  %merged.select78 = select i1 %430, double %574, double %577
  %merged.select79 = select i1 %430, double %576, double %575
  %578 = fadd double %merged.select78, %merged.select79
  %579 = select i1 %525, double %99, double %54
  %580 = fmul double %579, %534
  %merged.select81 = select i1 %430, double %284, double %408
  %merged.select82 = select i1 %430, double %258, double %339
  %581 = select i1 %merged.select14, double %merged.select81, double %merged.select82
  %582 = fsub double %581, %580
  %merged.select84 = select i1 %430, double %408, double %99
  %merged.select85 = select i1 %430, double %339, double %54
  %583 = select i1 %merged.select14, double %merged.select84, double %merged.select85
  %584 = fmul double %535, %583
  %merged.select86 = select i1 %430, double %582, double %581
  %merged.select87 = select i1 %430, double %584, double %583
  %585 = fsub double %merged.select86, %merged.select87
  %586 = select i1 %525, double %moved.phi8, double %moved.phi7
  %587 = fmul double %533, %586
  %588 = fadd double %585, %587
  %589 = select i1 %525, double %101, double %59
  %merged.select88 = select i1 %430, double %589, double %536
  %merged.select89 = select i1 %430, double %534, double %585
  %590 = fmul double %merged.select88, %merged.select89
  %591 = select i1 %525, double %272, double %246
  %592 = fsub double %591, %590
  %merged.select97 = select i1 %430, double %moved.phi23, double %284
  %merged.select98 = select i1 %430, double %327, double %258
  %593 = select i1 %merged.select14, double %merged.select97, double %merged.select98
  %594 = fmul double %535, %593
  %595 = fsub double %592, %594
  %596 = fmul double %532, %moved.phi5
  %merged.select99 = select i1 %430, double %595, double %593
  %merged.select100 = select i1 %430, double %596, double %590
  %597 = fadd double %merged.select99, %merged.select100
  %merged.select102 = select i1 %430, double %103, double %101
  %merged.select103 = select i1 %430, double %64, double %59
  %598 = select i1 %merged.select14, double %merged.select102, double %merged.select103
  %599 = fsub double %merged.select61, %598
  %merged.select104 = select i1 %430, double %598, double %536
  %merged.select105 = select i1 %430, double %534, double %599
  %600 = fmul double %merged.select104, %merged.select105
  %merged.select107 = select i1 %430, double %275, double %272
  %merged.select108 = select i1 %430, double %249, double %246
  %601 = select i1 %merged.select14, double %merged.select107, double %merged.select108
  %602 = fsub double %601, %600
  %603 = fadd double %601, %600
  %merged.select110 = select i1 %430, double %moved.phi24, double %103
  %merged.select111 = select i1 %430, double %328, double %64
  %604 = select i1 %merged.select14, double %merged.select110, double %merged.select111
  %605 = fmul double %535, %604
  %merged.select112 = select i1 %430, double %602, double %merged.select65
  %merged.select113 = select i1 %430, double %605, double %604
  %606 = fsub double %merged.select112, %merged.select113
  %merged.select114 = select i1 %430, double %532, double %536
  %merged.select115 = select i1 %430, double %moved.phi6, double %606
  %607 = fmul double %merged.select114, %merged.select115
  %608 = select i1 %361, double %275, double %249
  %merged.select116 = select i1 %430, double %606, double %608
  %609 = fadd double %merged.select116, %607
  %610 = getelementptr inbounds double, double addrspace(1)* %3, i64 %25
  store double %545, double addrspace(1)* %610, align 8, !tbaa !8
  %611 = getelementptr inbounds double, double addrspace(1)* %3, i64 %33
  %merged.select117.v = select i1 %430, double %551, double %553
  %merged.select117 = fadd double %552, %merged.select117.v
  store double %merged.select117, double addrspace(1)* %611, align 8, !tbaa !8
  %612 = getelementptr inbounds double, double addrspace(1)* %3, i64 %39
  store double %565, double addrspace(1)* %612, align 8, !tbaa !8
  %613 = getelementptr inbounds double, double addrspace(1)* %3, i64 %45
  store double %578, double addrspace(1)* %613, align 8, !tbaa !8
  %614 = getelementptr inbounds double, double addrspace(1)* %3, i64 %51
  %merged.select118 = select i1 %430, double %588, double %597
  store double %merged.select118, double addrspace(1)* %614, align 8, !tbaa !8
  %615 = getelementptr inbounds double, double addrspace(1)* %3, i64 %57
  %merged.select119 = select i1 %430, double %597, double %603
  store double %merged.select119, double addrspace(1)* %615, align 8, !tbaa !8
  %616 = getelementptr inbounds double, double addrspace(1)* %3, i64 %62
  store double %609, double addrspace(1)* %616, align 8, !tbaa !8
  br label %merged.bb9
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.maxnum.f64(double, double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.minnum.f64(double, double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rsq.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

attributes #0 = { nofree norecurse nounwind willreturn "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i32 0, i32 1024}
!6 = !{i16 1, i16 1025}
!7 = !{}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = !{!"merged.bb31", !"merged.bb32"}
!13 = !{!"merged.bb88", !"merged.bb89"}
