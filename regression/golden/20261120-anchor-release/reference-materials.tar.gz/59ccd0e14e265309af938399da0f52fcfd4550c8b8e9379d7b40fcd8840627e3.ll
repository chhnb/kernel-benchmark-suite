; ModuleID = '/data/home/chh/simplify-v2/build/b2b-layouts/anchor-ablation/heldout/SasPoint5/active/trial-46/fused.ll'
source_filename = "/data/home/chh/simplify-v2/cases/boost-saspoint5/source/kernel.cu"
target datalayout = "e-i64:64-i128:128-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P = internal local_unnamed_addr addrspace(4) constant [13 x double] [double 0x3FE45F306DC9C883, double 0x406B28D28834A1D2, double 0x40E10B4A1F6CF501, double 0x4149F72088DFB4E6, double 0x41AA2A2B1216B605, double 0x4201FEA8BB3BE600, double 0x4250E9DB94569883, double 0x4295367142D96C3E, double 0x42D0C7351C0FE465, double 0x42FDF1537961E7A8, double 0x4318FADA1D9742AD, double 0x431A6A62BB63A40C, double 0x42F7DD4E00E3184B], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q = internal local_unnamed_addr addrspace(4) constant [15 x double] [double 1.000000e+00, double 0x407554BBE33DF6D0, double 0x40EACD56D4D9BE96, double 0x415478A3A36859F4, double 0x41B4BEC095014516, double 0x420CDB326777C2EB, double 0x425BBC435F07A940, double 0x42A2357E7C0D108C, double 0x42DFC3D0B52A82F3, double 0x43119515C0126E89, double 0x4337006916401BF8, double 0x434F8D8E245D5F98, double 0x4352307314019A4E, double 0x433A78AB06FBD9E7, double 0x42F4F252E8C6C233], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FDBE1FDB85FCBFC, double 0x401C7FC4A4CD29B7, double 0x40441F91A172918F, double 0x40569F495083FE32, double 0x4052E785C1291E6C, double 0x402963DA5E858427, double 0xBFE51906626836E2], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x4033DCC50DCD8254, double 0x40631B677D5BB29F, double 0x4081D5A7BC4B586A, double 0x4090A232759E33CF, double 0x408C89486705C083, double 0x40702DF59FC94A86], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 = internal local_unnamed_addr addrspace(4) constant [8 x double] [double 0x3FD2EBDAE01A865A, double 0x4001E701431550F3, double 0x40140D55A266563C, double 0x40061BEABB9D2FFC, double 0x3FBE3E1608F6B264, double 0x3F948267DD4FFC5C, double 0xBF7EE20D1DA304B5, double 0x3F567E8E10E805D5], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 = internal local_unnamed_addr addrspace(4) constant [6 x double] [double 1.000000e+00, double 0x4024936FD6337035, double 0x4043419A7FE0209B, double 0x404EEC78CE96F318, double 0x4042DAE171B23F0E, double 0x4015ACB627173EB5], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FC5DB8AD965E90E, double 0x3FEAFCABC850EDD7, double 0x3FF65A44B7FDD998, double 0x3FEC06E8946EFB9F, double 0x3FC7D5630E234B35, double 0x3F7E240887A8C893, double 0xBF1B2EC29D8B2658], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x401AEF3DDBD087CA, double 0x40316DCC2BF05060, double 0x40359825CD283464, double 0x4029F6B804AEAD76, double 0x400B41AF064F350F, double 0x3FD1EF45AB10745B], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FB60B1E33F10647, double 0x3FC5B8636B0E3222, double 0x3FBC07DA7811D486, double 0x3F9C536ADCBF4A28, double 0x3F6411736D26FD34, double 0x3F057CF6442FA06A, double 0xBE91AFF35CC657D0], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x4008539DEC96056A, double 0x400C3466C3C7D450, double 0x3FFF2AD31AA58662, double 0x3FE0C440E94F34C7, double 0x3FAFB74D5C9C7495, double 0x3F62EDB894F212E5], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FA40A885E63F440, double 0x3FA4D8C2969E1484, double 0x3F8D5B4999760A8F, double 0x3F608452D391BA63, double 0x3F1A625FB47B3E5D, double 0x3EAFEDB5AFBF2767, double 0xBE2EA1B19268350A], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FFA3986886A7224, double 0x3FF09C23C029EA8F, double 0x3FD45C79F4902790, double 0x3FA8ACC143771083, double 0x3F6AA8DFF46DC0A1, double 0x3F126489EF16E3AC], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F90E6E15AE0A0B5, double 0x3F807EC586F8D6C3, double 0x3F5628C3995B9895, double 0x3F1815313F095300, double 0x3EC2BE8138C05760, double 0x3E46283600C31343, double 0xBDB56E517F96664C], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FE9EC7342A94DF8, double 0x3FD0446895858090, double 0x3FA3D20C0F793A99, double 0x3F67F69AED3331A7, double 0x3F19EDB2C6FDDBA7, double 0x3EB1F9FE5CE35DD4], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F7B09124BFF3246, double 0x3F5A1B509F6E6B7F, double 0x3F215B9A853FE1BC, double 0x3ED2AE3619D566E9, double 0x3E6CCC5CC17E6081, double 0x3DE0CED483645917, double 0xBD405E2A41165B21], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FDA44C156520F4B, double 0x3FB0B03579A0DD2F, double 0x3F74916FEE749C77, double 0x3F2921C431130861, double 0x3ECB75120A3FA3A9, double 0x3E5333ECBD8F94A3], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F64D5E29688B048, double 0x3F34521A788CC925, double 0x3EEB47C2C7618FAD, double 0x3E8D9FBD4F84DAEB, double 0x3E17053C44720DE3, double 0x3D7B01444FBF3B93, double 0xBCCAC1BB5B2D869C], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FCAC72D2F36E816, double 0x3F91595000B0EB93, double 0x3F45CFDE78902384, double 0x3EEB30C9CE3272DE, double 0x3E7E4D79F7AC44EB, double 0x3DF59B56446B4334], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F4F4BD6E99FF4E5, double 0x3F0EBAD7DF31FFFC, double 0x3EB4C3314DF7C43F, double 0x3E46AFD495CB1DD4, double 0x3DC1BAD3548A0AB8, double 0x3D14DED0BB7A816C, double 0xBC54EF99AFF7380B], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FBB218F9E698485, double 0x3F71D0F3147D5FAB, double 0x3F16B5EB6E086EA2, double 0x3EACB59E1205CC30, double 0x3E303913316A148C, double 0x3D9774482B0EAD22], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 0x3FC9884533D43651, double 0xBF93CB8214E9986F, double 0xBF814A78F15CF4A7, double 0x3F6C735355393978, double 0xBF3A917333BAF05A], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 1.000000e+00, double 0x3FE66E5F74B0D81B, double 0x3FD116080081EF83, double 0x3FAC405BB896DD07, double 0x3F7AA11B83649D74], align 8

; Function Attrs: nofree norecurse nounwind willreturn
define dso_local void @evaluate(double* nocapture readonly %0, double* nocapture %1, i32 %2) local_unnamed_addr #0 {
  %4 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #3, !range !5
  %5 = tail call i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #3, !range !6
  %6 = mul i32 %5, %4
  %7 = tail call i32 @llvm.nvvm.read.ptx.sreg.tid.x() #3, !range !7
  %8 = add i32 %6, %7
  %9 = icmp slt i32 %8, %2
  br i1 %9, label %10, label %334

10:                                               ; preds = %3
  %11 = sext i32 %8 to i64
  %12 = getelementptr inbounds double, double* %0, i64 %11
  %13 = load double, double* %12, align 8, !tbaa !8
  %14 = fcmp ord double %13, 0.000000e+00
  %15 = fcmp ule double %13, 0x7FEFFFFFFFFFFFFF
  %16 = fcmp uge double %13, 0xFFEFFFFFFFFFFFFF
  %17 = and i1 %15, %16
  %18 = and i1 %14, %17
  br i1 %18, label %19, label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

19:                                               ; preds = %10
  %20 = tail call double @llvm.fabs.f64(double %13) #3
  %21 = fcmp olt double %20, 1.250000e-01
  br i1 %21, label %22, label %105

22:                                               ; preds = %19
  %23 = fmul double %13, %13
  %24 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 12), align 8, !tbaa !8
  %25 = fmul double %23, %24
  %26 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 10), align 8, !tbaa !8
  %27 = fadd double %25, %26
  %28 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 11), align 8, !tbaa !8
  %29 = fmul double %23, %28
  %30 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 9), align 8, !tbaa !8
  %31 = fadd double %29, %30
  %32 = fmul double %23, %27
  %33 = fmul double %23, %31
  %34 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 8), align 8, !tbaa !8
  %35 = fadd double %32, %34
  %36 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 7), align 8, !tbaa !8
  %37 = fadd double %33, %36
  %38 = fmul double %23, %35
  %39 = fmul double %23, %37
  %40 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %41 = fadd double %38, %40
  %42 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %43 = fadd double %39, %42
  %44 = fmul double %23, %41
  %45 = fmul double %23, %43
  %46 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %47 = fadd double %44, %46
  %48 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %49 = fadd double %45, %48
  %50 = fmul double %23, %47
  %51 = fmul double %23, %49
  %52 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %53 = fadd double %50, %52
  %54 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %55 = fadd double %51, %54
  %56 = fmul double %23, %53
  %57 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %58 = fadd double %56, %57
  %59 = fmul double %20, %55
  %60 = fadd double %58, %59
  %61 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 14), align 8, !tbaa !8
  %62 = fmul double %23, %61
  %63 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 12), align 8, !tbaa !8
  %64 = fadd double %62, %63
  %65 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 13), align 8, !tbaa !8
  %66 = fmul double %23, %65
  %67 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 11), align 8, !tbaa !8
  %68 = fadd double %66, %67
  %69 = fmul double %23, %64
  %70 = fmul double %23, %68
  %71 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 10), align 8, !tbaa !8
  %72 = fadd double %69, %71
  %73 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 9), align 8, !tbaa !8
  %74 = fadd double %70, %73
  %75 = fmul double %23, %72
  %76 = fmul double %23, %74
  %77 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 8), align 8, !tbaa !8
  %78 = fadd double %75, %77
  %79 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 7), align 8, !tbaa !8
  %80 = fadd double %76, %79
  %81 = fmul double %23, %78
  %82 = fmul double %23, %80
  %83 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %84 = fadd double %81, %83
  %85 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %86 = fadd double %82, %85
  %87 = fmul double %23, %84
  %88 = fmul double %23, %86
  %89 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %90 = fadd double %87, %89
  %91 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %92 = fadd double %88, %91
  %93 = fmul double %23, %90
  %94 = fmul double %23, %92
  %95 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %96 = fadd double %93, %95
  %97 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %98 = fadd double %94, %97
  %99 = fmul double %23, %96
  %100 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %101 = fadd double %99, %100
  %102 = fmul double %20, %98
  %103 = fadd double %101, %102
  %104 = fdiv double %60, %103
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

105:                                              ; preds = %19
  %106 = fcmp olt double %20, 5.000000e-01
  br i1 %106, label %decision.dispatch, label %111, !decision.condition_prefix !12

decision.dispatch:                                ; preds = %105
  %107 = fcmp olt double %20, 2.500000e-01
  %108 = select i1 %107, double -1.250000e-01, double -2.500000e-01
  %109 = fadd double %20, %108
  %110 = fmul double %109, %109
  br i1 %107, label %fusion.common1, label %fusion.side2

111:                                              ; preds = %105
  %112 = fcmp olt double %20, 6.400000e+01
  br i1 %112, label %decision.dispatch2, label %124, !decision.condition_prefix !12

decision.dispatch2:                               ; preds = %111
  %113 = fcmp olt double %20, 4.000000e+00
  %114 = select i1 %113, double 2.000000e+00, double 3.200000e+01
  %115 = fcmp olt double %20, %114
  %116 = select i1 %113, double 1.000000e+00, double 1.600000e+01
  %117 = fcmp olt double %20, %116
  %118 = freeze i1 %117
  %119 = fcmp olt double %20, 8.000000e+00
  %120 = freeze i1 %119
  %fusion.paired6 = select i1 %113, i1 %118, i1 %120
  %121 = select i1 %113, double -5.000000e-01, double -4.000000e+00
  %122 = select i1 %113, double -1.000000e+00, double -8.000000e+00
  %123 = select i1 %fusion.paired6, double %121, double %122
  br i1 %113, label %fusion.common, label %fusion.side7

124:                                              ; preds = %111
  %125 = tail call double @llvm.sqrt.f64(double %20) #3
  %126 = fdiv double 1.000000e+00, %125
  %127 = fmul double %126, %126
  %128 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %129 = fmul double %127, %128
  %130 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %131 = fadd double %129, %130
  %132 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %133 = fmul double %127, %132
  %134 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %135 = fadd double %133, %134
  %136 = fmul double %127, %131
  %137 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %138 = fadd double %136, %137
  %139 = fmul double %126, %135
  %140 = fadd double %138, %139
  %141 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %142 = fmul double %127, %141
  %143 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %144 = fadd double %142, %143
  %145 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %146 = fmul double %127, %145
  %147 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %148 = fadd double %146, %147
  %149 = fmul double %127, %144
  %150 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %151 = fadd double %149, %150
  %152 = fmul double %126, %148
  %153 = fadd double %151, %152
  %154 = fdiv double %140, %153
  %155 = fmul double %126, %154
  %156 = fdiv double %155, %20
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

fusion.side7:                                     ; preds = %decision.dispatch2
  %157 = select i1 %117, double %123, double -1.600000e+01
  %158 = select i1 %115, i1 %117, i1 poison
  br label %fusion.common

fusion.common:                                    ; preds = %fusion.side7, %decision.dispatch2
  %159 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 0), %decision.dispatch2 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 0), %fusion.side7 ]
  %160 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 1), %decision.dispatch2 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 1), %fusion.side7 ]
  %161 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 2), %decision.dispatch2 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 2), %fusion.side7 ]
  %162 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 3), %decision.dispatch2 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 3), %fusion.side7 ]
  %163 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 5), %decision.dispatch2 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 5), %fusion.side7 ]
  %164 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 4), %decision.dispatch2 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 4), %fusion.side7 ]
  %165 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 6), %decision.dispatch2 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 6), %fusion.side7 ]
  %166 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 0), %decision.dispatch2 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 0), %fusion.side7 ]
  %167 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 1), %decision.dispatch2 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 1), %fusion.side7 ]
  %168 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 2), %decision.dispatch2 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 2), %fusion.side7 ]
  %169 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 3), %decision.dispatch2 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 3), %fusion.side7 ]
  %170 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 5), %decision.dispatch2 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 5), %fusion.side7 ]
  %171 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 4), %decision.dispatch2 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 4), %fusion.side7 ]
  %172 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 6), %decision.dispatch2 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 6), %fusion.side7 ]
  %173 = phi double [ -2.000000e+00, %decision.dispatch2 ], [ -3.200000e+01, %fusion.side7 ]
  %174 = phi i1 [ poison, %decision.dispatch2 ], [ %158, %fusion.side7 ]
  %fusion.paired = phi double [ %123, %decision.dispatch2 ], [ %157, %fusion.side7 ]
  %175 = select i1 %115, double %fusion.paired, double %173
  %176 = fadd double %20, %175
  %177 = fmul double %176, %176
  %178 = select i1 %118, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 6), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 6)
  %179 = select i1 %120, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 6), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 6)
  %180 = select i1 %174, double* %179, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 6)
  %fusion.paired5 = select i1 %113, double* %178, double* %180
  %181 = select i1 %115, double* %fusion.paired5, double* %172
  %182 = load double, double* %181, align 8, !tbaa !8
  %183 = fmul double %177, %182
  %184 = select i1 %118, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 4), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 4)
  %185 = select i1 %120, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 4), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 4)
  %186 = select i1 %174, double* %185, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 4)
  %fusion.paired9 = select i1 %113, double* %184, double* %186
  %187 = select i1 %115, double* %fusion.paired9, double* %171
  %188 = load double, double* %187, align 8, !tbaa !8
  %189 = fadd double %183, %188
  %190 = select i1 %118, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 5), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 5)
  %191 = select i1 %120, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 5), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 5)
  %192 = select i1 %174, double* %191, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 5)
  %fusion.paired13 = select i1 %113, double* %190, double* %192
  %193 = select i1 %115, double* %fusion.paired13, double* %170
  %194 = load double, double* %193, align 8, !tbaa !8
  %195 = fmul double %177, %194
  %196 = select i1 %118, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 3), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 3)
  %197 = select i1 %120, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 3), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 3)
  %198 = select i1 %174, double* %197, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 3)
  %fusion.paired17 = select i1 %113, double* %196, double* %198
  %199 = select i1 %115, double* %fusion.paired17, double* %169
  %200 = load double, double* %199, align 8, !tbaa !8
  %201 = fadd double %195, %200
  %202 = fmul double %177, %189
  %203 = fmul double %177, %201
  %204 = select i1 %118, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 2), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 2)
  %205 = select i1 %120, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 2), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 2)
  %206 = select i1 %174, double* %205, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 2)
  %fusion.paired21 = select i1 %113, double* %204, double* %206
  %207 = select i1 %115, double* %fusion.paired21, double* %168
  %208 = load double, double* %207, align 8, !tbaa !8
  %209 = fadd double %202, %208
  %210 = select i1 %118, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 1), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 1)
  %211 = select i1 %120, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 1), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 1)
  %212 = select i1 %174, double* %211, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 1)
  %fusion.paired25 = select i1 %113, double* %210, double* %212
  %213 = select i1 %115, double* %fusion.paired25, double* %167
  %214 = load double, double* %213, align 8, !tbaa !8
  %215 = fadd double %203, %214
  %216 = fmul double %177, %209
  %217 = select i1 %118, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 0), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 0)
  %218 = select i1 %120, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 0), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 0)
  %219 = select i1 %174, double* %218, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 0)
  %fusion.paired29 = select i1 %113, double* %217, double* %219
  %220 = select i1 %115, double* %fusion.paired29, double* %166
  %221 = load double, double* %220, align 8, !tbaa !8
  %222 = fadd double %216, %221
  %223 = fmul double %176, %215
  %224 = fadd double %222, %223
  %225 = select i1 %118, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 6), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 6)
  %226 = select i1 %120, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 6), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 6)
  %227 = select i1 %174, double* %226, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 6)
  %fusion.paired33 = select i1 %113, double* %225, double* %227
  %228 = select i1 %115, double* %fusion.paired33, double* %165
  %229 = load double, double* %228, align 8, !tbaa !8
  %230 = fmul double %177, %229
  %231 = select i1 %118, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 4), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 4)
  %232 = select i1 %120, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 4), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 4)
  %233 = select i1 %174, double* %232, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 4)
  %fusion.paired37 = select i1 %113, double* %231, double* %233
  %234 = select i1 %115, double* %fusion.paired37, double* %164
  %235 = load double, double* %234, align 8, !tbaa !8
  %236 = fadd double %230, %235
  %237 = select i1 %118, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 5), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 5)
  %238 = select i1 %120, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 5), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 5)
  %239 = select i1 %174, double* %238, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 5)
  %fusion.paired41 = select i1 %113, double* %237, double* %239
  %240 = select i1 %115, double* %fusion.paired41, double* %163
  %241 = load double, double* %240, align 8, !tbaa !8
  %242 = fmul double %177, %241
  %243 = select i1 %118, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 3), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 3)
  %244 = select i1 %120, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 3), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 3)
  %245 = select i1 %174, double* %244, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 3)
  %fusion.paired45 = select i1 %113, double* %243, double* %245
  %246 = select i1 %115, double* %fusion.paired45, double* %162
  %247 = load double, double* %246, align 8, !tbaa !8
  %248 = fadd double %242, %247
  %249 = fmul double %177, %236
  %250 = fmul double %177, %248
  %251 = select i1 %118, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 2), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 2)
  %252 = select i1 %120, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 2), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 2)
  %253 = select i1 %174, double* %252, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 2)
  %fusion.paired49 = select i1 %113, double* %251, double* %253
  %254 = select i1 %115, double* %fusion.paired49, double* %161
  %255 = load double, double* %254, align 8, !tbaa !8
  %256 = fadd double %249, %255
  %257 = select i1 %118, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 1), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 1)
  %258 = select i1 %120, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 1), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 1)
  %259 = select i1 %174, double* %258, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 1)
  %fusion.paired53 = select i1 %113, double* %257, double* %259
  %260 = select i1 %115, double* %fusion.paired53, double* %160
  %261 = load double, double* %260, align 8, !tbaa !8
  %262 = fadd double %250, %261
  %263 = fmul double %177, %256
  %264 = select i1 %118, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 0), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 0)
  %265 = select i1 %120, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 0), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 0)
  %266 = select i1 %174, double* %265, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 0)
  %fusion.paired57 = select i1 %113, double* %264, double* %266
  %267 = select i1 %115, double* %fusion.paired57, double* %159
  %268 = load double, double* %267, align 8, !tbaa !8
  %269 = fadd double %263, %268
  %270 = fmul double %176, %262
  %271 = fadd double %269, %270
  %272 = fdiv double %224, %271
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

fusion.side2:                                     ; preds = %decision.dispatch
  %273 = load double, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 7), align 8, !tbaa !8
  %274 = fmul double %110, %273
  %275 = load double, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %276 = fadd double %274, %275
  br label %fusion.common1

fusion.common1:                                   ; preds = %fusion.side2, %decision.dispatch
  %277 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 4), %decision.dispatch ], [ getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 4), %fusion.side2 ]
  %278 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 6), %decision.dispatch ], [ getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 6), %fusion.side2 ]
  %279 = phi double [ poison, %decision.dispatch ], [ %276, %fusion.side2 ]
  %280 = load double, double* %278, align 8, !tbaa !8
  %281 = fmul double %110, %280
  %282 = load double, double* %277, align 8, !tbaa !8
  %283 = fadd double %281, %282
  br i1 %107, label %fusion.side4, label %fusion.common3

fusion.side4:                                     ; preds = %fusion.common1
  %284 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 5), align 8, !tbaa !8
  br label %fusion.common3

fusion.common3:                                   ; preds = %fusion.side4, %fusion.common1
  %285 = phi double* [ getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 0), %fusion.common1 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 0), %fusion.side4 ]
  %286 = phi double* [ getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 1), %fusion.common1 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 1), %fusion.side4 ]
  %287 = phi double* [ getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 2), %fusion.common1 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 2), %fusion.side4 ]
  %288 = phi double* [ getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 3), %fusion.common1 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 3), %fusion.side4 ]
  %289 = phi double [ %279, %fusion.common1 ], [ %284, %fusion.side4 ]
  %290 = fmul double %110, %289
  %291 = fmul double %110, %283
  %292 = load double, double* %288, align 8, !tbaa !8
  %293 = fadd double %290, %292
  %294 = fmul double %110, %293
  %295 = load double, double* %287, align 8, !tbaa !8
  %296 = fadd double %291, %295
  %297 = fmul double %110, %296
  %298 = load double, double* %286, align 8, !tbaa !8
  %299 = fadd double %294, %298
  %300 = load double, double* %285, align 8, !tbaa !8
  %301 = fadd double %297, %300
  %302 = fmul double %109, %299
  %303 = fadd double %301, %302
  br i1 %107, label %fusion.side14, label %fusion.common13

fusion.side14:                                    ; preds = %fusion.common3
  %304 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %305 = fmul double %110, %304
  %306 = load double, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %307 = fadd double %305, %306
  br label %fusion.common13

fusion.common13:                                  ; preds = %fusion.side14, %fusion.common3
  %308 = phi double* [ getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 3), %fusion.common3 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 3), %fusion.side14 ]
  %309 = phi double* [ getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 5), %fusion.common3 ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 5), %fusion.side14 ]
  %310 = phi double [ poison, %fusion.common3 ], [ %307, %fusion.side14 ]
  %311 = load double, double* %309, align 8, !tbaa !8
  %312 = fmul double %110, %311
  %313 = load double, double* %308, align 8, !tbaa !8
  %314 = fadd double %312, %313
  br i1 %107, label %fusion.common15, label %fusion.side16

fusion.side16:                                    ; preds = %fusion.common13
  %315 = load double, double* getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 4), align 8, !tbaa !8
  br label %fusion.common15

fusion.common15:                                  ; preds = %fusion.side16, %fusion.common13
  %316 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 0), %fusion.common13 ], [ getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 0), %fusion.side16 ]
  %317 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 1), %fusion.common13 ], [ getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 1), %fusion.side16 ]
  %318 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 2), %fusion.common13 ], [ getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 2), %fusion.side16 ]
  %319 = phi double [ %310, %fusion.common13 ], [ %315, %fusion.side16 ]
  %320 = fmul double %110, %319
  %321 = fmul double %110, %314
  %322 = load double, double* %318, align 8, !tbaa !8
  %323 = fadd double %320, %322
  %324 = fmul double %110, %323
  %325 = load double, double* %317, align 8, !tbaa !8
  %326 = fadd double %321, %325
  %327 = load double, double* %316, align 8, !tbaa !8
  %328 = fadd double %324, %327
  %329 = fmul double %109, %326
  %330 = fadd double %328, %329
  %331 = fdiv double %303, %330
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit: ; preds = %fusion.common15, %fusion.common, %124, %22, %10
  %332 = phi double [ 0x7FF8000000000000, %10 ], [ %104, %22 ], [ %156, %124 ], [ %272, %fusion.common ], [ %331, %fusion.common15 ]
  %333 = getelementptr inbounds double, double* %1, i64 %11
  store double %332, double* %333, align 8, !tbaa !8
  br label %334

334:                                              ; preds = %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit, %3
  ret void
}

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #1

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #1

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.tid.x() #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.sqrt.f64(double) #2

attributes #0 = { nofree norecurse nounwind willreturn "disable-tail-calls"="false" "frame-pointer"="all" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="sm_70" "target-features"="+ptx32,+sm_70" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nounwind readnone }
attributes #2 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!nvvm.annotations = !{!0}
!llvm.module.flags = !{!1, !2}
!llvm.ident = !{!3, !4}

!0 = !{void (double*, double*, i32)* @evaluate, !"kernel", i32 1}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 4, !"nvvm-reflect-ftz", i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 3.8.0 (tags/RELEASE_380/final)"}
!5 = !{i32 0, i32 2147483647}
!6 = !{i32 1, i32 1025}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = !{}
