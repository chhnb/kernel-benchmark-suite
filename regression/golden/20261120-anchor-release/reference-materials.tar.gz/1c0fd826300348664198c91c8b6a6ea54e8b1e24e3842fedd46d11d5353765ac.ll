; ModuleID = '/data/home/chh/simplify-v2/build/dp1-removal/stable-darm/MapAiry/trial-157/fused.ll'
source_filename = "/home/chh/kernel-benchmark-suite/cases/boost-mapairy/source/kernel.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

@_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 0x3FE428A2F98D728B, double 0x3FE965FEA53D6E3D, double 1.000000e+00, double 0x3FF428A2F98D728B, double 0x3FF965FEA53D6E3D], align 16

; Function Attrs: nofree norecurse nounwind
define protected amdgpu_kernel void @evaluate(double addrspace(1)* nocapture readonly %input.coerce, double addrspace(1)* nocapture %output.coerce, i32 %n) local_unnamed_addr #0 {
entry:
  %0 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %1 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %2 = getelementptr i8, i8 addrspace(4)* %1, i64 4
  %3 = bitcast i8 addrspace(4)* %2 to i16 addrspace(4)*
  %4 = load i16, i16 addrspace(4)* %3, align 4, !range !5, !invariant.load !6
  %5 = zext i16 %4 to i32
  %6 = mul i32 %0, %5
  %7 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !7
  %add = add i32 %6, %7
  %cmp = icmp slt i32 %add, %n
  br i1 %cmp, label %if.end8.i.i, label %if.end

if.end8.i.i:                                      ; preds = %entry
  %idxprom = sext i32 %add to i64
  %arrayidx11 = getelementptr inbounds double, double addrspace(1)* %input.coerce, i64 %idxprom
  %arrayidx.val = load double, double addrspace(1)* %arrayidx11, align 8, !tbaa !8
  %cmp.i3.i.i = fcmp olt double %arrayidx.val, 0.000000e+00
  %cmp1.i.i.i = fcmp ogt double %arrayidx.val, 1.000000e+00
  %or.cond.i.i.i = or i1 %cmp.i3.i.i, %cmp1.i.i.i
  br i1 %or.cond.i.i.i, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %lor.lhs.false2.i.i.i

lor.lhs.false2.i.i.i:                             ; preds = %if.end8.i.i
  %cmp.i.i.i.i.i = fcmp uno double %arrayidx.val, 0.000000e+00
  %cmp.i3.i.i.i.i = fcmp ogt double %arrayidx.val, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i4.i.i = fcmp olt double %arrayidx.val, 0xFFEFFFFFFFFFFFFF
  %lnot.i.i.i.i.not = or i1 %cmp.i3.i.i.i.i, %cmp1.i.i.i4.i.i
  %brmerge = or i1 %cmp.i.i.i.i.i, %lnot.i.i.i.i.not
  br i1 %brmerge, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %if.end14.i.i

if.end14.i.i:                                     ; preds = %lor.lhs.false2.i.i.i
  %cmp.i.i.i = fcmp ogt double %arrayidx.val, 5.000000e-01
  br i1 %cmp.i.i.i, label %if.then.i.i.i, label %cond.false7.i.i.i

if.then.i.i.i:                                    ; preds = %if.end14.i.i
  %sub.i.i.i = fsub double 1.000000e+00, %arrayidx.val
  %decision.interval3 = fcmp ult double %sub.i.i.i, 1.250000e-01
  br i1 %decision.interval3, label %if.else9.i.i.i.i, label %decision.dispatch2, !decision.condition_prefix !6

decision.dispatch2:                               ; preds = %if.then.i.i.i
  %cmp.i.i.i.i = fcmp oge double %sub.i.i.i, 2.500000e-01
  %merged.select4 = select i1 %cmp.i.i.i.i, double -2.500000e-01, double -1.250000e-01
  %8 = fadd double %sub.i.i.i, %merged.select4
  %9 = fmul double %8, %8
  %merged.select10 = select i1 %cmp.i.i.i.i, double 0x404567B47A5D8CA4, double 0x409819CEF5B4E6C7
  %10 = fmul double %9, %merged.select10
  %11 = fsub double 0x405E69E51891A050, %10
  %12 = fadd double %10, 0xC096FC492E087B38
  %guard.result53 = select i1 %cmp.i.i.i.i, double %11, double %12
  %merged.select11 = select i1 %cmp.i.i.i.i, double 0x4050AAC38C60A1E3, double 0x4051B7FD7FEEB259
  %13 = fmul double %9, %merged.select11
  %merged.select17 = select i1 %cmp.i.i.i.i, double 0x40548E4AE13E33D8, double 0xC07E56261CB553E9
  %14 = fsub double %merged.select17, %13
  %15 = fmul double %9, %guard.result53
  %16 = fmul double %9, %14
  %merged.select19 = select i1 %cmp.i.i.i.i, double 0xC04860792DC1D02E, double 0x4036AD73494335DA
  %17 = fadd double %15, %merged.select19
  %merged.select20 = select i1 %cmp.i.i.i.i, double 0xC0407FAA65922A12, double 0x4034FFCB850049DF
  %18 = fadd double %16, %merged.select20
  %19 = fmul double %9, %17
  %merged.select21 = select i1 %cmp.i.i.i.i, double %18, double %17
  %20 = fmul double %9, %merged.select21
  %.op = fadd double %19, 0xC005F196AB7EF904
  %merged.select22 = select i1 %cmp.i.i.i.i, double 0x3FDED118296B2018, double 0x3FFB3E8B8B7EC8F9
  %21 = fadd double %20, %merged.select22
  %merged.select23 = select i1 %cmp.i.i.i.i, double %.op, double %18
  %22 = fmul double %8, %merged.select23
  %merged.select24 = select i1 %cmp.i.i.i.i, double %21, double %22
  %merged.select25 = select i1 %cmp.i.i.i.i, double %22, double %21
  %23 = fadd double %merged.select24, %merged.select25
  %merged.select26 = select i1 %cmp.i.i.i.i, double 0x3FF51F0306685285, double 0x406113A5A6902AC1
  %24 = fmul double %9, %merged.select26
  %25 = fadd double %24, 0xC083E59B9D34A0F1
  %merged.select27 = select i1 %cmp.i.i.i.i, double 0x3FEFDC5AEE1525E4, double 0x4071AEC837B9190D
  %26 = fmul double %9, %merged.select27
  %merged.select28 = select i1 %cmp.i.i.i.i, double 0x4043A793DEC20DEB, double 0x406A5A0FD2D4B901
  %27 = fsub double %merged.select28, %26
  br i1 %cmp.i.i.i.i, label %predication.split63, label %predication.tail64

if.else9.i.i.i.i:                                 ; preds = %if.then.i.i.i
  %28 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %sub.i.i.i) #3
  %29 = add nsw i32 %28, -1
  %30 = fcmp uno double %sub.i.i.i, 0.000000e+00
  %31 = tail call double @llvm.fabs.f64(double %sub.i.i.i) #4
  %32 = fcmp oeq double %31, 0x7FF0000000000000
  %33 = or i1 %30, %32
  %34 = select i1 %33, i32 2147483647, i32 %29
  %35 = fcmp oeq double %sub.i.i.i, 0.000000e+00
  %36 = select i1 %35, i32 -2147483648, i32 %34
  %cmp11.i.i.i.i = icmp sgt i32 %36, -5
  br i1 %cmp11.i.i.i.i, label %if.then12.i.i.i.i, label %if.else21.i.i.i.i

if.then12.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %37 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 3) #3
  %38 = tail call double @llvm.amdgcn.frexp.mant.f64(double %37) #3
  %39 = fcmp olt double %38, 0x3FE5555555555555
  %40 = zext i1 %39 to i32
  %41 = tail call double @llvm.amdgcn.ldexp.f64(double %38, i32 %40) #3
  %42 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %37) #3
  %43 = sub nsw i32 %42, %40
  %44 = fadd double %41, -1.000000e+00
  %45 = fadd double %41, 1.000000e+00
  %46 = fsub double %45, %41
  %47 = fsub double %45, %46
  %48 = fsub double %41, %47
  %49 = fsub double 1.000000e+00, %46
  %50 = fadd double %49, %48
  %51 = tail call double @llvm.amdgcn.rcp.f64(double %45) #3
  %52 = fneg double %45
  %53 = tail call double @llvm.fma.f64(double %52, double %51, double 1.000000e+00) #3
  %54 = tail call double @llvm.fma.f64(double %53, double %51, double %51) #3
  %55 = tail call double @llvm.fma.f64(double %52, double %54, double 1.000000e+00) #3
  %56 = tail call double @llvm.fma.f64(double %55, double %54, double %54) #3
  %57 = fmul double %44, %56
  %58 = fmul double %45, %57
  %59 = fneg double %58
  %60 = tail call double @llvm.fma.f64(double %57, double %45, double %59) #3
  %61 = tail call double @llvm.fma.f64(double %57, double %50, double %60) #3
  %62 = fadd double %58, %61
  %63 = fsub double %62, %58
  %64 = fsub double %61, %63
  %65 = fsub double %44, %62
  %66 = fsub double %44, %65
  %67 = fsub double %66, %62
  %68 = fsub double %67, %64
  %69 = fadd double %65, %68
  %70 = fmul double %56, %69
  %71 = fadd double %57, %70
  %72 = fsub double %71, %57
  %73 = fsub double %70, %72
  %74 = fmul double %71, %71
  %75 = fneg double %74
  %76 = tail call double @llvm.fma.f64(double %71, double %71, double %75) #3
  %77 = fmul double %73, 2.000000e+00
  %78 = tail call double @llvm.fma.f64(double %71, double %77, double %76) #3
  %79 = tail call double @llvm.fma.f64(double %73, double %73, double %78) #3
  %80 = fadd double %74, %79
  %81 = fsub double %80, %74
  %82 = fsub double %79, %81
  %83 = tail call double @llvm.fma.f64(double %80, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %84 = tail call double @llvm.fma.f64(double %80, double %83, double 0x3FC7474DD7F4DF2E) #3
  %85 = tail call double @llvm.fma.f64(double %80, double %84, double 0x3FCC71C016291751) #3
  %86 = tail call double @llvm.fma.f64(double %80, double %85, double 0x3FD249249B27ACF1) #3
  %87 = tail call double @llvm.fma.f64(double %80, double %86, double 0x3FD99999998EF7B6) #3
  %88 = tail call double @llvm.fma.f64(double %80, double %87, double 0x3FE5555555555780) #3
  %89 = tail call double @llvm.amdgcn.ldexp.f64(double %71, i32 1) #3
  %90 = tail call double @llvm.amdgcn.ldexp.f64(double %73, i32 1) #3
  %91 = fmul double %71, %80
  %92 = fneg double %91
  %93 = tail call double @llvm.fma.f64(double %71, double %80, double %92) #3
  %94 = fmul double %73, %80
  %95 = tail call double @llvm.fma.f64(double %71, double %82, double %94) #3
  %96 = fadd double %93, %95
  %97 = fadd double %91, %96
  %98 = fsub double %97, %91
  %99 = fsub double %96, %98
  %100 = fmul double %97, %88
  %101 = fneg double %100
  %102 = tail call double @llvm.fma.f64(double %97, double %88, double %101) #3
  %103 = tail call double @llvm.fma.f64(double %99, double %88, double %102) #3
  %104 = fadd double %100, %103
  %105 = fsub double %104, %100
  %106 = fsub double %103, %105
  %107 = fadd double %89, %104
  %108 = fsub double %107, %89
  %109 = fsub double %107, %108
  %110 = fsub double %89, %109
  %111 = fsub double %104, %108
  %112 = fadd double %111, %110
  %113 = fadd double %90, %106
  %114 = fsub double %113, %90
  %115 = fsub double %113, %114
  %116 = fsub double %90, %115
  %117 = fsub double %106, %114
  %118 = fadd double %117, %116
  %119 = fadd double %113, %112
  %120 = fadd double %107, %119
  %121 = fsub double %120, %107
  %122 = fsub double %119, %121
  %123 = fadd double %118, %122
  %124 = fadd double %120, %123
  %125 = fsub double %124, %120
  %126 = fsub double %123, %125
  %127 = sitofp i32 %43 to double
  %128 = fmul double %124, 0x3FF71547652B82FE
  %129 = fneg double %128
  %130 = fmul double %124, 0x3C7777D0FFDA0D24
  %131 = insertelement <2 x double> undef, double %124, i32 0
  %132 = insertelement <2 x double> %131, double %126, i32 1
  %133 = insertelement <2 x double> undef, double %129, i32 0
  %134 = insertelement <2 x double> %133, double %130, i32 1
  %135 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %132, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %134) #3
  %136 = extractelement <2 x double> %135, i32 0
  %137 = extractelement <2 x double> %135, i32 1
  %138 = fadd double %136, %137
  %139 = fadd double %128, %138
  %140 = fsub double %139, %128
  %141 = fsub double %138, %140
  %142 = fadd double %139, %127
  %143 = fsub double %142, %127
  %144 = fsub double %143, %142
  %145 = fadd double %144, %127
  %146 = fsub double %139, %143
  %147 = fadd double %146, %145
  %148 = fadd double %141, %147
  %149 = fadd double %142, %148
  %150 = tail call double @llvm.fabs.f64(double %37) #4
  %151 = fcmp oeq double %150, 0x7FF0000000000000
  %152 = select i1 %151, double %37, double %149
  %153 = fcmp olt double %37, 0.000000e+00
  %154 = select i1 %153, double 0x7FF8000000000000, double %152
  %155 = fcmp oeq double %37, 0.000000e+00
  %156 = select i1 %155, double 0xFFF0000000000000, double %154
  %mul.i.i682.i.i.i.i = fmul double %156, %156
  %mul1.i.i683.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3ED3E1F985CBB733
  %add.i.i684.i.i.i.i = fadd double %mul1.i.i683.i.i.i.i, 0x3F385DA443F57737
  %mul5.i.i685.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F24E9382EAABDBB
  %add7.i.i686.i.i.i.i = fadd double %mul5.i.i685.i.i.i.i, 0x3F77E2A342AA4E3B
  %mul10.i.i687.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i684.i.i.i.i
  %mul12.i.i688.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i686.i.i.i.i
  %add15.i.i689.i.i.i.i = fadd double %mul10.i.i687.i.i.i.i, 0x3F9808F2B640E69B
  %add18.i.i690.i.i.i.i = fadd double %mul12.i.i688.i.i.i.i, 0x3F9DD5C523A6CF6D
  %mul20.i.i691.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i689.i.i.i.i
  %mul22.i.i692.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i690.i.i.i.i
  %add25.i.i693.i.i.i.i = fadd double %mul20.i.i691.i.i.i.i, 0x3FD3E6D375851610
  %add28.i.i694.i.i.i.i = fadd double %mul22.i.i692.i.i.i.i, 0x3FDB3E8B8B7EC8FA
  %157 = fmul double %156, %add25.i.i693.i.i.i.i
  %add33.i.i696.i.i.i.i = fsub double %add28.i.i694.i.i.i.i, %157
  %mul1.i.i668.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3EF03AD80F271435
  %add.i.i669.i.i.i.i = fadd double %mul1.i.i668.i.i.i.i, 0x3F577B23357A1929
  %mul5.i.i670.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F27C5B13F4BAFF2
  %add7.i.i671.i.i.i.i = fadd double %mul5.i.i670.i.i.i.i, 0x3F825620F70E4E86
  %mul10.i.i672.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i669.i.i.i.i
  %mul12.i.i673.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i671.i.i.i.i
  %add15.i.i674.i.i.i.i = fadd double %mul10.i.i672.i.i.i.i, 0x3FA38976FFA62DF3
  %add18.i.i675.i.i.i.i = fadd double %mul12.i.i673.i.i.i.i, 0x3FBACD3553111974
  %mul20.i.i676.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i674.i.i.i.i
  %mul22.i.i677.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i675.i.i.i.i
  %add25.i.i678.i.i.i.i = fadd double %mul20.i.i676.i.i.i.i, 0x3FDA8C1A7A09CF75
  %add28.i.i679.i.i.i.i = fadd double %mul22.i.i677.i.i.i.i, 1.000000e+00
  %158 = fmul double %156, %add25.i.i678.i.i.i.i
  %add33.i.i681.i.i.i.i = fsub double %add28.i.i679.i.i.i.i, %158
  %mul.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i590.i.i.i.i = fcmp ogt double %mul.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i591.i.i.i.i = fcmp oeq double %mul.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i592.i.i.i.i = or i1 %cmp.i.i.i.i590.i.i.i.i, %cmp.i.i.i591.i.i.i.i
  br i1 %or.cond.i.i.i592.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end.i.i.i594.i.i.i.i

if.end.i.i.i594.i.i.i.i:                          ; preds = %if.then12.i.i.i.i
  %cmp.i.i.i.i.i593.i.i.i.i = fcmp uno double %mul.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i593.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end7.i.i.i620.i.i.i.i

if.end7.i.i.i620.i.i.i.i:                         ; preds = %if.end.i.i.i594.i.i.i.i
  %159 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul.i.i.i.i) #3
  %160 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul.i.i.i.i) #3
  %161 = tail call i1 @llvm.amdgcn.class.f64(double %mul.i.i.i.i, i32 519) #3
  %162 = select i1 %161, i32 0, i32 %159
  %163 = select i1 %161, double %mul.i.i.i.i, double %160
  %mul.i.i.i.i.i606.i.i.i.i = fmul double %163, %163
  %mul1.i.i.i.i.i607.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i608.i.i.i.i = fadd double %mul1.i.i.i.i.i607.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i609.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FE479D17050CA47
  %164 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i609.i.i.i.i
  %mul10.i.i.i.i.i611.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %add.i.i.i.i.i608.i.i.i.i
  %mul12.i.i.i.i.i612.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %164
  %add15.i.i.i.i.i613.i.i.i.i = fadd double %mul10.i.i.i.i.i611.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i614.i.i.i.i = fadd double %mul12.i.i.i.i.i612.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i615.i.i.i.i = fmul double %163, %add15.i.i.i.i.i613.i.i.i.i
  %add23.i.i.i.i.i616.i.i.i.i = fadd double %add18.i.i.i.i.i614.i.i.i.i, %mul20.i.i.i.i.i615.i.i.i.i
  %.frozen = freeze i32 %162
  %div.i.i.i617.i.i.i.i = sdiv i32 %.frozen, 3
  %165 = call i32 @llvm.abs.i32(i32 %div.i.i.i617.i.i.i.i, i1 true)
  %cmp11.i.i.i619.i.i.i.i = icmp ult i32 %165, 64
  %166 = sub nsw i32 0, %div.i.i.i617.i.i.i.i
  %167 = icmp sgt i32 %162, 2
  %168 = select i1 %167, i32 %div.i.i.i617.i.i.i.i, i32 %166
  %169 = zext i32 %168 to i64
  %170 = shl nuw i64 1, %169
  %171 = uitofp i64 %170 to double
  %not.cmp11.i.i.i619.i.i.i.i = xor i1 %cmp11.i.i.i619.i.i.i.i, true
  %172 = or i1 %167, %not.cmp11.i.i.i619.i.i.i.i
  br i1 %172, label %merged.bb5, label %merged.bb6

do.body.i.i.i651.i.i.i.i:                         ; preds = %merged.bb7, %do.body.i.i.i651.i.i.i.i
  %guess.i.i.i589.i.i.i.i.1 = phi double [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ], [ %mul24.i.i.i638.i.i.i.i, %merged.bb7 ]
  %mul28.i.i.i641.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %guess.i.i.i589.i.i.i.i.1
  %mul29.i.i.i642.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %mul28.i.i.i641.i.i.i.i
  %add30.i.i.i643.i.i.i.i = fadd double %mul.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add31.i.i.i644.i.i.i.i = fadd double %mul.i.i.i.i, %add30.i.i.i643.i.i.i.i
  %add32.i.i.i645.i.i.i.i = fadd double %mul29.i.i.i642.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add33.i.i.i646.i.i.i.i = fadd double %mul.i.i.i.i, %add32.i.i.i645.i.i.i.i
  %div34.i.i.i647.i.i.i.i = fdiv double %add31.i.i.i644.i.i.i.i, %add33.i.i.i646.i.i.i.i
  %mul35.i.i.i648.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %div34.i.i.i647.i.i.i.i
  %sub36.i.i.i649.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i647.i.i.i.i
  %173 = tail call double @llvm.fabs.f64(double %sub36.i.i.i649.i.i.i.i) #3
  %cmp38.i.i.i650.i.i.i.i = fcmp ogt double %173, 0x3EC0000000000000
  br i1 %cmp38.i.i.i650.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

do.body40.i.i.i662.i.i.i.i:                       ; preds = %merged.bb7, %do.body40.i.i.i662.i.i.i.i
  %guess.i.i.i589.i.i.i.i.2 = phi double [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ], [ %mul24.i.i.i638.i.i.i.i, %merged.bb7 ]
  %mul41.i.i.i652.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, %guess.i.i.i589.i.i.i.i.2
  %div42.i.i.i653.i.i.i.i = fdiv double %mul.i.i.i.i, %guess.i.i.i589.i.i.i.i.2
  %sub43.i.i.i654.i.i.i.i = fsub double %mul41.i.i.i652.i.i.i.i, %div42.i.i.i653.i.i.i.i
  %mul44.i.i.i655.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i656.i.i.i.i = fdiv double %mul.i.i.i.i, %mul41.i.i.i652.i.i.i.i
  %add46.i.i.i657.i.i.i.i = fadd double %mul44.i.i.i655.i.i.i.i, %div45.i.i.i656.i.i.i.i
  %div47.i.i.i658.i.i.i.i = fdiv double %sub43.i.i.i654.i.i.i.i, %add46.i.i.i657.i.i.i.i
  %sub48.i.i.i659.i.i.i.i = fsub double %guess.i.i.i589.i.i.i.i.2, %div47.i.i.i658.i.i.i.i
  %mul50.i.i.i660.i.i.i.i = fmul double %sub48.i.i.i659.i.i.i.i, 0x3EC0000000000000
  %174 = tail call double @llvm.fabs.f64(double %div47.i.i.i658.i.i.i.i) #3
  %cmp52.i.i.i661.i.i.i.i = fcmp olt double %mul50.i.i.i660.i.i.i.i, %174
  br i1 %cmp52.i.i.i661.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i: ; preds = %do.body40.i.i.i662.i.i.i.i, %do.body.i.i.i651.i.i.i.i, %if.end.i.i.i594.i.i.i.i, %if.then12.i.i.i.i
  %retval.0.i.i.i665.i.i.i.i = phi double [ %mul.i.i.i.i, %if.then12.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i594.i.i.i.i ], [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ], [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ]
  %mul19.i.i.i.i = fmul double %add33.i.i681.i.i.i.i, %retval.0.i.i.i665.i.i.i.i
  %div20.i.i.i.i = fdiv double %add33.i.i696.i.i.i.i, %mul19.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else21.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %cmp23.i.i.i.i = icmp sgt i32 %36, -9
  br i1 %cmp23.i.i.i.i, label %if.then24.i.i.i.i, label %if.else35.i.i.i.i

if.then24.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %175 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 4) #3
  %176 = tail call double @llvm.amdgcn.frexp.mant.f64(double %175) #3
  %177 = fcmp olt double %176, 0x3FE5555555555555
  %178 = zext i1 %177 to i32
  %179 = tail call double @llvm.amdgcn.ldexp.f64(double %176, i32 %178) #3
  %180 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %175) #3
  %181 = sub nsw i32 %180, %178
  %182 = fadd double %179, -1.000000e+00
  %183 = fadd double %179, 1.000000e+00
  %184 = fsub double %183, %179
  %185 = fsub double %183, %184
  %186 = fsub double %179, %185
  %187 = fsub double 1.000000e+00, %184
  %188 = fadd double %187, %186
  %189 = tail call double @llvm.amdgcn.rcp.f64(double %183) #3
  %190 = fneg double %183
  %191 = tail call double @llvm.fma.f64(double %190, double %189, double 1.000000e+00) #3
  %192 = tail call double @llvm.fma.f64(double %191, double %189, double %189) #3
  %193 = tail call double @llvm.fma.f64(double %190, double %192, double 1.000000e+00) #3
  %194 = tail call double @llvm.fma.f64(double %193, double %192, double %192) #3
  %195 = fmul double %182, %194
  %196 = fmul double %183, %195
  %197 = fneg double %196
  %198 = tail call double @llvm.fma.f64(double %195, double %183, double %197) #3
  %199 = tail call double @llvm.fma.f64(double %195, double %188, double %198) #3
  %200 = fadd double %196, %199
  %201 = fsub double %200, %196
  %202 = fsub double %199, %201
  %203 = fsub double %182, %200
  %204 = fsub double %182, %203
  %205 = fsub double %204, %200
  %206 = fsub double %205, %202
  %207 = fadd double %203, %206
  %208 = fmul double %194, %207
  %209 = fadd double %195, %208
  %210 = fsub double %209, %195
  %211 = fsub double %208, %210
  %212 = fmul double %209, %209
  %213 = fneg double %212
  %214 = tail call double @llvm.fma.f64(double %209, double %209, double %213) #3
  %215 = fmul double %211, 2.000000e+00
  %216 = tail call double @llvm.fma.f64(double %209, double %215, double %214) #3
  %217 = tail call double @llvm.fma.f64(double %211, double %211, double %216) #3
  %218 = fadd double %212, %217
  %219 = fsub double %218, %212
  %220 = fsub double %217, %219
  %221 = tail call double @llvm.fma.f64(double %218, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %222 = tail call double @llvm.fma.f64(double %218, double %221, double 0x3FC7474DD7F4DF2E) #3
  %223 = tail call double @llvm.fma.f64(double %218, double %222, double 0x3FCC71C016291751) #3
  %224 = tail call double @llvm.fma.f64(double %218, double %223, double 0x3FD249249B27ACF1) #3
  %225 = tail call double @llvm.fma.f64(double %218, double %224, double 0x3FD99999998EF7B6) #3
  %226 = tail call double @llvm.fma.f64(double %218, double %225, double 0x3FE5555555555780) #3
  %227 = tail call double @llvm.amdgcn.ldexp.f64(double %209, i32 1) #3
  %228 = tail call double @llvm.amdgcn.ldexp.f64(double %211, i32 1) #3
  %229 = fmul double %209, %218
  %230 = fneg double %229
  %231 = tail call double @llvm.fma.f64(double %209, double %218, double %230) #3
  %232 = fmul double %211, %218
  %233 = tail call double @llvm.fma.f64(double %209, double %220, double %232) #3
  %234 = fadd double %231, %233
  %235 = fadd double %229, %234
  %236 = fsub double %235, %229
  %237 = fsub double %234, %236
  %238 = fmul double %235, %226
  %239 = fneg double %238
  %240 = tail call double @llvm.fma.f64(double %235, double %226, double %239) #3
  %241 = tail call double @llvm.fma.f64(double %237, double %226, double %240) #3
  %242 = fadd double %238, %241
  %243 = fsub double %242, %238
  %244 = fsub double %241, %243
  %245 = fadd double %227, %242
  %246 = fsub double %245, %227
  %247 = fsub double %245, %246
  %248 = fsub double %227, %247
  %249 = fsub double %242, %246
  %250 = fadd double %249, %248
  %251 = fadd double %228, %244
  %252 = fsub double %251, %228
  %253 = fsub double %251, %252
  %254 = fsub double %228, %253
  %255 = fsub double %244, %252
  %256 = fadd double %255, %254
  %257 = fadd double %251, %250
  %258 = fadd double %245, %257
  %259 = fsub double %258, %245
  %260 = fsub double %257, %259
  %261 = fadd double %256, %260
  %262 = fadd double %258, %261
  %263 = fsub double %262, %258
  %264 = fsub double %261, %263
  %265 = sitofp i32 %181 to double
  %266 = fmul double %262, 0x3FF71547652B82FE
  %267 = fneg double %266
  %268 = fmul double %262, 0x3C7777D0FFDA0D24
  %269 = insertelement <2 x double> undef, double %262, i32 0
  %270 = insertelement <2 x double> %269, double %264, i32 1
  %271 = insertelement <2 x double> undef, double %267, i32 0
  %272 = insertelement <2 x double> %271, double %268, i32 1
  %273 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %270, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %272) #3
  %274 = extractelement <2 x double> %273, i32 0
  %275 = extractelement <2 x double> %273, i32 1
  %276 = fadd double %274, %275
  %277 = fadd double %266, %276
  %278 = fsub double %277, %266
  %279 = fsub double %276, %278
  %280 = fadd double %277, %265
  %281 = fsub double %280, %265
  %282 = fsub double %281, %280
  %283 = fadd double %282, %265
  %284 = fsub double %277, %281
  %285 = fadd double %284, %283
  %286 = fadd double %279, %285
  %287 = fadd double %280, %286
  %288 = tail call double @llvm.fabs.f64(double %175) #4
  %289 = fcmp oeq double %288, 0x7FF0000000000000
  %290 = select i1 %289, double %175, double %287
  %291 = fcmp olt double %175, 0.000000e+00
  %292 = select i1 %291, double 0x7FF8000000000000, double %290
  %293 = fcmp oeq double %175, 0.000000e+00
  %294 = select i1 %293, double 0xFFF0000000000000, double %292
  %mul.i.i565.i.i.i.i = fmul double %294, %294
  %mul1.i.i566.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3E919A5BE1262808
  %add.i.i567.i.i.i.i = fadd double %mul1.i.i566.i.i.i.i, 0x3F07A5175B4661FC
  %mul5.i.i568.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3ED3058F91E15D9E
  %add7.i.i569.i.i.i.i = fadd double %mul5.i.i568.i.i.i.i, 0x3F360A6A52B6CEE1
  %mul10.i.i570.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i567.i.i.i.i
  %mul12.i.i571.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i569.i.i.i.i
  %add15.i.i572.i.i.i.i = fadd double %mul10.i.i570.i.i.i.i, 0x3F5C5B8FA36BAEC3
  %add18.i.i573.i.i.i.i = fadd double %mul12.i.i571.i.i.i.i, 0x3F80EDCAE3A5BFEE
  %mul20.i.i574.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i572.i.i.i.i
  %mul22.i.i575.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i573.i.i.i.i
  %add25.i.i576.i.i.i.i = fadd double %mul20.i.i574.i.i.i.i, 0x3F9A5E78F653B833
  %add28.i.i577.i.i.i.i = fadd double %mul22.i.i575.i.i.i.i, 0x3FB5AC2080A26513
  %mul30.i.i578.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i576.i.i.i.i
  %mul32.i.i579.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i577.i.i.i.i
  %add35.i.i580.i.i.i.i = fadd double %mul30.i.i578.i.i.i.i, 0x3FC65686F7A4EE22
  %add38.i.i581.i.i.i.i = fadd double %mul32.i.i579.i.i.i.i, 0x3FD3F40EF6582604
  %mul40.i.i582.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i580.i.i.i.i
  %add43.i.i583.i.i.i.i = fadd double %mul40.i.i582.i.i.i.i, 0x3FE03C236600AD0B
  %295 = fmul double %294, %add38.i.i581.i.i.i.i
  %add48.i.i585.i.i.i.i = fsub double %add43.i.i583.i.i.i.i, %295
  %mul1.i.i547.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EA0457562E8B20F
  %add.i.i548.i.i.i.i = fadd double %mul1.i.i547.i.i.i.i, 0x3F16154BBE28AEB9
  %mul5.i.i549.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EE174949F46ED05
  %add7.i.i550.i.i.i.i = fadd double %mul5.i.i549.i.i.i.i, 0x3F43E3B25F7FFBED
  %mul10.i.i551.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i548.i.i.i.i
  %mul12.i.i552.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i550.i.i.i.i
  %add15.i.i553.i.i.i.i = fadd double %mul10.i.i551.i.i.i.i, 0x3F6B2284D418EE28
  %add18.i.i554.i.i.i.i = fadd double %mul12.i.i552.i.i.i.i, 0x3F8DC663E91E38DD
  %mul20.i.i555.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i553.i.i.i.i
  %mul22.i.i556.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i554.i.i.i.i
  %add25.i.i557.i.i.i.i = fadd double %mul20.i.i555.i.i.i.i, 0x3FA9F261B3019817
  %add28.i.i558.i.i.i.i = fadd double %mul22.i.i556.i.i.i.i, 0x3FC29CC24A62017B
  %mul30.i.i559.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i557.i.i.i.i
  %mul32.i.i560.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i558.i.i.i.i
  %add35.i.i561.i.i.i.i = fadd double %mul30.i.i559.i.i.i.i, 0x3FD660DD0F65AD11
  %add38.i.i562.i.i.i.i = fadd double %mul32.i.i560.i.i.i.i, 0x3FE0E738E979F959
  %mul40.i.i563.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i561.i.i.i.i
  %add43.i.i564.i.i.i.i = fadd double %mul40.i.i563.i.i.i.i, 1.000000e+00
  %296 = fmul double %294, %add38.i.i562.i.i.i.i
  %add48.i.i.i.i.i.i = fsub double %add43.i.i564.i.i.i.i, %296
  %mul31.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i469.i.i.i.i = fcmp ogt double %mul31.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i470.i.i.i.i = fcmp oeq double %mul31.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i471.i.i.i.i = or i1 %cmp.i.i.i.i469.i.i.i.i, %cmp.i.i.i470.i.i.i.i
  br i1 %or.cond.i.i.i471.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end.i.i.i473.i.i.i.i

if.end.i.i.i473.i.i.i.i:                          ; preds = %if.then24.i.i.i.i
  %cmp.i.i.i.i.i472.i.i.i.i = fcmp uno double %mul31.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i472.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end7.i.i.i499.i.i.i.i

if.end7.i.i.i499.i.i.i.i:                         ; preds = %if.end.i.i.i473.i.i.i.i
  %297 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul31.i.i.i.i) #3
  %298 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul31.i.i.i.i) #3
  %299 = tail call i1 @llvm.amdgcn.class.f64(double %mul31.i.i.i.i, i32 519) #3
  %300 = select i1 %299, i32 0, i32 %297
  %301 = select i1 %299, double %mul31.i.i.i.i, double %298
  %mul.i.i.i.i.i485.i.i.i.i = fmul double %301, %301
  %mul1.i.i.i.i.i486.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i487.i.i.i.i = fadd double %mul1.i.i.i.i.i486.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i488.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FE479D17050CA47
  %302 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i488.i.i.i.i
  %mul10.i.i.i.i.i490.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %add.i.i.i.i.i487.i.i.i.i
  %mul12.i.i.i.i.i491.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %302
  %add15.i.i.i.i.i492.i.i.i.i = fadd double %mul10.i.i.i.i.i490.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i493.i.i.i.i = fadd double %mul12.i.i.i.i.i491.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i494.i.i.i.i = fmul double %301, %add15.i.i.i.i.i492.i.i.i.i
  %add23.i.i.i.i.i495.i.i.i.i = fadd double %add18.i.i.i.i.i493.i.i.i.i, %mul20.i.i.i.i.i494.i.i.i.i
  %.frozen209 = freeze i32 %300
  %div.i.i.i496.i.i.i.i = sdiv i32 %.frozen209, 3
  %303 = call i32 @llvm.abs.i32(i32 %div.i.i.i496.i.i.i.i, i1 true)
  %cmp11.i.i.i498.i.i.i.i = icmp ult i32 %303, 64
  %304 = sub nsw i32 0, %div.i.i.i496.i.i.i.i
  %305 = icmp sgt i32 %300, 2
  %306 = select i1 %305, i32 %div.i.i.i496.i.i.i.i, i32 %304
  %307 = zext i32 %306 to i64
  %308 = shl nuw i64 1, %307
  %309 = uitofp i64 %308 to double
  %not.cmp11.i.i.i498.i.i.i.i = xor i1 %cmp11.i.i.i498.i.i.i.i, true
  %310 = or i1 %305, %not.cmp11.i.i.i498.i.i.i.i
  br i1 %310, label %merged.bb8, label %merged.bb9

do.body.i.i.i530.i.i.i.i:                         ; preds = %merged.bb10, %do.body.i.i.i530.i.i.i.i
  %guess.i.i.i468.i.i.i.i.1 = phi double [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ], [ %mul24.i.i.i517.i.i.i.i, %merged.bb10 ]
  %mul28.i.i.i520.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %guess.i.i.i468.i.i.i.i.1
  %mul29.i.i.i521.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %mul28.i.i.i520.i.i.i.i
  %add30.i.i.i522.i.i.i.i = fadd double %mul31.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add31.i.i.i523.i.i.i.i = fadd double %mul31.i.i.i.i, %add30.i.i.i522.i.i.i.i
  %add32.i.i.i524.i.i.i.i = fadd double %mul29.i.i.i521.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add33.i.i.i525.i.i.i.i = fadd double %mul31.i.i.i.i, %add32.i.i.i524.i.i.i.i
  %div34.i.i.i526.i.i.i.i = fdiv double %add31.i.i.i523.i.i.i.i, %add33.i.i.i525.i.i.i.i
  %mul35.i.i.i527.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %div34.i.i.i526.i.i.i.i
  %sub36.i.i.i528.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i526.i.i.i.i
  %311 = tail call double @llvm.fabs.f64(double %sub36.i.i.i528.i.i.i.i) #3
  %cmp38.i.i.i529.i.i.i.i = fcmp ogt double %311, 0x3EC0000000000000
  br i1 %cmp38.i.i.i529.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

do.body40.i.i.i541.i.i.i.i:                       ; preds = %merged.bb10, %do.body40.i.i.i541.i.i.i.i
  %guess.i.i.i468.i.i.i.i.2 = phi double [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ], [ %mul24.i.i.i517.i.i.i.i, %merged.bb10 ]
  %mul41.i.i.i531.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, %guess.i.i.i468.i.i.i.i.2
  %div42.i.i.i532.i.i.i.i = fdiv double %mul31.i.i.i.i, %guess.i.i.i468.i.i.i.i.2
  %sub43.i.i.i533.i.i.i.i = fsub double %mul41.i.i.i531.i.i.i.i, %div42.i.i.i532.i.i.i.i
  %mul44.i.i.i534.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i535.i.i.i.i = fdiv double %mul31.i.i.i.i, %mul41.i.i.i531.i.i.i.i
  %add46.i.i.i536.i.i.i.i = fadd double %mul44.i.i.i534.i.i.i.i, %div45.i.i.i535.i.i.i.i
  %div47.i.i.i537.i.i.i.i = fdiv double %sub43.i.i.i533.i.i.i.i, %add46.i.i.i536.i.i.i.i
  %sub48.i.i.i538.i.i.i.i = fsub double %guess.i.i.i468.i.i.i.i.2, %div47.i.i.i537.i.i.i.i
  %mul50.i.i.i539.i.i.i.i = fmul double %sub48.i.i.i538.i.i.i.i, 0x3EC0000000000000
  %312 = tail call double @llvm.fabs.f64(double %div47.i.i.i537.i.i.i.i) #3
  %cmp52.i.i.i540.i.i.i.i = fcmp olt double %mul50.i.i.i539.i.i.i.i, %312
  br i1 %cmp52.i.i.i540.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i: ; preds = %do.body40.i.i.i541.i.i.i.i, %do.body.i.i.i530.i.i.i.i, %if.end.i.i.i473.i.i.i.i, %if.then24.i.i.i.i
  %retval.0.i.i.i544.i.i.i.i = phi double [ %mul31.i.i.i.i, %if.then24.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i473.i.i.i.i ], [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ], [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ]
  %mul33.i.i.i.i = fmul double %add48.i.i.i.i.i.i, %retval.0.i.i.i544.i.i.i.i
  %div34.i.i.i.i = fdiv double %add48.i.i585.i.i.i.i, %mul33.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else35.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %cmp37.i.i.i.i = icmp sgt i32 %36, -17
  br i1 %cmp37.i.i.i.i, label %if.then38.i.i.i.i, label %if.else49.i.i.i.i

if.then38.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %313 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 8) #3
  %314 = tail call double @llvm.amdgcn.frexp.mant.f64(double %313) #3
  %315 = fcmp olt double %314, 0x3FE5555555555555
  %316 = zext i1 %315 to i32
  %317 = tail call double @llvm.amdgcn.ldexp.f64(double %314, i32 %316) #3
  %318 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %313) #3
  %319 = sub nsw i32 %318, %316
  %320 = fadd double %317, -1.000000e+00
  %321 = fadd double %317, 1.000000e+00
  %322 = fsub double %321, %317
  %323 = fsub double %321, %322
  %324 = fsub double %317, %323
  %325 = fsub double 1.000000e+00, %322
  %326 = fadd double %325, %324
  %327 = tail call double @llvm.amdgcn.rcp.f64(double %321) #3
  %328 = fneg double %321
  %329 = tail call double @llvm.fma.f64(double %328, double %327, double 1.000000e+00) #3
  %330 = tail call double @llvm.fma.f64(double %329, double %327, double %327) #3
  %331 = tail call double @llvm.fma.f64(double %328, double %330, double 1.000000e+00) #3
  %332 = tail call double @llvm.fma.f64(double %331, double %330, double %330) #3
  %333 = fmul double %320, %332
  %334 = fmul double %321, %333
  %335 = fneg double %334
  %336 = tail call double @llvm.fma.f64(double %333, double %321, double %335) #3
  %337 = tail call double @llvm.fma.f64(double %333, double %326, double %336) #3
  %338 = fadd double %334, %337
  %339 = fsub double %338, %334
  %340 = fsub double %337, %339
  %341 = fsub double %320, %338
  %342 = fsub double %320, %341
  %343 = fsub double %342, %338
  %344 = fsub double %343, %340
  %345 = fadd double %341, %344
  %346 = fmul double %332, %345
  %347 = fadd double %333, %346
  %348 = fsub double %347, %333
  %349 = fsub double %346, %348
  %350 = fmul double %347, %347
  %351 = fneg double %350
  %352 = tail call double @llvm.fma.f64(double %347, double %347, double %351) #3
  %353 = fmul double %349, 2.000000e+00
  %354 = tail call double @llvm.fma.f64(double %347, double %353, double %352) #3
  %355 = tail call double @llvm.fma.f64(double %349, double %349, double %354) #3
  %356 = fadd double %350, %355
  %357 = fsub double %356, %350
  %358 = fsub double %355, %357
  %359 = tail call double @llvm.fma.f64(double %356, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %360 = tail call double @llvm.fma.f64(double %356, double %359, double 0x3FC7474DD7F4DF2E) #3
  %361 = tail call double @llvm.fma.f64(double %356, double %360, double 0x3FCC71C016291751) #3
  %362 = tail call double @llvm.fma.f64(double %356, double %361, double 0x3FD249249B27ACF1) #3
  %363 = tail call double @llvm.fma.f64(double %356, double %362, double 0x3FD99999998EF7B6) #3
  %364 = tail call double @llvm.fma.f64(double %356, double %363, double 0x3FE5555555555780) #3
  %365 = tail call double @llvm.amdgcn.ldexp.f64(double %347, i32 1) #3
  %366 = tail call double @llvm.amdgcn.ldexp.f64(double %349, i32 1) #3
  %367 = fmul double %347, %356
  %368 = fneg double %367
  %369 = tail call double @llvm.fma.f64(double %347, double %356, double %368) #3
  %370 = fmul double %349, %356
  %371 = tail call double @llvm.fma.f64(double %347, double %358, double %370) #3
  %372 = fadd double %369, %371
  %373 = fadd double %367, %372
  %374 = fsub double %373, %367
  %375 = fsub double %372, %374
  %376 = fmul double %373, %364
  %377 = fneg double %376
  %378 = tail call double @llvm.fma.f64(double %373, double %364, double %377) #3
  %379 = tail call double @llvm.fma.f64(double %375, double %364, double %378) #3
  %380 = fadd double %376, %379
  %381 = fsub double %380, %376
  %382 = fsub double %379, %381
  %383 = fadd double %365, %380
  %384 = fsub double %383, %365
  %385 = fsub double %383, %384
  %386 = fsub double %365, %385
  %387 = fsub double %380, %384
  %388 = fadd double %387, %386
  %389 = fadd double %366, %382
  %390 = fsub double %389, %366
  %391 = fsub double %389, %390
  %392 = fsub double %366, %391
  %393 = fsub double %382, %390
  %394 = fadd double %393, %392
  %395 = fadd double %389, %388
  %396 = fadd double %383, %395
  %397 = fsub double %396, %383
  %398 = fsub double %395, %397
  %399 = fadd double %394, %398
  %400 = fadd double %396, %399
  %401 = fsub double %400, %396
  %402 = fsub double %399, %401
  %403 = sitofp i32 %319 to double
  %404 = fmul double %400, 0x3FF71547652B82FE
  %405 = fneg double %404
  %406 = fmul double %400, 0x3C7777D0FFDA0D24
  %407 = insertelement <2 x double> undef, double %400, i32 0
  %408 = insertelement <2 x double> %407, double %402, i32 1
  %409 = insertelement <2 x double> undef, double %405, i32 0
  %410 = insertelement <2 x double> %409, double %406, i32 1
  %411 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %408, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %410) #3
  %412 = extractelement <2 x double> %411, i32 0
  %413 = extractelement <2 x double> %411, i32 1
  %414 = fadd double %412, %413
  %415 = fadd double %404, %414
  %416 = fsub double %415, %404
  %417 = fsub double %414, %416
  %418 = fadd double %415, %403
  %419 = fsub double %418, %403
  %420 = fsub double %419, %418
  %421 = fadd double %420, %403
  %422 = fsub double %415, %419
  %423 = fadd double %422, %421
  %424 = fadd double %417, %423
  %425 = fadd double %418, %424
  %426 = tail call double @llvm.fabs.f64(double %313) #4
  %427 = fcmp oeq double %426, 0x7FF0000000000000
  %428 = select i1 %427, double %313, double %425
  %429 = fcmp olt double %313, 0.000000e+00
  %430 = select i1 %429, double 0x7FF8000000000000, double %428
  %431 = fcmp oeq double %313, 0.000000e+00
  %432 = select i1 %431, double 0xFFF0000000000000, double %430
  %mul.i.i450.i.i.i.i = fmul double %432, %432
  %mul1.i.i451.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3D1C49F35743D651
  %add.i.i452.i.i.i.i = fadd double %mul1.i.i451.i.i.i.i, 0x3EC5BDF8ABE0C4D2
  %mul5.i.i453.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E74DE722017F09B
  %add7.i.i454.i.i.i.i = fadd double %mul5.i.i453.i.i.i.i, 0x3F08B20867234AE0
  %mul10.i.i455.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i452.i.i.i.i
  %mul12.i.i456.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i454.i.i.i.i
  %add15.i.i457.i.i.i.i = fadd double %mul10.i.i455.i.i.i.i, 0x3F43291C59111954
  %add18.i.i458.i.i.i.i = fadd double %mul12.i.i456.i.i.i.i, 0x3F7555F81DC90AE6
  %mul20.i.i459.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i457.i.i.i.i
  %mul22.i.i460.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i458.i.i.i.i
  %add25.i.i461.i.i.i.i = fadd double %mul20.i.i459.i.i.i.i, 0x3FA118409603E368
  %add28.i.i462.i.i.i.i = fadd double %mul22.i.i460.i.i.i.i, 0x3FC2F812CF93403D
  %mul30.i.i463.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i461.i.i.i.i
  %mul32.i.i.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add28.i.i462.i.i.i.i
  %add35.i.i.i.i.i.i = fadd double %mul30.i.i463.i.i.i.i, 0x3FDA4ECF31EE23E1
  %add38.i.i464.i.i.i.i = fadd double %mul32.i.i.i.i.i.i, 0x3FE15637BD9C1C6C
  %433 = fmul double %432, %add35.i.i.i.i.i.i
  %add43.i.i.i.i.i.i = fsub double %add38.i.i464.i.i.i.i, %433
  %mul1.i.i434.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E834146FFF39045
  %add.i.i435.i.i.i.i = fadd double %mul1.i.i434.i.i.i.i, 0x3F16C942D4A0C545
  %mul5.i.i436.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3ED40F287F6755C5
  %add7.i.i437.i.i.i.i = fadd double %mul5.i.i436.i.i.i.i, 0x3F51AD434F5D94BA
  %mul10.i.i438.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i435.i.i.i.i
  %mul12.i.i439.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i437.i.i.i.i
  %add15.i.i440.i.i.i.i = fadd double %mul10.i.i438.i.i.i.i, 0x3F83AFF5A756295F
  %add18.i.i441.i.i.i.i = fadd double %mul12.i.i439.i.i.i.i, 0x3FAF8A313C5B71D0
  %mul20.i.i442.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i440.i.i.i.i
  %mul22.i.i443.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i441.i.i.i.i
  %add25.i.i444.i.i.i.i = fadd double %mul20.i.i442.i.i.i.i, 0x3FD1813788B6276A
  %add28.i.i445.i.i.i.i = fadd double %mul22.i.i443.i.i.i.i, 0x3FE84455F48DB67F
  %mul30.i.i446.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i444.i.i.i.i
  %add33.i.i447.i.i.i.i = fadd double %mul30.i.i446.i.i.i.i, 1.000000e+00
  %434 = fmul double %432, %add28.i.i445.i.i.i.i
  %add38.i.i449.i.i.i.i = fsub double %add33.i.i447.i.i.i.i, %434
  %mul45.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i356.i.i.i.i = fcmp ogt double %mul45.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i357.i.i.i.i = fcmp oeq double %mul45.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i358.i.i.i.i = or i1 %cmp.i.i.i.i356.i.i.i.i, %cmp.i.i.i357.i.i.i.i
  br i1 %or.cond.i.i.i358.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end.i.i.i360.i.i.i.i

if.end.i.i.i360.i.i.i.i:                          ; preds = %if.then38.i.i.i.i
  %cmp.i.i.i.i.i359.i.i.i.i = fcmp uno double %mul45.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i359.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end7.i.i.i386.i.i.i.i

if.end7.i.i.i386.i.i.i.i:                         ; preds = %if.end.i.i.i360.i.i.i.i
  %435 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul45.i.i.i.i) #3
  %436 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul45.i.i.i.i) #3
  %437 = tail call i1 @llvm.amdgcn.class.f64(double %mul45.i.i.i.i, i32 519) #3
  %438 = select i1 %437, i32 0, i32 %435
  %439 = select i1 %437, double %mul45.i.i.i.i, double %436
  %mul.i.i.i.i.i372.i.i.i.i = fmul double %439, %439
  %mul1.i.i.i.i.i373.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i374.i.i.i.i = fadd double %mul1.i.i.i.i.i373.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i375.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FE479D17050CA47
  %440 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i375.i.i.i.i
  %mul10.i.i.i.i.i377.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %add.i.i.i.i.i374.i.i.i.i
  %mul12.i.i.i.i.i378.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %440
  %add15.i.i.i.i.i379.i.i.i.i = fadd double %mul10.i.i.i.i.i377.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i380.i.i.i.i = fadd double %mul12.i.i.i.i.i378.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i381.i.i.i.i = fmul double %439, %add15.i.i.i.i.i379.i.i.i.i
  %add23.i.i.i.i.i382.i.i.i.i = fadd double %add18.i.i.i.i.i380.i.i.i.i, %mul20.i.i.i.i.i381.i.i.i.i
  %.frozen210 = freeze i32 %438
  %div.i.i.i383.i.i.i.i = sdiv i32 %.frozen210, 3
  %441 = call i32 @llvm.abs.i32(i32 %div.i.i.i383.i.i.i.i, i1 true)
  %cmp11.i.i.i385.i.i.i.i = icmp ult i32 %441, 64
  %442 = sub nsw i32 0, %div.i.i.i383.i.i.i.i
  %443 = icmp sgt i32 %438, 2
  %444 = select i1 %443, i32 %div.i.i.i383.i.i.i.i, i32 %442
  %445 = zext i32 %444 to i64
  %446 = shl nuw i64 1, %445
  %447 = uitofp i64 %446 to double
  %not.cmp11.i.i.i385.i.i.i.i = xor i1 %cmp11.i.i.i385.i.i.i.i, true
  %448 = or i1 %443, %not.cmp11.i.i.i385.i.i.i.i
  br i1 %448, label %merged.bb11, label %merged.bb12

do.body.i.i.i417.i.i.i.i:                         ; preds = %merged.bb13, %do.body.i.i.i417.i.i.i.i
  %guess.i.i.i355.i.i.i.i.1 = phi double [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ], [ %mul24.i.i.i404.i.i.i.i, %merged.bb13 ]
  %mul28.i.i.i407.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %guess.i.i.i355.i.i.i.i.1
  %mul29.i.i.i408.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %mul28.i.i.i407.i.i.i.i
  %add30.i.i.i409.i.i.i.i = fadd double %mul45.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add31.i.i.i410.i.i.i.i = fadd double %mul45.i.i.i.i, %add30.i.i.i409.i.i.i.i
  %add32.i.i.i411.i.i.i.i = fadd double %mul29.i.i.i408.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add33.i.i.i412.i.i.i.i = fadd double %mul45.i.i.i.i, %add32.i.i.i411.i.i.i.i
  %div34.i.i.i413.i.i.i.i = fdiv double %add31.i.i.i410.i.i.i.i, %add33.i.i.i412.i.i.i.i
  %mul35.i.i.i414.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %div34.i.i.i413.i.i.i.i
  %sub36.i.i.i415.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i413.i.i.i.i
  %449 = tail call double @llvm.fabs.f64(double %sub36.i.i.i415.i.i.i.i) #3
  %cmp38.i.i.i416.i.i.i.i = fcmp ogt double %449, 0x3EC0000000000000
  br i1 %cmp38.i.i.i416.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

do.body40.i.i.i428.i.i.i.i:                       ; preds = %merged.bb13, %do.body40.i.i.i428.i.i.i.i
  %guess.i.i.i355.i.i.i.i.2 = phi double [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ], [ %mul24.i.i.i404.i.i.i.i, %merged.bb13 ]
  %mul41.i.i.i418.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, %guess.i.i.i355.i.i.i.i.2
  %div42.i.i.i419.i.i.i.i = fdiv double %mul45.i.i.i.i, %guess.i.i.i355.i.i.i.i.2
  %sub43.i.i.i420.i.i.i.i = fsub double %mul41.i.i.i418.i.i.i.i, %div42.i.i.i419.i.i.i.i
  %mul44.i.i.i421.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i422.i.i.i.i = fdiv double %mul45.i.i.i.i, %mul41.i.i.i418.i.i.i.i
  %add46.i.i.i423.i.i.i.i = fadd double %mul44.i.i.i421.i.i.i.i, %div45.i.i.i422.i.i.i.i
  %div47.i.i.i424.i.i.i.i = fdiv double %sub43.i.i.i420.i.i.i.i, %add46.i.i.i423.i.i.i.i
  %sub48.i.i.i425.i.i.i.i = fsub double %guess.i.i.i355.i.i.i.i.2, %div47.i.i.i424.i.i.i.i
  %mul50.i.i.i426.i.i.i.i = fmul double %sub48.i.i.i425.i.i.i.i, 0x3EC0000000000000
  %450 = tail call double @llvm.fabs.f64(double %div47.i.i.i424.i.i.i.i) #3
  %cmp52.i.i.i427.i.i.i.i = fcmp olt double %mul50.i.i.i426.i.i.i.i, %450
  br i1 %cmp52.i.i.i427.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i: ; preds = %do.body40.i.i.i428.i.i.i.i, %do.body.i.i.i417.i.i.i.i, %if.end.i.i.i360.i.i.i.i, %if.then38.i.i.i.i
  %retval.0.i.i.i431.i.i.i.i = phi double [ %mul45.i.i.i.i, %if.then38.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i360.i.i.i.i ], [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ], [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ]
  %mul47.i.i.i.i = fmul double %add38.i.i449.i.i.i.i, %retval.0.i.i.i431.i.i.i.i
  %div48.i.i.i.i = fdiv double %add43.i.i.i.i.i.i, %mul47.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else49.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %cmp51.i.i.i.i = icmp sgt i32 %36, -33
  br i1 %cmp51.i.i.i.i, label %if.then52.i.i.i.i, label %if.else63.i.i.i.i

if.then52.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %451 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 16) #3
  %452 = tail call double @llvm.amdgcn.frexp.mant.f64(double %451) #3
  %453 = fcmp olt double %452, 0x3FE5555555555555
  %454 = zext i1 %453 to i32
  %455 = tail call double @llvm.amdgcn.ldexp.f64(double %452, i32 %454) #3
  %456 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %451) #3
  %457 = sub nsw i32 %456, %454
  %458 = fadd double %455, -1.000000e+00
  %459 = fadd double %455, 1.000000e+00
  %460 = fsub double %459, %455
  %461 = fsub double %459, %460
  %462 = fsub double %455, %461
  %463 = fsub double 1.000000e+00, %460
  %464 = fadd double %463, %462
  %465 = tail call double @llvm.amdgcn.rcp.f64(double %459) #3
  %466 = fneg double %459
  %467 = tail call double @llvm.fma.f64(double %466, double %465, double 1.000000e+00) #3
  %468 = tail call double @llvm.fma.f64(double %467, double %465, double %465) #3
  %469 = tail call double @llvm.fma.f64(double %466, double %468, double 1.000000e+00) #3
  %470 = tail call double @llvm.fma.f64(double %469, double %468, double %468) #3
  %471 = fmul double %458, %470
  %472 = fmul double %459, %471
  %473 = fneg double %472
  %474 = tail call double @llvm.fma.f64(double %471, double %459, double %473) #3
  %475 = tail call double @llvm.fma.f64(double %471, double %464, double %474) #3
  %476 = fadd double %472, %475
  %477 = fsub double %476, %472
  %478 = fsub double %475, %477
  %479 = fsub double %458, %476
  %480 = fsub double %458, %479
  %481 = fsub double %480, %476
  %482 = fsub double %481, %478
  %483 = fadd double %479, %482
  %484 = fmul double %470, %483
  %485 = fadd double %471, %484
  %486 = fsub double %485, %471
  %487 = fsub double %484, %486
  %488 = fmul double %485, %485
  %489 = fneg double %488
  %490 = tail call double @llvm.fma.f64(double %485, double %485, double %489) #3
  %491 = fmul double %487, 2.000000e+00
  %492 = tail call double @llvm.fma.f64(double %485, double %491, double %490) #3
  %493 = tail call double @llvm.fma.f64(double %487, double %487, double %492) #3
  %494 = fadd double %488, %493
  %495 = fsub double %494, %488
  %496 = fsub double %493, %495
  %497 = tail call double @llvm.fma.f64(double %494, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %498 = tail call double @llvm.fma.f64(double %494, double %497, double 0x3FC7474DD7F4DF2E) #3
  %499 = tail call double @llvm.fma.f64(double %494, double %498, double 0x3FCC71C016291751) #3
  %500 = tail call double @llvm.fma.f64(double %494, double %499, double 0x3FD249249B27ACF1) #3
  %501 = tail call double @llvm.fma.f64(double %494, double %500, double 0x3FD99999998EF7B6) #3
  %502 = tail call double @llvm.fma.f64(double %494, double %501, double 0x3FE5555555555780) #3
  %503 = tail call double @llvm.amdgcn.ldexp.f64(double %485, i32 1) #3
  %504 = tail call double @llvm.amdgcn.ldexp.f64(double %487, i32 1) #3
  %505 = fmul double %485, %494
  %506 = fneg double %505
  %507 = tail call double @llvm.fma.f64(double %485, double %494, double %506) #3
  %508 = fmul double %487, %494
  %509 = tail call double @llvm.fma.f64(double %485, double %496, double %508) #3
  %510 = fadd double %507, %509
  %511 = fadd double %505, %510
  %512 = fsub double %511, %505
  %513 = fsub double %510, %512
  %514 = fmul double %511, %502
  %515 = fneg double %514
  %516 = tail call double @llvm.fma.f64(double %511, double %502, double %515) #3
  %517 = tail call double @llvm.fma.f64(double %513, double %502, double %516) #3
  %518 = fadd double %514, %517
  %519 = fsub double %518, %514
  %520 = fsub double %517, %519
  %521 = fadd double %503, %518
  %522 = fsub double %521, %503
  %523 = fsub double %521, %522
  %524 = fsub double %503, %523
  %525 = fsub double %518, %522
  %526 = fadd double %525, %524
  %527 = fadd double %504, %520
  %528 = fsub double %527, %504
  %529 = fsub double %527, %528
  %530 = fsub double %504, %529
  %531 = fsub double %520, %528
  %532 = fadd double %531, %530
  %533 = fadd double %527, %526
  %534 = fadd double %521, %533
  %535 = fsub double %534, %521
  %536 = fsub double %533, %535
  %537 = fadd double %532, %536
  %538 = fadd double %534, %537
  %539 = fsub double %538, %534
  %540 = fsub double %537, %539
  %541 = sitofp i32 %457 to double
  %542 = fmul double %538, 0x3FF71547652B82FE
  %543 = fneg double %542
  %544 = fmul double %538, 0x3C7777D0FFDA0D24
  %545 = insertelement <2 x double> undef, double %538, i32 0
  %546 = insertelement <2 x double> %545, double %540, i32 1
  %547 = insertelement <2 x double> undef, double %543, i32 0
  %548 = insertelement <2 x double> %547, double %544, i32 1
  %549 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %546, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %548) #3
  %550 = extractelement <2 x double> %549, i32 0
  %551 = extractelement <2 x double> %549, i32 1
  %552 = fadd double %550, %551
  %553 = fadd double %542, %552
  %554 = fsub double %553, %542
  %555 = fsub double %552, %554
  %556 = fadd double %553, %541
  %557 = fsub double %556, %541
  %558 = fsub double %557, %556
  %559 = fadd double %558, %541
  %560 = fsub double %553, %557
  %561 = fadd double %560, %559
  %562 = fadd double %555, %561
  %563 = fadd double %556, %562
  %564 = tail call double @llvm.fabs.f64(double %451) #4
  %565 = fcmp oeq double %564, 0x7FF0000000000000
  %566 = select i1 %565, double %451, double %563
  %567 = fcmp olt double %451, 0.000000e+00
  %568 = select i1 %567, double 0x7FF8000000000000, double %566
  %569 = fcmp oeq double %451, 0.000000e+00
  %570 = select i1 %569, double 0xFFF0000000000000, double %568
  %mul.i.i335.i.i.i.i = fmul double %570, %570
  %mul1.i.i336.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EBF7344DBF5E403
  %add.i.i337.i.i.i.i = fadd double %mul1.i.i336.i.i.i.i, 0x3F2CFF1E2D54E4E7
  %mul5.i.i338.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EEF8CF23CAED047
  %add7.i.i339.i.i.i.i = fadd double %mul5.i.i338.i.i.i.i, 0x3F5CF8F0FF9B6F59
  %mul10.i.i340.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i337.i.i.i.i
  %mul12.i.i341.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i339.i.i.i.i
  %add15.i.i342.i.i.i.i = fadd double %mul10.i.i340.i.i.i.i, 0x3F8857AD74D33625
  %add18.i.i343.i.i.i.i = fadd double %mul12.i.i341.i.i.i.i, 0x3FAE52179C3AEDE6
  %mul20.i.i344.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i342.i.i.i.i
  %mul22.i.i345.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i343.i.i.i.i
  %add25.i.i346.i.i.i.i = fadd double %mul20.i.i344.i.i.i.i, 0x3FCB21A22303D8FC
  %add28.i.i347.i.i.i.i = fadd double %mul22.i.i345.i.i.i.i, 0x3FDF29CE00A8804B
  %mul30.i.i348.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i346.i.i.i.i
  %add33.i.i349.i.i.i.i = fadd double %mul30.i.i348.i.i.i.i, 0x3FE15775564555E5
  %571 = fmul double %570, %add28.i.i347.i.i.i.i
  %add38.i.i351.i.i.i.i = fsub double %add33.i.i349.i.i.i.i, %571
  %mul1.i.i321.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3ECD04621671DBCE
  %add.i.i322.i.i.i.i = fadd double %mul1.i.i321.i.i.i.i, 0x3F3AC0D433DC2A4E
  %mul5.i.i323.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EFD1C12EAA62BE9
  %add7.i.i324.i.i.i.i = fadd double %mul5.i.i323.i.i.i.i, 0x3F6ABB215A001E96
  %mul10.i.i325.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i322.i.i.i.i
  %mul12.i.i326.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i324.i.i.i.i
  %add15.i.i327.i.i.i.i = fadd double %mul10.i.i325.i.i.i.i, 0x3F967590758A1B1A
  %add18.i.i328.i.i.i.i = fadd double %mul12.i.i326.i.i.i.i, 0x3FBBF9941AE7DFDE
  %mul20.i.i329.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i327.i.i.i.i
  %mul22.i.i330.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i328.i.i.i.i
  %add25.i.i331.i.i.i.i = fadd double %mul20.i.i329.i.i.i.i, 0x3FD90848F242167F
  %add28.i.i332.i.i.i.i = fadd double %mul22.i.i330.i.i.i.i, 0x3FECC09A37BCEE76
  %mul30.i.i333.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i331.i.i.i.i
  %add33.i.i334.i.i.i.i = fadd double %mul30.i.i333.i.i.i.i, 1.000000e+00
  %572 = fmul double %570, %add28.i.i332.i.i.i.i
  %add38.i.i.i.i.i.i = fsub double %add33.i.i334.i.i.i.i, %572
  %mul59.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i243.i.i.i.i = fcmp ogt double %mul59.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i244.i.i.i.i = fcmp oeq double %mul59.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i245.i.i.i.i = or i1 %cmp.i.i.i.i243.i.i.i.i, %cmp.i.i.i244.i.i.i.i
  br i1 %or.cond.i.i.i245.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end.i.i.i247.i.i.i.i

if.end.i.i.i247.i.i.i.i:                          ; preds = %if.then52.i.i.i.i
  %cmp.i.i.i.i.i246.i.i.i.i = fcmp uno double %mul59.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i246.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end7.i.i.i273.i.i.i.i

if.end7.i.i.i273.i.i.i.i:                         ; preds = %if.end.i.i.i247.i.i.i.i
  %573 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul59.i.i.i.i) #3
  %574 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul59.i.i.i.i) #3
  %575 = tail call i1 @llvm.amdgcn.class.f64(double %mul59.i.i.i.i, i32 519) #3
  %576 = select i1 %575, i32 0, i32 %573
  %577 = select i1 %575, double %mul59.i.i.i.i, double %574
  %mul.i.i.i.i.i259.i.i.i.i = fmul double %577, %577
  %mul1.i.i.i.i.i260.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i261.i.i.i.i = fadd double %mul1.i.i.i.i.i260.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i262.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FE479D17050CA47
  %578 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i262.i.i.i.i
  %mul10.i.i.i.i.i264.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %add.i.i.i.i.i261.i.i.i.i
  %mul12.i.i.i.i.i265.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %578
  %add15.i.i.i.i.i266.i.i.i.i = fadd double %mul10.i.i.i.i.i264.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i267.i.i.i.i = fadd double %mul12.i.i.i.i.i265.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i268.i.i.i.i = fmul double %577, %add15.i.i.i.i.i266.i.i.i.i
  %add23.i.i.i.i.i269.i.i.i.i = fadd double %add18.i.i.i.i.i267.i.i.i.i, %mul20.i.i.i.i.i268.i.i.i.i
  %.frozen211 = freeze i32 %576
  %div.i.i.i270.i.i.i.i = sdiv i32 %.frozen211, 3
  %579 = call i32 @llvm.abs.i32(i32 %div.i.i.i270.i.i.i.i, i1 true)
  %cmp11.i.i.i272.i.i.i.i = icmp ult i32 %579, 64
  %580 = sub nsw i32 0, %div.i.i.i270.i.i.i.i
  %581 = icmp sgt i32 %576, 2
  %582 = select i1 %581, i32 %div.i.i.i270.i.i.i.i, i32 %580
  %583 = zext i32 %582 to i64
  %584 = shl nuw i64 1, %583
  %585 = uitofp i64 %584 to double
  %not.cmp11.i.i.i272.i.i.i.i = xor i1 %cmp11.i.i.i272.i.i.i.i, true
  %586 = or i1 %581, %not.cmp11.i.i.i272.i.i.i.i
  br i1 %586, label %merged.bb14, label %merged.bb15

do.body.i.i.i304.i.i.i.i:                         ; preds = %merged.bb16, %do.body.i.i.i304.i.i.i.i
  %guess.i.i.i242.i.i.i.i.1 = phi double [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ], [ %mul24.i.i.i291.i.i.i.i, %merged.bb16 ]
  %mul28.i.i.i294.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %guess.i.i.i242.i.i.i.i.1
  %mul29.i.i.i295.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %mul28.i.i.i294.i.i.i.i
  %add30.i.i.i296.i.i.i.i = fadd double %mul59.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add31.i.i.i297.i.i.i.i = fadd double %mul59.i.i.i.i, %add30.i.i.i296.i.i.i.i
  %add32.i.i.i298.i.i.i.i = fadd double %mul29.i.i.i295.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add33.i.i.i299.i.i.i.i = fadd double %mul59.i.i.i.i, %add32.i.i.i298.i.i.i.i
  %div34.i.i.i300.i.i.i.i = fdiv double %add31.i.i.i297.i.i.i.i, %add33.i.i.i299.i.i.i.i
  %mul35.i.i.i301.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %div34.i.i.i300.i.i.i.i
  %sub36.i.i.i302.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i300.i.i.i.i
  %587 = tail call double @llvm.fabs.f64(double %sub36.i.i.i302.i.i.i.i) #3
  %cmp38.i.i.i303.i.i.i.i = fcmp ogt double %587, 0x3EC0000000000000
  br i1 %cmp38.i.i.i303.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

do.body40.i.i.i315.i.i.i.i:                       ; preds = %merged.bb16, %do.body40.i.i.i315.i.i.i.i
  %guess.i.i.i242.i.i.i.i.2 = phi double [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ], [ %mul24.i.i.i291.i.i.i.i, %merged.bb16 ]
  %mul41.i.i.i305.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, %guess.i.i.i242.i.i.i.i.2
  %div42.i.i.i306.i.i.i.i = fdiv double %mul59.i.i.i.i, %guess.i.i.i242.i.i.i.i.2
  %sub43.i.i.i307.i.i.i.i = fsub double %mul41.i.i.i305.i.i.i.i, %div42.i.i.i306.i.i.i.i
  %mul44.i.i.i308.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i309.i.i.i.i = fdiv double %mul59.i.i.i.i, %mul41.i.i.i305.i.i.i.i
  %add46.i.i.i310.i.i.i.i = fadd double %mul44.i.i.i308.i.i.i.i, %div45.i.i.i309.i.i.i.i
  %div47.i.i.i311.i.i.i.i = fdiv double %sub43.i.i.i307.i.i.i.i, %add46.i.i.i310.i.i.i.i
  %sub48.i.i.i312.i.i.i.i = fsub double %guess.i.i.i242.i.i.i.i.2, %div47.i.i.i311.i.i.i.i
  %mul50.i.i.i313.i.i.i.i = fmul double %sub48.i.i.i312.i.i.i.i, 0x3EC0000000000000
  %588 = tail call double @llvm.fabs.f64(double %div47.i.i.i311.i.i.i.i) #3
  %cmp52.i.i.i314.i.i.i.i = fcmp olt double %mul50.i.i.i313.i.i.i.i, %588
  br i1 %cmp52.i.i.i314.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i: ; preds = %do.body40.i.i.i315.i.i.i.i, %do.body.i.i.i304.i.i.i.i, %if.end.i.i.i247.i.i.i.i, %if.then52.i.i.i.i
  %retval.0.i.i.i318.i.i.i.i = phi double [ %mul59.i.i.i.i, %if.then52.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i247.i.i.i.i ], [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ], [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ]
  %mul61.i.i.i.i = fmul double %add38.i.i.i.i.i.i, %retval.0.i.i.i318.i.i.i.i
  %div62.i.i.i.i = fdiv double %add38.i.i351.i.i.i.i, %mul61.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else63.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %mul64.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp1.i.i.i.i.i = fcmp oge double %mul64.i.i.i.i, 0x10000000000000
  %cmp2.i.i.i.i.i = fcmp ole double %mul64.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %589 = and i1 %cmp1.i.i.i.i.i, %cmp2.i.i.i.i.i
  br i1 %589, label %if.then66.i.i.i.i, label %if.else71.i.i.i.i

if.then66.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %mul68.i.i.i.i = fmul double %mul64.i.i.i.i, 0x401921FB54442D18
  %cmp.i.i.i.i162.i.i.i.i = fcmp ogt double %mul68.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i163.i.i.i.i = fcmp oeq double %mul68.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i164.i.i.i.i = or i1 %cmp.i.i.i.i162.i.i.i.i, %cmp.i.i.i163.i.i.i.i
  br i1 %or.cond.i.i.i164.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end.i.i.i166.i.i.i.i

if.end.i.i.i166.i.i.i.i:                          ; preds = %if.then66.i.i.i.i
  %cmp.i.i.i.i.i165.i.i.i.i = fcmp uno double %mul68.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i165.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end7.i.i.i192.i.i.i.i

if.end7.i.i.i192.i.i.i.i:                         ; preds = %if.end.i.i.i166.i.i.i.i
  %590 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul68.i.i.i.i) #3
  %591 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul68.i.i.i.i) #3
  %592 = tail call i1 @llvm.amdgcn.class.f64(double %mul68.i.i.i.i, i32 519) #3
  %593 = select i1 %592, i32 0, i32 %590
  %594 = select i1 %592, double %mul68.i.i.i.i, double %591
  %mul.i.i.i.i.i178.i.i.i.i = fmul double %594, %594
  %mul1.i.i.i.i.i179.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i180.i.i.i.i = fadd double %mul1.i.i.i.i.i179.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i181.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FE479D17050CA47
  %595 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i181.i.i.i.i
  %mul10.i.i.i.i.i183.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %add.i.i.i.i.i180.i.i.i.i
  %mul12.i.i.i.i.i184.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %595
  %add15.i.i.i.i.i185.i.i.i.i = fadd double %mul10.i.i.i.i.i183.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i186.i.i.i.i = fadd double %mul12.i.i.i.i.i184.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i187.i.i.i.i = fmul double %594, %add15.i.i.i.i.i185.i.i.i.i
  %add23.i.i.i.i.i188.i.i.i.i = fadd double %add18.i.i.i.i.i186.i.i.i.i, %mul20.i.i.i.i.i187.i.i.i.i
  %.frozen212 = freeze i32 %593
  %div.i.i.i189.i.i.i.i = sdiv i32 %.frozen212, 3
  %596 = call i32 @llvm.abs.i32(i32 %div.i.i.i189.i.i.i.i, i1 true)
  %cmp11.i.i.i191.i.i.i.i = icmp ult i32 %596, 64
  %597 = sub nsw i32 0, %div.i.i.i189.i.i.i.i
  %598 = icmp sgt i32 %593, 2
  %599 = select i1 %598, i32 %div.i.i.i189.i.i.i.i, i32 %597
  %600 = zext i32 %599 to i64
  %601 = shl nuw i64 1, %600
  %602 = uitofp i64 %601 to double
  %not.cmp11.i.i.i191.i.i.i.i = xor i1 %cmp11.i.i.i191.i.i.i.i, true
  %603 = or i1 %598, %not.cmp11.i.i.i191.i.i.i.i
  br i1 %603, label %merged.bb17, label %merged.bb18

do.body.i.i.i223.i.i.i.i:                         ; preds = %merged.bb19, %do.body.i.i.i223.i.i.i.i
  %guess.i.i.i161.i.i.i.i.1 = phi double [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ], [ %mul24.i.i.i210.i.i.i.i, %merged.bb19 ]
  %mul28.i.i.i213.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %guess.i.i.i161.i.i.i.i.1
  %mul29.i.i.i214.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %mul28.i.i.i213.i.i.i.i
  %add30.i.i.i215.i.i.i.i = fadd double %mul68.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add31.i.i.i216.i.i.i.i = fadd double %mul68.i.i.i.i, %add30.i.i.i215.i.i.i.i
  %add32.i.i.i217.i.i.i.i = fadd double %mul29.i.i.i214.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add33.i.i.i218.i.i.i.i = fadd double %mul68.i.i.i.i, %add32.i.i.i217.i.i.i.i
  %div34.i.i.i219.i.i.i.i = fdiv double %add31.i.i.i216.i.i.i.i, %add33.i.i.i218.i.i.i.i
  %mul35.i.i.i220.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %div34.i.i.i219.i.i.i.i
  %sub36.i.i.i221.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i219.i.i.i.i
  %604 = tail call double @llvm.fabs.f64(double %sub36.i.i.i221.i.i.i.i) #3
  %cmp38.i.i.i222.i.i.i.i = fcmp ogt double %604, 0x3EC0000000000000
  br i1 %cmp38.i.i.i222.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

do.body40.i.i.i234.i.i.i.i:                       ; preds = %merged.bb19, %do.body40.i.i.i234.i.i.i.i
  %guess.i.i.i161.i.i.i.i.2 = phi double [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ], [ %mul24.i.i.i210.i.i.i.i, %merged.bb19 ]
  %mul41.i.i.i224.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, %guess.i.i.i161.i.i.i.i.2
  %div42.i.i.i225.i.i.i.i = fdiv double %mul68.i.i.i.i, %guess.i.i.i161.i.i.i.i.2
  %sub43.i.i.i226.i.i.i.i = fsub double %mul41.i.i.i224.i.i.i.i, %div42.i.i.i225.i.i.i.i
  %mul44.i.i.i227.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i228.i.i.i.i = fdiv double %mul68.i.i.i.i, %mul41.i.i.i224.i.i.i.i
  %add46.i.i.i229.i.i.i.i = fadd double %mul44.i.i.i227.i.i.i.i, %div45.i.i.i228.i.i.i.i
  %div47.i.i.i230.i.i.i.i = fdiv double %sub43.i.i.i226.i.i.i.i, %add46.i.i.i229.i.i.i.i
  %sub48.i.i.i231.i.i.i.i = fsub double %guess.i.i.i161.i.i.i.i.2, %div47.i.i.i230.i.i.i.i
  %mul50.i.i.i232.i.i.i.i = fmul double %sub48.i.i.i231.i.i.i.i, 0x3EC0000000000000
  %605 = tail call double @llvm.fabs.f64(double %div47.i.i.i230.i.i.i.i) #3
  %cmp52.i.i.i233.i.i.i.i = fcmp olt double %mul50.i.i.i232.i.i.i.i, %605
  br i1 %cmp52.i.i.i233.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i: ; preds = %do.body40.i.i.i234.i.i.i.i, %do.body.i.i.i223.i.i.i.i, %if.end.i.i.i166.i.i.i.i, %if.then66.i.i.i.i
  %retval.0.i.i.i237.i.i.i.i = phi double [ %mul68.i.i.i.i, %if.then66.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i166.i.i.i.i ], [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ], [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ]
  %div70.i.i.i.i = fdiv double 1.000000e+00, %retval.0.i.i.i237.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else71.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %cmp72.i.i.i.i = fcmp ogt double %sub.i.i.i, 0.000000e+00
  br i1 %cmp72.i.i.i.i, label %if.then73.i.i.i.i, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.then73.i.i.i.i:                                ; preds = %if.else71.i.i.i.i
  %cmp.i.i.i.i79.i.i.i.i = fcmp ogt double %sub.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i.i80.i.i.i.i = fcmp olt double %sub.i.i.i, 0xFFEFFFFFFFFFFFFF
  %606 = or i1 %cmp.i.i.i.i79.i.i.i.i, %cmp1.i.i.i.i80.i.i.i.i
  %or.cond.i.i.i82.i.i.i.i = or i1 %35, %606
  %brmerge170 = or i1 %30, %or.cond.i.i.i82.i.i.i.i
  %sub.i.i.i.mux = select i1 %or.cond.i.i.i82.i.i.i.i, double %sub.i.i.i, double 0x7FF8000000000000
  br i1 %brmerge170, label %if.end7.i.i.i.i.i.i.i, label %if.end4.i.i.i92.i.i.i.i

if.end4.i.i.i92.i.i.i.i:                          ; preds = %if.then73.i.i.i.i
  %cmp5.i.i.i91.i.i.i.i = fcmp olt double %sub.i.i.i, 0.000000e+00
  %fneg.i.i.i93.i.i.i.i = fneg double %sub.i.i.i
  %z.addr.i.i.i76.i.i.i.i.0 = select i1 %cmp5.i.i.i91.i.i.i.i, double %fneg.i.i.i93.i.i.i.i, double %sub.i.i.i
  %607 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %608 = tail call double @llvm.amdgcn.frexp.mant.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %609 = tail call i1 @llvm.amdgcn.class.f64(double %z.addr.i.i.i76.i.i.i.i.0, i32 519) #3
  %610 = select i1 %609, i32 0, i32 %607
  %611 = select i1 %609, double %z.addr.i.i.i76.i.i.i.i.0, double %608
  %mul.i.i.i.i.i97.i.i.i.i = fmul double %611, %611
  %mul1.i.i.i.i.i98.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i99.i.i.i.i = fadd double %mul1.i.i.i.i.i98.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i100.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FE479D17050CA47
  %612 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i100.i.i.i.i
  %mul10.i.i.i.i.i102.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %add.i.i.i.i.i99.i.i.i.i
  %mul12.i.i.i.i.i103.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %612
  %add15.i.i.i.i.i104.i.i.i.i = fadd double %mul10.i.i.i.i.i102.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i105.i.i.i.i = fadd double %mul12.i.i.i.i.i103.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i106.i.i.i.i = fmul double %611, %add15.i.i.i.i.i104.i.i.i.i
  %add23.i.i.i.i.i107.i.i.i.i = fadd double %add18.i.i.i.i.i105.i.i.i.i, %mul20.i.i.i.i.i106.i.i.i.i
  %.frozen213 = freeze i32 %610
  %div.i.i.i108.i.i.i.i = sdiv i32 %.frozen213, 3
  %613 = sub nsw i32 0, %div.i.i.i108.i.i.i.i
  %614 = call i32 @llvm.abs.i32(i32 %div.i.i.i108.i.i.i.i, i1 true)
  %cmp11.i.i.i110.i.i.i.i = icmp ult i32 %614, 64
  %615 = icmp sgt i32 %610, 2
  %616 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  %guard.value6 = select i1 %cmp11.i.i.i110.i.i.i.i, double undef, double %616
  br i1 %cmp11.i.i.i110.i.i.i.i, label %merged.bb, label %if.end23.i.i.i131.i.i.i.i

if.end23.i.i.i131.i.i.i.i:                        ; preds = %predication.second4, %predication.first3, %if.end4.i.i.i92.i.i.i.i
  %guess.i.i.i78.i.i.i.i.0 = phi double [ %guard.value6, %if.end4.i.i.i92.i.i.i.i ], [ %1001, %predication.first3 ], [ %1002, %predication.second4 ]
  %.neg = mul nsw i32 %div.i.i.i108.i.i.i.i, -3
  %rem.i.i.i126.i.i.i.i.decomposed = add i32 %.frozen213, 2
  %add.i.i.i127.i.i.i.i = add i32 %rem.i.i.i126.i.i.i.i.decomposed, %.neg
  %617 = zext i32 %add.i.i.i127.i.i.i.i to i64
  %arrayidx1.i.i.i128.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %617
  %618 = load double, double addrspace(4)* %arrayidx1.i.i.i128.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i129.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.0, %618
  %cmp26.i.i.i130.i.i.i.i = icmp slt i32 %610, 1021
  br label %merged.bb20

if.end23.i.i.i50.i.i.i.i:                         ; preds = %merged.bb21, %predication.second5, %predication.first4
  %guess.i.i.i10.i.i.i.i.0 = phi double [ %1006, %predication.first4 ], [ %1007, %predication.second5 ], [ %616, %merged.bb21 ]
  %mul24.i.i.i48.i.i.i.i = fmul double %618, %guess.i.i.i10.i.i.i.i.0
  br label %merged.bb22

if.end7.i.i.i.i.i.i.i:                            ; preds = %merged.bb23, %if.then73.i.i.i.i
  %retval.0.i.i.i156.i.i.i.i162 = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %1029, %merged.bb23 ]
  %retval.0.i.i.i.i.i.i.i = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %1051, %merged.bb23 ]
  %mul76.i.i.i.i = fmul double %retval.0.i.i.i156.i.i.i.i162, %retval.0.i.i.i.i.i.i.i
  %mul79.i.i.i.i = fmul double %mul76.i.i.i.i, 0x3FFD8639FDCB60EB
  %div80.i.i.i.i = fdiv double 1.000000e+00, %mul79.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

cond.false7.i.i.i:                                ; preds = %if.end14.i.i
  %decision.interval4 = fcmp ult double %arrayidx.val, 1.250000e-01
  br i1 %decision.interval4, label %if.else17.i.i.i.i, label %decision.dispatch3, !decision.condition_prefix !6

decision.dispatch3:                               ; preds = %cond.false7.i.i.i
  %decision.interval = fcmp oge double %arrayidx.val, 2.500000e-01
  br i1 %decision.interval, label %predication.split83, label %predication.tail84

if.else17.i.i.i.i:                                ; preds = %cond.false7.i.i.i
  %619 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %arrayidx.val) #3
  %620 = add nsw i32 %619, -1
  %621 = tail call double @llvm.fabs.f64(double %arrayidx.val) #4
  %622 = fcmp oeq double %621, 0x7FF0000000000000
  %623 = select i1 %622, i32 2147483647, i32 %620
  %624 = fcmp oeq double %arrayidx.val, 0.000000e+00
  %625 = select i1 %624, i32 -2147483648, i32 %623
  %cmp106.i.i.i.i = icmp sgt i32 %625, -1025
  br i1 %cmp106.i.i.i.i, label %decision.dispatch1, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, !decision.condition_prefix !6

decision.dispatch1:                               ; preds = %if.else17.i.i.i.i
  %cmp19.i.i.i.i = icmp sgt i32 %625, -5
  br i1 %cmp19.i.i.i.i, label %predication.tail, label %predication.split

_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i: ; preds = %predication.tail84, %predication.tail64, %predication.tail85, %if.else17.i.i.i.i, %if.end7.i.i.i.i.i.i.i, %if.else71.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i
  %retval.0.i.i.i = phi double [ %div20.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i ], [ %div34.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i ], [ %div48.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i ], [ %div62.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i ], [ %div70.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i ], [ 0x7FF0000000000000, %if.else71.i.i.i.i ], [ %div80.i.i.i.i, %if.end7.i.i.i.i.i.i.i ], [ 0xFFF0000000000000, %if.else17.i.i.i.i ], [ %893, %predication.tail85 ], [ %909, %predication.tail64 ], [ %962, %predication.tail84 ]
  %add.i.i = fadd double %retval.0.i.i.i, 0.000000e+00
  br label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit

_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit: ; preds = %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, %lor.lhs.false2.i.i.i, %if.end8.i.i
  %retval.0.i.i = phi double [ 0x7FF8000000000000, %if.end8.i.i ], [ 0x7FF8000000000000, %lor.lhs.false2.i.i.i ], [ %add.i.i, %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i ]
  %arrayidx712 = getelementptr inbounds double, double addrspace(1)* %output.coerce, i64 %idxprom
  store double %retval.0.i.i, double addrspace(1)* %arrayidx712, align 8, !tbaa !8
  br label %if.end

if.end:                                           ; preds = %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, %entry
  ret void

predication.split:                                ; preds = %decision.dispatch1
  %626 = icmp sgt i32 %625, -65
  %627 = select i1 %626, i32 -17, i32 -257
  %628 = icmp sgt i32 %625, %627
  %629 = select i1 %626, i32 -9, i32 -129
  %630 = select i1 %626, i32 -33, i32 -513
  %631 = select i1 %628, i32 %629, i32 %630
  %632 = icmp sgt i32 %625, %631
  %633 = select i1 %626, i32 4, i32 64
  %634 = select i1 %626, i32 16, i32 256
  %635 = select i1 %628, i32 %633, i32 %634
  %636 = select i1 %626, i32 8, i32 128
  %637 = select i1 %626, i32 32, i32 512
  %638 = select i1 %628, i32 %636, i32 %637
  %639 = select i1 %632, i32 %635, i32 %638
  br label %predication.tail

predication.tail:                                 ; preds = %predication.split, %decision.dispatch1
  %merged.select30 = phi i32 [ 3, %decision.dispatch1 ], [ %639, %predication.split ]
  %640 = phi i1 [ undef, %decision.dispatch1 ], [ %626, %predication.split ]
  %641 = phi i1 [ undef, %decision.dispatch1 ], [ %628, %predication.split ]
  %642 = phi i1 [ undef, %decision.dispatch1 ], [ %632, %predication.split ]
  %643 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %merged.select30) #3
  %644 = tail call double @llvm.amdgcn.frexp.mant.f64(double %643) #3
  %645 = fcmp olt double %644, 0x3FE5555555555555
  %646 = zext i1 %645 to i32
  %647 = tail call double @llvm.amdgcn.ldexp.f64(double %644, i32 %646) #3
  %648 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %643) #3
  %649 = sub nsw i32 %648, %646
  %650 = fadd double %647, -1.000000e+00
  %651 = fadd double %647, 1.000000e+00
  %652 = fsub double %651, %647
  %653 = fsub double %651, %652
  %654 = fsub double %647, %653
  %655 = fsub double 1.000000e+00, %652
  %656 = fadd double %655, %654
  %657 = tail call double @llvm.amdgcn.rcp.f64(double %651) #3
  %658 = fneg double %651
  %659 = tail call double @llvm.fma.f64(double %658, double %657, double 1.000000e+00) #3
  %660 = tail call double @llvm.fma.f64(double %659, double %657, double %657) #3
  %661 = tail call double @llvm.fma.f64(double %658, double %660, double 1.000000e+00) #3
  %662 = tail call double @llvm.fma.f64(double %661, double %660, double %660) #3
  %663 = fmul double %650, %662
  %664 = fmul double %651, %663
  %665 = fneg double %664
  %666 = tail call double @llvm.fma.f64(double %663, double %651, double %665) #3
  %667 = tail call double @llvm.fma.f64(double %663, double %656, double %666) #3
  %668 = fadd double %664, %667
  %669 = fsub double %668, %664
  %670 = fsub double %667, %669
  %671 = fsub double %650, %668
  %672 = fsub double %650, %671
  %673 = fsub double %672, %668
  %674 = fsub double %673, %670
  %675 = fadd double %671, %674
  %676 = fmul double %662, %675
  %677 = fadd double %663, %676
  %678 = fsub double %677, %663
  %679 = fsub double %676, %678
  %680 = fmul double %677, %677
  %681 = fneg double %680
  %682 = tail call double @llvm.fma.f64(double %677, double %677, double %681) #3
  %683 = fmul double %679, 2.000000e+00
  %684 = tail call double @llvm.fma.f64(double %677, double %683, double %682) #3
  %685 = tail call double @llvm.fma.f64(double %679, double %679, double %684) #3
  %686 = fadd double %680, %685
  %687 = fsub double %686, %680
  %688 = fsub double %685, %687
  %689 = tail call double @llvm.fma.f64(double %686, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %690 = tail call double @llvm.fma.f64(double %686, double %689, double 0x3FC7474DD7F4DF2E) #3
  %691 = tail call double @llvm.fma.f64(double %686, double %690, double 0x3FCC71C016291751) #3
  %692 = tail call double @llvm.fma.f64(double %686, double %691, double 0x3FD249249B27ACF1) #3
  %693 = tail call double @llvm.fma.f64(double %686, double %692, double 0x3FD99999998EF7B6) #3
  %694 = tail call double @llvm.fma.f64(double %686, double %693, double 0x3FE5555555555780) #3
  %695 = tail call double @llvm.amdgcn.ldexp.f64(double %677, i32 1) #3
  %696 = tail call double @llvm.amdgcn.ldexp.f64(double %679, i32 1) #3
  %697 = fmul double %677, %686
  %698 = fneg double %697
  %699 = tail call double @llvm.fma.f64(double %677, double %686, double %698) #3
  %700 = fmul double %679, %686
  %701 = tail call double @llvm.fma.f64(double %677, double %688, double %700) #3
  %702 = fadd double %699, %701
  %703 = fadd double %697, %702
  %704 = fsub double %703, %697
  %705 = fsub double %702, %704
  %706 = fmul double %703, %694
  %707 = fneg double %706
  %708 = tail call double @llvm.fma.f64(double %703, double %694, double %707) #3
  %709 = tail call double @llvm.fma.f64(double %705, double %694, double %708) #3
  %710 = fadd double %706, %709
  %711 = fsub double %710, %706
  %712 = fsub double %709, %711
  %713 = fadd double %695, %710
  %714 = fsub double %713, %695
  %715 = fsub double %713, %714
  %716 = fsub double %695, %715
  %717 = fsub double %710, %714
  %718 = fadd double %717, %716
  %719 = fadd double %696, %712
  %720 = fsub double %719, %696
  %721 = fsub double %719, %720
  %722 = fsub double %696, %721
  %723 = fsub double %712, %720
  %724 = fadd double %723, %722
  %725 = fadd double %719, %718
  %726 = fadd double %713, %725
  %727 = fsub double %726, %713
  %728 = fsub double %725, %727
  %729 = fadd double %724, %728
  %730 = fadd double %726, %729
  %731 = fsub double %730, %726
  %732 = fsub double %729, %731
  %733 = sitofp i32 %649 to double
  %734 = fmul double %730, 0x3FF71547652B82FE
  %735 = fneg double %734
  %736 = fmul double %730, 0x3C7777D0FFDA0D24
  %737 = insertelement <2 x double> undef, double %730, i32 0
  %738 = insertelement <2 x double> %737, double %732, i32 1
  %739 = insertelement <2 x double> undef, double %735, i32 0
  %740 = insertelement <2 x double> %739, double %736, i32 1
  %741 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %738, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %740) #3
  %742 = extractelement <2 x double> %741, i32 0
  %743 = extractelement <2 x double> %741, i32 1
  %744 = fadd double %742, %743
  %745 = fadd double %734, %744
  %746 = fsub double %745, %734
  %747 = fsub double %744, %746
  %748 = fadd double %745, %733
  %749 = fsub double %748, %733
  %750 = fsub double %749, %748
  %751 = fadd double %750, %733
  %752 = fsub double %745, %749
  %753 = fadd double %752, %751
  %754 = fadd double %747, %753
  %755 = fadd double %748, %754
  %756 = tail call double @llvm.fabs.f64(double %643) #4
  %757 = fcmp oeq double %756, 0x7FF0000000000000
  %758 = select i1 %757, double %643, double %755
  %759 = fcmp olt double %643, 0.000000e+00
  %760 = select i1 %759, double 0x7FF8000000000000, double %758
  %761 = fcmp oeq double %643, 0.000000e+00
  br i1 %cmp19.i.i.i.i, label %predication.tail61, label %predication.split60

predication.split60:                              ; preds = %predication.tail
  %762 = select i1 %761, double 0xFFF0000000000000, double %760
  %763 = fmul double %762, %762
  %764 = select i1 %640, double 0x3E32022ABCFF5DE7, double 0x3C819FA1E5E36C20
  %765 = select i1 %640, double 0x3D5866A3E6D0F156, double 0x3BAA9A26E0297ED8
  %766 = select i1 %641, double %764, double %765
  %767 = select i1 %640, double 0x3DC4C8BD76453064, double 0x3C158FD8B3C1B0C0
  %768 = select i1 %640, double 0x3CED1FCD2AD8841F, double 0x3B408480D3491A50
  %769 = select i1 %641, double %767, double %768
  br label %predication.tail61

predication.tail61:                               ; preds = %predication.split60, %predication.tail
  %merged.select33 = phi double [ %760, %predication.tail ], [ %769, %predication.split60 ]
  %merged.select32 = phi double [ 0xFFF0000000000000, %predication.tail ], [ %766, %predication.split60 ]
  %merged.select31 = phi i1 [ %761, %predication.tail ], [ %642, %predication.split60 ]
  %770 = phi double [ undef, %predication.tail ], [ %762, %predication.split60 ]
  %771 = phi double [ undef, %predication.tail ], [ %763, %predication.split60 ]
  %772 = select i1 %merged.select31, double %merged.select32, double %merged.select33
  %merged.select34 = select i1 %cmp19.i.i.i.i, double %772, double %771
  %773 = fmul double %merged.select34, %772
  br i1 %cmp19.i.i.i.i, label %predication.tail63, label %predication.split62

predication.split62:                              ; preds = %predication.tail61
  %774 = select i1 %640, double 0xBF336C13BBA203F3, double 0xBE050B1B8007F8FF
  %775 = select i1 %640, double 0xBE9C2F1FFD2FFECD, double 0xBD7021DF3392EE60
  %776 = select i1 %641, double %774, double %775
  %777 = select i1 %640, double 0xBEE755F1646665DB, double 0xBDB9FC7E20BD04CC
  %778 = select i1 %640, double 0xBE512769C01EA7C5, double 0xBD241E51766A91FB
  %779 = select i1 %641, double %777, double %778
  %780 = select i1 %642, double %776, double %779
  %781 = fsub double %780, %773
  %782 = select i1 %640, double 0x3ECBFD524C94F258, double 0x3D5CB3C39661DD79
  %783 = select i1 %640, double 0x3E1390C28573DB0F, double 0x3CA5D280D4B5A285
  %784 = select i1 %641, double %782, double %783
  %785 = select i1 %640, double 0x3E70731CF2A765F0, double 0x3D01A287ED1019B8
  %786 = select i1 %640, double 0x3DB79116B58241AA, double 0x3C4B275AC5F91B68
  %787 = select i1 %641, double %785, double %786
  %788 = select i1 %642, double %784, double %787
  br label %predication.tail63

predication.tail63:                               ; preds = %predication.split62, %predication.tail61
  %merged.select36 = phi double [ 0x3F1989D450BBA5CA, %predication.tail61 ], [ %788, %predication.split62 ]
  %merged.select35 = phi double [ %773, %predication.tail61 ], [ %771, %predication.split62 ]
  %789 = phi double [ undef, %predication.tail61 ], [ %781, %predication.split62 ]
  %790 = fmul double %merged.select35, %merged.select36
  %791 = select i1 %640, double 0xBF81F96D17A7115B, double 0xBE94B8A80FB81310
  %792 = select i1 %640, double 0xBF0B3634004E0F5C, double 0xBE2007A65CA14E38
  %793 = select i1 %641, double %791, double %792
  %794 = select i1 %640, double 0xBF4625660A41D7B1, double 0xBE59BA2A0439E4A9
  %795 = select i1 %640, double 0xBED0C1E92AD969EF, double 0xBDE40A018263D493
  %796 = select i1 %641, double %794, double %795
  %797 = select i1 %642, double %793, double %796
  %merged.select37 = select i1 %cmp19.i.i.i.i, double 0xBFBD94CCEC41CB08, double %797
  %798 = fsub double %merged.select37, %790
  %merged.select39 = select i1 %cmp19.i.i.i.i, double 0x3F7B3A00DD9C9429, double %798
  %799 = fmul double %merged.select35, %merged.select39
  br i1 %cmp19.i.i.i.i, label %predication.second, label %predication.first

predication.first:                                ; preds = %predication.tail63
  %800 = fmul double %771, %789
  %801 = select i1 %640, double 0xBFBD7935AC58B5B5, double 0xBF1232A95F4E8466
  %802 = select i1 %640, double 0xBF676495E4B7EAAA, double 0xBEBC6E261AE99633
  %803 = select i1 %641, double %801, double %802
  %804 = select i1 %640, double 0xBF92AE2345C460A0, double 0xBEE6B9C7BCE39403
  %805 = select i1 %640, double 0xBF3D2E78945F9AC6, double 0xBE91D0F7FEBA5A35
  %806 = select i1 %641, double %804, double %805
  %807 = select i1 %642, double %803, double %806
  %808 = fadd double %800, %807
  %809 = select i1 %640, double 0xBFE78F054AC7A90B, double 0xBF7F5FDEC6827012
  %810 = select i1 %640, double 0xBFB3B5B6F694BB9E, double 0xBF48C2CA21FD14A5
  %811 = select i1 %641, double %809, double %810
  %812 = select i1 %640, double 0xBFCED54905311121, double 0xBF63B612102F3C24
  %813 = select i1 %640, double 0xBF98ED20B1D6A6D8, double 0xBF2F1E266EB4C824
  %814 = select i1 %641, double %812, double %813
  %815 = select i1 %642, double %811, double %814
  br label %predication.join

predication.second:                               ; preds = %predication.tail63
  %816 = fsub double 0xBFE8DDD719DA7D3E, %799
  br label %predication.join

predication.join:                                 ; preds = %predication.second, %predication.first
  %merged.select46 = phi double [ %770, %predication.first ], [ %772, %predication.second ]
  %merged.select41 = phi double [ %808, %predication.first ], [ %798, %predication.second ]
  %guard.value68 = phi double [ %815, %predication.first ], [ undef, %predication.second ]
  %guard.value69 = phi double [ undef, %predication.first ], [ %816, %predication.second ]
  %817 = fadd double %799, %guard.value68
  %818 = fmul double %merged.select35, %merged.select41
  %merged.select43 = select i1 %cmp19.i.i.i.i, double %guard.value69, double %817
  %819 = fmul double %merged.select35, %merged.select43
  %820 = select i1 %640, double 0xC001F1CD6A03BCAA, double 0xBFD9F6368DFEFDDF
  %821 = select i1 %640, double 0xBFEFD66AE54A0BCB, double 0xBFC4B5F131A679CC
  %822 = select i1 %641, double %820, double %821
  %823 = select i1 %640, double 0xBFF8595CA25899FD, double 0xBFD06A8AF4A3FC55
  %824 = select i1 %640, double 0xBFE46D859460DB51, double 0xBFBA19EDB555D8AD
  %825 = select i1 %641, double %823, double %824
  %826 = select i1 %642, double %822, double %825
  %merged.select44 = select i1 %cmp19.i.i.i.i, double 0xC001974D2C397C76, double %826
  %827 = fadd double %818, %merged.select44
  %828 = select i1 %640, double 0xC004C929A952DE48, double 0xC0207852FA1731C0
  %829 = select i1 %640, double 0xC013B000D66B8269, double 0xC02A92BAF87A7B72
  %830 = select i1 %641, double %828, double %829
  %831 = select i1 %640, double 0xC00D636ADAEC3C05, double 0xC024F817DD06EE79
  %832 = select i1 %640, double 0xC019A861C808DCFC, double 0xC030CB31255FFA09
  %833 = select i1 %641, double %831, double %832
  %834 = select i1 %642, double %830, double %833
  %merged.select45 = select i1 %cmp19.i.i.i.i, double 0xC001804F92FE2A82, double %834
  %835 = fadd double %819, %merged.select45
  %836 = fmul double %merged.select46, %827
  %837 = fsub double %835, %836
  %838 = select i1 %640, double 0x3E9090FBB4B042AE, double 0x3D0A81E9CB6A1EA5
  %839 = select i1 %640, double 0x3DCCD7C812F40049, double 0x3C495387D39D2504
  %840 = select i1 %641, double %838, double %839
  %841 = select i1 %640, double 0x3E2EB2F3F6504F32, double 0x3CA9D032740CF69A
  %842 = select i1 %640, double 0x3D6B7BD497A2CD17, double 0x3BE8FEBB5A4047D7
  %843 = select i1 %641, double %841, double %842
  %844 = select i1 %642, double %840, double %843
  %merged.select48 = select i1 %cmp19.i.i.i.i, double 0x3EDBEC7AF5AC0D6F, double %844
  %845 = fmul double %merged.select35, %merged.select48
  %846 = select i1 %640, double 0x3F586FC94B9EAD30, double 0x3E553724D72BE5C7
  %847 = select i1 %640, double 0x3ED66AFC954DE682, double 0x3DD49301DA58AEFA
  %848 = select i1 %641, double %846, double %847
  %849 = select i1 %640, double 0x3F1751EF5755C229, double 0x3E14D76BE5BA042B
  %850 = select i1 %640, double 0x3E95BA568EDD3BFB, double 0x3D9463E48A976F97
  %851 = select i1 %641, double %849, double %850
  %852 = select i1 %642, double %848, double %851
  %merged.select49 = select i1 %cmp19.i.i.i.i, double 0x3F98BA1DB321D0E9, double %852
  %853 = fadd double %845, %merged.select49
  %854 = select i1 %640, double 0x3F0330822740ADF9, double 0x3DC001D96C7E2C9D
  %855 = select i1 %640, double 0x3E6129D961D79065, double 0x3D1ED0326F0CBDDC
  %856 = select i1 %641, double %854, double %855
  %857 = select i1 %640, double 0x3EB20E304F6E5BCE, double 0x3D6F4FAB0C90F842
  %858 = select i1 %640, double 0x3E107ECF99D6009A, double 0x3CCE78F4A7F13C7D
  %859 = select i1 %641, double %857, double %858
  %860 = select i1 %642, double %856, double %859
  %merged.select51 = select i1 %cmp19.i.i.i.i, double 0x3F4ED662BB480251, double %860
  %861 = fmul double %merged.select35, %merged.select51
  %862 = select i1 %640, double 0x3F999857B526C821, double 0x3ED71590B83839D8
  %863 = select i1 %640, double 0x3F380B62C1407B15, double 0x3E768F19E4302EF3
  %864 = select i1 %641, double %862, double %863
  %865 = select i1 %640, double 0x3F68BF137C253BD1, double 0x3EA6C7746378848A
  %866 = select i1 %640, double 0x3F077F4625619D43, double 0x3E46680C94743FD9
  %867 = select i1 %641, double %865, double %866
  %868 = select i1 %642, double %864, double %867
  %merged.select52 = select i1 %cmp19.i.i.i.i, double 0x3FCBD444F5D4FCC2, double %868
  %869 = fadd double %861, %merged.select52
  %870 = fmul double %merged.select35, %853
  %871 = fmul double %merged.select35, %869
  br i1 %cmp19.i.i.i.i, label %predication.tail85, label %predication.split84

predication.split84:                              ; preds = %predication.join
  %872 = select i1 %640, double 0x3FC92E7DCCD1B70C, double 0x3F478C82425FFDCE
  %873 = select i1 %640, double 0x3F882FD20DA34F30, double 0x3F0730EC426E6E84
  %874 = select i1 %641, double %872, double %873
  %875 = select i1 %640, double 0x3FA8A45F1AE4ADBE, double 0x3F275783E6F9B4DA
  %876 = select i1 %640, double 0x3F67D3564F778B21, double 0x3EE71602E8EA99F3
  %877 = select i1 %641, double %875, double %876
  %878 = select i1 %642, double %874, double %877
  %879 = fadd double %870, %878
  %880 = select i1 %640, double 0x3FE7235AE26E3A60, double 0x3FA66506CA3FCEB3
  %881 = select i1 %640, double 0x3FC6B0CE3157BCB1, double 0x3F86397D81A61D6E
  %882 = select i1 %641, double %880, double %881
  %883 = select i1 %640, double 0x3FD6E5B7AB236028, double 0x3F964BEF3074CF28
  %884 = select i1 %640, double 0x3FB68627D1A51CB5, double 0x3F762C8C65771E78
  %885 = select i1 %641, double %883, double %884
  %886 = select i1 %642, double %882, double %885
  br label %predication.tail85

predication.tail85:                               ; preds = %predication.split84, %predication.join
  %merged.select56 = phi double [ 0x3FE957680773BEB6, %predication.join ], [ %886, %predication.split84 ]
  %merged.select55 = phi double [ %870, %predication.join ], [ %871, %predication.split84 ]
  %887 = phi double [ undef, %predication.join ], [ %879, %predication.split84 ]
  %888 = fadd double %merged.select55, %merged.select56
  %889 = fmul double %771, %887
  %merged.select57 = select i1 %cmp19.i.i.i.i, double %871, double %889
  %890 = fadd double %merged.select57, 1.000000e+00
  %891 = fmul double %merged.select46, %888
  %892 = fsub double %890, %891
  %893 = fdiv double %837, %892
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

predication.split63:                              ; preds = %decision.dispatch2
  %894 = fsub double 0xBFEEB82FAA589934, %24
  %895 = fmul double %9, %894
  %896 = fmul double %9, %27
  %897 = fadd double %895, 0x401A11C0BB0DC22E
  %898 = fadd double %896, 0xC04B158FF790C730
  br label %predication.tail64

predication.tail64:                               ; preds = %predication.split63, %decision.dispatch2
  %merged.select47 = phi double [ 0x40354F2A1256B431, %decision.dispatch2 ], [ 0x4020675EC4F85A38, %predication.split63 ]
  %merged.select42 = phi double [ 0x4063AA2F5D62DCD3, %decision.dispatch2 ], [ 0x403058D46A8EC004, %predication.split63 ]
  %merged.select40 = phi double [ 0x407BA4300BFE5087, %decision.dispatch2 ], [ 0xC02E8C55CA7195EF, %predication.split63 ]
  %merged.select38 = phi double [ %27, %decision.dispatch2 ], [ %898, %predication.split63 ]
  %merged.select29 = phi double [ %25, %decision.dispatch2 ], [ %897, %predication.split63 ]
  %899 = fmul double %9, %merged.select29
  %900 = fmul double %9, %merged.select38
  %901 = fadd double %899, %merged.select40
  %902 = fadd double %900, %merged.select42
  %903 = fmul double %9, %901
  %904 = fmul double %9, %902
  %905 = fadd double %903, %merged.select47
  %906 = fadd double %904, 1.000000e+00
  %907 = fmul double %8, %905
  %908 = fadd double %906, %907
  %909 = fdiv double %23, %908
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

predication.split83:                              ; preds = %decision.dispatch3
  %910 = fcmp oge double %arrayidx.val, 3.750000e-01
  %911 = select i1 %910, double -3.750000e-01, double -2.500000e-01
  br label %predication.tail84

predication.tail84:                               ; preds = %predication.split83, %decision.dispatch3
  %merged.select73 = phi double [ 0x4071A64A34042F35, %decision.dispatch3 ], [ 0xC0138A29DF206C0B, %predication.split83 ]
  %merged.select70 = phi double [ 0xC0809E1D789AFFE5, %decision.dispatch3 ], [ 0xC016B372910B83AB, %predication.split83 ]
  %merged.select54 = phi double [ 0x408C1B9BAF952B96, %decision.dispatch3 ], [ 0x4040A8BCD7811DE4, %predication.split83 ]
  %merged.select18 = phi double [ -1.250000e-01, %decision.dispatch3 ], [ %911, %predication.split83 ]
  %912 = phi i1 [ undef, %decision.dispatch3 ], [ %910, %predication.split83 ]
  %913 = fadd double %arrayidx.val, %merged.select18
  %914 = fmul double %913, %913
  %915 = select i1 %912, double 0x40132BDEE3243B58, double 0x402A50B00A1E7B86
  %merged.select50 = select i1 %decision.interval, double %915, double 0x406D392CDE09E490
  %916 = fmul double %914, %merged.select50
  %917 = select i1 %912, double 0xC0360FDD97954BA2, double 0xC03EAAFBAB179207
  %918 = fadd double %916, %917
  %919 = select i1 %912, double 0x401CB5EDEDB31A3B, double 0x403CBAD71AE3B29A
  %920 = fsub double 0x408C7AAA9D225E9A, %916
  %guard.result = select i1 %decision.interval, double %919, double 0x408B6249334DA816
  %guard.result92 = select i1 %decision.interval, double %918, double %920
  %921 = fmul double %914, %guard.result
  %922 = fadd double %921, 0xC017CB97C9E45E0D
  %923 = select i1 %decision.interval, double %922, double undef
  %924 = fsub double %merged.select54, %921
  %925 = fmul double %914, %guard.result92
  %926 = and i1 %decision.interval, %912
  %merged.select59 = select i1 %926, double %923, double %924
  %927 = fmul double %914, %merged.select59
  %928 = select i1 %912, double 0x4027FEF192CFFD80, double 0x402CB09090084637
  %merged.select60 = select i1 %decision.interval, double %928, double 0xC05E9BCF5C362E51
  %929 = fadd double %925, %merged.select60
  %930 = select i1 %912, double 0x3FF83BDAD25D5F48, double 0xC013B1AD6B90733F
  %merged.select61 = select i1 %decision.interval, double %930, double 0xC066A4A24A4E1713
  %931 = fadd double %927, %merged.select61
  %932 = fmul double %914, %929
  %933 = select i1 %912, double 0xBFF2C5AD0DCDC29A, double 0xBFFA1FFFE7A41296
  %934 = fadd double %932, %933
  %merged.select62 = select i1 %decision.interval, double %913, double %914
  %935 = fmul double %merged.select62, %931
  %merged.select63 = select i1 %decision.interval, double %935, double %932
  %merged.select64 = select i1 %decision.interval, double %934, double 0xC04249A2BD20D346
  %936 = fadd double %merged.select63, %merged.select64
  %937 = select i1 %912, double 0x3FF693D2420640AD, double 0x40296F06194D60C2
  %938 = fadd double %935, 0xC001804F92FE2A82
  %merged.select65 = select i1 %decision.interval, double %914, double %913
  %merged.select66 = select i1 %decision.interval, double %937, double %936
  %939 = fmul double %merged.select65, %merged.select66
  %940 = fsub double 0x401B5545C0CB5BDA, %939
  %941 = select i1 %decision.interval, double %940, double undef
  %merged.select67 = select i1 %decision.interval, double %939, double %938
  %merged.select68 = select i1 %decision.interval, double 0xC030F25386AA802B, double %939
  %942 = fadd double %merged.select67, %merged.select68
  %943 = select i1 %912, double %941, double %942
  %944 = select i1 %912, double 0x40074E9A9F865729, double 0x40199996D51EE9B7
  %merged.select69 = select i1 %decision.interval, double %944, double 0x405E5232607614DB
  %945 = fmul double %914, %merged.select69
  %946 = fadd double %945, %merged.select70
  %947 = fsub double 0x40034649FCCCF81F, %945
  %948 = fmul double %914, 0x404C078043CB129C
  %guard.value114 = select i1 %decision.interval, double %947, double undef
  %949 = select i1 %912, double %946, double %guard.value114
  %.op1 = fsub double 0xC0320C17B7F0ED52, %948
  %guard.result121 = select i1 %decision.interval, double %949, double %.op1
  %merged.select71 = select i1 %decision.interval, double %943, double %946
  %950 = fmul double %914, %merged.select71
  %951 = fmul double %914, %guard.result121
  %952 = fadd double %950, %merged.select73
  %953 = select i1 %912, double %951, double %950
  %954 = select i1 %912, double 0x3FFC33F0B4C09D66, double 0x40158CEB587D3265
  %merged.select74 = select i1 %decision.interval, double %953, double %951
  %merged.select75 = select i1 %decision.interval, double %954, double 0x405F12CC60181A8F
  %955 = fadd double %merged.select74, %merged.select75
  %956 = fmul double %914, %952
  %merged.select76 = select i1 %decision.interval, double %952, double %955
  %957 = fmul double %914, %merged.select76
  %958 = select i1 %912, double %957, double %951
  %.op2 = fadd double %956, 0x40332E0500972875
  %merged.select77 = select i1 %decision.interval, double %958, double %957
  %959 = fadd double %merged.select77, 1.000000e+00
  %merged.select78 = select i1 %decision.interval, double %955, double %.op2
  %960 = fmul double %913, %merged.select78
  %merged.select79 = select i1 %926, double %960, double %959
  %merged.select80 = select i1 %926, double %959, double %960
  %961 = fadd double %merged.select79, %merged.select80
  %merged.select81 = select i1 %decision.interval, double %936, double %942
  %962 = fdiv double %merged.select81, %961
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

merged.bb5:                                       ; preds = %if.end7.i.i.i620.i.i.i.i
  %963 = fmul double %add23.i.i.i.i.i616.i.i.i.i, %171
  %964 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i616.i.i.i.i, i32 %div.i.i.i617.i.i.i.i) #3
  %guard.value = select i1 %cmp11.i.i.i619.i.i.i.i, double %963, double undef
  %guard.value12 = select i1 %cmp11.i.i.i619.i.i.i.i, double undef, double %964
  br label %merged.bb7

merged.bb6:                                       ; preds = %if.end7.i.i.i620.i.i.i.i
  %965 = fdiv double %add23.i.i.i.i.i616.i.i.i.i, %171
  br label %merged.bb7

merged.bb7:                                       ; preds = %merged.bb6, %merged.bb5
  %966 = phi double [ %guard.value, %merged.bb5 ], [ %965, %merged.bb6 ]
  %967 = phi double [ %guard.value12, %merged.bb5 ], [ undef, %merged.bb6 ]
  %guess.i.i.i589.i.i.i.i.0 = select i1 %cmp11.i.i.i619.i.i.i.i, double %966, double %967
  %.neg6 = mul nsw i32 %div.i.i.i617.i.i.i.i, -3
  %rem.i.i.i635.i.i.i.i.decomposed = add i32 %.frozen, 2
  %add.i.i.i636.i.i.i.i = add i32 %rem.i.i.i635.i.i.i.i.decomposed, %.neg6
  %968 = zext i32 %add.i.i.i636.i.i.i.i to i64
  %arrayidx1.i.i.i637.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %968
  %969 = load double, double addrspace(4)* %arrayidx1.i.i.i637.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i638.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.0, %969
  %cmp26.i.i.i639.i.i.i.i = icmp slt i32 %162, 1021
  br i1 %cmp26.i.i.i639.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i

merged.bb8:                                       ; preds = %if.end7.i.i.i499.i.i.i.i
  %970 = fmul double %add23.i.i.i.i.i495.i.i.i.i, %309
  %971 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i495.i.i.i.i, i32 %div.i.i.i496.i.i.i.i) #3
  %guard.value15 = select i1 %cmp11.i.i.i498.i.i.i.i, double %970, double undef
  %guard.value16 = select i1 %cmp11.i.i.i498.i.i.i.i, double undef, double %971
  br label %merged.bb10

merged.bb9:                                       ; preds = %if.end7.i.i.i499.i.i.i.i
  %972 = fdiv double %add23.i.i.i.i.i495.i.i.i.i, %309
  br label %merged.bb10

merged.bb10:                                      ; preds = %merged.bb9, %merged.bb8
  %973 = phi double [ %guard.value15, %merged.bb8 ], [ %972, %merged.bb9 ]
  %974 = phi double [ %guard.value16, %merged.bb8 ], [ undef, %merged.bb9 ]
  %guess.i.i.i468.i.i.i.i.0 = select i1 %cmp11.i.i.i498.i.i.i.i, double %973, double %974
  %.neg5 = mul nsw i32 %div.i.i.i496.i.i.i.i, -3
  %rem.i.i.i514.i.i.i.i.decomposed = add i32 %.frozen209, 2
  %add.i.i.i515.i.i.i.i = add i32 %rem.i.i.i514.i.i.i.i.decomposed, %.neg5
  %975 = zext i32 %add.i.i.i515.i.i.i.i to i64
  %arrayidx1.i.i.i516.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %975
  %976 = load double, double addrspace(4)* %arrayidx1.i.i.i516.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i517.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.0, %976
  %cmp26.i.i.i518.i.i.i.i = icmp slt i32 %300, 1021
  br i1 %cmp26.i.i.i518.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i

merged.bb11:                                      ; preds = %if.end7.i.i.i386.i.i.i.i
  %977 = fmul double %add23.i.i.i.i.i382.i.i.i.i, %447
  %978 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i382.i.i.i.i, i32 %div.i.i.i383.i.i.i.i) #3
  %guard.value18 = select i1 %cmp11.i.i.i385.i.i.i.i, double %977, double undef
  %guard.value19 = select i1 %cmp11.i.i.i385.i.i.i.i, double undef, double %978
  br label %merged.bb13

merged.bb12:                                      ; preds = %if.end7.i.i.i386.i.i.i.i
  %979 = fdiv double %add23.i.i.i.i.i382.i.i.i.i, %447
  br label %merged.bb13

merged.bb13:                                      ; preds = %merged.bb12, %merged.bb11
  %980 = phi double [ %guard.value18, %merged.bb11 ], [ %979, %merged.bb12 ]
  %981 = phi double [ %guard.value19, %merged.bb11 ], [ undef, %merged.bb12 ]
  %guess.i.i.i355.i.i.i.i.0 = select i1 %cmp11.i.i.i385.i.i.i.i, double %980, double %981
  %.neg4 = mul nsw i32 %div.i.i.i383.i.i.i.i, -3
  %rem.i.i.i401.i.i.i.i.decomposed = add i32 %.frozen210, 2
  %add.i.i.i402.i.i.i.i = add i32 %rem.i.i.i401.i.i.i.i.decomposed, %.neg4
  %982 = zext i32 %add.i.i.i402.i.i.i.i to i64
  %arrayidx1.i.i.i403.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %982
  %983 = load double, double addrspace(4)* %arrayidx1.i.i.i403.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i404.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.0, %983
  %cmp26.i.i.i405.i.i.i.i = icmp slt i32 %438, 1021
  br i1 %cmp26.i.i.i405.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i

merged.bb14:                                      ; preds = %if.end7.i.i.i273.i.i.i.i
  %984 = fmul double %add23.i.i.i.i.i269.i.i.i.i, %585
  %985 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i269.i.i.i.i, i32 %div.i.i.i270.i.i.i.i) #3
  %guard.value21 = select i1 %cmp11.i.i.i272.i.i.i.i, double %984, double undef
  %guard.value22 = select i1 %cmp11.i.i.i272.i.i.i.i, double undef, double %985
  br label %merged.bb16

merged.bb15:                                      ; preds = %if.end7.i.i.i273.i.i.i.i
  %986 = fdiv double %add23.i.i.i.i.i269.i.i.i.i, %585
  br label %merged.bb16

merged.bb16:                                      ; preds = %merged.bb15, %merged.bb14
  %987 = phi double [ %guard.value21, %merged.bb14 ], [ %986, %merged.bb15 ]
  %988 = phi double [ %guard.value22, %merged.bb14 ], [ undef, %merged.bb15 ]
  %guess.i.i.i242.i.i.i.i.0 = select i1 %cmp11.i.i.i272.i.i.i.i, double %987, double %988
  %.neg3 = mul nsw i32 %div.i.i.i270.i.i.i.i, -3
  %rem.i.i.i288.i.i.i.i.decomposed = add i32 %.frozen211, 2
  %add.i.i.i289.i.i.i.i = add i32 %rem.i.i.i288.i.i.i.i.decomposed, %.neg3
  %989 = zext i32 %add.i.i.i289.i.i.i.i to i64
  %arrayidx1.i.i.i290.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %989
  %990 = load double, double addrspace(4)* %arrayidx1.i.i.i290.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i291.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.0, %990
  %cmp26.i.i.i292.i.i.i.i = icmp slt i32 %576, 1021
  br i1 %cmp26.i.i.i292.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i

merged.bb17:                                      ; preds = %if.end7.i.i.i192.i.i.i.i
  %991 = fmul double %add23.i.i.i.i.i188.i.i.i.i, %602
  %992 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i188.i.i.i.i, i32 %div.i.i.i189.i.i.i.i) #3
  %guard.value24 = select i1 %cmp11.i.i.i191.i.i.i.i, double %991, double undef
  %guard.value25 = select i1 %cmp11.i.i.i191.i.i.i.i, double undef, double %992
  br label %merged.bb19

merged.bb18:                                      ; preds = %if.end7.i.i.i192.i.i.i.i
  %993 = fdiv double %add23.i.i.i.i.i188.i.i.i.i, %602
  br label %merged.bb19

merged.bb19:                                      ; preds = %merged.bb18, %merged.bb17
  %994 = phi double [ %guard.value24, %merged.bb17 ], [ %993, %merged.bb18 ]
  %995 = phi double [ %guard.value25, %merged.bb17 ], [ undef, %merged.bb18 ]
  %guess.i.i.i161.i.i.i.i.0 = select i1 %cmp11.i.i.i191.i.i.i.i, double %994, double %995
  %.neg2 = mul nsw i32 %div.i.i.i189.i.i.i.i, -3
  %rem.i.i.i207.i.i.i.i.decomposed = add i32 %.frozen212, 2
  %add.i.i.i208.i.i.i.i = add i32 %rem.i.i.i207.i.i.i.i.decomposed, %.neg2
  %996 = zext i32 %add.i.i.i208.i.i.i.i to i64
  %arrayidx1.i.i.i209.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %996
  %997 = load double, double addrspace(4)* %arrayidx1.i.i.i209.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i210.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.0, %997
  %cmp26.i.i.i211.i.i.i.i = icmp slt i32 %593, 1021
  br i1 %cmp26.i.i.i211.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i

merged.bb:                                        ; preds = %if.end4.i.i.i92.i.i.i.i
  %merged.select = select i1 %615, i32 %div.i.i.i108.i.i.i.i, i32 %613
  %998 = zext i32 %merged.select to i64
  %999 = shl nuw i64 1, %998
  %1000 = uitofp i64 %999 to double
  br i1 %615, label %predication.first3, label %predication.second4

predication.first3:                               ; preds = %merged.bb
  %1001 = fmul double %add23.i.i.i.i.i107.i.i.i.i, %1000
  br label %if.end23.i.i.i131.i.i.i.i

predication.second4:                              ; preds = %merged.bb
  %1002 = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %1000
  br label %if.end23.i.i.i131.i.i.i.i

merged.bb1:                                       ; preds = %merged.bb21
  %merged.select2 = select i1 %615, i32 %div.i.i.i108.i.i.i.i, i32 %613
  %1003 = zext i32 %merged.select2 to i64
  %1004 = shl nuw i64 1, %1003
  %1005 = uitofp i64 %1004 to double
  br i1 %615, label %predication.first4, label %predication.second5

predication.first4:                               ; preds = %merged.bb1
  %1006 = fmul double %add23.i.i.i.i.i107.i.i.i.i, %1005
  br label %if.end23.i.i.i50.i.i.i.i

predication.second5:                              ; preds = %merged.bb1
  %1007 = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %1005
  br label %if.end23.i.i.i50.i.i.i.i

merged.bb20:                                      ; preds = %predication.join94, %if.end23.i.i.i131.i.i.i.i
  %1008 = phi double [ %mul24.i.i.i129.i.i.i.i, %if.end23.i.i.i131.i.i.i.i ], [ %1023, %predication.join94 ]
  %1009 = phi double [ %mul24.i.i.i129.i.i.i.i, %if.end23.i.i.i131.i.i.i.i ], [ %1022, %predication.join94 ]
  %merged.select53 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1008, double %1009
  %1010 = fmul double %merged.select53, %merged.select53
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.tail91, label %predication.split90

predication.split90:                              ; preds = %merged.bb20
  %1011 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %1009
  %1012 = fsub double %1010, %1011
  br label %predication.tail91

predication.tail91:                               ; preds = %predication.split90, %merged.bb20
  %merged.select82 = phi double [ %1010, %merged.bb20 ], [ 2.000000e+00, %predication.split90 ]
  %1013 = phi double [ undef, %merged.bb20 ], [ %1012, %predication.split90 ]
  %1014 = fmul double %merged.select53, %merged.select82
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.first92, label %predication.second93

predication.first92:                              ; preds = %predication.tail91
  %1015 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %1014
  %1016 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %1015
  %1017 = fadd double %1014, %1014
  br label %predication.join94

predication.second93:                             ; preds = %predication.tail91
  %1018 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %1010
  br label %predication.join94

predication.join94:                               ; preds = %predication.second93, %predication.first92
  %merged.select85 = phi double [ %1016, %predication.first92 ], [ %1013, %predication.second93 ]
  %merged.select83 = phi double [ %z.addr.i.i.i76.i.i.i.i.0, %predication.first92 ], [ %1014, %predication.second93 ]
  %guard.result98 = phi double [ %1017, %predication.first92 ], [ %1018, %predication.second93 ]
  %1019 = fadd double %merged.select83, %guard.result98
  %1020 = fdiv double %merged.select85, %1019
  %1021 = fsub double %1009, %1020
  %1022 = select i1 %cmp26.i.i.i130.i.i.i.i, double undef, double %1021
  %merged.select86 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1008, double %1021
  %merged.select87 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1020, double 0x3EC0000000000000
  %1023 = fmul double %merged.select86, %merged.select87
  %1024 = fsub double 1.000000e+00, %1020
  %merged.select88 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1024, double %1020
  %1025 = tail call double @llvm.fabs.f64(double %merged.select88) #3
  %1026 = fcmp ogt double %1025, 0x3EC0000000000000
  %1027 = fcmp olt double %1023, %1025
  %guard.result108 = select i1 %cmp26.i.i.i130.i.i.i.i, i1 %1026, i1 %1027
  br i1 %guard.result108, label %merged.bb20, label %merged.bb21

merged.bb21:                                      ; preds = %predication.join94
  %guess.i.i.i78.i.i.i.i.3 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1023, double %1021
  %1028 = fneg double %guess.i.i.i78.i.i.i.i.3
  %1029 = select i1 %cmp5.i.i.i91.i.i.i.i, double %1028, double %guess.i.i.i78.i.i.i.i.3
  br i1 %cmp11.i.i.i110.i.i.i.i, label %merged.bb1, label %if.end23.i.i.i50.i.i.i.i

merged.bb22:                                      ; preds = %predication.join101, %if.end23.i.i.i50.i.i.i.i
  %1030 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %1045, %predication.join101 ]
  %1031 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %1044, %predication.join101 ]
  %merged.select58 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1030, double %1031
  %1032 = fmul double %merged.select58, %merged.select58
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.tail98, label %predication.split97

predication.split97:                              ; preds = %merged.bb22
  %1033 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %1031
  %1034 = fsub double %1032, %1033
  br label %predication.tail98

predication.tail98:                               ; preds = %predication.split97, %merged.bb22
  %merged.select89 = phi double [ %1032, %merged.bb22 ], [ 2.000000e+00, %predication.split97 ]
  %1035 = phi double [ undef, %merged.bb22 ], [ %1034, %predication.split97 ]
  %1036 = fmul double %merged.select58, %merged.select89
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.first99, label %predication.second100

predication.first99:                              ; preds = %predication.tail98
  %1037 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %1036
  %1038 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %1037
  %1039 = fadd double %1036, %1036
  br label %predication.join101

predication.second100:                            ; preds = %predication.tail98
  %1040 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %1032
  br label %predication.join101

predication.join101:                              ; preds = %predication.second100, %predication.first99
  %merged.select92 = phi double [ %1038, %predication.first99 ], [ %1035, %predication.second100 ]
  %merged.select90 = phi double [ %z.addr.i.i.i76.i.i.i.i.0, %predication.first99 ], [ %1036, %predication.second100 ]
  %guard.result105 = phi double [ %1039, %predication.first99 ], [ %1040, %predication.second100 ]
  %1041 = fadd double %merged.select90, %guard.result105
  %1042 = fdiv double %merged.select92, %1041
  %1043 = fsub double %1031, %1042
  %1044 = select i1 %cmp26.i.i.i130.i.i.i.i, double undef, double %1043
  %merged.select93 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1030, double %1043
  %merged.select94 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1042, double 0x3EC0000000000000
  %1045 = fmul double %merged.select93, %merged.select94
  %1046 = fsub double 1.000000e+00, %1042
  %merged.select95 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1046, double %1042
  %1047 = tail call double @llvm.fabs.f64(double %merged.select95) #3
  %1048 = fcmp ogt double %1047, 0x3EC0000000000000
  %1049 = fcmp olt double %1045, %1047
  %guard.result116 = select i1 %cmp26.i.i.i130.i.i.i.i, i1 %1048, i1 %1049
  br i1 %guard.result116, label %merged.bb22, label %merged.bb23

merged.bb23:                                      ; preds = %predication.join101
  %guess.i.i.i10.i.i.i.i.3 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1045, double %1043
  %1050 = fneg double %guess.i.i.i10.i.i.i.i.3
  %1051 = select i1 %cmp5.i.i.i91.i.i.i.i, double %1050, double %guess.i.i.i10.i.i.i.i.3
  br label %if.end7.i.i.i.i.i.i.i
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.frexp.exp.i32.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.frexp.mant.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i1 @llvm.amdgcn.class.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.ldexp.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rcp.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fma.v2f64(<2 x double>, <2 x double>, <2 x double>) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.abs.i32(i32, i1 immarg) #1

attributes #0 = { nofree norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="128" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }
attributes #4 = { nounwind readnone }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/charitha22/cgo22ae-darm-code.git e9bc0540325ad9806313d34e84fc901496fd8be6)"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i16 1, i16 1025}
!6 = !{}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
