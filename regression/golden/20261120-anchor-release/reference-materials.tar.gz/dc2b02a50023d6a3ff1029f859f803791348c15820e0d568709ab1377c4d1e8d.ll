; ModuleID = '/data/home/chh/simplify-v2/build/dp1-removal/stable-darm/Landau/trial-258/fused.ll'
source_filename = "/home/chh/divergence-strategy-search/explorations/partition-darm-rocm-20261025/boost/generated/landau-mask0/kernel.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @evaluate(double addrspace(1)* nocapture readonly %input.coerce, double addrspace(1)* nocapture %output.coerce, i32 %n) local_unnamed_addr #0 {
entry:
  %0 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %1 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %2 = getelementptr i8, i8 addrspace(4)* %1, i64 4
  %3 = bitcast i8 addrspace(4)* %2 to i16 addrspace(4)*
  %4 = load i16, i16 addrspace(4)* %3, align 4, !range !5, !invariant.load !6
  %5 = zext i16 %4 to i32
  %6 = mul i32 %0, %5
  %7 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !7
  %add = add i32 %6, %7
  %cmp = icmp slt i32 %add, %n
  br i1 %cmp, label %if.end9.i.i, label %if.end

if.end9.i.i:                                      ; preds = %entry
  %idxprom = sext i32 %add to i64
  %arrayidx11 = getelementptr inbounds double, double addrspace(1)* %input.coerce, i64 %idxprom
  %arrayidx.val = load double, double addrspace(1)* %arrayidx11, align 8, !tbaa !8
  %cmp.i4.i.i = fcmp olt double %arrayidx.val, 0.000000e+00
  %cmp1.i.i.i = fcmp ogt double %arrayidx.val, 1.000000e+00
  %or.cond.i.i.i = or i1 %cmp.i4.i.i, %cmp1.i.i.i
  br i1 %or.cond.i.i.i, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14promote_doubleILb0EEENS2_12domain_errorILNS2_17error_policy_typeE2EEENS2_14overflow_errorILS7_2EEENS2_14default_policyESB_SB_SB_SB_SB_SB_SB_SB_SB_EEEET_RKNS0_19landau_distributionISD_T0_EERKSD_.exit, label %lor.lhs.false2.i.i.i

lor.lhs.false2.i.i.i:                             ; preds = %if.end9.i.i
  %cmp.i.i.i.i.i = fcmp uno double %arrayidx.val, 0.000000e+00
  %cmp.i3.i.i.i.i = fcmp ogt double %arrayidx.val, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i.i.i = fcmp olt double %arrayidx.val, 0xFFEFFFFFFFFFFFFF
  %lnot.i.i.i.i.not = or i1 %cmp.i3.i.i.i.i, %cmp1.i.i.i.i.i
  %brmerge = or i1 %cmp.i.i.i.i.i, %lnot.i.i.i.i.not
  br i1 %brmerge, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14promote_doubleILb0EEENS2_12domain_errorILNS2_17error_policy_typeE2EEENS2_14overflow_errorILS7_2EEENS2_14default_policyESB_SB_SB_SB_SB_SB_SB_SB_SB_EEEET_RKNS0_19landau_distributionISD_T0_EERKSD_.exit, label %if.end15.i.i

if.end15.i.i:                                     ; preds = %lor.lhs.false2.i.i.i
  %decision.interval = fcmp ult double %arrayidx.val, 1.250000e-01
  br i1 %decision.interval, label %if.else17.i35.i.i.i, label %decision.dispatch3, !decision.condition_prefix !6

if.then.i.i.i:                                    ; preds = %decision.dispatch3
  %sub.i.i.i = fsub double 1.000000e+00, %arrayidx.val
  %decision.interval5 = fcmp ult double %sub.i.i.i, 1.250000e-01
  br i1 %decision.interval5, label %if.else17.i.i.i.i, label %merged.bb5, !decision.condition_prefix !6, !decision.merged_from !12, !decision.origin !13

if.else17.i.i.i.i:                                ; preds = %if.then.i.i.i
  %8 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %sub.i.i.i) #3
  %9 = add nsw i32 %8, -1
  %10 = fcmp uno double %sub.i.i.i, 0.000000e+00
  %11 = tail call double @llvm.fabs.f64(double %sub.i.i.i) #4
  %12 = fcmp oeq double %11, 0x7FF0000000000000
  %13 = or i1 %10, %12
  %14 = select i1 %13, i32 2147483647, i32 %9
  %15 = fcmp oeq double %sub.i.i.i, 0.000000e+00
  %16 = select i1 %15, i32 -2147483648, i32 %14
  %cmp65.i.i.i.i = icmp sgt i32 %16, -65
  br i1 %cmp65.i.i.i.i, label %decision.dispatch, label %merged.bb, !decision.condition_prefix !6, !decision.merged_from !14, !decision.origin !15

decision.dispatch:                                ; preds = %if.else17.i.i.i.i
  %cmp19.i.i.i.i = icmp sgt i32 %16, -5
  %17 = icmp sgt i32 %16, -17
  %18 = select i1 %17, i32 -9, i32 -33
  %19 = icmp sgt i32 %16, %18
  %20 = select i1 %17, i32 4, i32 16
  %21 = select i1 %17, i32 8, i32 32
  %22 = select i1 %19, i32 %20, i32 %21
  %23 = select i1 %cmp19.i.i.i.i, i1 undef, i1 %17
  %24 = select i1 %cmp19.i.i.i.i, i1 undef, i1 %19
  %merged.select = select i1 %cmp19.i.i.i.i, i32 3, i32 %22
  %25 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 %merged.select) #3
  %26 = tail call double @llvm.amdgcn.frexp.mant.f64(double %25) #3
  %27 = fcmp olt double %26, 0x3FE5555555555555
  %28 = zext i1 %27 to i32
  %29 = tail call double @llvm.amdgcn.ldexp.f64(double %26, i32 %28) #3
  %30 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %25) #3
  %31 = sub nsw i32 %30, %28
  %32 = fadd double %29, -1.000000e+00
  %33 = fadd double %29, 1.000000e+00
  %34 = fsub double %33, %29
  %35 = fsub double %33, %34
  %36 = fsub double %29, %35
  %37 = fsub double 1.000000e+00, %34
  %38 = fadd double %37, %36
  %39 = tail call double @llvm.amdgcn.rcp.f64(double %33) #3
  %40 = fneg double %33
  %41 = tail call double @llvm.fma.f64(double %40, double %39, double 1.000000e+00) #3
  %42 = tail call double @llvm.fma.f64(double %41, double %39, double %39) #3
  %43 = tail call double @llvm.fma.f64(double %40, double %42, double 1.000000e+00) #3
  %44 = tail call double @llvm.fma.f64(double %43, double %42, double %42) #3
  %45 = fmul double %32, %44
  %46 = fmul double %33, %45
  %47 = fneg double %46
  %48 = tail call double @llvm.fma.f64(double %45, double %33, double %47) #3
  %49 = tail call double @llvm.fma.f64(double %45, double %38, double %48) #3
  %50 = fadd double %46, %49
  %51 = fsub double %50, %46
  %52 = fsub double %49, %51
  %53 = fsub double %32, %50
  %54 = fsub double %32, %53
  %55 = fsub double %54, %50
  %56 = fsub double %55, %52
  %57 = fadd double %53, %56
  %58 = fmul double %44, %57
  %59 = fadd double %45, %58
  %60 = fsub double %59, %45
  %61 = fsub double %58, %60
  %62 = fmul double %59, %59
  %63 = fneg double %62
  %64 = tail call double @llvm.fma.f64(double %59, double %59, double %63) #3
  %65 = fmul double %61, 2.000000e+00
  %66 = tail call double @llvm.fma.f64(double %59, double %65, double %64) #3
  %67 = tail call double @llvm.fma.f64(double %61, double %61, double %66) #3
  %68 = fadd double %62, %67
  %69 = fsub double %68, %62
  %70 = fsub double %67, %69
  %71 = tail call double @llvm.fma.f64(double %68, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %72 = tail call double @llvm.fma.f64(double %68, double %71, double 0x3FC7474DD7F4DF2E) #3
  %73 = tail call double @llvm.fma.f64(double %68, double %72, double 0x3FCC71C016291751) #3
  %74 = tail call double @llvm.fma.f64(double %68, double %73, double 0x3FD249249B27ACF1) #3
  %75 = tail call double @llvm.fma.f64(double %68, double %74, double 0x3FD99999998EF7B6) #3
  %76 = tail call double @llvm.fma.f64(double %68, double %75, double 0x3FE5555555555780) #3
  %77 = tail call double @llvm.amdgcn.ldexp.f64(double %59, i32 1) #3
  %78 = tail call double @llvm.amdgcn.ldexp.f64(double %61, i32 1) #3
  %79 = fmul double %59, %68
  %80 = fneg double %79
  %81 = tail call double @llvm.fma.f64(double %59, double %68, double %80) #3
  %82 = fmul double %61, %68
  %83 = tail call double @llvm.fma.f64(double %59, double %70, double %82) #3
  %84 = fadd double %81, %83
  %85 = fadd double %79, %84
  %86 = fsub double %85, %79
  %87 = fsub double %84, %86
  %88 = fmul double %85, %76
  %89 = fneg double %88
  %90 = tail call double @llvm.fma.f64(double %85, double %76, double %89) #3
  %91 = tail call double @llvm.fma.f64(double %87, double %76, double %90) #3
  %92 = fadd double %88, %91
  %93 = fsub double %92, %88
  %94 = fsub double %91, %93
  %95 = fadd double %77, %92
  %96 = fsub double %95, %77
  %97 = fsub double %95, %96
  %98 = fsub double %77, %97
  %99 = fsub double %92, %96
  %100 = fadd double %99, %98
  %101 = fadd double %78, %94
  %102 = fsub double %101, %78
  %103 = fsub double %101, %102
  %104 = fsub double %78, %103
  %105 = fsub double %94, %102
  %106 = fadd double %105, %104
  %107 = fadd double %101, %100
  %108 = fadd double %95, %107
  %109 = fsub double %108, %95
  %110 = fsub double %107, %109
  %111 = fadd double %106, %110
  %112 = fadd double %108, %111
  %113 = fsub double %112, %108
  %114 = fsub double %111, %113
  %115 = sitofp i32 %31 to double
  %116 = fmul double %112, 0x3FF71547652B82FE
  %117 = fneg double %116
  %118 = fmul double %112, 0x3C7777D0FFDA0D24
  %119 = insertelement <2 x double> undef, double %112, i32 0
  %120 = insertelement <2 x double> %119, double %114, i32 1
  %121 = insertelement <2 x double> undef, double %117, i32 0
  %122 = insertelement <2 x double> %121, double %118, i32 1
  %123 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %120, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %122) #3
  %124 = extractelement <2 x double> %123, i32 0
  %125 = extractelement <2 x double> %123, i32 1
  %126 = fadd double %124, %125
  %127 = fadd double %116, %126
  %128 = fsub double %127, %116
  %129 = fsub double %126, %128
  %130 = fadd double %127, %115
  %131 = fsub double %130, %115
  %132 = fsub double %131, %130
  %133 = fadd double %132, %115
  %134 = fsub double %127, %131
  %135 = fadd double %134, %133
  %136 = fadd double %129, %135
  %137 = fadd double %130, %136
  %138 = tail call double @llvm.fabs.f64(double %25) #4
  %139 = fcmp oeq double %138, 0x7FF0000000000000
  %140 = select i1 %139, double %25, double %137
  %141 = fcmp olt double %25, 0.000000e+00
  %142 = select i1 %141, double 0x7FF8000000000000, double %140
  %143 = fcmp oeq double %25, 0.000000e+00
  br i1 %cmp19.i.i.i.i, label %predication.tail84, label %predication.split83

decision.dispatch3:                               ; preds = %if.end15.i.i
  %cmp.i.i.i = fcmp ogt double %arrayidx.val, 5.000000e-01
  br i1 %cmp.i.i.i, label %if.then.i.i.i, label %decision.dispatch2, !decision.merged_from !16, !decision.origin !17

decision.dispatch2:                               ; preds = %decision.dispatch3
  %cmp.i6.i.i.i = fcmp oge double %arrayidx.val, 3.750000e-01
  %144 = fcmp oge double %arrayidx.val, 2.500000e-01
  %145 = select i1 %144, double -2.500000e-01, double -1.250000e-01
  %merged.select7 = select i1 %cmp.i6.i.i.i, double -3.750000e-01, double %145
  %146 = select i1 %cmp.i6.i.i.i, i1 undef, i1 %144
  %147 = fadd double %arrayidx.val, %merged.select7
  %148 = fmul double %147, %147
  %149 = select i1 %146, double 0x40209BA0CA602AA9, double 0x4068E6DDCC41063F
  %merged.select8 = select i1 %cmp.i6.i.i.i, double 0x402E3985AD07C11A, double %149
  %150 = fmul double %148, %merged.select8
  %151 = select i1 %146, double 0xC03AB74FA533B36E, double 0xC0752AD202523CE5
  %merged.select10 = select i1 %cmp.i6.i.i.i, double 0xC03085ADC87F148C, double %151
  %152 = fadd double %150, %merged.select10
  br i1 %cmp.i6.i.i.i, label %predication.tail108, label %predication.split107

if.else17.i35.i.i.i:                              ; preds = %if.end15.i.i
  %153 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %arrayidx.val) #3
  %154 = add nsw i32 %153, -1
  %155 = tail call double @llvm.fabs.f64(double %arrayidx.val) #4
  %156 = fcmp oeq double %155, 0x7FF0000000000000
  %157 = select i1 %156, i32 2147483647, i32 %154
  %158 = fcmp oeq double %arrayidx.val, 0.000000e+00
  %159 = select i1 %158, i32 -2147483648, i32 %157
  %cmp106.i.i.i.i = icmp sgt i32 %159, -1025
  br i1 %cmp106.i.i.i.i, label %decision.dispatch1, label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, !decision.condition_prefix !6

decision.dispatch1:                               ; preds = %if.else17.i35.i.i.i
  %cmp19.i34.i.i.i = icmp sgt i32 %159, -5
  br i1 %cmp19.i34.i.i.i, label %predication.tail, label %predication.split

_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i: ; preds = %predication.tail63, %predication.tail122, %if.else17.i35.i.i.i
  %retval.0.i.i.i = phi double [ 0xFFF0000000000000, %if.else17.i35.i.i.i ], [ %427, %predication.tail122 ], [ %659, %predication.tail63 ]
  %sub.i.i = fadd double %retval.0.i.i.i, 0.000000e+00
  br label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14promote_doubleILb0EEENS2_12domain_errorILNS2_17error_policy_typeE2EEENS2_14overflow_errorILS7_2EEENS2_14default_policyESB_SB_SB_SB_SB_SB_SB_SB_SB_EEEET_RKNS0_19landau_distributionISD_T0_EERKSD_.exit

_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14promote_doubleILb0EEENS2_12domain_errorILNS2_17error_policy_typeE2EEENS2_14overflow_errorILS7_2EEENS2_14default_policyESB_SB_SB_SB_SB_SB_SB_SB_SB_EEEET_RKNS0_19landau_distributionISD_T0_EERKSD_.exit: ; preds = %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, %lor.lhs.false2.i.i.i, %if.end9.i.i
  %retval.0.i.i = phi double [ 0x7FF8000000000000, %if.end9.i.i ], [ 0x7FF8000000000000, %lor.lhs.false2.i.i.i ], [ %sub.i.i, %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i ]
  %arrayidx712 = getelementptr inbounds double, double addrspace(1)* %output.coerce, i64 %idxprom
  store double %retval.0.i.i, double addrspace(1)* %arrayidx712, align 8, !tbaa !8
  br label %if.end

if.end:                                           ; preds = %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14promote_doubleILb0EEENS2_12domain_errorILNS2_17error_policy_typeE2EEENS2_14overflow_errorILS7_2EEENS2_14default_policyESB_SB_SB_SB_SB_SB_SB_SB_SB_EEEET_RKNS0_19landau_distributionISD_T0_EERKSD_.exit, %entry
  ret void

predication.split:                                ; preds = %decision.dispatch1
  %160 = icmp sgt i32 %159, -65
  %161 = select i1 %160, i32 -17, i32 -257
  %162 = icmp sgt i32 %159, %161
  %163 = select i1 %160, i32 -9, i32 -129
  %164 = select i1 %160, i32 -33, i32 -513
  %165 = select i1 %162, i32 %163, i32 %164
  %166 = icmp sgt i32 %159, %165
  %167 = select i1 %160, i32 4, i32 64
  %168 = select i1 %160, i32 16, i32 256
  %169 = select i1 %162, i32 %167, i32 %168
  %170 = select i1 %160, i32 8, i32 128
  %171 = select i1 %160, i32 32, i32 512
  %172 = select i1 %162, i32 %170, i32 %171
  %173 = select i1 %166, i32 %169, i32 %172
  br label %predication.tail

predication.tail:                                 ; preds = %predication.split, %decision.dispatch1
  %merged.select31 = phi i32 [ 3, %decision.dispatch1 ], [ %173, %predication.split ]
  %174 = phi i1 [ undef, %decision.dispatch1 ], [ %160, %predication.split ]
  %175 = phi i1 [ undef, %decision.dispatch1 ], [ %162, %predication.split ]
  %176 = phi i1 [ undef, %decision.dispatch1 ], [ %166, %predication.split ]
  %177 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %merged.select31) #3
  %178 = tail call double @llvm.amdgcn.frexp.mant.f64(double %177) #3
  %179 = fcmp olt double %178, 0x3FE5555555555555
  %180 = zext i1 %179 to i32
  %181 = tail call double @llvm.amdgcn.ldexp.f64(double %178, i32 %180) #3
  %182 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %177) #3
  %183 = sub nsw i32 %182, %180
  %184 = fadd double %181, -1.000000e+00
  %185 = fadd double %181, 1.000000e+00
  %186 = fsub double %185, %181
  %187 = fsub double %185, %186
  %188 = fsub double %181, %187
  %189 = fsub double 1.000000e+00, %186
  %190 = fadd double %189, %188
  %191 = tail call double @llvm.amdgcn.rcp.f64(double %185) #3
  %192 = fneg double %185
  %193 = tail call double @llvm.fma.f64(double %192, double %191, double 1.000000e+00) #3
  %194 = tail call double @llvm.fma.f64(double %193, double %191, double %191) #3
  %195 = tail call double @llvm.fma.f64(double %192, double %194, double 1.000000e+00) #3
  %196 = tail call double @llvm.fma.f64(double %195, double %194, double %194) #3
  %197 = fmul double %184, %196
  %198 = fmul double %185, %197
  %199 = fneg double %198
  %200 = tail call double @llvm.fma.f64(double %197, double %185, double %199) #3
  %201 = tail call double @llvm.fma.f64(double %197, double %190, double %200) #3
  %202 = fadd double %198, %201
  %203 = fsub double %202, %198
  %204 = fsub double %201, %203
  %205 = fsub double %184, %202
  %206 = fsub double %184, %205
  %207 = fsub double %206, %202
  %208 = fsub double %207, %204
  %209 = fadd double %205, %208
  %210 = fmul double %196, %209
  %211 = fadd double %197, %210
  %212 = fsub double %211, %197
  %213 = fsub double %210, %212
  %214 = fmul double %211, %211
  %215 = fneg double %214
  %216 = tail call double @llvm.fma.f64(double %211, double %211, double %215) #3
  %217 = fmul double %213, 2.000000e+00
  %218 = tail call double @llvm.fma.f64(double %211, double %217, double %216) #3
  %219 = tail call double @llvm.fma.f64(double %213, double %213, double %218) #3
  %220 = fadd double %214, %219
  %221 = fsub double %220, %214
  %222 = fsub double %219, %221
  %223 = tail call double @llvm.fma.f64(double %220, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %224 = tail call double @llvm.fma.f64(double %220, double %223, double 0x3FC7474DD7F4DF2E) #3
  %225 = tail call double @llvm.fma.f64(double %220, double %224, double 0x3FCC71C016291751) #3
  %226 = tail call double @llvm.fma.f64(double %220, double %225, double 0x3FD249249B27ACF1) #3
  %227 = tail call double @llvm.fma.f64(double %220, double %226, double 0x3FD99999998EF7B6) #3
  %228 = tail call double @llvm.fma.f64(double %220, double %227, double 0x3FE5555555555780) #3
  %229 = tail call double @llvm.amdgcn.ldexp.f64(double %211, i32 1) #3
  %230 = tail call double @llvm.amdgcn.ldexp.f64(double %213, i32 1) #3
  %231 = fmul double %211, %220
  %232 = fneg double %231
  %233 = tail call double @llvm.fma.f64(double %211, double %220, double %232) #3
  %234 = fmul double %213, %220
  %235 = tail call double @llvm.fma.f64(double %211, double %222, double %234) #3
  %236 = fadd double %233, %235
  %237 = fadd double %231, %236
  %238 = fsub double %237, %231
  %239 = fsub double %236, %238
  %240 = fmul double %237, %228
  %241 = fneg double %240
  %242 = tail call double @llvm.fma.f64(double %237, double %228, double %241) #3
  %243 = tail call double @llvm.fma.f64(double %239, double %228, double %242) #3
  %244 = fadd double %240, %243
  %245 = fsub double %244, %240
  %246 = fsub double %243, %245
  %247 = fadd double %229, %244
  %248 = fsub double %247, %229
  %249 = fsub double %247, %248
  %250 = fsub double %229, %249
  %251 = fsub double %244, %248
  %252 = fadd double %251, %250
  %253 = fadd double %230, %246
  %254 = fsub double %253, %230
  %255 = fsub double %253, %254
  %256 = fsub double %230, %255
  %257 = fsub double %246, %254
  %258 = fadd double %257, %256
  %259 = fadd double %253, %252
  %260 = fadd double %247, %259
  %261 = fsub double %260, %247
  %262 = fsub double %259, %261
  %263 = fadd double %258, %262
  %264 = fadd double %260, %263
  %265 = fsub double %264, %260
  %266 = fsub double %263, %265
  %267 = sitofp i32 %183 to double
  %268 = fmul double %264, 0x3FF71547652B82FE
  %269 = fneg double %268
  %270 = fmul double %264, 0x3C7777D0FFDA0D24
  %271 = insertelement <2 x double> undef, double %264, i32 0
  %272 = insertelement <2 x double> %271, double %266, i32 1
  %273 = insertelement <2 x double> undef, double %269, i32 0
  %274 = insertelement <2 x double> %273, double %270, i32 1
  %275 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %272, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %274) #3
  %276 = extractelement <2 x double> %275, i32 0
  %277 = extractelement <2 x double> %275, i32 1
  %278 = fadd double %276, %277
  %279 = fadd double %268, %278
  %280 = fsub double %279, %268
  %281 = fsub double %278, %280
  %282 = fadd double %279, %267
  %283 = fsub double %282, %267
  %284 = fsub double %283, %282
  %285 = fadd double %284, %267
  %286 = fsub double %279, %283
  %287 = fadd double %286, %285
  %288 = fadd double %281, %287
  %289 = fadd double %282, %288
  %290 = tail call double @llvm.fabs.f64(double %177) #4
  %291 = fcmp oeq double %290, 0x7FF0000000000000
  %292 = select i1 %291, double %177, double %289
  %293 = fcmp olt double %177, 0.000000e+00
  %294 = select i1 %293, double 0x7FF8000000000000, double %292
  %295 = fcmp oeq double %177, 0.000000e+00
  br i1 %cmp19.i34.i.i.i, label %predication.tail98, label %predication.split97

predication.split97:                              ; preds = %predication.tail
  %296 = select i1 %295, double 0xFFF0000000000000, double %294
  %297 = fmul double %296, %296
  %298 = select i1 %174, double 0x3E10954573CD1409, double 0x3C4C7C5BAC69CA30
  %299 = select i1 %174, double 0x3D2EEF3A19525962, double 0x3B6B104CE845D8CA
  %300 = select i1 %175, double %298, double %299
  %301 = select i1 %174, double 0x3DA028AD2F8C812A, double 0x3BDBA8610FC6ED80
  %302 = select i1 %174, double 0x3CBD95F745F985C6, double 0x3AFAA825FA80AEBC
  %303 = select i1 %175, double %301, double %302
  br label %predication.tail98

predication.tail98:                               ; preds = %predication.split97, %predication.tail
  %merged.select34 = phi double [ %294, %predication.tail ], [ %303, %predication.split97 ]
  %merged.select33 = phi double [ 0xFFF0000000000000, %predication.tail ], [ %300, %predication.split97 ]
  %merged.select32 = phi i1 [ %295, %predication.tail ], [ %176, %predication.split97 ]
  %304 = phi double [ undef, %predication.tail ], [ %296, %predication.split97 ]
  %305 = phi double [ undef, %predication.tail ], [ %297, %predication.split97 ]
  %306 = select i1 %merged.select32, double %merged.select33, double %merged.select34
  %merged.select35 = select i1 %cmp19.i34.i.i.i, double %306, double %305
  %307 = fmul double %merged.select35, %306
  br i1 %cmp19.i34.i.i.i, label %predication.tail100, label %predication.split99

predication.split99:                              ; preds = %predication.tail98
  %308 = select i1 %174, double 0xBF267FDAD7E340C0, double 0xBDEF4147E6D836F1
  %309 = select i1 %174, double 0xBE8B5F843E1F3895, double 0xBD51A9A584540197
  %310 = select i1 %175, double %308, double %309
  %311 = select i1 %174, double 0xBED9332B494FD162, double 0xBDA09F2D7C5D35C1
  %312 = select i1 %174, double 0xBE3D53C778BDFF24, double 0xBD02C12978DF0869
  %313 = select i1 %175, double %311, double %312
  %314 = select i1 %176, double %310, double %313
  %315 = fsub double %314, %307
  %316 = select i1 %174, double 0x3EBE74EDE276BA2A, double 0x3D42DFCD4EC1917B
  %317 = select i1 %174, double 0x3E015340F5605AFB, double 0x3C84A9C31CF1706D
  %318 = select i1 %175, double %316, double %317
  %319 = select i1 %174, double 0x3E6073196B230E1D, double 0x3CE3BA542B23A837
  %320 = select i1 %174, double 0x3DA2170560574A27, double 0x3C25ADBF5D5E2D40
  %321 = select i1 %175, double %319, double %320
  %322 = select i1 %176, double %318, double %321
  br label %predication.tail100

predication.tail100:                              ; preds = %predication.split99, %predication.tail98
  %merged.select37 = phi double [ 0x3F10728B75F46556, %predication.tail98 ], [ %322, %predication.split99 ]
  %merged.select36 = phi double [ %307, %predication.tail98 ], [ %305, %predication.split99 ]
  %323 = phi double [ undef, %predication.tail98 ], [ %315, %predication.split99 ]
  %324 = fmul double %merged.select36, %merged.select37
  %325 = select i1 %174, double 0xBF74D4DF73958DD4, double 0xBE80201FEE58D5EB
  %326 = select i1 %174, double 0xBEFB16A0F7496BD2, double 0xBE02B6DCAE997177
  %327 = select i1 %175, double %325, double %326
  %328 = select i1 %174, double 0xBF383759EF2EC40C, double 0xBE4167CB2DE9484D
  %329 = select i1 %174, double 0xBEBDB51233A64720, double 0xBDC40F84D4D29208
  %330 = select i1 %175, double %328, double %329
  %331 = select i1 %176, double %327, double %330
  %merged.select46 = select i1 %cmp19.i34.i.i.i, double 0xBFB1D997333851F3, double %331
  %332 = fsub double %merged.select46, %324
  %merged.select76 = select i1 %cmp19.i34.i.i.i, double 0x3F713B96D78DC454, double %332
  %333 = fmul double %merged.select36, %merged.select76
  br i1 %cmp19.i34.i.i.i, label %predication.second, label %predication.first

predication.first:                                ; preds = %predication.tail100
  %334 = fmul double %305, %323
  %335 = select i1 %174, double 0xBFB0A4004AB9FA2F, double 0xBEFCEEB9D33660E7
  %336 = select i1 %174, double 0xBF5751B27C5C9BFB, double 0xBEA134E225D1132C
  %337 = select i1 %175, double %335, double %336
  %338 = select i1 %174, double 0xBF843505D28DAEAC, double 0xBECFA9C0D9C5E4A9
  %339 = select i1 %174, double 0xBF2A2DC3D4DAE3C5, double 0xBE729A0FDD66F4F2
  %340 = select i1 %175, double %338, double %339
  %341 = select i1 %176, double %337, double %340
  %342 = fadd double %334, %341
  %343 = select i1 %174, double 0xBFD95EAC9AE91EB0, double 0xBF69297448457D24
  %344 = select i1 %174, double 0xBFA370C135EBE2E0, double 0xBF2EA5E4F352FCF9
  %345 = select i1 %175, double %343, double %344
  %346 = select i1 %174, double 0xBFC045854783A19F, double 0xBF4BE8F64D9A4925
  %347 = select i1 %174, double 0xBF865CF2B86753CE, double 0xBF10B2EEE9D945FC
  %348 = select i1 %175, double %346, double %347
  %349 = select i1 %176, double %345, double %348
  br label %predication.join

predication.second:                               ; preds = %predication.tail100
  %350 = fsub double 0xBFDBC9E8A9D4EBD0, %333
  br label %predication.join

predication.join:                                 ; preds = %predication.second, %predication.first
  %merged.select83 = phi double [ %304, %predication.first ], [ %306, %predication.second ]
  %merged.select78 = phi double [ %342, %predication.first ], [ %332, %predication.second ]
  %guard.value105 = phi double [ %349, %predication.first ], [ undef, %predication.second ]
  %guard.value106 = phi double [ undef, %predication.first ], [ %350, %predication.second ]
  %351 = fadd double %333, %guard.value105
  %352 = fmul double %merged.select36, %merged.select78
  %merged.select80 = select i1 %cmp19.i34.i.i.i, double %guard.value106, double %351
  %353 = fmul double %merged.select36, %merged.select80
  %354 = select i1 %174, double 0xBFF1F8D8D4096576, double 0xBFC4DA929BC925CB
  %355 = select i1 %174, double 0xBFDED3DE58969B0C, double 0xBFAA00AF73AD4FC4
  %356 = select i1 %175, double %354, double %355
  %357 = select i1 %174, double 0xBFE8CAFD8375357B, double 0xBFB77177F6F25868
  %358 = select i1 %174, double 0xBFD232BB27D90F0B, double 0xBF9C8D7861FA32DF
  %359 = select i1 %175, double %357, double %358
  %360 = select i1 %176, double %356, double %359
  %merged.select81 = select i1 %cmp19.i34.i.i.i, double 0xBFF164811EDD50A9, double %360
  %361 = fadd double %352, %merged.select81
  %362 = select i1 %174, double 0xBFF2AD2669F16A11, double 0xC00A6041983C62F2
  %363 = select i1 %174, double 0xC002991536F3B198, double 0xC010D5424AFC6707
  %364 = select i1 %175, double %362, double %363
  %365 = select i1 %174, double 0xBFFC8922BA24935C, double 0xC00E0DA8FADB7C8C
  %366 = select i1 %174, double 0xC00695E2D61C0C6E, double 0xC0129EFFBA10F842
  %367 = select i1 %175, double %365, double %366
  %368 = select i1 %176, double %364, double %367
  %merged.select82 = select i1 %cmp19.i34.i.i.i, double 0xBFEC1147FADC1DD1, double %368
  %369 = fadd double %353, %merged.select82
  %370 = fmul double %merged.select83, %361
  %371 = fsub double %369, %370
  %372 = select i1 %174, double 0x3E9C1C977F10265B, double 0x3D18B1987155CEA4
  %373 = select i1 %174, double 0x3DDA87308BB58726, double 0x3C579C2A1977500A
  %374 = select i1 %175, double %372, double %373
  %375 = select i1 %174, double 0x3E3B89766DC0E470, double 0x3CB8106C9C12C679
  %376 = select i1 %174, double 0x3D7985F69E9DFA4C, double 0x3BF74C460513871A
  %377 = select i1 %175, double %375, double %376
  %378 = select i1 %176, double %374, double %377
  %merged.select85 = select i1 %cmp19.i34.i.i.i, double 0x3EEE329A0EE79745, double %378
  %379 = fmul double %merged.select36, %merged.select85
  %380 = select i1 %174, double 0x3F5F07E1D05A5DFD, double 0x3E5C80E1BF396002
  %381 = select i1 %174, double 0x3EDDEB134B240B6B, double 0x3DDBA32CD8E6FFE2
  %382 = select i1 %175, double %380, double %381
  %383 = select i1 %174, double 0x3F1EA8AD4669BB53, double 0x3E1C00B930B6EDE4
  %384 = select i1 %174, double 0x3E9D26DA9BE0FF59, double 0x3D9B6269284AABC4
  %385 = select i1 %175, double %383, double %384
  %386 = select i1 %176, double %382, double %385
  %merged.select86 = select i1 %cmp19.i34.i.i.i, double 0x3F9F1FF0999DE692, double %386
  %387 = fadd double %379, %merged.select86
  %388 = select i1 %174, double 0x3F0B438FF2C388C0, double 0x3DC87E4D72BFB8FA
  %389 = select i1 %174, double 0x3E6A03AD8C7D561F, double 0x3D27942AF0BDEC40
  %390 = select i1 %175, double %388, double %389
  %391 = select i1 %174, double 0x3EBAD46BFAE07B75, double 0x3D77F69D5EF2EF55
  %392 = select i1 %174, double 0x3E192F9212752578, double 0x3CD7504574599FA7
  %393 = select i1 %175, double %391, double %392
  %394 = select i1 %176, double %390, double %393
  %merged.select88 = select i1 %cmp19.i34.i.i.i, double 0x3F56CF90A3508EC2, double %394
  %395 = fmul double %merged.select36, %merged.select88
  %396 = select i1 %174, double 0x3F9DF8C6DBF0F003, double 0x3EDC231F3DEEB6F9
  %397 = select i1 %174, double 0x3F3D2E4291C2C2D0, double 0x3E7B7CAE58B9ECC4
  %398 = select i1 %175, double %396, double %397
  %399 = select i1 %174, double 0x3F6DB7207E85C0EF, double 0x3EABC3297454E377
  %400 = select i1 %174, double 0x3F0C9E4DE67437CE, double 0x3E4B4BB19F333FF9
  %401 = select i1 %175, double %399, double %400
  %402 = select i1 %176, double %398, double %401
  %merged.select89 = select i1 %cmp19.i34.i.i.i, double 0x3FCFAFFF6FF925DC, double %402
  %403 = fadd double %395, %merged.select89
  %404 = fmul double %merged.select36, %387
  %405 = fmul double %merged.select36, %403
  br i1 %cmp19.i34.i.i.i, label %predication.tail122, label %predication.split121

predication.split121:                             ; preds = %predication.join
  %406 = select i1 %174, double 0x3FCBB079F2C252E4, double 0x3F4A8E38348FD9B2
  %407 = select i1 %174, double 0x3F8B35517DD09962, double 0x3F0A244903F50D45
  %408 = select i1 %175, double %406, double %407
  %409 = select i1 %174, double 0x3FAB895727F039DB, double 0x3F2A514E711D09AD
  %410 = select i1 %174, double 0x3F6ADBBA962C2080, double 0x3EEA04DE23809639
  %411 = select i1 %175, double %409, double %410
  %412 = select i1 %176, double %408, double %411
  %413 = fadd double %404, %412
  %414 = select i1 %174, double 0x3FE82B2F4B11BB5A, double 0x3FA7ABC63BB9671C
  %415 = select i1 %174, double 0x3FC7F5B66495DDB6, double 0x3F877C1A4ABB8039
  %416 = select i1 %175, double %414, double %415
  %417 = select i1 %174, double 0x3FD81A505016D302, double 0x3F97906FA7E2C9CF
  %418 = select i1 %174, double 0x3FB7CE42A74538CD, double 0x3F776DDB0ABF64AF
  %419 = select i1 %175, double %417, double %418
  %420 = select i1 %176, double %416, double %419
  br label %predication.tail122

predication.tail122:                              ; preds = %predication.split121, %predication.join
  %merged.select93 = phi double [ 0x3FEAD689E3DCFB29, %predication.join ], [ %420, %predication.split121 ]
  %merged.select92 = phi double [ %404, %predication.join ], [ %405, %predication.split121 ]
  %421 = phi double [ undef, %predication.join ], [ %413, %predication.split121 ]
  %422 = fadd double %merged.select92, %merged.select93
  %423 = fmul double %305, %421
  %merged.select94 = select i1 %cmp19.i34.i.i.i, double %405, double %423
  %424 = fadd double %merged.select94, 1.000000e+00
  %425 = fmul double %merged.select83, %422
  %426 = fsub double %424, %425
  %427 = fdiv double %371, %426
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

predication.split83:                              ; preds = %decision.dispatch
  %428 = select i1 %143, double 0xFFF0000000000000, double %142
  %429 = fmul double %428, %428
  %430 = select i1 %23, double 0x3E5572883C081004, double 0x3C79498433579691
  %431 = select i1 %23, double 0x3DFAC4B4389CCCBF, double 0x3E36A0C73E300E6B
  br label %predication.tail84

predication.tail84:                               ; preds = %predication.split83, %decision.dispatch
  %merged.select3 = phi double [ %142, %decision.dispatch ], [ %431, %predication.split83 ]
  %merged.select2 = phi double [ 0xFFF0000000000000, %decision.dispatch ], [ %430, %predication.split83 ]
  %merged.select1 = phi i1 [ %143, %decision.dispatch ], [ %19, %predication.split83 ]
  %432 = phi double [ undef, %decision.dispatch ], [ %428, %predication.split83 ]
  %433 = phi double [ undef, %decision.dispatch ], [ %429, %predication.split83 ]
  %434 = select i1 %merged.select1, double %merged.select2, double %merged.select3
  %merged.select4 = select i1 %cmp19.i.i.i.i, double %434, double %433
  %435 = fmul double %merged.select4, %434
  br i1 %cmp19.i.i.i.i, label %predication.tail86, label %predication.split85

predication.split85:                              ; preds = %predication.tail84
  %436 = select i1 %24, double 0x3EF19780C67DB179, double 0x3EA390F0E916846C
  %437 = fsub double 0x3E495C1E8002A2F3, %435
  %438 = select i1 %23, double undef, double %437
  %439 = fsub double %436, %435
  %440 = fadd double %435, 0x3EC7DFD742A8FC88
  %441 = select i1 %24, double %438, double %440
  %442 = select i1 %23, double %439, double %441
  %443 = select i1 %23, double 0x3EAD6D38A29E7848, double 0x3DE864F7A333A155
  %444 = select i1 %23, double 0x3E3DBF605CEF30C0, double 0x3E79AA80A6F64859
  %445 = select i1 %24, double %443, double %444
  br label %predication.tail86

predication.tail86:                               ; preds = %predication.split85, %predication.tail84
  %merged.select6 = phi double [ 0x3EDBD077F856B461, %predication.tail84 ], [ %445, %predication.split85 ]
  %merged.select5 = phi double [ %435, %predication.tail84 ], [ %433, %predication.split85 ]
  %446 = phi double [ undef, %predication.tail84 ], [ %442, %predication.split85 ]
  %447 = fmul double %merged.select5, %merged.select6
  %448 = select i1 %23, double 0x3F3931D0B31857FC, double 0x3E9EABE0F5513556
  %449 = select i1 %23, double 0x3EF49382D31EBA5E, double 0x3F097D0FE1D7D8F2
  %450 = select i1 %24, double %448, double %449
  %451 = fadd double %447, %450
  %452 = fsub double 0x3F78C25CB1F33D41, %447
  %guard.value = select i1 %cmp19.i.i.i.i, double %452, double undef
  %guard.result = select i1 %cmp19.i.i.i.i, double 0x3F40AF40801BC234, double %451
  %453 = fmul double %merged.select5, %guard.result
  br i1 %cmp19.i.i.i.i, label %predication.tail93, label %predication.split92

predication.split92:                              ; preds = %predication.tail86
  %454 = fmul double %433, %446
  %455 = select i1 %23, double 0x3F6DC47CA5637DCD, double 0x3EE98327A9C0F60B
  %456 = select i1 %23, double 0x3F391B9374A4479C, double 0x3F46894B5AD794D5
  %457 = select i1 %24, double %455, double %456
  %458 = fadd double %454, %457
  %459 = select i1 %23, double 0x3F9D4AC2F9914DE6, double 0x3F2EDE27BF6E2989
  %460 = select i1 %23, double 0x3F756FF813B95713, double 0x3F7DB25E4C9E7FD4
  %461 = select i1 %24, double %459, double %460
  br label %predication.tail93

predication.tail93:                               ; preds = %predication.split92, %predication.tail86
  %merged.select18 = phi double [ %434, %predication.tail86 ], [ %432, %predication.split92 ]
  %merged.select11 = phi double [ %guard.value, %predication.tail86 ], [ %458, %predication.split92 ]
  %merged.select9 = phi double [ 0x3FA89B8093A2295C, %predication.tail86 ], [ %461, %predication.split92 ]
  %462 = fadd double %453, %merged.select9
  %463 = fmul double %merged.select5, %merged.select11
  %464 = fmul double %merged.select5, %462
  %465 = select i1 %23, double 0x3FC0EDB6A0343FA2, double 0x3F6B2BC23526CCD2
  %466 = select i1 %23, double 0x3FA7D057D85283A0, double 0x3FAC2661E760FEEA
  %467 = select i1 %24, double %465, double %466
  %merged.select13 = select i1 %cmp19.i.i.i.i, double 0x3FCF140D06064BE5, double %467
  %468 = fadd double %463, %merged.select13
  %469 = select i1 %23, double 0x3FDB50BA04B5A380, double 0x3FA0CC4805CE702A
  %470 = select i1 %23, double 0x3FD02ACAC9630F2A, double 0x3FD12C697DF74133
  %471 = select i1 %24, double %469, double %470
  %merged.select14 = select i1 %cmp19.i.i.i.i, double 0x3FE570FCC3570002, double %471
  %472 = fadd double %464, %merged.select14
  %473 = fmul double %433, %468
  %474 = select i1 %24, double %472, double %468
  %475 = or i1 %cmp19.i.i.i.i, %23
  %merged.select16 = select i1 %475, double %468, double %474
  %476 = fmul double %merged.select5, %merged.select16
  %.op = fadd double %473, 0x3FCA6EBA13EF1190
  %477 = select i1 %cmp19.i.i.i.i, double 0x7FF8000000000000, double %.op
  %478 = select i1 %23, double 0x3FE698C26DDFFE1D, double 0x3FE460008BE31186
  %479 = select i1 %23, double 0x3FE4BE220CFACC02, double 0x3FE45F306F7BD51E
  %480 = select i1 %24, double %478, double %479
  %481 = select i1 %475, double undef, double %477
  %merged.select17 = select i1 %cmp19.i.i.i.i, double 0x3FE6B9F7A03E5CA5, double %480
  %482 = fadd double %476, %merged.select17
  %483 = select i1 %24, double %481, double %472
  %merged.select19 = select i1 %475, double %472, double %483
  %484 = fmul double %merged.select18, %merged.select19
  %485 = fsub double %482, %484
  br i1 %cmp19.i.i.i.i, label %predication.tail105, label %predication.split104

predication.split104:                             ; preds = %predication.tail93
  %486 = select i1 %23, double 0x3E5DE5C0706A9406, double 0x3DF328AAD4028837
  %487 = select i1 %23, double 0x3E04EA9B9D5ED2D3, double 0x3E41C5A32EBEB036
  %488 = select i1 %24, double %486, double %487
  %489 = fmul double %433, %488
  %490 = select i1 %23, double 0x3F004FBC687921D1, double 0x3EA816907A00ED43
  %491 = select i1 %23, double 0x3EAF46C18AB8D809, double 0x3ED2C03A84AD3954
  %492 = select i1 %24, double %490, double %491
  %493 = fneg double %489
  %494 = select i1 %23, double %493, double %489
  %495 = fadd double %492, %494
  %496 = select i1 %23, double 0x3EB3C06C21CA66A9, double 0x3E53EB10DB8936AA
  %497 = select i1 %23, double 0x3E46A463B527030B, double 0x3E842875EC14B32B
  %498 = select i1 %24, double %496, double %497
  br label %predication.tail105

predication.tail105:                              ; preds = %predication.split104, %predication.tail93
  %merged.select21 = phi double [ 0x3F44ACEECE75B689, %predication.tail93 ], [ %498, %predication.split104 ]
  %499 = phi double [ undef, %predication.tail93 ], [ %495, %predication.split104 ]
  %500 = fmul double %merged.select5, %merged.select21
  %501 = select i1 %23, double 0x3F41E908A5D59DEF, double 0x3EF409E2C6442ECB
  %502 = select i1 %23, double 0x3EFFDAE904854CF0, double 0x3F1404C590EDED62
  %503 = select i1 %24, double %501, double %502
  %merged.select23 = select i1 %cmp19.i.i.i.i, double 0x3FB48180AD0CAC24, double %503
  %504 = fadd double %500, %merged.select23
  %merged.select25 = select i1 %cmp19.i.i.i.i, double 0x3F8497E40449A14F, double %504
  %505 = fmul double %merged.select5, %merged.select25
  br i1 %cmp19.i.i.i.i, label %predication.tail111, label %predication.split110

predication.split110:                             ; preds = %predication.tail105
  %506 = fmul double %433, %499
  %507 = select i1 %23, double 0x3F78B07BF251DF23, double 0x3F383DD0A4891FC2
  %508 = select i1 %23, double 0x3F43F5B84727219B, double 0x3F51B33174D75BD6
  %509 = select i1 %24, double %507, double %508
  %510 = fadd double %506, %509
  %511 = select i1 %23, double 0x3FA6C0CF25D026FF, double 0x3F75579E42D43198
  %512 = select i1 %23, double 0x3F80B3A886D078D5, double 0x3F8752E2DAA7BC3C
  %513 = select i1 %24, double %511, double %512
  br label %predication.tail111

predication.tail111:                              ; preds = %predication.split110, %predication.tail105
  %merged.select28 = phi double [ %504, %predication.tail105 ], [ %510, %predication.split110 ]
  %merged.select26 = phi double [ 0x3FD7722E0F8ACAA8, %predication.tail105 ], [ %513, %predication.split110 ]
  %514 = fadd double %505, %merged.select26
  %515 = fmul double %merged.select5, %merged.select28
  %516 = fmul double %merged.select5, %514
  br i1 %cmp19.i.i.i.i, label %merged.bb, label %predication.split112

predication.split112:                             ; preds = %predication.tail111
  %517 = select i1 %23, double 0x3FCB01CF712825D2, double 0x3FAA6202C31DEDAF
  %518 = select i1 %23, double 0x3FB2BDAF5E161D54, double 0x3FB61BE1285F7AC2
  %519 = select i1 %24, double %517, double %518
  %520 = fadd double %515, %519
  %521 = select i1 %23, double 0x3FE41A23912FC356, double 0x3FD4C357E0FB8D40
  %522 = select i1 %23, double 0x3FD98FFFB01689E6, double 0x3FDAF9DE32D5716C
  %523 = select i1 %24, double %521, double %522
  br label %merged.bb

predication.split107:                             ; preds = %decision.dispatch2
  %524 = select i1 %146, double 0x40379E848D9E949D, double 0x4080D1B58D04D9C9
  %525 = fmul double %148, %524
  %526 = select i1 %146, double 0x4037940F708222AF, double 0x407CB1D75E0C4F58
  %527 = fsub double %526, %525
  %528 = fmul double %148, %152
  br label %predication.tail108

predication.tail108:                              ; preds = %predication.split107, %decision.dispatch2
  %merged.select12 = phi double [ 0x401BFCD2EDF5ACC4, %decision.dispatch2 ], [ %527, %predication.split107 ]
  %529 = phi double [ undef, %decision.dispatch2 ], [ %528, %predication.split107 ]
  %530 = fmul double %148, %merged.select12
  %531 = select i1 %146, double 0x4032087237C73F8C, double 0x4069326C1159E9DB
  %532 = fadd double %529, %531
  %533 = fsub double 0x40101FAA3F78B28E, %530
  %guard.value6 = select i1 %cmp.i6.i.i.i, double undef, double %532
  %guard.value8 = select i1 %cmp.i6.i.i.i, double %533, double undef
  br i1 %cmp.i6.i.i.i, label %merged.bb21, label %merged.branch.split2

merged.bb:                                        ; preds = %predication.split112, %predication.tail111, %if.else17.i.i.i.i
  %unify.phi6 = phi double [ undef, %if.else17.i.i.i.i ], [ %516, %predication.tail111 ], [ %516, %predication.split112 ]
  %unify.phi5 = phi double [ undef, %if.else17.i.i.i.i ], [ %485, %predication.tail111 ], [ %485, %predication.split112 ]
  %unify.phi4 = phi double [ undef, %if.else17.i.i.i.i ], [ %merged.select18, %predication.tail111 ], [ %merged.select18, %predication.split112 ]
  %unify.phi3 = phi double [ undef, %if.else17.i.i.i.i ], [ %433, %predication.tail111 ], [ %433, %predication.split112 ]
  %unify.phi = phi i1 [ undef, %if.else17.i.i.i.i ], [ %cmp19.i.i.i.i, %predication.tail111 ], [ false, %predication.split112 ]
  %moved.phi2 = phi double [ undef, %if.else17.i.i.i.i ], [ undef, %predication.tail111 ], [ %520, %predication.split112 ]
  %moved.phi1 = phi double [ undef, %if.else17.i.i.i.i ], [ %515, %predication.tail111 ], [ %516, %predication.split112 ]
  %moved.phi = phi double [ undef, %if.else17.i.i.i.i ], [ 0x3FED6593E87A041B, %predication.tail111 ], [ %523, %predication.split112 ]
  br i1 %cmp65.i.i.i.i, label %predication.split45, label %merged.bb5

predication.split45:                              ; preds = %merged.bb
  %534 = fadd double %moved.phi1, %moved.phi
  %535 = fmul double %unify.phi3, %moved.phi2
  %536 = select i1 %unify.phi, double %unify.phi6, double %535
  %537 = fadd double %536, 1.000000e+00
  %538 = fmul double %unify.phi4, %534
  %539 = fsub double %537, %538
  br label %merged.bb5

merged.bb5:                                       ; preds = %predication.split45, %merged.bb, %if.then.i.i.i
  %moved.phi4 = phi double [ undef, %if.then.i.i.i ], [ 0x400921FB54442D18, %merged.bb ], [ %539, %predication.split45 ]
  %moved.phi3 = phi double [ undef, %if.then.i.i.i ], [ 2.000000e+00, %merged.bb ], [ %unify.phi5, %predication.split45 ]
  br i1 %decision.interval5, label %merged.bb21, label %predication.split51

predication.split51:                              ; preds = %merged.bb5
  %540 = fcmp oge double %sub.i.i.i, 2.500000e-01
  %541 = fcmp oge double %sub.i.i.i, 3.750000e-01
  %542 = select i1 %541, double -3.750000e-01, double -2.500000e-01
  %543 = select i1 %540, double 0x4030441296C5FB34, double 0x40990C9A56964108
  %544 = select i1 %540, double %542, double -1.250000e-01
  %545 = select i1 %540, i1 %541, i1 undef
  %546 = fadd double %sub.i.i.i, %544
  %547 = fmul double %546, %546
  %548 = select i1 %545, double 0x403C1881A9A265FD, double 0x40277F82F0DAE120
  %549 = select i1 %540, double %548, double 0x4094388834A6E4C6
  %550 = fmul double %547, %549
  %551 = select i1 %545, double 0x404790211A5124A0, double 0x404307CEA86A355B
  %552 = fsub double %551, %550
  %553 = select i1 %545, double 0x40127122E53E19ED, double 0x4040C02F41527F9A
  %554 = fadd double %550, 0xC0ADEA3D7D257F67
  %555 = select i1 %540, double %553, double 0x40A377E7779F4961
  %556 = select i1 %540, double %552, double %554
  %557 = fmul double %547, %555
  %558 = select i1 %545, double 0xBFF88D9974F43E7E, double 0xC043CD5B8EF4636A
  %559 = select i1 %540, double %558, double 0xC0A6DC23D7E5E636
  %560 = fadd double %557, %559
  %561 = fmul double %547, %556
  %562 = fmul double %547, %560
  %563 = select i1 %545, double 0xC0321838C11B2DD4, double 0xC037479D2EDA47AB
  %564 = select i1 %540, double %563, double 0x407EB1E0C584548E
  %565 = fadd double %561, %564
  %566 = select i1 %545, double 0xBFF1103F72ECFAA8, double 0x40158CCE32F91DD3
  %567 = select i1 %540, double %566, double 0x4081F4137E2FB1C7
  %568 = fadd double %562, %567
  %569 = fmul double %547, %565
  %570 = select i1 %540, double %565, double %568
  %571 = fmul double %547, %570
  %572 = select i1 %545, double 0x3FF5040D3E43FC6C, double 0x400468120D7EB3C7
  %573 = fadd double %569, 0x405A8654D41DC46C
  %574 = select i1 %540, double %572, double 0x4016B9F7A03E5CA6
  %575 = fadd double %571, %574
  %576 = select i1 %540, double %568, double %573
  %577 = fmul double %546, %576
  %578 = select i1 %540, double %577, double %575
  %579 = select i1 %540, double %575, double %577
  %580 = fadd double %578, %579
  %581 = select i1 %545, double 0x4003830831C63CF0, double 0x40179A9AC0DA87EF
  %582 = select i1 %540, double %581, double 0x409B9068A3C78607
  %583 = fmul double %547, %582
  %584 = fsub double %543, %583
  %585 = fadd double %583, 0xC03ABCE1630E61C0
  %586 = select i1 %545, double %584, double %585
  %587 = select i1 %545, double 0x401D7BFF8CC54FA6, double 0x4000D00D57F2CBBD
  %588 = select i1 %540, double %587, double 0x408105AF09F369D0
  %589 = fmul double %547, %588
  %590 = select i1 %545, double 0xC026402DD156D3FC, double 0xC0226B8874380C5B
  %591 = fadd double %589, %590
  %592 = fsub double 0x40912C23C604419C, %589
  %593 = select i1 %540, double %591, double %592
  %594 = select i1 %540, double %586, double %584
  %595 = fmul double %547, %594
  %596 = fmul double %547, %593
  %597 = select i1 %545, double 0xC031083D20CE0F89, double 0x402AF4FD59F9A777
  %598 = select i1 %540, double %597, double 0x4070760E04B9BCBD
  %599 = fadd double %595, %598
  %600 = select i1 %545, double 0x3FF51C8655DB120C, double 0x401E18FAC448D58A
  %601 = select i1 %540, double %600, double 0x403AF5DBE51CBD80
  %602 = fadd double %596, %601
  %603 = fmul double %547, %599
  %604 = and i1 %540, %545
  %605 = select i1 %604, double %602, double %599
  %606 = fmul double %547, %605
  %607 = fadd double %603, 0x4012D71DC7267483
  %608 = select i1 %540, double %607, double undef
  %609 = fadd double %606, 1.000000e+00
  %610 = select i1 %604, double %608, double %602
  br label %merged.bb21

merged.bb21:                                      ; preds = %predication.tail108, %merged.branch.split2, %predication.split51, %merged.bb5
  %unify.phi20 = phi double [ %148, %predication.tail108 ], [ undef, %merged.bb5 ], [ undef, %predication.split51 ], [ %148, %merged.branch.split2 ]
  %unify.phi19 = phi double [ %147, %predication.tail108 ], [ undef, %merged.bb5 ], [ undef, %predication.split51 ], [ %147, %merged.branch.split2 ]
  %unify.phi18 = phi i1 [ %146, %predication.tail108 ], [ undef, %merged.bb5 ], [ undef, %predication.split51 ], [ %146, %merged.branch.split2 ]
  %unify.phi17 = phi i1 [ true, %predication.tail108 ], [ undef, %merged.bb5 ], [ undef, %predication.split51 ], [ false, %merged.branch.split2 ]
  %unify.phi16 = phi i1 [ undef, %predication.tail108 ], [ %decision.interval5, %merged.bb5 ], [ false, %predication.split51 ], [ undef, %merged.branch.split2 ]
  %moved.phi15 = phi double [ undef, %predication.tail108 ], [ undef, %merged.bb5 ], [ undef, %predication.split51 ], [ %661, %merged.branch.split2 ]
  %moved.phi14 = phi double [ undef, %predication.tail108 ], [ undef, %merged.bb5 ], [ undef, %predication.split51 ], [ %guard.value6, %merged.branch.split2 ]
  %moved.phi13 = phi double [ %guard.value8, %predication.tail108 ], [ undef, %merged.bb5 ], [ undef, %predication.split51 ], [ undef, %merged.branch.split2 ]
  %moved.phi12 = phi double [ %152, %predication.tail108 ], [ undef, %merged.bb5 ], [ undef, %predication.split51 ], [ %guard.value6, %merged.branch.split2 ]
  %moved.phi11 = phi double [ 0x400F06502EC2116F, %predication.tail108 ], [ undef, %merged.bb5 ], [ undef, %predication.split51 ], [ 0xC024B04741F7A527, %merged.branch.split2 ]
  %moved.phi10 = phi double [ 0xC019669B84791897, %predication.tail108 ], [ undef, %merged.bb5 ], [ undef, %predication.split51 ], [ 0x405440452173DCA6, %merged.branch.split2 ]
  %moved.phi9 = phi double [ undef, %predication.tail108 ], [ undef, %merged.bb5 ], [ %609, %predication.split51 ], [ undef, %merged.branch.split2 ]
  %moved.phi8 = phi i1 [ undef, %predication.tail108 ], [ undef, %merged.bb5 ], [ %604, %predication.split51 ], [ undef, %merged.branch.split2 ]
  %moved.phi7 = phi double [ undef, %predication.tail108 ], [ %sub.i.i.i, %merged.bb5 ], [ %546, %predication.split51 ], [ undef, %merged.branch.split2 ]
  %moved.phi6 = phi double [ undef, %predication.tail108 ], [ %moved.phi4, %merged.bb5 ], [ %610, %predication.split51 ], [ undef, %merged.branch.split2 ]
  %moved.phi5 = phi double [ undef, %predication.tail108 ], [ %moved.phi3, %merged.bb5 ], [ %580, %predication.split51 ], [ undef, %merged.branch.split2 ]
  br i1 %cmp.i.i.i, label %predication.tail63, label %predication.split62

predication.split62:                              ; preds = %merged.bb21
  %611 = fmul double %unify.phi20, %moved.phi12
  %612 = select i1 %unify.phi18, double %moved.phi14, double %moved.phi15
  %613 = select i1 %unify.phi17, double %moved.phi13, double %612
  %614 = fmul double %unify.phi20, %613
  %615 = fadd double %611, %moved.phi11
  %616 = select i1 %unify.phi18, double 0xBFDABCA86BC1374B, double 0xBFEC1147FADC1DD1
  %617 = select i1 %unify.phi17, double 0x3FA32D6622EF65AB, double %616
  %618 = fadd double %614, %617
  %619 = select i1 %unify.phi18, double %moved.phi15, double %615
  %620 = select i1 %unify.phi17, double %615, double %619
  %621 = fmul double %unify.phi19, %620
  %622 = select i1 %unify.phi18, double %621, double %618
  %623 = select i1 %unify.phi18, double %618, double %621
  %624 = select i1 %unify.phi17, double %618, double %622
  %625 = select i1 %unify.phi17, double %621, double %623
  %626 = fadd double %624, %625
  %627 = select i1 %unify.phi18, double 0x40298D77C48BA327, double 0x40705EDC8D95F7FC
  %628 = select i1 %unify.phi17, double 0x3FF9609F779C5E99, double %627
  %629 = fmul double %unify.phi20, %628
  %630 = select i1 %unify.phi18, double 0xC0311C9898526451, double 0xC06F965D272FAC7A
  %631 = fadd double %629, %630
  %632 = fsub double 0x4023738A7902B742, %629
  %633 = select i1 %unify.phi17, double %632, double %631
  %634 = select i1 %unify.phi18, double 0x401AE4210EC8894B, double 0x40686BB6228197AD
  %635 = select i1 %unify.phi17, double 0x4005C97BEA6BDB5A, double %634
  %636 = fmul double %unify.phi20, %635
  %637 = select i1 %unify.phi18, double 0x4002DB11078FC43E, double 0x40530C7F6C363BB9
  %638 = select i1 %unify.phi17, double 0x3FD3B07AFB10BC79, double %637
  %639 = fsub double %638, %636
  %640 = fmul double %unify.phi20, %633
  %641 = fmul double %unify.phi20, %639
  %642 = fadd double %640, %moved.phi10
  %643 = select i1 %unify.phi18, double %640, double %641
  %644 = select i1 %unify.phi18, double 0x40157F95E5CB1B22, double 0x40306AF25EBB4DDE
  %645 = select i1 %unify.phi17, double %641, double %643
  %646 = select i1 %unify.phi17, double 0x3FDC05F5C732E888, double %644
  %647 = fadd double %645, %646
  br label %predication.tail63

predication.tail63:                               ; preds = %predication.split62, %merged.bb21
  %merged.select59 = phi double [ %moved.phi5, %merged.bb21 ], [ %626, %predication.split62 ]
  %merged.select56 = phi i1 [ %unify.phi16, %merged.bb21 ], [ %unify.phi17, %predication.split62 ]
  %merged.select52 = phi i1 [ %moved.phi8, %merged.bb21 ], [ %unify.phi17, %predication.split62 ]
  %merged.select51 = phi double [ %moved.phi9, %merged.bb21 ], [ %641, %predication.split62 ]
  %merged.select50 = phi i1 [ %moved.phi8, %merged.bb21 ], [ %unify.phi18, %predication.split62 ]
  %merged.select43 = phi double [ %moved.phi6, %merged.bb21 ], [ %642, %predication.split62 ]
  %merged.select39 = phi double [ %moved.phi7, %merged.bb21 ], [ %unify.phi20, %predication.split62 ]
  %648 = phi double [ undef, %merged.bb21 ], [ %647, %predication.split62 ]
  %649 = fmul double %merged.select39, %merged.select43
  %650 = select i1 %merged.select50, double %merged.select51, double %649
  %merged.select53 = select i1 %cmp.i.i.i, double %moved.phi9, double %650
  %651 = select i1 %merged.select52, double %649, double %merged.select53
  %merged.select54 = select i1 %cmp.i.i.i, double %650, double %651
  %merged.select55 = select i1 %cmp.i.i.i, double %651, double 1.000000e+00
  %652 = fadd double %merged.select54, %merged.select55
  %653 = fmul double %unify.phi19, %648
  %654 = select i1 %unify.phi18, double %652, double %653
  %655 = select i1 %unify.phi18, double %653, double %652
  %656 = select i1 %unify.phi17, double %653, double %654
  %merged.select57 = select i1 %cmp.i.i.i, double %649, double %652
  %merged.select58 = select i1 %cmp.i.i.i, double %652, double %655
  %657 = select i1 %merged.select56, double %merged.select57, double %merged.select58
  %658 = fadd double %656, %657
  %merged.select60 = select i1 %cmp.i.i.i, double %657, double %658
  %659 = fdiv double %merged.select59, %merged.select60
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

merged.branch.split2:                             ; preds = %predication.tail108
  %660 = select i1 %146, double 0x3FF47646B0F87946, double 0xC024AD8FAE86A147
  %661 = fadd double %530, %660
  br label %merged.bb21
}

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.frexp.mant.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.ldexp.f64(double, i32) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.frexp.exp.i32.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rcp.f64(double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fma.v2f64(<2 x double>, <2 x double>, <2 x double>) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #1

attributes #0 = { convergent norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="128" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nounwind readnone speculatable willreturn }
attributes #2 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }
attributes #4 = { nounwind readnone }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/charitha22/cgo22ae-darm-code.git e9bc0540325ad9806313d34e84fc901496fd8be6)"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i16 1, i16 1025}
!6 = !{}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = !{!"evaluate:%decision.dispatch", !"evaluate:%if.else75.i.i.i.i", !"evaluate:%decision.dispatch4"}
!13 = !{!"merge(merge(evaluate:%decision.dispatch,evaluate:%if.else75.i.i.i.i),evaluate:%decision.dispatch4)"}
!14 = !{!"evaluate:%decision.dispatch", !"evaluate:%if.else75.i.i.i.i"}
!15 = !{!"merge(evaluate:%decision.dispatch,evaluate:%if.else75.i.i.i.i)"}
!16 = !{!"evaluate:%decision.dispatch", !"evaluate:%if.else75.i.i.i.i", !"evaluate:%decision.dispatch4", !"evaluate:%decision.dispatch2"}
!17 = !{!"merge(merge(merge(evaluate:%decision.dispatch,evaluate:%if.else75.i.i.i.i),evaluate:%decision.dispatch4),evaluate:%decision.dispatch2)"}
