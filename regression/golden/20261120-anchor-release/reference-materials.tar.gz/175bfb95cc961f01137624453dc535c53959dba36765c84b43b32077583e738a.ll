; ModuleID = '/data/home/chh/simplify-v2/build/b2b-layouts/anchor-ablation/heldout/CED/active/trial-2/fused.ll'
source_filename = "cases/ced/source/native.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7"
target triple = "amdgcn-amd-amdhsa"

@l_mem = external hidden local_unnamed_addr addrspace(3) global [0 x i32], align 4

; Function Attrs: convergent norecurse nounwind willreturn mustprogress
define protected amdgpu_kernel void @_Z19non_max_supp_kernelPKhPhS0_ii(i8 addrspace(1)* noalias nocapture readonly %0, i8 addrspace(1)* noalias nocapture %1, i8 addrspace(1)* noalias nocapture readonly %2, i32 %3, i32 %4) local_unnamed_addr #0 {
  %6 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %7 = getelementptr inbounds i8, i8 addrspace(4)* %6, i64 4
  %8 = bitcast i8 addrspace(4)* %7 to i16 addrspace(4)*
  %9 = load i16, i16 addrspace(4)* %8, align 4, !tbaa !3
  %10 = zext i16 %9 to i32
  %11 = getelementptr inbounds i8, i8 addrspace(4)* %6, i64 6
  %12 = bitcast i8 addrspace(4)* %11 to i16 addrspace(4)*
  %13 = load i16, i16 addrspace(4)* %12, align 2, !tbaa !3
  %14 = zext i16 %13 to i32
  %15 = tail call i32 @llvm.amdgcn.workitem.id.y(), !range !7
  %16 = add nuw nsw i32 %15, 1
  %17 = tail call i32 @llvm.amdgcn.workitem.id.x(), !range !7
  %18 = add nuw nsw i32 %17, 1
  %19 = tail call i32 @llvm.amdgcn.workgroup.id.y()
  %20 = mul i32 %19, %14
  %21 = add i32 %20, %16
  %22 = tail call i32 @llvm.amdgcn.workgroup.id.x()
  %23 = mul i32 %22, %10
  %24 = add i32 %23, %18
  %25 = mul nsw i32 %21, %4
  %26 = add nsw i32 %24, %25
  %27 = sext i32 %26 to i64
  %28 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %27
  %29 = load i8, i8 addrspace(1)* %28, align 1, !tbaa !8
  %30 = zext i8 %29 to i32
  %31 = add nuw nsw i32 %10, 2
  %32 = mul nuw nsw i32 %31, %16
  %33 = add nuw nsw i32 %32, %18
  %34 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %33
  store i32 %30, i32 addrspace(3)* %34, align 4, !tbaa !9
  %35 = icmp eq i32 %15, 0
  %36 = icmp eq i32 %16, %10
  %decision.take = or i1 %35, %36
  br i1 %decision.take, label %merged.bb, label %.pair.join, !decision.condition_prefix !11

.pair.join:                                       ; preds = %leaf.union, %merged.bb, %5
  %37 = icmp eq i32 %17, 0
  %38 = icmp eq i32 %18, %10
  %leaf.enter2 = or i1 %37, %38
  br i1 %leaf.enter2, label %leaf.union1, label %50, !fusion.logical.arm !12

leaf.union1:                                      ; preds = %.pair.join
  %39 = add nuw nsw i32 %10, 1
  %40 = add nuw nsw i32 %39, %32
  %41 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %40
  %42 = select i1 %37, i32 -1, i32 1
  %43 = add nsw i32 %26, %42
  %44 = sext i32 %43 to i64
  %45 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %44
  %46 = load i8, i8 addrspace(1)* %45, align 1, !tbaa !8
  %47 = zext i8 %46 to i32
  %48 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %32
  %49 = select i1 %37, i32 addrspace(3)* %48, i32 addrspace(3)* %41
  store i32 %47, i32 addrspace(3)* %49, align 4, !tbaa !9
  br label %50

50:                                               ; preds = %leaf.union1, %.pair.join
  fence syncscope("workgroup") seq_cst
  tail call void @llvm.amdgcn.s.barrier()
  fence syncscope("workgroup") seq_cst
  %51 = load i32, i32 addrspace(3)* %34, align 4, !tbaa !9
  %52 = trunc i32 %51 to i8
  %53 = getelementptr inbounds i8, i8 addrspace(1)* %2, i64 %27
  %54 = load i8, i8 addrspace(1)* %53, align 1, !tbaa !8
  switch i8 %54, label %114 [
    i8 0, label %55
    i8 45, label %67
    i8 90, label %83
    i8 -121, label %98
  ]

55:                                               ; preds = %50
  %56 = and i32 %51, 255
  %57 = add nuw nsw i32 %33, 1
  %58 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %57
  %59 = load i32, i32 addrspace(3)* %58, align 4, !tbaa !9
  %60 = icmp sgt i32 %56, %59
  br i1 %60, label %61, label %114

61:                                               ; preds = %55
  %62 = add nuw nsw i32 %32, %17
  %63 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %62
  %64 = load i32, i32 addrspace(3)* %63, align 4, !tbaa !9
  %65 = icmp sgt i32 %56, %64
  %66 = select i1 %65, i8 %52, i8 0
  br label %114

67:                                               ; preds = %50
  %68 = and i32 %51, 255
  %69 = mul nuw nsw i32 %31, %15
  %70 = add nuw nsw i32 %17, 2
  %71 = add nuw nsw i32 %70, %69
  %72 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %71
  %73 = load i32, i32 addrspace(3)* %72, align 4, !tbaa !9
  %74 = icmp sgt i32 %68, %73
  br i1 %74, label %75, label %114

75:                                               ; preds = %67
  %76 = add nuw nsw i32 %15, 2
  %77 = mul nuw nsw i32 %31, %76
  %78 = add nuw nsw i32 %77, %17
  %79 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %78
  %80 = load i32, i32 addrspace(3)* %79, align 4, !tbaa !9
  %81 = icmp sgt i32 %68, %80
  %82 = select i1 %81, i8 %52, i8 0
  br label %114

83:                                               ; preds = %50
  %84 = and i32 %51, 255
  %85 = mul nuw nsw i32 %31, %15
  %86 = add nuw nsw i32 %85, %18
  %87 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %86
  %88 = load i32, i32 addrspace(3)* %87, align 4, !tbaa !9
  %89 = icmp sgt i32 %84, %88
  br i1 %89, label %90, label %114

90:                                               ; preds = %83
  %91 = add nuw nsw i32 %15, 2
  %92 = mul nuw nsw i32 %31, %91
  %93 = add nuw nsw i32 %92, %18
  %94 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %93
  %95 = load i32, i32 addrspace(3)* %94, align 4, !tbaa !9
  %96 = icmp sgt i32 %84, %95
  %97 = select i1 %96, i8 %52, i8 0
  br label %114

98:                                               ; preds = %50
  %99 = and i32 %51, 255
  %100 = mul nuw nsw i32 %31, %15
  %101 = add nuw nsw i32 %100, %17
  %102 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %101
  %103 = load i32, i32 addrspace(3)* %102, align 4, !tbaa !9
  %104 = icmp sgt i32 %99, %103
  br i1 %104, label %105, label %114

105:                                              ; preds = %98
  %106 = add nuw nsw i32 %15, 2
  %107 = mul nuw nsw i32 %31, %106
  %108 = add nuw nsw i32 %17, 2
  %109 = add nuw nsw i32 %108, %107
  %110 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %109
  %111 = load i32, i32 addrspace(3)* %110, align 4, !tbaa !9
  %112 = icmp sgt i32 %99, %111
  %113 = select i1 %112, i8 %52, i8 0
  br label %114

114:                                              ; preds = %105, %98, %90, %83, %75, %67, %61, %55, %50
  %115 = phi i8 [ %52, %50 ], [ 0, %55 ], [ %66, %61 ], [ 0, %67 ], [ %82, %75 ], [ 0, %83 ], [ %97, %90 ], [ 0, %98 ], [ %113, %105 ]
  %116 = getelementptr inbounds i8, i8 addrspace(1)* %1, i64 %27
  store i8 %115, i8 addrspace(1)* %116, align 1, !tbaa !8
  ret void

merged.bb:                                        ; preds = %5
  %117 = sub i32 0, %4
  %guard.result.p = select i1 %35, i32 %117, i32 %4
  %guard.result = add i32 %26, %guard.result.p
  %118 = sext i32 %guard.result to i64
  %119 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %118
  %120 = load i8, i8 addrspace(1)* %119, align 1, !tbaa !8
  %121 = zext i8 %120 to i32
  %122 = add nuw nsw i32 %10, 1
  %123 = mul nsw i32 %122, %31
  %124 = select i1 %35, i32 0, i32 %123
  %merged.select6 = add nuw nsw i32 %18, %124
  %125 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %merged.select6
  store i32 %121, i32 addrspace(3)* %125, align 4, !tbaa !9
  %126 = icmp eq i32 %17, 0
  %127 = icmp eq i32 %18, %10
  %leaf.enter = or i1 %126, %127
  br i1 %leaf.enter, label %leaf.union, label %.pair.join, !fusion.logical.arm !13

leaf.union:                                       ; preds = %merged.bb
  %128 = select i1 %126, i32 undef, i32 %10
  %129 = select i1 %35, i32 %128, i32 %123
  %130 = select i1 %35, i32 1, i32 %122
  %131 = add nuw nsw i32 %129, %130
  %132 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %131
  %133 = select i1 %126, i32 -1, i32 1
  %134 = add nsw i32 %guard.result, %133
  %135 = sext i32 %134 to i64
  %136 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %135
  %137 = load i8, i8 addrspace(1)* %136, align 1, !tbaa !8
  %138 = zext i8 %137 to i32
  %139 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %129
  %140 = select i1 %35, i32 addrspace(3)* getelementptr inbounds ([0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 0), i32 addrspace(3)* %139
  %141 = select i1 %126, i32 addrspace(3)* %140, i32 addrspace(3)* %132
  store i32 %138, i32 addrspace(3)* %141, align 4, !tbaa !9
  br label %.pair.join
}

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.y() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.y() #1

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #1

attributes #0 = { convergent norecurse nounwind willreturn mustprogress "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nounwind readnone speculatable willreturn }
attributes #2 = { convergent nounwind willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!3 = !{!4, !4, i64 0}
!4 = !{!"short", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C++ TBAA"}
!7 = !{i32 0, i32 1024}
!8 = !{!5, !5, i64 0}
!9 = !{!10, !10, i64 0}
!10 = !{!"int", !5, i64 0}
!11 = !{}
!12 = !{!"%39", !"%47"}
!13 = !{!"merged.bb2", !"merged.bb4"}
