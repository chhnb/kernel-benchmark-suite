; ModuleID = '/data/home/chh/simplify-v2/build/simplify-fingerprint/active/tigre/trial-14/fused.ll'
source_filename = "/home/chh/region-fusion-lab/work/tigre-fusion-bounds-20261104/device.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

%struct.Point3D.18.21.24 = type { float, float, float }
%struct.Geometry.coerce.19.22.25 = type { i32, i32, i32, float, float, float, float, float, float, float addrspace(1)*, float addrspace(1)*, float addrspace(1)*, float addrspace(1)*, i32, i32, float, float, float, float, float addrspace(1)*, float addrspace(1)*, float addrspace(1)*, float addrspace(1)*, float addrspace(1)*, float addrspace(1)*, float, float, float, float, float, float, float addrspace(1)*, float, float }
%struct.__hip_texture.20.23.26 = type opaque

@projParamsArrayDev = protected local_unnamed_addr addrspace(4) externally_initialized global [36 x %struct.Point3D.18.21.24] zeroinitializer, align 16

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z19kernelPixelDetector8GeometryPfiiP13__hip_texture(%struct.Geometry.coerce.19.22.25 %geo.coerce, float addrspace(1)* nocapture %detector.coerce, i32 %currProjSetNumber, i32 %totalNoOfProjections, %struct.__hip_texture.20.23.26 addrspace(1)* nocapture readonly %tex.coerce) local_unnamed_addr #0 {
entry:
  %0 = extractvalue %struct.Geometry.coerce.19.22.25 %geo.coerce, 0
  %1 = extractvalue %struct.Geometry.coerce.19.22.25 %geo.coerce, 1
  %2 = extractvalue %struct.Geometry.coerce.19.22.25 %geo.coerce, 2
  %3 = extractvalue %struct.Geometry.coerce.19.22.25 %geo.coerce, 6
  %4 = extractvalue %struct.Geometry.coerce.19.22.25 %geo.coerce, 7
  %5 = extractvalue %struct.Geometry.coerce.19.22.25 %geo.coerce, 8
  %6 = extractvalue %struct.Geometry.coerce.19.22.25 %geo.coerce, 13
  %7 = tail call i32 @llvm.amdgcn.workgroup.id.x() #4
  %8 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #4
  %9 = getelementptr i8, i8 addrspace(4)* %8, i64 4
  %10 = bitcast i8 addrspace(4)* %9 to i16 addrspace(4)*
  %11 = load i16, i16 addrspace(4)* %10, align 4, !range !5, !invariant.load !6
  %12 = zext i16 %11 to i32
  %13 = mul i32 %7, %12
  %14 = tail call i32 @llvm.amdgcn.workitem.id.x() #4, !range !7
  %add = add i32 %13, %14
  %conv = zext i32 %add to i64
  %15 = tail call i32 @llvm.amdgcn.workgroup.id.y() #4
  %16 = getelementptr i8, i8 addrspace(4)* %8, i64 6
  %17 = bitcast i8 addrspace(4)* %16 to i16 addrspace(4)*
  %18 = load i16, i16 addrspace(4)* %17, align 2, !range !5, !invariant.load !6
  %19 = zext i16 %18 to i32
  %20 = mul i32 %15, %19
  %21 = tail call i32 @llvm.amdgcn.workitem.id.y() #4, !range !7
  %add10 = add i32 %20, %21
  %conv11 = zext i32 %add10 to i64
  %22 = tail call i32 @llvm.amdgcn.workitem.id.z() #4, !range !7
  %conv13 = zext i32 %22 to i64
  %conv14 = sext i32 %6 to i64
  %cmp.not = icmp ult i64 %conv, %conv14
  br i1 %cmp.not, label %lor.lhs.false, label %cleanup550

lor.lhs.false:                                    ; preds = %entry
  %23 = extractvalue %struct.Geometry.coerce.19.22.25 %geo.coerce, 14
  %conv15 = sext i32 %23 to i64
  %cmp16 = icmp ule i64 %conv15, %conv11
  %cmp18 = icmp ugt i32 %22, 8
  %or.cond = or i1 %cmp18, %cmp16
  br i1 %or.cond, label %cleanup550, label %if.end

if.end:                                           ; preds = %lor.lhs.false
  %mul28 = mul nsw i64 %conv15, %conv13
  %reass.add = add nsw i64 %mul28, %conv11
  %reass.mul = mul i64 %reass.add, %conv14
  %add29 = add i64 %reass.mul, %conv
  %mul30 = mul nsw i32 %currProjSetNumber, 9
  %conv31 = sext i32 %mul30 to i64
  %add32 = add nsw i64 %conv31, %conv13
  %conv33 = sext i32 %totalNoOfProjections to i64
  %cmp34.not = icmp ult i64 %add32, %conv33
  br i1 %cmp34.not, label %if.end36, label %cleanup550

if.end36:                                         ; preds = %if.end
  %mul37 = shl nuw nsw i64 %conv13, 2
  %uvOrigin.sroa.0.0..sroa_idx = getelementptr inbounds [36 x %struct.Point3D.18.21.24], [36 x %struct.Point3D.18.21.24] addrspace(4)* @projParamsArrayDev, i64 0, i64 %mul37, i32 0
  %uvOrigin.sroa.0.0.copyload = load float, float addrspace(4)* %uvOrigin.sroa.0.0..sroa_idx, align 16, !tbaa.struct !8
  %uvOrigin.sroa.4.0..sroa_idx805 = getelementptr inbounds [36 x %struct.Point3D.18.21.24], [36 x %struct.Point3D.18.21.24] addrspace(4)* @projParamsArrayDev, i64 0, i64 %mul37, i32 1
  %uvOrigin.sroa.4.0.copyload = load float, float addrspace(4)* %uvOrigin.sroa.4.0..sroa_idx805, align 4, !tbaa.struct !8
  %uvOrigin.sroa.5.0..sroa_idx807 = getelementptr inbounds [36 x %struct.Point3D.18.21.24], [36 x %struct.Point3D.18.21.24] addrspace(4)* @projParamsArrayDev, i64 0, i64 %mul37, i32 2
  %uvOrigin.sroa.5.0.copyload = load float, float addrspace(4)* %uvOrigin.sroa.5.0..sroa_idx807, align 8, !tbaa.struct !8
  %add39 = or i64 %mul37, 1
  %deltaU.sroa.0.0..sroa_idx = getelementptr inbounds [36 x %struct.Point3D.18.21.24], [36 x %struct.Point3D.18.21.24] addrspace(4)* @projParamsArrayDev, i64 0, i64 %add39, i32 0
  %deltaU.sroa.0.0.copyload = load float, float addrspace(4)* %deltaU.sroa.0.0..sroa_idx, align 4, !tbaa.struct !8
  %deltaU.sroa.4.0..sroa_idx800 = getelementptr inbounds [36 x %struct.Point3D.18.21.24], [36 x %struct.Point3D.18.21.24] addrspace(4)* @projParamsArrayDev, i64 0, i64 %add39, i32 1
  %deltaU.sroa.4.0.copyload = load float, float addrspace(4)* %deltaU.sroa.4.0..sroa_idx800, align 16, !tbaa.struct !8
  %deltaU.sroa.5.0..sroa_idx802 = getelementptr inbounds [36 x %struct.Point3D.18.21.24], [36 x %struct.Point3D.18.21.24] addrspace(4)* @projParamsArrayDev, i64 0, i64 %add39, i32 2
  %deltaU.sroa.5.0.copyload = load float, float addrspace(4)* %deltaU.sroa.5.0..sroa_idx802, align 4, !tbaa.struct !8
  %add42 = or i64 %mul37, 2
  %deltaV.sroa.0.0..sroa_idx = getelementptr inbounds [36 x %struct.Point3D.18.21.24], [36 x %struct.Point3D.18.21.24] addrspace(4)* @projParamsArrayDev, i64 0, i64 %add42, i32 0
  %deltaV.sroa.0.0.copyload = load float, float addrspace(4)* %deltaV.sroa.0.0..sroa_idx, align 8, !tbaa.struct !8
  %deltaV.sroa.4.0..sroa_idx795 = getelementptr inbounds [36 x %struct.Point3D.18.21.24], [36 x %struct.Point3D.18.21.24] addrspace(4)* @projParamsArrayDev, i64 0, i64 %add42, i32 1
  %deltaV.sroa.4.0.copyload = load float, float addrspace(4)* %deltaV.sroa.4.0..sroa_idx795, align 4, !tbaa.struct !8
  %deltaV.sroa.5.0..sroa_idx797 = getelementptr inbounds [36 x %struct.Point3D.18.21.24], [36 x %struct.Point3D.18.21.24] addrspace(4)* @projParamsArrayDev, i64 0, i64 %add42, i32 2
  %deltaV.sroa.5.0.copyload = load float, float addrspace(4)* %deltaV.sroa.5.0..sroa_idx797, align 16, !tbaa.struct !8
  %add45 = or i64 %mul37, 3
  %source.sroa.0.0..sroa_idx = getelementptr inbounds [36 x %struct.Point3D.18.21.24], [36 x %struct.Point3D.18.21.24] addrspace(4)* @projParamsArrayDev, i64 0, i64 %add45, i32 0
  %source.sroa.0.0.copyload = load float, float addrspace(4)* %source.sroa.0.0..sroa_idx, align 4, !tbaa.struct !8
  %source.sroa.18.0..sroa_idx762 = getelementptr inbounds [36 x %struct.Point3D.18.21.24], [36 x %struct.Point3D.18.21.24] addrspace(4)* @projParamsArrayDev, i64 0, i64 %add45, i32 1
  %source.sroa.18.0.copyload = load float, float addrspace(4)* %source.sroa.18.0..sroa_idx762, align 8, !tbaa.struct !8
  %source.sroa.33.0..sroa_idx778 = getelementptr inbounds [36 x %struct.Point3D.18.21.24], [36 x %struct.Point3D.18.21.24] addrspace(4)* @projParamsArrayDev, i64 0, i64 %add45, i32 2
  %source.sroa.33.0.copyload = load float, float addrspace(4)* %source.sroa.33.0..sroa_idx778, align 4, !tbaa.struct !8
  %24 = xor i64 %conv11, -1
  %sub49 = add nsw i64 %24, %conv15
  %conv50 = uitofp i32 %add to float
  %mul52 = fmul float %deltaU.sroa.0.0.copyload, %conv50
  %add53 = fadd float %uvOrigin.sroa.0.0.copyload, %mul52
  %conv54 = uitofp i64 %sub49 to float
  %mul56 = fmul float %deltaV.sroa.0.0.copyload, %conv54
  %add57 = fadd float %add53, %mul56
  %mul61 = fmul float %deltaU.sroa.4.0.copyload, %conv50
  %add62 = fadd float %uvOrigin.sroa.4.0.copyload, %mul61
  %mul65 = fmul float %deltaV.sroa.4.0.copyload, %conv54
  %add66 = fadd float %add62, %mul65
  %mul70 = fmul float %deltaU.sroa.5.0.copyload, %conv50
  %add71 = fadd float %uvOrigin.sroa.5.0.copyload, %mul70
  %mul74 = fmul float %deltaV.sroa.5.0.copyload, %conv54
  %add75 = fadd float %add71, %mul74
  %sub79 = fsub float %add57, %source.sroa.0.0.copyload
  %sub83 = fsub float %add66, %source.sroa.18.0.copyload
  %sub87 = fsub float %add75, %source.sroa.33.0.copyload
  %25 = tail call float @llvm.fabs.f32(float %sub79) #4
  %cmp91 = fcmp olt float %25, 0x3F50624DE0000000
  %cond = select i1 %cmp91, float 0.000000e+00, float %sub79
  %26 = tail call float @llvm.fabs.f32(float %sub83) #4
  %cmp96 = fcmp olt float %26, 0x3F50624DE0000000
  %cond101 = select i1 %cmp96, float 0.000000e+00, float %sub83
  %27 = tail call float @llvm.fabs.f32(float %sub87) #4
  %cmp105 = fcmp olt float %27, 0x3F50624DE0000000
  %cond110 = select i1 %cmp105, float 0.000000e+00, float %sub87
  %fneg = fneg float %source.sroa.0.0.copyload
  %div.i904 = fdiv float %fneg, %cond
  %conv115 = sitofp i32 %0 to float
  %sub117 = fsub float %conv115, %source.sroa.0.0.copyload
  %div.i903 = fdiv float %sub117, %cond
  %28 = tail call float @llvm.minnum.f32(float %div.i904, float %div.i903) #4
  %fneg122 = fneg float %source.sroa.18.0.copyload
  %div.i902 = fdiv float %fneg122, %cond101
  %conv125 = sitofp i32 %1 to float
  %sub127 = fsub float %conv125, %source.sroa.18.0.copyload
  %div.i901 = fdiv float %sub127, %cond101
  %29 = tail call float @llvm.minnum.f32(float %div.i902, float %div.i901) #4
  %fneg132 = fneg float %source.sroa.33.0.copyload
  %div.i900 = fdiv float %fneg132, %cond110
  %conv135 = sitofp i32 %2 to float
  %sub137 = fsub float %conv135, %source.sroa.33.0.copyload
  %div.i899 = fdiv float %sub137, %cond110
  %30 = tail call float @llvm.minnum.f32(float %div.i900, float %div.i899) #4
  %31 = tail call float @llvm.maxnum.f32(float %div.i904, float %div.i903) #4
  %32 = tail call float @llvm.maxnum.f32(float %div.i902, float %div.i901) #4
  %33 = tail call float @llvm.maxnum.f32(float %div.i900, float %div.i899) #4
  %34 = tail call float @llvm.maxnum.f32(float %28, float %29) #4
  %35 = tail call float @llvm.maxnum.f32(float %34, float %30) #4
  %36 = tail call float @llvm.minnum.f32(float %31, float %32) #4
  %37 = tail call float @llvm.minnum.f32(float %36, float %33) #4
  %cmp178 = fcmp ult float %35, %37
  br i1 %cmp178, label %if.end181, label %if.then179

if.then179:                                       ; preds = %if.end36
  %arrayidx180849 = getelementptr inbounds float, float addrspace(1)* %detector.coerce, i64 %add29
  store float 0.000000e+00, float addrspace(1)* %arrayidx180849, align 4, !tbaa !9
  br label %cleanup550

if.end181:                                        ; preds = %if.end36
  %cmp184 = fcmp olt float %source.sroa.0.0.copyload, %add57
  %cmp186 = fcmp oeq float %35, %28
  %38 = fadd float %conv115, -1.000000e+00
  %39 = fmul float %cond, %35
  %40 = fadd float %source.sroa.0.0.copyload, %39
  %41 = tail call float @llvm.ceil.f32(float %40) #4
  %42 = tail call float @llvm.floor.f32(float %40) #4
  %guard.result = select i1 %cmp184, float %41, float %42
  %merged.select = select i1 %cmp184, float 1.000000e+00, float %38
  %43 = select i1 %cmp186, float %merged.select, float %guard.result
  %44 = fcmp oeq float %37, %31
  %45 = fmul float %cond, %37
  %46 = fadd float %source.sroa.0.0.copyload, %45
  %47 = tail call float @llvm.floor.f32(float %46) #4
  %48 = tail call float @llvm.ceil.f32(float %46) #4
  %guard.value = select i1 %cmp184, float %47, float undef
  %guard.value15 = select i1 %cmp184, float undef, float %48
  %49 = select i1 %44, float %conv115, float %guard.value
  %50 = select i1 %44, float 0.000000e+00, float %guard.value15
  %imax.0 = select i1 %cmp184, float %49, float %43
  %imin.0 = select i1 %cmp184, float %43, float %50
  %cmp234 = fcmp olt float %source.sroa.18.0.copyload, %add66
  %cmp236 = fcmp oeq float %35, %29
  %51 = fadd float %conv125, -1.000000e+00
  %52 = fmul float %cond101, %35
  %53 = fadd float %source.sroa.18.0.copyload, %52
  %54 = tail call float @llvm.ceil.f32(float %53) #4
  %55 = tail call float @llvm.floor.f32(float %53) #4
  %guard.result14 = select i1 %cmp234, float %54, float %55
  %merged.select9 = select i1 %cmp234, float 1.000000e+00, float %51
  %56 = select i1 %cmp236, float %merged.select9, float %guard.result14
  %57 = fcmp oeq float %37, %32
  %58 = fmul float %cond101, %37
  %59 = fadd float %source.sroa.18.0.copyload, %58
  %60 = tail call float @llvm.floor.f32(float %59) #4
  %61 = tail call float @llvm.ceil.f32(float %59) #4
  %guard.value18 = select i1 %cmp234, float %60, float undef
  %guard.value19 = select i1 %cmp234, float undef, float %61
  %62 = select i1 %57, float %conv125, float %guard.value18
  %63 = select i1 %57, float 0.000000e+00, float %guard.value19
  %jmax.0 = select i1 %cmp234, float %62, float %56
  %jmin.0 = select i1 %cmp234, float %56, float %63
  %cmp285 = fcmp olt float %source.sroa.33.0.copyload, %add75
  %cmp287 = fcmp oeq float %35, %30
  %64 = fadd float %conv135, -1.000000e+00
  %65 = fmul float %cond110, %35
  %66 = fadd float %source.sroa.33.0.copyload, %65
  %67 = tail call float @llvm.ceil.f32(float %66) #4
  %68 = tail call float @llvm.floor.f32(float %66) #4
  %guard.result15 = select i1 %cmp285, float %67, float %68
  %merged.select10 = select i1 %cmp285, float 1.000000e+00, float %64
  %69 = select i1 %cmp287, float %merged.select10, float %guard.result15
  %70 = fcmp oeq float %37, %33
  %71 = fmul float %cond110, %37
  %72 = fadd float %source.sroa.33.0.copyload, %71
  %73 = tail call float @llvm.floor.f32(float %72) #4
  %74 = tail call float @llvm.ceil.f32(float %72) #4
  %guard.value20 = select i1 %cmp285, float %73, float undef
  %guard.value21 = select i1 %cmp285, float undef, float %74
  %75 = select i1 %70, float %conv135, float %guard.value20
  %76 = select i1 %70, float 0.000000e+00, float %guard.value21
  %kmin.0 = select i1 %cmp285, float %69, float %76
  %kmax.0 = select i1 %cmp285, float %75, float %69
  %sub339.pn = fsub float %43, %source.sroa.0.0.copyload
  %cond348 = fdiv float %sub339.pn, %cond
  %sub354.pn = fsub float %56, %source.sroa.18.0.copyload
  %cond363 = fdiv float %sub354.pn, %cond101
  %sub369.pn = fsub float %69, %source.sroa.33.0.copyload
  %cond378 = fdiv float %sub369.pn, %cond110
  %77 = tail call float @llvm.fabs.f32(float %cond348) #5
  %78 = fcmp oeq float %77, 0x7FF0000000000000
  %cond384 = select i1 %78, float %77, float %cond348
  %79 = tail call float @llvm.fabs.f32(float %cond363) #5
  %80 = fcmp oeq float %79, 0x7FF0000000000000
  %cond390 = select i1 %80, float %79, float %cond363
  %81 = tail call float @llvm.fabs.f32(float %cond378) #5
  %82 = fcmp oeq float %81, 0x7FF0000000000000
  %cond396 = select i1 %82, float %81, float %cond378
  %83 = tail call float @llvm.minnum.f32(float %cond384, float %cond390) #4
  %84 = tail call float @llvm.minnum.f32(float %83, float %cond396) #4
  %add400 = fadd float %35, %84
  %mul401 = fmul float %add400, 5.000000e-01
  %mul403 = fmul float %cond, %mul401
  %add404 = fadd float %source.sroa.0.0.copyload, %mul403
  %85 = tail call float @llvm.floor.f32(float %add404) #4
  %conv406 = fptoui float %85 to i64
  %mul411 = fmul float %cond101, %mul401
  %add412 = fadd float %source.sroa.18.0.copyload, %mul411
  %86 = tail call float @llvm.floor.f32(float %add412) #4
  %conv414 = fptoui float %86 to i64
  %mul419 = fmul float %cond110, %mul401
  %add420 = fadd float %source.sroa.33.0.copyload, %mul419
  %87 = tail call float @llvm.floor.f32(float %add420) #4
  %conv422 = fptoui float %87 to i64
  %88 = tail call float @llvm.fabs.f32(float %cond) #4
  %cmp.i877 = fcmp oeq float %cond, 0.000000e+00
  br i1 %cmp.i877, label %_Z12tigre_rcp_rdf.exit887, label %if.end.i879

if.end.i879:                                      ; preds = %if.end181
  %conv1.i878 = fdiv float 1.000000e+00, %88
  %89 = fcmp oeq float %conv1.i878, 0x7FF0000000000000
  br i1 %89, label %_Z12tigre_rcp_rdf.exit887, label %if.end3.i884

if.end3.i884:                                     ; preds = %if.end.i879
  %conv.i880 = fpext float %88 to double
  %conv4.i881 = fpext float %conv1.i878 to double
  %mul.i882 = fmul double %conv.i880, %conv4.i881
  %cmp6.i883 = fcmp ogt double %mul.i882, 1.000000e+00
  br i1 %cmp6.i883, label %if.then7.i885, label %_Z12tigre_rcp_rdf.exit887

if.then7.i885:                                    ; preds = %if.end3.i884
  %90 = insertelement <2 x float> <float poison, float 0.000000e+00>, float %conv1.i878, i32 0
  %91 = bitcast <2 x float> %90 to <2 x i32>
  %92 = sub nsw <2 x i32> <i32 -2147483648, i32 -2147483648>, %91
  %93 = icmp slt <2 x i32> %91, zeroinitializer
  %94 = select <2 x i1> %93, <2 x i32> %92, <2 x i32> %91
  %95 = extractelement <2 x i32> %94, i32 0
  %96 = extractelement <2 x i32> %94, i32 1
  %97 = icmp slt i32 %95, %96
  %98 = select i1 %97, i32 1, i32 -1
  %99 = add nsw i32 %98, %95
  %100 = sub nsw i32 -2147483648, %99
  %101 = icmp slt i32 %99, 0
  %102 = select i1 %101, i32 %100, i32 %99
  %103 = fcmp uno float %conv1.i878, 0.000000e+00
  %104 = bitcast float %conv1.i878 to i32
  %105 = select i1 %103, i32 %104, i32 %102
  %106 = insertelement <2 x float> <float 0.000000e+00, float poison>, float %conv1.i878, i32 1
  %107 = tail call <2 x float> @llvm.fabs.v2f32(<2 x float> %106) #4
  %108 = bitcast <2 x float> %107 to <2 x i32>
  %109 = extractelement <2 x i32> %108, i32 0
  %110 = extractelement <2 x i32> %108, i32 1
  %111 = or i32 %109, %110
  %112 = icmp eq i32 %111, 0
  %113 = icmp eq i32 %104, 0
  %114 = or i1 %113, %112
  %115 = bitcast i32 %105 to float
  %116 = select i1 %114, float 0.000000e+00, float %115
  br label %_Z12tigre_rcp_rdf.exit887

_Z12tigre_rcp_rdf.exit887:                        ; preds = %if.then7.i885, %if.end3.i884, %if.end.i879, %if.end181
  %retval.1.i886 = phi float [ 0x7FF0000000000000, %if.end181 ], [ 0x47EFFFFFE0000000, %if.end.i879 ], [ %conv1.i878, %if.end3.i884 ], [ %116, %if.then7.i885 ]
  %117 = tail call float @llvm.fabs.f32(float %cond101) #4
  %cmp.i866 = fcmp oeq float %cond101, 0.000000e+00
  br i1 %cmp.i866, label %_Z12tigre_rcp_rdf.exit876, label %if.end.i868

if.end.i868:                                      ; preds = %_Z12tigre_rcp_rdf.exit887
  %conv1.i867 = fdiv float 1.000000e+00, %117
  %118 = fcmp oeq float %conv1.i867, 0x7FF0000000000000
  br i1 %118, label %_Z12tigre_rcp_rdf.exit876, label %if.end3.i873

if.end3.i873:                                     ; preds = %if.end.i868
  %conv.i869 = fpext float %117 to double
  %conv4.i870 = fpext float %conv1.i867 to double
  %mul.i871 = fmul double %conv.i869, %conv4.i870
  %cmp6.i872 = fcmp ogt double %mul.i871, 1.000000e+00
  br i1 %cmp6.i872, label %if.then7.i874, label %_Z12tigre_rcp_rdf.exit876

if.then7.i874:                                    ; preds = %if.end3.i873
  %119 = insertelement <2 x float> <float poison, float 0.000000e+00>, float %conv1.i867, i32 0
  %120 = bitcast <2 x float> %119 to <2 x i32>
  %121 = sub nsw <2 x i32> <i32 -2147483648, i32 -2147483648>, %120
  %122 = icmp slt <2 x i32> %120, zeroinitializer
  %123 = select <2 x i1> %122, <2 x i32> %121, <2 x i32> %120
  %124 = extractelement <2 x i32> %123, i32 0
  %125 = extractelement <2 x i32> %123, i32 1
  %126 = icmp slt i32 %124, %125
  %127 = select i1 %126, i32 1, i32 -1
  %128 = add nsw i32 %127, %124
  %129 = sub nsw i32 -2147483648, %128
  %130 = icmp slt i32 %128, 0
  %131 = select i1 %130, i32 %129, i32 %128
  %132 = fcmp uno float %conv1.i867, 0.000000e+00
  %133 = bitcast float %conv1.i867 to i32
  %134 = select i1 %132, i32 %133, i32 %131
  %135 = insertelement <2 x float> <float 0.000000e+00, float poison>, float %conv1.i867, i32 1
  %136 = tail call <2 x float> @llvm.fabs.v2f32(<2 x float> %135) #4
  %137 = bitcast <2 x float> %136 to <2 x i32>
  %138 = extractelement <2 x i32> %137, i32 0
  %139 = extractelement <2 x i32> %137, i32 1
  %140 = or i32 %138, %139
  %141 = icmp eq i32 %140, 0
  %142 = icmp eq i32 %133, 0
  %143 = or i1 %142, %141
  %144 = bitcast i32 %134 to float
  %145 = select i1 %143, float 0.000000e+00, float %144
  br label %_Z12tigre_rcp_rdf.exit876

_Z12tigre_rcp_rdf.exit876:                        ; preds = %if.then7.i874, %if.end3.i873, %if.end.i868, %_Z12tigre_rcp_rdf.exit887
  %retval.1.i875 = phi float [ 0x7FF0000000000000, %_Z12tigre_rcp_rdf.exit887 ], [ 0x47EFFFFFE0000000, %if.end.i868 ], [ %conv1.i867, %if.end3.i873 ], [ %145, %if.then7.i874 ]
  %146 = tail call float @llvm.fabs.f32(float %cond110) #4
  %cmp.i862 = fcmp oeq float %cond110, 0.000000e+00
  br i1 %cmp.i862, label %_Z12tigre_rcp_rdf.exit, label %if.end.i

if.end.i:                                         ; preds = %_Z12tigre_rcp_rdf.exit876
  %conv1.i863 = fdiv float 1.000000e+00, %146
  %147 = fcmp oeq float %conv1.i863, 0x7FF0000000000000
  br i1 %147, label %_Z12tigre_rcp_rdf.exit, label %if.end3.i

if.end3.i:                                        ; preds = %if.end.i
  %conv.i864 = fpext float %146 to double
  %conv4.i = fpext float %conv1.i863 to double
  %mul.i865 = fmul double %conv.i864, %conv4.i
  %cmp6.i = fcmp ogt double %mul.i865, 1.000000e+00
  br i1 %cmp6.i, label %if.then7.i, label %_Z12tigre_rcp_rdf.exit

if.then7.i:                                       ; preds = %if.end3.i
  %148 = insertelement <2 x float> <float poison, float 0.000000e+00>, float %conv1.i863, i32 0
  %149 = bitcast <2 x float> %148 to <2 x i32>
  %150 = sub nsw <2 x i32> <i32 -2147483648, i32 -2147483648>, %149
  %151 = icmp slt <2 x i32> %149, zeroinitializer
  %152 = select <2 x i1> %151, <2 x i32> %150, <2 x i32> %149
  %153 = extractelement <2 x i32> %152, i32 0
  %154 = extractelement <2 x i32> %152, i32 1
  %155 = icmp slt i32 %153, %154
  %156 = select i1 %155, i32 1, i32 -1
  %157 = add nsw i32 %156, %153
  %158 = sub nsw i32 -2147483648, %157
  %159 = icmp slt i32 %157, 0
  %160 = select i1 %159, i32 %158, i32 %157
  %161 = fcmp uno float %conv1.i863, 0.000000e+00
  %162 = bitcast float %conv1.i863 to i32
  %163 = select i1 %161, i32 %162, i32 %160
  %164 = insertelement <2 x float> <float 0.000000e+00, float poison>, float %conv1.i863, i32 1
  %165 = tail call <2 x float> @llvm.fabs.v2f32(<2 x float> %164) #4
  %166 = bitcast <2 x float> %165 to <2 x i32>
  %167 = extractelement <2 x i32> %166, i32 0
  %168 = extractelement <2 x i32> %166, i32 1
  %169 = or i32 %167, %168
  %170 = icmp eq i32 %169, 0
  %171 = icmp eq i32 %162, 0
  %172 = or i1 %171, %170
  %173 = bitcast i32 %163 to float
  %174 = select i1 %172, float 0.000000e+00, float %173
  br label %_Z12tigre_rcp_rdf.exit

_Z12tigre_rcp_rdf.exit:                           ; preds = %if.then7.i, %if.end3.i, %if.end.i, %_Z12tigre_rcp_rdf.exit876
  %retval.1.i = phi float [ 0x7FF0000000000000, %_Z12tigre_rcp_rdf.exit876 ], [ 0x47EFFFFFE0000000, %if.end.i ], [ %conv1.i863, %if.end3.i ], [ %174, %if.then7.i ]
  %cond435 = select i1 %cmp184, float 1.000000e+00, float -1.000000e+00
  %cond439 = select i1 %cmp234, float 1.000000e+00, float -1.000000e+00
  %cond443 = select i1 %cmp285, float 1.000000e+00, float -1.000000e+00
  %mul446 = fmul float %cond, %cond
  %mul447 = fmul float %3, %mul446
  %mul449 = fmul float %3, %mul447
  %mul452 = fmul float %cond101, %cond101
  %mul453 = fmul float %4, %mul452
  %mul455 = fmul float %4, %mul453
  %add456 = fadd float %mul449, %mul455
  %mul459 = fmul float %cond110, %cond110
  %mul460 = fmul float %5, %mul459
  %mul462 = fmul float %5, %mul460
  %add463 = fadd float %add456, %mul462
  %conv.i = fpext float %add463 to double
  %175 = fcmp olt double %conv.i, 0x1000000000000000
  %176 = select i1 %175, double 0x4FF0000000000000, double 1.000000e+00
  %177 = fmul double %176, %conv.i
  %178 = tail call double @llvm.amdgcn.rsq.f64(double %177) #4
  %179 = fmul double %177, %178
  %180 = fmul double %178, 5.000000e-01
  %181 = fneg double %180
  %182 = tail call double @llvm.fma.f64(double %181, double %179, double 5.000000e-01) #4
  %183 = tail call double @llvm.fma.f64(double %180, double %182, double %180) #4
  %184 = tail call double @llvm.fma.f64(double %179, double %182, double %179) #4
  %185 = fneg double %184
  %186 = tail call double @llvm.fma.f64(double %185, double %184, double %177) #4
  %187 = tail call double @llvm.fma.f64(double %186, double %183, double %184) #4
  %188 = fneg double %187
  %189 = tail call double @llvm.fma.f64(double %188, double %187, double %177) #4
  %190 = tail call double @llvm.fma.f64(double %189, double %183, double %187) #4
  %191 = select i1 %175, double 0x37F0000000000000, double 1.000000e+00
  %192 = fmul double %191, %190
  %193 = fcmp oeq double %177, 0.000000e+00
  %194 = fcmp oeq double %177, 0x7FF0000000000000
  %195 = or i1 %193, %194
  %196 = select i1 %195, double %177, double %192
  %conv1.i = fptrunc double %196 to float
  %conv2.i = fpext float %conv1.i to double
  %mul.i = fmul double %conv2.i, %conv2.i
  %cmp.i = fcmp ogt double %mul.i, %conv.i
  br i1 %cmp.i, label %if.then.i, label %_Z13tigre_sqrt_rdf.exit

if.then.i:                                        ; preds = %_Z12tigre_rcp_rdf.exit
  %197 = insertelement <2 x float> <float poison, float 0.000000e+00>, float %conv1.i, i32 0
  %198 = bitcast <2 x float> %197 to <2 x i32>
  %199 = sub nsw <2 x i32> <i32 -2147483648, i32 -2147483648>, %198
  %200 = icmp slt <2 x i32> %198, zeroinitializer
  %201 = select <2 x i1> %200, <2 x i32> %199, <2 x i32> %198
  %202 = extractelement <2 x i32> %201, i32 0
  %203 = extractelement <2 x i32> %201, i32 1
  %204 = icmp slt i32 %202, %203
  %205 = select i1 %204, i32 1, i32 -1
  %206 = add nsw i32 %205, %202
  %207 = sub nsw i32 -2147483648, %206
  %208 = icmp slt i32 %206, 0
  %209 = select i1 %208, i32 %207, i32 %206
  %210 = fcmp uno float %conv1.i, 0.000000e+00
  %211 = bitcast float %conv1.i to i32
  %212 = select i1 %210, i32 %211, i32 %209
  %213 = insertelement <2 x float> <float 0.000000e+00, float poison>, float %conv1.i, i32 1
  %214 = tail call <2 x float> @llvm.fabs.v2f32(<2 x float> %213) #4
  %215 = bitcast <2 x float> %214 to <2 x i32>
  %216 = extractelement <2 x i32> %215, i32 0
  %217 = extractelement <2 x i32> %215, i32 1
  %218 = or i32 %216, %217
  %219 = icmp eq i32 %218, 0
  %220 = icmp eq i32 %211, 0
  %221 = or i1 %220, %219
  %222 = bitcast i32 %212 to float
  %223 = select i1 %221, float 0.000000e+00, float %222
  br label %_Z13tigre_sqrt_rdf.exit

_Z13tigre_sqrt_rdf.exit:                          ; preds = %if.then.i, %_Z12tigre_rcp_rdf.exit
  %r.0.i = phi float [ %conv1.i, %_Z12tigre_rcp_rdf.exit ], [ %223, %if.then.i ]
  %sub465 = fsub float %imax.0, %imin.0
  %add466 = fadd float %sub465, 1.000000e+00
  %sub467 = fsub float %jmax.0, %jmin.0
  %add468 = fadd float %sub467, 1.000000e+00
  %add469 = fadd float %add466, %add468
  %sub470 = fsub float %kmax.0, %kmin.0
  %add471 = fadd float %sub470, 1.000000e+00
  %add472 = fadd float %add469, %add471
  %conv473 = fptoui float %add472 to i64
  %cmp483908.not = icmp eq i64 %conv473, 0
  br i1 %cmp483908.not, label %for.cond.cleanup, label %for.body.lr.ph

for.body.lr.ph:                                   ; preds = %_Z13tigre_sqrt_rdf.exit
  %conv480 = uitofp i64 %conv422 to float
  %add481 = fadd float %conv480, 5.000000e-01
  %conv482 = fptoui float %add481 to i64
  %conv477 = uitofp i64 %conv414 to float
  %add478 = fadd float %conv477, 5.000000e-01
  %conv479 = fptoui float %add478 to i64
  %conv474 = uitofp i64 %conv406 to float
  %add475 = fadd float %conv474, 5.000000e-01
  %conv476 = fptoui float %add475 to i64
  %224 = bitcast %struct.__hip_texture.20.23.26 addrspace(1)* %tex.coerce to i32 addrspace(1)*
  %225 = addrspacecast i32 addrspace(1)* %224 to i32 addrspace(4)*
  %add.ptr.i = getelementptr inbounds i32, i32 addrspace(4)* %225, i64 12
  %226 = getelementptr inbounds i32, i32 addrspace(4)* %225, i64 10
  %227 = getelementptr inbounds i32, i32 addrspace(4)* %225, i64 2
  %228 = getelementptr inbounds i32, i32 addrspace(4)* %225, i64 4
  %229 = getelementptr inbounds i32, i32 addrspace(4)* %225, i64 14
  %230 = bitcast %struct.__hip_texture.20.23.26 addrspace(1)* %tex.coerce to <8 x i32> addrspace(1)*
  %231 = addrspacecast <8 x i32> addrspace(1)* %230 to <8 x i32> addrspace(4)*
  %232 = bitcast i32 addrspace(4)* %add.ptr.i to <4 x i32> addrspace(4)*
  br label %for.body

for.cond.cleanup:                                 ; preds = %if.end527, %_Z13tigre_sqrt_rdf.exit
  %sum.0.lcssa = phi float [ 0.000000e+00, %_Z13tigre_sqrt_rdf.exit ], [ %sum.1, %if.end527 ]
  %mul530 = fmul float %r.0.i, %sum.0.lcssa
  %arrayidx531848 = getelementptr inbounds float, float addrspace(1)* %detector.coerce, i64 %add29
  store float %mul530, float addrspace(1)* %arrayidx531848, align 4, !tbaa !9
  br label %cleanup550

for.body:                                         ; preds = %if.end527, %for.body.lr.ph
  %ii.0918 = phi i64 [ 0, %for.body.lr.ph ], [ %inc, %if.end527 ]
  %sum.0917 = phi float [ 0.000000e+00, %for.body.lr.ph ], [ %sum.1, %if.end527 ]
  %ac.0916 = phi float [ %35, %for.body.lr.ph ], [ %ac.1, %if.end527 ]
  %aminc.0915 = phi float [ %84, %for.body.lr.ph ], [ %293, %if.end527 ]
  %k.0914 = phi i64 [ %conv482, %for.body.lr.ph ], [ %k.1, %if.end527 ]
  %j.0913 = phi i64 [ %conv479, %for.body.lr.ph ], [ %j.1, %if.end527 ]
  %i.0912 = phi i64 [ %conv476, %for.body.lr.ph ], [ %i.1, %if.end527 ]
  %az.0911 = phi float [ %cond396, %for.body.lr.ph ], [ %az.1, %if.end527 ]
  %ay.0910 = phi float [ %cond390, %for.body.lr.ph ], [ %ay.1, %if.end527 ]
  %ax.0909 = phi float [ %cond384, %for.body.lr.ph ], [ %ax.1, %if.end527 ]
  %cmp484 = fcmp oeq float %ax.0909, %aminc.0915
  %cmp498 = fcmp oeq float %ay.0910, %aminc.0915
  %decision.take = or i1 %cmp484, %cmp498
  %cmp512 = fcmp oeq float %az.0911, %aminc.0915
  %decision.take1 = or i1 %decision.take, %cmp512
  br i1 %decision.take1, label %decision.dispatch2, label %if.end527, !decision.condition_prefix !6

decision.dispatch2:                               ; preds = %for.body
  %233 = select i1 %cmp484, float %ax.0909, float %ay.0910
  %234 = select i1 %decision.take, float %233, float %az.0911
  %235 = fsub float %234, %ac.0916
  %236 = uitofp i64 %i.0912 to float
  %237 = uitofp i64 %j.0913 to float
  %238 = uitofp i64 %k.0914 to float
  %239 = load i32, i32 addrspace(4)* %226, align 4, !tbaa !13
  %240 = uitofp i32 %239 to float
  %241 = load i32, i32 addrspace(4)* %227, align 4, !tbaa !13
  %242 = lshr i32 %241, 14
  %243 = and i32 %242, 16383
  %244 = add nuw nsw i32 %243, 1
  %245 = uitofp i32 %244 to float
  %246 = load i32, i32 addrspace(4)* %228, align 4, !tbaa !13
  %247 = and i32 %246, 8191
  %248 = add nuw nsw i32 %247, 1
  %249 = uitofp i32 %248 to float
  %250 = load i32, i32 addrspace(4)* %add.ptr.i, align 4, !tbaa !13
  %251 = and i32 %250, 32768
  %252 = icmp eq i32 %251, 0
  %253 = select i1 %252, float %240, float 1.000000e+00
  %254 = select i1 %252, float %245, float 1.000000e+00
  %255 = select i1 %252, float %249, float 1.000000e+00
  %256 = fmul float %253, %236
  %257 = tail call float @llvm.floor.f32(float %256) #4
  %258 = tail call float @llvm.amdgcn.rcp.f32(float %253) #4
  %259 = fmul float %258, %257
  %260 = fmul float %254, %237
  %261 = tail call float @llvm.floor.f32(float %260) #4
  %262 = tail call float @llvm.amdgcn.rcp.f32(float %254) #4
  %263 = fmul float %262, %261
  %264 = fmul float %255, %238
  %265 = tail call float @llvm.floor.f32(float %264) #4
  %266 = tail call float @llvm.amdgcn.rcp.f32(float %255) #4
  %267 = fmul float %266, %265
  %268 = load i32, i32 addrspace(4)* %229, align 4, !tbaa !13
  %269 = and i32 %268, 1048576
  %270 = icmp eq i32 %269, 0
  %271 = select i1 %270, float %259, float %236
  %272 = select i1 %270, float %263, float %237
  %273 = select i1 %270, float %267, float %238
  %274 = load <8 x i32>, <8 x i32> addrspace(4)* %231, align 32, !tbaa !17
  %275 = load <4 x i32>, <4 x i32> addrspace(4)* %232, align 16, !tbaa !17
  %276 = tail call float @llvm.amdgcn.image.sample.lz.3d.f32.f32(i32 1, float %271, float %272, float %273, <8 x i32> %274, <4 x i32> %275, i1 false, i32 0, i32 0)
  %277 = fmul float %235, %276
  %278 = fadd float %sum.0917, %277
  %279 = fadd float %cond435, %236
  %280 = fadd float %cond439, %237
  %281 = select i1 %cmp484, float %279, float %280
  %282 = fadd float %cond443, %238
  %fusion.paired4 = select i1 %decision.take, float %281, float %282
  %283 = fptoui float %fusion.paired4 to i64
  %284 = select i1 %cmp484, float %retval.1.i886, float %retval.1.i875
  %285 = select i1 %decision.take, float %284, float %retval.1.i
  %286 = select i1 %decision.take, float %233, float %az.0911
  %287 = fadd float %285, %286
  br i1 %decision.take, label %fusion.side1, label %if.end527

fusion.side1:                                     ; preds = %decision.dispatch2
  %288 = select i1 %cmp484, float %287, float %ax.0909
  %289 = select i1 %cmp484, float %ay.0910, float %287
  %290 = select i1 %cmp484, i64 %283, i64 %i.0912
  %291 = select i1 %cmp484, i64 %j.0913, i64 %283
  br label %if.end527

if.end527:                                        ; preds = %fusion.side1, %decision.dispatch2, %for.body
  %ax.1 = phi float [ %ax.0909, %for.body ], [ %ax.0909, %decision.dispatch2 ], [ %288, %fusion.side1 ]
  %ay.1 = phi float [ %ay.0910, %for.body ], [ %ay.0910, %decision.dispatch2 ], [ %289, %fusion.side1 ]
  %az.1 = phi float [ %az.0911, %for.body ], [ %287, %decision.dispatch2 ], [ %az.0911, %fusion.side1 ]
  %i.1 = phi i64 [ %i.0912, %for.body ], [ %i.0912, %decision.dispatch2 ], [ %290, %fusion.side1 ]
  %j.1 = phi i64 [ %j.0913, %for.body ], [ %j.0913, %decision.dispatch2 ], [ %291, %fusion.side1 ]
  %k.1 = phi i64 [ %k.0914, %for.body ], [ %283, %decision.dispatch2 ], [ %k.0914, %fusion.side1 ]
  %ac.1 = phi float [ %ac.0916, %for.body ], [ %az.0911, %decision.dispatch2 ], [ %233, %fusion.side1 ]
  %sum.1 = phi float [ %sum.0917, %for.body ], [ %278, %decision.dispatch2 ], [ %278, %fusion.side1 ]
  %292 = tail call float @llvm.minnum.f32(float %ax.1, float %ay.1) #4
  %293 = tail call float @llvm.minnum.f32(float %292, float %az.1) #4
  %inc = add nuw i64 %ii.0918, 1
  %exitcond.not = icmp eq i64 %inc, %conv473
  br i1 %exitcond.not, label %for.cond.cleanup, label %for.body

cleanup550:                                       ; preds = %for.cond.cleanup, %if.then179, %if.end, %lor.lhs.false, %entry
  ret void
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.ceil.f32(float) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.fabs.f32(float) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.floor.f32(float) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.maxnum.f32(float, float) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.minnum.f32(float, float) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare <2 x float> @llvm.fabs.v2f32(<2 x float>) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rsq.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare float @llvm.amdgcn.rcp.f32(float) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.y() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.y() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.z() #2

; Function Attrs: nounwind readonly willreturn
declare float @llvm.amdgcn.image.sample.lz.3d.f32.f32(i32 immarg, float, float, float, <8 x i32>, <4 x i32>, i1 immarg, i32 immarg, i32 immarg) #3

attributes #0 = { convergent norecurse nounwind "amdgpu-flat-work-group-size"="1,729" "amdgpu-implicitarg-num-bytes"="56" "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind readonly willreturn }
attributes #4 = { nounwind }
attributes #5 = { nounwind readnone }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/charitha22/cgo22ae-darm-code.git e9bc0540325ad9806313d34e84fc901496fd8be6)"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i16 1, i16 1025}
!6 = !{}
!7 = !{i32 0, i32 1024}
!8 = !{i64 0, i64 4, !9, i64 4, i64 4, !9, i64 8, i64 4, !9}
!9 = !{!10, !10, i64 0}
!10 = !{!"float", !11, i64 0}
!11 = !{!"omnipotent char", !12, i64 0}
!12 = !{!"Simple C++ TBAA"}
!13 = !{!14, !14, i64 0}
!14 = !{!"int", !15, i64 0}
!15 = !{!"omnipotent char", !16, i64 0}
!16 = !{!"Simple C/C++ TBAA"}
!17 = !{!15, !15, i64 0}
