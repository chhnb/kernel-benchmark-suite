; ModuleID = '/data/home/chh/simplify-v2/build/dp1-removal/stable-darm/vllm/trial-1066/fused.ll'
source_filename = "llvm-link"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p5i8(i64 immarg, i8 addrspace(5)* nocapture) #0

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p5i8(i64 immarg, i8 addrspace(5)* nocapture) #0

; Function Attrs: norecurse nounwind
define protected amdgpu_kernel void @cache_eval(i16 addrspace(1)* nocapture readonly %key.coerce, i16 addrspace(1)* nocapture readonly %value.coerce, i64 addrspace(1)* nocapture readonly %slots.coerce, i8 addrspace(1)* nocapture %kd.coerce, i8 addrspace(1)* nocapture %vd.coerce, i8 addrspace(1)* nocapture %ks.coerce, i8 addrspace(1)* nocapture %vs.coerce, i32 %heads, i32 %dim, i32 %page, i32 %stride, float %kg, float %vg) local_unnamed_addr #1 {
entry:
  %code = alloca [2 x i8], align 1, addrspace(5)
  %0 = tail call i32 @llvm.amdgcn.workgroup.id.x() #4
  %idxprom = sext i32 %0 to i64
  %arrayidx330 = getelementptr inbounds i64, i64 addrspace(1)* %slots.coerce, i64 %idxprom
  %1 = load i64, i64 addrspace(1)* %arrayidx330, align 8, !tbaa !5
  %cmp = icmp slt i64 %1, 0
  br i1 %cmp, label %cleanup, label %if.end

if.end:                                           ; preds = %entry
  %conv = sext i32 %page to i64
  %.frozen = freeze i64 %1
  %conv.frozen = freeze i64 %conv
  %div = sdiv i64 %.frozen, %conv.frozen
  %2 = mul i64 %div, %conv.frozen
  %rem.decomposed = sub i64 %.frozen, %2
  %conv9 = trunc i64 %rem.decomposed to i32
  %div10 = sdiv i32 %dim, 16
  %mul = mul nsw i32 %div10, %heads
  %conv13 = sext i32 %stride to i64
  %mul14 = mul nsw i64 %conv13, %idxprom
  %3 = tail call i32 @llvm.amdgcn.workitem.id.x() #4, !range !9
  %cmp32418 = icmp slt i32 %3, %mul
  %4 = getelementptr inbounds [2 x i8], [2 x i8] addrspace(5)* %code, i32 0, i32 0
  %conv151 = sext i32 %heads to i64
  %mul152 = mul nsw i64 %div, %conv151
  %div159 = sdiv i32 %dim, 2
  %conv160 = sext i32 %div159 to i64
  %div194 = sdiv i32 %conv9, 4
  %mul195 = shl nsw i32 %div194, 2
  %div196 = sdiv i32 %dim, 64
  %rem202.decomposed = sub i32 %conv9, %mul195
  %conv215 = sext i32 %div10 to i64
  %5 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #4
  %6 = getelementptr i8, i8 addrspace(4)* %5, i64 4
  %7 = bitcast i8 addrspace(4)* %6 to i16 addrspace(4)*
  %8 = load i16, i16 addrspace(4)* %7, align 4
  %9 = zext i16 %8 to i32
  %arrayidx64340398.1 = getelementptr inbounds [2 x i8], [2 x i8] addrspace(5)* %code, i32 0, i32 1
  %div10.frozen = freeze i32 %div10
  %div196.frozen = freeze i32 %div196
  br label %for.body

for.body:                                         ; preds = %for.cond.cleanup33, %if.end
  %os.sroa.0.0 = phi <2 x float> [ undef, %if.end ], [ %os.sroa.0.1, %for.cond.cleanup33 ]
  %tobool.not = phi i1 [ true, %if.end ], [ false, %for.cond.cleanup33 ]
  %cond.v = select i1 %tobool.not, i16 addrspace(1)* %key.coerce, i16 addrspace(1)* %value.coerce
  %add.ptr331 = getelementptr inbounds i16, i16 addrspace(1)* %cond.v, i64 %mul14
  %cond19.v = select i1 %tobool.not, i8 addrspace(1)* %kd.coerce, i8 addrspace(1)* %vd.coerce
  %cond24.v = select i1 %tobool.not, i8 addrspace(1)* %ks.coerce, i8 addrspace(1)* %vs.coerce
  %cond29 = select i1 %tobool.not, float %kg, float %vg
  br i1 %cmp32418, label %for.body34.lr.ph, label %for.cond.cleanup33

for.body34.lr.ph:                                 ; preds = %for.body
  %div71 = fdiv float 1.000000e+00, %cond29
  br label %for.body34

for.cond.cleanup33:                               ; preds = %if.end204, %for.body
  %os.sroa.0.1 = phi <2 x float> [ %os.sroa.0.0, %for.body ], [ %os.sroa.0.6, %if.end204 ]
  br i1 %tobool.not, label %for.body, label %cleanup

for.body34:                                       ; preds = %if.end204, %for.body34.lr.ph
  %os.sroa.0.2 = phi <2 x float> [ %os.sroa.0.0, %for.body34.lr.ph ], [ %os.sroa.0.6, %if.end204 ]
  %g.0419 = phi i32 [ %3, %for.body34.lr.ph ], [ %add222, %if.end204 ]
  %g.0419.frozen = freeze i32 %g.0419
  %div35 = sdiv i32 %g.0419.frozen, %div10.frozen
  %10 = mul i32 %div35, %div10.frozen
  %rem36.decomposed = sub i32 %g.0419.frozen, %10
  %mul41 = mul nsw i32 %div35, %dim
  %mul42 = shl nsw i32 %rem36.decomposed, 4
  %add = add nsw i32 %mul42, %mul41
  %idxprom44 = sext i32 %add to i64
  %arrayidx45347 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44
  %11 = load i16, i16 addrspace(1)* %arrayidx45347, align 2, !tbaa !10
  %conv.i = zext i16 %11 to i32
  %shl.i = shl nuw i32 %conv.i, 16
  %12 = bitcast i32 %shl.i to float
  %13 = tail call float @llvm.fabs.f32(float %12) #4
  %14 = tail call float @llvm.maxnum.f32(float %13, float 0.000000e+00) #4
  %add43.1 = add nsw i32 %add, 1
  %idxprom44.1 = sext i32 %add43.1 to i64
  %arrayidx45347.1 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.1
  %15 = load i16, i16 addrspace(1)* %arrayidx45347.1, align 2, !tbaa !10
  %conv.i.1 = zext i16 %15 to i32
  %shl.i.1 = shl nuw i32 %conv.i.1, 16
  %16 = bitcast i32 %shl.i.1 to float
  %17 = tail call float @llvm.fabs.f32(float %16) #4
  %18 = tail call float @llvm.maxnum.f32(float %14, float %17) #4
  %add43.2 = add nsw i32 %add, 2
  %idxprom44.2 = sext i32 %add43.2 to i64
  %arrayidx45347.2 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.2
  %19 = load i16, i16 addrspace(1)* %arrayidx45347.2, align 2, !tbaa !10
  %conv.i.2 = zext i16 %19 to i32
  %shl.i.2 = shl nuw i32 %conv.i.2, 16
  %20 = bitcast i32 %shl.i.2 to float
  %21 = tail call float @llvm.fabs.f32(float %20) #4
  %22 = tail call float @llvm.maxnum.f32(float %18, float %21) #4
  %add43.3 = add nsw i32 %add, 3
  %idxprom44.3 = sext i32 %add43.3 to i64
  %arrayidx45347.3 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.3
  %23 = load i16, i16 addrspace(1)* %arrayidx45347.3, align 2, !tbaa !10
  %conv.i.3 = zext i16 %23 to i32
  %shl.i.3 = shl nuw i32 %conv.i.3, 16
  %24 = bitcast i32 %shl.i.3 to float
  %25 = tail call float @llvm.fabs.f32(float %24) #4
  %26 = tail call float @llvm.maxnum.f32(float %22, float %25) #4
  %add43.4 = add nsw i32 %add, 4
  %idxprom44.4 = sext i32 %add43.4 to i64
  %arrayidx45347.4 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.4
  %27 = load i16, i16 addrspace(1)* %arrayidx45347.4, align 2, !tbaa !10
  %conv.i.4 = zext i16 %27 to i32
  %shl.i.4 = shl nuw i32 %conv.i.4, 16
  %28 = bitcast i32 %shl.i.4 to float
  %29 = tail call float @llvm.fabs.f32(float %28) #4
  %30 = tail call float @llvm.maxnum.f32(float %26, float %29) #4
  %add43.5 = add nsw i32 %add, 5
  %idxprom44.5 = sext i32 %add43.5 to i64
  %arrayidx45347.5 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.5
  %31 = load i16, i16 addrspace(1)* %arrayidx45347.5, align 2, !tbaa !10
  %conv.i.5 = zext i16 %31 to i32
  %shl.i.5 = shl nuw i32 %conv.i.5, 16
  %32 = bitcast i32 %shl.i.5 to float
  %33 = tail call float @llvm.fabs.f32(float %32) #4
  %34 = tail call float @llvm.maxnum.f32(float %30, float %33) #4
  %add43.6 = add nsw i32 %add, 6
  %idxprom44.6 = sext i32 %add43.6 to i64
  %arrayidx45347.6 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.6
  %35 = load i16, i16 addrspace(1)* %arrayidx45347.6, align 2, !tbaa !10
  %conv.i.6 = zext i16 %35 to i32
  %shl.i.6 = shl nuw i32 %conv.i.6, 16
  %36 = bitcast i32 %shl.i.6 to float
  %37 = tail call float @llvm.fabs.f32(float %36) #4
  %38 = tail call float @llvm.maxnum.f32(float %34, float %37) #4
  %add43.7 = add nsw i32 %add, 7
  %idxprom44.7 = sext i32 %add43.7 to i64
  %arrayidx45347.7 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.7
  %39 = load i16, i16 addrspace(1)* %arrayidx45347.7, align 2, !tbaa !10
  %conv.i.7 = zext i16 %39 to i32
  %shl.i.7 = shl nuw i32 %conv.i.7, 16
  %40 = bitcast i32 %shl.i.7 to float
  %41 = tail call float @llvm.fabs.f32(float %40) #4
  %42 = tail call float @llvm.maxnum.f32(float %38, float %41) #4
  %add43.8 = add nsw i32 %add, 8
  %idxprom44.8 = sext i32 %add43.8 to i64
  %arrayidx45347.8 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.8
  %43 = load i16, i16 addrspace(1)* %arrayidx45347.8, align 2, !tbaa !10
  %conv.i.8 = zext i16 %43 to i32
  %shl.i.8 = shl nuw i32 %conv.i.8, 16
  %44 = bitcast i32 %shl.i.8 to float
  %45 = tail call float @llvm.fabs.f32(float %44) #4
  %46 = tail call float @llvm.maxnum.f32(float %42, float %45) #4
  %add43.9 = add nsw i32 %add, 9
  %idxprom44.9 = sext i32 %add43.9 to i64
  %arrayidx45347.9 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.9
  %47 = load i16, i16 addrspace(1)* %arrayidx45347.9, align 2, !tbaa !10
  %conv.i.9 = zext i16 %47 to i32
  %shl.i.9 = shl nuw i32 %conv.i.9, 16
  %48 = bitcast i32 %shl.i.9 to float
  %49 = tail call float @llvm.fabs.f32(float %48) #4
  %50 = tail call float @llvm.maxnum.f32(float %46, float %49) #4
  %add43.10 = add nsw i32 %add, 10
  %idxprom44.10 = sext i32 %add43.10 to i64
  %arrayidx45347.10 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.10
  %51 = load i16, i16 addrspace(1)* %arrayidx45347.10, align 2, !tbaa !10
  %conv.i.10 = zext i16 %51 to i32
  %shl.i.10 = shl nuw i32 %conv.i.10, 16
  %52 = bitcast i32 %shl.i.10 to float
  %53 = tail call float @llvm.fabs.f32(float %52) #4
  %54 = tail call float @llvm.maxnum.f32(float %50, float %53) #4
  %add43.11 = add nsw i32 %add, 11
  %idxprom44.11 = sext i32 %add43.11 to i64
  %arrayidx45347.11 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.11
  %55 = load i16, i16 addrspace(1)* %arrayidx45347.11, align 2, !tbaa !10
  %conv.i.11 = zext i16 %55 to i32
  %shl.i.11 = shl nuw i32 %conv.i.11, 16
  %56 = bitcast i32 %shl.i.11 to float
  %57 = tail call float @llvm.fabs.f32(float %56) #4
  %58 = tail call float @llvm.maxnum.f32(float %54, float %57) #4
  %add43.12 = add nsw i32 %add, 12
  %idxprom44.12 = sext i32 %add43.12 to i64
  %arrayidx45347.12 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.12
  %59 = load i16, i16 addrspace(1)* %arrayidx45347.12, align 2, !tbaa !10
  %conv.i.12 = zext i16 %59 to i32
  %shl.i.12 = shl nuw i32 %conv.i.12, 16
  %60 = bitcast i32 %shl.i.12 to float
  %61 = tail call float @llvm.fabs.f32(float %60) #4
  %62 = tail call float @llvm.maxnum.f32(float %58, float %61) #4
  %add43.13 = add nsw i32 %add, 13
  %idxprom44.13 = sext i32 %add43.13 to i64
  %arrayidx45347.13 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.13
  %63 = load i16, i16 addrspace(1)* %arrayidx45347.13, align 2, !tbaa !10
  %conv.i.13 = zext i16 %63 to i32
  %shl.i.13 = shl nuw i32 %conv.i.13, 16
  %64 = bitcast i32 %shl.i.13 to float
  %65 = tail call float @llvm.fabs.f32(float %64) #4
  %66 = tail call float @llvm.maxnum.f32(float %62, float %65) #4
  %add43.14 = add nsw i32 %add, 14
  %idxprom44.14 = sext i32 %add43.14 to i64
  %arrayidx45347.14 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.14
  %67 = load i16, i16 addrspace(1)* %arrayidx45347.14, align 2, !tbaa !10
  %add43.15 = add nsw i32 %add, 15
  %idxprom44.15 = sext i32 %add43.15 to i64
  %arrayidx45347.15 = getelementptr inbounds i16, i16 addrspace(1)* %add.ptr331, i64 %idxprom44.15
  %68 = load i16, i16 addrspace(1)* %arrayidx45347.15, align 2, !tbaa !10
  %69 = insertelement <2 x i16> undef, i16 %68, i32 0
  %70 = insertelement <2 x i16> %69, i16 %67, i32 1
  %71 = zext <2 x i16> %70 to <2 x i32>
  %72 = shl nuw <2 x i32> %71, <i32 16, i32 16>
  %73 = bitcast <2 x i32> %72 to <2 x float>
  %74 = extractelement <2 x float> %73, i32 1
  %75 = tail call float @llvm.fabs.f32(float %74) #4
  %76 = tail call float @llvm.maxnum.f32(float %66, float %75) #4
  %77 = extractelement <2 x float> %73, i32 0
  %78 = tail call float @llvm.fabs.f32(float %77) #4
  %79 = tail call float @llvm.maxnum.f32(float %76, float %78) #4
  call void @llvm.lifetime.start.p5i8(i64 2, i8 addrspace(5)* %4) #4
  %mul60 = fmul float %79, 0x3FC5555560000000
  %mul61 = fmul float %cond29, %mul60
  %cmp.i379 = fcmp ult float %mul61, 4.480000e+02
  br i1 %cmp.i379, label %_Z4dec8i.exit.i.2, label %_Z4enc8f.exit.thread396

_Z4enc8f.exit.thread396:                          ; preds = %for.body34
  store i8 126, i8 addrspace(5)* %4, align 1, !tbaa !12
  br label %cond.true.i

_Z4enc8f.exit.thread:                             ; preds = %_Z4dec8i.exit.i.2
  store i8 0, i8 addrspace(5)* %4, align 1, !tbaa !12
  br label %cond.false.i377

if.end9.i:                                        ; preds = %_Z4dec8i.exit.i.2
  %sub.i382 = add nsw i32 %lo.1.i.6, -1
  %shr.i62.i = ashr i32 %sub.i382, 3
  %and.i63.i = and i32 %sub.i382, 7
  %tobool.not.i64.i = icmp eq i32 %shr.i62.i, 0
  %conv1.i70.i = sitofp i32 %and.i63.i to float
  %mul.i66.i = fmul float %conv1.i70.i, 1.250000e-01
  %add.i67.i = fadd float %mul.i66.i, 1.000000e+00
  %sub.i68.i = add nsw i32 %shr.i62.i, -7
  %80 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i67.i, i32 %sub.i68.i) #4
  %mul2.i71.i = fmul float %conv1.i70.i, 0x3F60000000000000
  %cond.i73.i = select i1 %tobool.not.i64.i, float %mul2.i71.i, float %80
  %sub11.i = fsub float %mul61, %cond.i73.i
  %shr.i49.i657 = lshr i32 %lo.1.i.6, 3
  %and.i50.i = and i32 %lo.1.i.6, 7
  %tobool.not.i51.i = icmp eq i32 %shr.i49.i657, 0
  %conv1.i57.i = sitofp i32 %and.i50.i to float
  %mul.i53.i = fmul float %conv1.i57.i, 1.250000e-01
  %add.i54.i = fadd float %mul.i53.i, 1.000000e+00
  %sub.i55.i = add nsw i32 %shr.i49.i657, -7
  %81 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i54.i, i32 %sub.i55.i) #4
  %mul2.i58.i = fmul float %conv1.i57.i, 0x3F60000000000000
  %cond.i60.i = select i1 %tobool.not.i51.i, float %mul2.i58.i, float %81
  %sub13.i = fsub float %cond.i60.i, %mul61
  %cmp14.i = fcmp olt float %sub11.i, %sub13.i
  br i1 %cmp14.i, label %_Z4enc8f.exit, label %cond.false.i384

cond.false.i384:                                  ; preds = %if.end9.i
  %cmp16.i383 = fcmp olt float %sub13.i, %sub11.i
  %and.i385 = and i32 %lo.1.i.6, 1
  %tobool.not.i386 = icmp eq i32 %and.i385, 0
  %cond.i387 = select i1 %tobool.not.i386, i32 %lo.1.i.6, i32 %sub.i382
  br i1 %cmp16.i383, label %_Z4enc8f.exit, label %cond.false18.i

cond.false18.i:                                   ; preds = %cond.false.i384
  %.pre449 = and i32 %cond.i387, 7
  br label %_Z4enc8f.exit

_Z4enc8f.exit:                                    ; preds = %cond.false18.i, %cond.false.i384, %if.end9.i
  %and.i375.pre-phi = phi i32 [ %and.i63.i, %if.end9.i ], [ %and.i50.i, %cond.false.i384 ], [ %.pre449, %cond.false18.i ]
  %cond25.i = phi i32 [ %sub.i382, %if.end9.i ], [ %lo.1.i.6, %cond.false.i384 ], [ %cond.i387, %cond.false18.i ]
  %conv.i388 = trunc i32 %cond25.i to i8
  store i8 %conv.i388, i8 addrspace(5)* %4, align 1, !tbaa !12
  %conv67 = lshr i32 %cond25.i, 3
  %tobool.not.i = icmp eq i32 %conv67, 0
  br i1 %tobool.not.i, label %cond.false.i377, label %cond.true.i

cond.true.i:                                      ; preds = %_Z4enc8f.exit, %_Z4enc8f.exit.thread396
  %and.i375404 = phi i32 [ 6, %_Z4enc8f.exit.thread396 ], [ %and.i375.pre-phi, %_Z4enc8f.exit ]
  %shr.i374403 = phi i32 [ 15, %_Z4enc8f.exit.thread396 ], [ %conv67, %_Z4enc8f.exit ]
  %conv.i376 = sitofp i32 %and.i375404 to float
  %mul.i = fmul float %conv.i376, 1.250000e-01
  %add.i = fadd float %mul.i, 1.000000e+00
  %sub.i = add nsw i32 %shr.i374403, -7
  %82 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i, i32 %sub.i) #4
  br label %_Z4dec8i.exit

cond.false.i377:                                  ; preds = %_Z4enc8f.exit, %_Z4enc8f.exit.thread
  %and.i375395 = phi i32 [ 0, %_Z4enc8f.exit.thread ], [ %and.i375.pre-phi, %_Z4enc8f.exit ]
  %conv1.i = sitofp i32 %and.i375395 to float
  %mul2.i = fmul float %conv1.i, 0x3F60000000000000
  br label %_Z4dec8i.exit

_Z4dec8i.exit:                                    ; preds = %cond.false.i377, %cond.true.i
  %cond.i378 = phi float [ %82, %cond.true.i ], [ %mul2.i, %cond.false.i377 ]
  %cmp69 = fcmp une float %cond.i378, 0.000000e+00
  br i1 %cmp69, label %cond.end75, label %cond.end75.thread

cond.end75.thread:                                ; preds = %_Z4dec8i.exit
  %83 = insertelement <2 x float> %os.sroa.0.2, float 0.000000e+00, i32 0
  br label %if.then97.7

cond.end75:                                       ; preds = %_Z4dec8i.exit
  %mul72 = fmul float %div71, %cond.i378
  %div73 = fdiv float 1.000000e+00, %mul72
  %84 = insertelement <2 x float> %os.sroa.0.2, float %div73, i32 0
  %cmp81 = fcmp une float %div73, 0.000000e+00
  %div85 = fdiv float 1.000000e+00, %div73
  %cond88 = select i1 %cmp81, float %div85, float 0.000000e+00
  %cmp96 = fcmp oeq float %div73, 0.000000e+00
  br i1 %cmp96, label %if.then97.7, label %if.else.7

cond.false.i353:                                  ; preds = %for.inc138.7.1
  %cmp1.i352 = fcmp olt float %477, 7.500000e-01
  br i1 %cmp1.i352, label %_Z5pack4f.exit369, label %cond.false3.i355

cond.false3.i355:                                 ; preds = %cond.false.i353
  %cmp4.i354 = fcmp ugt float %477, 1.250000e+00
  br i1 %cmp4.i354, label %cond.false6.i357, label %_Z5pack4f.exit369

cond.false6.i357:                                 ; preds = %cond.false3.i355
  %cmp7.i356 = fcmp olt float %477, 1.750000e+00
  br i1 %cmp7.i356, label %_Z5pack4f.exit369, label %cond.false9.i359

cond.false9.i359:                                 ; preds = %cond.false6.i357
  %cmp10.i358 = fcmp ugt float %477, 2.500000e+00
  br i1 %cmp10.i358, label %cond.false12.i361, label %_Z5pack4f.exit369

cond.false12.i361:                                ; preds = %cond.false9.i359
  %cmp13.i360 = fcmp olt float %477, 3.500000e+00
  br i1 %cmp13.i360, label %_Z5pack4f.exit369, label %cond.false15.i364

cond.false15.i364:                                ; preds = %cond.false12.i361
  %cmp16.i362 = fcmp ole float %477, 5.000000e+00
  %cond.i363 = select i1 %cmp16.i362, i32 6, i32 7
  br label %_Z5pack4f.exit369

_Z5pack4f.exit369:                                ; preds = %for.inc138.7.1, %cond.false15.i364, %cond.false12.i361, %cond.false9.i359, %cond.false6.i357, %cond.false3.i355, %cond.false.i353
  %cond27.i365 = phi i32 [ 1, %cond.false.i353 ], [ 2, %cond.false3.i355 ], [ 3, %cond.false6.i357 ], [ 4, %cond.false9.i359 ], [ 5, %cond.false12.i361 ], [ %cond.i363, %cond.false15.i364 ], [ 0, %for.inc138.7.1 ]
  %85 = bitcast float %mul175 to i32
  %shr.i366 = lshr i32 %85, 28
  %and.i367 = and i32 %shr.i366, 8
  %or.i368 = or i32 %cond27.i365, %and.i367
  %mul183 = fmul float %476, %16
  %86 = tail call float @llvm.fabs.f32(float %mul183) #4
  %cmp.i = fcmp ugt float %86, 2.500000e-01
  br i1 %cmp.i, label %cond.false.i, label %_Z5pack4f.exit

cond.false.i:                                     ; preds = %_Z5pack4f.exit369
  %cmp1.i = fcmp olt float %86, 7.500000e-01
  br i1 %cmp1.i, label %_Z5pack4f.exit, label %cond.false3.i

cond.false3.i:                                    ; preds = %cond.false.i
  %cmp4.i = fcmp ugt float %86, 1.250000e+00
  br i1 %cmp4.i, label %cond.false6.i, label %_Z5pack4f.exit

cond.false6.i:                                    ; preds = %cond.false3.i
  %cmp7.i = fcmp olt float %86, 1.750000e+00
  br i1 %cmp7.i, label %_Z5pack4f.exit, label %cond.false9.i

cond.false9.i:                                    ; preds = %cond.false6.i
  %cmp10.i = fcmp ugt float %86, 2.500000e+00
  br i1 %cmp10.i, label %cond.false12.i, label %_Z5pack4f.exit

cond.false12.i:                                   ; preds = %cond.false9.i
  %cmp13.i = fcmp olt float %86, 3.500000e+00
  br i1 %cmp13.i, label %_Z5pack4f.exit, label %cond.false15.i

cond.false15.i:                                   ; preds = %cond.false12.i
  %cmp16.i = fcmp ole float %86, 5.000000e+00
  %cond.i = select i1 %cmp16.i, i32 6, i32 7
  br label %_Z5pack4f.exit

_Z5pack4f.exit:                                   ; preds = %cond.false15.i, %cond.false12.i, %cond.false9.i, %cond.false6.i, %cond.false3.i, %cond.false.i, %_Z5pack4f.exit369
  %cond27.i = phi i32 [ 0, %_Z5pack4f.exit369 ], [ 1, %cond.false.i ], [ 2, %cond.false3.i ], [ 3, %cond.false6.i ], [ 4, %cond.false9.i ], [ 5, %cond.false12.i ], [ %cond.i, %cond.false15.i ]
  %87 = bitcast float %mul183 to i32
  %shr.i = lshr i32 %87, 28
  %and.i = and i32 %shr.i, 8
  %or.i = or i32 %cond27.i, %and.i
  %shl = shl nuw nsw i32 %or.i, 4
  %or = or i32 %or.i368, %shl
  %conv185 = trunc i32 %or to i8
  %arrayidx188339 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add164
  store i8 %conv185, i8 addrspace(1)* %arrayidx188339, align 1, !tbaa !12
  %mul175.1 = fmul float %476, %20
  %88 = tail call float @llvm.fabs.f32(float %mul175.1) #4
  %cmp.i351.1 = fcmp ugt float %88, 2.500000e-01
  br i1 %cmp.i351.1, label %cond.false.i353.1, label %_Z5pack4f.exit369.1

if.then193:                                       ; preds = %_Z5pack4f.exit.7
  %div197 = sdiv i32 %rem36.decomposed, %div196.frozen
  %add198 = add nsw i32 %div197, %mul195
  %89 = mul i32 %div197, %div196.frozen
  %rem200.decomposed = sub i32 %rem36.decomposed, %89
  %mul201 = shl nsw i32 %rem200.decomposed, 2
  %add203 = add nsw i32 %rem202.decomposed, %mul201
  br label %if.end204

if.end204:                                        ; preds = %_Z5pack4f.exit.7, %if.then193
  %st.0 = phi i32 [ %add198, %if.then193 ], [ %conv9, %_Z5pack4f.exit.7 ]
  %ss.0 = phi i32 [ %add203, %if.then193 ], [ %rem36.decomposed, %_Z5pack4f.exit.7 ]
  %arrayidx206334 = getelementptr inbounds [2 x i8], [2 x i8] addrspace(5)* %code, i32 0, i32 %475
  %90 = load i8, i8 addrspace(5)* %arrayidx206334, align 1, !tbaa !12
  %conv213 = sext i32 %st.0 to i64
  %add214 = add nsw i64 %mul156, %conv213
  %mul216 = mul nsw i64 %add214, %conv215
  %conv217 = sext i32 %ss.0 to i64
  %add218 = add nsw i64 %mul216, %conv217
  %arrayidx219335 = getelementptr inbounds i8, i8 addrspace(1)* %cond24.v, i64 %add218
  store i8 %90, i8 addrspace(1)* %arrayidx219335, align 1, !tbaa !12
  call void @llvm.lifetime.end.p5i8(i64 2, i8 addrspace(5)* %4) #4
  %add222 = add i32 %g.0419, %9
  %cmp32 = icmp slt i32 %add222, %mul
  br i1 %cmp32, label %for.body34, label %for.cond.cleanup33

cleanup:                                          ; preds = %for.cond.cleanup33, %entry
  ret void

_Z4dec8i.exit.i.2:                                ; preds = %for.body34
  %cmp2.i = fcmp ogt float %mul61, 1.875000e+00
  %hi.1.i = select i1 %cmp2.i, i32 126, i32 63
  %lo.1.i = select i1 %cmp2.i, i32 64, i32 0
  %div.i.1 = select i1 %cmp2.i, i32 95, i32 31
  %91 = lshr i32 %div.i.1, 3
  %sub.i.i.1 = add nsw i32 %91, -7
  %92 = tail call float @llvm.amdgcn.ldexp.f32(float 1.875000e+00, i32 %sub.i.i.1) #4
  %cmp2.i.1 = fcmp olt float %92, %mul61
  %add4.i.1 = add nuw nsw i32 %div.i.1, 1
  %hi.1.i.1 = select i1 %cmp2.i.1, i32 %hi.1.i, i32 %div.i.1
  %lo.1.i.1 = select i1 %cmp2.i.1, i32 %add4.i.1, i32 %lo.1.i
  %add.i381.2 = add nuw nsw i32 %lo.1.i.1, %hi.1.i.1
  %div.i.2 = lshr i32 %add.i381.2, 1
  %93 = lshr i32 %add.i381.2, 4
  %sub.i.i.2 = add nsw i32 %93, -7
  %94 = tail call float @llvm.amdgcn.ldexp.f32(float 1.875000e+00, i32 %sub.i.i.2) #4
  %cmp2.i.2 = fcmp olt float %94, %mul61
  %add4.i.2 = add nuw nsw i32 %div.i.2, 1
  %hi.1.i.2 = select i1 %cmp2.i.2, i32 %hi.1.i.1, i32 %div.i.2
  %lo.1.i.2 = select i1 %cmp2.i.2, i32 %add4.i.2, i32 %lo.1.i.1
  %add.i381.3 = add nuw nsw i32 %lo.1.i.2, %hi.1.i.2
  %div.i.3 = lshr i32 %add.i381.3, 1
  %95 = lshr i32 %add.i381.3, 4
  %and.i.i.3 = and i32 %div.i.3, 7
  %tobool.not.i.i.3 = icmp eq i32 %95, 0
  %conv1.i.i.3 = sitofp i32 %and.i.i.3 to float
  %mul.i.i.3 = fmul float %conv1.i.i.3, 1.250000e-01
  %add.i.i.3 = fadd float %mul.i.i.3, 1.000000e+00
  %sub.i.i.3 = add nsw i32 %95, -7
  %96 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.3, i32 %sub.i.i.3) #4
  %mul2.i.i.3 = fmul float %conv1.i.i.3, 0x3F60000000000000
  %cond.i.i.3 = select i1 %tobool.not.i.i.3, float %mul2.i.i.3, float %96
  %cmp2.i.3 = fcmp olt float %cond.i.i.3, %mul61
  %add4.i.3 = add nuw nsw i32 %div.i.3, 1
  %hi.1.i.3 = select i1 %cmp2.i.3, i32 %hi.1.i.2, i32 %div.i.3
  %lo.1.i.3 = select i1 %cmp2.i.3, i32 %add4.i.3, i32 %lo.1.i.2
  %add.i381.4 = add nuw nsw i32 %lo.1.i.3, %hi.1.i.3
  %div.i.4 = lshr i32 %add.i381.4, 1
  %97 = lshr i32 %add.i381.4, 4
  %and.i.i.4 = and i32 %div.i.4, 7
  %tobool.not.i.i.4 = icmp eq i32 %97, 0
  %conv1.i.i.4 = sitofp i32 %and.i.i.4 to float
  %mul.i.i.4 = fmul float %conv1.i.i.4, 1.250000e-01
  %add.i.i.4 = fadd float %mul.i.i.4, 1.000000e+00
  %sub.i.i.4 = add nsw i32 %97, -7
  %98 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.4, i32 %sub.i.i.4) #4
  %mul2.i.i.4 = fmul float %conv1.i.i.4, 0x3F60000000000000
  %cond.i.i.4 = select i1 %tobool.not.i.i.4, float %mul2.i.i.4, float %98
  %cmp2.i.4 = fcmp olt float %cond.i.i.4, %mul61
  %add4.i.4 = add nuw nsw i32 %div.i.4, 1
  %hi.1.i.4 = select i1 %cmp2.i.4, i32 %hi.1.i.3, i32 %div.i.4
  %lo.1.i.4 = select i1 %cmp2.i.4, i32 %add4.i.4, i32 %lo.1.i.3
  %add.i381.5 = add nuw nsw i32 %lo.1.i.4, %hi.1.i.4
  %div.i.5 = sdiv i32 %add.i381.5, 2
  %shr.i.i.5 = ashr i32 %div.i.5, 3
  %and.i.i.5 = and i32 %div.i.5, 7
  %tobool.not.i.i.5 = icmp eq i32 %shr.i.i.5, 0
  %conv1.i.i.5 = sitofp i32 %and.i.i.5 to float
  %mul.i.i.5 = fmul float %conv1.i.i.5, 1.250000e-01
  %add.i.i.5 = fadd float %mul.i.i.5, 1.000000e+00
  %sub.i.i.5 = add nsw i32 %shr.i.i.5, -7
  %99 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.5, i32 %sub.i.i.5) #4
  %mul2.i.i.5 = fmul float %conv1.i.i.5, 0x3F60000000000000
  %cond.i.i.5 = select i1 %tobool.not.i.i.5, float %mul2.i.i.5, float %99
  %cmp2.i.5 = fcmp olt float %cond.i.i.5, %mul61
  %add4.i.5 = add nuw nsw i32 %div.i.5, 1
  %hi.1.i.5 = select i1 %cmp2.i.5, i32 %hi.1.i.4, i32 %div.i.5
  %lo.1.i.5 = select i1 %cmp2.i.5, i32 %add4.i.5, i32 %lo.1.i.4
  %add.i381.6 = add nuw nsw i32 %lo.1.i.5, %hi.1.i.5
  %div.i.6 = sdiv i32 %add.i381.6, 2
  %shr.i.i.6 = ashr i32 %div.i.6, 3
  %and.i.i.6 = and i32 %div.i.6, 7
  %tobool.not.i.i.6 = icmp eq i32 %shr.i.i.6, 0
  %conv1.i.i.6 = sitofp i32 %and.i.i.6 to float
  %mul.i.i.6 = fmul float %conv1.i.i.6, 1.250000e-01
  %add.i.i.6 = fadd float %mul.i.i.6, 1.000000e+00
  %sub.i.i.6 = add nsw i32 %shr.i.i.6, -7
  %100 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.6, i32 %sub.i.i.6) #4
  %mul2.i.i.6 = fmul float %conv1.i.i.6, 0x3F60000000000000
  %cond.i.i.6 = select i1 %tobool.not.i.i.6, float %mul2.i.i.6, float %100
  %cmp2.i.6 = fcmp olt float %cond.i.i.6, %mul61
  %add4.i.6 = add nuw nsw i32 %div.i.6, 1
  %lo.1.i.6 = select i1 %cmp2.i.6, i32 %add4.i.6, i32 %lo.1.i.5
  %cmp6.i = icmp eq i32 %lo.1.i.6, 0
  br i1 %cmp6.i, label %_Z4enc8f.exit.thread, label %if.end9.i

if.else.7:                                        ; preds = %cond.end75
  %mul116 = fmul float %div73, %12
  %101 = tail call float @llvm.fabs.f32(float %mul116) #4
  %decision.interval2 = fcmp ugt float %101, 2.500000e+00
  %102 = fcmp olt float %101, 1.750000e+00
  %103 = fcmp ole float %101, 1.250000e+00
  %merged.select = select i1 %decision.interval2, float 3.500000e+00, float 7.500000e-01
  %104 = fcmp olt float %101, %merged.select
  %105 = fcmp ole float %101, 2.500000e-01
  %106 = select i1 %105, float 0.000000e+00, float 5.000000e-01
  %107 = fcmp ugt float %101, 5.000000e+00
  %guard.value = select i1 %decision.interval2, float undef, float %106
  %108 = select i1 %104, float %guard.value, float 1.000000e+00
  %merged.select3 = select i1 %decision.interval2, i1 %107, i1 %103
  %merged.select4 = select i1 %decision.interval2, float 6.000000e+00, float %108
  %merged.select5 = select i1 %decision.interval2, float 4.000000e+00, float 1.500000e+00
  %109 = select i1 %merged.select3, float %merged.select4, float %merged.select5
  %merged.select6 = select i1 %decision.interval2, i1 %104, i1 %102
  %merged.select7 = select i1 %decision.interval2, float 3.000000e+00, float %109
  %merged.select8 = select i1 %decision.interval2, float %109, float 2.000000e+00
  %110 = select i1 %merged.select6, float %merged.select7, float %merged.select8
  %111 = tail call float @llvm.copysign.f32(float %110, float %mul116) #4
  %mul118 = fmul float %cond88, %111
  %sub = fsub float %mul118, %12
  %mul126 = fmul float %div73, %16
  %112 = tail call float @llvm.fabs.f32(float %mul126) #4
  %decision.interval3 = fcmp ugt float %112, 2.500000e+00
  %113 = fcmp olt float %112, 1.750000e+00
  %114 = fcmp ole float %112, 1.250000e+00
  %merged.select1 = select i1 %decision.interval3, float 3.500000e+00, float 7.500000e-01
  %115 = fcmp olt float %112, %merged.select1
  %116 = fcmp ole float %112, 2.500000e-01
  %117 = select i1 %116, float 0.000000e+00, float 5.000000e-01
  %118 = fcmp ugt float %112, 5.000000e+00
  %guard.value17 = select i1 %decision.interval3, float undef, float %117
  %119 = select i1 %115, float %guard.value17, float 1.000000e+00
  %merged.select10 = select i1 %decision.interval3, i1 %118, i1 %114
  %merged.select11 = select i1 %decision.interval3, float 6.000000e+00, float %119
  %merged.select12 = select i1 %decision.interval3, float 4.000000e+00, float 1.500000e+00
  %120 = select i1 %merged.select10, float %merged.select11, float %merged.select12
  %merged.select13 = select i1 %decision.interval3, i1 %115, i1 %113
  %merged.select14 = select i1 %decision.interval3, float 3.000000e+00, float %120
  %merged.select15 = select i1 %decision.interval3, float %120, float 2.000000e+00
  %121 = select i1 %merged.select13, float %merged.select14, float %merged.select15
  %122 = tail call float @llvm.copysign.f32(float %121, float %mul126) #4
  %mul128 = fmul float %cond88, %122
  %sub132 = fsub float %mul128, %16
  %mul133 = fmul float %sub, %sub
  %mul134 = fmul float %sub132, %sub132
  %add135 = fadd float %mul133, %mul134
  %e.1 = fadd float %add135, 0.000000e+00
  %mul116.1 = fmul float %div73, %20
  %123 = tail call float @llvm.fabs.f32(float %mul116.1) #4
  %decision.interval4 = fcmp ugt float %123, 2.500000e+00
  %124 = fcmp olt float %123, 1.750000e+00
  %125 = fcmp ole float %123, 1.250000e+00
  %merged.select2 = select i1 %decision.interval4, float 3.500000e+00, float 7.500000e-01
  %126 = fcmp olt float %123, %merged.select2
  %127 = fcmp ole float %123, 2.500000e-01
  %128 = select i1 %127, float 0.000000e+00, float 5.000000e-01
  %129 = fcmp ugt float %123, 5.000000e+00
  %guard.value24 = select i1 %decision.interval4, float undef, float %128
  %130 = select i1 %126, float %guard.value24, float 1.000000e+00
  %merged.select17 = select i1 %decision.interval4, i1 %129, i1 %125
  %merged.select18 = select i1 %decision.interval4, float 6.000000e+00, float %130
  %merged.select19 = select i1 %decision.interval4, float 4.000000e+00, float 1.500000e+00
  %131 = select i1 %merged.select17, float %merged.select18, float %merged.select19
  %merged.select20 = select i1 %decision.interval4, i1 %126, i1 %124
  %merged.select21 = select i1 %decision.interval4, float 3.000000e+00, float %131
  %merged.select22 = select i1 %decision.interval4, float %131, float 2.000000e+00
  %132 = select i1 %merged.select20, float %merged.select21, float %merged.select22
  %133 = tail call float @llvm.copysign.f32(float %132, float %mul116.1) #4
  %mul118.1 = fmul float %cond88, %133
  %sub.1 = fsub float %mul118.1, %20
  %mul126.1 = fmul float %div73, %24
  %134 = tail call float @llvm.fabs.f32(float %mul126.1) #4
  %decision.interval5 = fcmp ugt float %134, 2.500000e+00
  %135 = fcmp olt float %134, 1.750000e+00
  %136 = fcmp ole float %134, 1.250000e+00
  %merged.select9 = select i1 %decision.interval5, float 3.500000e+00, float 7.500000e-01
  %137 = fcmp olt float %134, %merged.select9
  %138 = fcmp ole float %134, 2.500000e-01
  %139 = select i1 %138, float 0.000000e+00, float 5.000000e-01
  %140 = fcmp ugt float %134, 5.000000e+00
  %guard.value31 = select i1 %decision.interval5, float undef, float %139
  %141 = select i1 %137, float %guard.value31, float 1.000000e+00
  %merged.select24 = select i1 %decision.interval5, i1 %140, i1 %136
  %merged.select25 = select i1 %decision.interval5, float 6.000000e+00, float %141
  %merged.select26 = select i1 %decision.interval5, float 4.000000e+00, float 1.500000e+00
  %142 = select i1 %merged.select24, float %merged.select25, float %merged.select26
  %merged.select27 = select i1 %decision.interval5, i1 %137, i1 %135
  %merged.select28 = select i1 %decision.interval5, float 3.000000e+00, float %142
  %merged.select29 = select i1 %decision.interval5, float %142, float 2.000000e+00
  %143 = select i1 %merged.select27, float %merged.select28, float %merged.select29
  %144 = tail call float @llvm.copysign.f32(float %143, float %mul126.1) #4
  %mul128.1 = fmul float %cond88, %144
  %sub132.1 = fsub float %mul128.1, %24
  %mul133.1 = fmul float %sub.1, %sub.1
  %mul134.1 = fmul float %sub132.1, %sub132.1
  %add135.1 = fadd float %mul133.1, %mul134.1
  %e.1.1 = fadd float %e.1, %add135.1
  %mul116.2 = fmul float %div73, %28
  %145 = tail call float @llvm.fabs.f32(float %mul116.2) #4
  %decision.interval6 = fcmp ugt float %145, 2.500000e+00
  %146 = fcmp olt float %145, 1.750000e+00
  %147 = fcmp ole float %145, 1.250000e+00
  %merged.select16 = select i1 %decision.interval6, float 3.500000e+00, float 7.500000e-01
  %148 = fcmp olt float %145, %merged.select16
  %149 = fcmp ole float %145, 2.500000e-01
  %150 = select i1 %149, float 0.000000e+00, float 5.000000e-01
  %151 = fcmp ugt float %145, 5.000000e+00
  %guard.value38 = select i1 %decision.interval6, float undef, float %150
  %152 = select i1 %148, float %guard.value38, float 1.000000e+00
  %merged.select31 = select i1 %decision.interval6, i1 %151, i1 %147
  %merged.select32 = select i1 %decision.interval6, float 6.000000e+00, float %152
  %merged.select33 = select i1 %decision.interval6, float 4.000000e+00, float 1.500000e+00
  %153 = select i1 %merged.select31, float %merged.select32, float %merged.select33
  %merged.select34 = select i1 %decision.interval6, i1 %148, i1 %146
  %merged.select35 = select i1 %decision.interval6, float 3.000000e+00, float %153
  %merged.select36 = select i1 %decision.interval6, float %153, float 2.000000e+00
  %154 = select i1 %merged.select34, float %merged.select35, float %merged.select36
  %155 = tail call float @llvm.copysign.f32(float %154, float %mul116.2) #4
  %mul118.2 = fmul float %cond88, %155
  %sub.2 = fsub float %mul118.2, %28
  %mul126.2 = fmul float %div73, %32
  %156 = tail call float @llvm.fabs.f32(float %mul126.2) #4
  %decision.interval7 = fcmp ugt float %156, 2.500000e+00
  %157 = fcmp olt float %156, 1.750000e+00
  %158 = fcmp ole float %156, 1.250000e+00
  %merged.select23 = select i1 %decision.interval7, float 3.500000e+00, float 7.500000e-01
  %159 = fcmp olt float %156, %merged.select23
  %160 = fcmp ole float %156, 2.500000e-01
  %161 = select i1 %160, float 0.000000e+00, float 5.000000e-01
  %162 = fcmp ugt float %156, 5.000000e+00
  %guard.value45 = select i1 %decision.interval7, float undef, float %161
  %163 = select i1 %159, float %guard.value45, float 1.000000e+00
  %merged.select38 = select i1 %decision.interval7, i1 %162, i1 %158
  %merged.select39 = select i1 %decision.interval7, float 6.000000e+00, float %163
  %merged.select40 = select i1 %decision.interval7, float 4.000000e+00, float 1.500000e+00
  %164 = select i1 %merged.select38, float %merged.select39, float %merged.select40
  %merged.select41 = select i1 %decision.interval7, i1 %159, i1 %157
  %merged.select42 = select i1 %decision.interval7, float 3.000000e+00, float %164
  %merged.select43 = select i1 %decision.interval7, float %164, float 2.000000e+00
  %165 = select i1 %merged.select41, float %merged.select42, float %merged.select43
  %166 = tail call float @llvm.copysign.f32(float %165, float %mul126.2) #4
  %mul128.2 = fmul float %cond88, %166
  %sub132.2 = fsub float %mul128.2, %32
  %mul133.2 = fmul float %sub.2, %sub.2
  %mul134.2 = fmul float %sub132.2, %sub132.2
  %add135.2 = fadd float %mul133.2, %mul134.2
  %e.1.2 = fadd float %e.1.1, %add135.2
  %mul116.3 = fmul float %div73, %36
  %167 = tail call float @llvm.fabs.f32(float %mul116.3) #4
  %decision.interval8 = fcmp ugt float %167, 2.500000e+00
  %168 = fcmp olt float %167, 1.750000e+00
  %169 = fcmp ole float %167, 1.250000e+00
  %merged.select30 = select i1 %decision.interval8, float 3.500000e+00, float 7.500000e-01
  %170 = fcmp olt float %167, %merged.select30
  %171 = fcmp ole float %167, 2.500000e-01
  %172 = select i1 %171, float 0.000000e+00, float 5.000000e-01
  %173 = fcmp ugt float %167, 5.000000e+00
  %guard.value52 = select i1 %decision.interval8, float undef, float %172
  %174 = select i1 %170, float %guard.value52, float 1.000000e+00
  %merged.select45 = select i1 %decision.interval8, i1 %173, i1 %169
  %merged.select46 = select i1 %decision.interval8, float 6.000000e+00, float %174
  %merged.select47 = select i1 %decision.interval8, float 4.000000e+00, float 1.500000e+00
  %175 = select i1 %merged.select45, float %merged.select46, float %merged.select47
  %merged.select48 = select i1 %decision.interval8, i1 %170, i1 %168
  %merged.select49 = select i1 %decision.interval8, float 3.000000e+00, float %175
  %merged.select50 = select i1 %decision.interval8, float %175, float 2.000000e+00
  %176 = select i1 %merged.select48, float %merged.select49, float %merged.select50
  %177 = tail call float @llvm.copysign.f32(float %176, float %mul116.3) #4
  %mul118.3 = fmul float %cond88, %177
  %sub.3 = fsub float %mul118.3, %36
  %mul126.3 = fmul float %div73, %40
  %178 = tail call float @llvm.fabs.f32(float %mul126.3) #4
  %decision.interval9 = fcmp ugt float %178, 2.500000e+00
  %179 = fcmp olt float %178, 1.750000e+00
  %180 = fcmp ole float %178, 1.250000e+00
  %merged.select37 = select i1 %decision.interval9, float 3.500000e+00, float 7.500000e-01
  %181 = fcmp olt float %178, %merged.select37
  %182 = fcmp ole float %178, 2.500000e-01
  %183 = select i1 %182, float 0.000000e+00, float 5.000000e-01
  %184 = fcmp ugt float %178, 5.000000e+00
  %guard.value59 = select i1 %decision.interval9, float undef, float %183
  %185 = select i1 %181, float %guard.value59, float 1.000000e+00
  %merged.select52 = select i1 %decision.interval9, i1 %184, i1 %180
  %merged.select53 = select i1 %decision.interval9, float 6.000000e+00, float %185
  %merged.select54 = select i1 %decision.interval9, float 4.000000e+00, float 1.500000e+00
  %186 = select i1 %merged.select52, float %merged.select53, float %merged.select54
  %merged.select55 = select i1 %decision.interval9, i1 %181, i1 %179
  %merged.select56 = select i1 %decision.interval9, float 3.000000e+00, float %186
  %merged.select57 = select i1 %decision.interval9, float %186, float 2.000000e+00
  %187 = select i1 %merged.select55, float %merged.select56, float %merged.select57
  %188 = tail call float @llvm.copysign.f32(float %187, float %mul126.3) #4
  %mul128.3 = fmul float %cond88, %188
  %sub132.3 = fsub float %mul128.3, %40
  %mul133.3 = fmul float %sub.3, %sub.3
  %mul134.3 = fmul float %sub132.3, %sub132.3
  %add135.3 = fadd float %mul133.3, %mul134.3
  %e.1.3 = fadd float %e.1.2, %add135.3
  %mul116.4 = fmul float %div73, %44
  %189 = tail call float @llvm.fabs.f32(float %mul116.4) #4
  %decision.interval10 = fcmp ugt float %189, 2.500000e+00
  %190 = fcmp olt float %189, 1.750000e+00
  %191 = fcmp ole float %189, 1.250000e+00
  %merged.select44 = select i1 %decision.interval10, float 3.500000e+00, float 7.500000e-01
  %192 = fcmp olt float %189, %merged.select44
  %193 = fcmp ole float %189, 2.500000e-01
  %194 = select i1 %193, float 0.000000e+00, float 5.000000e-01
  %195 = fcmp ugt float %189, 5.000000e+00
  %guard.value66 = select i1 %decision.interval10, float undef, float %194
  %196 = select i1 %192, float %guard.value66, float 1.000000e+00
  %merged.select59 = select i1 %decision.interval10, i1 %195, i1 %191
  %merged.select60 = select i1 %decision.interval10, float 6.000000e+00, float %196
  %merged.select61 = select i1 %decision.interval10, float 4.000000e+00, float 1.500000e+00
  %197 = select i1 %merged.select59, float %merged.select60, float %merged.select61
  %merged.select62 = select i1 %decision.interval10, i1 %192, i1 %190
  %merged.select63 = select i1 %decision.interval10, float 3.000000e+00, float %197
  %merged.select64 = select i1 %decision.interval10, float %197, float 2.000000e+00
  %198 = select i1 %merged.select62, float %merged.select63, float %merged.select64
  %199 = tail call float @llvm.copysign.f32(float %198, float %mul116.4) #4
  %mul118.4 = fmul float %cond88, %199
  %sub.4 = fsub float %mul118.4, %44
  %mul126.4 = fmul float %div73, %48
  %200 = tail call float @llvm.fabs.f32(float %mul126.4) #4
  %decision.interval11 = fcmp ugt float %200, 2.500000e+00
  %201 = fcmp olt float %200, 1.750000e+00
  %202 = fcmp ole float %200, 1.250000e+00
  %merged.select51 = select i1 %decision.interval11, float 3.500000e+00, float 7.500000e-01
  %203 = fcmp olt float %200, %merged.select51
  %204 = fcmp ole float %200, 2.500000e-01
  %205 = select i1 %204, float 0.000000e+00, float 5.000000e-01
  %206 = fcmp ugt float %200, 5.000000e+00
  %guard.value73 = select i1 %decision.interval11, float undef, float %205
  %207 = select i1 %203, float %guard.value73, float 1.000000e+00
  %merged.select66 = select i1 %decision.interval11, i1 %206, i1 %202
  %merged.select67 = select i1 %decision.interval11, float 6.000000e+00, float %207
  %merged.select68 = select i1 %decision.interval11, float 4.000000e+00, float 1.500000e+00
  %208 = select i1 %merged.select66, float %merged.select67, float %merged.select68
  %merged.select69 = select i1 %decision.interval11, i1 %203, i1 %201
  %merged.select70 = select i1 %decision.interval11, float 3.000000e+00, float %208
  %merged.select71 = select i1 %decision.interval11, float %208, float 2.000000e+00
  %209 = select i1 %merged.select69, float %merged.select70, float %merged.select71
  %210 = tail call float @llvm.copysign.f32(float %209, float %mul126.4) #4
  %mul128.4 = fmul float %cond88, %210
  %sub132.4 = fsub float %mul128.4, %48
  %mul133.4 = fmul float %sub.4, %sub.4
  %mul134.4 = fmul float %sub132.4, %sub132.4
  %add135.4 = fadd float %mul133.4, %mul134.4
  %e.1.4 = fadd float %e.1.3, %add135.4
  %mul116.5 = fmul float %div73, %52
  %211 = tail call float @llvm.fabs.f32(float %mul116.5) #4
  %decision.interval12 = fcmp ugt float %211, 2.500000e+00
  %212 = fcmp olt float %211, 1.750000e+00
  %213 = fcmp ole float %211, 1.250000e+00
  %merged.select58 = select i1 %decision.interval12, float 3.500000e+00, float 7.500000e-01
  %214 = fcmp olt float %211, %merged.select58
  %215 = fcmp ole float %211, 2.500000e-01
  %216 = select i1 %215, float 0.000000e+00, float 5.000000e-01
  %217 = fcmp ugt float %211, 5.000000e+00
  %guard.value80 = select i1 %decision.interval12, float undef, float %216
  %218 = select i1 %214, float %guard.value80, float 1.000000e+00
  %merged.select73 = select i1 %decision.interval12, i1 %217, i1 %213
  %merged.select74 = select i1 %decision.interval12, float 6.000000e+00, float %218
  %merged.select75 = select i1 %decision.interval12, float 4.000000e+00, float 1.500000e+00
  %219 = select i1 %merged.select73, float %merged.select74, float %merged.select75
  %merged.select76 = select i1 %decision.interval12, i1 %214, i1 %212
  %merged.select77 = select i1 %decision.interval12, float 3.000000e+00, float %219
  %merged.select78 = select i1 %decision.interval12, float %219, float 2.000000e+00
  %220 = select i1 %merged.select76, float %merged.select77, float %merged.select78
  %221 = tail call float @llvm.copysign.f32(float %220, float %mul116.5) #4
  %mul118.5 = fmul float %cond88, %221
  %sub.5 = fsub float %mul118.5, %52
  %mul126.5 = fmul float %div73, %56
  %222 = tail call float @llvm.fabs.f32(float %mul126.5) #4
  %decision.interval13 = fcmp ugt float %222, 2.500000e+00
  %223 = fcmp olt float %222, 1.750000e+00
  %224 = fcmp ole float %222, 1.250000e+00
  %merged.select65 = select i1 %decision.interval13, float 3.500000e+00, float 7.500000e-01
  %225 = fcmp olt float %222, %merged.select65
  %226 = fcmp ole float %222, 2.500000e-01
  %227 = select i1 %226, float 0.000000e+00, float 5.000000e-01
  %228 = fcmp ugt float %222, 5.000000e+00
  %guard.value87 = select i1 %decision.interval13, float undef, float %227
  %229 = select i1 %225, float %guard.value87, float 1.000000e+00
  %merged.select80 = select i1 %decision.interval13, i1 %228, i1 %224
  %merged.select81 = select i1 %decision.interval13, float 6.000000e+00, float %229
  %merged.select82 = select i1 %decision.interval13, float 4.000000e+00, float 1.500000e+00
  %230 = select i1 %merged.select80, float %merged.select81, float %merged.select82
  %merged.select83 = select i1 %decision.interval13, i1 %225, i1 %223
  %merged.select84 = select i1 %decision.interval13, float 3.000000e+00, float %230
  %merged.select85 = select i1 %decision.interval13, float %230, float 2.000000e+00
  %231 = select i1 %merged.select83, float %merged.select84, float %merged.select85
  %232 = tail call float @llvm.copysign.f32(float %231, float %mul126.5) #4
  %mul128.5 = fmul float %cond88, %232
  %sub132.5 = fsub float %mul128.5, %56
  %mul133.5 = fmul float %sub.5, %sub.5
  %mul134.5 = fmul float %sub132.5, %sub132.5
  %add135.5 = fadd float %mul133.5, %mul134.5
  %e.1.5 = fadd float %e.1.4, %add135.5
  %mul116.6 = fmul float %div73, %60
  %233 = tail call float @llvm.fabs.f32(float %mul116.6) #4
  %decision.interval14 = fcmp ugt float %233, 2.500000e+00
  %234 = fcmp olt float %233, 1.750000e+00
  %235 = fcmp ole float %233, 1.250000e+00
  %merged.select72 = select i1 %decision.interval14, float 3.500000e+00, float 7.500000e-01
  %236 = fcmp olt float %233, %merged.select72
  %237 = fcmp ole float %233, 2.500000e-01
  %238 = select i1 %237, float 0.000000e+00, float 5.000000e-01
  %239 = fcmp ugt float %233, 5.000000e+00
  %guard.value94 = select i1 %decision.interval14, float undef, float %238
  %240 = select i1 %236, float %guard.value94, float 1.000000e+00
  %merged.select87 = select i1 %decision.interval14, i1 %239, i1 %235
  %merged.select88 = select i1 %decision.interval14, float 6.000000e+00, float %240
  %merged.select89 = select i1 %decision.interval14, float 4.000000e+00, float 1.500000e+00
  %241 = select i1 %merged.select87, float %merged.select88, float %merged.select89
  %merged.select90 = select i1 %decision.interval14, i1 %236, i1 %234
  %merged.select91 = select i1 %decision.interval14, float 3.000000e+00, float %241
  %merged.select92 = select i1 %decision.interval14, float %241, float 2.000000e+00
  %242 = select i1 %merged.select90, float %merged.select91, float %merged.select92
  %243 = tail call float @llvm.copysign.f32(float %242, float %mul116.6) #4
  %mul118.6 = fmul float %cond88, %243
  %sub.6 = fsub float %mul118.6, %60
  %mul126.6 = fmul float %div73, %64
  %244 = tail call float @llvm.fabs.f32(float %mul126.6) #4
  %decision.interval15 = fcmp ugt float %244, 2.500000e+00
  %245 = fcmp olt float %244, 1.750000e+00
  %246 = fcmp ole float %244, 1.250000e+00
  %merged.select79 = select i1 %decision.interval15, float 3.500000e+00, float 7.500000e-01
  %247 = fcmp olt float %244, %merged.select79
  %248 = fcmp ole float %244, 2.500000e-01
  %249 = select i1 %248, float 0.000000e+00, float 5.000000e-01
  %250 = fcmp ugt float %244, 5.000000e+00
  %guard.value101 = select i1 %decision.interval15, float undef, float %249
  %251 = select i1 %247, float %guard.value101, float 1.000000e+00
  %merged.select94 = select i1 %decision.interval15, i1 %250, i1 %246
  %merged.select95 = select i1 %decision.interval15, float 6.000000e+00, float %251
  %merged.select96 = select i1 %decision.interval15, float 4.000000e+00, float 1.500000e+00
  %252 = select i1 %merged.select94, float %merged.select95, float %merged.select96
  %merged.select97 = select i1 %decision.interval15, i1 %247, i1 %245
  %merged.select98 = select i1 %decision.interval15, float 3.000000e+00, float %252
  %merged.select99 = select i1 %decision.interval15, float %252, float 2.000000e+00
  %253 = select i1 %merged.select97, float %merged.select98, float %merged.select99
  %254 = tail call float @llvm.copysign.f32(float %253, float %mul126.6) #4
  %mul128.6 = fmul float %cond88, %254
  %sub132.6 = fsub float %mul128.6, %64
  %mul133.6 = fmul float %sub.6, %sub.6
  %mul134.6 = fmul float %sub132.6, %sub132.6
  %add135.6 = fadd float %mul133.6, %mul134.6
  %e.1.6 = fadd float %e.1.5, %add135.6
  %mul116.7 = fmul float %div73, %74
  %255 = tail call float @llvm.fabs.f32(float %mul116.7) #4
  %decision.interval16 = fcmp ugt float %255, 2.500000e+00
  %256 = fcmp olt float %255, 1.750000e+00
  %257 = fcmp ole float %255, 1.250000e+00
  %merged.select86 = select i1 %decision.interval16, float 3.500000e+00, float 7.500000e-01
  %258 = fcmp olt float %255, %merged.select86
  %259 = fcmp ole float %255, 2.500000e-01
  %260 = select i1 %259, float 0.000000e+00, float 5.000000e-01
  %261 = fcmp ugt float %255, 5.000000e+00
  %guard.value108 = select i1 %decision.interval16, float undef, float %260
  %262 = select i1 %258, float %guard.value108, float 1.000000e+00
  %merged.select101 = select i1 %decision.interval16, i1 %261, i1 %257
  %merged.select102 = select i1 %decision.interval16, float 6.000000e+00, float %262
  %merged.select103 = select i1 %decision.interval16, float 4.000000e+00, float 1.500000e+00
  %263 = select i1 %merged.select101, float %merged.select102, float %merged.select103
  %merged.select104 = select i1 %decision.interval16, i1 %258, i1 %256
  %merged.select105 = select i1 %decision.interval16, float 3.000000e+00, float %263
  %merged.select106 = select i1 %decision.interval16, float %263, float 2.000000e+00
  %264 = select i1 %merged.select104, float %merged.select105, float %merged.select106
  %265 = tail call float @llvm.copysign.f32(float %264, float %mul116.7) #4
  %mul118.7 = fmul float %cond88, %265
  %sub.7 = fsub float %mul118.7, %74
  %mul126.7 = fmul float %div73, %77
  %266 = tail call float @llvm.fabs.f32(float %mul126.7) #4
  %decision.interval17 = fcmp ugt float %266, 2.500000e+00
  %267 = fcmp olt float %266, 1.750000e+00
  %268 = fcmp ole float %266, 1.250000e+00
  %merged.select93 = select i1 %decision.interval17, float 3.500000e+00, float 7.500000e-01
  %269 = fcmp olt float %266, %merged.select93
  %270 = fcmp ole float %266, 2.500000e-01
  %271 = select i1 %270, float 0.000000e+00, float 5.000000e-01
  %272 = fcmp ugt float %266, 5.000000e+00
  %guard.value115 = select i1 %decision.interval17, float undef, float %271
  %273 = select i1 %269, float %guard.value115, float 1.000000e+00
  %merged.select108 = select i1 %decision.interval17, i1 %272, i1 %268
  %merged.select109 = select i1 %decision.interval17, float 6.000000e+00, float %273
  %merged.select110 = select i1 %decision.interval17, float 4.000000e+00, float 1.500000e+00
  %274 = select i1 %merged.select108, float %merged.select109, float %merged.select110
  %merged.select111 = select i1 %decision.interval17, i1 %269, i1 %267
  %merged.select112 = select i1 %decision.interval17, float 3.000000e+00, float %274
  %merged.select113 = select i1 %decision.interval17, float %274, float 2.000000e+00
  %275 = select i1 %merged.select111, float %merged.select112, float %merged.select113
  %276 = tail call float @llvm.copysign.f32(float %275, float %mul126.7) #4
  %mul128.7 = fmul float %cond88, %276
  %sub132.7 = fsub float %mul128.7, %77
  %mul133.7 = fmul float %sub.7, %sub.7
  %mul134.7 = fmul float %sub132.7, %sub132.7
  br label %for.inc138.7

if.then97.7:                                      ; preds = %cond.end75, %cond.end75.thread
  %os.sroa.0.3 = phi <2 x float> [ %83, %cond.end75.thread ], [ %84, %cond.end75 ]
  %mul102 = fmul float %12, %12
  %mul109 = fmul float %16, %16
  %add110 = fadd float %mul102, %mul109
  %e.1478 = fadd float %add110, 0.000000e+00
  %mul102.1 = fmul float %20, %20
  %mul109.1 = fmul float %24, %24
  %add110.1 = fadd float %mul102.1, %mul109.1
  %e.1.1490 = fadd float %e.1478, %add110.1
  %mul102.2 = fmul float %28, %28
  %mul109.2 = fmul float %32, %32
  %add110.2 = fadd float %mul102.2, %mul109.2
  %e.1.2502 = fadd float %e.1.1490, %add110.2
  %mul102.3 = fmul float %36, %36
  %mul109.3 = fmul float %40, %40
  %add110.3 = fadd float %mul102.3, %mul109.3
  %e.1.3514 = fadd float %e.1.2502, %add110.3
  %mul102.4 = fmul float %44, %44
  %mul109.4 = fmul float %48, %48
  %add110.4 = fadd float %mul102.4, %mul109.4
  %e.1.4526 = fadd float %e.1.3514, %add110.4
  %mul102.5 = fmul float %52, %52
  %mul109.5 = fmul float %56, %56
  %add110.5 = fadd float %mul102.5, %mul109.5
  %e.1.5538 = fadd float %e.1.4526, %add110.5
  %mul102.6 = fmul float %60, %60
  %mul109.6 = fmul float %64, %64
  %add110.6 = fadd float %mul102.6, %mul109.6
  %e.1.6550 = fadd float %e.1.5538, %add110.6
  %mul102.7 = fmul float %74, %74
  %mul109.7 = fmul float %77, %77
  br label %for.inc138.7

for.inc138.7:                                     ; preds = %if.then97.7, %if.else.7
  %os.sroa.0.4 = phi <2 x float> [ %84, %if.else.7 ], [ %os.sroa.0.3, %if.then97.7 ]
  %mul109.7.sink = phi float [ %mul134.7, %if.else.7 ], [ %mul109.7, %if.then97.7 ]
  %mul102.7.sink = phi float [ %mul133.7, %if.else.7 ], [ %mul102.7, %if.then97.7 ]
  %e.1.6551 = phi float [ %e.1.6, %if.else.7 ], [ %e.1.6550, %if.then97.7 ]
  %add110.7 = fadd float %mul109.7.sink, %mul102.7.sink
  %e.1.7 = fadd float %e.1.6551, %add110.7
  %mul60.1 = fmul float %79, 2.500000e-01
  %mul61.1 = fmul float %cond29, %mul60.1
  %cmp.i379.1 = fcmp ult float %mul61.1, 4.480000e+02
  br i1 %cmp.i379.1, label %_Z4dec8i.exit.i.2.1, label %_Z4enc8f.exit.thread396.1

_Z4enc8f.exit.thread396.1:                        ; preds = %for.inc138.7
  store i8 126, i8 addrspace(5)* %arrayidx64340398.1, align 1, !tbaa !12
  br label %cond.true.i.1

_Z4dec8i.exit.i.2.1:                              ; preds = %for.inc138.7
  %cmp2.i.1424 = fcmp ogt float %mul61.1, 1.875000e+00
  %hi.1.i.1425 = select i1 %cmp2.i.1424, i32 126, i32 63
  %lo.1.i.1426 = select i1 %cmp2.i.1424, i32 64, i32 0
  %div.i.1.1 = select i1 %cmp2.i.1424, i32 95, i32 31
  %277 = lshr i32 %div.i.1.1, 3
  %sub.i.i.1.1 = add nsw i32 %277, -7
  %278 = tail call float @llvm.amdgcn.ldexp.f32(float 1.875000e+00, i32 %sub.i.i.1.1) #4
  %cmp2.i.1.1 = fcmp olt float %278, %mul61.1
  %add4.i.1.1 = add nuw nsw i32 %div.i.1.1, 1
  %hi.1.i.1.1 = select i1 %cmp2.i.1.1, i32 %hi.1.i.1425, i32 %div.i.1.1
  %lo.1.i.1.1 = select i1 %cmp2.i.1.1, i32 %add4.i.1.1, i32 %lo.1.i.1426
  %add.i381.2.1 = add nuw nsw i32 %lo.1.i.1.1, %hi.1.i.1.1
  %div.i.2.1 = lshr i32 %add.i381.2.1, 1
  %279 = lshr i32 %add.i381.2.1, 4
  %sub.i.i.2.1 = add nsw i32 %279, -7
  %280 = tail call float @llvm.amdgcn.ldexp.f32(float 1.875000e+00, i32 %sub.i.i.2.1) #4
  %cmp2.i.2.1 = fcmp olt float %280, %mul61.1
  %add4.i.2.1 = add nuw nsw i32 %div.i.2.1, 1
  %hi.1.i.2.1 = select i1 %cmp2.i.2.1, i32 %hi.1.i.1.1, i32 %div.i.2.1
  %lo.1.i.2.1 = select i1 %cmp2.i.2.1, i32 %add4.i.2.1, i32 %lo.1.i.1.1
  %add.i381.3.1 = add nuw nsw i32 %lo.1.i.2.1, %hi.1.i.2.1
  %div.i.3.1 = lshr i32 %add.i381.3.1, 1
  %281 = lshr i32 %add.i381.3.1, 4
  %and.i.i.3.1 = and i32 %div.i.3.1, 7
  %tobool.not.i.i.3.1 = icmp eq i32 %281, 0
  %conv1.i.i.3.1 = sitofp i32 %and.i.i.3.1 to float
  %mul.i.i.3.1 = fmul float %conv1.i.i.3.1, 1.250000e-01
  %add.i.i.3.1 = fadd float %mul.i.i.3.1, 1.000000e+00
  %sub.i.i.3.1 = add nsw i32 %281, -7
  %282 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.3.1, i32 %sub.i.i.3.1) #4
  %mul2.i.i.3.1 = fmul float %conv1.i.i.3.1, 0x3F60000000000000
  %cond.i.i.3.1 = select i1 %tobool.not.i.i.3.1, float %mul2.i.i.3.1, float %282
  %cmp2.i.3.1 = fcmp olt float %cond.i.i.3.1, %mul61.1
  %add4.i.3.1 = add nuw nsw i32 %div.i.3.1, 1
  %hi.1.i.3.1 = select i1 %cmp2.i.3.1, i32 %hi.1.i.2.1, i32 %div.i.3.1
  %lo.1.i.3.1 = select i1 %cmp2.i.3.1, i32 %add4.i.3.1, i32 %lo.1.i.2.1
  %add.i381.4.1 = add nuw nsw i32 %lo.1.i.3.1, %hi.1.i.3.1
  %div.i.4.1 = lshr i32 %add.i381.4.1, 1
  %283 = lshr i32 %add.i381.4.1, 4
  %and.i.i.4.1 = and i32 %div.i.4.1, 7
  %tobool.not.i.i.4.1 = icmp eq i32 %283, 0
  %conv1.i.i.4.1 = sitofp i32 %and.i.i.4.1 to float
  %mul.i.i.4.1 = fmul float %conv1.i.i.4.1, 1.250000e-01
  %add.i.i.4.1 = fadd float %mul.i.i.4.1, 1.000000e+00
  %sub.i.i.4.1 = add nsw i32 %283, -7
  %284 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.4.1, i32 %sub.i.i.4.1) #4
  %mul2.i.i.4.1 = fmul float %conv1.i.i.4.1, 0x3F60000000000000
  %cond.i.i.4.1 = select i1 %tobool.not.i.i.4.1, float %mul2.i.i.4.1, float %284
  %cmp2.i.4.1 = fcmp olt float %cond.i.i.4.1, %mul61.1
  %add4.i.4.1 = add nuw nsw i32 %div.i.4.1, 1
  %hi.1.i.4.1 = select i1 %cmp2.i.4.1, i32 %hi.1.i.3.1, i32 %div.i.4.1
  %lo.1.i.4.1 = select i1 %cmp2.i.4.1, i32 %add4.i.4.1, i32 %lo.1.i.3.1
  %add.i381.5.1 = add nuw nsw i32 %lo.1.i.4.1, %hi.1.i.4.1
  %div.i.5.1 = sdiv i32 %add.i381.5.1, 2
  %shr.i.i.5.1 = ashr i32 %div.i.5.1, 3
  %and.i.i.5.1 = and i32 %div.i.5.1, 7
  %tobool.not.i.i.5.1 = icmp eq i32 %shr.i.i.5.1, 0
  %conv1.i.i.5.1 = sitofp i32 %and.i.i.5.1 to float
  %mul.i.i.5.1 = fmul float %conv1.i.i.5.1, 1.250000e-01
  %add.i.i.5.1 = fadd float %mul.i.i.5.1, 1.000000e+00
  %sub.i.i.5.1 = add nsw i32 %shr.i.i.5.1, -7
  %285 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.5.1, i32 %sub.i.i.5.1) #4
  %mul2.i.i.5.1 = fmul float %conv1.i.i.5.1, 0x3F60000000000000
  %cond.i.i.5.1 = select i1 %tobool.not.i.i.5.1, float %mul2.i.i.5.1, float %285
  %cmp2.i.5.1 = fcmp olt float %cond.i.i.5.1, %mul61.1
  %add4.i.5.1 = add nuw nsw i32 %div.i.5.1, 1
  %hi.1.i.5.1 = select i1 %cmp2.i.5.1, i32 %hi.1.i.4.1, i32 %div.i.5.1
  %lo.1.i.5.1 = select i1 %cmp2.i.5.1, i32 %add4.i.5.1, i32 %lo.1.i.4.1
  %add.i381.6.1 = add nuw nsw i32 %lo.1.i.5.1, %hi.1.i.5.1
  %div.i.6.1 = sdiv i32 %add.i381.6.1, 2
  %shr.i.i.6.1 = ashr i32 %div.i.6.1, 3
  %and.i.i.6.1 = and i32 %div.i.6.1, 7
  %tobool.not.i.i.6.1 = icmp eq i32 %shr.i.i.6.1, 0
  %conv1.i.i.6.1 = sitofp i32 %and.i.i.6.1 to float
  %mul.i.i.6.1 = fmul float %conv1.i.i.6.1, 1.250000e-01
  %add.i.i.6.1 = fadd float %mul.i.i.6.1, 1.000000e+00
  %sub.i.i.6.1 = add nsw i32 %shr.i.i.6.1, -7
  %286 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.i.6.1, i32 %sub.i.i.6.1) #4
  %mul2.i.i.6.1 = fmul float %conv1.i.i.6.1, 0x3F60000000000000
  %cond.i.i.6.1 = select i1 %tobool.not.i.i.6.1, float %mul2.i.i.6.1, float %286
  %cmp2.i.6.1 = fcmp olt float %cond.i.i.6.1, %mul61.1
  %add4.i.6.1 = add nuw nsw i32 %div.i.6.1, 1
  %lo.1.i.6.1 = select i1 %cmp2.i.6.1, i32 %add4.i.6.1, i32 %lo.1.i.5.1
  %cmp6.i.1 = icmp eq i32 %lo.1.i.6.1, 0
  br i1 %cmp6.i.1, label %_Z4enc8f.exit.thread.1, label %if.end9.i.1

if.end9.i.1:                                      ; preds = %_Z4dec8i.exit.i.2.1
  %sub.i382.1 = add nsw i32 %lo.1.i.6.1, -1
  %shr.i62.i.1 = ashr i32 %sub.i382.1, 3
  %and.i63.i.1 = and i32 %sub.i382.1, 7
  %tobool.not.i64.i.1 = icmp eq i32 %shr.i62.i.1, 0
  %conv1.i70.i.1 = sitofp i32 %and.i63.i.1 to float
  %mul.i66.i.1 = fmul float %conv1.i70.i.1, 1.250000e-01
  %add.i67.i.1 = fadd float %mul.i66.i.1, 1.000000e+00
  %sub.i68.i.1 = add nsw i32 %shr.i62.i.1, -7
  %287 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i67.i.1, i32 %sub.i68.i.1) #4
  %mul2.i71.i.1 = fmul float %conv1.i70.i.1, 0x3F60000000000000
  %cond.i73.i.1 = select i1 %tobool.not.i64.i.1, float %mul2.i71.i.1, float %287
  %sub11.i.1 = fsub float %mul61.1, %cond.i73.i.1
  %shr.i49.i.1656 = lshr i32 %lo.1.i.6.1, 3
  %and.i50.i.1 = and i32 %lo.1.i.6.1, 7
  %tobool.not.i51.i.1 = icmp eq i32 %shr.i49.i.1656, 0
  %conv1.i57.i.1 = sitofp i32 %and.i50.i.1 to float
  %mul.i53.i.1 = fmul float %conv1.i57.i.1, 1.250000e-01
  %add.i54.i.1 = fadd float %mul.i53.i.1, 1.000000e+00
  %sub.i55.i.1 = add nsw i32 %shr.i49.i.1656, -7
  %288 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i54.i.1, i32 %sub.i55.i.1) #4
  %mul2.i58.i.1 = fmul float %conv1.i57.i.1, 0x3F60000000000000
  %cond.i60.i.1 = select i1 %tobool.not.i51.i.1, float %mul2.i58.i.1, float %288
  %sub13.i.1 = fsub float %cond.i60.i.1, %mul61.1
  %cmp14.i.1 = fcmp olt float %sub11.i.1, %sub13.i.1
  br i1 %cmp14.i.1, label %_Z4enc8f.exit.1, label %cond.false.i384.1

cond.false.i384.1:                                ; preds = %if.end9.i.1
  %cmp16.i383.1 = fcmp olt float %sub13.i.1, %sub11.i.1
  %and.i385.1 = and i32 %lo.1.i.6.1, 1
  %tobool.not.i386.1 = icmp eq i32 %and.i385.1, 0
  %cond.i387.1 = select i1 %tobool.not.i386.1, i32 %lo.1.i.6.1, i32 %sub.i382.1
  br i1 %cmp16.i383.1, label %_Z4enc8f.exit.1, label %cond.false18.i.1

cond.false18.i.1:                                 ; preds = %cond.false.i384.1
  %.pre = and i32 %cond.i387.1, 7
  br label %_Z4enc8f.exit.1

_Z4enc8f.exit.1:                                  ; preds = %cond.false18.i.1, %cond.false.i384.1, %if.end9.i.1
  %and.i375.1.pre-phi = phi i32 [ %and.i63.i.1, %if.end9.i.1 ], [ %and.i50.i.1, %cond.false.i384.1 ], [ %.pre, %cond.false18.i.1 ]
  %cond25.i.1 = phi i32 [ %sub.i382.1, %if.end9.i.1 ], [ %lo.1.i.6.1, %cond.false.i384.1 ], [ %cond.i387.1, %cond.false18.i.1 ]
  %conv.i388.1 = trunc i32 %cond25.i.1 to i8
  store i8 %conv.i388.1, i8 addrspace(5)* %arrayidx64340398.1, align 1, !tbaa !12
  %conv67.1 = lshr i32 %cond25.i.1, 3
  %tobool.not.i.1 = icmp eq i32 %conv67.1, 0
  br i1 %tobool.not.i.1, label %cond.false.i377.1, label %cond.true.i.1

cond.true.i.1:                                    ; preds = %_Z4enc8f.exit.1, %_Z4enc8f.exit.thread396.1
  %and.i375404.1 = phi i32 [ 6, %_Z4enc8f.exit.thread396.1 ], [ %and.i375.1.pre-phi, %_Z4enc8f.exit.1 ]
  %shr.i374403.1 = phi i32 [ 15, %_Z4enc8f.exit.thread396.1 ], [ %conv67.1, %_Z4enc8f.exit.1 ]
  %conv.i376.1 = sitofp i32 %and.i375404.1 to float
  %mul.i.1 = fmul float %conv.i376.1, 1.250000e-01
  %add.i.1 = fadd float %mul.i.1, 1.000000e+00
  %sub.i.1 = add nsw i32 %shr.i374403.1, -7
  %289 = tail call float @llvm.amdgcn.ldexp.f32(float %add.i.1, i32 %sub.i.1) #4
  br label %_Z4dec8i.exit.1

_Z4enc8f.exit.thread.1:                           ; preds = %_Z4dec8i.exit.i.2.1
  store i8 0, i8 addrspace(5)* %arrayidx64340398.1, align 1, !tbaa !12
  br label %cond.false.i377.1

cond.false.i377.1:                                ; preds = %_Z4enc8f.exit.thread.1, %_Z4enc8f.exit.1
  %and.i375395.1 = phi i32 [ %and.i375.1.pre-phi, %_Z4enc8f.exit.1 ], [ 0, %_Z4enc8f.exit.thread.1 ]
  %conv1.i.1 = sitofp i32 %and.i375395.1 to float
  %mul2.i.1 = fmul float %conv1.i.1, 0x3F60000000000000
  br label %_Z4dec8i.exit.1

_Z4dec8i.exit.1:                                  ; preds = %cond.false.i377.1, %cond.true.i.1
  %cond.i378.1 = phi float [ %289, %cond.true.i.1 ], [ %mul2.i.1, %cond.false.i377.1 ]
  %cmp69.1 = fcmp une float %cond.i378.1, 0.000000e+00
  br i1 %cmp69.1, label %cond.end75.1, label %cond.end75.1.thread

cond.end75.1.thread:                              ; preds = %_Z4dec8i.exit.1
  %290 = insertelement <2 x float> %os.sroa.0.4, float 0.000000e+00, i32 1
  br label %if.then97.7.1

cond.end75.1:                                     ; preds = %_Z4dec8i.exit.1
  %mul72.1 = fmul float %div71, %cond.i378.1
  %div73.1 = fdiv float 1.000000e+00, %mul72.1
  %291 = insertelement <2 x float> %os.sroa.0.4, float %div73.1, i32 1
  %cmp81.1 = fcmp une float %div73.1, 0.000000e+00
  %div85.1 = fdiv float 1.000000e+00, %div73.1
  %cond88.1 = select i1 %cmp81.1, float %div85.1, float 0.000000e+00
  %cmp96.1 = fcmp oeq float %div73.1, 0.000000e+00
  br i1 %cmp96.1, label %if.then97.7.1, label %if.else.7.1

if.else.7.1:                                      ; preds = %cond.end75.1
  %mul116.1429 = fmul float %div73.1, %12
  %292 = tail call float @llvm.fabs.f32(float %mul116.1429) #4
  %decision.interval18 = fcmp ugt float %292, 2.500000e+00
  %293 = fcmp olt float %292, 1.750000e+00
  %294 = fcmp ole float %292, 1.250000e+00
  %merged.select100 = select i1 %decision.interval18, float 3.500000e+00, float 7.500000e-01
  %295 = fcmp olt float %292, %merged.select100
  %296 = fcmp ole float %292, 2.500000e-01
  %297 = select i1 %296, float 0.000000e+00, float 5.000000e-01
  %298 = fcmp ugt float %292, 5.000000e+00
  %guard.value122 = select i1 %decision.interval18, float undef, float %297
  %299 = select i1 %295, float %guard.value122, float 1.000000e+00
  %merged.select115 = select i1 %decision.interval18, i1 %298, i1 %294
  %merged.select116 = select i1 %decision.interval18, float 6.000000e+00, float %299
  %merged.select117 = select i1 %decision.interval18, float 4.000000e+00, float 1.500000e+00
  %300 = select i1 %merged.select115, float %merged.select116, float %merged.select117
  %merged.select118 = select i1 %decision.interval18, i1 %295, i1 %293
  %merged.select119 = select i1 %decision.interval18, float 3.000000e+00, float %300
  %merged.select120 = select i1 %decision.interval18, float %300, float 2.000000e+00
  %301 = select i1 %merged.select118, float %merged.select119, float %merged.select120
  %302 = tail call float @llvm.copysign.f32(float %301, float %mul116.1429) #4
  %mul118.1430 = fmul float %cond88.1, %302
  %sub.1431 = fsub float %mul118.1430, %12
  %mul126.1433 = fmul float %div73.1, %16
  %303 = tail call float @llvm.fabs.f32(float %mul126.1433) #4
  %decision.interval19 = fcmp ugt float %303, 2.500000e+00
  %304 = fcmp olt float %303, 1.750000e+00
  %305 = fcmp ole float %303, 1.250000e+00
  %merged.select107 = select i1 %decision.interval19, float 3.500000e+00, float 7.500000e-01
  %306 = fcmp olt float %303, %merged.select107
  %307 = fcmp ole float %303, 2.500000e-01
  %308 = select i1 %307, float 0.000000e+00, float 5.000000e-01
  %309 = fcmp ugt float %303, 5.000000e+00
  %guard.value129 = select i1 %decision.interval19, float undef, float %308
  %310 = select i1 %306, float %guard.value129, float 1.000000e+00
  %merged.select122 = select i1 %decision.interval19, i1 %309, i1 %305
  %merged.select123 = select i1 %decision.interval19, float 6.000000e+00, float %310
  %merged.select124 = select i1 %decision.interval19, float 4.000000e+00, float 1.500000e+00
  %311 = select i1 %merged.select122, float %merged.select123, float %merged.select124
  %merged.select125 = select i1 %decision.interval19, i1 %306, i1 %304
  %merged.select126 = select i1 %decision.interval19, float 3.000000e+00, float %311
  %merged.select127 = select i1 %decision.interval19, float %311, float 2.000000e+00
  %312 = select i1 %merged.select125, float %merged.select126, float %merged.select127
  %313 = tail call float @llvm.copysign.f32(float %312, float %mul126.1433) #4
  %mul128.1434 = fmul float %cond88.1, %313
  %sub132.1435 = fsub float %mul128.1434, %16
  %mul133.1436 = fmul float %sub.1431, %sub.1431
  %mul134.1437 = fmul float %sub132.1435, %sub132.1435
  %add135.1438 = fadd float %mul133.1436, %mul134.1437
  %e.1.1447 = fadd float %add135.1438, 0.000000e+00
  %mul116.1.1 = fmul float %div73.1, %20
  %314 = tail call float @llvm.fabs.f32(float %mul116.1.1) #4
  %decision.interval20 = fcmp ugt float %314, 2.500000e+00
  %315 = fcmp olt float %314, 1.750000e+00
  %316 = fcmp ole float %314, 1.250000e+00
  %merged.select114 = select i1 %decision.interval20, float 3.500000e+00, float 7.500000e-01
  %317 = fcmp olt float %314, %merged.select114
  %318 = fcmp ole float %314, 2.500000e-01
  %319 = select i1 %318, float 0.000000e+00, float 5.000000e-01
  %320 = fcmp ugt float %314, 5.000000e+00
  %guard.value136 = select i1 %decision.interval20, float undef, float %319
  %321 = select i1 %317, float %guard.value136, float 1.000000e+00
  %merged.select129 = select i1 %decision.interval20, i1 %320, i1 %316
  %merged.select130 = select i1 %decision.interval20, float 6.000000e+00, float %321
  %merged.select131 = select i1 %decision.interval20, float 4.000000e+00, float 1.500000e+00
  %322 = select i1 %merged.select129, float %merged.select130, float %merged.select131
  %merged.select132 = select i1 %decision.interval20, i1 %317, i1 %315
  %merged.select133 = select i1 %decision.interval20, float 3.000000e+00, float %322
  %merged.select134 = select i1 %decision.interval20, float %322, float 2.000000e+00
  %323 = select i1 %merged.select132, float %merged.select133, float %merged.select134
  %324 = tail call float @llvm.copysign.f32(float %323, float %mul116.1.1) #4
  %mul118.1.1 = fmul float %cond88.1, %324
  %sub.1.1 = fsub float %mul118.1.1, %20
  %mul126.1.1 = fmul float %div73.1, %24
  %325 = tail call float @llvm.fabs.f32(float %mul126.1.1) #4
  %decision.interval21 = fcmp ugt float %325, 2.500000e+00
  %326 = fcmp olt float %325, 1.750000e+00
  %327 = fcmp ole float %325, 1.250000e+00
  %merged.select121 = select i1 %decision.interval21, float 3.500000e+00, float 7.500000e-01
  %328 = fcmp olt float %325, %merged.select121
  %329 = fcmp ole float %325, 2.500000e-01
  %330 = select i1 %329, float 0.000000e+00, float 5.000000e-01
  %331 = fcmp ugt float %325, 5.000000e+00
  %guard.value143 = select i1 %decision.interval21, float undef, float %330
  %332 = select i1 %328, float %guard.value143, float 1.000000e+00
  %merged.select136 = select i1 %decision.interval21, i1 %331, i1 %327
  %merged.select137 = select i1 %decision.interval21, float 6.000000e+00, float %332
  %merged.select138 = select i1 %decision.interval21, float 4.000000e+00, float 1.500000e+00
  %333 = select i1 %merged.select136, float %merged.select137, float %merged.select138
  %merged.select139 = select i1 %decision.interval21, i1 %328, i1 %326
  %merged.select140 = select i1 %decision.interval21, float 3.000000e+00, float %333
  %merged.select141 = select i1 %decision.interval21, float %333, float 2.000000e+00
  %334 = select i1 %merged.select139, float %merged.select140, float %merged.select141
  %335 = tail call float @llvm.copysign.f32(float %334, float %mul126.1.1) #4
  %mul128.1.1 = fmul float %cond88.1, %335
  %sub132.1.1 = fsub float %mul128.1.1, %24
  %mul133.1.1 = fmul float %sub.1.1, %sub.1.1
  %mul134.1.1 = fmul float %sub132.1.1, %sub132.1.1
  %add135.1.1 = fadd float %mul133.1.1, %mul134.1.1
  %e.1.1.1 = fadd float %e.1.1447, %add135.1.1
  %mul116.2.1 = fmul float %div73.1, %28
  %336 = tail call float @llvm.fabs.f32(float %mul116.2.1) #4
  %decision.interval22 = fcmp ugt float %336, 2.500000e+00
  %337 = fcmp olt float %336, 1.750000e+00
  %338 = fcmp ole float %336, 1.250000e+00
  %merged.select128 = select i1 %decision.interval22, float 3.500000e+00, float 7.500000e-01
  %339 = fcmp olt float %336, %merged.select128
  %340 = fcmp ole float %336, 2.500000e-01
  %341 = select i1 %340, float 0.000000e+00, float 5.000000e-01
  %342 = fcmp ugt float %336, 5.000000e+00
  %guard.value150 = select i1 %decision.interval22, float undef, float %341
  %343 = select i1 %339, float %guard.value150, float 1.000000e+00
  %merged.select143 = select i1 %decision.interval22, i1 %342, i1 %338
  %merged.select144 = select i1 %decision.interval22, float 6.000000e+00, float %343
  %merged.select145 = select i1 %decision.interval22, float 4.000000e+00, float 1.500000e+00
  %344 = select i1 %merged.select143, float %merged.select144, float %merged.select145
  %merged.select146 = select i1 %decision.interval22, i1 %339, i1 %337
  %merged.select147 = select i1 %decision.interval22, float 3.000000e+00, float %344
  %merged.select148 = select i1 %decision.interval22, float %344, float 2.000000e+00
  %345 = select i1 %merged.select146, float %merged.select147, float %merged.select148
  %346 = tail call float @llvm.copysign.f32(float %345, float %mul116.2.1) #4
  %mul118.2.1 = fmul float %cond88.1, %346
  %sub.2.1 = fsub float %mul118.2.1, %28
  %mul126.2.1 = fmul float %div73.1, %32
  %347 = tail call float @llvm.fabs.f32(float %mul126.2.1) #4
  %decision.interval23 = fcmp ugt float %347, 2.500000e+00
  %348 = fcmp olt float %347, 1.750000e+00
  %349 = fcmp ole float %347, 1.250000e+00
  %merged.select135 = select i1 %decision.interval23, float 3.500000e+00, float 7.500000e-01
  %350 = fcmp olt float %347, %merged.select135
  %351 = fcmp ole float %347, 2.500000e-01
  %352 = select i1 %351, float 0.000000e+00, float 5.000000e-01
  %353 = fcmp ugt float %347, 5.000000e+00
  %guard.value157 = select i1 %decision.interval23, float undef, float %352
  %354 = select i1 %350, float %guard.value157, float 1.000000e+00
  %merged.select150 = select i1 %decision.interval23, i1 %353, i1 %349
  %merged.select151 = select i1 %decision.interval23, float 6.000000e+00, float %354
  %merged.select152 = select i1 %decision.interval23, float 4.000000e+00, float 1.500000e+00
  %355 = select i1 %merged.select150, float %merged.select151, float %merged.select152
  %merged.select153 = select i1 %decision.interval23, i1 %350, i1 %348
  %merged.select154 = select i1 %decision.interval23, float 3.000000e+00, float %355
  %merged.select155 = select i1 %decision.interval23, float %355, float 2.000000e+00
  %356 = select i1 %merged.select153, float %merged.select154, float %merged.select155
  %357 = tail call float @llvm.copysign.f32(float %356, float %mul126.2.1) #4
  %mul128.2.1 = fmul float %cond88.1, %357
  %sub132.2.1 = fsub float %mul128.2.1, %32
  %mul133.2.1 = fmul float %sub.2.1, %sub.2.1
  %mul134.2.1 = fmul float %sub132.2.1, %sub132.2.1
  %add135.2.1 = fadd float %mul133.2.1, %mul134.2.1
  %e.1.2.1 = fadd float %e.1.1.1, %add135.2.1
  %mul116.3.1 = fmul float %div73.1, %36
  %358 = tail call float @llvm.fabs.f32(float %mul116.3.1) #4
  %decision.interval24 = fcmp ugt float %358, 2.500000e+00
  %359 = fcmp olt float %358, 1.750000e+00
  %360 = fcmp ole float %358, 1.250000e+00
  %merged.select142 = select i1 %decision.interval24, float 3.500000e+00, float 7.500000e-01
  %361 = fcmp olt float %358, %merged.select142
  %362 = fcmp ole float %358, 2.500000e-01
  %363 = select i1 %362, float 0.000000e+00, float 5.000000e-01
  %364 = fcmp ugt float %358, 5.000000e+00
  %guard.value164 = select i1 %decision.interval24, float undef, float %363
  %365 = select i1 %361, float %guard.value164, float 1.000000e+00
  %merged.select157 = select i1 %decision.interval24, i1 %364, i1 %360
  %merged.select158 = select i1 %decision.interval24, float 6.000000e+00, float %365
  %merged.select159 = select i1 %decision.interval24, float 4.000000e+00, float 1.500000e+00
  %366 = select i1 %merged.select157, float %merged.select158, float %merged.select159
  %merged.select160 = select i1 %decision.interval24, i1 %361, i1 %359
  %merged.select161 = select i1 %decision.interval24, float 3.000000e+00, float %366
  %merged.select162 = select i1 %decision.interval24, float %366, float 2.000000e+00
  %367 = select i1 %merged.select160, float %merged.select161, float %merged.select162
  %368 = tail call float @llvm.copysign.f32(float %367, float %mul116.3.1) #4
  %mul118.3.1 = fmul float %cond88.1, %368
  %sub.3.1 = fsub float %mul118.3.1, %36
  %mul126.3.1 = fmul float %div73.1, %40
  %369 = tail call float @llvm.fabs.f32(float %mul126.3.1) #4
  %decision.interval25 = fcmp ugt float %369, 2.500000e+00
  %370 = fcmp olt float %369, 1.750000e+00
  %371 = fcmp ole float %369, 1.250000e+00
  %merged.select149 = select i1 %decision.interval25, float 3.500000e+00, float 7.500000e-01
  %372 = fcmp olt float %369, %merged.select149
  %373 = fcmp ole float %369, 2.500000e-01
  %374 = select i1 %373, float 0.000000e+00, float 5.000000e-01
  %375 = fcmp ugt float %369, 5.000000e+00
  %guard.value171 = select i1 %decision.interval25, float undef, float %374
  %376 = select i1 %372, float %guard.value171, float 1.000000e+00
  %merged.select164 = select i1 %decision.interval25, i1 %375, i1 %371
  %merged.select165 = select i1 %decision.interval25, float 6.000000e+00, float %376
  %merged.select166 = select i1 %decision.interval25, float 4.000000e+00, float 1.500000e+00
  %377 = select i1 %merged.select164, float %merged.select165, float %merged.select166
  %merged.select167 = select i1 %decision.interval25, i1 %372, i1 %370
  %merged.select168 = select i1 %decision.interval25, float 3.000000e+00, float %377
  %merged.select169 = select i1 %decision.interval25, float %377, float 2.000000e+00
  %378 = select i1 %merged.select167, float %merged.select168, float %merged.select169
  %379 = tail call float @llvm.copysign.f32(float %378, float %mul126.3.1) #4
  %mul128.3.1 = fmul float %cond88.1, %379
  %sub132.3.1 = fsub float %mul128.3.1, %40
  %mul133.3.1 = fmul float %sub.3.1, %sub.3.1
  %mul134.3.1 = fmul float %sub132.3.1, %sub132.3.1
  %add135.3.1 = fadd float %mul133.3.1, %mul134.3.1
  %e.1.3.1 = fadd float %e.1.2.1, %add135.3.1
  %mul116.4.1 = fmul float %div73.1, %44
  %380 = tail call float @llvm.fabs.f32(float %mul116.4.1) #4
  %decision.interval26 = fcmp ugt float %380, 2.500000e+00
  %381 = fcmp olt float %380, 1.750000e+00
  %382 = fcmp ole float %380, 1.250000e+00
  %merged.select156 = select i1 %decision.interval26, float 3.500000e+00, float 7.500000e-01
  %383 = fcmp olt float %380, %merged.select156
  %384 = fcmp ole float %380, 2.500000e-01
  %385 = select i1 %384, float 0.000000e+00, float 5.000000e-01
  %386 = fcmp ugt float %380, 5.000000e+00
  %guard.value178 = select i1 %decision.interval26, float undef, float %385
  %387 = select i1 %383, float %guard.value178, float 1.000000e+00
  %merged.select171 = select i1 %decision.interval26, i1 %386, i1 %382
  %merged.select172 = select i1 %decision.interval26, float 6.000000e+00, float %387
  %merged.select173 = select i1 %decision.interval26, float 4.000000e+00, float 1.500000e+00
  %388 = select i1 %merged.select171, float %merged.select172, float %merged.select173
  %merged.select174 = select i1 %decision.interval26, i1 %383, i1 %381
  %merged.select175 = select i1 %decision.interval26, float 3.000000e+00, float %388
  %merged.select176 = select i1 %decision.interval26, float %388, float 2.000000e+00
  %389 = select i1 %merged.select174, float %merged.select175, float %merged.select176
  %390 = tail call float @llvm.copysign.f32(float %389, float %mul116.4.1) #4
  %mul118.4.1 = fmul float %cond88.1, %390
  %sub.4.1 = fsub float %mul118.4.1, %44
  %mul126.4.1 = fmul float %div73.1, %48
  %391 = tail call float @llvm.fabs.f32(float %mul126.4.1) #4
  %decision.interval27 = fcmp ugt float %391, 2.500000e+00
  %392 = fcmp olt float %391, 1.750000e+00
  %393 = fcmp ole float %391, 1.250000e+00
  %merged.select163 = select i1 %decision.interval27, float 3.500000e+00, float 7.500000e-01
  %394 = fcmp olt float %391, %merged.select163
  %395 = fcmp ole float %391, 2.500000e-01
  %396 = select i1 %395, float 0.000000e+00, float 5.000000e-01
  %397 = fcmp ugt float %391, 5.000000e+00
  %guard.value185 = select i1 %decision.interval27, float undef, float %396
  %398 = select i1 %394, float %guard.value185, float 1.000000e+00
  %merged.select178 = select i1 %decision.interval27, i1 %397, i1 %393
  %merged.select179 = select i1 %decision.interval27, float 6.000000e+00, float %398
  %merged.select180 = select i1 %decision.interval27, float 4.000000e+00, float 1.500000e+00
  %399 = select i1 %merged.select178, float %merged.select179, float %merged.select180
  %merged.select181 = select i1 %decision.interval27, i1 %394, i1 %392
  %merged.select182 = select i1 %decision.interval27, float 3.000000e+00, float %399
  %merged.select183 = select i1 %decision.interval27, float %399, float 2.000000e+00
  %400 = select i1 %merged.select181, float %merged.select182, float %merged.select183
  %401 = tail call float @llvm.copysign.f32(float %400, float %mul126.4.1) #4
  %mul128.4.1 = fmul float %cond88.1, %401
  %sub132.4.1 = fsub float %mul128.4.1, %48
  %mul133.4.1 = fmul float %sub.4.1, %sub.4.1
  %mul134.4.1 = fmul float %sub132.4.1, %sub132.4.1
  %add135.4.1 = fadd float %mul133.4.1, %mul134.4.1
  %e.1.4.1 = fadd float %e.1.3.1, %add135.4.1
  %mul116.5.1 = fmul float %div73.1, %52
  %402 = tail call float @llvm.fabs.f32(float %mul116.5.1) #4
  %decision.interval28 = fcmp ugt float %402, 2.500000e+00
  %403 = fcmp olt float %402, 1.750000e+00
  %404 = fcmp ole float %402, 1.250000e+00
  %merged.select170 = select i1 %decision.interval28, float 3.500000e+00, float 7.500000e-01
  %405 = fcmp olt float %402, %merged.select170
  %406 = fcmp ole float %402, 2.500000e-01
  %407 = select i1 %406, float 0.000000e+00, float 5.000000e-01
  %408 = fcmp ugt float %402, 5.000000e+00
  %guard.value192 = select i1 %decision.interval28, float undef, float %407
  %409 = select i1 %405, float %guard.value192, float 1.000000e+00
  %merged.select185 = select i1 %decision.interval28, i1 %408, i1 %404
  %merged.select186 = select i1 %decision.interval28, float 6.000000e+00, float %409
  %merged.select187 = select i1 %decision.interval28, float 4.000000e+00, float 1.500000e+00
  %410 = select i1 %merged.select185, float %merged.select186, float %merged.select187
  %merged.select188 = select i1 %decision.interval28, i1 %405, i1 %403
  %merged.select189 = select i1 %decision.interval28, float 3.000000e+00, float %410
  %merged.select190 = select i1 %decision.interval28, float %410, float 2.000000e+00
  %411 = select i1 %merged.select188, float %merged.select189, float %merged.select190
  %412 = tail call float @llvm.copysign.f32(float %411, float %mul116.5.1) #4
  %mul118.5.1 = fmul float %cond88.1, %412
  %sub.5.1 = fsub float %mul118.5.1, %52
  %mul126.5.1 = fmul float %div73.1, %56
  %413 = tail call float @llvm.fabs.f32(float %mul126.5.1) #4
  %decision.interval29 = fcmp ugt float %413, 2.500000e+00
  %414 = fcmp olt float %413, 1.750000e+00
  %415 = fcmp ole float %413, 1.250000e+00
  %merged.select177 = select i1 %decision.interval29, float 3.500000e+00, float 7.500000e-01
  %416 = fcmp olt float %413, %merged.select177
  %417 = fcmp ole float %413, 2.500000e-01
  %418 = select i1 %417, float 0.000000e+00, float 5.000000e-01
  %419 = fcmp ugt float %413, 5.000000e+00
  %guard.value199 = select i1 %decision.interval29, float undef, float %418
  %420 = select i1 %416, float %guard.value199, float 1.000000e+00
  %merged.select192 = select i1 %decision.interval29, i1 %419, i1 %415
  %merged.select193 = select i1 %decision.interval29, float 6.000000e+00, float %420
  %merged.select194 = select i1 %decision.interval29, float 4.000000e+00, float 1.500000e+00
  %421 = select i1 %merged.select192, float %merged.select193, float %merged.select194
  %merged.select195 = select i1 %decision.interval29, i1 %416, i1 %414
  %merged.select196 = select i1 %decision.interval29, float 3.000000e+00, float %421
  %merged.select197 = select i1 %decision.interval29, float %421, float 2.000000e+00
  %422 = select i1 %merged.select195, float %merged.select196, float %merged.select197
  %423 = tail call float @llvm.copysign.f32(float %422, float %mul126.5.1) #4
  %mul128.5.1 = fmul float %cond88.1, %423
  %sub132.5.1 = fsub float %mul128.5.1, %56
  %mul133.5.1 = fmul float %sub.5.1, %sub.5.1
  %mul134.5.1 = fmul float %sub132.5.1, %sub132.5.1
  %add135.5.1 = fadd float %mul133.5.1, %mul134.5.1
  %e.1.5.1 = fadd float %e.1.4.1, %add135.5.1
  %mul116.6.1 = fmul float %div73.1, %60
  %424 = tail call float @llvm.fabs.f32(float %mul116.6.1) #4
  %decision.interval30 = fcmp ugt float %424, 2.500000e+00
  %425 = fcmp olt float %424, 1.750000e+00
  %426 = fcmp ole float %424, 1.250000e+00
  %merged.select184 = select i1 %decision.interval30, float 3.500000e+00, float 7.500000e-01
  %427 = fcmp olt float %424, %merged.select184
  %428 = fcmp ole float %424, 2.500000e-01
  %429 = select i1 %428, float 0.000000e+00, float 5.000000e-01
  %430 = fcmp ugt float %424, 5.000000e+00
  %guard.value206 = select i1 %decision.interval30, float undef, float %429
  %431 = select i1 %427, float %guard.value206, float 1.000000e+00
  %merged.select199 = select i1 %decision.interval30, i1 %430, i1 %426
  %merged.select200 = select i1 %decision.interval30, float 6.000000e+00, float %431
  %merged.select201 = select i1 %decision.interval30, float 4.000000e+00, float 1.500000e+00
  %432 = select i1 %merged.select199, float %merged.select200, float %merged.select201
  %merged.select202 = select i1 %decision.interval30, i1 %427, i1 %425
  %merged.select203 = select i1 %decision.interval30, float 3.000000e+00, float %432
  %merged.select204 = select i1 %decision.interval30, float %432, float 2.000000e+00
  %433 = select i1 %merged.select202, float %merged.select203, float %merged.select204
  %434 = tail call float @llvm.copysign.f32(float %433, float %mul116.6.1) #4
  %mul118.6.1 = fmul float %cond88.1, %434
  %sub.6.1 = fsub float %mul118.6.1, %60
  %mul126.6.1 = fmul float %div73.1, %64
  %435 = tail call float @llvm.fabs.f32(float %mul126.6.1) #4
  %decision.interval31 = fcmp ugt float %435, 2.500000e+00
  %436 = fcmp olt float %435, 1.750000e+00
  %437 = fcmp ole float %435, 1.250000e+00
  %merged.select191 = select i1 %decision.interval31, float 3.500000e+00, float 7.500000e-01
  %438 = fcmp olt float %435, %merged.select191
  %439 = fcmp ole float %435, 2.500000e-01
  %440 = select i1 %439, float 0.000000e+00, float 5.000000e-01
  %441 = fcmp ugt float %435, 5.000000e+00
  %guard.value213 = select i1 %decision.interval31, float undef, float %440
  %442 = select i1 %438, float %guard.value213, float 1.000000e+00
  %merged.select206 = select i1 %decision.interval31, i1 %441, i1 %437
  %merged.select207 = select i1 %decision.interval31, float 6.000000e+00, float %442
  %merged.select208 = select i1 %decision.interval31, float 4.000000e+00, float 1.500000e+00
  %443 = select i1 %merged.select206, float %merged.select207, float %merged.select208
  %merged.select209 = select i1 %decision.interval31, i1 %438, i1 %436
  %merged.select210 = select i1 %decision.interval31, float 3.000000e+00, float %443
  %merged.select211 = select i1 %decision.interval31, float %443, float 2.000000e+00
  %444 = select i1 %merged.select209, float %merged.select210, float %merged.select211
  %445 = tail call float @llvm.copysign.f32(float %444, float %mul126.6.1) #4
  %mul128.6.1 = fmul float %cond88.1, %445
  %sub132.6.1 = fsub float %mul128.6.1, %64
  %mul133.6.1 = fmul float %sub.6.1, %sub.6.1
  %mul134.6.1 = fmul float %sub132.6.1, %sub132.6.1
  %add135.6.1 = fadd float %mul133.6.1, %mul134.6.1
  %e.1.6.1 = fadd float %e.1.5.1, %add135.6.1
  %mul116.7.1 = fmul float %div73.1, %74
  %446 = tail call float @llvm.fabs.f32(float %mul116.7.1) #4
  %decision.interval32 = fcmp ugt float %446, 2.500000e+00
  %447 = fcmp olt float %446, 1.750000e+00
  %448 = fcmp ole float %446, 1.250000e+00
  %merged.select198 = select i1 %decision.interval32, float 3.500000e+00, float 7.500000e-01
  %449 = fcmp olt float %446, %merged.select198
  %450 = fcmp ole float %446, 2.500000e-01
  %451 = select i1 %450, float 0.000000e+00, float 5.000000e-01
  %452 = fcmp ugt float %446, 5.000000e+00
  %guard.value220 = select i1 %decision.interval32, float undef, float %451
  %453 = select i1 %449, float %guard.value220, float 1.000000e+00
  %merged.select213 = select i1 %decision.interval32, i1 %452, i1 %448
  %merged.select214 = select i1 %decision.interval32, float 6.000000e+00, float %453
  %merged.select215 = select i1 %decision.interval32, float 4.000000e+00, float 1.500000e+00
  %454 = select i1 %merged.select213, float %merged.select214, float %merged.select215
  %merged.select216 = select i1 %decision.interval32, i1 %449, i1 %447
  %merged.select217 = select i1 %decision.interval32, float 3.000000e+00, float %454
  %merged.select218 = select i1 %decision.interval32, float %454, float 2.000000e+00
  %455 = select i1 %merged.select216, float %merged.select217, float %merged.select218
  %456 = tail call float @llvm.copysign.f32(float %455, float %mul116.7.1) #4
  %mul118.7.1 = fmul float %cond88.1, %456
  %sub.7.1 = fsub float %mul118.7.1, %74
  %mul126.7.1 = fmul float %div73.1, %77
  %457 = tail call float @llvm.fabs.f32(float %mul126.7.1) #4
  %decision.interval33 = fcmp ugt float %457, 2.500000e+00
  %458 = fcmp olt float %457, 1.750000e+00
  %459 = fcmp ole float %457, 1.250000e+00
  %merged.select205 = select i1 %decision.interval33, float 3.500000e+00, float 7.500000e-01
  %460 = fcmp olt float %457, %merged.select205
  %461 = fcmp ole float %457, 2.500000e-01
  %462 = select i1 %461, float 0.000000e+00, float 5.000000e-01
  %463 = fcmp ugt float %457, 5.000000e+00
  %guard.value227 = select i1 %decision.interval33, float undef, float %462
  %464 = select i1 %460, float %guard.value227, float 1.000000e+00
  %merged.select220 = select i1 %decision.interval33, i1 %463, i1 %459
  %merged.select221 = select i1 %decision.interval33, float 6.000000e+00, float %464
  %merged.select222 = select i1 %decision.interval33, float 4.000000e+00, float 1.500000e+00
  %465 = select i1 %merged.select220, float %merged.select221, float %merged.select222
  %merged.select223 = select i1 %decision.interval33, i1 %460, i1 %458
  %merged.select224 = select i1 %decision.interval33, float 3.000000e+00, float %465
  %merged.select225 = select i1 %decision.interval33, float %465, float 2.000000e+00
  %466 = select i1 %merged.select223, float %merged.select224, float %merged.select225
  %467 = tail call float @llvm.copysign.f32(float %466, float %mul126.7.1) #4
  %mul128.7.1 = fmul float %cond88.1, %467
  %sub132.7.1 = fsub float %mul128.7.1, %77
  %468 = insertelement <2 x float> undef, float %sub132.7.1, i32 0
  %469 = insertelement <2 x float> %468, float %sub.7.1, i32 1
  %470 = fmul <2 x float> %469, %469
  br label %for.inc138.7.1

if.then97.7.1:                                    ; preds = %cond.end75.1, %cond.end75.1.thread
  %os.sroa.0.5 = phi <2 x float> [ %290, %cond.end75.1.thread ], [ %291, %cond.end75.1 ]
  %mul102.1441 = fmul float %12, %12
  %mul109.1443 = fmul float %16, %16
  %add110.1444 = fadd float %mul102.1441, %mul109.1443
  %e.1.1447581 = fadd float %add110.1444, 0.000000e+00
  %mul102.1.1 = fmul float %20, %20
  %mul109.1.1 = fmul float %24, %24
  %add110.1.1 = fadd float %mul102.1.1, %mul109.1.1
  %e.1.1.1593 = fadd float %e.1.1447581, %add110.1.1
  %mul102.2.1 = fmul float %28, %28
  %mul109.2.1 = fmul float %32, %32
  %add110.2.1 = fadd float %mul102.2.1, %mul109.2.1
  %e.1.2.1605 = fadd float %e.1.1.1593, %add110.2.1
  %mul102.3.1 = fmul float %36, %36
  %mul109.3.1 = fmul float %40, %40
  %add110.3.1 = fadd float %mul102.3.1, %mul109.3.1
  %e.1.3.1617 = fadd float %e.1.2.1605, %add110.3.1
  %mul102.4.1 = fmul float %44, %44
  %mul109.4.1 = fmul float %48, %48
  %add110.4.1 = fadd float %mul102.4.1, %mul109.4.1
  %e.1.4.1629 = fadd float %e.1.3.1617, %add110.4.1
  %mul102.5.1 = fmul float %52, %52
  %mul109.5.1 = fmul float %56, %56
  %add110.5.1 = fadd float %mul102.5.1, %mul109.5.1
  %e.1.5.1641 = fadd float %e.1.4.1629, %add110.5.1
  %mul102.6.1 = fmul float %60, %60
  %mul109.6.1 = fmul float %64, %64
  %add110.6.1 = fadd float %mul102.6.1, %mul109.6.1
  %e.1.6.1653 = fadd float %e.1.5.1641, %add110.6.1
  %471 = fmul <2 x float> %73, %73
  br label %for.inc138.7.1

for.inc138.7.1:                                   ; preds = %if.then97.7.1, %if.else.7.1
  %os.sroa.0.6 = phi <2 x float> [ %291, %if.else.7.1 ], [ %os.sroa.0.5, %if.then97.7.1 ]
  %e.1.6.1654 = phi float [ %e.1.6.1, %if.else.7.1 ], [ %e.1.6.1653, %if.then97.7.1 ]
  %472 = phi <2 x float> [ %470, %if.else.7.1 ], [ %471, %if.then97.7.1 ]
  %473 = extractelement <2 x float> %472, i32 0
  %474 = extractelement <2 x float> %472, i32 1
  %add110.7.1 = fadd float %473, %474
  %e.1.7.1 = fadd float %e.1.6.1654, %add110.7.1
  %cmp149 = fcmp olt float %e.1.7.1, %e.1.7
  %conv153 = sext i32 %div35 to i64
  %add154 = add nsw i64 %mul152, %conv153
  %mul156 = mul nsw i64 %add154, %conv
  %add158 = add nsw i64 %mul156, %rem.decomposed
  %mul161 = mul nsw i64 %add158, %conv160
  %mul162 = shl nsw i32 %rem36.decomposed, 3
  %conv163 = sext i32 %mul162 to i64
  %add164 = add nsw i64 %mul161, %conv163
  %475 = zext i1 %cmp149 to i32
  %476 = extractelement <2 x float> %os.sroa.0.6, i32 %475
  %mul175 = fmul float %476, %12
  %477 = tail call float @llvm.fabs.f32(float %mul175) #4
  %cmp.i351 = fcmp ugt float %477, 2.500000e-01
  br i1 %cmp.i351, label %cond.false.i353, label %_Z5pack4f.exit369

cond.false.i353.1:                                ; preds = %_Z5pack4f.exit
  %cmp1.i352.1 = fcmp olt float %88, 7.500000e-01
  br i1 %cmp1.i352.1, label %_Z5pack4f.exit369.1, label %cond.false3.i355.1

cond.false3.i355.1:                               ; preds = %cond.false.i353.1
  %cmp4.i354.1 = fcmp ugt float %88, 1.250000e+00
  br i1 %cmp4.i354.1, label %cond.false6.i357.1, label %_Z5pack4f.exit369.1

cond.false6.i357.1:                               ; preds = %cond.false3.i355.1
  %cmp7.i356.1 = fcmp olt float %88, 1.750000e+00
  br i1 %cmp7.i356.1, label %_Z5pack4f.exit369.1, label %cond.false9.i359.1

cond.false9.i359.1:                               ; preds = %cond.false6.i357.1
  %cmp10.i358.1 = fcmp ugt float %88, 2.500000e+00
  br i1 %cmp10.i358.1, label %cond.false12.i361.1, label %_Z5pack4f.exit369.1

cond.false12.i361.1:                              ; preds = %cond.false9.i359.1
  %cmp13.i360.1 = fcmp olt float %88, 3.500000e+00
  br i1 %cmp13.i360.1, label %_Z5pack4f.exit369.1, label %cond.false15.i364.1

cond.false15.i364.1:                              ; preds = %cond.false12.i361.1
  %cmp16.i362.1 = fcmp ole float %88, 5.000000e+00
  %cond.i363.1 = select i1 %cmp16.i362.1, i32 6, i32 7
  br label %_Z5pack4f.exit369.1

_Z5pack4f.exit369.1:                              ; preds = %cond.false15.i364.1, %cond.false12.i361.1, %cond.false9.i359.1, %cond.false6.i357.1, %cond.false3.i355.1, %cond.false.i353.1, %_Z5pack4f.exit
  %cond27.i365.1 = phi i32 [ 0, %_Z5pack4f.exit ], [ 1, %cond.false.i353.1 ], [ 2, %cond.false3.i355.1 ], [ 3, %cond.false6.i357.1 ], [ 4, %cond.false9.i359.1 ], [ 5, %cond.false12.i361.1 ], [ %cond.i363.1, %cond.false15.i364.1 ]
  %478 = bitcast float %mul175.1 to i32
  %shr.i366.1 = lshr i32 %478, 28
  %and.i367.1 = and i32 %shr.i366.1, 8
  %or.i368.1 = or i32 %cond27.i365.1, %and.i367.1
  %mul183.1 = fmul float %476, %24
  %479 = tail call float @llvm.fabs.f32(float %mul183.1) #4
  %cmp.i.1 = fcmp ugt float %479, 2.500000e-01
  br i1 %cmp.i.1, label %cond.false.i.1, label %_Z5pack4f.exit.1

cond.false.i.1:                                   ; preds = %_Z5pack4f.exit369.1
  %cmp1.i.1 = fcmp olt float %479, 7.500000e-01
  br i1 %cmp1.i.1, label %_Z5pack4f.exit.1, label %cond.false3.i.1

cond.false3.i.1:                                  ; preds = %cond.false.i.1
  %cmp4.i.1 = fcmp ugt float %479, 1.250000e+00
  br i1 %cmp4.i.1, label %cond.false6.i.1, label %_Z5pack4f.exit.1

cond.false6.i.1:                                  ; preds = %cond.false3.i.1
  %cmp7.i.1 = fcmp olt float %479, 1.750000e+00
  br i1 %cmp7.i.1, label %_Z5pack4f.exit.1, label %cond.false9.i.1

cond.false9.i.1:                                  ; preds = %cond.false6.i.1
  %cmp10.i.1 = fcmp ugt float %479, 2.500000e+00
  br i1 %cmp10.i.1, label %cond.false12.i.1, label %_Z5pack4f.exit.1

cond.false12.i.1:                                 ; preds = %cond.false9.i.1
  %cmp13.i.1 = fcmp olt float %479, 3.500000e+00
  br i1 %cmp13.i.1, label %_Z5pack4f.exit.1, label %cond.false15.i.1

cond.false15.i.1:                                 ; preds = %cond.false12.i.1
  %cmp16.i.1 = fcmp ole float %479, 5.000000e+00
  %cond.i.1 = select i1 %cmp16.i.1, i32 6, i32 7
  br label %_Z5pack4f.exit.1

_Z5pack4f.exit.1:                                 ; preds = %cond.false15.i.1, %cond.false12.i.1, %cond.false9.i.1, %cond.false6.i.1, %cond.false3.i.1, %cond.false.i.1, %_Z5pack4f.exit369.1
  %cond27.i.1 = phi i32 [ 0, %_Z5pack4f.exit369.1 ], [ 1, %cond.false.i.1 ], [ 2, %cond.false3.i.1 ], [ 3, %cond.false6.i.1 ], [ 4, %cond.false9.i.1 ], [ 5, %cond.false12.i.1 ], [ %cond.i.1, %cond.false15.i.1 ]
  %480 = bitcast float %mul183.1 to i32
  %shr.i.1 = lshr i32 %480, 28
  %and.i.1 = and i32 %shr.i.1, 8
  %or.i.1 = or i32 %cond27.i.1, %and.i.1
  %shl.1 = shl nuw nsw i32 %or.i.1, 4
  %or.1 = or i32 %or.i368.1, %shl.1
  %conv185.1 = trunc i32 %or.1 to i8
  %add187.1 = add nsw i64 %add164, 1
  %arrayidx188339.1 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add187.1
  store i8 %conv185.1, i8 addrspace(1)* %arrayidx188339.1, align 1, !tbaa !12
  %mul175.2 = fmul float %476, %28
  %481 = tail call float @llvm.fabs.f32(float %mul175.2) #4
  %cmp.i351.2 = fcmp ugt float %481, 2.500000e-01
  br i1 %cmp.i351.2, label %cond.false.i353.2, label %_Z5pack4f.exit369.2

cond.false.i353.2:                                ; preds = %_Z5pack4f.exit.1
  %cmp1.i352.2 = fcmp olt float %481, 7.500000e-01
  br i1 %cmp1.i352.2, label %_Z5pack4f.exit369.2, label %cond.false3.i355.2

cond.false3.i355.2:                               ; preds = %cond.false.i353.2
  %cmp4.i354.2 = fcmp ugt float %481, 1.250000e+00
  br i1 %cmp4.i354.2, label %cond.false6.i357.2, label %_Z5pack4f.exit369.2

cond.false6.i357.2:                               ; preds = %cond.false3.i355.2
  %cmp7.i356.2 = fcmp olt float %481, 1.750000e+00
  br i1 %cmp7.i356.2, label %_Z5pack4f.exit369.2, label %cond.false9.i359.2

cond.false9.i359.2:                               ; preds = %cond.false6.i357.2
  %cmp10.i358.2 = fcmp ugt float %481, 2.500000e+00
  br i1 %cmp10.i358.2, label %cond.false12.i361.2, label %_Z5pack4f.exit369.2

cond.false12.i361.2:                              ; preds = %cond.false9.i359.2
  %cmp13.i360.2 = fcmp olt float %481, 3.500000e+00
  br i1 %cmp13.i360.2, label %_Z5pack4f.exit369.2, label %cond.false15.i364.2

cond.false15.i364.2:                              ; preds = %cond.false12.i361.2
  %cmp16.i362.2 = fcmp ole float %481, 5.000000e+00
  %cond.i363.2 = select i1 %cmp16.i362.2, i32 6, i32 7
  br label %_Z5pack4f.exit369.2

_Z5pack4f.exit369.2:                              ; preds = %cond.false15.i364.2, %cond.false12.i361.2, %cond.false9.i359.2, %cond.false6.i357.2, %cond.false3.i355.2, %cond.false.i353.2, %_Z5pack4f.exit.1
  %cond27.i365.2 = phi i32 [ 0, %_Z5pack4f.exit.1 ], [ 1, %cond.false.i353.2 ], [ 2, %cond.false3.i355.2 ], [ 3, %cond.false6.i357.2 ], [ 4, %cond.false9.i359.2 ], [ 5, %cond.false12.i361.2 ], [ %cond.i363.2, %cond.false15.i364.2 ]
  %482 = bitcast float %mul175.2 to i32
  %shr.i366.2 = lshr i32 %482, 28
  %and.i367.2 = and i32 %shr.i366.2, 8
  %or.i368.2 = or i32 %cond27.i365.2, %and.i367.2
  %mul183.2 = fmul float %476, %32
  %483 = tail call float @llvm.fabs.f32(float %mul183.2) #4
  %cmp.i.2 = fcmp ugt float %483, 2.500000e-01
  br i1 %cmp.i.2, label %cond.false.i.2, label %_Z5pack4f.exit.2

cond.false.i.2:                                   ; preds = %_Z5pack4f.exit369.2
  %cmp1.i.2 = fcmp olt float %483, 7.500000e-01
  br i1 %cmp1.i.2, label %_Z5pack4f.exit.2, label %cond.false3.i.2

cond.false3.i.2:                                  ; preds = %cond.false.i.2
  %cmp4.i.2 = fcmp ugt float %483, 1.250000e+00
  br i1 %cmp4.i.2, label %cond.false6.i.2, label %_Z5pack4f.exit.2

cond.false6.i.2:                                  ; preds = %cond.false3.i.2
  %cmp7.i.2 = fcmp olt float %483, 1.750000e+00
  br i1 %cmp7.i.2, label %_Z5pack4f.exit.2, label %cond.false9.i.2

cond.false9.i.2:                                  ; preds = %cond.false6.i.2
  %cmp10.i.2 = fcmp ugt float %483, 2.500000e+00
  br i1 %cmp10.i.2, label %cond.false12.i.2, label %_Z5pack4f.exit.2

cond.false12.i.2:                                 ; preds = %cond.false9.i.2
  %cmp13.i.2 = fcmp olt float %483, 3.500000e+00
  br i1 %cmp13.i.2, label %_Z5pack4f.exit.2, label %cond.false15.i.2

cond.false15.i.2:                                 ; preds = %cond.false12.i.2
  %cmp16.i.2 = fcmp ole float %483, 5.000000e+00
  %cond.i.2 = select i1 %cmp16.i.2, i32 6, i32 7
  br label %_Z5pack4f.exit.2

_Z5pack4f.exit.2:                                 ; preds = %cond.false15.i.2, %cond.false12.i.2, %cond.false9.i.2, %cond.false6.i.2, %cond.false3.i.2, %cond.false.i.2, %_Z5pack4f.exit369.2
  %cond27.i.2 = phi i32 [ 0, %_Z5pack4f.exit369.2 ], [ 1, %cond.false.i.2 ], [ 2, %cond.false3.i.2 ], [ 3, %cond.false6.i.2 ], [ 4, %cond.false9.i.2 ], [ 5, %cond.false12.i.2 ], [ %cond.i.2, %cond.false15.i.2 ]
  %484 = bitcast float %mul183.2 to i32
  %shr.i.2 = lshr i32 %484, 28
  %and.i.2 = and i32 %shr.i.2, 8
  %or.i.2 = or i32 %cond27.i.2, %and.i.2
  %shl.2 = shl nuw nsw i32 %or.i.2, 4
  %or.2 = or i32 %or.i368.2, %shl.2
  %conv185.2 = trunc i32 %or.2 to i8
  %add187.2 = add nsw i64 %add164, 2
  %arrayidx188339.2 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add187.2
  store i8 %conv185.2, i8 addrspace(1)* %arrayidx188339.2, align 1, !tbaa !12
  %mul175.3 = fmul float %476, %36
  %485 = tail call float @llvm.fabs.f32(float %mul175.3) #4
  %cmp.i351.3 = fcmp ugt float %485, 2.500000e-01
  br i1 %cmp.i351.3, label %cond.false.i353.3, label %_Z5pack4f.exit369.3

cond.false.i353.3:                                ; preds = %_Z5pack4f.exit.2
  %cmp1.i352.3 = fcmp olt float %485, 7.500000e-01
  br i1 %cmp1.i352.3, label %_Z5pack4f.exit369.3, label %cond.false3.i355.3

cond.false3.i355.3:                               ; preds = %cond.false.i353.3
  %cmp4.i354.3 = fcmp ugt float %485, 1.250000e+00
  br i1 %cmp4.i354.3, label %cond.false6.i357.3, label %_Z5pack4f.exit369.3

cond.false6.i357.3:                               ; preds = %cond.false3.i355.3
  %cmp7.i356.3 = fcmp olt float %485, 1.750000e+00
  br i1 %cmp7.i356.3, label %_Z5pack4f.exit369.3, label %cond.false9.i359.3

cond.false9.i359.3:                               ; preds = %cond.false6.i357.3
  %cmp10.i358.3 = fcmp ugt float %485, 2.500000e+00
  br i1 %cmp10.i358.3, label %cond.false12.i361.3, label %_Z5pack4f.exit369.3

cond.false12.i361.3:                              ; preds = %cond.false9.i359.3
  %cmp13.i360.3 = fcmp olt float %485, 3.500000e+00
  br i1 %cmp13.i360.3, label %_Z5pack4f.exit369.3, label %cond.false15.i364.3

cond.false15.i364.3:                              ; preds = %cond.false12.i361.3
  %cmp16.i362.3 = fcmp ole float %485, 5.000000e+00
  %cond.i363.3 = select i1 %cmp16.i362.3, i32 6, i32 7
  br label %_Z5pack4f.exit369.3

_Z5pack4f.exit369.3:                              ; preds = %cond.false15.i364.3, %cond.false12.i361.3, %cond.false9.i359.3, %cond.false6.i357.3, %cond.false3.i355.3, %cond.false.i353.3, %_Z5pack4f.exit.2
  %cond27.i365.3 = phi i32 [ 0, %_Z5pack4f.exit.2 ], [ 1, %cond.false.i353.3 ], [ 2, %cond.false3.i355.3 ], [ 3, %cond.false6.i357.3 ], [ 4, %cond.false9.i359.3 ], [ 5, %cond.false12.i361.3 ], [ %cond.i363.3, %cond.false15.i364.3 ]
  %486 = bitcast float %mul175.3 to i32
  %shr.i366.3 = lshr i32 %486, 28
  %and.i367.3 = and i32 %shr.i366.3, 8
  %or.i368.3 = or i32 %cond27.i365.3, %and.i367.3
  %mul183.3 = fmul float %476, %40
  %487 = tail call float @llvm.fabs.f32(float %mul183.3) #4
  %cmp.i.3 = fcmp ugt float %487, 2.500000e-01
  br i1 %cmp.i.3, label %cond.false.i.3, label %_Z5pack4f.exit.3

cond.false.i.3:                                   ; preds = %_Z5pack4f.exit369.3
  %cmp1.i.3 = fcmp olt float %487, 7.500000e-01
  br i1 %cmp1.i.3, label %_Z5pack4f.exit.3, label %cond.false3.i.3

cond.false3.i.3:                                  ; preds = %cond.false.i.3
  %cmp4.i.3 = fcmp ugt float %487, 1.250000e+00
  br i1 %cmp4.i.3, label %cond.false6.i.3, label %_Z5pack4f.exit.3

cond.false6.i.3:                                  ; preds = %cond.false3.i.3
  %cmp7.i.3 = fcmp olt float %487, 1.750000e+00
  br i1 %cmp7.i.3, label %_Z5pack4f.exit.3, label %cond.false9.i.3

cond.false9.i.3:                                  ; preds = %cond.false6.i.3
  %cmp10.i.3 = fcmp ugt float %487, 2.500000e+00
  br i1 %cmp10.i.3, label %cond.false12.i.3, label %_Z5pack4f.exit.3

cond.false12.i.3:                                 ; preds = %cond.false9.i.3
  %cmp13.i.3 = fcmp olt float %487, 3.500000e+00
  br i1 %cmp13.i.3, label %_Z5pack4f.exit.3, label %cond.false15.i.3

cond.false15.i.3:                                 ; preds = %cond.false12.i.3
  %cmp16.i.3 = fcmp ole float %487, 5.000000e+00
  %cond.i.3 = select i1 %cmp16.i.3, i32 6, i32 7
  br label %_Z5pack4f.exit.3

_Z5pack4f.exit.3:                                 ; preds = %cond.false15.i.3, %cond.false12.i.3, %cond.false9.i.3, %cond.false6.i.3, %cond.false3.i.3, %cond.false.i.3, %_Z5pack4f.exit369.3
  %cond27.i.3 = phi i32 [ 0, %_Z5pack4f.exit369.3 ], [ 1, %cond.false.i.3 ], [ 2, %cond.false3.i.3 ], [ 3, %cond.false6.i.3 ], [ 4, %cond.false9.i.3 ], [ 5, %cond.false12.i.3 ], [ %cond.i.3, %cond.false15.i.3 ]
  %488 = bitcast float %mul183.3 to i32
  %shr.i.3 = lshr i32 %488, 28
  %and.i.3 = and i32 %shr.i.3, 8
  %or.i.3 = or i32 %cond27.i.3, %and.i.3
  %shl.3 = shl nuw nsw i32 %or.i.3, 4
  %or.3 = or i32 %or.i368.3, %shl.3
  %conv185.3 = trunc i32 %or.3 to i8
  %add187.3 = add nsw i64 %add164, 3
  %arrayidx188339.3 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add187.3
  store i8 %conv185.3, i8 addrspace(1)* %arrayidx188339.3, align 1, !tbaa !12
  %mul175.4 = fmul float %476, %44
  %489 = tail call float @llvm.fabs.f32(float %mul175.4) #4
  %cmp.i351.4 = fcmp ugt float %489, 2.500000e-01
  br i1 %cmp.i351.4, label %cond.false.i353.4, label %_Z5pack4f.exit369.4

cond.false.i353.4:                                ; preds = %_Z5pack4f.exit.3
  %cmp1.i352.4 = fcmp olt float %489, 7.500000e-01
  br i1 %cmp1.i352.4, label %_Z5pack4f.exit369.4, label %cond.false3.i355.4

cond.false3.i355.4:                               ; preds = %cond.false.i353.4
  %cmp4.i354.4 = fcmp ugt float %489, 1.250000e+00
  br i1 %cmp4.i354.4, label %cond.false6.i357.4, label %_Z5pack4f.exit369.4

cond.false6.i357.4:                               ; preds = %cond.false3.i355.4
  %cmp7.i356.4 = fcmp olt float %489, 1.750000e+00
  br i1 %cmp7.i356.4, label %_Z5pack4f.exit369.4, label %cond.false9.i359.4

cond.false9.i359.4:                               ; preds = %cond.false6.i357.4
  %cmp10.i358.4 = fcmp ugt float %489, 2.500000e+00
  br i1 %cmp10.i358.4, label %cond.false12.i361.4, label %_Z5pack4f.exit369.4

cond.false12.i361.4:                              ; preds = %cond.false9.i359.4
  %cmp13.i360.4 = fcmp olt float %489, 3.500000e+00
  br i1 %cmp13.i360.4, label %_Z5pack4f.exit369.4, label %cond.false15.i364.4

cond.false15.i364.4:                              ; preds = %cond.false12.i361.4
  %cmp16.i362.4 = fcmp ole float %489, 5.000000e+00
  %cond.i363.4 = select i1 %cmp16.i362.4, i32 6, i32 7
  br label %_Z5pack4f.exit369.4

_Z5pack4f.exit369.4:                              ; preds = %cond.false15.i364.4, %cond.false12.i361.4, %cond.false9.i359.4, %cond.false6.i357.4, %cond.false3.i355.4, %cond.false.i353.4, %_Z5pack4f.exit.3
  %cond27.i365.4 = phi i32 [ 0, %_Z5pack4f.exit.3 ], [ 1, %cond.false.i353.4 ], [ 2, %cond.false3.i355.4 ], [ 3, %cond.false6.i357.4 ], [ 4, %cond.false9.i359.4 ], [ 5, %cond.false12.i361.4 ], [ %cond.i363.4, %cond.false15.i364.4 ]
  %490 = bitcast float %mul175.4 to i32
  %shr.i366.4 = lshr i32 %490, 28
  %and.i367.4 = and i32 %shr.i366.4, 8
  %or.i368.4 = or i32 %cond27.i365.4, %and.i367.4
  %mul183.4 = fmul float %476, %48
  %491 = tail call float @llvm.fabs.f32(float %mul183.4) #4
  %cmp.i.4 = fcmp ugt float %491, 2.500000e-01
  br i1 %cmp.i.4, label %cond.false.i.4, label %_Z5pack4f.exit.4

cond.false.i.4:                                   ; preds = %_Z5pack4f.exit369.4
  %cmp1.i.4 = fcmp olt float %491, 7.500000e-01
  br i1 %cmp1.i.4, label %_Z5pack4f.exit.4, label %cond.false3.i.4

cond.false3.i.4:                                  ; preds = %cond.false.i.4
  %cmp4.i.4 = fcmp ugt float %491, 1.250000e+00
  br i1 %cmp4.i.4, label %cond.false6.i.4, label %_Z5pack4f.exit.4

cond.false6.i.4:                                  ; preds = %cond.false3.i.4
  %cmp7.i.4 = fcmp olt float %491, 1.750000e+00
  br i1 %cmp7.i.4, label %_Z5pack4f.exit.4, label %cond.false9.i.4

cond.false9.i.4:                                  ; preds = %cond.false6.i.4
  %cmp10.i.4 = fcmp ugt float %491, 2.500000e+00
  br i1 %cmp10.i.4, label %cond.false12.i.4, label %_Z5pack4f.exit.4

cond.false12.i.4:                                 ; preds = %cond.false9.i.4
  %cmp13.i.4 = fcmp olt float %491, 3.500000e+00
  br i1 %cmp13.i.4, label %_Z5pack4f.exit.4, label %cond.false15.i.4

cond.false15.i.4:                                 ; preds = %cond.false12.i.4
  %cmp16.i.4 = fcmp ole float %491, 5.000000e+00
  %cond.i.4 = select i1 %cmp16.i.4, i32 6, i32 7
  br label %_Z5pack4f.exit.4

_Z5pack4f.exit.4:                                 ; preds = %cond.false15.i.4, %cond.false12.i.4, %cond.false9.i.4, %cond.false6.i.4, %cond.false3.i.4, %cond.false.i.4, %_Z5pack4f.exit369.4
  %cond27.i.4 = phi i32 [ 0, %_Z5pack4f.exit369.4 ], [ 1, %cond.false.i.4 ], [ 2, %cond.false3.i.4 ], [ 3, %cond.false6.i.4 ], [ 4, %cond.false9.i.4 ], [ 5, %cond.false12.i.4 ], [ %cond.i.4, %cond.false15.i.4 ]
  %492 = bitcast float %mul183.4 to i32
  %shr.i.4 = lshr i32 %492, 28
  %and.i.4 = and i32 %shr.i.4, 8
  %or.i.4 = or i32 %cond27.i.4, %and.i.4
  %shl.4 = shl nuw nsw i32 %or.i.4, 4
  %or.4 = or i32 %or.i368.4, %shl.4
  %conv185.4 = trunc i32 %or.4 to i8
  %add187.4 = add nsw i64 %add164, 4
  %arrayidx188339.4 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add187.4
  store i8 %conv185.4, i8 addrspace(1)* %arrayidx188339.4, align 1, !tbaa !12
  %mul175.5 = fmul float %476, %52
  %493 = tail call float @llvm.fabs.f32(float %mul175.5) #4
  %cmp.i351.5 = fcmp ugt float %493, 2.500000e-01
  br i1 %cmp.i351.5, label %cond.false.i353.5, label %_Z5pack4f.exit369.5

cond.false.i353.5:                                ; preds = %_Z5pack4f.exit.4
  %cmp1.i352.5 = fcmp olt float %493, 7.500000e-01
  br i1 %cmp1.i352.5, label %_Z5pack4f.exit369.5, label %cond.false3.i355.5

cond.false3.i355.5:                               ; preds = %cond.false.i353.5
  %cmp4.i354.5 = fcmp ugt float %493, 1.250000e+00
  br i1 %cmp4.i354.5, label %cond.false6.i357.5, label %_Z5pack4f.exit369.5

cond.false6.i357.5:                               ; preds = %cond.false3.i355.5
  %cmp7.i356.5 = fcmp olt float %493, 1.750000e+00
  br i1 %cmp7.i356.5, label %_Z5pack4f.exit369.5, label %cond.false9.i359.5

cond.false9.i359.5:                               ; preds = %cond.false6.i357.5
  %cmp10.i358.5 = fcmp ugt float %493, 2.500000e+00
  br i1 %cmp10.i358.5, label %cond.false12.i361.5, label %_Z5pack4f.exit369.5

cond.false12.i361.5:                              ; preds = %cond.false9.i359.5
  %cmp13.i360.5 = fcmp olt float %493, 3.500000e+00
  br i1 %cmp13.i360.5, label %_Z5pack4f.exit369.5, label %cond.false15.i364.5

cond.false15.i364.5:                              ; preds = %cond.false12.i361.5
  %cmp16.i362.5 = fcmp ole float %493, 5.000000e+00
  %cond.i363.5 = select i1 %cmp16.i362.5, i32 6, i32 7
  br label %_Z5pack4f.exit369.5

_Z5pack4f.exit369.5:                              ; preds = %cond.false15.i364.5, %cond.false12.i361.5, %cond.false9.i359.5, %cond.false6.i357.5, %cond.false3.i355.5, %cond.false.i353.5, %_Z5pack4f.exit.4
  %cond27.i365.5 = phi i32 [ 0, %_Z5pack4f.exit.4 ], [ 1, %cond.false.i353.5 ], [ 2, %cond.false3.i355.5 ], [ 3, %cond.false6.i357.5 ], [ 4, %cond.false9.i359.5 ], [ 5, %cond.false12.i361.5 ], [ %cond.i363.5, %cond.false15.i364.5 ]
  %494 = bitcast float %mul175.5 to i32
  %shr.i366.5 = lshr i32 %494, 28
  %and.i367.5 = and i32 %shr.i366.5, 8
  %or.i368.5 = or i32 %cond27.i365.5, %and.i367.5
  %mul183.5 = fmul float %476, %56
  %495 = tail call float @llvm.fabs.f32(float %mul183.5) #4
  %cmp.i.5 = fcmp ugt float %495, 2.500000e-01
  br i1 %cmp.i.5, label %cond.false.i.5, label %_Z5pack4f.exit.5

cond.false.i.5:                                   ; preds = %_Z5pack4f.exit369.5
  %cmp1.i.5 = fcmp olt float %495, 7.500000e-01
  br i1 %cmp1.i.5, label %_Z5pack4f.exit.5, label %cond.false3.i.5

cond.false3.i.5:                                  ; preds = %cond.false.i.5
  %cmp4.i.5 = fcmp ugt float %495, 1.250000e+00
  br i1 %cmp4.i.5, label %cond.false6.i.5, label %_Z5pack4f.exit.5

cond.false6.i.5:                                  ; preds = %cond.false3.i.5
  %cmp7.i.5 = fcmp olt float %495, 1.750000e+00
  br i1 %cmp7.i.5, label %_Z5pack4f.exit.5, label %cond.false9.i.5

cond.false9.i.5:                                  ; preds = %cond.false6.i.5
  %cmp10.i.5 = fcmp ugt float %495, 2.500000e+00
  br i1 %cmp10.i.5, label %cond.false12.i.5, label %_Z5pack4f.exit.5

cond.false12.i.5:                                 ; preds = %cond.false9.i.5
  %cmp13.i.5 = fcmp olt float %495, 3.500000e+00
  br i1 %cmp13.i.5, label %_Z5pack4f.exit.5, label %cond.false15.i.5

cond.false15.i.5:                                 ; preds = %cond.false12.i.5
  %cmp16.i.5 = fcmp ole float %495, 5.000000e+00
  %cond.i.5 = select i1 %cmp16.i.5, i32 6, i32 7
  br label %_Z5pack4f.exit.5

_Z5pack4f.exit.5:                                 ; preds = %cond.false15.i.5, %cond.false12.i.5, %cond.false9.i.5, %cond.false6.i.5, %cond.false3.i.5, %cond.false.i.5, %_Z5pack4f.exit369.5
  %cond27.i.5 = phi i32 [ 0, %_Z5pack4f.exit369.5 ], [ 1, %cond.false.i.5 ], [ 2, %cond.false3.i.5 ], [ 3, %cond.false6.i.5 ], [ 4, %cond.false9.i.5 ], [ 5, %cond.false12.i.5 ], [ %cond.i.5, %cond.false15.i.5 ]
  %496 = bitcast float %mul183.5 to i32
  %shr.i.5 = lshr i32 %496, 28
  %and.i.5 = and i32 %shr.i.5, 8
  %or.i.5 = or i32 %cond27.i.5, %and.i.5
  %shl.5 = shl nuw nsw i32 %or.i.5, 4
  %or.5 = or i32 %or.i368.5, %shl.5
  %conv185.5 = trunc i32 %or.5 to i8
  %add187.5 = add nsw i64 %add164, 5
  %arrayidx188339.5 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add187.5
  store i8 %conv185.5, i8 addrspace(1)* %arrayidx188339.5, align 1, !tbaa !12
  %mul175.6 = fmul float %476, %60
  %497 = tail call float @llvm.fabs.f32(float %mul175.6) #4
  %cmp.i351.6 = fcmp ugt float %497, 2.500000e-01
  br i1 %cmp.i351.6, label %cond.false.i353.6, label %_Z5pack4f.exit369.6

cond.false.i353.6:                                ; preds = %_Z5pack4f.exit.5
  %cmp1.i352.6 = fcmp olt float %497, 7.500000e-01
  br i1 %cmp1.i352.6, label %_Z5pack4f.exit369.6, label %cond.false3.i355.6

cond.false3.i355.6:                               ; preds = %cond.false.i353.6
  %cmp4.i354.6 = fcmp ugt float %497, 1.250000e+00
  br i1 %cmp4.i354.6, label %cond.false6.i357.6, label %_Z5pack4f.exit369.6

cond.false6.i357.6:                               ; preds = %cond.false3.i355.6
  %cmp7.i356.6 = fcmp olt float %497, 1.750000e+00
  br i1 %cmp7.i356.6, label %_Z5pack4f.exit369.6, label %cond.false9.i359.6

cond.false9.i359.6:                               ; preds = %cond.false6.i357.6
  %cmp10.i358.6 = fcmp ugt float %497, 2.500000e+00
  br i1 %cmp10.i358.6, label %cond.false12.i361.6, label %_Z5pack4f.exit369.6

cond.false12.i361.6:                              ; preds = %cond.false9.i359.6
  %cmp13.i360.6 = fcmp olt float %497, 3.500000e+00
  br i1 %cmp13.i360.6, label %_Z5pack4f.exit369.6, label %cond.false15.i364.6

cond.false15.i364.6:                              ; preds = %cond.false12.i361.6
  %cmp16.i362.6 = fcmp ole float %497, 5.000000e+00
  %cond.i363.6 = select i1 %cmp16.i362.6, i32 6, i32 7
  br label %_Z5pack4f.exit369.6

_Z5pack4f.exit369.6:                              ; preds = %cond.false15.i364.6, %cond.false12.i361.6, %cond.false9.i359.6, %cond.false6.i357.6, %cond.false3.i355.6, %cond.false.i353.6, %_Z5pack4f.exit.5
  %cond27.i365.6 = phi i32 [ 0, %_Z5pack4f.exit.5 ], [ 1, %cond.false.i353.6 ], [ 2, %cond.false3.i355.6 ], [ 3, %cond.false6.i357.6 ], [ 4, %cond.false9.i359.6 ], [ 5, %cond.false12.i361.6 ], [ %cond.i363.6, %cond.false15.i364.6 ]
  %498 = bitcast float %mul175.6 to i32
  %shr.i366.6 = lshr i32 %498, 28
  %and.i367.6 = and i32 %shr.i366.6, 8
  %or.i368.6 = or i32 %cond27.i365.6, %and.i367.6
  %mul183.6 = fmul float %476, %64
  %499 = tail call float @llvm.fabs.f32(float %mul183.6) #4
  %cmp.i.6 = fcmp ugt float %499, 2.500000e-01
  br i1 %cmp.i.6, label %cond.false.i.6, label %_Z5pack4f.exit.6

cond.false.i.6:                                   ; preds = %_Z5pack4f.exit369.6
  %cmp1.i.6 = fcmp olt float %499, 7.500000e-01
  br i1 %cmp1.i.6, label %_Z5pack4f.exit.6, label %cond.false3.i.6

cond.false3.i.6:                                  ; preds = %cond.false.i.6
  %cmp4.i.6 = fcmp ugt float %499, 1.250000e+00
  br i1 %cmp4.i.6, label %cond.false6.i.6, label %_Z5pack4f.exit.6

cond.false6.i.6:                                  ; preds = %cond.false3.i.6
  %cmp7.i.6 = fcmp olt float %499, 1.750000e+00
  br i1 %cmp7.i.6, label %_Z5pack4f.exit.6, label %cond.false9.i.6

cond.false9.i.6:                                  ; preds = %cond.false6.i.6
  %cmp10.i.6 = fcmp ugt float %499, 2.500000e+00
  br i1 %cmp10.i.6, label %cond.false12.i.6, label %_Z5pack4f.exit.6

cond.false12.i.6:                                 ; preds = %cond.false9.i.6
  %cmp13.i.6 = fcmp olt float %499, 3.500000e+00
  br i1 %cmp13.i.6, label %_Z5pack4f.exit.6, label %cond.false15.i.6

cond.false15.i.6:                                 ; preds = %cond.false12.i.6
  %cmp16.i.6 = fcmp ole float %499, 5.000000e+00
  %cond.i.6 = select i1 %cmp16.i.6, i32 6, i32 7
  br label %_Z5pack4f.exit.6

_Z5pack4f.exit.6:                                 ; preds = %cond.false15.i.6, %cond.false12.i.6, %cond.false9.i.6, %cond.false6.i.6, %cond.false3.i.6, %cond.false.i.6, %_Z5pack4f.exit369.6
  %cond27.i.6 = phi i32 [ 0, %_Z5pack4f.exit369.6 ], [ 1, %cond.false.i.6 ], [ 2, %cond.false3.i.6 ], [ 3, %cond.false6.i.6 ], [ 4, %cond.false9.i.6 ], [ 5, %cond.false12.i.6 ], [ %cond.i.6, %cond.false15.i.6 ]
  %500 = bitcast float %mul183.6 to i32
  %shr.i.6 = lshr i32 %500, 28
  %and.i.6 = and i32 %shr.i.6, 8
  %or.i.6 = or i32 %cond27.i.6, %and.i.6
  %shl.6 = shl nuw nsw i32 %or.i.6, 4
  %or.6 = or i32 %or.i368.6, %shl.6
  %conv185.6 = trunc i32 %or.6 to i8
  %add187.6 = add nsw i64 %add164, 6
  %arrayidx188339.6 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add187.6
  store i8 %conv185.6, i8 addrspace(1)* %arrayidx188339.6, align 1, !tbaa !12
  %mul175.7 = fmul float %476, %74
  %501 = tail call float @llvm.fabs.f32(float %mul175.7) #4
  %cmp.i351.7 = fcmp ugt float %501, 2.500000e-01
  br i1 %cmp.i351.7, label %cond.false.i353.7, label %_Z5pack4f.exit369.7

cond.false.i353.7:                                ; preds = %_Z5pack4f.exit.6
  %cmp1.i352.7 = fcmp olt float %501, 7.500000e-01
  br i1 %cmp1.i352.7, label %_Z5pack4f.exit369.7, label %cond.false3.i355.7

cond.false3.i355.7:                               ; preds = %cond.false.i353.7
  %cmp4.i354.7 = fcmp ugt float %501, 1.250000e+00
  br i1 %cmp4.i354.7, label %cond.false6.i357.7, label %_Z5pack4f.exit369.7

cond.false6.i357.7:                               ; preds = %cond.false3.i355.7
  %cmp7.i356.7 = fcmp olt float %501, 1.750000e+00
  br i1 %cmp7.i356.7, label %_Z5pack4f.exit369.7, label %cond.false9.i359.7

cond.false9.i359.7:                               ; preds = %cond.false6.i357.7
  %cmp10.i358.7 = fcmp ugt float %501, 2.500000e+00
  br i1 %cmp10.i358.7, label %cond.false12.i361.7, label %_Z5pack4f.exit369.7

cond.false12.i361.7:                              ; preds = %cond.false9.i359.7
  %cmp13.i360.7 = fcmp olt float %501, 3.500000e+00
  br i1 %cmp13.i360.7, label %_Z5pack4f.exit369.7, label %cond.false15.i364.7

cond.false15.i364.7:                              ; preds = %cond.false12.i361.7
  %cmp16.i362.7 = fcmp ole float %501, 5.000000e+00
  %cond.i363.7 = select i1 %cmp16.i362.7, i32 6, i32 7
  br label %_Z5pack4f.exit369.7

_Z5pack4f.exit369.7:                              ; preds = %cond.false15.i364.7, %cond.false12.i361.7, %cond.false9.i359.7, %cond.false6.i357.7, %cond.false3.i355.7, %cond.false.i353.7, %_Z5pack4f.exit.6
  %cond27.i365.7 = phi i32 [ 0, %_Z5pack4f.exit.6 ], [ 1, %cond.false.i353.7 ], [ 2, %cond.false3.i355.7 ], [ 3, %cond.false6.i357.7 ], [ 4, %cond.false9.i359.7 ], [ 5, %cond.false12.i361.7 ], [ %cond.i363.7, %cond.false15.i364.7 ]
  %502 = bitcast float %mul175.7 to i32
  %shr.i366.7 = lshr i32 %502, 28
  %and.i367.7 = and i32 %shr.i366.7, 8
  %or.i368.7 = or i32 %cond27.i365.7, %and.i367.7
  %mul183.7 = fmul float %476, %77
  %503 = tail call float @llvm.fabs.f32(float %mul183.7) #4
  %cmp.i.7 = fcmp ugt float %503, 2.500000e-01
  br i1 %cmp.i.7, label %cond.false.i.7, label %_Z5pack4f.exit.7

cond.false.i.7:                                   ; preds = %_Z5pack4f.exit369.7
  %cmp1.i.7 = fcmp olt float %503, 7.500000e-01
  br i1 %cmp1.i.7, label %_Z5pack4f.exit.7, label %cond.false3.i.7

cond.false3.i.7:                                  ; preds = %cond.false.i.7
  %cmp4.i.7 = fcmp ugt float %503, 1.250000e+00
  br i1 %cmp4.i.7, label %cond.false6.i.7, label %_Z5pack4f.exit.7

cond.false6.i.7:                                  ; preds = %cond.false3.i.7
  %cmp7.i.7 = fcmp olt float %503, 1.750000e+00
  br i1 %cmp7.i.7, label %_Z5pack4f.exit.7, label %cond.false9.i.7

cond.false9.i.7:                                  ; preds = %cond.false6.i.7
  %cmp10.i.7 = fcmp ugt float %503, 2.500000e+00
  br i1 %cmp10.i.7, label %cond.false12.i.7, label %_Z5pack4f.exit.7

cond.false12.i.7:                                 ; preds = %cond.false9.i.7
  %cmp13.i.7 = fcmp olt float %503, 3.500000e+00
  br i1 %cmp13.i.7, label %_Z5pack4f.exit.7, label %cond.false15.i.7

cond.false15.i.7:                                 ; preds = %cond.false12.i.7
  %cmp16.i.7 = fcmp ole float %503, 5.000000e+00
  %cond.i.7 = select i1 %cmp16.i.7, i32 6, i32 7
  br label %_Z5pack4f.exit.7

_Z5pack4f.exit.7:                                 ; preds = %cond.false15.i.7, %cond.false12.i.7, %cond.false9.i.7, %cond.false6.i.7, %cond.false3.i.7, %cond.false.i.7, %_Z5pack4f.exit369.7
  %cond27.i.7 = phi i32 [ 0, %_Z5pack4f.exit369.7 ], [ 1, %cond.false.i.7 ], [ 2, %cond.false3.i.7 ], [ 3, %cond.false6.i.7 ], [ 4, %cond.false9.i.7 ], [ 5, %cond.false12.i.7 ], [ %cond.i.7, %cond.false15.i.7 ]
  %504 = bitcast float %mul183.7 to i32
  %shr.i.7 = lshr i32 %504, 28
  %and.i.7 = and i32 %shr.i.7, 8
  %or.i.7 = or i32 %cond27.i.7, %and.i.7
  %shl.7 = shl nuw nsw i32 %or.i.7, 4
  %or.7 = or i32 %or.i368.7, %shl.7
  %conv185.7 = trunc i32 %or.7 to i8
  %add187.7 = add nsw i64 %add164, 7
  %arrayidx188339.7 = getelementptr inbounds i8, i8 addrspace(1)* %cond19.v, i64 %add187.7
  store i8 %conv185.7, i8 addrspace(1)* %arrayidx188339.7, align 1, !tbaa !12
  br i1 %tobool.not, label %if.end204, label %if.then193
}

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.fabs.f32(float) #3

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.maxnum.f32(float, float) #3

; Function Attrs: nounwind readnone speculatable willreturn
declare float @llvm.amdgcn.ldexp.f32(float, i32) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare float @llvm.copysign.f32(float, float) #3

attributes #0 = { argmemonly nofree nosync nounwind willreturn }
attributes #1 = { norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #4 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/charitha22/cgo22ae-darm-code.git e9bc0540325ad9806313d34e84fc901496fd8be6)"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{!6, !6, i64 0}
!6 = !{!"long", !7, i64 0}
!7 = !{!"omnipotent char", !8, i64 0}
!8 = !{!"Simple C++ TBAA"}
!9 = !{i32 0, i32 1024}
!10 = !{!11, !11, i64 0}
!11 = !{!"short", !7, i64 0}
!12 = !{!7, !7, i64 0}
