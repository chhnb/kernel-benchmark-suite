; ModuleID = '/data/home/chh/simplify-v2/build/b2b-layouts/anchor-ablation/heldout/Landau/active/trial-349/fused.ll'
source_filename = "/home/chh/divergence-strategy-search/explorations/partition-darm-rocm-20261025/boost/generated/landau-mask0/kernel.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @evaluate(double addrspace(1)* nocapture readonly %input.coerce, double addrspace(1)* nocapture %output.coerce, i32 %n) local_unnamed_addr #0 {
entry:
  %0 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %1 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %2 = getelementptr i8, i8 addrspace(4)* %1, i64 4
  %3 = bitcast i8 addrspace(4)* %2 to i16 addrspace(4)*
  %4 = load i16, i16 addrspace(4)* %3, align 4, !range !5, !invariant.load !6
  %5 = zext i16 %4 to i32
  %6 = mul i32 %0, %5
  %7 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !7
  %add = add i32 %6, %7
  %cmp = icmp slt i32 %add, %n
  br i1 %cmp, label %if.end9.i.i, label %if.end

if.end9.i.i:                                      ; preds = %entry
  %idxprom = sext i32 %add to i64
  %arrayidx11 = getelementptr inbounds double, double addrspace(1)* %input.coerce, i64 %idxprom
  %arrayidx.val = load double, double addrspace(1)* %arrayidx11, align 8, !tbaa !8
  %cmp.i4.i.i = fcmp olt double %arrayidx.val, 0.000000e+00
  %cmp1.i.i.i = fcmp ogt double %arrayidx.val, 1.000000e+00
  %or.cond.i.i.i = or i1 %cmp.i4.i.i, %cmp1.i.i.i
  br i1 %or.cond.i.i.i, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14promote_doubleILb0EEENS2_12domain_errorILNS2_17error_policy_typeE2EEENS2_14overflow_errorILS7_2EEENS2_14default_policyESB_SB_SB_SB_SB_SB_SB_SB_SB_EEEET_RKNS0_19landau_distributionISD_T0_EERKSD_.exit, label %lor.lhs.false2.i.i.i

lor.lhs.false2.i.i.i:                             ; preds = %if.end9.i.i
  %cmp.i.i.i.i.i = fcmp uno double %arrayidx.val, 0.000000e+00
  %cmp.i3.i.i.i.i = fcmp ogt double %arrayidx.val, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i.i.i = fcmp olt double %arrayidx.val, 0xFFEFFFFFFFFFFFFF
  %lnot.i.i.i.i.not = or i1 %cmp.i3.i.i.i.i, %cmp1.i.i.i.i.i
  %brmerge = or i1 %cmp.i.i.i.i.i, %lnot.i.i.i.i.not
  br i1 %brmerge, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14promote_doubleILb0EEENS2_12domain_errorILNS2_17error_policy_typeE2EEENS2_14overflow_errorILS7_2EEENS2_14default_policyESB_SB_SB_SB_SB_SB_SB_SB_SB_EEEET_RKNS0_19landau_distributionISD_T0_EERKSD_.exit, label %if.end15.i.i

if.end15.i.i:                                     ; preds = %lor.lhs.false2.i.i.i
  %cmp.i.i.i = fcmp ogt double %arrayidx.val, 5.000000e-01
  br i1 %cmp.i.i.i, label %if.then.i.i.i, label %cond.false7.i.i.i

if.then.i.i.i:                                    ; preds = %if.end15.i.i
  %sub.i.i.i = fsub double 1.000000e+00, %arrayidx.val
  %decision.interval8 = fcmp ult double %sub.i.i.i, 1.250000e-01
  br i1 %decision.interval8, label %if.else17.i.i.i.i, label %decision.dispatch7, !decision.condition_prefix !6

decision.dispatch7:                               ; preds = %if.then.i.i.i
  %decision.interval = fcmp ult double %sub.i.i.i, 2.500000e-01
  %8 = fcmp ult double %sub.i.i.i, 3.750000e-01
  %9 = select i1 %8, double -2.500000e-01, double -3.750000e-01
  %10 = select i1 %decision.interval, double -1.250000e-01, double %9
  %11 = select i1 %decision.interval, i1 poison, i1 %8
  %12 = fadd double %sub.i.i.i, %10
  %13 = fmul double %12, %12
  %14 = select i1 %11, double 0x40277F82F0DAE120, double 0x403C1881A9A265FD
  %15 = select i1 %decision.interval, double 0x4094388834A6E4C6, double %14
  %16 = fmul double %13, %15
  br i1 %decision.interval, label %fusion.side8, label %fusion.side9

if.else17.i.i.i.i:                                ; preds = %if.then.i.i.i
  %17 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %sub.i.i.i) #3
  %18 = add nsw i32 %17, -1
  %19 = fcmp uno double %sub.i.i.i, 0.000000e+00
  %20 = tail call double @llvm.fabs.f64(double %sub.i.i.i) #4
  %21 = fcmp oeq double %20, 0x7FF0000000000000
  %22 = or i1 %19, %21
  %23 = select i1 %22, i32 2147483647, i32 %18
  %24 = fcmp oeq double %sub.i.i.i, 0.000000e+00
  %25 = select i1 %24, i32 -2147483648, i32 %23
  %cmp65.i.i.i.i = icmp sgt i32 %25, -65
  br i1 %cmp65.i.i.i.i, label %decision.dispatch3, label %if.else75.i.i.i.i, !decision.condition_prefix !6

decision.dispatch3:                               ; preds = %if.else17.i.i.i.i
  %cmp19.i.i.i.i = icmp sgt i32 %25, -5
  %26 = icmp sgt i32 %25, -17
  %27 = select i1 %26, i32 -9, i32 -33
  %28 = icmp sgt i32 %25, %27
  %29 = select i1 %26, i32 4, i32 16
  %30 = select i1 %26, i32 8, i32 32
  %31 = select i1 %28, i32 %29, i32 %30
  %32 = select i1 %cmp19.i.i.i.i, i1 poison, i1 %26
  %33 = select i1 %cmp19.i.i.i.i, i1 poison, i1 %28
  %34 = select i1 %cmp19.i.i.i.i, i32 3, i32 %31
  %35 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 %34) #3
  %36 = tail call double @llvm.amdgcn.frexp.mant.f64(double %35) #3
  %37 = fcmp olt double %36, 0x3FE5555555555555
  %38 = zext i1 %37 to i32
  %39 = tail call double @llvm.amdgcn.ldexp.f64(double %36, i32 %38) #3
  %40 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %35) #3
  %41 = sub nsw i32 %40, %38
  %42 = fadd double %39, -1.000000e+00
  %43 = fadd double %39, 1.000000e+00
  %44 = fsub double %43, %39
  %45 = fsub double %43, %44
  %46 = fsub double %39, %45
  %47 = fsub double 1.000000e+00, %44
  %48 = fadd double %47, %46
  %49 = tail call double @llvm.amdgcn.rcp.f64(double %43) #3
  %50 = fneg double %43
  %51 = tail call double @llvm.fma.f64(double %50, double %49, double 1.000000e+00) #3
  %52 = tail call double @llvm.fma.f64(double %51, double %49, double %49) #3
  %53 = tail call double @llvm.fma.f64(double %50, double %52, double 1.000000e+00) #3
  %54 = tail call double @llvm.fma.f64(double %53, double %52, double %52) #3
  %55 = fmul double %42, %54
  %56 = fmul double %43, %55
  %57 = fneg double %56
  %58 = tail call double @llvm.fma.f64(double %55, double %43, double %57) #3
  %59 = tail call double @llvm.fma.f64(double %55, double %48, double %58) #3
  %60 = fadd double %56, %59
  %61 = fsub double %60, %56
  %62 = fsub double %59, %61
  %63 = fsub double %42, %60
  %64 = fsub double %42, %63
  %65 = fsub double %64, %60
  %66 = fsub double %65, %62
  %67 = fadd double %63, %66
  %68 = fmul double %54, %67
  %69 = fadd double %55, %68
  %70 = fsub double %69, %55
  %71 = fsub double %68, %70
  %72 = fmul double %69, %69
  %73 = fneg double %72
  %74 = tail call double @llvm.fma.f64(double %69, double %69, double %73) #3
  %75 = fmul double %71, 2.000000e+00
  %76 = tail call double @llvm.fma.f64(double %69, double %75, double %74) #3
  %77 = tail call double @llvm.fma.f64(double %71, double %71, double %76) #3
  %78 = fadd double %72, %77
  %79 = fsub double %78, %72
  %80 = fsub double %77, %79
  %81 = tail call double @llvm.fma.f64(double %78, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %82 = tail call double @llvm.fma.f64(double %78, double %81, double 0x3FC7474DD7F4DF2E) #3
  %83 = tail call double @llvm.fma.f64(double %78, double %82, double 0x3FCC71C016291751) #3
  %84 = tail call double @llvm.fma.f64(double %78, double %83, double 0x3FD249249B27ACF1) #3
  %85 = tail call double @llvm.fma.f64(double %78, double %84, double 0x3FD99999998EF7B6) #3
  %86 = tail call double @llvm.fma.f64(double %78, double %85, double 0x3FE5555555555780) #3
  %87 = tail call double @llvm.amdgcn.ldexp.f64(double %69, i32 1) #3
  %88 = tail call double @llvm.amdgcn.ldexp.f64(double %71, i32 1) #3
  %89 = fmul double %69, %78
  %90 = fneg double %89
  %91 = tail call double @llvm.fma.f64(double %69, double %78, double %90) #3
  %92 = fmul double %71, %78
  %93 = tail call double @llvm.fma.f64(double %69, double %80, double %92) #3
  %94 = fadd double %91, %93
  %95 = fadd double %89, %94
  %96 = fsub double %95, %89
  %97 = fsub double %94, %96
  %98 = fmul double %95, %86
  %99 = fneg double %98
  %100 = tail call double @llvm.fma.f64(double %95, double %86, double %99) #3
  %101 = tail call double @llvm.fma.f64(double %97, double %86, double %100) #3
  %102 = fadd double %98, %101
  %103 = fsub double %102, %98
  %104 = fsub double %101, %103
  %105 = fadd double %87, %102
  %106 = fsub double %105, %87
  %107 = fsub double %105, %106
  %108 = fsub double %87, %107
  %109 = fsub double %102, %106
  %110 = fadd double %109, %108
  %111 = fadd double %88, %104
  %112 = fsub double %111, %88
  %113 = fsub double %111, %112
  %114 = fsub double %88, %113
  %115 = fsub double %104, %112
  %116 = fadd double %115, %114
  %117 = fadd double %111, %110
  %118 = fadd double %105, %117
  %119 = fsub double %118, %105
  %120 = fsub double %117, %119
  %121 = fadd double %116, %120
  %122 = fadd double %118, %121
  %123 = fsub double %122, %118
  %124 = fsub double %121, %123
  %125 = sitofp i32 %41 to double
  %126 = fmul double %122, 0x3FF71547652B82FE
  %127 = fneg double %126
  %128 = fmul double %122, 0x3C7777D0FFDA0D24
  br i1 %cmp19.i.i.i.i, label %fusion.side2, label %fusion.common1

fusion.side2:                                     ; preds = %decision.dispatch3
  %129 = insertelement <2 x double> undef, double %122, i32 0
  %130 = insertelement <2 x double> %129, double %124, i32 1
  %131 = insertelement <2 x double> undef, double %127, i32 0
  %132 = insertelement <2 x double> %131, double %128, i32 1
  %133 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %130, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %132) #3
  %134 = extractelement <2 x double> %133, i32 0
  %135 = extractelement <2 x double> %133, i32 1
  %136 = fadd double %134, %135
  %137 = fadd double %126, %136
  %138 = fsub double %137, %126
  %139 = fsub double %136, %138
  %140 = fadd double %137, %125
  %141 = fsub double %140, %125
  %142 = fsub double %141, %140
  %143 = fadd double %142, %125
  %144 = fsub double %137, %141
  %145 = fadd double %144, %143
  %146 = fadd double %139, %145
  %147 = fadd double %140, %146
  %148 = tail call double @llvm.fabs.f64(double %35) #4
  %149 = fcmp oeq double %148, 0x7FF0000000000000
  %150 = select i1 %149, double %35, double %147
  %151 = fcmp olt double %35, 0.000000e+00
  %152 = select i1 %151, double 0x7FF8000000000000, double %150
  %153 = fcmp oeq double %35, 0.000000e+00
  %154 = select i1 %153, double 0xFFF0000000000000, double %152
  %155 = fmul double %154, %154
  %156 = fmul double %155, 0x3EDBD077F856B461
  %157 = fsub double 0x3F78C25CB1F33D41, %156
  %158 = fmul double %155, 0x3F40AF40801BC234
  %159 = fadd double %158, 0x3FA89B8093A2295C
  %160 = fmul double %155, %157
  %161 = fmul double %155, %159
  %162 = fadd double %160, 0x3FCF140D06064BE5
  %163 = fadd double %161, 0x3FE570FCC3570002
  %164 = fmul double %155, %162
  %165 = fadd double %164, 0x3FE6B9F7A03E5CA5
  %166 = fmul double %154, %163
  %167 = fsub double %165, %166
  %168 = fmul double %155, 0x3F44ACEECE75B689
  %169 = fadd double %168, 0x3FB48180AD0CAC24
  %170 = fmul double %155, 0x3F8497E40449A14F
  %171 = fadd double %170, 0x3FD7722E0F8ACAA8
  %172 = fmul double %155, %169
  %173 = fmul double %155, %171
  %174 = fadd double %172, 0x3FED6593E87A041B
  %175 = fadd double %173, 1.000000e+00
  %176 = fmul double %154, %174
  %177 = fsub double %175, %176
  %178 = fmul double %sub.i.i.i, %177
  %179 = fdiv double %167, %178
  br label %fusion.common1

fusion.common1:                                   ; preds = %fusion.side2, %decision.dispatch3
  %180 = phi double [ poison, %decision.dispatch3 ], [ %179, %fusion.side2 ]
  br i1 %cmp19.i.i.i.i, label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, label %decision.dispatch6

decision.dispatch6:                               ; preds = %fusion.common1
  br i1 %33, label %merged.bb35, label %merged.bb36

if.else75.i.i.i.i:                                ; preds = %if.else17.i.i.i.i
  %mul77.i.i.i.i = fmul double %sub.i.i.i, 0x400921FB54442D18
  %div78.i.i.i.i = fdiv double 2.000000e+00, %mul77.i.i.i.i
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

cond.false7.i.i.i:                                ; preds = %if.end15.i.i
  %cmp.i6.i.i.i = fcmp ult double %arrayidx.val, 3.750000e-01
  br i1 %cmp.i6.i.i.i, label %if.else.i23.i.i.i, label %if.then.i21.i.i.i

if.then.i21.i.i.i:                                ; preds = %cond.false7.i.i.i
  %sub.i7.i.i.i = fadd double %arrayidx.val, -3.750000e-01
  %mul.i.i.i8.i.i.i = fmul double %sub.i7.i.i.i, %sub.i7.i.i.i
  %mul1.i.i.i9.i.i.i = fmul double %mul.i.i.i8.i.i.i, 0x402E3985AD07C11A
  %add.i.i.i10.i.i.i = fadd double %mul1.i.i.i9.i.i.i, 0xC03085ADC87F148C
  %mul5.i.i.i11.i.i.i = fmul double %mul.i.i.i8.i.i.i, 0x401BFCD2EDF5ACC4
  %181 = fsub double 0x40101FAA3F78B28E, %mul5.i.i.i11.i.i.i
  %mul10.i.i.i13.i.i.i = fmul double %mul.i.i.i8.i.i.i, %add.i.i.i10.i.i.i
  %mul12.i.i.i14.i.i.i = fmul double %mul.i.i.i8.i.i.i, %181
  %add15.i.i.i15.i.i.i = fadd double %mul10.i.i.i13.i.i.i, 0x400F06502EC2116F
  %add18.i.i.i16.i.i.i = fadd double %mul12.i.i.i14.i.i.i, 0x3FA32D6622EF65AB
  %mul20.i.i.i17.i.i.i = fmul double %sub.i7.i.i.i, %add15.i.i.i15.i.i.i
  %add23.i.i.i18.i.i.i = fadd double %add18.i.i.i16.i.i.i, %mul20.i.i.i17.i.i.i
  %mul1.i.i306.i.i.i.i = fmul double %mul.i.i.i8.i.i.i, 0x3FF9609F779C5E99
  %182 = fsub double 0x4023738A7902B742, %mul1.i.i306.i.i.i.i
  %mul5.i.i308.i.i.i.i = fmul double %mul.i.i.i8.i.i.i, 0x4005C97BEA6BDB5A
  %183 = fsub double 0x3FD3B07AFB10BC79, %mul5.i.i308.i.i.i.i
  %mul10.i.i310.i.i.i.i = fmul double %mul.i.i.i8.i.i.i, %182
  %mul12.i.i311.i.i.i.i = fmul double %mul.i.i.i8.i.i.i, %183
  %add15.i.i312.i.i.i.i = fadd double %mul10.i.i310.i.i.i.i, 0xC019669B84791897
  %add18.i.i313.i.i.i.i = fadd double %mul12.i.i311.i.i.i.i, 0x3FDC05F5C732E888
  %mul20.i.i314.i.i.i.i = fmul double %mul.i.i.i8.i.i.i, %add15.i.i312.i.i.i.i
  %add23.i.i315.i.i.i.i = fadd double %mul20.i.i314.i.i.i.i, 1.000000e+00
  %mul25.i.i316.i.i.i.i = fmul double %sub.i7.i.i.i, %add18.i.i313.i.i.i.i
  %add28.i.i317.i.i.i.i = fadd double %mul25.i.i316.i.i.i.i, %add23.i.i315.i.i.i.i
  %div.i20.i.i.i = fdiv double %add23.i.i.i18.i.i.i, %add28.i.i317.i.i.i.i
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else.i23.i.i.i:                                ; preds = %cond.false7.i.i.i
  %decision.interval6 = fcmp ult double %arrayidx.val, 1.250000e-01
  %184 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %arrayidx.val) #3
  %185 = add nsw i32 %184, -1
  %186 = tail call double @llvm.fabs.f64(double %arrayidx.val) #4
  %187 = fcmp oeq double %186, 0x7FF0000000000000
  %188 = select i1 %187, i32 2147483647, i32 %185
  %189 = fcmp oeq double %arrayidx.val, 0.000000e+00
  %190 = select i1 %189, i32 -2147483648, i32 %188
  %cmp19.i34.i.i.i = icmp slt i32 %190, -4
  %decision.value = select i1 %decision.interval6, i32 %190, i32 undef
  %191 = and i1 %decision.interval6, %cmp19.i34.i.i.i
  br i1 %191, label %if.else27.i41.i.i.i, label %decision.dispatch4, !decision.short_gate !6

decision.dispatch4:                               ; preds = %if.else.i23.i.i.i
  br i1 %decision.interval6, label %fusion.side6, label %fusion.side5

if.else27.i41.i.i.i:                              ; preds = %if.else.i23.i.i.i
  %cmp106.i.i.i.i = icmp sgt i32 %decision.value, -1025
  br i1 %cmp106.i.i.i.i, label %decision.dispatch2, label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, !decision.condition_prefix !6

decision.dispatch2:                               ; preds = %if.else27.i41.i.i.i
  %cmp62.i.i.i.i = icmp sgt i32 %decision.value, -65
  %merged.select = select i1 %cmp62.i.i.i.i, i32 -17, i32 -257
  %192 = icmp sgt i32 %decision.value, %merged.select
  %merged.select73 = select i1 %cmp62.i.i.i.i, i32 -9, i32 -129
  %merged.select74 = select i1 %cmp62.i.i.i.i, i32 -33, i32 -513
  %193 = select i1 %192, i32 %merged.select73, i32 %merged.select74
  %194 = icmp sgt i32 %decision.value, %193
  %merged.select75 = select i1 %cmp62.i.i.i.i, i32 4, i32 64
  %merged.select76 = select i1 %cmp62.i.i.i.i, i32 16, i32 256
  %195 = select i1 %192, i32 %merged.select75, i32 %merged.select76
  %merged.select77 = select i1 %cmp62.i.i.i.i, i32 8, i32 128
  %merged.select78 = select i1 %cmp62.i.i.i.i, i32 32, i32 512
  %196 = select i1 %192, i32 %merged.select77, i32 %merged.select78
  %197 = select i1 %194, i32 %195, i32 %196
  %198 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %197) #3
  %199 = tail call double @llvm.amdgcn.frexp.mant.f64(double %198) #3
  %200 = fcmp olt double %199, 0x3FE5555555555555
  %201 = zext i1 %200 to i32
  %202 = tail call double @llvm.amdgcn.ldexp.f64(double %199, i32 %201) #3
  %203 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %198) #3
  %204 = sub nsw i32 %203, %201
  %205 = fadd double %202, -1.000000e+00
  %206 = fadd double %202, 1.000000e+00
  %207 = fsub double %206, %202
  %208 = fsub double %206, %207
  %209 = fsub double %202, %208
  %210 = fsub double 1.000000e+00, %207
  %211 = fadd double %210, %209
  %212 = tail call double @llvm.amdgcn.rcp.f64(double %206) #3
  %213 = fneg double %206
  %214 = tail call double @llvm.fma.f64(double %213, double %212, double 1.000000e+00) #3
  %215 = tail call double @llvm.fma.f64(double %214, double %212, double %212) #3
  %216 = tail call double @llvm.fma.f64(double %213, double %215, double 1.000000e+00) #3
  %217 = tail call double @llvm.fma.f64(double %216, double %215, double %215) #3
  %218 = fmul double %205, %217
  %219 = fmul double %206, %218
  %220 = fneg double %219
  %221 = tail call double @llvm.fma.f64(double %218, double %206, double %220) #3
  %222 = tail call double @llvm.fma.f64(double %218, double %211, double %221) #3
  %223 = fadd double %219, %222
  %224 = fsub double %223, %219
  %225 = fsub double %222, %224
  %226 = fsub double %205, %223
  %227 = fsub double %205, %226
  %228 = fsub double %227, %223
  %229 = fsub double %228, %225
  %230 = fadd double %226, %229
  %231 = fmul double %217, %230
  %232 = fadd double %218, %231
  %233 = fsub double %232, %218
  %234 = fsub double %231, %233
  %235 = fmul double %232, %232
  %236 = fneg double %235
  %237 = tail call double @llvm.fma.f64(double %232, double %232, double %236) #3
  %238 = fmul double %234, 2.000000e+00
  %239 = tail call double @llvm.fma.f64(double %232, double %238, double %237) #3
  %240 = tail call double @llvm.fma.f64(double %234, double %234, double %239) #3
  %241 = fadd double %235, %240
  %242 = fsub double %241, %235
  %243 = fsub double %240, %242
  %244 = tail call double @llvm.fma.f64(double %241, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %245 = tail call double @llvm.fma.f64(double %241, double %244, double 0x3FC7474DD7F4DF2E) #3
  %246 = tail call double @llvm.fma.f64(double %241, double %245, double 0x3FCC71C016291751) #3
  %247 = tail call double @llvm.fma.f64(double %241, double %246, double 0x3FD249249B27ACF1) #3
  %248 = tail call double @llvm.fma.f64(double %241, double %247, double 0x3FD99999998EF7B6) #3
  %249 = tail call double @llvm.fma.f64(double %241, double %248, double 0x3FE5555555555780) #3
  %250 = tail call double @llvm.amdgcn.ldexp.f64(double %232, i32 1) #3
  %251 = tail call double @llvm.amdgcn.ldexp.f64(double %234, i32 1) #3
  %252 = fmul double %232, %241
  %253 = fneg double %252
  %254 = tail call double @llvm.fma.f64(double %232, double %241, double %253) #3
  %255 = fmul double %234, %241
  %256 = tail call double @llvm.fma.f64(double %232, double %243, double %255) #3
  %257 = fadd double %254, %256
  %258 = fadd double %252, %257
  %259 = fsub double %258, %252
  %260 = fsub double %257, %259
  %261 = fmul double %258, %249
  %262 = fneg double %261
  %263 = tail call double @llvm.fma.f64(double %258, double %249, double %262) #3
  %264 = tail call double @llvm.fma.f64(double %260, double %249, double %263) #3
  %265 = fadd double %261, %264
  %266 = fsub double %265, %261
  %267 = fsub double %264, %266
  %268 = fadd double %250, %265
  %269 = fsub double %268, %250
  %270 = fsub double %268, %269
  %271 = fsub double %250, %270
  %272 = fsub double %265, %269
  %273 = fadd double %272, %271
  %274 = fadd double %251, %267
  %275 = fsub double %274, %251
  %276 = fsub double %274, %275
  %277 = fsub double %251, %276
  %278 = fsub double %267, %275
  %279 = fadd double %278, %277
  %280 = fadd double %274, %273
  %281 = fadd double %268, %280
  %282 = fsub double %281, %268
  %283 = fsub double %280, %282
  %284 = fadd double %279, %283
  %285 = fadd double %281, %284
  %286 = fsub double %285, %281
  %287 = fsub double %284, %286
  %288 = fmul double %285, 0x3FF71547652B82FE
  %289 = fneg double %288
  %290 = fmul double %285, 0x3C7777D0FFDA0D24
  br i1 %194, label %merged.bb69, label %merged.bb71

fusion.side8:                                     ; preds = %decision.dispatch7
  %291 = fadd double %16, 0xC0ADEA3D7D257F67
  %292 = fmul double %13, 0x40A377E7779F4961
  %293 = fadd double %292, 0xC0A6DC23D7E5E636
  br label %fusion.common2

fusion.side9:                                     ; preds = %decision.dispatch7
  %294 = select i1 %11, double 0x404307CEA86A355B, double 0x404790211A5124A0
  %295 = fsub double %294, %16
  %296 = select i1 %11, double 0x4040C02F41527F9A, double 0x40127122E53E19ED
  br label %fusion.common2

fusion.common2:                                   ; preds = %fusion.side9, %fusion.side8
  %297 = phi double [ 0x40990C9A56964108, %fusion.side8 ], [ 0x4030441296C5FB34, %fusion.side9 ]
  %298 = phi double [ 0x409B9068A3C78607, %fusion.side8 ], [ 0x4003830831C63CF0, %fusion.side9 ]
  %299 = phi double [ poison, %fusion.side8 ], [ %295, %fusion.side9 ]
  %300 = phi double [ %293, %fusion.side8 ], [ poison, %fusion.side9 ]
  %fusion.paired = phi double [ %291, %fusion.side8 ], [ %296, %fusion.side9 ]
  %301 = fmul double %13, %fusion.paired
  %302 = select i1 %11, double 0xC043CD5B8EF4636A, double 0xBFF88D9974F43E7E
  %303 = fmul double %13, %300
  %304 = select i1 %decision.interval, double 0x407EB1E0C584548E, double %302
  %305 = fadd double %301, %304
  %306 = fmul double %13, %299
  %.op4 = fadd double %303, 0x4081F4137E2FB1C7
  %307 = fmul double %13, %305
  %308 = select i1 %11, double 0xC037479D2EDA47AB, double 0xC0321838C11B2DD4
  %309 = fadd double %306, %308
  %310 = select i1 %11, double 0x40158CCE32F91DD3, double 0xBFF1103F72ECFAA8
  %311 = select i1 %decision.interval, double 0x405A8654D41DC46C, double %310
  %312 = fadd double %307, %311
  %313 = select i1 %11, double 0x400468120D7EB3C7, double 0x3FF5040D3E43FC6C
  %.v5 = select i1 %decision.interval, double %.op4, double %309
  %314 = fmul double %13, %.v5
  %315 = select i1 %decision.interval, double 0x4016B9F7A03E5CA6, double %313
  %316 = fadd double %314, %315
  %317 = fmul double %12, %312
  %318 = fadd double %317, %316
  %319 = fmul double %13, %298
  %320 = fsub double %297, %319
  %321 = select i1 %11, double 0x40179A9AC0DA87EF, double 0x401D7BFF8CC54FA6
  %322 = select i1 %decision.interval, double 0x408105AF09F369D0, double %321
  %323 = fmul double %13, %322
  br i1 %decision.interval, label %fusion.side1, label %fusion.side7

fusion.side1:                                     ; preds = %fusion.common2
  %324 = fsub double 0x40912C23C604419C, %323
  br label %fusion.common16

fusion.side7:                                     ; preds = %fusion.common2
  %325 = select i1 %11, double 0xC03ABCE1630E61C0, double 0xC026402DD156D3FC
  %326 = fadd double %323, %325
  %327 = select i1 %11, double 0x4000D00D57F2CBBD, double %320
  %328 = fmul double %13, %327
  %329 = fadd double %328, 0xC0226B8874380C5B
  %330 = fadd double %328, 0xC031083D20CE0F89
  br label %fusion.common16

fusion.common16:                                  ; preds = %fusion.side7, %fusion.side1
  %331 = phi double [ 0x403AF5DBE51CBD80, %fusion.side1 ], [ 0x401E18FAC448D58A, %fusion.side7 ]
  %332 = phi double [ %324, %fusion.side1 ], [ %329, %fusion.side7 ]
  %333 = phi double [ poison, %fusion.side1 ], [ %330, %fusion.side7 ]
  %334 = phi double [ %320, %fusion.side1 ], [ %326, %fusion.side7 ]
  %335 = fmul double %13, %334
  %336 = fmul double %13, %332
  %337 = select i1 %11, double 0x402AF4FD59F9A777, double 0x3FF51C8655DB120C
  %338 = select i1 %decision.interval, double 0x4070760E04B9BCBD, double %337
  %339 = fadd double %335, %338
  %340 = fmul double %13, %333
  %341 = fadd double %336, %331
  %342 = fmul double %13, %339
  %.op8 = fadd double %340, 0x4012D71DC7267483
  %343 = select i1 %decision.interval, double poison, double %.op8
  %344 = fadd double %342, 1.000000e+00
  %345 = or i1 %decision.interval, %11
  %346 = select i1 %345, double %341, double %343
  %347 = fmul double %12, %346
  %348 = fadd double %344, %347
  %349 = fdiv double %318, %348
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

fusion.side5:                                     ; preds = %decision.dispatch4
  %350 = fcmp ult double %arrayidx.val, 2.500000e-01
  %351 = select i1 %350, double -1.250000e-01, double -2.500000e-01
  %352 = fadd double %arrayidx.val, %351
  %353 = fmul double %352, %352
  %354 = select i1 %350, double 0x4068E6DDCC41063F, double 0x40209BA0CA602AA9
  %355 = fmul double %353, %354
  %356 = select i1 %350, double 0xC0752AD202523CE5, double 0xC03AB74FA533B36E
  %357 = fadd double %355, %356
  %358 = select i1 %350, double 0x4080D1B58D04D9C9, double 0x40379E848D9E949D
  %359 = fmul double %353, %358
  %360 = select i1 %350, double 0x407CB1D75E0C4F58, double 0x4037940F708222AF
  %361 = fsub double %360, %359
  %362 = fmul double %353, %357
  %363 = select i1 %350, double %361, double %357
  %364 = fmul double %353, %363
  %365 = fadd double %362, 0x4069326C1159E9DB
  %366 = select i1 %350, double %365, double %361
  %367 = fmul double %353, %366
  %368 = select i1 %350, double 0xC024B04741F7A527, double 0x3FF47646B0F87946
  %369 = fadd double %367, %368
  %370 = select i1 %350, double 0xC024AD8FAE86A147, double 0x4032087237C73F8C
  %371 = fadd double %364, %370
  %372 = fmul double %353, %371
  %373 = select i1 %350, double 0xBFEC1147FADC1DD1, double 0xBFDABCA86BC1374B
  %374 = fadd double %372, %373
  %375 = fmul double %352, %369
  %376 = fadd double %375, %374
  %377 = select i1 %350, double 0x40705EDC8D95F7FC, double 0x40298D77C48BA327
  %378 = fmul double %353, %377
  %379 = select i1 %350, double 0xC06F965D272FAC7A, double 0xC0311C9898526451
  %380 = fadd double %378, %379
  %381 = select i1 %350, double 0x40686BB6228197AD, double 0x401AE4210EC8894B
  %382 = fmul double %353, %381
  %383 = select i1 %350, double 0x40530C7F6C363BB9, double 0x4002DB11078FC43E
  %384 = fsub double %383, %382
  %385 = fmul double %353, %380
  %386 = select i1 %350, double %384, double %380
  %387 = fmul double %353, %386
  %388 = fadd double %385, 0x405440452173DCA6
  %389 = select i1 %350, double %388, double %384
  %390 = fmul double %353, %389
  %391 = fadd double %390, 1.000000e+00
  %392 = select i1 %350, double 0x40306AF25EBB4DDE, double 0x40157F95E5CB1B22
  %393 = fadd double %387, %392
  %394 = fmul double %352, %393
  %395 = fadd double %391, %394
  br label %fusion.common3

fusion.side6:                                     ; preds = %decision.dispatch4
  %396 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 3) #3
  %397 = tail call double @llvm.amdgcn.frexp.mant.f64(double %396) #3
  %398 = fcmp olt double %397, 0x3FE5555555555555
  %399 = zext i1 %398 to i32
  %400 = tail call double @llvm.amdgcn.ldexp.f64(double %397, i32 %399) #3
  %401 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %396) #3
  %402 = sub nsw i32 %401, %399
  %403 = fadd double %400, -1.000000e+00
  %404 = fadd double %400, 1.000000e+00
  %405 = fsub double %404, %400
  %406 = fsub double %404, %405
  %407 = fsub double %400, %406
  %408 = fsub double 1.000000e+00, %405
  %409 = fadd double %408, %407
  %410 = tail call double @llvm.amdgcn.rcp.f64(double %404) #3
  %411 = fneg double %404
  %412 = tail call double @llvm.fma.f64(double %411, double %410, double 1.000000e+00) #3
  %413 = tail call double @llvm.fma.f64(double %412, double %410, double %410) #3
  %414 = tail call double @llvm.fma.f64(double %411, double %413, double 1.000000e+00) #3
  %415 = tail call double @llvm.fma.f64(double %414, double %413, double %413) #3
  %416 = fmul double %403, %415
  %417 = fmul double %404, %416
  %418 = fneg double %417
  %419 = tail call double @llvm.fma.f64(double %416, double %404, double %418) #3
  %420 = tail call double @llvm.fma.f64(double %416, double %409, double %419) #3
  %421 = fadd double %417, %420
  %422 = fsub double %421, %417
  %423 = fsub double %420, %422
  %424 = fsub double %403, %421
  %425 = fsub double %403, %424
  %426 = fsub double %425, %421
  %427 = fsub double %426, %423
  %428 = fadd double %424, %427
  %429 = fmul double %415, %428
  %430 = fadd double %416, %429
  %431 = fsub double %430, %416
  %432 = fsub double %429, %431
  %433 = fmul double %430, %430
  %434 = fneg double %433
  %435 = tail call double @llvm.fma.f64(double %430, double %430, double %434) #3
  %436 = fmul double %432, 2.000000e+00
  %437 = tail call double @llvm.fma.f64(double %430, double %436, double %435) #3
  %438 = tail call double @llvm.fma.f64(double %432, double %432, double %437) #3
  %439 = fadd double %433, %438
  %440 = fsub double %439, %433
  %441 = fsub double %438, %440
  %442 = tail call double @llvm.fma.f64(double %439, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %443 = tail call double @llvm.fma.f64(double %439, double %442, double 0x3FC7474DD7F4DF2E) #3
  %444 = tail call double @llvm.fma.f64(double %439, double %443, double 0x3FCC71C016291751) #3
  %445 = tail call double @llvm.fma.f64(double %439, double %444, double 0x3FD249249B27ACF1) #3
  %446 = tail call double @llvm.fma.f64(double %439, double %445, double 0x3FD99999998EF7B6) #3
  %447 = tail call double @llvm.fma.f64(double %439, double %446, double 0x3FE5555555555780) #3
  %448 = tail call double @llvm.amdgcn.ldexp.f64(double %430, i32 1) #3
  %449 = tail call double @llvm.amdgcn.ldexp.f64(double %432, i32 1) #3
  %450 = fmul double %430, %439
  %451 = fneg double %450
  %452 = tail call double @llvm.fma.f64(double %430, double %439, double %451) #3
  %453 = fmul double %432, %439
  %454 = tail call double @llvm.fma.f64(double %430, double %441, double %453) #3
  %455 = fadd double %452, %454
  %456 = fadd double %450, %455
  %457 = fsub double %456, %450
  %458 = fsub double %455, %457
  %459 = fmul double %456, %447
  %460 = fneg double %459
  %461 = tail call double @llvm.fma.f64(double %456, double %447, double %460) #3
  %462 = tail call double @llvm.fma.f64(double %458, double %447, double %461) #3
  %463 = fadd double %459, %462
  %464 = fsub double %463, %459
  %465 = fsub double %462, %464
  %466 = fadd double %448, %463
  %467 = fsub double %466, %448
  %468 = fsub double %466, %467
  %469 = fsub double %448, %468
  %470 = fsub double %463, %467
  %471 = fadd double %470, %469
  %472 = fadd double %449, %465
  %473 = fsub double %472, %449
  %474 = fsub double %472, %473
  %475 = fsub double %449, %474
  %476 = fsub double %465, %473
  %477 = fadd double %476, %475
  %478 = fadd double %472, %471
  %479 = fadd double %466, %478
  %480 = fsub double %479, %466
  %481 = fsub double %478, %480
  %482 = fadd double %477, %481
  %483 = fadd double %479, %482
  %484 = fsub double %483, %479
  %485 = fsub double %482, %484
  %486 = sitofp i32 %402 to double
  %487 = fmul double %483, 0x3FF71547652B82FE
  %488 = fneg double %487
  %489 = fmul double %483, 0x3C7777D0FFDA0D24
  %490 = insertelement <2 x double> undef, double %483, i32 0
  %491 = insertelement <2 x double> %490, double %485, i32 1
  %492 = insertelement <2 x double> undef, double %488, i32 0
  %493 = insertelement <2 x double> %492, double %489, i32 1
  %494 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %491, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %493) #3
  %495 = extractelement <2 x double> %494, i32 0
  %496 = extractelement <2 x double> %494, i32 1
  %497 = fadd double %495, %496
  %498 = fadd double %487, %497
  %499 = fsub double %498, %487
  %500 = fsub double %497, %499
  %501 = fadd double %498, %486
  %502 = fsub double %501, %486
  %503 = fsub double %502, %501
  %504 = fadd double %503, %486
  %505 = fsub double %498, %502
  %506 = fadd double %505, %504
  %507 = fadd double %500, %506
  %508 = fadd double %501, %507
  %509 = tail call double @llvm.fabs.f64(double %396) #4
  %510 = fcmp oeq double %509, 0x7FF0000000000000
  %511 = select i1 %510, double %396, double %508
  %512 = fcmp olt double %396, 0.000000e+00
  %513 = select i1 %512, double 0x7FF8000000000000, double %511
  %514 = fcmp oeq double %396, 0.000000e+00
  %515 = select i1 %514, double 0xFFF0000000000000, double %513
  %516 = fmul double %515, %515
  %517 = fmul double %516, 0x3F10728B75F46556
  %518 = fsub double 0xBFB1D997333851F3, %517
  %519 = fmul double %516, 0x3F713B96D78DC454
  %520 = fsub double 0xBFDBC9E8A9D4EBD0, %519
  %521 = fmul double %516, %518
  %522 = fmul double %516, %520
  %523 = fadd double %521, 0xBFF164811EDD50A9
  %524 = fadd double %522, 0xBFEC1147FADC1DD1
  %525 = fmul double %515, %523
  %526 = fsub double %524, %525
  %527 = fmul double %516, 0x3EEE329A0EE79745
  %528 = fadd double %527, 0x3F9F1FF0999DE692
  %529 = fmul double %516, 0x3F56CF90A3508EC2
  %530 = fadd double %529, 0x3FCFAFFF6FF925DC
  %531 = fmul double %516, %528
  %532 = fmul double %516, %530
  %533 = fadd double %531, 0x3FEAD689E3DCFB29
  %534 = fadd double %532, 1.000000e+00
  %535 = fmul double %515, %533
  %536 = fsub double %534, %535
  br label %fusion.common3

fusion.common3:                                   ; preds = %fusion.side6, %fusion.side5
  %fusion.paired7 = phi double [ %376, %fusion.side5 ], [ %526, %fusion.side6 ]
  %fusion.paired8 = phi double [ %395, %fusion.side5 ], [ %536, %fusion.side6 ]
  %537 = fdiv double %fusion.paired7, %fusion.paired8
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i: ; preds = %merged.bb70, %merged.bb37, %fusion.common3, %fusion.common16, %if.else27.i41.i.i.i, %if.then.i21.i.i.i, %if.else75.i.i.i.i, %fusion.common1
  %retval.0.i.i.i = phi double [ %180, %fusion.common1 ], [ %div78.i.i.i.i, %if.else75.i.i.i.i ], [ %div.i20.i.i.i, %if.then.i21.i.i.i ], [ 0xFFF0000000000000, %if.else27.i41.i.i.i ], [ %349, %fusion.common16 ], [ %537, %fusion.common3 ], [ %664, %merged.bb37 ], [ %725, %merged.bb70 ]
  %sub.i.i = fadd double %retval.0.i.i.i, 0.000000e+00
  br label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14promote_doubleILb0EEENS2_12domain_errorILNS2_17error_policy_typeE2EEENS2_14overflow_errorILS7_2EEENS2_14default_policyESB_SB_SB_SB_SB_SB_SB_SB_SB_EEEET_RKNS0_19landau_distributionISD_T0_EERKSD_.exit

_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14promote_doubleILb0EEENS2_12domain_errorILNS2_17error_policy_typeE2EEENS2_14overflow_errorILS7_2EEENS2_14default_policyESB_SB_SB_SB_SB_SB_SB_SB_SB_EEEET_RKNS0_19landau_distributionISD_T0_EERKSD_.exit: ; preds = %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, %lor.lhs.false2.i.i.i, %if.end9.i.i
  %retval.0.i.i = phi double [ 0x7FF8000000000000, %if.end9.i.i ], [ 0x7FF8000000000000, %lor.lhs.false2.i.i.i ], [ %sub.i.i, %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i ]
  %arrayidx712 = getelementptr inbounds double, double addrspace(1)* %output.coerce, i64 %idxprom
  store double %retval.0.i.i, double addrspace(1)* %arrayidx712, align 8, !tbaa !8
  br label %if.end

if.end:                                           ; preds = %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14promote_doubleILb0EEENS2_12domain_errorILNS2_17error_policy_typeE2EEENS2_14overflow_errorILS7_2EEENS2_14default_policyESB_SB_SB_SB_SB_SB_SB_SB_SB_EEEET_RKNS0_19landau_distributionISD_T0_EERKSD_.exit, %entry
  ret void

merged.bb35:                                      ; preds = %decision.dispatch6
  %538 = insertelement <2 x double> undef, double %122, i32 0
  %539 = insertelement <2 x double> %538, double %124, i32 1
  %540 = insertelement <2 x double> undef, double %127, i32 0
  %541 = insertelement <2 x double> %540, double %128, i32 1
  %542 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %539, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %541) #3
  %543 = extractelement <2 x double> %542, i32 0
  %544 = extractelement <2 x double> %542, i32 1
  br label %merged.bb37

merged.bb36:                                      ; preds = %decision.dispatch6
  %545 = insertelement <2 x double> undef, double %122, i32 0
  %546 = insertelement <2 x double> %545, double %124, i32 1
  %547 = insertelement <2 x double> undef, double %127, i32 0
  %548 = insertelement <2 x double> %547, double %128, i32 1
  %549 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %546, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %548) #3
  %550 = extractelement <2 x double> %549, i32 0
  %551 = extractelement <2 x double> %549, i32 1
  br label %merged.bb37

merged.bb37:                                      ; preds = %merged.bb36, %merged.bb35
  %552 = phi double [ %544, %merged.bb35 ], [ %551, %merged.bb36 ]
  %553 = phi double [ %543, %merged.bb35 ], [ %550, %merged.bb36 ]
  %554 = phi double [ 0x3E5572883C081004, %merged.bb35 ], [ 0x3DFAC4B4389CCCBF, %merged.bb36 ]
  %555 = phi double [ 0x3EF19780C67DB179, %merged.bb35 ], [ 0x3EA390F0E916846C, %merged.bb36 ]
  %556 = phi double [ 0x3EAD6D38A29E7848, %merged.bb35 ], [ 0x3E3DBF605CEF30C0, %merged.bb36 ]
  %557 = phi double [ 0x3F3931D0B31857FC, %merged.bb35 ], [ 0x3EF49382D31EBA5E, %merged.bb36 ]
  %558 = phi double [ 0x3F6DC47CA5637DCD, %merged.bb35 ], [ 0x3F391B9374A4479C, %merged.bb36 ]
  %559 = phi double [ 0x3F9D4AC2F9914DE6, %merged.bb35 ], [ 0x3F756FF813B95713, %merged.bb36 ]
  %560 = phi double [ 0x3FC0EDB6A0343FA2, %merged.bb35 ], [ 0x3FA7D057D85283A0, %merged.bb36 ]
  %561 = phi double [ 0x3FDB50BA04B5A380, %merged.bb35 ], [ 0x3FD02ACAC9630F2A, %merged.bb36 ]
  %562 = phi double [ 0x3FE698C26DDFFE1D, %merged.bb35 ], [ 0x3FE4BE220CFACC02, %merged.bb36 ]
  %563 = phi double [ 0x3E5DE5C0706A9406, %merged.bb35 ], [ 0x3E04EA9B9D5ED2D3, %merged.bb36 ]
  %564 = phi double [ 0x3F004FBC687921D1, %merged.bb35 ], [ 0x3EAF46C18AB8D809, %merged.bb36 ]
  %565 = phi double [ 0x3EB3C06C21CA66A9, %merged.bb35 ], [ 0x3E46A463B527030B, %merged.bb36 ]
  %566 = phi double [ 0x3F41E908A5D59DEF, %merged.bb35 ], [ 0x3EFFDAE904854CF0, %merged.bb36 ]
  %567 = phi double [ 0x3F78B07BF251DF23, %merged.bb35 ], [ 0x3F43F5B84727219B, %merged.bb36 ]
  %568 = phi double [ 0x3FA6C0CF25D026FF, %merged.bb35 ], [ 0x3F80B3A886D078D5, %merged.bb36 ]
  %569 = phi double [ 0x3FCB01CF712825D2, %merged.bb35 ], [ 0x3FB2BDAF5E161D54, %merged.bb36 ]
  %570 = phi double [ 0x3FE41A23912FC356, %merged.bb35 ], [ 0x3FD98FFFB01689E6, %merged.bb36 ]
  %571 = phi double [ 0x3DE864F7A333A155, %merged.bb35 ], [ 0x3E36A0C73E300E6B, %merged.bb36 ]
  %572 = phi double [ 0x3E9EABE0F5513556, %merged.bb35 ], [ 0x3EC7DFD742A8FC88, %merged.bb36 ]
  %573 = phi double [ 0x3F2EDE27BF6E2989, %merged.bb35 ], [ 0x3F46894B5AD794D5, %merged.bb36 ]
  %574 = phi double [ 0x3FA0CC4805CE702A, %merged.bb35 ], [ 0x3FAC2661E760FEEA, %merged.bb36 ]
  %575 = phi double [ 0x3FE460008BE31186, %merged.bb35 ], [ 0x3FE45F306F7BD51E, %merged.bb36 ]
  %576 = phi double [ 0x3DF328AAD4028837, %merged.bb35 ], [ 0x3E41C5A32EBEB036, %merged.bb36 ]
  %577 = phi double [ 0x3EA816907A00ED43, %merged.bb35 ], [ 0x3ED2C03A84AD3954, %merged.bb36 ]
  %578 = phi double [ 0x3E53EB10DB8936AA, %merged.bb35 ], [ 0x3E842875EC14B32B, %merged.bb36 ]
  %579 = phi double [ 0x3EF409E2C6442ECB, %merged.bb35 ], [ 0x3F1404C590EDED62, %merged.bb36 ]
  %580 = phi double [ 0x3F383DD0A4891FC2, %merged.bb35 ], [ 0x3F51B33174D75BD6, %merged.bb36 ]
  %581 = phi double [ 0x3F75579E42D43198, %merged.bb35 ], [ 0x3F8752E2DAA7BC3C, %merged.bb36 ]
  %582 = phi double [ 0x3FAA6202C31DEDAF, %merged.bb35 ], [ 0x3FB61BE1285F7AC2, %merged.bb36 ]
  %583 = phi double [ 0x3FD4C357E0FB8D40, %merged.bb35 ], [ 0x3FDAF9DE32D5716C, %merged.bb36 ]
  %584 = fadd double %553, %552
  %585 = fadd double %126, %584
  %586 = fsub double %585, %126
  %587 = fsub double %584, %586
  %588 = fadd double %585, %125
  %589 = fsub double %588, %125
  %590 = fsub double %589, %588
  %591 = fadd double %590, %125
  %592 = fsub double %585, %589
  %593 = fadd double %592, %591
  %594 = fadd double %587, %593
  %595 = fadd double %588, %594
  %596 = tail call double @llvm.fabs.f64(double %35) #4
  %597 = fcmp oeq double %596, 0x7FF0000000000000
  %598 = select i1 %597, double %35, double %595
  %599 = fcmp olt double %35, 0.000000e+00
  %600 = select i1 %599, double 0x7FF8000000000000, double %598
  %601 = fcmp oeq double %35, 0.000000e+00
  %602 = select i1 %601, double 0xFFF0000000000000, double %600
  %603 = fmul double %602, %602
  %604 = select i1 %32, double %554, double 0x3C79498433579691
  %605 = fmul double %603, %604
  %606 = select i1 %32, double %555, double 0x3E495C1E8002A2F3
  %607 = fsub double %606, %605
  %608 = select i1 %32, double %556, double %571
  %609 = fmul double %603, %608
  %610 = select i1 %32, double %557, double %572
  %611 = fadd double %609, %610
  %612 = select i1 %33, double %607, double 0x3E79AA80A6F64859
  %613 = fmul double %603, %612
  %614 = fadd double %613, 0x3F097D0FE1D7D8F2
  %615 = select i1 %32, double %607, double %611
  %616 = fmul double %603, %615
  %.op = fadd double %613, 0x3EE98327A9C0F60B
  %617 = select i1 %32, double %611, double %614
  %618 = fmul double %603, %617
  %619 = select i1 %32, double %558, double %573
  %620 = fadd double %616, %619
  %621 = fmul double %603, %.op
  %622 = select i1 %32, double %559, double 0x3F7DB25E4C9E7FD4
  %623 = fadd double %618, %622
  %624 = fmul double %603, %620
  %.op1 = fadd double %621, 0x3F6B2BC23526CCD2
  %625 = fmul double %603, %623
  %626 = select i1 %32, double %560, double %574
  %627 = fadd double %624, %626
  %628 = fmul double %603, %.op1
  %629 = select i1 %32, double %561, double 0x3FD12C697DF74133
  %630 = fadd double %625, %629
  %631 = fmul double %603, %627
  %.op2 = fadd double %628, 0x3FCA6EBA13EF1190
  %632 = select i1 %32, double poison, double %.op2
  %633 = select i1 %32, double %562, double %575
  %634 = fadd double %631, %633
  %635 = select i1 %33, double %632, double %630
  %636 = select i1 %32, double %630, double %635
  %637 = fmul double %602, %636
  %638 = fsub double %634, %637
  %639 = select i1 %32, double %563, double %576
  %640 = fmul double %603, %639
  %641 = fsub double %564, %640
  %642 = fadd double %640, %577
  %fusion.paired22 = select i1 %32, double %641, double %642
  %643 = select i1 %32, double %565, double %578
  %644 = fmul double %603, %643
  %645 = select i1 %32, double %566, double %579
  %646 = fadd double %644, %645
  %647 = fmul double %603, %fusion.paired22
  %648 = fmul double %603, %646
  %649 = select i1 %32, double %567, double %580
  %650 = fadd double %647, %649
  %651 = select i1 %32, double %568, double %581
  %652 = fadd double %648, %651
  %653 = fmul double %603, %650
  %654 = fmul double %603, %652
  %655 = select i1 %32, double %569, double %582
  %656 = fadd double %653, %655
  %657 = select i1 %32, double %570, double %583
  %658 = fadd double %654, %657
  %659 = fmul double %603, %656
  %660 = fadd double %659, 1.000000e+00
  %661 = fmul double %602, %658
  %662 = fsub double %660, %661
  %663 = fmul double %sub.i.i.i, %662
  %664 = fdiv double %638, %663
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

merged.bb70:                                      ; preds = %merged.branch.split80, %merged.bb72
  %merged.select99 = phi double [ %769, %merged.bb72 ], [ %797, %merged.branch.split80 ]
  %merged.select98 = phi double [ %768, %merged.bb72 ], [ %796, %merged.branch.split80 ]
  %merged.select97 = phi double [ %767, %merged.bb72 ], [ %795, %merged.branch.split80 ]
  %merged.select96 = phi double [ %766, %merged.bb72 ], [ %794, %merged.branch.split80 ]
  %merged.select95 = phi double [ %765, %merged.bb72 ], [ %793, %merged.branch.split80 ]
  %merged.select94 = phi double [ %764, %merged.bb72 ], [ %792, %merged.branch.split80 ]
  %merged.select93 = phi double [ %763, %merged.bb72 ], [ %791, %merged.branch.split80 ]
  %merged.select92 = phi double [ %762, %merged.bb72 ], [ %790, %merged.branch.split80 ]
  %merged.select91 = phi double [ %761, %merged.bb72 ], [ %789, %merged.branch.split80 ]
  %merged.select90 = phi double [ %760, %merged.bb72 ], [ %788, %merged.branch.split80 ]
  %merged.select89 = phi double [ %759, %merged.bb72 ], [ %787, %merged.branch.split80 ]
  %merged.select88 = phi double [ %758, %merged.bb72 ], [ %786, %merged.branch.split80 ]
  %merged.select87 = phi double [ %757, %merged.bb72 ], [ %785, %merged.branch.split80 ]
  %merged.select86 = phi double [ %756, %merged.bb72 ], [ %784, %merged.branch.split80 ]
  %merged.select124 = phi double [ %755, %merged.bb72 ], [ %783, %merged.branch.split80 ]
  %merged.select123 = phi double [ %754, %merged.bb72 ], [ %782, %merged.branch.split80 ]
  %merged.select122 = phi double [ %753, %merged.bb72 ], [ %781, %merged.branch.split80 ]
  %merged.select121 = phi double [ %752, %merged.bb72 ], [ %780, %merged.branch.split80 ]
  %merged.select120 = phi double [ %751, %merged.bb72 ], [ %779, %merged.branch.split80 ]
  %merged.select119 = phi double [ %750, %merged.bb72 ], [ %778, %merged.branch.split80 ]
  %merged.select118 = phi double [ %749, %merged.bb72 ], [ %777, %merged.branch.split80 ]
  %merged.select117 = phi double [ %748, %merged.bb72 ], [ %776, %merged.branch.split80 ]
  %merged.select116 = phi double [ %747, %merged.bb72 ], [ %775, %merged.branch.split80 ]
  %merged.select115 = phi double [ %746, %merged.bb72 ], [ %774, %merged.branch.split80 ]
  %merged.select114 = phi double [ %745, %merged.bb72 ], [ %773, %merged.branch.split80 ]
  %merged.select113 = phi double [ %744, %merged.bb72 ], [ %772, %merged.branch.split80 ]
  %merged.select112 = phi double [ %743, %merged.bb72 ], [ %771, %merged.branch.split80 ]
  %merged.select111 = phi double [ %742, %merged.bb72 ], [ %770, %merged.branch.split80 ]
  %merged.select104 = sitofp i32 %204 to double
  %665 = fadd double %740, %741
  %666 = fadd double %288, %665
  %667 = fsub double %666, %288
  %668 = fsub double %665, %667
  %669 = fadd double %666, %merged.select104
  %670 = fsub double %669, %merged.select104
  %671 = fsub double %670, %669
  %672 = fadd double %671, %merged.select104
  %673 = fsub double %666, %670
  %674 = fadd double %673, %672
  %675 = fadd double %668, %674
  %676 = fadd double %669, %675
  %677 = tail call double @llvm.fabs.f64(double %198) #4
  %678 = fcmp oeq double %677, 0x7FF0000000000000
  %679 = select i1 %678, double %198, double %676
  %680 = fcmp olt double %198, 0.000000e+00
  %681 = select i1 %680, double 0x7FF8000000000000, double %679
  %682 = fcmp oeq double %198, 0.000000e+00
  %683 = select i1 %682, double 0xFFF0000000000000, double %681
  %684 = fmul double %683, %683
  %685 = select i1 %192, double %merged.select86, double %merged.select111
  %686 = fmul double %684, %685
  %687 = select i1 %192, double %merged.select87, double %merged.select112
  %688 = fsub double %687, %686
  %689 = select i1 %192, double %merged.select88, double %merged.select113
  %690 = fmul double %684, %689
  %691 = select i1 %192, double %merged.select89, double %merged.select114
  %692 = fsub double %691, %690
  %693 = fmul double %684, %688
  %694 = fmul double %684, %692
  %695 = select i1 %192, double %merged.select90, double %merged.select115
  %696 = fadd double %693, %695
  %697 = select i1 %192, double %merged.select91, double %merged.select116
  %698 = fadd double %694, %697
  %699 = fmul double %684, %696
  %700 = fmul double %684, %698
  %701 = select i1 %192, double %merged.select92, double %merged.select117
  %702 = fadd double %699, %701
  %703 = select i1 %192, double %merged.select93, double %merged.select118
  %704 = fadd double %700, %703
  %705 = fmul double %683, %702
  %706 = fsub double %704, %705
  %707 = select i1 %192, double %merged.select94, double %merged.select119
  %708 = fmul double %684, %707
  %709 = select i1 %192, double %merged.select95, double %merged.select120
  %710 = fadd double %708, %709
  %711 = select i1 %192, double %merged.select96, double %merged.select121
  %712 = fmul double %684, %711
  %713 = select i1 %192, double %merged.select97, double %merged.select122
  %714 = fadd double %712, %713
  %715 = fmul double %684, %710
  %716 = fmul double %684, %714
  %717 = select i1 %192, double %merged.select98, double %merged.select123
  %718 = fadd double %715, %717
  %719 = select i1 %192, double %merged.select99, double %merged.select124
  %720 = fadd double %716, %719
  %721 = fmul double %684, %718
  %722 = fadd double %721, 1.000000e+00
  %723 = fmul double %683, %720
  %724 = fsub double %722, %723
  %725 = fdiv double %706, %724
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

merged.bb69:                                      ; preds = %decision.dispatch2
  %726 = insertelement <2 x double> undef, double %285, i32 0
  %727 = insertelement <2 x double> %726, double %287, i32 1
  %728 = insertelement <2 x double> undef, double %289, i32 0
  %729 = insertelement <2 x double> %728, double %290, i32 1
  %730 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %727, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %729) #3
  %731 = extractelement <2 x double> %730, i32 0
  %732 = extractelement <2 x double> %730, i32 1
  br label %merged.bb72

merged.bb71:                                      ; preds = %decision.dispatch2
  %733 = insertelement <2 x double> undef, double %285, i32 0
  %734 = insertelement <2 x double> %733, double %287, i32 1
  %735 = insertelement <2 x double> undef, double %289, i32 0
  %736 = insertelement <2 x double> %735, double %290, i32 1
  %737 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %734, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %736) #3
  %738 = extractelement <2 x double> %737, i32 0
  %739 = extractelement <2 x double> %737, i32 1
  br label %merged.bb72

merged.bb72:                                      ; preds = %merged.bb71, %merged.bb69
  %740 = phi double [ %731, %merged.bb69 ], [ %738, %merged.bb71 ]
  %741 = phi double [ %732, %merged.bb69 ], [ %739, %merged.bb71 ]
  %742 = phi double [ 0x3D2EEF3A19525962, %merged.bb69 ], [ 0x3CBD95F745F985C6, %merged.bb71 ]
  %743 = phi double [ 0xBE8B5F843E1F3895, %merged.bb69 ], [ 0xBE3D53C778BDFF24, %merged.bb71 ]
  %744 = phi double [ 0x3E015340F5605AFB, %merged.bb69 ], [ 0x3DA2170560574A27, %merged.bb71 ]
  %745 = phi double [ 0xBEFB16A0F7496BD2, %merged.bb69 ], [ 0xBEBDB51233A64720, %merged.bb71 ]
  %746 = phi double [ 0xBF5751B27C5C9BFB, %merged.bb69 ], [ 0xBF2A2DC3D4DAE3C5, %merged.bb71 ]
  %747 = phi double [ 0xBFA370C135EBE2E0, %merged.bb69 ], [ 0xBF865CF2B86753CE, %merged.bb71 ]
  %748 = phi double [ 0xBFDED3DE58969B0C, %merged.bb69 ], [ 0xBFD232BB27D90F0B, %merged.bb71 ]
  %749 = phi double [ 0xC002991536F3B198, %merged.bb69 ], [ 0xC00695E2D61C0C6E, %merged.bb71 ]
  %750 = phi double [ 0x3DDA87308BB58726, %merged.bb69 ], [ 0x3D7985F69E9DFA4C, %merged.bb71 ]
  %751 = phi double [ 0x3EDDEB134B240B6B, %merged.bb69 ], [ 0x3E9D26DA9BE0FF59, %merged.bb71 ]
  %752 = phi double [ 0x3E6A03AD8C7D561F, %merged.bb69 ], [ 0x3E192F9212752578, %merged.bb71 ]
  %753 = phi double [ 0x3F3D2E4291C2C2D0, %merged.bb69 ], [ 0x3F0C9E4DE67437CE, %merged.bb71 ]
  %754 = phi double [ 0x3F8B35517DD09962, %merged.bb69 ], [ 0x3F6ADBBA962C2080, %merged.bb71 ]
  %755 = phi double [ 0x3FC7F5B66495DDB6, %merged.bb69 ], [ 0x3FB7CE42A74538CD, %merged.bb71 ]
  %756 = phi double [ 0x3E10954573CD1409, %merged.bb69 ], [ 0x3DA028AD2F8C812A, %merged.bb71 ]
  %757 = phi double [ 0xBF267FDAD7E340C0, %merged.bb69 ], [ 0xBED9332B494FD162, %merged.bb71 ]
  %758 = phi double [ 0x3EBE74EDE276BA2A, %merged.bb69 ], [ 0x3E6073196B230E1D, %merged.bb71 ]
  %759 = phi double [ 0xBF74D4DF73958DD4, %merged.bb69 ], [ 0xBF383759EF2EC40C, %merged.bb71 ]
  %760 = phi double [ 0xBFB0A4004AB9FA2F, %merged.bb69 ], [ 0xBF843505D28DAEAC, %merged.bb71 ]
  %761 = phi double [ 0xBFD95EAC9AE91EB0, %merged.bb69 ], [ 0xBFC045854783A19F, %merged.bb71 ]
  %762 = phi double [ 0xBFF1F8D8D4096576, %merged.bb69 ], [ 0xBFE8CAFD8375357B, %merged.bb71 ]
  %763 = phi double [ 0xBFF2AD2669F16A11, %merged.bb69 ], [ 0xBFFC8922BA24935C, %merged.bb71 ]
  %764 = phi double [ 0x3E9C1C977F10265B, %merged.bb69 ], [ 0x3E3B89766DC0E470, %merged.bb71 ]
  %765 = phi double [ 0x3F5F07E1D05A5DFD, %merged.bb69 ], [ 0x3F1EA8AD4669BB53, %merged.bb71 ]
  %766 = phi double [ 0x3F0B438FF2C388C0, %merged.bb69 ], [ 0x3EBAD46BFAE07B75, %merged.bb71 ]
  %767 = phi double [ 0x3F9DF8C6DBF0F003, %merged.bb69 ], [ 0x3F6DB7207E85C0EF, %merged.bb71 ]
  %768 = phi double [ 0x3FCBB079F2C252E4, %merged.bb69 ], [ 0x3FAB895727F039DB, %merged.bb71 ]
  %769 = phi double [ 0x3FE82B2F4B11BB5A, %merged.bb69 ], [ 0x3FD81A505016D302, %merged.bb71 ]
  %770 = phi double [ 0x3B6B104CE845D8CA, %merged.bb69 ], [ 0x3AFAA825FA80AEBC, %merged.bb71 ]
  %771 = phi double [ 0xBD51A9A584540197, %merged.bb69 ], [ 0xBD02C12978DF0869, %merged.bb71 ]
  %772 = phi double [ 0x3C84A9C31CF1706D, %merged.bb69 ], [ 0x3C25ADBF5D5E2D40, %merged.bb71 ]
  %773 = phi double [ 0xBE02B6DCAE997177, %merged.bb69 ], [ 0xBDC40F84D4D29208, %merged.bb71 ]
  %774 = phi double [ 0xBEA134E225D1132C, %merged.bb69 ], [ 0xBE729A0FDD66F4F2, %merged.bb71 ]
  %775 = phi double [ 0xBF2EA5E4F352FCF9, %merged.bb69 ], [ 0xBF10B2EEE9D945FC, %merged.bb71 ]
  %776 = phi double [ 0xBFAA00AF73AD4FC4, %merged.bb69 ], [ 0xBF9C8D7861FA32DF, %merged.bb71 ]
  %777 = phi double [ 0xC010D5424AFC6707, %merged.bb69 ], [ 0xC0129EFFBA10F842, %merged.bb71 ]
  %778 = phi double [ 0x3C579C2A1977500A, %merged.bb69 ], [ 0x3BF74C460513871A, %merged.bb71 ]
  %779 = phi double [ 0x3DDBA32CD8E6FFE2, %merged.bb69 ], [ 0x3D9B6269284AABC4, %merged.bb71 ]
  %780 = phi double [ 0x3D27942AF0BDEC40, %merged.bb69 ], [ 0x3CD7504574599FA7, %merged.bb71 ]
  %781 = phi double [ 0x3E7B7CAE58B9ECC4, %merged.bb69 ], [ 0x3E4B4BB19F333FF9, %merged.bb71 ]
  %782 = phi double [ 0x3F0A244903F50D45, %merged.bb69 ], [ 0x3EEA04DE23809639, %merged.bb71 ]
  %783 = phi double [ 0x3F877C1A4ABB8039, %merged.bb69 ], [ 0x3F776DDB0ABF64AF, %merged.bb71 ]
  %784 = phi double [ 0x3C4C7C5BAC69CA30, %merged.bb69 ], [ 0x3BDBA8610FC6ED80, %merged.bb71 ]
  %785 = phi double [ 0xBDEF4147E6D836F1, %merged.bb69 ], [ 0xBDA09F2D7C5D35C1, %merged.bb71 ]
  %786 = phi double [ 0x3D42DFCD4EC1917B, %merged.bb69 ], [ 0x3CE3BA542B23A837, %merged.bb71 ]
  %787 = phi double [ 0xBE80201FEE58D5EB, %merged.bb69 ], [ 0xBE4167CB2DE9484D, %merged.bb71 ]
  %788 = phi double [ 0xBEFCEEB9D33660E7, %merged.bb69 ], [ 0xBECFA9C0D9C5E4A9, %merged.bb71 ]
  %789 = phi double [ 0xBF69297448457D24, %merged.bb69 ], [ 0xBF4BE8F64D9A4925, %merged.bb71 ]
  %790 = phi double [ 0xBFC4DA929BC925CB, %merged.bb69 ], [ 0xBFB77177F6F25868, %merged.bb71 ]
  %791 = phi double [ 0xC00A6041983C62F2, %merged.bb69 ], [ 0xC00E0DA8FADB7C8C, %merged.bb71 ]
  %792 = phi double [ 0x3D18B1987155CEA4, %merged.bb69 ], [ 0x3CB8106C9C12C679, %merged.bb71 ]
  %793 = phi double [ 0x3E5C80E1BF396002, %merged.bb69 ], [ 0x3E1C00B930B6EDE4, %merged.bb71 ]
  %794 = phi double [ 0x3DC87E4D72BFB8FA, %merged.bb69 ], [ 0x3D77F69D5EF2EF55, %merged.bb71 ]
  %795 = phi double [ 0x3EDC231F3DEEB6F9, %merged.bb69 ], [ 0x3EABC3297454E377, %merged.bb71 ]
  %796 = phi double [ 0x3F4A8E38348FD9B2, %merged.bb69 ], [ 0x3F2A514E711D09AD, %merged.bb71 ]
  %797 = phi double [ 0x3FA7ABC63BB9671C, %merged.bb69 ], [ 0x3F97906FA7E2C9CF, %merged.bb71 ]
  br i1 %cmp62.i.i.i.i, label %merged.bb70, label %merged.branch.split80

merged.branch.split80:                            ; preds = %merged.bb72
  br label %merged.bb70
}

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.frexp.mant.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.ldexp.f64(double, i32) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.frexp.exp.i32.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rcp.f64(double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fma.v2f64(<2 x double>, <2 x double>, <2 x double>) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #1

attributes #0 = { convergent norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="128" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nounwind readnone speculatable willreturn }
attributes #2 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }
attributes #4 = { nounwind readnone }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/charitha22/cgo22ae-darm-code.git e9bc0540325ad9806313d34e84fc901496fd8be6)"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i16 1, i16 1025}
!6 = !{}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
