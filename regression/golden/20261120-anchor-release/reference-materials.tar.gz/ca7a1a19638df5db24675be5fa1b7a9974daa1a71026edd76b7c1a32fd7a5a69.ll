; ModuleID = '/data/home/chh/simplify-v2/build/b2b-layouts/anchor-ablation/heldout/SasPoint5/active/trial-76/fused.ll'
source_filename = "/data/home/chh/simplify-v2/cases/boost-saspoint5/source/kernel.cu"
target datalayout = "e-i64:64-i128:128-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P = internal local_unnamed_addr addrspace(4) constant [13 x double] [double 0x3FE45F306DC9C883, double 0x406B28D28834A1D2, double 0x40E10B4A1F6CF501, double 0x4149F72088DFB4E6, double 0x41AA2A2B1216B605, double 0x4201FEA8BB3BE600, double 0x4250E9DB94569883, double 0x4295367142D96C3E, double 0x42D0C7351C0FE465, double 0x42FDF1537961E7A8, double 0x4318FADA1D9742AD, double 0x431A6A62BB63A40C, double 0x42F7DD4E00E3184B], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q = internal local_unnamed_addr addrspace(4) constant [15 x double] [double 1.000000e+00, double 0x407554BBE33DF6D0, double 0x40EACD56D4D9BE96, double 0x415478A3A36859F4, double 0x41B4BEC095014516, double 0x420CDB326777C2EB, double 0x425BBC435F07A940, double 0x42A2357E7C0D108C, double 0x42DFC3D0B52A82F3, double 0x43119515C0126E89, double 0x4337006916401BF8, double 0x434F8D8E245D5F98, double 0x4352307314019A4E, double 0x433A78AB06FBD9E7, double 0x42F4F252E8C6C233], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FDBE1FDB85FCBFC, double 0x401C7FC4A4CD29B7, double 0x40441F91A172918F, double 0x40569F495083FE32, double 0x4052E785C1291E6C, double 0x402963DA5E858427, double 0xBFE51906626836E2], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x4033DCC50DCD8254, double 0x40631B677D5BB29F, double 0x4081D5A7BC4B586A, double 0x4090A232759E33CF, double 0x408C89486705C083, double 0x40702DF59FC94A86], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 = internal local_unnamed_addr addrspace(4) constant [8 x double] [double 0x3FD2EBDAE01A865A, double 0x4001E701431550F3, double 0x40140D55A266563C, double 0x40061BEABB9D2FFC, double 0x3FBE3E1608F6B264, double 0x3F948267DD4FFC5C, double 0xBF7EE20D1DA304B5, double 0x3F567E8E10E805D5], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 = internal local_unnamed_addr addrspace(4) constant [6 x double] [double 1.000000e+00, double 0x4024936FD6337035, double 0x4043419A7FE0209B, double 0x404EEC78CE96F318, double 0x4042DAE171B23F0E, double 0x4015ACB627173EB5], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FC5DB8AD965E90E, double 0x3FEAFCABC850EDD7, double 0x3FF65A44B7FDD998, double 0x3FEC06E8946EFB9F, double 0x3FC7D5630E234B35, double 0x3F7E240887A8C893, double 0xBF1B2EC29D8B2658], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x401AEF3DDBD087CA, double 0x40316DCC2BF05060, double 0x40359825CD283464, double 0x4029F6B804AEAD76, double 0x400B41AF064F350F, double 0x3FD1EF45AB10745B], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FB60B1E33F10647, double 0x3FC5B8636B0E3222, double 0x3FBC07DA7811D486, double 0x3F9C536ADCBF4A28, double 0x3F6411736D26FD34, double 0x3F057CF6442FA06A, double 0xBE91AFF35CC657D0], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x4008539DEC96056A, double 0x400C3466C3C7D450, double 0x3FFF2AD31AA58662, double 0x3FE0C440E94F34C7, double 0x3FAFB74D5C9C7495, double 0x3F62EDB894F212E5], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3FA40A885E63F440, double 0x3FA4D8C2969E1484, double 0x3F8D5B4999760A8F, double 0x3F608452D391BA63, double 0x3F1A625FB47B3E5D, double 0x3EAFEDB5AFBF2767, double 0xBE2EA1B19268350A], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FFA3986886A7224, double 0x3FF09C23C029EA8F, double 0x3FD45C79F4902790, double 0x3FA8ACC143771083, double 0x3F6AA8DFF46DC0A1, double 0x3F126489EF16E3AC], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F90E6E15AE0A0B5, double 0x3F807EC586F8D6C3, double 0x3F5628C3995B9895, double 0x3F1815313F095300, double 0x3EC2BE8138C05760, double 0x3E46283600C31343, double 0xBDB56E517F96664C], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FE9EC7342A94DF8, double 0x3FD0446895858090, double 0x3FA3D20C0F793A99, double 0x3F67F69AED3331A7, double 0x3F19EDB2C6FDDBA7, double 0x3EB1F9FE5CE35DD4], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F7B09124BFF3246, double 0x3F5A1B509F6E6B7F, double 0x3F215B9A853FE1BC, double 0x3ED2AE3619D566E9, double 0x3E6CCC5CC17E6081, double 0x3DE0CED483645917, double 0xBD405E2A41165B21], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FDA44C156520F4B, double 0x3FB0B03579A0DD2F, double 0x3F74916FEE749C77, double 0x3F2921C431130861, double 0x3ECB75120A3FA3A9, double 0x3E5333ECBD8F94A3], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F64D5E29688B048, double 0x3F34521A788CC925, double 0x3EEB47C2C7618FAD, double 0x3E8D9FBD4F84DAEB, double 0x3E17053C44720DE3, double 0x3D7B01444FBF3B93, double 0xBCCAC1BB5B2D869C], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FCAC72D2F36E816, double 0x3F91595000B0EB93, double 0x3F45CFDE78902384, double 0x3EEB30C9CE3272DE, double 0x3E7E4D79F7AC44EB, double 0x3DF59B56446B4334], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 0x3F4F4BD6E99FF4E5, double 0x3F0EBAD7DF31FFFC, double 0x3EB4C3314DF7C43F, double 0x3E46AFD495CB1DD4, double 0x3DC1BAD3548A0AB8, double 0x3D14DED0BB7A816C, double 0xBC54EF99AFF7380B], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 = internal local_unnamed_addr addrspace(4) constant [7 x double] [double 1.000000e+00, double 0x3FBB218F9E698485, double 0x3F71D0F3147D5FAB, double 0x3F16B5EB6E086EA2, double 0x3EACB59E1205CC30, double 0x3E303913316A148C, double 0x3D9774482B0EAD22], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 0x3FC9884533D43651, double 0xBF93CB8214E9986F, double 0xBF814A78F15CF4A7, double 0x3F6C735355393978, double 0xBF3A917333BAF05A], align 8
@_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 1.000000e+00, double 0x3FE66E5F74B0D81B, double 0x3FD116080081EF83, double 0x3FAC405BB896DD07, double 0x3F7AA11B83649D74], align 8

; Function Attrs: nofree norecurse nounwind willreturn
define dso_local void @evaluate(double* nocapture readonly %0, double* nocapture %1, i32 %2) local_unnamed_addr #0 {
  %4 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #3, !range !5
  %5 = tail call i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #3, !range !6
  %6 = mul i32 %5, %4
  %7 = tail call i32 @llvm.nvvm.read.ptx.sreg.tid.x() #3, !range !7
  %8 = add i32 %6, %7
  %9 = icmp slt i32 %8, %2
  br i1 %9, label %10, label %350

10:                                               ; preds = %3
  %11 = sext i32 %8 to i64
  %12 = getelementptr inbounds double, double* %0, i64 %11
  %13 = load double, double* %12, align 8, !tbaa !8
  %14 = fcmp ord double %13, 0.000000e+00
  %15 = fcmp ule double %13, 0x7FEFFFFFFFFFFFFF
  %16 = fcmp uge double %13, 0xFFEFFFFFFFFFFFFF
  %17 = and i1 %15, %16
  %18 = and i1 %14, %17
  br i1 %18, label %19, label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

19:                                               ; preds = %10
  %20 = tail call double @llvm.fabs.f64(double %13) #3
  %21 = fcmp olt double %20, 2.500000e-01
  br i1 %21, label %decision.dispatch1, label %47, !decision.condition_prefix !12

decision.dispatch1:                               ; preds = %19
  %22 = fcmp olt double %20, 1.250000e-01
  %23 = fadd double %20, -1.250000e-01
  %24 = select i1 %22, double %13, double %23
  %25 = fmul double %24, %24
  %26 = select i1 %22, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 12), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 6)
  %27 = load double, double* %26, align 8, !tbaa !8
  %28 = fmul double %25, %27
  %29 = select i1 %22, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 10), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 4)
  %30 = load double, double* %29, align 8, !tbaa !8
  %31 = fadd double %28, %30
  %32 = select i1 %22, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 11), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 5)
  %33 = load double, double* %32, align 8, !tbaa !8
  %34 = fmul double %25, %33
  %35 = select i1 %22, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 9), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 3)
  %36 = load double, double* %35, align 8, !tbaa !8
  %37 = fadd double %34, %36
  %38 = fmul double %25, %31
  %39 = fmul double %25, %37
  %40 = select i1 %22, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 8), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 2)
  %41 = load double, double* %40, align 8, !tbaa !8
  %42 = fadd double %38, %41
  %43 = select i1 %22, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 7), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 1)
  %44 = load double, double* %43, align 8, !tbaa !8
  %45 = fadd double %39, %44
  %46 = fmul double %25, %42
  br i1 %22, label %fusion.side2, label %fusion.common1

47:                                               ; preds = %19
  %48 = fcmp olt double %20, 8.000000e+00
  br i1 %48, label %decision.dispatch4, label %108, !decision.condition_prefix !12

decision.dispatch4:                               ; preds = %47
  %49 = fcmp olt double %20, 5.000000e-01
  %50 = fcmp olt double %20, 2.000000e+00
  %51 = select i1 %50, double 1.000000e+00, double 4.000000e+00
  %52 = fcmp olt double %20, %51
  %53 = freeze i1 %52
  %54 = select i1 %50, double -5.000000e-01, double -2.000000e+00
  %55 = select i1 %50, double -1.000000e+00, double -4.000000e+00
  %56 = select i1 %53, double %54, double %55
  %57 = select i1 %49, i1 poison, i1 %50
  %58 = select i1 %49, double -2.500000e-01, double %56
  %59 = fadd double %20, %58
  %60 = fmul double %59, %59
  %61 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 6), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 6)
  %62 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 6), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 6)
  %63 = select i1 %53, double* %61, double* %62
  %64 = select i1 %49, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 7), double* %63
  %65 = load double, double* %64, align 8, !tbaa !8
  %66 = fmul double %60, %65
  %67 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 4), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 4)
  %68 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 4), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 4)
  %69 = select i1 %53, double* %67, double* %68
  %70 = select i1 %49, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 5), double* %69
  %71 = load double, double* %70, align 8, !tbaa !8
  %72 = fadd double %66, %71
  %73 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 5), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 5)
  %74 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 5), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 5)
  %75 = select i1 %53, double* %73, double* %74
  %76 = select i1 %49, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 6), double* %75
  %77 = load double, double* %76, align 8, !tbaa !8
  %78 = fmul double %60, %77
  %79 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 3), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 3)
  %80 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 3), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 3)
  %81 = select i1 %53, double* %79, double* %80
  %82 = select i1 %49, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 4), double* %81
  %83 = load double, double* %82, align 8, !tbaa !8
  %84 = fadd double %78, %83
  %85 = fmul double %60, %72
  %86 = fmul double %60, %84
  %87 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 2), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 2)
  %88 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 2), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 2)
  %89 = select i1 %53, double* %87, double* %88
  %90 = select i1 %49, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 3), double* %89
  %91 = load double, double* %90, align 8, !tbaa !8
  %92 = fadd double %85, %91
  %93 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 1), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 1)
  %94 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 1), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 1)
  %95 = select i1 %53, double* %93, double* %94
  %96 = select i1 %49, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 2), double* %95
  %97 = load double, double* %96, align 8, !tbaa !8
  %98 = fadd double %86, %97
  %99 = fmul double %60, %92
  %100 = select i1 %49, double %60, double %59
  %101 = fmul double %100, %98
  %102 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_2 to [7 x double]*), i64 0, i64 0), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_4 to [7 x double]*), i64 0, i64 0)
  %103 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_3 to [7 x double]*), i64 0, i64 0), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_5 to [7 x double]*), i64 0, i64 0)
  %104 = select i1 %53, double* %102, double* %103
  %105 = select i1 %49, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 1), double* %104
  %106 = load double, double* %105, align 8, !tbaa !8
  %107 = fadd double %99, %106
  br i1 %49, label %fusion.side1, label %fusion.side3

108:                                              ; preds = %47
  %109 = fcmp olt double %20, 6.400000e+01
  br i1 %109, label %decision.dispatch3, label %129, !decision.condition_prefix !12

decision.dispatch:                                ; preds = %decision.dispatch3
  %110 = fcmp olt double %20, 1.600000e+01
  %111 = freeze i1 %110
  %112 = select i1 %111, double -8.000000e+00, double -1.600000e+01
  %113 = select i1 %111, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 6), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 6)
  %114 = select i1 %111, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 4), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 4)
  %115 = select i1 %111, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 5), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 5)
  %116 = select i1 %111, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 3), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 3)
  %117 = select i1 %111, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 2), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 2)
  %118 = select i1 %111, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 1), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 1)
  %119 = select i1 %111, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_6 to [7 x double]*), i64 0, i64 0), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_7 to [7 x double]*), i64 0, i64 0)
  %120 = select i1 %111, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 6), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 6)
  %121 = select i1 %111, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 4), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 4)
  %122 = select i1 %111, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 5), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 5)
  %123 = select i1 %111, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 3), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 3)
  %124 = select i1 %111, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 2), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 2)
  %125 = select i1 %111, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 1), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 1)
  %126 = select i1 %111, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_6 to [7 x double]*), i64 0, i64 0), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_7 to [7 x double]*), i64 0, i64 0)
  br label %fusion.suffix1

decision.dispatch3:                               ; preds = %108
  %127 = fcmp olt double %20, 3.200000e+01
  br i1 %127, label %decision.dispatch, label %128, !decision.merged_from !13, !decision.origin !14

128:                                              ; preds = %decision.dispatch3
  br label %fusion.suffix1

129:                                              ; preds = %108
  %130 = tail call double @llvm.sqrt.f64(double %20) #3
  %131 = fdiv double 1.000000e+00, %130
  %132 = fmul double %131, %131
  %133 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %134 = fmul double %132, %133
  %135 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %136 = fadd double %134, %135
  %137 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %138 = fmul double %132, %137
  %139 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %140 = fadd double %138, %139
  %141 = fmul double %132, %136
  %142 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_9 to [5 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %143 = fadd double %141, %142
  %144 = fmul double %131, %140
  %145 = fadd double %143, %144
  %146 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %147 = fmul double %132, %146
  %148 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %149 = fadd double %147, %148
  %150 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %151 = fmul double %132, %150
  %152 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %153 = fadd double %151, %152
  %154 = fmul double %132, %149
  %155 = load double, double* getelementptr ([5 x double], [5 x double]* addrspacecast ([5 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_9 to [5 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %156 = fadd double %154, %155
  %157 = fmul double %131, %153
  %158 = fadd double %156, %157
  %159 = fdiv double %145, %158
  %160 = fmul double %131, %159
  %161 = fdiv double %160, %20
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

fusion.side2:                                     ; preds = %decision.dispatch1
  %162 = fmul double %25, %45
  %163 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %164 = fadd double %46, %163
  %165 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %166 = fadd double %162, %165
  %167 = fmul double %25, %164
  %168 = fmul double %25, %166
  %169 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %170 = fadd double %167, %169
  %171 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %172 = fadd double %168, %171
  %173 = fmul double %25, %170
  %174 = fmul double %25, %172
  %175 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %176 = fadd double %173, %175
  %177 = load double, double* getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %178 = fadd double %174, %177
  %179 = fmul double %25, %176
  br label %fusion.common1

fusion.common1:                                   ; preds = %fusion.side2, %decision.dispatch1
  %180 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 1), %decision.dispatch1 ], [ getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 9), %fusion.side2 ]
  %181 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 2), %decision.dispatch1 ], [ getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 10), %fusion.side2 ]
  %182 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 3), %decision.dispatch1 ], [ getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 11), %fusion.side2 ]
  %183 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 5), %decision.dispatch1 ], [ getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 13), %fusion.side2 ]
  %184 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 4), %decision.dispatch1 ], [ getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 12), %fusion.side2 ]
  %185 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 6), %decision.dispatch1 ], [ getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 14), %fusion.side2 ]
  %186 = phi double [ %45, %decision.dispatch1 ], [ %178, %fusion.side2 ]
  %187 = phi double [ %23, %decision.dispatch1 ], [ %20, %fusion.side2 ]
  %188 = phi double [ %46, %decision.dispatch1 ], [ %179, %fusion.side2 ]
  %189 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_0 to [7 x double]*), i64 0, i64 0), %decision.dispatch1 ], [ getelementptr ([13 x double], [13 x double]* addrspacecast ([13 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P to [13 x double]*), i64 0, i64 0), %fusion.side2 ]
  %190 = load double, double* %189, align 8, !tbaa !8
  %191 = fadd double %188, %190
  %192 = fmul double %187, %186
  %193 = fadd double %191, %192
  %194 = load double, double* %185, align 8, !tbaa !8
  %195 = fmul double %25, %194
  %196 = load double, double* %184, align 8, !tbaa !8
  %197 = fadd double %195, %196
  %198 = load double, double* %183, align 8, !tbaa !8
  %199 = fmul double %25, %198
  %200 = load double, double* %182, align 8, !tbaa !8
  %201 = fadd double %199, %200
  %202 = fmul double %25, %197
  %203 = fmul double %25, %201
  %204 = load double, double* %181, align 8, !tbaa !8
  %205 = fadd double %202, %204
  %206 = load double, double* %180, align 8, !tbaa !8
  %207 = fadd double %203, %206
  %208 = fmul double %25, %205
  br i1 %22, label %fusion.side4, label %fusion.common3

fusion.side4:                                     ; preds = %fusion.common1
  %209 = fmul double %25, %207
  %210 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 8), align 8, !tbaa !8
  %211 = fadd double %208, %210
  %212 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 7), align 8, !tbaa !8
  %213 = fadd double %209, %212
  %214 = fmul double %25, %211
  %215 = fmul double %25, %213
  %216 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 6), align 8, !tbaa !8
  %217 = fadd double %214, %216
  %218 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 5), align 8, !tbaa !8
  %219 = fadd double %215, %218
  %220 = fmul double %25, %217
  %221 = fmul double %25, %219
  %222 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 4), align 8, !tbaa !8
  %223 = fadd double %220, %222
  %224 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 3), align 8, !tbaa !8
  %225 = fadd double %221, %224
  %226 = fmul double %25, %223
  %227 = fmul double %25, %225
  %228 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 2), align 8, !tbaa !8
  %229 = fadd double %226, %228
  %230 = load double, double* getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 1), align 8, !tbaa !8
  %231 = fadd double %227, %230
  %232 = fmul double %25, %229
  br label %fusion.common3

fusion.common3:                                   ; preds = %fusion.side4, %fusion.common1
  %233 = phi double [ %207, %fusion.common1 ], [ %231, %fusion.side4 ]
  %234 = phi double [ %208, %fusion.common1 ], [ %232, %fusion.side4 ]
  %235 = phi double* [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_0 to [7 x double]*), i64 0, i64 0), %fusion.common1 ], [ getelementptr ([15 x double], [15 x double]* addrspacecast ([15 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q to [15 x double]*), i64 0, i64 0), %fusion.side4 ]
  %236 = load double, double* %235, align 8, !tbaa !8
  %237 = fadd double %234, %236
  %238 = fmul double %187, %233
  %239 = fadd double %237, %238
  %240 = fdiv double %193, %239
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

fusion.suffix1:                                   ; preds = %128, %decision.dispatch
  %241 = phi double* [ %113, %decision.dispatch ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 6), %128 ]
  %242 = phi double* [ %114, %decision.dispatch ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 4), %128 ]
  %243 = phi double* [ %115, %decision.dispatch ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 5), %128 ]
  %244 = phi double* [ %116, %decision.dispatch ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 3), %128 ]
  %245 = phi double* [ %117, %decision.dispatch ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 2), %128 ]
  %246 = phi double* [ %118, %decision.dispatch ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 1), %128 ]
  %247 = phi double* [ %119, %decision.dispatch ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_8 to [7 x double]*), i64 0, i64 0), %128 ]
  %248 = phi double* [ %122, %decision.dispatch ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 5), %128 ]
  %249 = phi double* [ %123, %decision.dispatch ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 3), %128 ]
  %250 = phi double* [ %125, %decision.dispatch ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 1), %128 ]
  %251 = phi double* [ %126, %decision.dispatch ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 0), %128 ]
  %.in = phi double* [ %124, %decision.dispatch ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 2), %128 ]
  %.in1 = phi double* [ %121, %decision.dispatch ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 4), %128 ]
  %.in2 = phi double* [ %120, %decision.dispatch ], [ getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_8 to [7 x double]*), i64 0, i64 6), %128 ]
  %252 = phi double [ %112, %decision.dispatch ], [ -3.200000e+01, %128 ]
  %253 = load double, double* %.in2, align 8, !tbaa !8
  %254 = load double, double* %.in1, align 8, !tbaa !8
  %255 = load double, double* %.in, align 8, !tbaa !8
  %256 = fadd double %20, %252
  %257 = fmul double %256, %256
  %258 = fmul double %257, %253
  %259 = fadd double %258, %254
  %260 = fmul double %257, %259
  %261 = fadd double %260, %255
  %262 = load double, double* %241, align 8, !tbaa !8
  %263 = load double, double* %242, align 8, !tbaa !8
  %264 = load double, double* %243, align 8, !tbaa !8
  %265 = load double, double* %244, align 8, !tbaa !8
  %266 = load double, double* %245, align 8, !tbaa !8
  %267 = load double, double* %246, align 8, !tbaa !8
  %268 = load double, double* %247, align 8, !tbaa !8
  %269 = load double, double* %248, align 8, !tbaa !8
  %270 = load double, double* %249, align 8, !tbaa !8
  %271 = load double, double* %250, align 8, !tbaa !8
  %272 = load double, double* %251, align 8, !tbaa !8
  %273 = fmul double %257, %262
  %274 = fadd double %273, %263
  %275 = fmul double %257, %264
  %276 = fadd double %275, %265
  %277 = fmul double %257, %274
  %278 = fmul double %257, %276
  %279 = fadd double %277, %266
  %280 = fadd double %278, %267
  %281 = fmul double %257, %279
  %282 = fadd double %281, %268
  %283 = fmul double %256, %280
  %284 = fadd double %282, %283
  %285 = fmul double %257, %269
  %286 = fadd double %285, %270
  %287 = fmul double %257, %286
  %288 = fadd double %287, %271
  %289 = fmul double %257, %261
  %290 = fadd double %289, %272
  %291 = fmul double %256, %288
  %292 = fadd double %290, %291
  %293 = fdiv double %284, %292
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

fusion.side1:                                     ; preds = %decision.dispatch4
  %294 = load double, double* getelementptr ([8 x double], [8 x double]* addrspacecast ([8 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1P_1 to [8 x double]*), i64 0, i64 0), align 8, !tbaa !8
  %295 = fadd double %101, %294
  %296 = fmul double %59, %107
  %297 = load double, double* getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 4), align 8, !tbaa !8
  br label %fusion.suffix2

fusion.side3:                                     ; preds = %decision.dispatch4
  %298 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 6), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 6)
  %299 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 6), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 6)
  %300 = select i1 %53, double* %298, double* %299
  %301 = load double, double* %300, align 8, !tbaa !8
  %302 = fmul double %60, %301
  %303 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 4), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 4)
  %304 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 4), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 4)
  %305 = select i1 %53, double* %303, double* %304
  %306 = load double, double* %305, align 8, !tbaa !8
  %307 = fadd double %302, %306
  %308 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 5), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 5)
  %309 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 5), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 5)
  %310 = select i1 %53, double* %308, double* %309
  %311 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 3), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 3)
  %312 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 3), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 3)
  %313 = select i1 %53, double* %311, double* %312
  %314 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 2), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 2)
  %315 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 2), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 2)
  %316 = select i1 %53, double* %314, double* %315
  %317 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 1), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 1)
  %318 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 1), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 1)
  %319 = select i1 %53, double* %317, double* %318
  %320 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_2 to [7 x double]*), i64 0, i64 0), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_4 to [7 x double]*), i64 0, i64 0)
  %321 = select i1 %57, double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_3 to [7 x double]*), i64 0, i64 0), double* getelementptr ([7 x double], [7 x double]* addrspacecast ([7 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_5 to [7 x double]*), i64 0, i64 0)
  %322 = select i1 %53, double* %320, double* %321
  br label %fusion.suffix2

fusion.suffix2:                                   ; preds = %fusion.side3, %fusion.side1
  %323 = phi double [ %296, %fusion.side1 ], [ %107, %fusion.side3 ]
  %324 = phi double [ %295, %fusion.side1 ], [ %101, %fusion.side3 ]
  %325 = phi double* [ getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 5), %fusion.side1 ], [ %310, %fusion.side3 ]
  %326 = phi double* [ getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 3), %fusion.side1 ], [ %313, %fusion.side3 ]
  %327 = phi double* [ getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 1), %fusion.side1 ], [ %319, %fusion.side3 ]
  %328 = phi double* [ getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 0), %fusion.side1 ], [ %322, %fusion.side3 ]
  %.in11 = phi double* [ getelementptr ([6 x double], [6 x double]* addrspacecast ([6 x double] addrspace(4)* @_ZZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EEE1Q_1 to [6 x double]*), i64 0, i64 2), %fusion.side1 ], [ %316, %fusion.side3 ]
  %329 = phi double [ %297, %fusion.side1 ], [ %307, %fusion.side3 ]
  %330 = load double, double* %.in11, align 8, !tbaa !8
  %331 = fmul double %60, %329
  %332 = fadd double %331, %330
  %333 = load double, double* %325, align 8, !tbaa !8
  %334 = load double, double* %326, align 8, !tbaa !8
  %335 = load double, double* %327, align 8, !tbaa !8
  %336 = fadd double %323, %324
  %337 = fmul double %60, %333
  %338 = fadd double %337, %334
  %339 = fmul double %60, %338
  %340 = fadd double %339, %335
  %fusion.paired = fmul double %60, %332
  %341 = load double, double* %328, align 8, !tbaa !8
  %342 = fadd double %fusion.paired, %341
  %343 = fmul double %59, %340
  %344 = select i1 %49, double %343, double %342
  %345 = select i1 %49, double %342, double %343
  %346 = fadd double %344, %345
  %347 = fdiv double %336, %346
  br label %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit

_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit: ; preds = %fusion.suffix2, %fusion.suffix1, %fusion.common3, %129, %10
  %348 = phi double [ 0x7FF8000000000000, %10 ], [ %161, %129 ], [ %240, %fusion.common3 ], [ %293, %fusion.suffix1 ], [ %347, %fusion.suffix2 ]
  %349 = getelementptr inbounds double, double* %1, i64 %11
  store double %348, double* %349, align 8, !tbaa !8
  br label %350

350:                                              ; preds = %_ZN5boost4math6detail27saspoint5_pdf_plus_imp_precIdEET_RKS3_RKSt17integral_constantIiLi53EE.exit, %3
  ret void
}

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #1

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.ntid.x() #1

; Function Attrs: nounwind readnone
declare i32 @llvm.nvvm.read.ptx.sreg.tid.x() #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.sqrt.f64(double) #2

attributes #0 = { nofree norecurse nounwind willreturn "disable-tail-calls"="false" "frame-pointer"="all" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="sm_70" "target-features"="+ptx32,+sm_70" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nounwind readnone }
attributes #2 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!nvvm.annotations = !{!0}
!llvm.module.flags = !{!1, !2}
!llvm.ident = !{!3, !4}

!0 = !{void (double*, double*, i32)* @evaluate, !"kernel", i32 1}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 4, !"nvvm-reflect-ftz", i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 3.8.0 (tags/RELEASE_380/final)"}
!5 = !{i32 0, i32 2147483647}
!6 = !{i32 1, i32 1025}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = !{}
!13 = !{!"evaluate:%decision.dispatch", !"evaluate:%245"}
!14 = !{!"merge(evaluate:%decision.dispatch,evaluate:%245)"}
