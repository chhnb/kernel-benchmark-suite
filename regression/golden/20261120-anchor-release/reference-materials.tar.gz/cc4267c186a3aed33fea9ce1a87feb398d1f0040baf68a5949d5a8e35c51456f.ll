; ModuleID = '/data/home/chh/simplify-v2/build/b2b-layouts/anchor-ablation/heldout/Landau/active/trial-336/fused.ll'
source_filename = "/home/chh/divergence-strategy-search/explorations/partition-darm-rocm-20261025/boost/generated/landau-mask0/kernel.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @evaluate(double addrspace(1)* nocapture readonly %input.coerce, double addrspace(1)* nocapture %output.coerce, i32 %n) local_unnamed_addr #0 {
entry:
  %0 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %1 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %2 = getelementptr i8, i8 addrspace(4)* %1, i64 4
  %3 = bitcast i8 addrspace(4)* %2 to i16 addrspace(4)*
  %4 = load i16, i16 addrspace(4)* %3, align 4, !range !5, !invariant.load !6
  %5 = zext i16 %4 to i32
  %6 = mul i32 %0, %5
  %7 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !7
  %add = add i32 %6, %7
  %cmp = icmp slt i32 %add, %n
  br i1 %cmp, label %if.end9.i.i, label %if.end

if.end9.i.i:                                      ; preds = %entry
  %idxprom = sext i32 %add to i64
  %arrayidx11 = getelementptr inbounds double, double addrspace(1)* %input.coerce, i64 %idxprom
  %arrayidx.val = load double, double addrspace(1)* %arrayidx11, align 8, !tbaa !8
  %cmp.i4.i.i = fcmp olt double %arrayidx.val, 0.000000e+00
  %cmp1.i.i.i = fcmp ogt double %arrayidx.val, 1.000000e+00
  %or.cond.i.i.i = or i1 %cmp.i4.i.i, %cmp1.i.i.i
  br i1 %or.cond.i.i.i, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14promote_doubleILb0EEENS2_12domain_errorILNS2_17error_policy_typeE2EEENS2_14overflow_errorILS7_2EEENS2_14default_policyESB_SB_SB_SB_SB_SB_SB_SB_SB_EEEET_RKNS0_19landau_distributionISD_T0_EERKSD_.exit, label %lor.lhs.false2.i.i.i

lor.lhs.false2.i.i.i:                             ; preds = %if.end9.i.i
  %cmp.i.i.i.i.i = fcmp uno double %arrayidx.val, 0.000000e+00
  %cmp.i3.i.i.i.i = fcmp ogt double %arrayidx.val, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i.i.i = fcmp olt double %arrayidx.val, 0xFFEFFFFFFFFFFFFF
  %lnot.i.i.i.i.not = or i1 %cmp.i3.i.i.i.i, %cmp1.i.i.i.i.i
  %brmerge = or i1 %cmp.i.i.i.i.i, %lnot.i.i.i.i.not
  br i1 %brmerge, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14promote_doubleILb0EEENS2_12domain_errorILNS2_17error_policy_typeE2EEENS2_14overflow_errorILS7_2EEENS2_14default_policyESB_SB_SB_SB_SB_SB_SB_SB_SB_EEEET_RKNS0_19landau_distributionISD_T0_EERKSD_.exit, label %if.end15.i.i

if.end15.i.i:                                     ; preds = %lor.lhs.false2.i.i.i
  %cmp.i.i.i = fcmp ogt double %arrayidx.val, 5.000000e-01
  br i1 %cmp.i.i.i, label %if.then.i.i.i, label %cond.false7.i.i.i

if.then.i.i.i:                                    ; preds = %if.end15.i.i
  %sub.i.i.i = fsub double 1.000000e+00, %arrayidx.val
  %decision.interval5 = fcmp ult double %sub.i.i.i, 1.250000e-01
  br i1 %decision.interval5, label %if.else17.i.i.i.i, label %decision.dispatch4, !decision.condition_prefix !6

decision.dispatch4:                               ; preds = %if.then.i.i.i
  %decision.interval = fcmp ult double %sub.i.i.i, 2.500000e-01
  %8 = fcmp ult double %sub.i.i.i, 3.750000e-01
  %9 = select i1 %8, double -2.500000e-01, double -3.750000e-01
  %10 = select i1 %decision.interval, i1 poison, i1 %8
  %11 = select i1 %decision.interval, double -1.250000e-01, double %9
  %12 = fadd double %sub.i.i.i, %11
  %13 = fmul double %12, %12
  %14 = select i1 %10, double 0x4040C02F41527F9A, double 0x40127122E53E19ED
  %15 = select i1 %decision.interval, double 0x4094388834A6E4C6, double %14
  %16 = fmul double %13, %15
  %17 = select i1 %10, double 0x404307CEA86A355B, double 0x404790211A5124A0
  %18 = select i1 %10, double 0x40277F82F0DAE120, double 0x403C1881A9A265FD
  %19 = fmul double %13, %18
  %20 = fsub double %17, %19
  %21 = select i1 %10, double 0xC043CD5B8EF4636A, double 0xBFF88D9974F43E7E
  %22 = select i1 %decision.interval, double 0xC0ADEA3D7D257F67, double %21
  %23 = fadd double %16, %22
  %24 = select i1 %decision.interval, double 0x40A377E7779F4961, double %20
  %25 = fmul double %13, %24
  %26 = fmul double %13, %23
  %27 = select i1 %10, double 0xC037479D2EDA47AB, double 0xC0321838C11B2DD4
  %28 = select i1 %decision.interval, double 0xC0A6DC23D7E5E636, double %27
  %29 = fadd double %25, %28
  %30 = fmul double %13, %29
  %31 = select i1 %10, double 0x40158CCE32F91DD3, double 0xBFF1103F72ECFAA8
  %32 = select i1 %decision.interval, double 0x407EB1E0C584548E, double %31
  %33 = fadd double %26, %32
  %34 = select i1 %10, double 0x400468120D7EB3C7, double 0x3FF5040D3E43FC6C
  %35 = select i1 %decision.interval, double 0x4081F4137E2FB1C7, double %34
  %36 = fadd double %30, %35
  %37 = select i1 %decision.interval, double %13, double %12
  %38 = fmul double %37, %33
  %39 = select i1 %10, double 0x40179A9AC0DA87EF, double 0x4003830831C63CF0
  %40 = select i1 %decision.interval, double %36, double %39
  %41 = fmul double %13, %40
  %42 = select i1 %decision.interval, double 0x4016B9F7A03E5CA6, double 0xC03ABCE1630E61C0
  %43 = fadd double %41, %42
  br i1 %decision.interval, label %fusion.side4, label %fusion.side6

if.else17.i.i.i.i:                                ; preds = %if.then.i.i.i
  %44 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %sub.i.i.i) #3
  %45 = add nsw i32 %44, -1
  %46 = fcmp uno double %sub.i.i.i, 0.000000e+00
  %47 = tail call double @llvm.fabs.f64(double %sub.i.i.i) #4
  %48 = fcmp oeq double %47, 0x7FF0000000000000
  %49 = or i1 %46, %48
  %50 = select i1 %49, i32 2147483647, i32 %45
  %51 = fcmp oeq double %sub.i.i.i, 0.000000e+00
  %52 = select i1 %51, i32 -2147483648, i32 %50
  %.off = add i32 %52, 64
  %53 = icmp ugt i32 %.off, 59
  br i1 %53, label %leaf.union, label %decision.dispatch2, !fusion.logical.arm !12

leaf.union:                                       ; preds = %if.else17.i.i.i.i
  %cmp19.i.i.i.i = icmp sgt i32 %52, -5
  br i1 %cmp19.i.i.i.i, label %if.then20.i.i.i.i, label %fusion.suffix4

if.then20.i.i.i.i:                                ; preds = %leaf.union
  %54 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 3) #3
  %55 = tail call double @llvm.amdgcn.frexp.mant.f64(double %54) #3
  %56 = fcmp olt double %55, 0x3FE5555555555555
  %57 = zext i1 %56 to i32
  %58 = tail call double @llvm.amdgcn.ldexp.f64(double %55, i32 %57) #3
  %59 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %54) #3
  %60 = sub nsw i32 %59, %57
  %61 = fadd double %58, -1.000000e+00
  %62 = fadd double %58, 1.000000e+00
  %63 = fsub double %62, %58
  %64 = fsub double %62, %63
  %65 = fsub double %58, %64
  %66 = fsub double 1.000000e+00, %63
  %67 = fadd double %66, %65
  %68 = tail call double @llvm.amdgcn.rcp.f64(double %62) #3
  %69 = fneg double %62
  %70 = tail call double @llvm.fma.f64(double %69, double %68, double 1.000000e+00) #3
  %71 = tail call double @llvm.fma.f64(double %70, double %68, double %68) #3
  %72 = tail call double @llvm.fma.f64(double %69, double %71, double 1.000000e+00) #3
  %73 = tail call double @llvm.fma.f64(double %72, double %71, double %71) #3
  %74 = fmul double %61, %73
  %75 = fmul double %62, %74
  %76 = fneg double %75
  %77 = tail call double @llvm.fma.f64(double %74, double %62, double %76) #3
  %78 = tail call double @llvm.fma.f64(double %74, double %67, double %77) #3
  %79 = fadd double %75, %78
  %80 = fsub double %79, %75
  %81 = fsub double %78, %80
  %82 = fsub double %61, %79
  %83 = fsub double %61, %82
  %84 = fsub double %83, %79
  %85 = fsub double %84, %81
  %86 = fadd double %82, %85
  %87 = fmul double %73, %86
  %88 = fadd double %74, %87
  %89 = fsub double %88, %74
  %90 = fsub double %87, %89
  %91 = fmul double %88, %88
  %92 = fneg double %91
  %93 = tail call double @llvm.fma.f64(double %88, double %88, double %92) #3
  %94 = fmul double %90, 2.000000e+00
  %95 = tail call double @llvm.fma.f64(double %88, double %94, double %93) #3
  %96 = tail call double @llvm.fma.f64(double %90, double %90, double %95) #3
  %97 = fadd double %91, %96
  %98 = fsub double %97, %91
  %99 = fsub double %96, %98
  %100 = tail call double @llvm.fma.f64(double %97, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %101 = tail call double @llvm.fma.f64(double %97, double %100, double 0x3FC7474DD7F4DF2E) #3
  %102 = tail call double @llvm.fma.f64(double %97, double %101, double 0x3FCC71C016291751) #3
  %103 = tail call double @llvm.fma.f64(double %97, double %102, double 0x3FD249249B27ACF1) #3
  %104 = tail call double @llvm.fma.f64(double %97, double %103, double 0x3FD99999998EF7B6) #3
  %105 = tail call double @llvm.fma.f64(double %97, double %104, double 0x3FE5555555555780) #3
  %106 = tail call double @llvm.amdgcn.ldexp.f64(double %88, i32 1) #3
  %107 = tail call double @llvm.amdgcn.ldexp.f64(double %90, i32 1) #3
  %108 = fmul double %88, %97
  %109 = fneg double %108
  %110 = tail call double @llvm.fma.f64(double %88, double %97, double %109) #3
  %111 = fmul double %90, %97
  %112 = tail call double @llvm.fma.f64(double %88, double %99, double %111) #3
  %113 = fadd double %110, %112
  %114 = fadd double %108, %113
  %115 = fsub double %114, %108
  %116 = fsub double %113, %115
  %117 = fmul double %114, %105
  %118 = fneg double %117
  %119 = tail call double @llvm.fma.f64(double %114, double %105, double %118) #3
  %120 = tail call double @llvm.fma.f64(double %116, double %105, double %119) #3
  %121 = fadd double %117, %120
  %122 = fsub double %121, %117
  %123 = fsub double %120, %122
  %124 = fadd double %106, %121
  %125 = fsub double %124, %106
  %126 = fsub double %124, %125
  %127 = fsub double %106, %126
  %128 = fsub double %121, %125
  %129 = fadd double %128, %127
  %130 = fadd double %107, %123
  %131 = fsub double %130, %107
  %132 = fsub double %130, %131
  %133 = fsub double %107, %132
  %134 = fsub double %123, %131
  %135 = fadd double %134, %133
  %136 = fadd double %130, %129
  %137 = fadd double %124, %136
  %138 = fsub double %137, %124
  %139 = fsub double %136, %138
  %140 = fadd double %135, %139
  %141 = fadd double %137, %140
  %142 = fsub double %141, %137
  %143 = fsub double %140, %142
  %144 = sitofp i32 %60 to double
  %145 = fmul double %141, 0x3FF71547652B82FE
  %146 = fneg double %145
  %147 = fmul double %141, 0x3C7777D0FFDA0D24
  %148 = insertelement <2 x double> undef, double %141, i32 0
  %149 = insertelement <2 x double> %148, double %143, i32 1
  %150 = insertelement <2 x double> undef, double %146, i32 0
  %151 = insertelement <2 x double> %150, double %147, i32 1
  %152 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %149, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %151) #3
  %153 = extractelement <2 x double> %152, i32 0
  %154 = extractelement <2 x double> %152, i32 1
  %155 = fadd double %153, %154
  %156 = fadd double %145, %155
  %157 = fsub double %156, %145
  %158 = fsub double %155, %157
  %159 = fadd double %156, %144
  %160 = fsub double %159, %144
  %161 = fsub double %160, %159
  %162 = fadd double %161, %144
  %163 = fsub double %156, %160
  %164 = fadd double %163, %162
  %165 = fadd double %158, %164
  %166 = fadd double %159, %165
  %167 = tail call double @llvm.fabs.f64(double %54) #4
  %168 = fcmp oeq double %167, 0x7FF0000000000000
  %169 = select i1 %168, double %54, double %166
  %170 = fcmp olt double %54, 0.000000e+00
  %171 = select i1 %170, double 0x7FF8000000000000, double %169
  %172 = fcmp oeq double %54, 0.000000e+00
  %173 = select i1 %172, double 0xFFF0000000000000, double %171
  %mul.i.i148.i.i.i.i = fmul double %173, %173
  %mul1.i.i149.i.i.i.i = fmul double %mul.i.i148.i.i.i.i, 0x3EDBD077F856B461
  %174 = fsub double 0x3F78C25CB1F33D41, %mul1.i.i149.i.i.i.i
  %mul5.i.i151.i.i.i.i = fmul double %mul.i.i148.i.i.i.i, 0x3F40AF40801BC234
  %add7.i.i152.i.i.i.i = fadd double %mul5.i.i151.i.i.i.i, 0x3FA89B8093A2295C
  %mul10.i.i153.i.i.i.i = fmul double %mul.i.i148.i.i.i.i, %174
  %mul12.i.i154.i.i.i.i = fmul double %mul.i.i148.i.i.i.i, %add7.i.i152.i.i.i.i
  %add15.i.i155.i.i.i.i = fadd double %mul10.i.i153.i.i.i.i, 0x3FCF140D06064BE5
  %add18.i.i156.i.i.i.i = fadd double %mul12.i.i154.i.i.i.i, 0x3FE570FCC3570002
  %mul20.i.i157.i.i.i.i = fmul double %mul.i.i148.i.i.i.i, %add15.i.i155.i.i.i.i
  %add23.i.i158.i.i.i.i = fadd double %mul20.i.i157.i.i.i.i, 0x3FE6B9F7A03E5CA5
  %175 = fmul double %173, %add18.i.i156.i.i.i.i
  %add28.i.i160.i.i.i.i = fsub double %add23.i.i158.i.i.i.i, %175
  %mul1.i.i138.i.i.i.i = fmul double %mul.i.i148.i.i.i.i, 0x3F44ACEECE75B689
  %add.i.i139.i.i.i.i = fadd double %mul1.i.i138.i.i.i.i, 0x3FB48180AD0CAC24
  %mul5.i.i140.i.i.i.i = fmul double %mul.i.i148.i.i.i.i, 0x3F8497E40449A14F
  %add7.i.i141.i.i.i.i = fadd double %mul5.i.i140.i.i.i.i, 0x3FD7722E0F8ACAA8
  %mul10.i.i142.i.i.i.i = fmul double %mul.i.i148.i.i.i.i, %add.i.i139.i.i.i.i
  %mul12.i.i143.i.i.i.i = fmul double %mul.i.i148.i.i.i.i, %add7.i.i141.i.i.i.i
  %add15.i.i144.i.i.i.i = fadd double %mul10.i.i142.i.i.i.i, 0x3FED6593E87A041B
  %add18.i.i145.i.i.i.i = fadd double %mul12.i.i143.i.i.i.i, 1.000000e+00
  %176 = fmul double %173, %add15.i.i144.i.i.i.i
  %add23.i.i147.i.i.i.i = fsub double %add18.i.i145.i.i.i.i, %176
  br label %fusion.suffix4

decision.dispatch2:                               ; preds = %if.else17.i.i.i.i
  %cmp41.i.i.i.i = icmp sgt i32 %52, -17
  %merged.select36 = select i1 %cmp41.i.i.i.i, i32 -9, i32 -33
  %177 = icmp sgt i32 %52, %merged.select36
  %merged.select37 = select i1 %cmp41.i.i.i.i, i32 4, i32 16
  %merged.select38 = select i1 %cmp41.i.i.i.i, i32 8, i32 32
  %178 = select i1 %177, i32 %merged.select37, i32 %merged.select38
  %179 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 %178) #3
  %180 = tail call double @llvm.amdgcn.frexp.mant.f64(double %179) #3
  %181 = fcmp olt double %180, 0x3FE5555555555555
  %182 = zext i1 %181 to i32
  %183 = tail call double @llvm.amdgcn.ldexp.f64(double %180, i32 %182) #3
  %184 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %179) #3
  %185 = sub nsw i32 %184, %182
  %186 = fadd double %183, -1.000000e+00
  %187 = fadd double %183, 1.000000e+00
  %188 = fsub double %187, %183
  %189 = fsub double %187, %188
  %190 = fsub double %183, %189
  %191 = fsub double 1.000000e+00, %188
  %192 = fadd double %191, %190
  %193 = tail call double @llvm.amdgcn.rcp.f64(double %187) #3
  %194 = fneg double %187
  %195 = tail call double @llvm.fma.f64(double %194, double %193, double 1.000000e+00) #3
  %196 = tail call double @llvm.fma.f64(double %195, double %193, double %193) #3
  %197 = tail call double @llvm.fma.f64(double %194, double %196, double 1.000000e+00) #3
  %198 = tail call double @llvm.fma.f64(double %197, double %196, double %196) #3
  %199 = fmul double %186, %198
  %200 = fmul double %187, %199
  %201 = fneg double %200
  %202 = tail call double @llvm.fma.f64(double %199, double %187, double %201) #3
  %203 = tail call double @llvm.fma.f64(double %199, double %192, double %202) #3
  %204 = fadd double %200, %203
  %205 = fsub double %204, %200
  %206 = fsub double %203, %205
  %207 = fsub double %186, %204
  %208 = fsub double %186, %207
  %209 = fsub double %208, %204
  %210 = fsub double %209, %206
  %211 = fadd double %207, %210
  %212 = fmul double %198, %211
  %213 = fadd double %199, %212
  %214 = fsub double %213, %199
  %215 = fsub double %212, %214
  %216 = fmul double %213, %213
  %217 = fneg double %216
  %218 = tail call double @llvm.fma.f64(double %213, double %213, double %217) #3
  %219 = fmul double %215, 2.000000e+00
  %220 = tail call double @llvm.fma.f64(double %213, double %219, double %218) #3
  %221 = tail call double @llvm.fma.f64(double %215, double %215, double %220) #3
  %222 = fadd double %216, %221
  %223 = fsub double %222, %216
  %224 = fsub double %221, %223
  %225 = tail call double @llvm.fma.f64(double %222, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %226 = tail call double @llvm.fma.f64(double %222, double %225, double 0x3FC7474DD7F4DF2E) #3
  %227 = tail call double @llvm.fma.f64(double %222, double %226, double 0x3FCC71C016291751) #3
  %228 = tail call double @llvm.fma.f64(double %222, double %227, double 0x3FD249249B27ACF1) #3
  %229 = tail call double @llvm.fma.f64(double %222, double %228, double 0x3FD99999998EF7B6) #3
  %230 = tail call double @llvm.fma.f64(double %222, double %229, double 0x3FE5555555555780) #3
  %231 = tail call double @llvm.amdgcn.ldexp.f64(double %213, i32 1) #3
  %232 = tail call double @llvm.amdgcn.ldexp.f64(double %215, i32 1) #3
  %233 = fmul double %213, %222
  %234 = fneg double %233
  %235 = tail call double @llvm.fma.f64(double %213, double %222, double %234) #3
  %236 = fmul double %215, %222
  %237 = tail call double @llvm.fma.f64(double %213, double %224, double %236) #3
  %238 = fadd double %235, %237
  %239 = fadd double %233, %238
  %240 = fsub double %239, %233
  %241 = fsub double %238, %240
  %242 = fmul double %239, %230
  %243 = fneg double %242
  %244 = tail call double @llvm.fma.f64(double %239, double %230, double %243) #3
  %245 = tail call double @llvm.fma.f64(double %241, double %230, double %244) #3
  %246 = fadd double %242, %245
  %247 = fsub double %246, %242
  %248 = fsub double %245, %247
  %249 = fadd double %231, %246
  %250 = fsub double %249, %231
  %251 = fsub double %249, %250
  %252 = fsub double %231, %251
  %253 = fsub double %246, %250
  %254 = fadd double %253, %252
  %255 = fadd double %232, %248
  %256 = fsub double %255, %232
  %257 = fsub double %255, %256
  %258 = fsub double %232, %257
  %259 = fsub double %248, %256
  %260 = fadd double %259, %258
  %261 = fadd double %255, %254
  %262 = fadd double %249, %261
  %263 = fsub double %262, %249
  %264 = fsub double %261, %263
  %265 = fadd double %260, %264
  %266 = fadd double %262, %265
  %267 = fsub double %266, %262
  %268 = fsub double %265, %267
  %269 = sitofp i32 %185 to double
  %270 = fmul double %266, 0x3FF71547652B82FE
  %271 = fneg double %270
  %272 = fmul double %266, 0x3C7777D0FFDA0D24
  %273 = insertelement <2 x double> undef, double %266, i32 0
  %274 = insertelement <2 x double> %273, double %268, i32 1
  %275 = insertelement <2 x double> undef, double %271, i32 0
  %276 = insertelement <2 x double> %275, double %272, i32 1
  %277 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %274, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %276) #3
  %278 = extractelement <2 x double> %277, i32 0
  %279 = extractelement <2 x double> %277, i32 1
  %280 = fadd double %278, %279
  %281 = fadd double %270, %280
  %282 = fsub double %281, %270
  %283 = fsub double %280, %282
  %284 = fadd double %281, %269
  %285 = fsub double %284, %269
  %286 = fsub double %285, %284
  %287 = fadd double %286, %269
  %288 = fsub double %281, %285
  %289 = fadd double %288, %287
  %290 = fadd double %283, %289
  %291 = fadd double %284, %290
  %292 = tail call double @llvm.fabs.f64(double %179) #4
  br i1 %cmp41.i.i.i.i, label %merged.bb67, label %merged.bb66

cond.false7.i.i.i:                                ; preds = %if.end15.i.i
  %cmp.i6.i.i.i = fcmp ult double %arrayidx.val, 3.750000e-01
  br i1 %cmp.i6.i.i.i, label %if.else.i23.i.i.i, label %if.then.i21.i.i.i

if.then.i21.i.i.i:                                ; preds = %cond.false7.i.i.i
  %sub.i7.i.i.i = fadd double %arrayidx.val, -3.750000e-01
  %mul.i.i.i8.i.i.i = fmul double %sub.i7.i.i.i, %sub.i7.i.i.i
  %mul1.i.i.i9.i.i.i = fmul double %mul.i.i.i8.i.i.i, 0x402E3985AD07C11A
  %add.i.i.i10.i.i.i = fadd double %mul1.i.i.i9.i.i.i, 0xC03085ADC87F148C
  %mul5.i.i.i11.i.i.i = fmul double %mul.i.i.i8.i.i.i, 0x401BFCD2EDF5ACC4
  %293 = fsub double 0x40101FAA3F78B28E, %mul5.i.i.i11.i.i.i
  %mul10.i.i.i13.i.i.i = fmul double %mul.i.i.i8.i.i.i, %add.i.i.i10.i.i.i
  %mul12.i.i.i14.i.i.i = fmul double %mul.i.i.i8.i.i.i, %293
  %add15.i.i.i15.i.i.i = fadd double %mul10.i.i.i13.i.i.i, 0x400F06502EC2116F
  %add18.i.i.i16.i.i.i = fadd double %mul12.i.i.i14.i.i.i, 0x3FA32D6622EF65AB
  %mul20.i.i.i17.i.i.i = fmul double %sub.i7.i.i.i, %add15.i.i.i15.i.i.i
  %add23.i.i.i18.i.i.i = fadd double %add18.i.i.i16.i.i.i, %mul20.i.i.i17.i.i.i
  %mul1.i.i306.i.i.i.i = fmul double %mul.i.i.i8.i.i.i, 0x3FF9609F779C5E99
  %294 = fsub double 0x4023738A7902B742, %mul1.i.i306.i.i.i.i
  %mul5.i.i308.i.i.i.i = fmul double %mul.i.i.i8.i.i.i, 0x4005C97BEA6BDB5A
  %295 = fsub double 0x3FD3B07AFB10BC79, %mul5.i.i308.i.i.i.i
  %mul10.i.i310.i.i.i.i = fmul double %mul.i.i.i8.i.i.i, %294
  %mul12.i.i311.i.i.i.i = fmul double %mul.i.i.i8.i.i.i, %295
  %add15.i.i312.i.i.i.i = fadd double %mul10.i.i310.i.i.i.i, 0xC019669B84791897
  %add18.i.i313.i.i.i.i = fadd double %mul12.i.i311.i.i.i.i, 0x3FDC05F5C732E888
  %mul20.i.i314.i.i.i.i = fmul double %mul.i.i.i8.i.i.i, %add15.i.i312.i.i.i.i
  %add23.i.i315.i.i.i.i = fadd double %mul20.i.i314.i.i.i.i, 1.000000e+00
  %mul25.i.i316.i.i.i.i = fmul double %sub.i7.i.i.i, %add18.i.i313.i.i.i.i
  %add28.i.i317.i.i.i.i = fadd double %mul25.i.i316.i.i.i.i, %add23.i.i315.i.i.i.i
  %div.i20.i.i.i = fdiv double %add23.i.i.i18.i.i.i, %add28.i.i317.i.i.i.i
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else.i23.i.i.i:                                ; preds = %cond.false7.i.i.i
  %decision.interval2 = fcmp ult double %arrayidx.val, 1.250000e-01
  br i1 %decision.interval2, label %if.else17.i35.i.i.i, label %decision.dispatch1, !decision.condition_prefix !6

decision.dispatch1:                               ; preds = %if.else.i23.i.i.i
  %cmp2.i22.i.i.i = fcmp ult double %arrayidx.val, 2.500000e-01
  %296 = select i1 %cmp2.i22.i.i.i, double -1.250000e-01, double -2.500000e-01
  %297 = fadd double %arrayidx.val, %296
  %298 = fmul double %297, %297
  %299 = select i1 %cmp2.i22.i.i.i, double 0x4068E6DDCC41063F, double 0x40209BA0CA602AA9
  %300 = fmul double %298, %299
  %301 = select i1 %cmp2.i22.i.i.i, double 0xC0752AD202523CE5, double 0xC03AB74FA533B36E
  %302 = fadd double %300, %301
  %303 = select i1 %cmp2.i22.i.i.i, double 0x4080D1B58D04D9C9, double 0x40379E848D9E949D
  %304 = fmul double %298, %303
  %305 = select i1 %cmp2.i22.i.i.i, double 0x407CB1D75E0C4F58, double 0x4037940F708222AF
  %306 = fsub double %305, %304
  %307 = fmul double %298, %302
  %308 = fmul double %298, %306
  %309 = select i1 %cmp2.i22.i.i.i, double 0x4069326C1159E9DB, double 0x4032087237C73F8C
  %310 = fadd double %307, %309
  %311 = select i1 %cmp2.i22.i.i.i, double 0xC024AD8FAE86A147, double 0x3FF47646B0F87946
  %312 = fadd double %308, %311
  %313 = fmul double %298, %310
  %314 = select i1 %cmp2.i22.i.i.i, double %298, double %297
  %315 = fmul double %314, %312
  %316 = select i1 %cmp2.i22.i.i.i, double 0x40705EDC8D95F7FC, double 0x40298D77C48BA327
  %317 = fmul double %298, %316
  %318 = select i1 %cmp2.i22.i.i.i, double 0xC06F965D272FAC7A, double 0xC0311C9898526451
  %319 = fadd double %317, %318
  %320 = select i1 %cmp2.i22.i.i.i, double 0x40686BB6228197AD, double 0x401AE4210EC8894B
  %321 = fmul double %298, %320
  %322 = select i1 %cmp2.i22.i.i.i, double 0x40530C7F6C363BB9, double 0x4002DB11078FC43E
  %323 = fsub double %322, %321
  %324 = fmul double %298, %319
  %325 = fmul double %298, %323
  %326 = select i1 %cmp2.i22.i.i.i, double 0x405440452173DCA6, double 0x40157F95E5CB1B22
  %327 = fadd double %324, %326
  %328 = select i1 %cmp2.i22.i.i.i, double 0x40306AF25EBB4DDE, double 1.000000e+00
  %329 = fadd double %325, %328
  %330 = fmul double %314, %327
  %331 = select i1 %cmp2.i22.i.i.i, double 0xC024B04741F7A527, double 0xBFDABCA86BC1374B
  %332 = fadd double %313, %331
  br i1 %cmp2.i22.i.i.i, label %if.then11.i33.i.i.i, label %fusion.suffix, !decision.merged_from !13, !decision.origin !14

if.then11.i33.i.i.i:                              ; preds = %decision.dispatch1
  %add28.i.i278.i.i.i.i = fadd double %315, 0xBFEC1147FADC1DD1
  %mul30.i.i279.i.i.i.i = fmul double %297, %332
  %add23.i.i263.i.i.i.i = fadd double %330, 1.000000e+00
  %mul25.i.i264.i.i.i.i = fmul double %297, %329
  br label %fusion.suffix

if.else17.i35.i.i.i:                              ; preds = %if.else.i23.i.i.i
  %333 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %arrayidx.val) #3
  %334 = add nsw i32 %333, -1
  %335 = tail call double @llvm.fabs.f64(double %arrayidx.val) #4
  %336 = fcmp oeq double %335, 0x7FF0000000000000
  %337 = select i1 %336, i32 2147483647, i32 %334
  %338 = fcmp oeq double %arrayidx.val, 0.000000e+00
  %339 = select i1 %338, i32 -2147483648, i32 %337
  %cmp19.i34.i.i.i = icmp sgt i32 %339, -5
  br i1 %cmp19.i34.i.i.i, label %if.then20.i39.i.i.i, label %if.else27.i41.i.i.i

if.then20.i39.i.i.i:                              ; preds = %if.else17.i35.i.i.i
  %340 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 3) #3
  %341 = tail call double @llvm.amdgcn.frexp.mant.f64(double %340) #3
  %342 = fcmp olt double %341, 0x3FE5555555555555
  %343 = zext i1 %342 to i32
  %344 = tail call double @llvm.amdgcn.ldexp.f64(double %341, i32 %343) #3
  %345 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %340) #3
  %346 = sub nsw i32 %345, %343
  %347 = fadd double %344, -1.000000e+00
  %348 = fadd double %344, 1.000000e+00
  %349 = fsub double %348, %344
  %350 = fsub double %348, %349
  %351 = fsub double %344, %350
  %352 = fsub double 1.000000e+00, %349
  %353 = fadd double %352, %351
  %354 = tail call double @llvm.amdgcn.rcp.f64(double %348) #3
  %355 = fneg double %348
  %356 = tail call double @llvm.fma.f64(double %355, double %354, double 1.000000e+00) #3
  %357 = tail call double @llvm.fma.f64(double %356, double %354, double %354) #3
  %358 = tail call double @llvm.fma.f64(double %355, double %357, double 1.000000e+00) #3
  %359 = tail call double @llvm.fma.f64(double %358, double %357, double %357) #3
  %360 = fmul double %347, %359
  %361 = fmul double %348, %360
  %362 = fneg double %361
  %363 = tail call double @llvm.fma.f64(double %360, double %348, double %362) #3
  %364 = tail call double @llvm.fma.f64(double %360, double %353, double %363) #3
  %365 = fadd double %361, %364
  %366 = fsub double %365, %361
  %367 = fsub double %364, %366
  %368 = fsub double %347, %365
  %369 = fsub double %347, %368
  %370 = fsub double %369, %365
  %371 = fsub double %370, %367
  %372 = fadd double %368, %371
  %373 = fmul double %359, %372
  %374 = fadd double %360, %373
  %375 = fsub double %374, %360
  %376 = fsub double %373, %375
  %377 = fmul double %374, %374
  %378 = fneg double %377
  %379 = tail call double @llvm.fma.f64(double %374, double %374, double %378) #3
  %380 = fmul double %376, 2.000000e+00
  %381 = tail call double @llvm.fma.f64(double %374, double %380, double %379) #3
  %382 = tail call double @llvm.fma.f64(double %376, double %376, double %381) #3
  %383 = fadd double %377, %382
  %384 = fsub double %383, %377
  %385 = fsub double %382, %384
  %386 = tail call double @llvm.fma.f64(double %383, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %387 = tail call double @llvm.fma.f64(double %383, double %386, double 0x3FC7474DD7F4DF2E) #3
  %388 = tail call double @llvm.fma.f64(double %383, double %387, double 0x3FCC71C016291751) #3
  %389 = tail call double @llvm.fma.f64(double %383, double %388, double 0x3FD249249B27ACF1) #3
  %390 = tail call double @llvm.fma.f64(double %383, double %389, double 0x3FD99999998EF7B6) #3
  %391 = tail call double @llvm.fma.f64(double %383, double %390, double 0x3FE5555555555780) #3
  %392 = tail call double @llvm.amdgcn.ldexp.f64(double %374, i32 1) #3
  %393 = tail call double @llvm.amdgcn.ldexp.f64(double %376, i32 1) #3
  %394 = fmul double %374, %383
  %395 = fneg double %394
  %396 = tail call double @llvm.fma.f64(double %374, double %383, double %395) #3
  %397 = fmul double %376, %383
  %398 = tail call double @llvm.fma.f64(double %374, double %385, double %397) #3
  %399 = fadd double %396, %398
  %400 = fadd double %394, %399
  %401 = fsub double %400, %394
  %402 = fsub double %399, %401
  %403 = fmul double %400, %391
  %404 = fneg double %403
  %405 = tail call double @llvm.fma.f64(double %400, double %391, double %404) #3
  %406 = tail call double @llvm.fma.f64(double %402, double %391, double %405) #3
  %407 = fadd double %403, %406
  %408 = fsub double %407, %403
  %409 = fsub double %406, %408
  %410 = fadd double %392, %407
  %411 = fsub double %410, %392
  %412 = fsub double %410, %411
  %413 = fsub double %392, %412
  %414 = fsub double %407, %411
  %415 = fadd double %414, %413
  %416 = fadd double %393, %409
  %417 = fsub double %416, %393
  %418 = fsub double %416, %417
  %419 = fsub double %393, %418
  %420 = fsub double %409, %417
  %421 = fadd double %420, %419
  %422 = fadd double %416, %415
  %423 = fadd double %410, %422
  %424 = fsub double %423, %410
  %425 = fsub double %422, %424
  %426 = fadd double %421, %425
  %427 = fadd double %423, %426
  %428 = fsub double %427, %423
  %429 = fsub double %426, %428
  %430 = sitofp i32 %346 to double
  %431 = fmul double %427, 0x3FF71547652B82FE
  %432 = fneg double %431
  %433 = fmul double %427, 0x3C7777D0FFDA0D24
  %434 = insertelement <2 x double> undef, double %427, i32 0
  %435 = insertelement <2 x double> %434, double %429, i32 1
  %436 = insertelement <2 x double> undef, double %432, i32 0
  %437 = insertelement <2 x double> %436, double %433, i32 1
  %438 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %435, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %437) #3
  %439 = extractelement <2 x double> %438, i32 0
  %440 = extractelement <2 x double> %438, i32 1
  %441 = fadd double %439, %440
  %442 = fadd double %431, %441
  %443 = fsub double %442, %431
  %444 = fsub double %441, %443
  %445 = fadd double %442, %430
  %446 = fsub double %445, %430
  %447 = fsub double %446, %445
  %448 = fadd double %447, %430
  %449 = fsub double %442, %446
  %450 = fadd double %449, %448
  %451 = fadd double %444, %450
  %452 = fadd double %445, %451
  %453 = tail call double @llvm.fabs.f64(double %340) #4
  %454 = fcmp oeq double %453, 0x7FF0000000000000
  %455 = select i1 %454, double %340, double %452
  %456 = fcmp olt double %340, 0.000000e+00
  %457 = select i1 %456, double 0x7FF8000000000000, double %455
  %458 = fcmp oeq double %340, 0.000000e+00
  %459 = select i1 %458, double 0xFFF0000000000000, double %457
  %mul.i.i242.i.i.i.i = fmul double %459, %459
  %mul1.i.i243.i.i.i.i = fmul double %mul.i.i242.i.i.i.i, 0x3F10728B75F46556
  %460 = fsub double 0xBFB1D997333851F3, %mul1.i.i243.i.i.i.i
  %mul5.i.i245.i.i.i.i = fmul double %mul.i.i242.i.i.i.i, 0x3F713B96D78DC454
  %461 = fsub double 0xBFDBC9E8A9D4EBD0, %mul5.i.i245.i.i.i.i
  %mul10.i.i247.i.i.i.i = fmul double %mul.i.i242.i.i.i.i, %460
  %mul12.i.i248.i.i.i.i = fmul double %mul.i.i242.i.i.i.i, %461
  %add15.i.i249.i.i.i.i = fadd double %mul10.i.i247.i.i.i.i, 0xBFF164811EDD50A9
  %add18.i.i250.i.i.i.i = fadd double %mul12.i.i248.i.i.i.i, 0xBFEC1147FADC1DD1
  %462 = fmul double %459, %add15.i.i249.i.i.i.i
  %add23.i.i252.i.i.i.i = fsub double %add18.i.i250.i.i.i.i, %462
  %mul1.i.i232.i.i.i.i = fmul double %mul.i.i242.i.i.i.i, 0x3EEE329A0EE79745
  %add.i.i233.i.i.i.i = fadd double %mul1.i.i232.i.i.i.i, 0x3F9F1FF0999DE692
  %mul5.i.i234.i.i.i.i = fmul double %mul.i.i242.i.i.i.i, 0x3F56CF90A3508EC2
  %add7.i.i235.i.i.i.i = fadd double %mul5.i.i234.i.i.i.i, 0x3FCFAFFF6FF925DC
  %mul10.i.i236.i.i.i.i = fmul double %mul.i.i242.i.i.i.i, %add.i.i233.i.i.i.i
  %mul12.i.i237.i.i.i.i = fmul double %mul.i.i242.i.i.i.i, %add7.i.i235.i.i.i.i
  %add15.i.i238.i.i.i.i = fadd double %mul10.i.i236.i.i.i.i, 0x3FEAD689E3DCFB29
  %add18.i.i239.i.i.i.i = fadd double %mul12.i.i237.i.i.i.i, 1.000000e+00
  %463 = fmul double %459, %add15.i.i238.i.i.i.i
  %add23.i.i241.i.i.i.i = fsub double %add18.i.i239.i.i.i.i, %463
  %div26.i38.i.i.i = fdiv double %add23.i.i252.i.i.i.i, %add23.i.i241.i.i.i.i
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else27.i41.i.i.i:                              ; preds = %if.else17.i35.i.i.i
  %cmp106.i.i.i.i = icmp sgt i32 %339, -1025
  br i1 %cmp106.i.i.i.i, label %decision.dispatch3, label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, !decision.condition_prefix !6

decision.dispatch3:                               ; preds = %if.else27.i41.i.i.i
  %cmp84.i.i.i.i = icmp sgt i32 %339, -257
  %464 = icmp sgt i32 %339, -65
  %465 = icmp sgt i32 %339, -17
  %466 = select i1 %465, i32 -9, i32 -33
  %467 = select i1 %464, i32 %466, i32 -129
  %468 = select i1 %cmp84.i.i.i.i, i1 %464, i1 undef
  %469 = select i1 %464, i1 %465, i1 undef
  %merged.select = select i1 %cmp84.i.i.i.i, i32 %467, i32 -513
  %470 = icmp sgt i32 %339, %merged.select
  %471 = select i1 %469, i32 4, i32 16
  %472 = select i1 %469, i32 8, i32 32
  %473 = select i1 %468, i32 %471, i32 64
  %474 = select i1 %468, i32 %472, i32 128
  %merged.select64 = select i1 %cmp84.i.i.i.i, i32 %473, i32 256
  %merged.select65 = select i1 %cmp84.i.i.i.i, i32 %474, i32 512
  %475 = select i1 %470, i32 %merged.select64, i32 %merged.select65
  %476 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %475) #3
  %477 = tail call double @llvm.amdgcn.frexp.mant.f64(double %476) #3
  %478 = fcmp olt double %477, 0x3FE5555555555555
  %479 = zext i1 %478 to i32
  %480 = tail call double @llvm.amdgcn.ldexp.f64(double %477, i32 %479) #3
  %481 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %476) #3
  %482 = sub nsw i32 %481, %479
  %483 = fadd double %480, -1.000000e+00
  %484 = fadd double %480, 1.000000e+00
  %485 = fsub double %484, %480
  %486 = fsub double %484, %485
  %487 = fsub double %480, %486
  %488 = fsub double 1.000000e+00, %485
  %489 = fadd double %488, %487
  %490 = tail call double @llvm.amdgcn.rcp.f64(double %484) #3
  %491 = fneg double %484
  %492 = tail call double @llvm.fma.f64(double %491, double %490, double 1.000000e+00) #3
  %493 = tail call double @llvm.fma.f64(double %492, double %490, double %490) #3
  %494 = tail call double @llvm.fma.f64(double %491, double %493, double 1.000000e+00) #3
  %495 = tail call double @llvm.fma.f64(double %494, double %493, double %493) #3
  %496 = fmul double %483, %495
  %497 = fmul double %484, %496
  %498 = fneg double %497
  %499 = tail call double @llvm.fma.f64(double %496, double %484, double %498) #3
  %500 = tail call double @llvm.fma.f64(double %496, double %489, double %499) #3
  %501 = fadd double %497, %500
  %502 = fsub double %501, %497
  %503 = fsub double %500, %502
  %504 = fsub double %483, %501
  %505 = fsub double %483, %504
  %506 = fsub double %505, %501
  %507 = fsub double %506, %503
  %508 = fadd double %504, %507
  %509 = fmul double %495, %508
  %510 = fadd double %496, %509
  %511 = fsub double %510, %496
  %512 = fsub double %509, %511
  %513 = fmul double %510, %510
  %514 = fneg double %513
  %515 = tail call double @llvm.fma.f64(double %510, double %510, double %514) #3
  %516 = fmul double %512, 2.000000e+00
  %517 = tail call double @llvm.fma.f64(double %510, double %516, double %515) #3
  %518 = tail call double @llvm.fma.f64(double %512, double %512, double %517) #3
  %519 = fadd double %513, %518
  %520 = fsub double %519, %513
  %521 = fsub double %518, %520
  %522 = tail call double @llvm.fma.f64(double %519, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %523 = tail call double @llvm.fma.f64(double %519, double %522, double 0x3FC7474DD7F4DF2E) #3
  %524 = tail call double @llvm.fma.f64(double %519, double %523, double 0x3FCC71C016291751) #3
  %525 = tail call double @llvm.fma.f64(double %519, double %524, double 0x3FD249249B27ACF1) #3
  %526 = tail call double @llvm.fma.f64(double %519, double %525, double 0x3FD99999998EF7B6) #3
  %527 = tail call double @llvm.fma.f64(double %519, double %526, double 0x3FE5555555555780) #3
  %528 = tail call double @llvm.amdgcn.ldexp.f64(double %510, i32 1) #3
  %529 = tail call double @llvm.amdgcn.ldexp.f64(double %512, i32 1) #3
  %530 = fmul double %510, %519
  %531 = fneg double %530
  %532 = tail call double @llvm.fma.f64(double %510, double %519, double %531) #3
  %533 = fmul double %512, %519
  %534 = tail call double @llvm.fma.f64(double %510, double %521, double %533) #3
  %535 = fadd double %532, %534
  %536 = fadd double %530, %535
  %537 = fsub double %536, %530
  %538 = fsub double %535, %537
  %539 = fmul double %536, %527
  %540 = fneg double %539
  %541 = tail call double @llvm.fma.f64(double %536, double %527, double %540) #3
  %542 = tail call double @llvm.fma.f64(double %538, double %527, double %541) #3
  %543 = fadd double %539, %542
  %544 = fsub double %543, %539
  %545 = fsub double %542, %544
  %546 = fadd double %528, %543
  %547 = fsub double %546, %528
  %548 = fsub double %546, %547
  %549 = fsub double %528, %548
  %550 = fsub double %543, %547
  %551 = fadd double %550, %549
  %552 = fadd double %529, %545
  %553 = fsub double %552, %529
  %554 = fsub double %552, %553
  %555 = fsub double %529, %554
  %556 = fsub double %545, %553
  %557 = fadd double %556, %555
  %558 = fadd double %552, %551
  %559 = fadd double %546, %558
  %560 = fsub double %559, %546
  %561 = fsub double %558, %560
  %562 = fadd double %557, %561
  %563 = fadd double %559, %562
  %564 = fsub double %563, %559
  %565 = fsub double %562, %564
  %566 = sitofp i32 %482 to double
  %567 = fmul double %563, 0x3FF71547652B82FE
  %568 = fneg double %567
  %569 = fmul double %563, 0x3C7777D0FFDA0D24
  br i1 %470, label %fusion.side, label %fusion.side1

fusion.suffix:                                    ; preds = %if.then11.i33.i.i.i, %decision.dispatch1
  %570 = phi double [ %330, %decision.dispatch1 ], [ %add23.i.i263.i.i.i.i, %if.then11.i33.i.i.i ]
  %571 = phi double [ %329, %decision.dispatch1 ], [ %mul25.i.i264.i.i.i.i, %if.then11.i33.i.i.i ]
  %572 = phi double [ %332, %decision.dispatch1 ], [ %mul30.i.i279.i.i.i.i, %if.then11.i33.i.i.i ]
  %573 = phi double [ %315, %decision.dispatch1 ], [ %add28.i.i278.i.i.i.i, %if.then11.i33.i.i.i ]
  %574 = fadd double %573, %572
  %575 = fadd double %571, %570
  %576 = fdiv double %574, %575
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

fusion.side4:                                     ; preds = %decision.dispatch4
  %577 = fadd double %38, 0x405A8654D41DC46C
  %578 = fmul double %12, %577
  %579 = fmul double %13, 0x409B9068A3C78607
  %580 = fsub double 0x40990C9A56964108, %579
  %581 = fmul double %13, 0x408105AF09F369D0
  %582 = fsub double 0x40912C23C604419C, %581
  %583 = fmul double %13, %580
  %584 = fmul double %13, %582
  %585 = fadd double %583, 0x4070760E04B9BCBD
  %586 = fadd double %584, 0x403AF5DBE51CBD80
  %587 = fmul double %13, %585
  %588 = fadd double %587, 1.000000e+00
  %589 = fmul double %12, %586
  br label %fusion.suffix1

fusion.side6:                                     ; preds = %decision.dispatch4
  %590 = fsub double 0x4030441296C5FB34, %41
  %591 = select i1 %10, double %43, double %590
  %592 = select i1 %10, double 0x4000D00D57F2CBBD, double 0x401D7BFF8CC54FA6
  %593 = fmul double %13, %592
  %594 = select i1 %10, double 0xC0226B8874380C5B, double 0xC026402DD156D3FC
  %595 = fadd double %593, %594
  %596 = fmul double %13, %591
  %597 = fmul double %13, %595
  %598 = select i1 %10, double 0x402AF4FD59F9A777, double 0xC031083D20CE0F89
  %599 = fadd double %596, %598
  %600 = select i1 %10, double 0x401E18FAC448D58A, double 0x3FF51C8655DB120C
  %601 = fadd double %597, %600
  %602 = fmul double %13, %599
  %603 = fmul double %13, %601
  %604 = fadd double %602, 0x4012D71DC7267483
  %605 = select i1 %10, double %602, double %603
  %606 = fadd double %605, 1.000000e+00
  %607 = select i1 %10, double %601, double %604
  %608 = fmul double %12, %607
  %609 = select i1 %10, double %608, double %606
  %610 = select i1 %10, double %606, double %608
  br label %fusion.suffix1

fusion.suffix1:                                   ; preds = %fusion.side6, %fusion.side4
  %611 = phi double [ %588, %fusion.side4 ], [ %610, %fusion.side6 ]
  %612 = phi double [ %589, %fusion.side4 ], [ %609, %fusion.side6 ]
  %613 = phi double [ %578, %fusion.side4 ], [ %36, %fusion.side6 ]
  %614 = phi double [ %43, %fusion.side4 ], [ %38, %fusion.side6 ]
  %615 = fadd double %614, %613
  %616 = fadd double %612, %611
  %617 = fdiv double %615, %616
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

fusion.suffix2:                                   ; preds = %merged.branch.split66, %merged.branch.split54
  %618 = phi double [ %714, %merged.branch.split54 ], [ %764, %merged.branch.split66 ]
  %619 = phi double [ %713, %merged.branch.split54 ], [ %763, %merged.branch.split66 ]
  %620 = phi double [ %712, %merged.branch.split54 ], [ %762, %merged.branch.split66 ]
  %621 = phi double [ %711, %merged.branch.split54 ], [ %761, %merged.branch.split66 ]
  %622 = phi double [ %710, %merged.branch.split54 ], [ %760, %merged.branch.split66 ]
  %623 = phi double [ %709, %merged.branch.split54 ], [ %759, %merged.branch.split66 ]
  %624 = phi double [ %708, %merged.branch.split54 ], [ %758, %merged.branch.split66 ]
  %625 = phi double [ %707, %merged.branch.split54 ], [ %757, %merged.branch.split66 ]
  %626 = phi double [ %706, %merged.branch.split54 ], [ %756, %merged.branch.split66 ]
  %627 = phi double [ %705, %merged.branch.split54 ], [ %755, %merged.branch.split66 ]
  %628 = phi double [ %704, %merged.branch.split54 ], [ %754, %merged.branch.split66 ]
  %629 = phi double [ %703, %merged.branch.split54 ], [ %753, %merged.branch.split66 ]
  %630 = phi double [ %702, %merged.branch.split54 ], [ %752, %merged.branch.split66 ]
  %631 = phi double [ %701, %merged.branch.split54 ], [ %751, %merged.branch.split66 ]
  %632 = fcmp oeq double %780, 0x7FF0000000000000
  %633 = select i1 %632, double %476, double %779
  %634 = fcmp olt double %476, 0.000000e+00
  %635 = select i1 %634, double 0x7FF8000000000000, double %633
  %636 = fcmp oeq double %476, 0.000000e+00
  %637 = select i1 %636, double 0xFFF0000000000000, double %635
  %638 = fmul double %637, %637
  %639 = fmul double %638, %631
  %640 = fsub double %630, %639
  %641 = fmul double %638, %629
  %642 = fsub double %628, %641
  %643 = fmul double %638, %640
  %644 = fmul double %638, %642
  %645 = fadd double %643, %627
  %646 = fadd double %644, %626
  %647 = fmul double %638, %645
  %648 = fmul double %638, %646
  %649 = fadd double %647, %625
  %650 = fadd double %648, %624
  %651 = fmul double %637, %649
  %652 = fsub double %650, %651
  %653 = fmul double %638, %623
  %654 = fadd double %653, %622
  %655 = fmul double %638, %621
  %656 = fadd double %655, %620
  %657 = fmul double %638, %654
  %658 = fmul double %638, %656
  %659 = fadd double %657, %619
  %660 = fadd double %658, %618
  %661 = fmul double %638, %659
  %662 = fadd double %661, 1.000000e+00
  %663 = fmul double %637, %660
  %664 = fsub double %662, %663
  %665 = fdiv double %652, %664
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

fusion.suffix3:                                   ; preds = %merged.branch.split40, %merged.branch.split39
  %666 = phi double [ %845, %merged.branch.split39 ], [ %855, %merged.branch.split40 ]
  %667 = phi double [ %844, %merged.branch.split39 ], [ %854, %merged.branch.split40 ]
  %668 = phi double [ %843, %merged.branch.split39 ], [ %853, %merged.branch.split40 ]
  %669 = phi double [ %842, %merged.branch.split39 ], [ %852, %merged.branch.split40 ]
  %670 = phi double [ %877, %merged.branch.split39 ], [ %879, %merged.branch.split40 ]
  %671 = phi double [ %841, %merged.branch.split39 ], [ %851, %merged.branch.split40 ]
  %672 = phi double [ %840, %merged.branch.split39 ], [ %850, %merged.branch.split40 ]
  %673 = phi double [ %862, %merged.branch.split39 ], [ %903, %merged.branch.split40 ]
  %674 = phi double [ %874, %merged.branch.split39 ], [ %847, %merged.branch.split40 ]
  %675 = phi double [ %861, %merged.branch.split39 ], [ %905, %merged.branch.split40 ]
  %676 = phi double [ %837, %merged.branch.split39 ], [ %846, %merged.branch.split40 ]
  %677 = phi double [ %875, %merged.branch.split39 ], [ %906, %merged.branch.split40 ]
  %678 = fadd double %677, %676
  %679 = fmul double %675, %674
  %680 = fsub double %678, %679
  %681 = fmul double %673, %672
  %682 = fadd double %681, %671
  %683 = fmul double %673, %670
  %684 = fmul double %673, %682
  %685 = fadd double %683, %669
  %686 = fadd double %684, %668
  %687 = fmul double %673, %685
  %688 = fmul double %673, %686
  %689 = fadd double %687, %667
  %690 = fadd double %688, %666
  %691 = fmul double %673, %689
  %692 = fadd double %691, 1.000000e+00
  %693 = fmul double %675, %690
  %694 = fsub double %692, %693
  %695 = fmul double %sub.i.i.i, %694
  %696 = fdiv double %680, %695
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

fusion.suffix4:                                   ; preds = %if.then20.i.i.i.i, %leaf.union
  %697 = phi double [ 2.000000e+00, %leaf.union ], [ %add28.i.i160.i.i.i.i, %if.then20.i.i.i.i ]
  %698 = phi double [ 0x400921FB54442D18, %leaf.union ], [ %add23.i.i147.i.i.i.i, %if.then20.i.i.i.i ]
  %699 = fmul double %sub.i.i.i, %698
  %700 = fdiv double %697, %699
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i: ; preds = %merged.branch.split67, %fusion.suffix4, %fusion.suffix3, %fusion.suffix2, %fusion.suffix1, %fusion.suffix, %if.else27.i41.i.i.i, %if.then20.i39.i.i.i, %if.then.i21.i.i.i
  %retval.0.i.i.i = phi double [ %div.i20.i.i.i, %if.then.i21.i.i.i ], [ %div26.i38.i.i.i, %if.then20.i39.i.i.i ], [ 0xFFF0000000000000, %if.else27.i41.i.i.i ], [ %576, %fusion.suffix ], [ %617, %fusion.suffix1 ], [ %665, %fusion.suffix2 ], [ %696, %fusion.suffix3 ], [ %700, %fusion.suffix4 ], [ %828, %merged.branch.split67 ]
  %sub.i.i = fadd double %retval.0.i.i.i, 0.000000e+00
  br label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14promote_doubleILb0EEENS2_12domain_errorILNS2_17error_policy_typeE2EEENS2_14overflow_errorILS7_2EEENS2_14default_policyESB_SB_SB_SB_SB_SB_SB_SB_SB_EEEET_RKNS0_19landau_distributionISD_T0_EERKSD_.exit

_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14promote_doubleILb0EEENS2_12domain_errorILNS2_17error_policy_typeE2EEENS2_14overflow_errorILS7_2EEENS2_14default_policyESB_SB_SB_SB_SB_SB_SB_SB_SB_EEEET_RKNS0_19landau_distributionISD_T0_EERKSD_.exit: ; preds = %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, %lor.lhs.false2.i.i.i, %if.end9.i.i
  %retval.0.i.i = phi double [ 0x7FF8000000000000, %if.end9.i.i ], [ 0x7FF8000000000000, %lor.lhs.false2.i.i.i ], [ %sub.i.i, %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i ]
  %arrayidx712 = getelementptr inbounds double, double addrspace(1)* %output.coerce, i64 %idxprom
  store double %retval.0.i.i, double addrspace(1)* %arrayidx712, align 8, !tbaa !8
  br label %if.end

if.end:                                           ; preds = %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14promote_doubleILb0EEENS2_12domain_errorILNS2_17error_policy_typeE2EEENS2_14overflow_errorILS7_2EEENS2_14default_policyESB_SB_SB_SB_SB_SB_SB_SB_SB_EEEET_RKNS0_19landau_distributionISD_T0_EERKSD_.exit, %entry
  ret void

merged.branch.split54:                            ; preds = %merged.branch.split66
  %701 = select i1 %469, double %750, double %736
  %702 = select i1 %469, double %749, double %735
  %703 = select i1 %469, double %748, double %734
  %704 = select i1 %469, double %747, double %733
  %705 = select i1 %469, double %746, double %732
  %706 = select i1 %469, double %745, double %731
  %707 = select i1 %469, double %744, double %730
  %708 = select i1 %469, double %743, double %729
  %709 = select i1 %469, double %742, double %728
  %710 = select i1 %469, double %741, double %727
  %711 = select i1 %469, double %740, double %726
  %712 = select i1 %469, double %739, double %725
  %713 = select i1 %469, double %738, double %724
  %714 = select i1 %469, double %737, double %723
  br label %fusion.suffix2

fusion.side:                                      ; preds = %decision.dispatch3
  %715 = insertelement <2 x double> undef, double %563, i32 0
  %716 = insertelement <2 x double> %715, double %565, i32 1
  %717 = insertelement <2 x double> undef, double %568, i32 0
  %718 = insertelement <2 x double> %717, double %569, i32 1
  br label %fusion.common

fusion.side1:                                     ; preds = %decision.dispatch3
  %719 = insertelement <2 x double> undef, double %563, i32 0
  %720 = insertelement <2 x double> %719, double %565, i32 1
  %721 = insertelement <2 x double> undef, double %568, i32 0
  %722 = insertelement <2 x double> %721, double %569, i32 1
  br label %fusion.common

fusion.common:                                    ; preds = %fusion.side1, %fusion.side
  %723 = phi double [ 0x3FC7F5B66495DDB6, %fusion.side ], [ 0x3FB7CE42A74538CD, %fusion.side1 ]
  %724 = phi double [ 0x3F8B35517DD09962, %fusion.side ], [ 0x3F6ADBBA962C2080, %fusion.side1 ]
  %725 = phi double [ 0x3F3D2E4291C2C2D0, %fusion.side ], [ 0x3F0C9E4DE67437CE, %fusion.side1 ]
  %726 = phi double [ 0x3E6A03AD8C7D561F, %fusion.side ], [ 0x3E192F9212752578, %fusion.side1 ]
  %727 = phi double [ 0x3EDDEB134B240B6B, %fusion.side ], [ 0x3E9D26DA9BE0FF59, %fusion.side1 ]
  %728 = phi double [ 0x3DDA87308BB58726, %fusion.side ], [ 0x3D7985F69E9DFA4C, %fusion.side1 ]
  %729 = phi double [ 0xC002991536F3B198, %fusion.side ], [ 0xC00695E2D61C0C6E, %fusion.side1 ]
  %730 = phi double [ 0xBFDED3DE58969B0C, %fusion.side ], [ 0xBFD232BB27D90F0B, %fusion.side1 ]
  %731 = phi double [ 0xBFA370C135EBE2E0, %fusion.side ], [ 0xBF865CF2B86753CE, %fusion.side1 ]
  %732 = phi double [ 0xBF5751B27C5C9BFB, %fusion.side ], [ 0xBF2A2DC3D4DAE3C5, %fusion.side1 ]
  %733 = phi double [ 0xBEFB16A0F7496BD2, %fusion.side ], [ 0xBEBDB51233A64720, %fusion.side1 ]
  %734 = phi double [ 0x3E015340F5605AFB, %fusion.side ], [ 0x3DA2170560574A27, %fusion.side1 ]
  %735 = phi double [ 0xBE8B5F843E1F3895, %fusion.side ], [ 0xBE3D53C778BDFF24, %fusion.side1 ]
  %736 = phi double [ 0x3D2EEF3A19525962, %fusion.side ], [ 0x3CBD95F745F985C6, %fusion.side1 ]
  %737 = phi double [ 0x3FE82B2F4B11BB5A, %fusion.side ], [ 0x3FD81A505016D302, %fusion.side1 ]
  %738 = phi double [ 0x3FCBB079F2C252E4, %fusion.side ], [ 0x3FAB895727F039DB, %fusion.side1 ]
  %739 = phi double [ 0x3F9DF8C6DBF0F003, %fusion.side ], [ 0x3F6DB7207E85C0EF, %fusion.side1 ]
  %740 = phi double [ 0x3F0B438FF2C388C0, %fusion.side ], [ 0x3EBAD46BFAE07B75, %fusion.side1 ]
  %741 = phi double [ 0x3F5F07E1D05A5DFD, %fusion.side ], [ 0x3F1EA8AD4669BB53, %fusion.side1 ]
  %742 = phi double [ 0x3E9C1C977F10265B, %fusion.side ], [ 0x3E3B89766DC0E470, %fusion.side1 ]
  %743 = phi double [ 0xBFF2AD2669F16A11, %fusion.side ], [ 0xBFFC8922BA24935C, %fusion.side1 ]
  %744 = phi double [ 0xBFF1F8D8D4096576, %fusion.side ], [ 0xBFE8CAFD8375357B, %fusion.side1 ]
  %745 = phi double [ 0xBFD95EAC9AE91EB0, %fusion.side ], [ 0xBFC045854783A19F, %fusion.side1 ]
  %746 = phi double [ 0xBFB0A4004AB9FA2F, %fusion.side ], [ 0xBF843505D28DAEAC, %fusion.side1 ]
  %747 = phi double [ 0xBF74D4DF73958DD4, %fusion.side ], [ 0xBF383759EF2EC40C, %fusion.side1 ]
  %748 = phi double [ 0x3EBE74EDE276BA2A, %fusion.side ], [ 0x3E6073196B230E1D, %fusion.side1 ]
  %749 = phi double [ 0xBF267FDAD7E340C0, %fusion.side ], [ 0xBED9332B494FD162, %fusion.side1 ]
  %750 = phi double [ 0x3E10954573CD1409, %fusion.side ], [ 0x3DA028AD2F8C812A, %fusion.side1 ]
  %751 = phi double [ 0x3C4C7C5BAC69CA30, %fusion.side ], [ 0x3BDBA8610FC6ED80, %fusion.side1 ]
  %752 = phi double [ 0xBDEF4147E6D836F1, %fusion.side ], [ 0xBDA09F2D7C5D35C1, %fusion.side1 ]
  %753 = phi double [ 0x3D42DFCD4EC1917B, %fusion.side ], [ 0x3CE3BA542B23A837, %fusion.side1 ]
  %754 = phi double [ 0xBE80201FEE58D5EB, %fusion.side ], [ 0xBE4167CB2DE9484D, %fusion.side1 ]
  %755 = phi double [ 0xBEFCEEB9D33660E7, %fusion.side ], [ 0xBECFA9C0D9C5E4A9, %fusion.side1 ]
  %756 = phi double [ 0xBF69297448457D24, %fusion.side ], [ 0xBF4BE8F64D9A4925, %fusion.side1 ]
  %757 = phi double [ 0xBFC4DA929BC925CB, %fusion.side ], [ 0xBFB77177F6F25868, %fusion.side1 ]
  %758 = phi double [ 0xC00A6041983C62F2, %fusion.side ], [ 0xC00E0DA8FADB7C8C, %fusion.side1 ]
  %759 = phi double [ 0x3D18B1987155CEA4, %fusion.side ], [ 0x3CB8106C9C12C679, %fusion.side1 ]
  %760 = phi double [ 0x3E5C80E1BF396002, %fusion.side ], [ 0x3E1C00B930B6EDE4, %fusion.side1 ]
  %761 = phi double [ 0x3DC87E4D72BFB8FA, %fusion.side ], [ 0x3D77F69D5EF2EF55, %fusion.side1 ]
  %762 = phi double [ 0x3EDC231F3DEEB6F9, %fusion.side ], [ 0x3EABC3297454E377, %fusion.side1 ]
  %763 = phi double [ 0x3F4A8E38348FD9B2, %fusion.side ], [ 0x3F2A514E711D09AD, %fusion.side1 ]
  %764 = phi double [ 0x3FA7ABC63BB9671C, %fusion.side ], [ 0x3F97906FA7E2C9CF, %fusion.side1 ]
  %fusion.paired2 = phi <2 x double> [ %716, %fusion.side ], [ %720, %fusion.side1 ]
  %fusion.paired3 = phi <2 x double> [ %718, %fusion.side ], [ %722, %fusion.side1 ]
  %765 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %fusion.paired2, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %fusion.paired3) #3
  %766 = extractelement <2 x double> %765, i32 0
  %767 = extractelement <2 x double> %765, i32 1
  %768 = fadd double %766, %767
  %769 = fadd double %567, %768
  %770 = fsub double %769, %567
  %771 = fsub double %768, %770
  %772 = fadd double %769, %566
  %773 = fsub double %772, %566
  %774 = fsub double %773, %772
  %775 = fadd double %774, %566
  %776 = fsub double %769, %773
  %777 = fadd double %776, %775
  %778 = fadd double %771, %777
  %779 = fadd double %772, %778
  %780 = tail call double @llvm.fabs.f64(double %476) #4
  br i1 %cmp84.i.i.i.i, label %merged.branch.split66, label %merged.branch.split67

merged.branch.split66:                            ; preds = %fusion.common
  br i1 %468, label %merged.branch.split54, label %fusion.suffix2

merged.branch.split67:                            ; preds = %fusion.common
  %781 = select i1 %470, double 0x3F877C1A4ABB8039, double 0x3F776DDB0ABF64AF
  %782 = select i1 %470, double 0x3F0A244903F50D45, double 0x3EEA04DE23809639
  %783 = select i1 %470, double 0x3E7B7CAE58B9ECC4, double 0x3E4B4BB19F333FF9
  %784 = select i1 %470, double 0x3D27942AF0BDEC40, double 0x3CD7504574599FA7
  %785 = select i1 %470, double 0x3DDBA32CD8E6FFE2, double 0x3D9B6269284AABC4
  %786 = select i1 %470, double 0x3C579C2A1977500A, double 0x3BF74C460513871A
  %787 = select i1 %470, double 0xC010D5424AFC6707, double 0xC0129EFFBA10F842
  %788 = select i1 %470, double 0xBFAA00AF73AD4FC4, double 0xBF9C8D7861FA32DF
  %789 = select i1 %470, double 0xBF2EA5E4F352FCF9, double 0xBF10B2EEE9D945FC
  %790 = select i1 %470, double 0xBEA134E225D1132C, double 0xBE729A0FDD66F4F2
  %791 = select i1 %470, double 0xBE02B6DCAE997177, double 0xBDC40F84D4D29208
  %792 = select i1 %470, double 0x3C84A9C31CF1706D, double 0x3C25ADBF5D5E2D40
  %793 = select i1 %470, double 0xBD51A9A584540197, double 0xBD02C12978DF0869
  %794 = select i1 %470, double 0x3B6B104CE845D8CA, double 0x3AFAA825FA80AEBC
  %795 = fcmp oeq double %780, 0x7FF0000000000000
  %796 = select i1 %795, double %476, double %779
  %797 = fcmp olt double %476, 0.000000e+00
  %798 = select i1 %797, double 0x7FF8000000000000, double %796
  %799 = fcmp oeq double %476, 0.000000e+00
  %800 = select i1 %799, double 0xFFF0000000000000, double %798
  %801 = fmul double %800, %800
  %802 = fmul double %801, %794
  %803 = fsub double %793, %802
  %804 = fmul double %801, %792
  %805 = fsub double %791, %804
  %806 = fmul double %801, %803
  %807 = fmul double %801, %805
  %808 = fadd double %806, %790
  %809 = fadd double %807, %789
  %810 = fmul double %801, %808
  %811 = fmul double %801, %809
  %812 = fadd double %810, %788
  %813 = fadd double %811, %787
  %814 = fmul double %800, %812
  %815 = fsub double %813, %814
  %816 = fmul double %801, %786
  %817 = fadd double %816, %785
  %818 = fmul double %801, %784
  %819 = fadd double %818, %783
  %820 = fmul double %801, %817
  %821 = fmul double %801, %819
  %822 = fadd double %820, %782
  %823 = fadd double %821, %781
  %824 = fmul double %801, %822
  %825 = fadd double %824, 1.000000e+00
  %826 = fmul double %800, %823
  %827 = fsub double %825, %826
  %828 = fdiv double %815, %827
  br label %_ZN5boost4math6detail24landau_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

merged.bb35:                                      ; preds = %merged.branch.split78, %merged.bb67
  %829 = phi double [ 0x3E5572883C081004, %merged.bb67 ], [ 0x3DFAC4B4389CCCBF, %merged.branch.split78 ]
  %830 = phi double [ 0x3EF19780C67DB179, %merged.bb67 ], [ 0x3EA390F0E916846C, %merged.branch.split78 ]
  %831 = phi double [ 0x3EAD6D38A29E7848, %merged.bb67 ], [ 0x3E3DBF605CEF30C0, %merged.branch.split78 ]
  %832 = phi double [ 0x3F3931D0B31857FC, %merged.bb67 ], [ 0x3EF49382D31EBA5E, %merged.branch.split78 ]
  %833 = phi double [ 0x3F6DC47CA5637DCD, %merged.bb67 ], [ 0x3F391B9374A4479C, %merged.branch.split78 ]
  %834 = phi double [ 0x3F9D4AC2F9914DE6, %merged.bb67 ], [ 0x3F756FF813B95713, %merged.branch.split78 ]
  %835 = phi double [ 0x3FC0EDB6A0343FA2, %merged.bb67 ], [ 0x3FA7D057D85283A0, %merged.branch.split78 ]
  %836 = phi double [ 0x3FDB50BA04B5A380, %merged.bb67 ], [ 0x3FD02ACAC9630F2A, %merged.branch.split78 ]
  %837 = phi double [ 0x3FE698C26DDFFE1D, %merged.bb67 ], [ 0x3FE4BE220CFACC02, %merged.branch.split78 ]
  %838 = phi double [ 0x3E5DE5C0706A9406, %merged.bb67 ], [ 0x3E04EA9B9D5ED2D3, %merged.branch.split78 ]
  %839 = phi double [ 0x3F004FBC687921D1, %merged.bb67 ], [ 0x3EAF46C18AB8D809, %merged.branch.split78 ]
  %840 = phi double [ 0x3EB3C06C21CA66A9, %merged.bb67 ], [ 0x3E46A463B527030B, %merged.branch.split78 ]
  %841 = phi double [ 0x3F41E908A5D59DEF, %merged.bb67 ], [ 0x3EFFDAE904854CF0, %merged.branch.split78 ]
  %842 = phi double [ 0x3F78B07BF251DF23, %merged.bb67 ], [ 0x3F43F5B84727219B, %merged.branch.split78 ]
  %843 = phi double [ 0x3FA6C0CF25D026FF, %merged.bb67 ], [ 0x3F80B3A886D078D5, %merged.branch.split78 ]
  %844 = phi double [ 0x3FCB01CF712825D2, %merged.bb67 ], [ 0x3FB2BDAF5E161D54, %merged.branch.split78 ]
  %845 = phi double [ 0x3FE41A23912FC356, %merged.bb67 ], [ 0x3FD98FFFB01689E6, %merged.branch.split78 ]
  %846 = phi double [ 0x3FE460008BE31186, %merged.bb67 ], [ 0x3FE45F306F7BD51E, %merged.branch.split78 ]
  %847 = phi double [ %904, %merged.bb67 ], [ %907, %merged.branch.split78 ]
  %848 = phi double [ 0x3DF328AAD4028837, %merged.bb67 ], [ 0x3E41C5A32EBEB036, %merged.branch.split78 ]
  %849 = phi double [ 0x3EA816907A00ED43, %merged.bb67 ], [ 0x3ED2C03A84AD3954, %merged.branch.split78 ]
  %850 = phi double [ 0x3E53EB10DB8936AA, %merged.bb67 ], [ 0x3E842875EC14B32B, %merged.branch.split78 ]
  %851 = phi double [ 0x3EF409E2C6442ECB, %merged.bb67 ], [ 0x3F1404C590EDED62, %merged.branch.split78 ]
  %852 = phi double [ 0x3F383DD0A4891FC2, %merged.bb67 ], [ 0x3F51B33174D75BD6, %merged.branch.split78 ]
  %853 = phi double [ 0x3F75579E42D43198, %merged.bb67 ], [ 0x3F8752E2DAA7BC3C, %merged.branch.split78 ]
  %854 = phi double [ 0x3FAA6202C31DEDAF, %merged.bb67 ], [ 0x3FB61BE1285F7AC2, %merged.branch.split78 ]
  %855 = phi double [ 0x3FD4C357E0FB8D40, %merged.bb67 ], [ 0x3FDAF9DE32D5716C, %merged.branch.split78 ]
  br i1 %cmp41.i.i.i.i, label %merged.branch.split39, label %merged.branch.split40

merged.branch.split39:                            ; preds = %merged.bb35
  %856 = fcmp oeq double %292, 0x7FF0000000000000
  %857 = select i1 %856, double %179, double %291
  %858 = fcmp olt double %179, 0.000000e+00
  %859 = select i1 %858, double 0x7FF8000000000000, double %857
  %860 = fcmp oeq double %179, 0.000000e+00
  %861 = select i1 %860, double 0xFFF0000000000000, double %859
  %862 = fmul double %861, %861
  %863 = fmul double %862, %829
  %864 = fsub double %830, %863
  %865 = fmul double %862, %831
  %866 = fadd double %865, %832
  %867 = fmul double %862, %864
  %868 = fmul double %862, %866
  %869 = fadd double %867, %833
  %870 = fadd double %868, %834
  %871 = fmul double %862, %869
  %872 = fmul double %862, %870
  %873 = fadd double %871, %835
  %874 = fadd double %872, %836
  %875 = fmul double %862, %873
  %876 = fmul double %862, %838
  %877 = fsub double %839, %876
  br label %fusion.suffix3

merged.branch.split40:                            ; preds = %merged.bb35
  %878 = fmul double %903, %848
  %879 = fadd double %878, %849
  br label %fusion.suffix3

merged.bb66:                                      ; preds = %decision.dispatch2
  %880 = fcmp oeq double %292, 0x7FF0000000000000
  %881 = select i1 %880, double %179, double %291
  %882 = fcmp olt double %179, 0.000000e+00
  %883 = select i1 %882, double 0x7FF8000000000000, double %881
  %884 = fcmp oeq double %179, 0.000000e+00
  %885 = select i1 %884, double 0xFFF0000000000000, double %883
  %886 = fmul double %885, %885
  %merged.select68 = select i1 %177, double 0x3C79498433579691, double 0x3E36A0C73E300E6B
  %887 = fmul double %886, %merged.select68
  %888 = fsub double 0x3E495C1E8002A2F3, %887
  %889 = fadd double %887, 0x3EC7DFD742A8FC88
  %guard.result = select i1 %177, double %888, double %889
  %merged.select69 = select i1 %177, double 0x3DE864F7A333A155, double 0x3E79AA80A6F64859
  %890 = fmul double %886, %merged.select69
  %merged.select70 = select i1 %177, double 0x3E9EABE0F5513556, double 0x3F097D0FE1D7D8F2
  %891 = fadd double %890, %merged.select70
  %892 = fmul double %886, %guard.result
  %893 = fmul double %886, %891
  %merged.select72 = select i1 %177, double 0x3EE98327A9C0F60B, double 0x3F46894B5AD794D5
  %894 = fadd double %892, %merged.select72
  %merged.select73 = select i1 %177, double 0x3F2EDE27BF6E2989, double 0x3F7DB25E4C9E7FD4
  %895 = fadd double %893, %merged.select73
  %896 = fmul double %886, %894
  %897 = fmul double %886, %895
  %merged.select74 = select i1 %177, double 0x3F6B2BC23526CCD2, double 0x3FAC2661E760FEEA
  %898 = fadd double %896, %merged.select74
  %merged.select75 = select i1 %177, double 0x3FA0CC4805CE702A, double 0x3FD12C697DF74133
  %899 = fadd double %897, %merged.select75
  %900 = fmul double %886, %898
  %merged.select76 = select i1 %177, double %899, double %898
  %901 = fmul double %886, %merged.select76
  %.op = fadd double %900, 0x3FCA6EBA13EF1190
  %902 = select i1 %177, double %.op, double undef
  br label %merged.bb67

merged.bb67:                                      ; preds = %merged.bb66, %decision.dispatch2
  %903 = phi double [ undef, %decision.dispatch2 ], [ %886, %merged.bb66 ]
  %904 = phi double [ undef, %decision.dispatch2 ], [ %902, %merged.bb66 ]
  %905 = phi double [ undef, %decision.dispatch2 ], [ %885, %merged.bb66 ]
  %906 = phi double [ undef, %decision.dispatch2 ], [ %901, %merged.bb66 ]
  %907 = phi double [ undef, %decision.dispatch2 ], [ %899, %merged.bb66 ]
  br i1 %177, label %merged.bb35, label %merged.branch.split78

merged.branch.split78:                            ; preds = %merged.bb67
  br label %merged.bb35
}

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.frexp.mant.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.ldexp.f64(double, i32) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.frexp.exp.i32.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rcp.f64(double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fma.v2f64(<2 x double>, <2 x double>, <2 x double>) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #1

attributes #0 = { convergent norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="128" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nounwind readnone speculatable willreturn }
attributes #2 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }
attributes #4 = { nounwind readnone }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/charitha22/cgo22ae-darm-code.git e9bc0540325ad9806313d34e84fc901496fd8be6)"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i16 1, i16 1025}
!6 = !{}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = !{!"if.then20.i.i.i.i", !"if.else75.i.i.i.i"}
!13 = !{!"evaluate:%if.then3.i27.i.i.i", !"evaluate:%if.then11.i33.i.i.i"}
!14 = !{!"merge(evaluate:%if.then3.i27.i.i.i,evaluate:%if.then11.i33.i.i.i)"}
