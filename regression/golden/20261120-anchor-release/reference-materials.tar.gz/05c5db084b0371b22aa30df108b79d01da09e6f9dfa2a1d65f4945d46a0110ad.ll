; ModuleID = '/data/home/chh/simplify-v2/build/simplify-fingerprint/inputs/MS32.ll'
source_filename = "/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-benchmarks/benchmarks/MS/mergesort.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

%struct.__HIP_Coordinates = type { i8 }
%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z" = type { i8 }
%struct.__HIP_Coordinates.0 = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z" = type { i8 }
%struct.dim3 = type { i32, i32, i32 }
%struct.__HIP_ThreadIdx = type { i8 }
%struct.__HIP_BlockIdx = type { i8 }

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1yE = comdat any

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1zE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1yE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1zE = comdat any

@.str = private unnamed_addr addrspace(4) constant [47 x i8] c"%s:%u: %s: Device-side assertion `%s' failed.\0A\00", align 1
@_ZL9threadIdx = internal addrspace(4) constant %struct.__HIP_Coordinates undef, align 1
@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1yE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1zE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z" undef, comdat, align 1
@_ZL8blockIdx = internal addrspace(4) constant %struct.__HIP_Coordinates.0 undef, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1yE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1zE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z" undef, comdat, align 1

; Function Attrs: convergent noinline nounwind
define weak hidden void @__assert_fail(i8* %0, i8* %1, i32 %2, i8* %3) #0 {
  %5 = alloca i8*, align 8, addrspace(5)
  %6 = addrspacecast i8* addrspace(5)* %5 to i8**
  %7 = alloca i8*, align 8, addrspace(5)
  %8 = addrspacecast i8* addrspace(5)* %7 to i8**
  %9 = alloca i32, align 4, addrspace(5)
  %10 = addrspacecast i32 addrspace(5)* %9 to i32*
  %11 = alloca i8*, align 8, addrspace(5)
  %12 = addrspacecast i8* addrspace(5)* %11 to i8**
  store i8* %0, i8** %6, align 8
  store i8* %1, i8** %8, align 8
  store i32 %2, i32* %10, align 4
  store i8* %3, i8** %12, align 8
  call void @_ZL6printfIJPKcjS1_S1_EEvS1_DpT_(i8* getelementptr inbounds ([47 x i8], [47 x i8]* addrspacecast ([47 x i8] addrspace(4)* @.str to [47 x i8]*), i64 0, i64 0), i8* %1, i32 %2, i8* %3, i8* %0) #6
  call void @llvm.trap()
  ret void
}

; Function Attrs: convergent noinline nounwind
define internal void @_ZL6printfIJPKcjS1_S1_EEvS1_DpT_(i8* %0, i8* %1, i32 %2, i8* %3, i8* %4) #0 {
  %6 = alloca i8*, align 8, addrspace(5)
  %7 = addrspacecast i8* addrspace(5)* %6 to i8**
  %8 = alloca i8*, align 8, addrspace(5)
  %9 = addrspacecast i8* addrspace(5)* %8 to i8**
  %10 = alloca i32, align 4, addrspace(5)
  %11 = addrspacecast i32 addrspace(5)* %10 to i32*
  %12 = alloca i8*, align 8, addrspace(5)
  %13 = addrspacecast i8* addrspace(5)* %12 to i8**
  %14 = alloca i8*, align 8, addrspace(5)
  %15 = addrspacecast i8* addrspace(5)* %14 to i8**
  store i8* %0, i8** %7, align 8
  store i8* %1, i8** %9, align 8
  store i32 %2, i32* %11, align 4
  store i8* %3, i8** %13, align 8
  store i8* %4, i8** %15, align 8
  ret void
}

; Function Attrs: cold noreturn nounwind
declare void @llvm.trap() #1

; Function Attrs: convergent noinline nounwind
define weak hidden void @__assertfail(i8* %0, i8* %1, i32 %2, i8* %3, i64 %4) #0 {
  %6 = alloca i8*, align 8, addrspace(5)
  %7 = addrspacecast i8* addrspace(5)* %6 to i8**
  %8 = alloca i8*, align 8, addrspace(5)
  %9 = addrspacecast i8* addrspace(5)* %8 to i8**
  %10 = alloca i32, align 4, addrspace(5)
  %11 = addrspacecast i32 addrspace(5)* %10 to i32*
  %12 = alloca i8*, align 8, addrspace(5)
  %13 = addrspacecast i8* addrspace(5)* %12 to i8**
  %14 = alloca i64, align 8, addrspace(5)
  %15 = addrspacecast i64 addrspace(5)* %14 to i64*
  store i8* %0, i8** %7, align 8
  store i8* %1, i8** %9, align 8
  store i32 %2, i32* %11, align 4
  store i8* %3, i8** %13, align 8
  store i64 %4, i64* %15, align 8
  call void @llvm.trap()
  ret void
}

; Function Attrs: alwaysinline convergent nounwind
define hidden i32 @_Z6getIdxP4dim3S0_(%struct.dim3* %0, %struct.dim3* %1) #2 {
  %3 = alloca %struct.__HIP_ThreadIdx*, align 8, addrspace(5)
  %4 = alloca i32, align 4, addrspace(5)
  %5 = alloca %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"*, align 8, addrspace(5)
  %6 = alloca %struct.__HIP_ThreadIdx, align 1, addrspace(5)
  %7 = alloca %struct.__HIP_ThreadIdx*, align 8, addrspace(5)
  %8 = alloca i32, align 4, addrspace(5)
  %9 = alloca %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"*, align 8, addrspace(5)
  %10 = alloca %struct.__HIP_ThreadIdx, align 1, addrspace(5)
  %11 = alloca %struct.__HIP_BlockIdx*, align 8, addrspace(5)
  %12 = alloca i32, align 4, addrspace(5)
  %13 = alloca %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"*, align 8, addrspace(5)
  %14 = alloca %struct.__HIP_BlockIdx, align 1, addrspace(5)
  %15 = alloca %struct.__HIP_BlockIdx*, align 8, addrspace(5)
  %16 = alloca i32, align 4, addrspace(5)
  %17 = alloca %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"*, align 8, addrspace(5)
  %18 = alloca %struct.__HIP_BlockIdx, align 1, addrspace(5)
  %19 = alloca %struct.__HIP_BlockIdx*, align 8, addrspace(5)
  %20 = alloca i32, align 4, addrspace(5)
  %21 = alloca %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"*, align 8, addrspace(5)
  %22 = alloca %struct.__HIP_BlockIdx, align 1, addrspace(5)
  %23 = alloca %struct.__HIP_ThreadIdx*, align 8, addrspace(5)
  %24 = alloca i32, align 4, addrspace(5)
  %25 = alloca %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"*, align 8, addrspace(5)
  %26 = alloca %struct.__HIP_ThreadIdx, align 1, addrspace(5)
  %27 = alloca %struct.dim3*, align 8, addrspace(5)
  %28 = addrspacecast %struct.dim3* addrspace(5)* %27 to %struct.dim3**
  %29 = alloca %struct.dim3*, align 8, addrspace(5)
  %30 = addrspacecast %struct.dim3* addrspace(5)* %29 to %struct.dim3**
  %31 = alloca i32, align 4, addrspace(5)
  %32 = addrspacecast i32 addrspace(5)* %31 to i32*
  store %struct.dim3* %0, %struct.dim3** %28, align 8
  store %struct.dim3* %1, %struct.dim3** %30, align 8
  %33 = bitcast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"* addrspace(5)* %25 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %33)
  %34 = bitcast %struct.__HIP_ThreadIdx addrspace(5)* %26 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %34)
  %35 = addrspacecast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"* addrspace(5)* %25 to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"**
  %36 = addrspacecast %struct.__HIP_ThreadIdx addrspace(5)* %26 to %struct.__HIP_ThreadIdx*
  store %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" addrspace(4)* @_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"*), %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"** %35, align 8
  %37 = bitcast %struct.__HIP_ThreadIdx* addrspace(5)* %23 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %37) #7
  %38 = bitcast i32 addrspace(5)* %24 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %38) #7
  %39 = addrspacecast %struct.__HIP_ThreadIdx* addrspace(5)* %23 to %struct.__HIP_ThreadIdx**
  %40 = addrspacecast i32 addrspace(5)* %24 to i32*
  store %struct.__HIP_ThreadIdx* %36, %struct.__HIP_ThreadIdx** %39, align 8
  store i32 0, i32* %40, align 4
  %41 = call i32 @llvm.amdgcn.workitem.id.x() #7, !range !5
  %42 = zext i32 %41 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %37) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %38) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %33)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %34)
  %43 = bitcast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"* addrspace(5)* %5 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %43)
  %44 = bitcast %struct.__HIP_ThreadIdx addrspace(5)* %6 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %44)
  %45 = addrspacecast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"* addrspace(5)* %5 to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"**
  %46 = addrspacecast %struct.__HIP_ThreadIdx addrspace(5)* %6 to %struct.__HIP_ThreadIdx*
  store %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y" addrspace(4)* @_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1yE to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"*), %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"** %45, align 8
  %47 = bitcast %struct.__HIP_ThreadIdx* addrspace(5)* %3 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %47) #7
  %48 = bitcast i32 addrspace(5)* %4 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %48) #7
  %49 = addrspacecast %struct.__HIP_ThreadIdx* addrspace(5)* %3 to %struct.__HIP_ThreadIdx**
  %50 = addrspacecast i32 addrspace(5)* %4 to i32*
  store %struct.__HIP_ThreadIdx* %46, %struct.__HIP_ThreadIdx** %49, align 8
  store i32 1, i32* %50, align 4
  %51 = call i32 @llvm.amdgcn.workitem.id.y() #7, !range !5
  %52 = zext i32 %51 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %47) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %48) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %43)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %44)
  %53 = getelementptr inbounds %struct.dim3, %struct.dim3* %0, i32 0, i32 0
  %54 = load i32, i32* %53, align 4
  store i32 %54, i32* %32, align 4
  %55 = mul i32 %51, %54
  %56 = add i32 %41, %55
  %57 = bitcast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"* addrspace(5)* %9 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %57)
  %58 = bitcast %struct.__HIP_ThreadIdx addrspace(5)* %10 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %58)
  %59 = addrspacecast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"* addrspace(5)* %9 to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"**
  %60 = addrspacecast %struct.__HIP_ThreadIdx addrspace(5)* %10 to %struct.__HIP_ThreadIdx*
  store %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z" addrspace(4)* @_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1zE to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"*), %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"** %59, align 8
  %61 = bitcast %struct.__HIP_ThreadIdx* addrspace(5)* %7 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %61) #7
  %62 = bitcast i32 addrspace(5)* %8 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %62) #7
  %63 = addrspacecast %struct.__HIP_ThreadIdx* addrspace(5)* %7 to %struct.__HIP_ThreadIdx**
  %64 = addrspacecast i32 addrspace(5)* %8 to i32*
  store %struct.__HIP_ThreadIdx* %60, %struct.__HIP_ThreadIdx** %63, align 8
  store i32 2, i32* %64, align 4
  %65 = call i32 @llvm.amdgcn.workitem.id.z() #7, !range !5
  %66 = zext i32 %65 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %61) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %62) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %57)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %58)
  %67 = getelementptr inbounds %struct.dim3, %struct.dim3* %0, i32 0, i32 1
  %68 = load i32, i32* %67, align 4
  %69 = mul i32 %54, %68
  store i32 %69, i32* %32, align 4
  %70 = mul i32 %65, %69
  %71 = add i32 %56, %70
  %72 = bitcast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"* addrspace(5)* %13 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %72)
  %73 = bitcast %struct.__HIP_BlockIdx addrspace(5)* %14 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %73)
  %74 = addrspacecast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"* addrspace(5)* %13 to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"**
  %75 = addrspacecast %struct.__HIP_BlockIdx addrspace(5)* %14 to %struct.__HIP_BlockIdx*
  store %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" addrspace(4)* @_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"*), %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"** %74, align 8
  %76 = bitcast %struct.__HIP_BlockIdx* addrspace(5)* %11 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %76) #7
  %77 = bitcast i32 addrspace(5)* %12 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %77) #7
  %78 = addrspacecast %struct.__HIP_BlockIdx* addrspace(5)* %11 to %struct.__HIP_BlockIdx**
  %79 = addrspacecast i32 addrspace(5)* %12 to i32*
  store %struct.__HIP_BlockIdx* %75, %struct.__HIP_BlockIdx** %78, align 8
  store i32 0, i32* %79, align 4
  %80 = call i32 @llvm.amdgcn.workgroup.id.x() #7
  %81 = zext i32 %80 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %76) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %77) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %72)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %73)
  %82 = getelementptr inbounds %struct.dim3, %struct.dim3* %0, i32 0, i32 2
  %83 = load i32, i32* %82, align 4
  %84 = mul i32 %69, %83
  store i32 %84, i32* %32, align 4
  %85 = mul i32 %80, %84
  %86 = add i32 %71, %85
  %87 = bitcast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"* addrspace(5)* %17 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %87)
  %88 = bitcast %struct.__HIP_BlockIdx addrspace(5)* %18 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %88)
  %89 = addrspacecast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"* addrspace(5)* %17 to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"**
  %90 = addrspacecast %struct.__HIP_BlockIdx addrspace(5)* %18 to %struct.__HIP_BlockIdx*
  store %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y" addrspace(4)* @_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1yE to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"*), %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"** %89, align 8
  %91 = bitcast %struct.__HIP_BlockIdx* addrspace(5)* %15 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %91) #7
  %92 = bitcast i32 addrspace(5)* %16 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %92) #7
  %93 = addrspacecast %struct.__HIP_BlockIdx* addrspace(5)* %15 to %struct.__HIP_BlockIdx**
  %94 = addrspacecast i32 addrspace(5)* %16 to i32*
  store %struct.__HIP_BlockIdx* %90, %struct.__HIP_BlockIdx** %93, align 8
  store i32 1, i32* %94, align 4
  %95 = call i32 @llvm.amdgcn.workgroup.id.y() #7
  %96 = zext i32 %95 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %91) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %92) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %87)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %88)
  %97 = getelementptr inbounds %struct.dim3, %struct.dim3* %1, i32 0, i32 2
  %98 = load i32, i32* %97, align 4
  %99 = mul i32 %84, %98
  store i32 %99, i32* %32, align 4
  %100 = mul i32 %95, %99
  %101 = add i32 %86, %100
  %102 = bitcast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"* addrspace(5)* %21 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %102)
  %103 = bitcast %struct.__HIP_BlockIdx addrspace(5)* %22 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %103)
  %104 = addrspacecast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"* addrspace(5)* %21 to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"**
  %105 = addrspacecast %struct.__HIP_BlockIdx addrspace(5)* %22 to %struct.__HIP_BlockIdx*
  store %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z" addrspace(4)* @_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1zE to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"*), %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"** %104, align 8
  %106 = bitcast %struct.__HIP_BlockIdx* addrspace(5)* %19 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %106) #7
  %107 = bitcast i32 addrspace(5)* %20 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %107) #7
  %108 = addrspacecast %struct.__HIP_BlockIdx* addrspace(5)* %19 to %struct.__HIP_BlockIdx**
  %109 = addrspacecast i32 addrspace(5)* %20 to i32*
  store %struct.__HIP_BlockIdx* %105, %struct.__HIP_BlockIdx** %108, align 8
  store i32 2, i32* %109, align 4
  %110 = call i32 @llvm.amdgcn.workgroup.id.z() #7
  %111 = zext i32 %110 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %106) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %107) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %102)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %103)
  %112 = getelementptr inbounds %struct.dim3, %struct.dim3* %1, i32 0, i32 1
  %113 = load i32, i32* %112, align 4
  %114 = mul i32 %99, %113
  store i32 %114, i32* %32, align 4
  %115 = mul i32 %110, %114
  %116 = add i32 %101, %115
  ret i32 %116
}

; Function Attrs: convergent noinline norecurse nounwind
define protected amdgpu_kernel void @_Z13gpu_mergesortPlS_lllP4dim3S1_(i64 addrspace(1)* %0, i64 addrspace(1)* %1, i64 %2, i64 %3, i64 %4, %struct.dim3 addrspace(1)* %5, %struct.dim3 addrspace(1)* %6) #3 {
  %8 = alloca i64, align 8, addrspace(5)
  %9 = addrspacecast i64 addrspace(5)* %8 to i64*
  %10 = alloca i64, align 8, addrspace(5)
  %11 = addrspacecast i64 addrspace(5)* %10 to i64*
  %12 = addrspacecast i64 addrspace(1)* %0 to i64*
  %13 = addrspacecast i64 addrspace(1)* %1 to i64*
  %14 = addrspacecast %struct.dim3 addrspace(1)* %5 to %struct.dim3*
  %15 = addrspacecast %struct.dim3 addrspace(1)* %6 to %struct.dim3*
  %16 = call i32 @llvm.amdgcn.workitem.id.x() #7, !range !5
  %17 = call i32 @llvm.amdgcn.workitem.id.y() #7, !range !5
  %18 = getelementptr inbounds %struct.dim3, %struct.dim3* %14, i64 0, i32 0
  %19 = load i32, i32* %18, align 4
  %20 = mul i32 %17, %19
  %21 = add i32 %16, %20
  %22 = call i32 @llvm.amdgcn.workitem.id.z() #7, !range !5
  %23 = getelementptr inbounds %struct.dim3, %struct.dim3* %14, i64 0, i32 1
  %24 = load i32, i32* %23, align 4
  %25 = mul i32 %19, %24
  %26 = mul i32 %22, %25
  %27 = add i32 %21, %26
  %28 = call i32 @llvm.amdgcn.workgroup.id.x() #7
  %29 = getelementptr inbounds %struct.dim3, %struct.dim3* %14, i64 0, i32 2
  %30 = load i32, i32* %29, align 4
  %31 = mul i32 %25, %30
  %32 = mul i32 %28, %31
  %33 = add i32 %27, %32
  %34 = call i32 @llvm.amdgcn.workgroup.id.y() #7
  %35 = getelementptr inbounds %struct.dim3, %struct.dim3* %15, i64 0, i32 2
  %36 = load i32, i32* %35, align 4
  %37 = mul i32 %31, %36
  %38 = mul i32 %34, %37
  %39 = add i32 %33, %38
  %40 = call i32 @llvm.amdgcn.workgroup.id.z() #7
  %41 = getelementptr inbounds %struct.dim3, %struct.dim3* %15, i64 0, i32 1
  %42 = load i32, i32* %41, align 4
  %43 = mul i32 %37, %42
  %44 = mul i32 %40, %43
  %45 = add i32 %39, %44
  %46 = zext i32 %45 to i64
  %47 = mul nsw i64 %46, %3
  %48 = mul nsw i64 %47, %4
  br label %49

49:                                               ; preds = %104, %7
  %50 = phi i64* [ %13, %7 ], [ %68, %104 ]
  %51 = phi i64* [ %12, %7 ], [ %69, %104 ]
  %52 = phi i64* [ %12, %7 ], [ %72, %104 ]
  %53 = phi i64 [ %2, %7 ], [ %65, %104 ]
  %54 = phi i64 [ %48, %7 ], [ %63, %104 ]
  %55 = phi i64 [ 0, %7 ], [ %105, %104 ]
  %56 = icmp slt i64 %55, %4
  br i1 %56, label %57, label %106

57:                                               ; preds = %49
  %.not = icmp slt i64 %54, %53
  br i1 %.not, label %58, label %106

58:                                               ; preds = %57
  %59 = ashr i64 %3, 1
  %60 = add nsw i64 %54, %59
  %61 = icmp slt i64 %60, %53
  %62 = select i1 %61, i64 %60, i64 %53
  %63 = add nsw i64 %54, %3
  %64 = icmp slt i64 %63, %53
  %65 = select i1 %64, i64 %53, i64 %2
  %66 = select i1 %64, i64 %63, i64 %2
  store i64 %54, i64* %9, align 8
  store i64 %62, i64* %11, align 8
  br label %67

67:                                               ; preds = %86, %58
  %68 = phi i64* [ %50, %58 ], [ %95, %86 ]
  %69 = phi i64* [ %51, %58 ], [ %91, %86 ]
  %70 = phi i64 [ %62, %58 ], [ %99, %86 ]
  %71 = phi i64 [ %54, %58 ], [ %100, %86 ]
  %72 = phi i64* [ %52, %58 ], [ %91, %86 ]
  %73 = phi i64 [ %62, %58 ], [ %101, %86 ]
  %74 = phi i64 [ %54, %58 ], [ %102, %86 ]
  %75 = phi i64 [ %54, %58 ], [ %103, %86 ]
  %76 = icmp slt i64 %75, %66
  br i1 %76, label %77, label %104

77:                                               ; preds = %67
  %78 = icmp slt i64 %74, %62
  br i1 %78, label %79, label %86

79:                                               ; preds = %77
  %.not1 = icmp slt i64 %73, %66
  br i1 %.not1, label %80, label %86

80:                                               ; preds = %79
  %81 = getelementptr inbounds i64, i64* %72, i64 %71
  %82 = load i64, i64* %81, align 8
  %83 = getelementptr inbounds i64, i64* %72, i64 %70
  %84 = load i64, i64* %83, align 8
  %85 = icmp slt i64 %82, %84
  br label %86

86:                                               ; preds = %79, %80, %77
  %87 = phi i64 [ %73, %77 ], [ %73, %79 ], [ %70, %80 ]
  %88 = phi i64 [ %74, %77 ], [ %74, %79 ], [ %71, %80 ]
  %89 = phi i1 [ false, %77 ], [ true, %79 ], [ %85, %80 ]
  %90 = freeze i1 %89
  %91 = select i1 %90, i64* %12, i64* %69
  %92 = select i1 %90, i64 %71, i64 %70
  %93 = getelementptr inbounds i64, i64* %91, i64 %92
  %94 = load i64, i64* %93, align 8
  %95 = select i1 %90, i64* %13, i64* %68
  %96 = getelementptr inbounds i64, i64* %95, i64 %75
  store i64 %94, i64* %96, align 8
  %97 = add nsw i64 %92, 1
  %98 = select i1 %90, i64* %9, i64* %11
  store i64 %97, i64* %98, align 8
  %99 = select i1 %90, i64 %70, i64 %97
  %100 = select i1 %90, i64 %97, i64 %71
  %101 = select i1 %90, i64 %87, i64 %97
  %102 = select i1 %90, i64 %97, i64 %88
  %103 = add nsw i64 %75, 1
  br label %67, !llvm.loop !6

104:                                              ; preds = %67
  %105 = add nuw nsw i64 %55, 1
  br label %49, !llvm.loop !8

106:                                              ; preds = %57, %49
  ret void
}

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #4

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.y() #4

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.z() #4

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #4

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.y() #4

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.z() #4

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p5i8(i64 immarg, i8 addrspace(5)* nocapture) #5

; Function Attrs: argmemonly nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p5i8(i64 immarg, i8 addrspace(5)* nocapture) #5

attributes #0 = { convergent noinline nounwind "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="all" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { cold noreturn nounwind }
attributes #2 = { alwaysinline convergent nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="all" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+add-no-carry-insts,+aperture-regs,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+ds-src2-insts,+enable-ds128,+enable-prt-strict-null,+fast-denormal-f32,+fast-fmaf,+flat-address-space,+flat-for-global,+flat-global-insts,+flat-inst-offsets,+flat-scratch-insts,+fma-mix-insts,+fp64,+gcn3-encoding,+gfx7-gfx8-gfx9-insts,+gfx8-insts,+gfx9,+gfx9-insts,+half-rate-64-ops,+image-gather4-d16-bug,+int-clamp-insts,+inv-2pi-inline-imm,+ldsbankcount32,+load-store-opt,+localmemorysize65536,+mad-mac-f32-insts,+promote-alloca,+r128-a16,+s-memrealtime,+s-memtime-inst,+scalar-atomics,+scalar-flat-scratch-insts,+scalar-stores,+sdwa,+sdwa-omod,+sdwa-scalar,+sdwa-sdst,+sramecc-support,+trap-handler,+unaligned-access-mode,+unaligned-buffer-access,+unaligned-ds-access,+vgpr-index-mode,+vop3p,-wavefrontsize16,-wavefrontsize32,+wavefrontsize64,+xnack-support" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #3 = { convergent noinline norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="all" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #4 = { nounwind readnone speculatable willreturn }
attributes #5 = { argmemonly nofree nosync nounwind willreturn }
attributes #6 = { convergent nounwind }
attributes #7 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3}
!opencl.ocl.version = !{!4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!3 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!4 = !{i32 2, i32 0}
!5 = !{i32 0, i32 1024}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
