; ModuleID = 'cases/sw2d/source/flux.hip'
source_filename = "cases/sw2d/source/flux.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7"
target triple = "amdgcn-amd-amdhsa"

%"struct.__HIP_Coordinates<__HIP_BlockDim>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_GridDim>::X" = type { i8 }

$_ZN17__HIP_CoordinatesI14__HIP_BlockDimE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI13__HIP_GridDimE1xE = comdat any

@_ZN17__HIP_CoordinatesI14__HIP_BlockDimE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockDim>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI13__HIP_GridDimE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_GridDim>::X" undef, comdat, align 1

; Function Attrs: nofree norecurse nounwind
define protected amdgpu_kernel void @_Z4fluxPdddPiS_S0_S0_S_S_S_S_S_S_S_S_S_S_S_S_iiiddd(double addrspace(1)* nocapture readonly %0, double %1, double %2, i32 addrspace(1)* nocapture readonly %3, double addrspace(1)* nocapture readonly %4, i32 addrspace(1)* nocapture readonly %5, i32 addrspace(1)* nocapture readonly %6, double addrspace(1)* nocapture readonly %7, double addrspace(1)* nocapture %8, double addrspace(1)* nocapture readonly %9, double addrspace(1)* nocapture readonly %10, double addrspace(1)* nocapture readonly %11, double addrspace(1)* nocapture readonly %12, double addrspace(1)* nocapture readonly %13, double addrspace(1)* nocapture %14, double addrspace(1)* nocapture readonly %15, double addrspace(1)* nocapture readonly %16, double addrspace(1)* nocapture readonly %17, double addrspace(1)* nocapture readnone %18, i32 %19, i32 %20, i32 %21, double %22, double %23, double %24) local_unnamed_addr #0 {
  %26 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %27 = getelementptr inbounds i8, i8 addrspace(4)* %26, i64 12
  %28 = bitcast i8 addrspace(4)* %27 to i32 addrspace(4)*
  %29 = load i32, i32 addrspace(4)* %28, align 4, !tbaa !5
  %30 = getelementptr i8, i8 addrspace(4)* %26, i64 4
  %31 = bitcast i8 addrspace(4)* %30 to i16 addrspace(4)*
  %32 = load i16, i16 addrspace(4)* %31, align 4, !range !14, !invariant.load !15
  %33 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %34 = zext i16 %32 to i32
  %35 = mul i32 %33, %34
  %36 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !16
  %37 = add i32 %35, %36
  %38 = icmp slt i32 %37, %19
  br i1 %38, label %39, label %1048

39:                                               ; preds = %25
  %40 = fdiv double %24, %22
  %41 = fdiv double %24, %23
  %42 = fmul double %1, %2
  %43 = fmul double %42, %2
  %44 = fneg double %40
  %45 = fmul double %1, 2.000000e+00
  %46 = icmp sgt i32 %20, -1
  br label %47

47:                                               ; preds = %39, %1043
  %48 = phi i32 [ %37, %39 ], [ %1046, %1043 ]
  %49 = freeze i32 %48
  %50 = freeze i32 %20
  %51 = sdiv i32 %49, %50
  %52 = mul i32 %51, %50
  %53 = sub i32 %49, %52
  %54 = icmp sgt i32 %51, 0
  %55 = icmp slt i32 %51, %21
  %56 = and i1 %54, %55
  %57 = sext i32 %48 to i64
  br i1 %56, label %58, label %544

58:                                               ; preds = %47
  %59 = getelementptr inbounds i32, i32 addrspace(1)* %3, i64 %57
  %60 = load i32, i32 addrspace(1)* %59, align 4, !tbaa !17
  %61 = icmp eq i32 %60, 0
  br i1 %61, label %544, label %62

62:                                               ; preds = %58
  %63 = sub nsw i32 %48, %20
  %64 = sext i32 %63 to i64
  %65 = getelementptr inbounds i32, i32 addrspace(1)* %3, i64 %64
  %66 = load i32, i32 addrspace(1)* %65, align 4, !tbaa !17
  %67 = icmp eq i32 %66, 0
  br i1 %67, label %544, label %68

68:                                               ; preds = %62
  %69 = getelementptr inbounds double, double addrspace(1)* %4, i64 %64
  %70 = load double, double addrspace(1)* %69, align 8, !tbaa !21
  %71 = load double, double addrspace(1)* %0, align 8, !tbaa !21
  %72 = fcmp ogt double %70, %71
  br i1 %72, label %77, label %73

73:                                               ; preds = %68
  %74 = getelementptr inbounds double, double addrspace(1)* %4, i64 %57
  %75 = load double, double addrspace(1)* %74, align 8, !tbaa !21
  %76 = fcmp ogt double %75, %71
  br i1 %76, label %77, label %544

77:                                               ; preds = %73, %68
  %78 = getelementptr inbounds i32, i32 addrspace(1)* %5, i64 %57
  %79 = load i32, i32 addrspace(1)* %78, align 4, !tbaa !17
  %80 = icmp eq i32 %79, 1
  br i1 %80, label %544, label %81

81:                                               ; preds = %77
  %82 = getelementptr inbounds double, double addrspace(1)* %4, i64 %57
  %83 = load double, double addrspace(1)* %82, align 8, !tbaa !21
  %84 = getelementptr inbounds double, double addrspace(1)* %7, i64 %57
  %85 = load double, double addrspace(1)* %84, align 8, !tbaa !21
  %86 = fadd double %83, %85
  %87 = getelementptr inbounds double, double addrspace(1)* %7, i64 %64
  %88 = load double, double addrspace(1)* %87, align 8, !tbaa !21
  %89 = fsub double %83, %71
  %90 = fsub double %70, %71
  %91 = fcmp olt double %86, %88
  br i1 %91, label %92, label %119

92:                                               ; preds = %81
  br i1 %72, label %93, label %544

93:                                               ; preds = %92
  %94 = fmul double %70, 5.440000e-01
  %95 = fmul double %70, %1
  %96 = fcmp olt double %95, 0x1000000000000000
  %97 = select i1 %96, double 0x4FF0000000000000, double 1.000000e+00
  %98 = fmul double %95, %97
  %99 = tail call double @llvm.amdgcn.rsq.f64(double %98) #3
  %100 = fmul double %98, %99
  %101 = fmul double %99, 5.000000e-01
  %102 = fneg double %101
  %103 = tail call double @llvm.fma.f64(double %102, double %100, double 5.000000e-01) #3
  %104 = tail call double @llvm.fma.f64(double %101, double %103, double %101) #3
  %105 = tail call double @llvm.fma.f64(double %100, double %103, double %100) #3
  %106 = fneg double %105
  %107 = tail call double @llvm.fma.f64(double %106, double %105, double %98) #3
  %108 = tail call double @llvm.fma.f64(double %107, double %104, double %105) #3
  %109 = fneg double %108
  %110 = tail call double @llvm.fma.f64(double %109, double %108, double %98) #3
  %111 = tail call double @llvm.fma.f64(double %110, double %104, double %108) #3
  %112 = select i1 %96, double 0x37F0000000000000, double 1.000000e+00
  %113 = fmul double %112, %111
  %114 = fcmp oeq double %98, 0.000000e+00
  %115 = fcmp oeq double %98, 0x7FF0000000000000
  %116 = or i1 %114, %115
  %117 = select i1 %116, double %98, double %113
  %118 = fmul double %94, %117
  br label %544

119:                                              ; preds = %81
  %120 = fadd double %70, %88
  %121 = fcmp olt double %120, %85
  br i1 %121, label %122, label %150

122:                                              ; preds = %119
  %123 = fcmp ogt double %83, %71
  br i1 %123, label %124, label %544

124:                                              ; preds = %122
  %125 = fmul double %83, -5.440000e-01
  %126 = fmul double %83, %1
  %127 = fcmp olt double %126, 0x1000000000000000
  %128 = select i1 %127, double 0x4FF0000000000000, double 1.000000e+00
  %129 = fmul double %126, %128
  %130 = tail call double @llvm.amdgcn.rsq.f64(double %129) #3
  %131 = fmul double %129, %130
  %132 = fmul double %130, 5.000000e-01
  %133 = fneg double %132
  %134 = tail call double @llvm.fma.f64(double %133, double %131, double 5.000000e-01) #3
  %135 = tail call double @llvm.fma.f64(double %132, double %134, double %132) #3
  %136 = tail call double @llvm.fma.f64(double %131, double %134, double %131) #3
  %137 = fneg double %136
  %138 = tail call double @llvm.fma.f64(double %137, double %136, double %129) #3
  %139 = tail call double @llvm.fma.f64(double %138, double %135, double %136) #3
  %140 = fneg double %139
  %141 = tail call double @llvm.fma.f64(double %140, double %139, double %129) #3
  %142 = tail call double @llvm.fma.f64(double %141, double %135, double %139) #3
  %143 = select i1 %127, double 0x37F0000000000000, double 1.000000e+00
  %144 = fmul double %143, %142
  %145 = fcmp oeq double %129, 0.000000e+00
  %146 = fcmp oeq double %129, 0x7FF0000000000000
  %147 = or i1 %145, %146
  %148 = select i1 %147, double %129, double %144
  %149 = fmul double %125, %148
  br label %544

150:                                              ; preds = %119
  %151 = fmul double %90, %89
  %152 = fcmp olt double %151, 0.000000e+00
  br i1 %152, label %153, label %191

153:                                              ; preds = %150
  %154 = fcmp ogt double %83, 0.000000e+00
  %155 = fcmp ogt double %70, 0.000000e+00
  %156 = or i1 %155, %154
  br i1 %156, label %157, label %544

157:                                              ; preds = %153
  %158 = fsub double %89, %90
  %159 = tail call double @llvm.fabs.f64(double %158) #3
  %160 = tail call double @llvm.maxnum.f64(double %86, double %120) #3
  %161 = tail call double @llvm.maxnum.f64(double %85, double %88) #3
  %162 = fsub double %160, %161
  %163 = fneg double %158
  %164 = fdiv double %163, %159
  %165 = fmul double %164, 3.500000e-01
  %166 = fmul double %165, %162
  %167 = fmul double %45, %162
  %168 = fcmp olt double %167, 0x1000000000000000
  %169 = select i1 %168, double 0x4FF0000000000000, double 1.000000e+00
  %170 = fmul double %167, %169
  %171 = tail call double @llvm.amdgcn.rsq.f64(double %170) #3
  %172 = fmul double %170, %171
  %173 = fmul double %171, 5.000000e-01
  %174 = fneg double %173
  %175 = tail call double @llvm.fma.f64(double %174, double %172, double 5.000000e-01) #3
  %176 = tail call double @llvm.fma.f64(double %173, double %175, double %173) #3
  %177 = tail call double @llvm.fma.f64(double %172, double %175, double %172) #3
  %178 = fneg double %177
  %179 = tail call double @llvm.fma.f64(double %178, double %177, double %170) #3
  %180 = tail call double @llvm.fma.f64(double %179, double %176, double %177) #3
  %181 = fneg double %180
  %182 = tail call double @llvm.fma.f64(double %181, double %180, double %170) #3
  %183 = tail call double @llvm.fma.f64(double %182, double %176, double %180) #3
  %184 = select i1 %168, double 0x37F0000000000000, double 1.000000e+00
  %185 = fmul double %184, %183
  %186 = fcmp oeq double %170, 0.000000e+00
  %187 = fcmp oeq double %170, 0x7FF0000000000000
  %188 = or i1 %186, %187
  %189 = select i1 %188, double %170, double %185
  %190 = fmul double %166, %189
  br label %544

191:                                              ; preds = %150
  %192 = getelementptr inbounds double, double addrspace(1)* %9, i64 %57
  %193 = load double, double addrspace(1)* %192, align 8, !tbaa !21
  %194 = fmul double %193, %1
  %195 = fmul double %40, %194
  %196 = fsub double %86, %70
  %197 = fsub double %196, %88
  %198 = fmul double %197, %195
  %199 = add nsw i32 %48, %20
  %200 = sext i32 %199 to i64
  %201 = getelementptr inbounds double, double addrspace(1)* %10, i64 %200
  %202 = load double, double addrspace(1)* %201, align 8, !tbaa !21
  %203 = getelementptr inbounds double, double addrspace(1)* %10, i64 %57
  %204 = load double, double addrspace(1)* %203, align 8, !tbaa !21
  %205 = fadd double %202, %204
  %206 = fmul double %205, 5.000000e-01
  %207 = getelementptr inbounds double, double addrspace(1)* %10, i64 %64
  %208 = load double, double addrspace(1)* %207, align 8, !tbaa !21
  %209 = fadd double %204, %208
  %210 = fmul double %209, 5.000000e-01
  %211 = getelementptr inbounds double, double addrspace(1)* %11, i64 %200
  %212 = load double, double addrspace(1)* %211, align 8, !tbaa !21
  %213 = getelementptr inbounds double, double addrspace(1)* %11, i64 %57
  %214 = load double, double addrspace(1)* %213, align 8, !tbaa !21
  %215 = fadd double %212, %214
  %216 = fmul double %206, %215
  %217 = fmul double %216, 5.000000e-01
  %218 = tail call double @llvm.fabs.f64(double %206) #3
  %219 = fsub double %214, %212
  %220 = fmul double %218, %219
  %221 = fmul double %220, 5.000000e-01
  %222 = fadd double %217, %221
  %223 = getelementptr inbounds double, double addrspace(1)* %11, i64 %64
  %224 = load double, double addrspace(1)* %223, align 8, !tbaa !21
  %225 = fadd double %214, %224
  %226 = fmul double %210, %225
  %227 = fmul double %226, 5.000000e-01
  %228 = tail call double @llvm.fabs.f64(double %210) #3
  %229 = fsub double %224, %214
  %230 = fmul double %228, %229
  %231 = fmul double %230, 5.000000e-01
  %232 = fadd double %227, %231
  %233 = fsub double %222, %232
  %234 = icmp eq i32 %53, 0
  br i1 %234, label %276, label %235

235:                                              ; preds = %191
  %236 = add nsw i32 %48, 1
  %237 = sext i32 %236 to i64
  %238 = getelementptr inbounds double, double addrspace(1)* %12, i64 %237
  %239 = load double, double addrspace(1)* %238, align 8, !tbaa !21
  %240 = add nsw i32 %63, 1
  %241 = sext i32 %240 to i64
  %242 = getelementptr inbounds double, double addrspace(1)* %12, i64 %241
  %243 = load double, double addrspace(1)* %242, align 8, !tbaa !21
  %244 = fadd double %239, %243
  %245 = fmul double %244, 5.000000e-01
  %246 = getelementptr inbounds double, double addrspace(1)* %12, i64 %57
  %247 = load double, double addrspace(1)* %246, align 8, !tbaa !21
  %248 = getelementptr inbounds double, double addrspace(1)* %12, i64 %64
  %249 = load double, double addrspace(1)* %248, align 8, !tbaa !21
  %250 = fadd double %247, %249
  %251 = fmul double %250, 5.000000e-01
  %252 = getelementptr inbounds double, double addrspace(1)* %11, i64 %237
  %253 = load double, double addrspace(1)* %252, align 8, !tbaa !21
  %254 = fadd double %214, %253
  %255 = fmul double %245, %254
  %256 = fmul double %255, 5.000000e-01
  %257 = tail call double @llvm.fabs.f64(double %245) #3
  %258 = fsub double %214, %253
  %259 = fmul double %257, %258
  %260 = fmul double %259, 5.000000e-01
  %261 = fadd double %256, %260
  %262 = add nsw i32 %48, -1
  %263 = sext i32 %262 to i64
  %264 = getelementptr inbounds double, double addrspace(1)* %11, i64 %263
  %265 = load double, double addrspace(1)* %264, align 8, !tbaa !21
  %266 = fadd double %214, %265
  %267 = fmul double %251, %266
  %268 = fmul double %267, 5.000000e-01
  %269 = tail call double @llvm.fabs.f64(double %251) #3
  %270 = fsub double %265, %214
  %271 = fmul double %269, %270
  %272 = fmul double %271, 5.000000e-01
  %273 = fadd double %268, %272
  %274 = fsub double %261, %273
  %275 = fmul double %41, %274
  br label %276

276:                                              ; preds = %191, %235
  %277 = phi double [ %275, %235 ], [ 0.000000e+00, %191 ]
  %278 = fmul double %204, %204
  %279 = getelementptr inbounds double, double addrspace(1)* %13, i64 %57
  %280 = load double, double addrspace(1)* %279, align 8, !tbaa !21
  %281 = fmul double %280, %280
  %282 = fadd double %278, %281
  %283 = fcmp olt double %282, 0x1000000000000000
  %284 = select i1 %283, double 0x4FF0000000000000, double 1.000000e+00
  %285 = fmul double %282, %284
  %286 = tail call double @llvm.amdgcn.rsq.f64(double %285) #3
  %287 = fmul double %285, %286
  %288 = fmul double %286, 5.000000e-01
  %289 = fneg double %288
  %290 = tail call double @llvm.fma.f64(double %289, double %287, double 5.000000e-01) #3
  %291 = tail call double @llvm.fma.f64(double %288, double %290, double %288) #3
  %292 = tail call double @llvm.fma.f64(double %287, double %290, double %287) #3
  %293 = fneg double %292
  %294 = tail call double @llvm.fma.f64(double %293, double %292, double %285) #3
  %295 = tail call double @llvm.fma.f64(double %294, double %291, double %292) #3
  %296 = fneg double %295
  %297 = tail call double @llvm.fma.f64(double %296, double %295, double %285) #3
  %298 = tail call double @llvm.fma.f64(double %297, double %291, double %295) #3
  %299 = select i1 %283, double 0x37F0000000000000, double 1.000000e+00
  %300 = fmul double %299, %298
  %301 = fcmp oeq double %285, 0.000000e+00
  %302 = fcmp oeq double %285, 0x7FF0000000000000
  %303 = or i1 %301, %302
  %304 = select i1 %303, double %285, double %300
  %305 = tail call double @llvm.fabs.f64(double %193) #3
  %306 = tail call double @llvm.amdgcn.frexp.mant.f64(double %305) #3
  %307 = fcmp olt double %306, 0x3FE5555555555555
  %308 = zext i1 %307 to i32
  %309 = tail call double @llvm.amdgcn.ldexp.f64(double %306, i32 %308) #3
  %310 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %305) #3
  %311 = sub nsw i32 %310, %308
  %312 = fadd double %309, -1.000000e+00
  %313 = fadd double %309, 1.000000e+00
  %314 = fsub double %313, %309
  %315 = fsub double %313, %314
  %316 = fsub double %309, %315
  %317 = fsub double 1.000000e+00, %314
  %318 = fadd double %317, %316
  %319 = tail call double @llvm.amdgcn.rcp.f64(double %313) #3
  %320 = fneg double %313
  %321 = tail call double @llvm.fma.f64(double %320, double %319, double 1.000000e+00) #3
  %322 = tail call double @llvm.fma.f64(double %321, double %319, double %319) #3
  %323 = tail call double @llvm.fma.f64(double %320, double %322, double 1.000000e+00) #3
  %324 = tail call double @llvm.fma.f64(double %323, double %322, double %322) #3
  %325 = fmul double %312, %324
  %326 = fmul double %313, %325
  %327 = fneg double %326
  %328 = tail call double @llvm.fma.f64(double %325, double %313, double %327) #3
  %329 = tail call double @llvm.fma.f64(double %325, double %318, double %328) #3
  %330 = fadd double %326, %329
  %331 = fsub double %330, %326
  %332 = fsub double %329, %331
  %333 = fsub double %312, %330
  %334 = fsub double %312, %333
  %335 = fsub double %334, %330
  %336 = fsub double %335, %332
  %337 = fadd double %333, %336
  %338 = fmul double %324, %337
  %339 = fadd double %325, %338
  %340 = fsub double %339, %325
  %341 = fsub double %338, %340
  %342 = fmul double %339, %339
  %343 = fneg double %342
  %344 = tail call double @llvm.fma.f64(double %339, double %339, double %343) #3
  %345 = fmul double %341, 2.000000e+00
  %346 = tail call double @llvm.fma.f64(double %339, double %345, double %344) #3
  %347 = tail call double @llvm.fma.f64(double %341, double %341, double %346) #3
  %348 = fadd double %342, %347
  %349 = fsub double %348, %342
  %350 = fsub double %347, %349
  %351 = tail call double @llvm.fma.f64(double %348, double 0x3FBDEE674222DE17, double 0x3FBA6564968915A9) #3
  %352 = tail call double @llvm.fma.f64(double %348, double %351, double 0x3FBE25E43ABE935A) #3
  %353 = tail call double @llvm.fma.f64(double %348, double %352, double 0x3FC110EF47E6C9C2) #3
  %354 = tail call double @llvm.fma.f64(double %348, double %353, double 0x3FC3B13BCFA74449) #3
  %355 = tail call double @llvm.fma.f64(double %348, double %354, double 0x3FC745D171BF3C30) #3
  %356 = tail call double @llvm.fma.f64(double %348, double %355, double 0x3FCC71C71C7792CE) #3
  %357 = tail call double @llvm.fma.f64(double %348, double %356, double 0x3FD24924924920DA) #3
  %358 = tail call double @llvm.fma.f64(double %348, double %357, double 0x3FD999999999999C) #3
  %359 = sitofp i32 %311 to double
  %360 = fmul double %359, 0x3FE62E42FEFA39EF
  %361 = fneg double %360
  %362 = tail call double @llvm.fma.f64(double %359, double 0x3FE62E42FEFA39EF, double %361) #3
  %363 = tail call double @llvm.fma.f64(double %359, double 0x3C7ABC9E3B39803F, double %362) #3
  %364 = fadd double %360, %363
  %365 = fsub double %364, %360
  %366 = fsub double %363, %365
  %367 = tail call double @llvm.amdgcn.ldexp.f64(double %339, i32 1) #3
  %368 = tail call double @llvm.amdgcn.ldexp.f64(double %341, i32 1) #3
  %369 = fmul double %339, %348
  %370 = fneg double %369
  %371 = tail call double @llvm.fma.f64(double %348, double %339, double %370) #3
  %372 = fmul double %339, %350
  %373 = tail call double @llvm.fma.f64(double %348, double %341, double %372) #3
  %374 = fadd double %371, %373
  %375 = fadd double %369, %374
  %376 = fsub double %375, %369
  %377 = fsub double %374, %376
  %378 = fmul double %348, %358
  %379 = fneg double %378
  %380 = tail call double @llvm.fma.f64(double %348, double %358, double %379) #3
  %381 = tail call double @llvm.fma.f64(double %350, double %358, double %380) #3
  %382 = fadd double %378, %381
  %383 = fsub double %382, %378
  %384 = fsub double %381, %383
  %385 = fadd double %382, 0x3FE5555555555555
  %386 = fadd double %385, 0xBFE5555555555555
  %387 = fsub double %382, %386
  %388 = fadd double %384, 0x3C8543B0D5DF274D
  %389 = fadd double %387, %388
  %390 = fadd double %385, %389
  %391 = fsub double %390, %385
  %392 = fsub double %389, %391
  %393 = fmul double %375, %390
  %394 = fneg double %393
  %395 = fmul double %377, %390
  %396 = insertelement <2 x double> undef, double %375, i32 0
  %397 = shufflevector <2 x double> %396, <2 x double> undef, <2 x i32> zeroinitializer
  %398 = insertelement <2 x double> undef, double %390, i32 0
  %399 = insertelement <2 x double> %398, double %392, i32 1
  %400 = insertelement <2 x double> undef, double %394, i32 0
  %401 = insertelement <2 x double> %400, double %395, i32 1
  %402 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %397, <2 x double> %399, <2 x double> %401) #3
  %403 = extractelement <2 x double> %402, i32 0
  %404 = extractelement <2 x double> %402, i32 1
  %405 = fadd double %403, %404
  %406 = fadd double %393, %405
  %407 = fsub double %406, %393
  %408 = fsub double %405, %407
  %409 = fadd double %367, %406
  %410 = fsub double %409, %367
  %411 = fsub double %406, %410
  %412 = fadd double %368, %408
  %413 = fadd double %411, %412
  %414 = fadd double %409, %413
  %415 = fsub double %414, %409
  %416 = fsub double %413, %415
  %417 = fadd double %364, %414
  %418 = fsub double %417, %364
  %419 = fsub double %417, %418
  %420 = fsub double %364, %419
  %421 = fsub double %414, %418
  %422 = fadd double %421, %420
  %423 = fadd double %366, %416
  %424 = fsub double %423, %366
  %425 = fsub double %423, %424
  %426 = fsub double %366, %425
  %427 = fsub double %416, %424
  %428 = fadd double %427, %426
  %429 = fadd double %423, %422
  %430 = fadd double %417, %429
  %431 = fsub double %430, %417
  %432 = fsub double %429, %431
  %433 = fadd double %428, %432
  %434 = fadd double %430, %433
  %435 = fsub double %434, %430
  %436 = fsub double %433, %435
  %437 = fmul double %434, 0x3FF55554FBDAD752
  %438 = fneg double %437
  %439 = tail call double @llvm.fma.f64(double %434, double 0x3FF55554FBDAD752, double %438) #3
  %440 = tail call double @llvm.fma.f64(double %436, double 0x3FF55554FBDAD752, double %439) #3
  %441 = fadd double %437, %440
  %442 = fsub double %441, %437
  %443 = fsub double %440, %442
  %444 = tail call double @llvm.fabs.f64(double %437) #4
  %445 = fcmp oeq double %444, 0x7FF0000000000000
  %446 = select i1 %445, double %437, double %441
  %447 = tail call double @llvm.fabs.f64(double %446) #4
  %448 = fcmp oeq double %447, 0x7FF0000000000000
  %449 = select i1 %448, double 0.000000e+00, double %443
  %450 = fmul double %446, 0x3FF71547652B82FE
  %451 = tail call double @llvm.rint.f64(double %450) #3
  %452 = fmul double %451, 0x3FE62E42FEFA3000
  %453 = fsub double %446, %452
  %454 = fsub double %453, %446
  %455 = fsub double %453, %454
  %456 = fsub double %446, %455
  %457 = fadd double %452, %454
  %458 = fsub double %456, %457
  %459 = fadd double %449, %458
  %460 = fadd double %453, %459
  %461 = fsub double %460, %453
  %462 = fsub double %459, %461
  %463 = fmul double %451, 0x3D53DE6AF278E000
  %464 = fsub double %460, %463
  %465 = fsub double %460, %464
  %466 = fsub double %465, %463
  %467 = fadd double %462, %466
  %468 = fadd double %464, %467
  %469 = fsub double %468, %464
  %470 = fsub double %467, %469
  %471 = fmul double %451, 0x3AC9CC01F97B57A0
  %472 = fsub double %468, %471
  %473 = fsub double %468, %472
  %474 = fsub double %473, %471
  %475 = fadd double %470, %474
  %476 = fadd double %472, %475
  %477 = fsub double %476, %472
  %478 = fsub double %475, %477
  %479 = tail call double @llvm.fma.f64(double %476, double 0x3E5ADE156A5DCB37, double 0x3E928AF3FCA7AB0C) #3
  %480 = tail call double @llvm.fma.f64(double %476, double %479, double 0x3EC71DEE623FDE64) #3
  %481 = tail call double @llvm.fma.f64(double %476, double %480, double 0x3EFA01997C89E6B0) #3
  %482 = tail call double @llvm.fma.f64(double %476, double %481, double 0x3F2A01A014761F6E) #3
  %483 = tail call double @llvm.fma.f64(double %476, double %482, double 0x3F56C16C1852B7B0) #3
  %484 = tail call double @llvm.fma.f64(double %476, double %483, double 0x3F81111111122322) #3
  %485 = tail call double @llvm.fma.f64(double %476, double %484, double 0x3FA55555555502A1) #3
  %486 = tail call double @llvm.fma.f64(double %476, double %485, double 0x3FC5555555555511) #3
  %487 = tail call double @llvm.fma.f64(double %476, double %486, double 0x3FE000000000000B) #3
  %488 = fmul double %476, %476
  %489 = fneg double %488
  %490 = tail call double @llvm.fma.f64(double %476, double %476, double %489) #3
  %491 = fmul double %478, 2.000000e+00
  %492 = tail call double @llvm.fma.f64(double %476, double %491, double %490) #3
  %493 = tail call double @llvm.fma.f64(double %478, double %478, double %492) #3
  %494 = fadd double %488, %493
  %495 = fsub double %494, %488
  %496 = fsub double %493, %495
  %497 = fmul double %494, %487
  %498 = fneg double %497
  %499 = tail call double @llvm.fma.f64(double %494, double %487, double %498) #3
  %500 = tail call double @llvm.fma.f64(double %496, double %487, double %499) #3
  %501 = fadd double %497, %500
  %502 = fsub double %501, %497
  %503 = fsub double %500, %502
  %504 = fadd double %476, %501
  %505 = fsub double %504, %476
  %506 = fsub double %501, %505
  %507 = fadd double %478, %503
  %508 = fadd double %506, %507
  %509 = fadd double %504, %508
  %510 = fadd double %509, 1.000000e+00
  %511 = fptosi double %451 to i32
  %512 = tail call double @llvm.amdgcn.ldexp.f64(double %510, i32 %511) #3
  %513 = fcmp ogt double %446, 7.100000e+02
  %514 = select i1 %513, double 0x7FF0000000000000, double %512
  %515 = fcmp olt double %446, -7.450000e+02
  %516 = select i1 %515, double 0.000000e+00, double %514
  %517 = fcmp uno double %193, 0.000000e+00
  %518 = tail call i1 @llvm.amdgcn.class.f64(double %193, i32 512) #3
  %519 = tail call i1 @llvm.amdgcn.class.f64(double %193, i32 4) #3
  %520 = or i1 %518, %519
  %521 = fcmp oeq double %193, 0.000000e+00
  %522 = tail call i1 @llvm.amdgcn.class.f64(double %193, i32 960) #3
  %523 = tail call double @llvm.fabs.f64(double %516) #3
  %524 = select i1 %522, double %523, double 0x7FF8000000000000
  %525 = select i1 %521, double 0.000000e+00, double %524
  %526 = select i1 %520, double 0x7FF0000000000000, double %525
  %527 = select i1 %517, double %193, double %526
  %528 = fcmp oeq double %193, 1.000000e+00
  %529 = select i1 %528, double 1.000000e+00, double %527
  %530 = fmul double %43, %304
  %531 = fdiv double %530, %529
  %532 = fcmp ugt double %193, %71
  %533 = select i1 %532, double %531, double 0.000000e+00
  %534 = fmul double %533, %24
  %535 = fmul double %534, 5.000000e-01
  %536 = fsub double 1.000000e+00, %535
  %537 = fmul double %214, %536
  %538 = fmul double %233, %44
  %539 = fsub double %538, %277
  %540 = fsub double %539, %198
  %541 = fadd double %540, %537
  %542 = fadd double %535, 1.000000e+00
  %543 = fdiv double %541, %542
  br label %544

544:                                              ; preds = %47, %58, %62, %73, %77, %153, %122, %92, %93, %276, %157, %124
  %545 = phi double [ %118, %93 ], [ %543, %276 ], [ %190, %157 ], [ %149, %124 ], [ 0.000000e+00, %92 ], [ 0.000000e+00, %122 ], [ 0.000000e+00, %153 ], [ 0.000000e+00, %77 ], [ 0.000000e+00, %73 ], [ 0.000000e+00, %62 ], [ 0.000000e+00, %58 ], [ 0.000000e+00, %47 ]
  %546 = getelementptr inbounds double, double addrspace(1)* %8, i64 %57
  store double %545, double addrspace(1)* %546, align 8, !tbaa !21
  %547 = icmp sgt i32 %53, 0
  %548 = and i1 %46, %547
  %549 = sext i32 %48 to i64
  br i1 %548, label %550, label %1043

550:                                              ; preds = %544
  %551 = getelementptr inbounds i32, i32 addrspace(1)* %3, i64 %549
  %552 = load i32, i32 addrspace(1)* %551, align 4, !tbaa !17
  %553 = icmp eq i32 %552, 0
  br i1 %553, label %1043, label %554

554:                                              ; preds = %550
  %555 = add nsw i32 %48, -1
  %556 = sext i32 %555 to i64
  %557 = getelementptr inbounds i32, i32 addrspace(1)* %3, i64 %556
  %558 = load i32, i32 addrspace(1)* %557, align 4, !tbaa !17
  %559 = icmp eq i32 %558, 0
  br i1 %559, label %1043, label %560

560:                                              ; preds = %554
  %561 = getelementptr inbounds double, double addrspace(1)* %4, i64 %556
  %562 = load double, double addrspace(1)* %561, align 8, !tbaa !21
  %563 = load double, double addrspace(1)* %0, align 8, !tbaa !21
  %564 = fcmp ogt double %562, %563
  br i1 %564, label %569, label %565

565:                                              ; preds = %560
  %566 = getelementptr inbounds double, double addrspace(1)* %4, i64 %549
  %567 = load double, double addrspace(1)* %566, align 8, !tbaa !21
  %568 = fcmp ogt double %567, %563
  br i1 %568, label %569, label %1043

569:                                              ; preds = %565, %560
  %570 = getelementptr inbounds i32, i32 addrspace(1)* %6, i64 %549
  %571 = load i32, i32 addrspace(1)* %570, align 4, !tbaa !17
  %572 = icmp eq i32 %571, 1
  br i1 %572, label %1043, label %573

573:                                              ; preds = %569
  %574 = getelementptr inbounds double, double addrspace(1)* %4, i64 %549
  %575 = load double, double addrspace(1)* %574, align 8, !tbaa !21
  %576 = getelementptr inbounds double, double addrspace(1)* %7, i64 %549
  %577 = load double, double addrspace(1)* %576, align 8, !tbaa !21
  %578 = fadd double %575, %577
  %579 = getelementptr inbounds double, double addrspace(1)* %7, i64 %556
  %580 = load double, double addrspace(1)* %579, align 8, !tbaa !21
  %581 = fsub double %575, %563
  %582 = fsub double %562, %563
  %583 = fcmp olt double %578, %580
  br i1 %583, label %584, label %611

584:                                              ; preds = %573
  br i1 %564, label %585, label %1043

585:                                              ; preds = %584
  %586 = fmul double %562, 5.440000e-01
  %587 = fmul double %562, %1
  %588 = fcmp olt double %587, 0x1000000000000000
  %589 = select i1 %588, double 0x4FF0000000000000, double 1.000000e+00
  %590 = fmul double %587, %589
  %591 = tail call double @llvm.amdgcn.rsq.f64(double %590) #3
  %592 = fmul double %590, %591
  %593 = fmul double %591, 5.000000e-01
  %594 = fneg double %593
  %595 = tail call double @llvm.fma.f64(double %594, double %592, double 5.000000e-01) #3
  %596 = tail call double @llvm.fma.f64(double %593, double %595, double %593) #3
  %597 = tail call double @llvm.fma.f64(double %592, double %595, double %592) #3
  %598 = fneg double %597
  %599 = tail call double @llvm.fma.f64(double %598, double %597, double %590) #3
  %600 = tail call double @llvm.fma.f64(double %599, double %596, double %597) #3
  %601 = fneg double %600
  %602 = tail call double @llvm.fma.f64(double %601, double %600, double %590) #3
  %603 = tail call double @llvm.fma.f64(double %602, double %596, double %600) #3
  %604 = select i1 %588, double 0x37F0000000000000, double 1.000000e+00
  %605 = fmul double %604, %603
  %606 = fcmp oeq double %590, 0.000000e+00
  %607 = fcmp oeq double %590, 0x7FF0000000000000
  %608 = or i1 %606, %607
  %609 = select i1 %608, double %590, double %605
  %610 = fmul double %586, %609
  br label %1043

611:                                              ; preds = %573
  %612 = fadd double %562, %580
  %613 = fcmp olt double %612, %577
  br i1 %613, label %614, label %642

614:                                              ; preds = %611
  %615 = fcmp ogt double %575, %563
  br i1 %615, label %616, label %1043

616:                                              ; preds = %614
  %617 = fmul double %575, -5.440000e-01
  %618 = fmul double %575, %1
  %619 = fcmp olt double %618, 0x1000000000000000
  %620 = select i1 %619, double 0x4FF0000000000000, double 1.000000e+00
  %621 = fmul double %618, %620
  %622 = tail call double @llvm.amdgcn.rsq.f64(double %621) #3
  %623 = fmul double %621, %622
  %624 = fmul double %622, 5.000000e-01
  %625 = fneg double %624
  %626 = tail call double @llvm.fma.f64(double %625, double %623, double 5.000000e-01) #3
  %627 = tail call double @llvm.fma.f64(double %624, double %626, double %624) #3
  %628 = tail call double @llvm.fma.f64(double %623, double %626, double %623) #3
  %629 = fneg double %628
  %630 = tail call double @llvm.fma.f64(double %629, double %628, double %621) #3
  %631 = tail call double @llvm.fma.f64(double %630, double %627, double %628) #3
  %632 = fneg double %631
  %633 = tail call double @llvm.fma.f64(double %632, double %631, double %621) #3
  %634 = tail call double @llvm.fma.f64(double %633, double %627, double %631) #3
  %635 = select i1 %619, double 0x37F0000000000000, double 1.000000e+00
  %636 = fmul double %635, %634
  %637 = fcmp oeq double %621, 0.000000e+00
  %638 = fcmp oeq double %621, 0x7FF0000000000000
  %639 = or i1 %637, %638
  %640 = select i1 %639, double %621, double %636
  %641 = fmul double %617, %640
  br label %1043

642:                                              ; preds = %611
  %643 = fmul double %582, %581
  %644 = fcmp olt double %643, 0.000000e+00
  br i1 %644, label %645, label %683

645:                                              ; preds = %642
  %646 = fcmp ogt double %575, 0.000000e+00
  %647 = fcmp ogt double %562, 0.000000e+00
  %648 = or i1 %647, %646
  br i1 %648, label %649, label %1043

649:                                              ; preds = %645
  %650 = fsub double %581, %582
  %651 = tail call double @llvm.fabs.f64(double %650) #3
  %652 = tail call double @llvm.maxnum.f64(double %578, double %612) #3
  %653 = tail call double @llvm.maxnum.f64(double %577, double %580) #3
  %654 = fsub double %652, %653
  %655 = fneg double %650
  %656 = fdiv double %655, %651
  %657 = fmul double %656, 3.500000e-01
  %658 = fmul double %657, %654
  %659 = fmul double %45, %654
  %660 = fcmp olt double %659, 0x1000000000000000
  %661 = select i1 %660, double 0x4FF0000000000000, double 1.000000e+00
  %662 = fmul double %659, %661
  %663 = tail call double @llvm.amdgcn.rsq.f64(double %662) #3
  %664 = fmul double %662, %663
  %665 = fmul double %663, 5.000000e-01
  %666 = fneg double %665
  %667 = tail call double @llvm.fma.f64(double %666, double %664, double 5.000000e-01) #3
  %668 = tail call double @llvm.fma.f64(double %665, double %667, double %665) #3
  %669 = tail call double @llvm.fma.f64(double %664, double %667, double %664) #3
  %670 = fneg double %669
  %671 = tail call double @llvm.fma.f64(double %670, double %669, double %662) #3
  %672 = tail call double @llvm.fma.f64(double %671, double %668, double %669) #3
  %673 = fneg double %672
  %674 = tail call double @llvm.fma.f64(double %673, double %672, double %662) #3
  %675 = tail call double @llvm.fma.f64(double %674, double %668, double %672) #3
  %676 = select i1 %660, double 0x37F0000000000000, double 1.000000e+00
  %677 = fmul double %676, %675
  %678 = fcmp oeq double %662, 0.000000e+00
  %679 = fcmp oeq double %662, 0x7FF0000000000000
  %680 = or i1 %678, %679
  %681 = select i1 %680, double %662, double %677
  %682 = fmul double %658, %681
  br label %1043

683:                                              ; preds = %642
  %684 = getelementptr inbounds double, double addrspace(1)* %15, i64 %549
  %685 = load double, double addrspace(1)* %684, align 8, !tbaa !21
  %686 = fmul double %685, %1
  %687 = fmul double %41, %686
  %688 = fsub double %578, %562
  %689 = fsub double %688, %580
  %690 = fmul double %689, %687
  %691 = icmp eq i32 %51, 0
  %692 = icmp eq i32 %51, %21
  %693 = or i1 %691, %692
  br i1 %693, label %694, label %697

694:                                              ; preds = %683
  %695 = getelementptr inbounds double, double addrspace(1)* %16, i64 %549
  %696 = load double, double addrspace(1)* %695, align 8, !tbaa !21
  br label %740

697:                                              ; preds = %683
  %698 = add nsw i32 %48, %20
  %699 = sext i32 %698 to i64
  %700 = getelementptr inbounds double, double addrspace(1)* %10, i64 %699
  %701 = load double, double addrspace(1)* %700, align 8, !tbaa !21
  %702 = add nsw i32 %698, -1
  %703 = sext i32 %702 to i64
  %704 = getelementptr inbounds double, double addrspace(1)* %10, i64 %703
  %705 = load double, double addrspace(1)* %704, align 8, !tbaa !21
  %706 = fadd double %701, %705
  %707 = fmul double %706, 5.000000e-01
  %708 = getelementptr inbounds double, double addrspace(1)* %10, i64 %549
  %709 = load double, double addrspace(1)* %708, align 8, !tbaa !21
  %710 = getelementptr inbounds double, double addrspace(1)* %10, i64 %556
  %711 = load double, double addrspace(1)* %710, align 8, !tbaa !21
  %712 = fadd double %709, %711
  %713 = fmul double %712, 5.000000e-01
  %714 = getelementptr inbounds double, double addrspace(1)* %16, i64 %699
  %715 = load double, double addrspace(1)* %714, align 8, !tbaa !21
  %716 = getelementptr inbounds double, double addrspace(1)* %16, i64 %549
  %717 = load double, double addrspace(1)* %716, align 8, !tbaa !21
  %718 = fadd double %715, %717
  %719 = fmul double %707, %718
  %720 = fmul double %719, 5.000000e-01
  %721 = tail call double @llvm.fabs.f64(double %707) #3
  %722 = fsub double %717, %715
  %723 = fmul double %721, %722
  %724 = fmul double %723, 5.000000e-01
  %725 = fadd double %720, %724
  %726 = sub nsw i32 %48, %20
  %727 = sext i32 %726 to i64
  %728 = getelementptr inbounds double, double addrspace(1)* %16, i64 %727
  %729 = load double, double addrspace(1)* %728, align 8, !tbaa !21
  %730 = fadd double %717, %729
  %731 = fmul double %713, %730
  %732 = fmul double %731, 5.000000e-01
  %733 = tail call double @llvm.fabs.f64(double %713) #3
  %734 = fsub double %729, %717
  %735 = fmul double %733, %734
  %736 = fmul double %735, 5.000000e-01
  %737 = fadd double %732, %736
  %738 = fsub double %725, %737
  %739 = fmul double %40, %738
  br label %740

740:                                              ; preds = %694, %697
  %741 = phi double [ %717, %697 ], [ %696, %694 ]
  %742 = phi double [ %739, %697 ], [ 0.000000e+00, %694 ]
  %743 = add nsw i32 %48, 1
  %744 = sext i32 %743 to i64
  %745 = getelementptr inbounds double, double addrspace(1)* %12, i64 %744
  %746 = load double, double addrspace(1)* %745, align 8, !tbaa !21
  %747 = getelementptr inbounds double, double addrspace(1)* %12, i64 %549
  %748 = load double, double addrspace(1)* %747, align 8, !tbaa !21
  %749 = fadd double %746, %748
  %750 = fmul double %749, 5.000000e-01
  %751 = getelementptr inbounds double, double addrspace(1)* %12, i64 %556
  %752 = load double, double addrspace(1)* %751, align 8, !tbaa !21
  %753 = fadd double %748, %752
  %754 = fmul double %753, 5.000000e-01
  %755 = getelementptr inbounds double, double addrspace(1)* %16, i64 %744
  %756 = load double, double addrspace(1)* %755, align 8, !tbaa !21
  %757 = fadd double %756, %741
  %758 = fmul double %750, %757
  %759 = fmul double %758, 5.000000e-01
  %760 = tail call double @llvm.fabs.f64(double %750) #3
  %761 = fsub double %741, %756
  %762 = fmul double %760, %761
  %763 = fmul double %762, 5.000000e-01
  %764 = fadd double %759, %763
  %765 = getelementptr inbounds double, double addrspace(1)* %16, i64 %556
  %766 = load double, double addrspace(1)* %765, align 8, !tbaa !21
  %767 = fadd double %741, %766
  %768 = fmul double %754, %767
  %769 = fmul double %768, 5.000000e-01
  %770 = tail call double @llvm.fabs.f64(double %754) #3
  %771 = fsub double %766, %741
  %772 = fmul double %770, %771
  %773 = fmul double %772, 5.000000e-01
  %774 = fadd double %769, %773
  %775 = fsub double %764, %774
  %776 = fmul double %41, %775
  %777 = getelementptr inbounds double, double addrspace(1)* %17, i64 %549
  %778 = load double, double addrspace(1)* %777, align 8, !tbaa !21
  %779 = fmul double %778, %778
  %780 = fmul double %748, %748
  %781 = fadd double %780, %779
  %782 = fcmp olt double %781, 0x1000000000000000
  %783 = select i1 %782, double 0x4FF0000000000000, double 1.000000e+00
  %784 = fmul double %781, %783
  %785 = tail call double @llvm.amdgcn.rsq.f64(double %784) #3
  %786 = fmul double %784, %785
  %787 = fmul double %785, 5.000000e-01
  %788 = fneg double %787
  %789 = tail call double @llvm.fma.f64(double %788, double %786, double 5.000000e-01) #3
  %790 = tail call double @llvm.fma.f64(double %787, double %789, double %787) #3
  %791 = tail call double @llvm.fma.f64(double %786, double %789, double %786) #3
  %792 = fneg double %791
  %793 = tail call double @llvm.fma.f64(double %792, double %791, double %784) #3
  %794 = tail call double @llvm.fma.f64(double %793, double %790, double %791) #3
  %795 = fneg double %794
  %796 = tail call double @llvm.fma.f64(double %795, double %794, double %784) #3
  %797 = tail call double @llvm.fma.f64(double %796, double %790, double %794) #3
  %798 = select i1 %782, double 0x37F0000000000000, double 1.000000e+00
  %799 = fmul double %798, %797
  %800 = fcmp oeq double %784, 0.000000e+00
  %801 = fcmp oeq double %784, 0x7FF0000000000000
  %802 = or i1 %800, %801
  %803 = select i1 %802, double %784, double %799
  %804 = tail call double @llvm.fabs.f64(double %685) #3
  %805 = tail call double @llvm.amdgcn.frexp.mant.f64(double %804) #3
  %806 = fcmp olt double %805, 0x3FE5555555555555
  %807 = zext i1 %806 to i32
  %808 = tail call double @llvm.amdgcn.ldexp.f64(double %805, i32 %807) #3
  %809 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %804) #3
  %810 = sub nsw i32 %809, %807
  %811 = fadd double %808, -1.000000e+00
  %812 = fadd double %808, 1.000000e+00
  %813 = fsub double %812, %808
  %814 = fsub double %812, %813
  %815 = fsub double %808, %814
  %816 = fsub double 1.000000e+00, %813
  %817 = fadd double %816, %815
  %818 = tail call double @llvm.amdgcn.rcp.f64(double %812) #3
  %819 = fneg double %812
  %820 = tail call double @llvm.fma.f64(double %819, double %818, double 1.000000e+00) #3
  %821 = tail call double @llvm.fma.f64(double %820, double %818, double %818) #3
  %822 = tail call double @llvm.fma.f64(double %819, double %821, double 1.000000e+00) #3
  %823 = tail call double @llvm.fma.f64(double %822, double %821, double %821) #3
  %824 = fmul double %811, %823
  %825 = fmul double %812, %824
  %826 = fneg double %825
  %827 = tail call double @llvm.fma.f64(double %824, double %812, double %826) #3
  %828 = tail call double @llvm.fma.f64(double %824, double %817, double %827) #3
  %829 = fadd double %825, %828
  %830 = fsub double %829, %825
  %831 = fsub double %828, %830
  %832 = fsub double %811, %829
  %833 = fsub double %811, %832
  %834 = fsub double %833, %829
  %835 = fsub double %834, %831
  %836 = fadd double %832, %835
  %837 = fmul double %823, %836
  %838 = fadd double %824, %837
  %839 = fsub double %838, %824
  %840 = fsub double %837, %839
  %841 = fmul double %838, %838
  %842 = fneg double %841
  %843 = tail call double @llvm.fma.f64(double %838, double %838, double %842) #3
  %844 = fmul double %840, 2.000000e+00
  %845 = tail call double @llvm.fma.f64(double %838, double %844, double %843) #3
  %846 = tail call double @llvm.fma.f64(double %840, double %840, double %845) #3
  %847 = fadd double %841, %846
  %848 = fsub double %847, %841
  %849 = fsub double %846, %848
  %850 = tail call double @llvm.fma.f64(double %847, double 0x3FBDEE674222DE17, double 0x3FBA6564968915A9) #3
  %851 = tail call double @llvm.fma.f64(double %847, double %850, double 0x3FBE25E43ABE935A) #3
  %852 = tail call double @llvm.fma.f64(double %847, double %851, double 0x3FC110EF47E6C9C2) #3
  %853 = tail call double @llvm.fma.f64(double %847, double %852, double 0x3FC3B13BCFA74449) #3
  %854 = tail call double @llvm.fma.f64(double %847, double %853, double 0x3FC745D171BF3C30) #3
  %855 = tail call double @llvm.fma.f64(double %847, double %854, double 0x3FCC71C71C7792CE) #3
  %856 = tail call double @llvm.fma.f64(double %847, double %855, double 0x3FD24924924920DA) #3
  %857 = tail call double @llvm.fma.f64(double %847, double %856, double 0x3FD999999999999C) #3
  %858 = sitofp i32 %810 to double
  %859 = fmul double %858, 0x3FE62E42FEFA39EF
  %860 = fneg double %859
  %861 = tail call double @llvm.fma.f64(double %858, double 0x3FE62E42FEFA39EF, double %860) #3
  %862 = tail call double @llvm.fma.f64(double %858, double 0x3C7ABC9E3B39803F, double %861) #3
  %863 = fadd double %859, %862
  %864 = fsub double %863, %859
  %865 = fsub double %862, %864
  %866 = tail call double @llvm.amdgcn.ldexp.f64(double %838, i32 1) #3
  %867 = tail call double @llvm.amdgcn.ldexp.f64(double %840, i32 1) #3
  %868 = fmul double %838, %847
  %869 = fneg double %868
  %870 = tail call double @llvm.fma.f64(double %847, double %838, double %869) #3
  %871 = fmul double %838, %849
  %872 = tail call double @llvm.fma.f64(double %847, double %840, double %871) #3
  %873 = fadd double %870, %872
  %874 = fadd double %868, %873
  %875 = fsub double %874, %868
  %876 = fsub double %873, %875
  %877 = fmul double %847, %857
  %878 = fneg double %877
  %879 = tail call double @llvm.fma.f64(double %847, double %857, double %878) #3
  %880 = tail call double @llvm.fma.f64(double %849, double %857, double %879) #3
  %881 = fadd double %877, %880
  %882 = fsub double %881, %877
  %883 = fsub double %880, %882
  %884 = fadd double %881, 0x3FE5555555555555
  %885 = fadd double %884, 0xBFE5555555555555
  %886 = fsub double %881, %885
  %887 = fadd double %883, 0x3C8543B0D5DF274D
  %888 = fadd double %886, %887
  %889 = fadd double %884, %888
  %890 = fsub double %889, %884
  %891 = fsub double %888, %890
  %892 = fmul double %874, %889
  %893 = fneg double %892
  %894 = fmul double %876, %889
  %895 = insertelement <2 x double> undef, double %874, i32 0
  %896 = shufflevector <2 x double> %895, <2 x double> undef, <2 x i32> zeroinitializer
  %897 = insertelement <2 x double> undef, double %889, i32 0
  %898 = insertelement <2 x double> %897, double %891, i32 1
  %899 = insertelement <2 x double> undef, double %893, i32 0
  %900 = insertelement <2 x double> %899, double %894, i32 1
  %901 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %896, <2 x double> %898, <2 x double> %900) #3
  %902 = extractelement <2 x double> %901, i32 0
  %903 = extractelement <2 x double> %901, i32 1
  %904 = fadd double %902, %903
  %905 = fadd double %892, %904
  %906 = fsub double %905, %892
  %907 = fsub double %904, %906
  %908 = fadd double %866, %905
  %909 = fsub double %908, %866
  %910 = fsub double %905, %909
  %911 = fadd double %867, %907
  %912 = fadd double %910, %911
  %913 = fadd double %908, %912
  %914 = fsub double %913, %908
  %915 = fsub double %912, %914
  %916 = fadd double %863, %913
  %917 = fsub double %916, %863
  %918 = fsub double %916, %917
  %919 = fsub double %863, %918
  %920 = fsub double %913, %917
  %921 = fadd double %920, %919
  %922 = fadd double %865, %915
  %923 = fsub double %922, %865
  %924 = fsub double %922, %923
  %925 = fsub double %865, %924
  %926 = fsub double %915, %923
  %927 = fadd double %926, %925
  %928 = fadd double %922, %921
  %929 = fadd double %916, %928
  %930 = fsub double %929, %916
  %931 = fsub double %928, %930
  %932 = fadd double %927, %931
  %933 = fadd double %929, %932
  %934 = fsub double %933, %929
  %935 = fsub double %932, %934
  %936 = fmul double %933, 0x3FF55554FBDAD752
  %937 = fneg double %936
  %938 = tail call double @llvm.fma.f64(double %933, double 0x3FF55554FBDAD752, double %937) #3
  %939 = tail call double @llvm.fma.f64(double %935, double 0x3FF55554FBDAD752, double %938) #3
  %940 = fadd double %936, %939
  %941 = fsub double %940, %936
  %942 = fsub double %939, %941
  %943 = tail call double @llvm.fabs.f64(double %936) #4
  %944 = fcmp oeq double %943, 0x7FF0000000000000
  %945 = select i1 %944, double %936, double %940
  %946 = tail call double @llvm.fabs.f64(double %945) #4
  %947 = fcmp oeq double %946, 0x7FF0000000000000
  %948 = select i1 %947, double 0.000000e+00, double %942
  %949 = fmul double %945, 0x3FF71547652B82FE
  %950 = tail call double @llvm.rint.f64(double %949) #3
  %951 = fmul double %950, 0x3FE62E42FEFA3000
  %952 = fsub double %945, %951
  %953 = fsub double %952, %945
  %954 = fsub double %952, %953
  %955 = fsub double %945, %954
  %956 = fadd double %951, %953
  %957 = fsub double %955, %956
  %958 = fadd double %948, %957
  %959 = fadd double %952, %958
  %960 = fsub double %959, %952
  %961 = fsub double %958, %960
  %962 = fmul double %950, 0x3D53DE6AF278E000
  %963 = fsub double %959, %962
  %964 = fsub double %959, %963
  %965 = fsub double %964, %962
  %966 = fadd double %961, %965
  %967 = fadd double %963, %966
  %968 = fsub double %967, %963
  %969 = fsub double %966, %968
  %970 = fmul double %950, 0x3AC9CC01F97B57A0
  %971 = fsub double %967, %970
  %972 = fsub double %967, %971
  %973 = fsub double %972, %970
  %974 = fadd double %969, %973
  %975 = fadd double %971, %974
  %976 = fsub double %975, %971
  %977 = fsub double %974, %976
  %978 = tail call double @llvm.fma.f64(double %975, double 0x3E5ADE156A5DCB37, double 0x3E928AF3FCA7AB0C) #3
  %979 = tail call double @llvm.fma.f64(double %975, double %978, double 0x3EC71DEE623FDE64) #3
  %980 = tail call double @llvm.fma.f64(double %975, double %979, double 0x3EFA01997C89E6B0) #3
  %981 = tail call double @llvm.fma.f64(double %975, double %980, double 0x3F2A01A014761F6E) #3
  %982 = tail call double @llvm.fma.f64(double %975, double %981, double 0x3F56C16C1852B7B0) #3
  %983 = tail call double @llvm.fma.f64(double %975, double %982, double 0x3F81111111122322) #3
  %984 = tail call double @llvm.fma.f64(double %975, double %983, double 0x3FA55555555502A1) #3
  %985 = tail call double @llvm.fma.f64(double %975, double %984, double 0x3FC5555555555511) #3
  %986 = tail call double @llvm.fma.f64(double %975, double %985, double 0x3FE000000000000B) #3
  %987 = fmul double %975, %975
  %988 = fneg double %987
  %989 = tail call double @llvm.fma.f64(double %975, double %975, double %988) #3
  %990 = fmul double %977, 2.000000e+00
  %991 = tail call double @llvm.fma.f64(double %975, double %990, double %989) #3
  %992 = tail call double @llvm.fma.f64(double %977, double %977, double %991) #3
  %993 = fadd double %987, %992
  %994 = fsub double %993, %987
  %995 = fsub double %992, %994
  %996 = fmul double %993, %986
  %997 = fneg double %996
  %998 = tail call double @llvm.fma.f64(double %993, double %986, double %997) #3
  %999 = tail call double @llvm.fma.f64(double %995, double %986, double %998) #3
  %1000 = fadd double %996, %999
  %1001 = fsub double %1000, %996
  %1002 = fsub double %999, %1001
  %1003 = fadd double %975, %1000
  %1004 = fsub double %1003, %975
  %1005 = fsub double %1000, %1004
  %1006 = fadd double %977, %1002
  %1007 = fadd double %1005, %1006
  %1008 = fadd double %1003, %1007
  %1009 = fadd double %1008, 1.000000e+00
  %1010 = fptosi double %950 to i32
  %1011 = tail call double @llvm.amdgcn.ldexp.f64(double %1009, i32 %1010) #3
  %1012 = fcmp ogt double %945, 7.100000e+02
  %1013 = select i1 %1012, double 0x7FF0000000000000, double %1011
  %1014 = fcmp olt double %945, -7.450000e+02
  %1015 = select i1 %1014, double 0.000000e+00, double %1013
  %1016 = fcmp uno double %685, 0.000000e+00
  %1017 = tail call i1 @llvm.amdgcn.class.f64(double %685, i32 512) #3
  %1018 = tail call i1 @llvm.amdgcn.class.f64(double %685, i32 4) #3
  %1019 = or i1 %1017, %1018
  %1020 = fcmp oeq double %685, 0.000000e+00
  %1021 = tail call i1 @llvm.amdgcn.class.f64(double %685, i32 960) #3
  %1022 = tail call double @llvm.fabs.f64(double %1015) #3
  %1023 = select i1 %1021, double %1022, double 0x7FF8000000000000
  %1024 = select i1 %1020, double 0.000000e+00, double %1023
  %1025 = select i1 %1019, double 0x7FF0000000000000, double %1024
  %1026 = select i1 %1016, double %685, double %1025
  %1027 = fcmp oeq double %685, 1.000000e+00
  %1028 = select i1 %1027, double 1.000000e+00, double %1026
  %1029 = fmul double %43, %803
  %1030 = fdiv double %1029, %1028
  %1031 = fcmp ugt double %685, %563
  %1032 = select i1 %1031, double %1030, double 0.000000e+00
  %1033 = fmul double %1032, %24
  %1034 = fmul double %1033, 5.000000e-01
  %1035 = fsub double 1.000000e+00, %1034
  %1036 = fmul double %741, %1035
  %1037 = fneg double %742
  %1038 = fsub double %1037, %776
  %1039 = fsub double %1038, %690
  %1040 = fadd double %1039, %1036
  %1041 = fadd double %1034, 1.000000e+00
  %1042 = fdiv double %1040, %1041
  br label %1043

1043:                                             ; preds = %544, %550, %554, %565, %569, %645, %614, %584, %585, %740, %649, %616
  %1044 = phi double [ %610, %585 ], [ %1042, %740 ], [ %682, %649 ], [ %641, %616 ], [ 0.000000e+00, %584 ], [ 0.000000e+00, %614 ], [ 0.000000e+00, %645 ], [ 0.000000e+00, %569 ], [ 0.000000e+00, %565 ], [ 0.000000e+00, %554 ], [ 0.000000e+00, %550 ], [ 0.000000e+00, %544 ]
  %1045 = getelementptr inbounds double, double addrspace(1)* %14, i64 %549
  store double %1044, double addrspace(1)* %1045, align 8, !tbaa !21
  %1046 = add i32 %48, %29
  %1047 = icmp slt i32 %1046, %19
  br i1 %1047, label %47, label %1048, !llvm.loop !23

1048:                                             ; preds = %1043, %25
  ret void
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.maxnum.f64(double, double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i1 @llvm.amdgcn.class.f64(double, i32) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.rint.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.ldexp.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.frexp.mant.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.frexp.exp.i32.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rcp.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fma.v2f64(<2 x double>, <2 x double>, <2 x double>) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rsq.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

attributes #0 = { nofree norecurse nounwind "amdgpu-flat-work-group-size"="1,1024" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="128" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }
attributes #4 = { nounwind readnone }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{!6, !10, i64 12}
!6 = !{!"hsa_kernel_dispatch_packet_s", !7, i64 0, !7, i64 2, !7, i64 4, !7, i64 6, !7, i64 8, !7, i64 10, !10, i64 12, !10, i64 16, !10, i64 20, !10, i64 24, !10, i64 28, !11, i64 32, !12, i64 40, !11, i64 48, !13, i64 56}
!7 = !{!"short", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C/C++ TBAA"}
!10 = !{!"int", !8, i64 0}
!11 = !{!"long", !8, i64 0}
!12 = !{!"any pointer", !8, i64 0}
!13 = !{!"hsa_signal_s", !11, i64 0}
!14 = !{i16 1, i16 1025}
!15 = !{}
!16 = !{i32 0, i32 1024}
!17 = !{!18, !18, i64 0}
!18 = !{!"int", !19, i64 0}
!19 = !{!"omnipotent char", !20, i64 0}
!20 = !{!"Simple C++ TBAA"}
!21 = !{!22, !22, i64 0}
!22 = !{!"double", !19, i64 0}
!23 = distinct !{!23, !24}
!24 = !{!"llvm.loop.mustprogress"}
