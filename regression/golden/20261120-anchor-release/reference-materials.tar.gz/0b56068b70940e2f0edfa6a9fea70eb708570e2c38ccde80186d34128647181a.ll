; ModuleID = '/data/home/chh/simplify-v2/build/dp1-removal/stable-darm/CED/trial-2/fused.ll'
source_filename = "cases/ced/source/native.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7"
target triple = "amdgcn-amd-amdhsa"

@l_mem = external hidden local_unnamed_addr addrspace(3) global [0 x i32], align 4

; Function Attrs: convergent norecurse nounwind willreturn mustprogress
define protected amdgpu_kernel void @_Z19non_max_supp_kernelPKhPhS0_ii(i8 addrspace(1)* noalias nocapture readonly %0, i8 addrspace(1)* noalias nocapture %1, i8 addrspace(1)* noalias nocapture readonly %2, i32 %3, i32 %4) local_unnamed_addr #0 {
  %6 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %7 = getelementptr inbounds i8, i8 addrspace(4)* %6, i64 4
  %8 = bitcast i8 addrspace(4)* %7 to i16 addrspace(4)*
  %9 = load i16, i16 addrspace(4)* %8, align 4, !tbaa !3
  %10 = zext i16 %9 to i32
  %11 = getelementptr inbounds i8, i8 addrspace(4)* %6, i64 6
  %12 = bitcast i8 addrspace(4)* %11 to i16 addrspace(4)*
  %13 = load i16, i16 addrspace(4)* %12, align 2, !tbaa !3
  %14 = zext i16 %13 to i32
  %15 = tail call i32 @llvm.amdgcn.workitem.id.y(), !range !7
  %16 = add nuw nsw i32 %15, 1
  %17 = tail call i32 @llvm.amdgcn.workitem.id.x(), !range !7
  %18 = add nuw nsw i32 %17, 1
  %19 = tail call i32 @llvm.amdgcn.workgroup.id.y()
  %20 = mul i32 %19, %14
  %21 = add i32 %20, %16
  %22 = tail call i32 @llvm.amdgcn.workgroup.id.x()
  %23 = mul i32 %22, %10
  %24 = add i32 %23, %18
  %25 = mul nsw i32 %21, %4
  %26 = add nsw i32 %24, %25
  %27 = sext i32 %26 to i64
  %28 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %27
  %29 = load i8, i8 addrspace(1)* %28, align 1, !tbaa !8
  %30 = zext i8 %29 to i32
  %31 = add nuw nsw i32 %10, 2
  %32 = mul nuw nsw i32 %31, %16
  %33 = add nuw nsw i32 %32, %18
  %34 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %33
  store i32 %30, i32 addrspace(3)* %34, align 4, !tbaa !9
  %35 = icmp eq i32 %15, 0
  %36 = icmp eq i32 %16, %10
  %decision.take = or i1 %35, %36
  br i1 %decision.take, label %merged.bb, label %.pair.join, !decision.condition_prefix !11

.pair.join:                                       ; preds = %merged.bb1, %merged.bb, %5
  %37 = icmp eq i32 %17, 0
  %38 = icmp eq i32 %18, %10
  %leaf.enter1 = or i1 %37, %38
  br i1 %leaf.enter1, label %merged.bb2, label %merged.branch.split, !fusion.logical.arm !12

merged.branch.split:                              ; preds = %merged.bb2, %.pair.join
  fence syncscope("workgroup") seq_cst
  tail call void @llvm.amdgcn.s.barrier()
  fence syncscope("workgroup") seq_cst
  %39 = load i32, i32 addrspace(3)* %34, align 4, !tbaa !9
  %40 = trunc i32 %39 to i8
  %41 = getelementptr inbounds i8, i8 addrspace(1)* %2, i64 %27
  %42 = load i8, i8 addrspace(1)* %41, align 1, !tbaa !8
  switch i8 %42, label %102 [
    i8 0, label %43
    i8 45, label %55
    i8 90, label %71
    i8 -121, label %86
  ]

43:                                               ; preds = %merged.branch.split
  %44 = and i32 %39, 255
  %45 = add nuw nsw i32 %33, 1
  %46 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %45
  %47 = load i32, i32 addrspace(3)* %46, align 4, !tbaa !9
  %48 = icmp sgt i32 %44, %47
  br i1 %48, label %49, label %102

49:                                               ; preds = %43
  %50 = add nuw nsw i32 %32, %17
  %51 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %50
  %52 = load i32, i32 addrspace(3)* %51, align 4, !tbaa !9
  %53 = icmp sgt i32 %44, %52
  %54 = select i1 %53, i8 %40, i8 0
  br label %102

55:                                               ; preds = %merged.branch.split
  %56 = and i32 %39, 255
  %57 = mul nuw nsw i32 %31, %15
  %58 = add nuw nsw i32 %17, 2
  %59 = add nuw nsw i32 %58, %57
  %60 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %59
  %61 = load i32, i32 addrspace(3)* %60, align 4, !tbaa !9
  %62 = icmp sgt i32 %56, %61
  br i1 %62, label %63, label %102

63:                                               ; preds = %55
  %64 = add nuw nsw i32 %15, 2
  %65 = mul nuw nsw i32 %31, %64
  %66 = add nuw nsw i32 %65, %17
  %67 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %66
  %68 = load i32, i32 addrspace(3)* %67, align 4, !tbaa !9
  %69 = icmp sgt i32 %56, %68
  %70 = select i1 %69, i8 %40, i8 0
  br label %102

71:                                               ; preds = %merged.branch.split
  %72 = and i32 %39, 255
  %73 = mul nuw nsw i32 %31, %15
  %74 = add nuw nsw i32 %73, %18
  %75 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %74
  %76 = load i32, i32 addrspace(3)* %75, align 4, !tbaa !9
  %77 = icmp sgt i32 %72, %76
  br i1 %77, label %78, label %102

78:                                               ; preds = %71
  %79 = add nuw nsw i32 %15, 2
  %80 = mul nuw nsw i32 %31, %79
  %81 = add nuw nsw i32 %80, %18
  %82 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %81
  %83 = load i32, i32 addrspace(3)* %82, align 4, !tbaa !9
  %84 = icmp sgt i32 %72, %83
  %85 = select i1 %84, i8 %40, i8 0
  br label %102

86:                                               ; preds = %merged.branch.split
  %87 = and i32 %39, 255
  %88 = mul nuw nsw i32 %31, %15
  %89 = add nuw nsw i32 %88, %17
  %90 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %89
  %91 = load i32, i32 addrspace(3)* %90, align 4, !tbaa !9
  %92 = icmp sgt i32 %87, %91
  br i1 %92, label %93, label %102

93:                                               ; preds = %86
  %94 = add nuw nsw i32 %15, 2
  %95 = mul nuw nsw i32 %31, %94
  %96 = add nuw nsw i32 %17, 2
  %97 = add nuw nsw i32 %96, %95
  %98 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %97
  %99 = load i32, i32 addrspace(3)* %98, align 4, !tbaa !9
  %100 = icmp sgt i32 %87, %99
  %101 = select i1 %100, i8 %40, i8 0
  br label %102

102:                                              ; preds = %93, %86, %78, %71, %63, %55, %49, %43, %merged.branch.split
  %103 = phi i8 [ %40, %merged.branch.split ], [ 0, %43 ], [ %54, %49 ], [ 0, %55 ], [ %70, %63 ], [ 0, %71 ], [ %85, %78 ], [ 0, %86 ], [ %101, %93 ]
  %104 = getelementptr inbounds i8, i8 addrspace(1)* %1, i64 %27
  store i8 %103, i8 addrspace(1)* %104, align 1, !tbaa !8
  ret void

merged.bb:                                        ; preds = %5
  %105 = sub i32 0, %4
  %guard.result.p = select i1 %35, i32 %105, i32 %4
  %guard.result = add i32 %26, %guard.result.p
  %106 = sext i32 %guard.result to i64
  %107 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %106
  %108 = load i8, i8 addrspace(1)* %107, align 1, !tbaa !8
  %109 = zext i8 %108 to i32
  %110 = add nuw nsw i32 %10, 1
  %111 = mul nsw i32 %110, %31
  %112 = select i1 %35, i32 0, i32 %111
  %merged.select6 = add nuw nsw i32 %18, %112
  %113 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %merged.select6
  store i32 %109, i32 addrspace(3)* %113, align 4, !tbaa !9
  %114 = icmp eq i32 %17, 0
  %115 = icmp eq i32 %18, %10
  %leaf.enter = or i1 %114, %115
  br i1 %leaf.enter, label %merged.bb1, label %.pair.join, !fusion.logical.arm !13

merged.bb1:                                       ; preds = %merged.bb
  %116 = select i1 %35, i32 %10, i32 %111
  %117 = select i1 %114, i32 undef, i32 %116
  %merged.select2 = select i1 %114, i32 %111, i32 %110
  %118 = select i1 %35, i32 1, i32 %merged.select2
  %119 = add nuw nsw i32 %117, %118
  %120 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %119
  %merged.select3 = select i1 %114, i32 -1, i32 1
  %121 = add nsw i32 %guard.result, %merged.select3
  %122 = sext i32 %121 to i64
  %123 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %122
  %124 = load i8, i8 addrspace(1)* %123, align 1, !tbaa !8
  %125 = zext i8 %124 to i32
  %126 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %118
  %127 = select i1 %35, i32 addrspace(3)* getelementptr inbounds ([0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 0), i32 addrspace(3)* %126
  %merged.select4 = select i1 %114, i32 addrspace(3)* %127, i32 addrspace(3)* %120
  store i32 %125, i32 addrspace(3)* %merged.select4, align 4, !tbaa !9
  br label %.pair.join

merged.bb2:                                       ; preds = %.pair.join
  %128 = add nuw nsw i32 %10, 1
  %129 = add nuw nsw i32 %128, %32
  %130 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %129
  %merged.select = select i1 %37, i32 -1, i32 1
  %131 = add nsw i32 %26, %merged.select
  %132 = sext i32 %131 to i64
  %133 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %132
  %134 = load i8, i8 addrspace(1)* %133, align 1, !tbaa !8
  %135 = zext i8 %134 to i32
  %136 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %32
  %merged.select5 = select i1 %37, i32 addrspace(3)* %136, i32 addrspace(3)* %130
  store i32 %135, i32 addrspace(3)* %merged.select5, align 4, !tbaa !9
  br label %merged.branch.split
}

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.y() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.y() #1

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #1

attributes #0 = { convergent norecurse nounwind willreturn mustprogress "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nounwind readnone speculatable willreturn }
attributes #2 = { convergent nounwind willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!3 = !{!4, !4, i64 0}
!4 = !{!"short", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C++ TBAA"}
!7 = !{i32 0, i32 1024}
!8 = !{!5, !5, i64 0}
!9 = !{!10, !10, i64 0}
!10 = !{!"int", !5, i64 0}
!11 = !{}
!12 = !{!"%39", !"%47"}
!13 = !{!"merged.bb2", !"merged.bb4"}
