; ModuleID = '/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-repro.XpJFTn/MS32/inline-marked.ll'
source_filename = "/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-benchmarks/benchmarks/MS/mergesort.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

%struct.__HIP_Coordinates = type { i8 }
%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z" = type { i8 }
%struct.__HIP_Coordinates.0 = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z" = type { i8 }
%struct.dim3 = type { i32, i32, i32 }
%struct.__HIP_ThreadIdx = type { i8 }
%struct.__HIP_BlockIdx = type { i8 }

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1yE = comdat any

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1zE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1yE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1zE = comdat any

@.str = private unnamed_addr addrspace(4) constant [47 x i8] c"%s:%u: %s: Device-side assertion `%s' failed.\0A\00", align 1
@_ZL9threadIdx = internal addrspace(4) constant %struct.__HIP_Coordinates undef, align 1
@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1yE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1zE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z" undef, comdat, align 1
@_ZL8blockIdx = internal addrspace(4) constant %struct.__HIP_Coordinates.0 undef, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1yE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1zE = weak protected addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z" undef, comdat, align 1

; Function Attrs: convergent noinline nounwind
define weak hidden void @__assert_fail(i8* %0, i8* %1, i32 %2, i8* %3) #0 {
  %5 = alloca i8*, align 8, addrspace(5)
  %6 = addrspacecast i8* addrspace(5)* %5 to i8**
  %7 = alloca i8*, align 8, addrspace(5)
  %8 = addrspacecast i8* addrspace(5)* %7 to i8**
  %9 = alloca i32, align 4, addrspace(5)
  %10 = addrspacecast i32 addrspace(5)* %9 to i32*
  %11 = alloca i8*, align 8, addrspace(5)
  %12 = addrspacecast i8* addrspace(5)* %11 to i8**
  store i8* %0, i8** %6, align 8
  store i8* %1, i8** %8, align 8
  store i32 %2, i32* %10, align 4
  store i8* %3, i8** %12, align 8
  call void @_ZL6printfIJPKcjS1_S1_EEvS1_DpT_(i8* getelementptr inbounds ([47 x i8], [47 x i8]* addrspacecast ([47 x i8] addrspace(4)* @.str to [47 x i8]*), i64 0, i64 0), i8* %1, i32 %2, i8* %3, i8* %0) #6
  call void @llvm.trap()
  ret void
}

; Function Attrs: convergent noinline nounwind
define internal void @_ZL6printfIJPKcjS1_S1_EEvS1_DpT_(i8* %0, i8* %1, i32 %2, i8* %3, i8* %4) #0 {
  %6 = alloca i8*, align 8, addrspace(5)
  %7 = addrspacecast i8* addrspace(5)* %6 to i8**
  %8 = alloca i8*, align 8, addrspace(5)
  %9 = addrspacecast i8* addrspace(5)* %8 to i8**
  %10 = alloca i32, align 4, addrspace(5)
  %11 = addrspacecast i32 addrspace(5)* %10 to i32*
  %12 = alloca i8*, align 8, addrspace(5)
  %13 = addrspacecast i8* addrspace(5)* %12 to i8**
  %14 = alloca i8*, align 8, addrspace(5)
  %15 = addrspacecast i8* addrspace(5)* %14 to i8**
  store i8* %0, i8** %7, align 8
  store i8* %1, i8** %9, align 8
  store i32 %2, i32* %11, align 4
  store i8* %3, i8** %13, align 8
  store i8* %4, i8** %15, align 8
  ret void
}

; Function Attrs: cold noreturn nounwind
declare void @llvm.trap() #1

; Function Attrs: convergent noinline nounwind
define weak hidden void @__assertfail(i8* %0, i8* %1, i32 %2, i8* %3, i64 %4) #0 {
  %6 = alloca i8*, align 8, addrspace(5)
  %7 = addrspacecast i8* addrspace(5)* %6 to i8**
  %8 = alloca i8*, align 8, addrspace(5)
  %9 = addrspacecast i8* addrspace(5)* %8 to i8**
  %10 = alloca i32, align 4, addrspace(5)
  %11 = addrspacecast i32 addrspace(5)* %10 to i32*
  %12 = alloca i8*, align 8, addrspace(5)
  %13 = addrspacecast i8* addrspace(5)* %12 to i8**
  %14 = alloca i64, align 8, addrspace(5)
  %15 = addrspacecast i64 addrspace(5)* %14 to i64*
  store i8* %0, i8** %7, align 8
  store i8* %1, i8** %9, align 8
  store i32 %2, i32* %11, align 4
  store i8* %3, i8** %13, align 8
  store i64 %4, i64* %15, align 8
  call void @llvm.trap()
  ret void
}

; Function Attrs: alwaysinline convergent nounwind
define hidden i32 @_Z6getIdxP4dim3S0_(%struct.dim3* %0, %struct.dim3* %1) #2 {
  %3 = alloca %struct.__HIP_ThreadIdx*, align 8, addrspace(5)
  %4 = alloca i32, align 4, addrspace(5)
  %5 = alloca %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"*, align 8, addrspace(5)
  %6 = alloca %struct.__HIP_ThreadIdx, align 1, addrspace(5)
  %7 = alloca %struct.__HIP_ThreadIdx*, align 8, addrspace(5)
  %8 = alloca i32, align 4, addrspace(5)
  %9 = alloca %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"*, align 8, addrspace(5)
  %10 = alloca %struct.__HIP_ThreadIdx, align 1, addrspace(5)
  %11 = alloca %struct.__HIP_BlockIdx*, align 8, addrspace(5)
  %12 = alloca i32, align 4, addrspace(5)
  %13 = alloca %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"*, align 8, addrspace(5)
  %14 = alloca %struct.__HIP_BlockIdx, align 1, addrspace(5)
  %15 = alloca %struct.__HIP_BlockIdx*, align 8, addrspace(5)
  %16 = alloca i32, align 4, addrspace(5)
  %17 = alloca %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"*, align 8, addrspace(5)
  %18 = alloca %struct.__HIP_BlockIdx, align 1, addrspace(5)
  %19 = alloca %struct.__HIP_BlockIdx*, align 8, addrspace(5)
  %20 = alloca i32, align 4, addrspace(5)
  %21 = alloca %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"*, align 8, addrspace(5)
  %22 = alloca %struct.__HIP_BlockIdx, align 1, addrspace(5)
  %23 = alloca %struct.__HIP_ThreadIdx*, align 8, addrspace(5)
  %24 = alloca i32, align 4, addrspace(5)
  %25 = alloca %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"*, align 8, addrspace(5)
  %26 = alloca %struct.__HIP_ThreadIdx, align 1, addrspace(5)
  %27 = alloca %struct.dim3*, align 8, addrspace(5)
  %28 = addrspacecast %struct.dim3* addrspace(5)* %27 to %struct.dim3**
  %29 = alloca %struct.dim3*, align 8, addrspace(5)
  %30 = addrspacecast %struct.dim3* addrspace(5)* %29 to %struct.dim3**
  %31 = alloca i32, align 4, addrspace(5)
  %32 = addrspacecast i32 addrspace(5)* %31 to i32*
  store %struct.dim3* %0, %struct.dim3** %28, align 8
  store %struct.dim3* %1, %struct.dim3** %30, align 8
  %33 = bitcast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"* addrspace(5)* %25 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %33)
  %34 = bitcast %struct.__HIP_ThreadIdx addrspace(5)* %26 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %34)
  %35 = addrspacecast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"* addrspace(5)* %25 to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"**
  %36 = addrspacecast %struct.__HIP_ThreadIdx addrspace(5)* %26 to %struct.__HIP_ThreadIdx*
  store %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" addrspace(4)* @_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"*), %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"** %35, align 8
  %37 = bitcast %struct.__HIP_ThreadIdx* addrspace(5)* %23 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %37) #7
  %38 = bitcast i32 addrspace(5)* %24 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %38) #7
  %39 = addrspacecast %struct.__HIP_ThreadIdx* addrspace(5)* %23 to %struct.__HIP_ThreadIdx**
  %40 = addrspacecast i32 addrspace(5)* %24 to i32*
  store %struct.__HIP_ThreadIdx* %36, %struct.__HIP_ThreadIdx** %39, align 8
  store i32 0, i32* %40, align 4
  %41 = call i32 @llvm.amdgcn.workitem.id.x() #7, !range !5
  %42 = zext i32 %41 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %37) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %38) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %33)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %34)
  %43 = bitcast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"* addrspace(5)* %5 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %43)
  %44 = bitcast %struct.__HIP_ThreadIdx addrspace(5)* %6 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %44)
  %45 = addrspacecast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"* addrspace(5)* %5 to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"**
  %46 = addrspacecast %struct.__HIP_ThreadIdx addrspace(5)* %6 to %struct.__HIP_ThreadIdx*
  store %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y" addrspace(4)* @_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1yE to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"*), %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"** %45, align 8
  %47 = bitcast %struct.__HIP_ThreadIdx* addrspace(5)* %3 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %47) #7
  %48 = bitcast i32 addrspace(5)* %4 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %48) #7
  %49 = addrspacecast %struct.__HIP_ThreadIdx* addrspace(5)* %3 to %struct.__HIP_ThreadIdx**
  %50 = addrspacecast i32 addrspace(5)* %4 to i32*
  store %struct.__HIP_ThreadIdx* %46, %struct.__HIP_ThreadIdx** %49, align 8
  store i32 1, i32* %50, align 4
  %51 = call i32 @llvm.amdgcn.workitem.id.y() #7, !range !5
  %52 = zext i32 %51 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %47) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %48) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %43)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %44)
  %53 = getelementptr inbounds %struct.dim3, %struct.dim3* %0, i32 0, i32 0
  %54 = load i32, i32* %53, align 4
  store i32 %54, i32* %32, align 4
  %55 = mul i32 %51, %54
  %56 = add i32 %41, %55
  %57 = bitcast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"* addrspace(5)* %9 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %57)
  %58 = bitcast %struct.__HIP_ThreadIdx addrspace(5)* %10 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %58)
  %59 = addrspacecast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"* addrspace(5)* %9 to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"**
  %60 = addrspacecast %struct.__HIP_ThreadIdx addrspace(5)* %10 to %struct.__HIP_ThreadIdx*
  store %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z" addrspace(4)* @_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1zE to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"*), %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"** %59, align 8
  %61 = bitcast %struct.__HIP_ThreadIdx* addrspace(5)* %7 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %61) #7
  %62 = bitcast i32 addrspace(5)* %8 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %62) #7
  %63 = addrspacecast %struct.__HIP_ThreadIdx* addrspace(5)* %7 to %struct.__HIP_ThreadIdx**
  %64 = addrspacecast i32 addrspace(5)* %8 to i32*
  store %struct.__HIP_ThreadIdx* %60, %struct.__HIP_ThreadIdx** %63, align 8
  store i32 2, i32* %64, align 4
  %65 = call i32 @llvm.amdgcn.workitem.id.z() #7, !range !5
  %66 = zext i32 %65 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %61) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %62) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %57)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %58)
  %67 = getelementptr inbounds %struct.dim3, %struct.dim3* %0, i32 0, i32 1
  %68 = load i32, i32* %67, align 4
  %69 = mul i32 %54, %68
  store i32 %69, i32* %32, align 4
  %70 = mul i32 %65, %69
  %71 = add i32 %56, %70
  %72 = bitcast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"* addrspace(5)* %13 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %72)
  %73 = bitcast %struct.__HIP_BlockIdx addrspace(5)* %14 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %73)
  %74 = addrspacecast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"* addrspace(5)* %13 to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"**
  %75 = addrspacecast %struct.__HIP_BlockIdx addrspace(5)* %14 to %struct.__HIP_BlockIdx*
  store %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" addrspace(4)* @_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"*), %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"** %74, align 8
  %76 = bitcast %struct.__HIP_BlockIdx* addrspace(5)* %11 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %76) #7
  %77 = bitcast i32 addrspace(5)* %12 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %77) #7
  %78 = addrspacecast %struct.__HIP_BlockIdx* addrspace(5)* %11 to %struct.__HIP_BlockIdx**
  %79 = addrspacecast i32 addrspace(5)* %12 to i32*
  store %struct.__HIP_BlockIdx* %75, %struct.__HIP_BlockIdx** %78, align 8
  store i32 0, i32* %79, align 4
  %80 = call i32 @llvm.amdgcn.workgroup.id.x() #7
  %81 = zext i32 %80 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %76) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %77) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %72)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %73)
  %82 = getelementptr inbounds %struct.dim3, %struct.dim3* %0, i32 0, i32 2
  %83 = load i32, i32* %82, align 4
  %84 = mul i32 %69, %83
  store i32 %84, i32* %32, align 4
  %85 = mul i32 %80, %84
  %86 = add i32 %71, %85
  %87 = bitcast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"* addrspace(5)* %17 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %87)
  %88 = bitcast %struct.__HIP_BlockIdx addrspace(5)* %18 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %88)
  %89 = addrspacecast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"* addrspace(5)* %17 to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"**
  %90 = addrspacecast %struct.__HIP_BlockIdx addrspace(5)* %18 to %struct.__HIP_BlockIdx*
  store %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y" addrspace(4)* @_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1yE to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"*), %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"** %89, align 8
  %91 = bitcast %struct.__HIP_BlockIdx* addrspace(5)* %15 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %91) #7
  %92 = bitcast i32 addrspace(5)* %16 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %92) #7
  %93 = addrspacecast %struct.__HIP_BlockIdx* addrspace(5)* %15 to %struct.__HIP_BlockIdx**
  %94 = addrspacecast i32 addrspace(5)* %16 to i32*
  store %struct.__HIP_BlockIdx* %90, %struct.__HIP_BlockIdx** %93, align 8
  store i32 1, i32* %94, align 4
  %95 = call i32 @llvm.amdgcn.workgroup.id.y() #7
  %96 = zext i32 %95 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %91) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %92) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %87)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %88)
  %97 = getelementptr inbounds %struct.dim3, %struct.dim3* %1, i32 0, i32 2
  %98 = load i32, i32* %97, align 4
  %99 = mul i32 %84, %98
  store i32 %99, i32* %32, align 4
  %100 = mul i32 %95, %99
  %101 = add i32 %86, %100
  %102 = bitcast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"* addrspace(5)* %21 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %102)
  %103 = bitcast %struct.__HIP_BlockIdx addrspace(5)* %22 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %103)
  %104 = addrspacecast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"* addrspace(5)* %21 to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"**
  %105 = addrspacecast %struct.__HIP_BlockIdx addrspace(5)* %22 to %struct.__HIP_BlockIdx*
  store %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z" addrspace(4)* @_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1zE to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"*), %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"** %104, align 8
  %106 = bitcast %struct.__HIP_BlockIdx* addrspace(5)* %19 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %106) #7
  %107 = bitcast i32 addrspace(5)* %20 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %107) #7
  %108 = addrspacecast %struct.__HIP_BlockIdx* addrspace(5)* %19 to %struct.__HIP_BlockIdx**
  %109 = addrspacecast i32 addrspace(5)* %20 to i32*
  store %struct.__HIP_BlockIdx* %105, %struct.__HIP_BlockIdx** %108, align 8
  store i32 2, i32* %109, align 4
  %110 = call i32 @llvm.amdgcn.workgroup.id.z() #7
  %111 = zext i32 %110 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %106) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %107) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %102)
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %103)
  %112 = getelementptr inbounds %struct.dim3, %struct.dim3* %1, i32 0, i32 1
  %113 = load i32, i32* %112, align 4
  %114 = mul i32 %99, %113
  store i32 %114, i32* %32, align 4
  %115 = mul i32 %110, %114
  %116 = add i32 %101, %115
  ret i32 %116
}

; Function Attrs: convergent noinline norecurse nounwind
define protected amdgpu_kernel void @_Z13gpu_mergesortPlS_lllP4dim3S1_(i64 addrspace(1)* %0, i64 addrspace(1)* %1, i64 %2, i64 %3, i64 %4, %struct.dim3 addrspace(1)* %5, %struct.dim3 addrspace(1)* %6) #3 {
  %8 = alloca %struct.__HIP_ThreadIdx*, align 8, addrspace(5)
  %9 = alloca i32, align 4, addrspace(5)
  %10 = alloca %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"*, align 8, addrspace(5)
  %11 = alloca %struct.__HIP_ThreadIdx, align 1, addrspace(5)
  %12 = alloca %struct.__HIP_ThreadIdx*, align 8, addrspace(5)
  %13 = alloca i32, align 4, addrspace(5)
  %14 = alloca %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"*, align 8, addrspace(5)
  %15 = alloca %struct.__HIP_ThreadIdx, align 1, addrspace(5)
  %16 = alloca %struct.__HIP_BlockIdx*, align 8, addrspace(5)
  %17 = alloca i32, align 4, addrspace(5)
  %18 = alloca %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"*, align 8, addrspace(5)
  %19 = alloca %struct.__HIP_BlockIdx, align 1, addrspace(5)
  %20 = alloca %struct.__HIP_BlockIdx*, align 8, addrspace(5)
  %21 = alloca i32, align 4, addrspace(5)
  %22 = alloca %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"*, align 8, addrspace(5)
  %23 = alloca %struct.__HIP_BlockIdx, align 1, addrspace(5)
  %24 = alloca %struct.__HIP_BlockIdx*, align 8, addrspace(5)
  %25 = alloca i32, align 4, addrspace(5)
  %26 = alloca %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"*, align 8, addrspace(5)
  %27 = alloca %struct.__HIP_BlockIdx, align 1, addrspace(5)
  %28 = alloca %struct.__HIP_ThreadIdx*, align 8, addrspace(5)
  %29 = alloca i32, align 4, addrspace(5)
  %30 = alloca %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"*, align 8, addrspace(5)
  %31 = alloca %struct.__HIP_ThreadIdx, align 1, addrspace(5)
  %32 = alloca %struct.dim3*, align 8, addrspace(5)
  %33 = alloca %struct.dim3*, align 8, addrspace(5)
  %34 = alloca i32, align 4, addrspace(5)
  %35 = alloca i64*, align 8, addrspace(5)
  %36 = addrspacecast i64* addrspace(5)* %35 to i64**
  %37 = alloca i64*, align 8, addrspace(5)
  %38 = addrspacecast i64* addrspace(5)* %37 to i64**
  %39 = alloca %struct.dim3*, align 8, addrspace(5)
  %40 = addrspacecast %struct.dim3* addrspace(5)* %39 to %struct.dim3**
  %41 = alloca %struct.dim3*, align 8, addrspace(5)
  %42 = addrspacecast %struct.dim3* addrspace(5)* %41 to %struct.dim3**
  %43 = alloca i64*, align 8, addrspace(5)
  %44 = addrspacecast i64* addrspace(5)* %43 to i64**
  %45 = alloca i64*, align 8, addrspace(5)
  %46 = addrspacecast i64* addrspace(5)* %45 to i64**
  %47 = alloca i64, align 8, addrspace(5)
  %48 = addrspacecast i64 addrspace(5)* %47 to i64*
  %49 = alloca i64, align 8, addrspace(5)
  %50 = addrspacecast i64 addrspace(5)* %49 to i64*
  %51 = alloca i64, align 8, addrspace(5)
  %52 = addrspacecast i64 addrspace(5)* %51 to i64*
  %53 = alloca %struct.dim3*, align 8, addrspace(5)
  %54 = addrspacecast %struct.dim3* addrspace(5)* %53 to %struct.dim3**
  %55 = alloca %struct.dim3*, align 8, addrspace(5)
  %56 = addrspacecast %struct.dim3* addrspace(5)* %55 to %struct.dim3**
  %57 = alloca i32, align 4, addrspace(5)
  %58 = addrspacecast i32 addrspace(5)* %57 to i32*
  %59 = alloca i64, align 8, addrspace(5)
  %60 = addrspacecast i64 addrspace(5)* %59 to i64*
  %61 = alloca i64, align 8, addrspace(5)
  %62 = addrspacecast i64 addrspace(5)* %61 to i64*
  %63 = alloca i64, align 8, addrspace(5)
  %64 = addrspacecast i64 addrspace(5)* %63 to i64*
  %65 = alloca i64, align 8, addrspace(5)
  %66 = addrspacecast i64 addrspace(5)* %65 to i64*
  %67 = alloca i64, align 8, addrspace(5)
  %68 = addrspacecast i64 addrspace(5)* %67 to i64*
  %69 = alloca i64, align 8, addrspace(5)
  %70 = addrspacecast i64 addrspace(5)* %69 to i64*
  %71 = alloca i64, align 8, addrspace(5)
  %72 = addrspacecast i64 addrspace(5)* %71 to i64*
  %73 = alloca i8, align 1, addrspace(5)
  %74 = addrspacecast i8 addrspace(5)* %73 to i8*
  %75 = addrspacecast i64 addrspace(1)* %0 to i64*
  store i64* %75, i64** %36, align 8
  %76 = addrspacecast i64 addrspace(1)* %1 to i64*
  store i64* %76, i64** %38, align 8
  %77 = addrspacecast %struct.dim3 addrspace(1)* %5 to %struct.dim3*
  store %struct.dim3* %77, %struct.dim3** %40, align 8
  %78 = addrspacecast %struct.dim3 addrspace(1)* %6 to %struct.dim3*
  store %struct.dim3* %78, %struct.dim3** %42, align 8
  store i64* %75, i64** %44, align 8
  store i64* %76, i64** %46, align 8
  store i64 %2, i64* %48, align 8
  store i64 %3, i64* %50, align 8
  store i64 %4, i64* %52, align 8
  store %struct.dim3* %77, %struct.dim3** %54, align 8
  store %struct.dim3* %78, %struct.dim3** %56, align 8
  %79 = bitcast %struct.dim3* addrspace(5)* %32 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %79)
  %80 = bitcast %struct.dim3* addrspace(5)* %33 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %80)
  %81 = bitcast i32 addrspace(5)* %34 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %81)
  %82 = addrspacecast %struct.dim3* addrspace(5)* %32 to %struct.dim3**
  %83 = addrspacecast %struct.dim3* addrspace(5)* %33 to %struct.dim3**
  %84 = addrspacecast i32 addrspace(5)* %34 to i32*
  store %struct.dim3* %77, %struct.dim3** %82, align 8
  store %struct.dim3* %78, %struct.dim3** %83, align 8
  %85 = bitcast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"* addrspace(5)* %30 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %85) #7
  %86 = bitcast %struct.__HIP_ThreadIdx addrspace(5)* %31 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %86) #7
  %87 = addrspacecast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"* addrspace(5)* %30 to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"**
  %88 = addrspacecast %struct.__HIP_ThreadIdx addrspace(5)* %31 to %struct.__HIP_ThreadIdx*
  store %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" addrspace(4)* @_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"*), %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X"** %87, align 8
  %89 = bitcast %struct.__HIP_ThreadIdx* addrspace(5)* %28 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %89) #7
  %90 = bitcast i32 addrspace(5)* %29 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %90) #7
  %91 = addrspacecast %struct.__HIP_ThreadIdx* addrspace(5)* %28 to %struct.__HIP_ThreadIdx**
  %92 = addrspacecast i32 addrspace(5)* %29 to i32*
  store %struct.__HIP_ThreadIdx* %88, %struct.__HIP_ThreadIdx** %91, align 8
  store i32 0, i32* %92, align 4
  %93 = call i32 @llvm.amdgcn.workitem.id.x() #7, !range !5
  %94 = zext i32 %93 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %89) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %90) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %85) #7
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %86) #7
  %95 = bitcast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"* addrspace(5)* %10 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %95) #7
  %96 = bitcast %struct.__HIP_ThreadIdx addrspace(5)* %11 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %96) #7
  %97 = addrspacecast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"* addrspace(5)* %10 to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"**
  %98 = addrspacecast %struct.__HIP_ThreadIdx addrspace(5)* %11 to %struct.__HIP_ThreadIdx*
  store %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y" addrspace(4)* @_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1yE to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"*), %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Y"** %97, align 8
  %99 = bitcast %struct.__HIP_ThreadIdx* addrspace(5)* %8 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %99) #7
  %100 = bitcast i32 addrspace(5)* %9 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %100) #7
  %101 = addrspacecast %struct.__HIP_ThreadIdx* addrspace(5)* %8 to %struct.__HIP_ThreadIdx**
  %102 = addrspacecast i32 addrspace(5)* %9 to i32*
  store %struct.__HIP_ThreadIdx* %98, %struct.__HIP_ThreadIdx** %101, align 8
  store i32 1, i32* %102, align 4
  %103 = call i32 @llvm.amdgcn.workitem.id.y() #7, !range !5
  %104 = zext i32 %103 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %99) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %100) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %95) #7
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %96) #7
  %105 = getelementptr inbounds %struct.dim3, %struct.dim3* %77, i32 0, i32 0
  %106 = load i32, i32* %105, align 4
  store i32 %106, i32* %84, align 4
  %107 = mul i32 %103, %106
  %108 = add i32 %93, %107
  %109 = bitcast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"* addrspace(5)* %14 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %109) #7
  %110 = bitcast %struct.__HIP_ThreadIdx addrspace(5)* %15 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %110) #7
  %111 = addrspacecast %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"* addrspace(5)* %14 to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"**
  %112 = addrspacecast %struct.__HIP_ThreadIdx addrspace(5)* %15 to %struct.__HIP_ThreadIdx*
  store %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z" addrspace(4)* @_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1zE to %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"*), %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::Z"** %111, align 8
  %113 = bitcast %struct.__HIP_ThreadIdx* addrspace(5)* %12 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %113) #7
  %114 = bitcast i32 addrspace(5)* %13 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %114) #7
  %115 = addrspacecast %struct.__HIP_ThreadIdx* addrspace(5)* %12 to %struct.__HIP_ThreadIdx**
  %116 = addrspacecast i32 addrspace(5)* %13 to i32*
  store %struct.__HIP_ThreadIdx* %112, %struct.__HIP_ThreadIdx** %115, align 8
  store i32 2, i32* %116, align 4
  %117 = call i32 @llvm.amdgcn.workitem.id.z() #7, !range !5
  %118 = zext i32 %117 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %113) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %114) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %109) #7
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %110) #7
  %119 = getelementptr inbounds %struct.dim3, %struct.dim3* %77, i32 0, i32 1
  %120 = load i32, i32* %119, align 4
  %121 = mul i32 %106, %120
  store i32 %121, i32* %84, align 4
  %122 = mul i32 %117, %121
  %123 = add i32 %108, %122
  %124 = bitcast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"* addrspace(5)* %18 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %124) #7
  %125 = bitcast %struct.__HIP_BlockIdx addrspace(5)* %19 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %125) #7
  %126 = addrspacecast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"* addrspace(5)* %18 to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"**
  %127 = addrspacecast %struct.__HIP_BlockIdx addrspace(5)* %19 to %struct.__HIP_BlockIdx*
  store %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" addrspace(4)* @_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"*), %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X"** %126, align 8
  %128 = bitcast %struct.__HIP_BlockIdx* addrspace(5)* %16 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %128) #7
  %129 = bitcast i32 addrspace(5)* %17 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %129) #7
  %130 = addrspacecast %struct.__HIP_BlockIdx* addrspace(5)* %16 to %struct.__HIP_BlockIdx**
  %131 = addrspacecast i32 addrspace(5)* %17 to i32*
  store %struct.__HIP_BlockIdx* %127, %struct.__HIP_BlockIdx** %130, align 8
  store i32 0, i32* %131, align 4
  %132 = call i32 @llvm.amdgcn.workgroup.id.x() #7
  %133 = zext i32 %132 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %128) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %129) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %124) #7
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %125) #7
  %134 = getelementptr inbounds %struct.dim3, %struct.dim3* %77, i32 0, i32 2
  %135 = load i32, i32* %134, align 4
  %136 = mul i32 %121, %135
  store i32 %136, i32* %84, align 4
  %137 = mul i32 %132, %136
  %138 = add i32 %123, %137
  %139 = bitcast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"* addrspace(5)* %22 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %139) #7
  %140 = bitcast %struct.__HIP_BlockIdx addrspace(5)* %23 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %140) #7
  %141 = addrspacecast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"* addrspace(5)* %22 to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"**
  %142 = addrspacecast %struct.__HIP_BlockIdx addrspace(5)* %23 to %struct.__HIP_BlockIdx*
  store %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y" addrspace(4)* @_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1yE to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"*), %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Y"** %141, align 8
  %143 = bitcast %struct.__HIP_BlockIdx* addrspace(5)* %20 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %143) #7
  %144 = bitcast i32 addrspace(5)* %21 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %144) #7
  %145 = addrspacecast %struct.__HIP_BlockIdx* addrspace(5)* %20 to %struct.__HIP_BlockIdx**
  %146 = addrspacecast i32 addrspace(5)* %21 to i32*
  store %struct.__HIP_BlockIdx* %142, %struct.__HIP_BlockIdx** %145, align 8
  store i32 1, i32* %146, align 4
  %147 = call i32 @llvm.amdgcn.workgroup.id.y() #7
  %148 = zext i32 %147 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %143) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %144) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %139) #7
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %140) #7
  %149 = getelementptr inbounds %struct.dim3, %struct.dim3* %78, i32 0, i32 2
  %150 = load i32, i32* %149, align 4
  %151 = mul i32 %136, %150
  store i32 %151, i32* %84, align 4
  %152 = mul i32 %147, %151
  %153 = add i32 %138, %152
  %154 = bitcast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"* addrspace(5)* %26 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %154) #7
  %155 = bitcast %struct.__HIP_BlockIdx addrspace(5)* %27 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 1, i8 addrspace(5)* %155) #7
  %156 = addrspacecast %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"* addrspace(5)* %26 to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"**
  %157 = addrspacecast %struct.__HIP_BlockIdx addrspace(5)* %27 to %struct.__HIP_BlockIdx*
  store %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"* addrspacecast (%"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z" addrspace(4)* @_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1zE to %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"*), %"struct.__HIP_Coordinates<__HIP_BlockIdx>::Z"** %156, align 8
  %158 = bitcast %struct.__HIP_BlockIdx* addrspace(5)* %24 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 8, i8 addrspace(5)* %158) #7
  %159 = bitcast i32 addrspace(5)* %25 to i8 addrspace(5)*
  call void @llvm.lifetime.start.p5i8(i64 4, i8 addrspace(5)* %159) #7
  %160 = addrspacecast %struct.__HIP_BlockIdx* addrspace(5)* %24 to %struct.__HIP_BlockIdx**
  %161 = addrspacecast i32 addrspace(5)* %25 to i32*
  store %struct.__HIP_BlockIdx* %157, %struct.__HIP_BlockIdx** %160, align 8
  store i32 2, i32* %161, align 4
  %162 = call i32 @llvm.amdgcn.workgroup.id.z() #7
  %163 = zext i32 %162 to i64
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %158) #7
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %159) #7
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %154) #7
  call void @llvm.lifetime.end.p5i8(i64 1, i8 addrspace(5)* %155) #7
  %164 = getelementptr inbounds %struct.dim3, %struct.dim3* %78, i32 0, i32 1
  %165 = load i32, i32* %164, align 4
  %166 = mul i32 %151, %165
  store i32 %166, i32* %84, align 4
  %167 = mul i32 %162, %166
  %168 = add i32 %153, %167
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %79)
  call void @llvm.lifetime.end.p5i8(i64 8, i8 addrspace(5)* %80)
  call void @llvm.lifetime.end.p5i8(i64 4, i8 addrspace(5)* %81)
  store i32 %168, i32* %58, align 4
  %169 = zext i32 %168 to i64
  %170 = mul nsw i64 %3, %169
  %171 = mul nsw i64 %170, %4
  store i64 %171, i64* %60, align 8
  store i64 0, i64* %66, align 8
  br label %172

172:                                              ; preds = %250, %7
  %173 = phi i64* [ %201, %250 ], [ %76, %7 ]
  %174 = phi i64* [ %202, %250 ], [ %75, %7 ]
  %175 = phi i64* [ %205, %250 ], [ %75, %7 ]
  %176 = phi i64 [ %197, %250 ], [ %2, %7 ]
  %177 = phi i64 [ %198, %250 ], [ %2, %7 ]
  %178 = phi i64 [ %192, %250 ], [ %171, %7 ]
  %179 = phi i64 [ %251, %250 ], [ 0, %7 ]
  %180 = icmp slt i64 %179, %4
  br i1 %180, label %181, label %252

181:                                              ; preds = %172
  %182 = icmp sge i64 %178, %177
  br i1 %182, label %183, label %184

183:                                              ; preds = %181
  br label %252

184:                                              ; preds = %181
  %185 = ashr i64 %3, 1
  %186 = add nsw i64 %178, %185
  %187 = icmp slt i64 %186, %177
  br i1 %187, label %188, label %189

188:                                              ; preds = %184
  br label %190

189:                                              ; preds = %184
  br label %190

190:                                              ; preds = %189, %188
  %191 = phi i64 [ %186, %188 ], [ %177, %189 ]
  store i64 %191, i64* %62, align 8
  %192 = add nsw i64 %178, %3
  %193 = icmp slt i64 %192, %176
  br i1 %193, label %194, label %195

194:                                              ; preds = %190
  br label %196

195:                                              ; preds = %190
  br label %196

196:                                              ; preds = %195, %194
  %197 = phi i64 [ %176, %194 ], [ %2, %195 ]
  %198 = phi i64 [ %176, %194 ], [ %2, %195 ]
  %199 = phi i64 [ %192, %194 ], [ %2, %195 ]
  store i64 %199, i64* %64, align 8
  store i64 %178, i64* %68, align 8
  store i64 %191, i64* %70, align 8
  store i64 %178, i64* %72, align 8
  br label %200

200:                                              ; preds = %241, %196
  %201 = phi i64* [ %242, %241 ], [ %173, %196 ]
  %202 = phi i64* [ %243, %241 ], [ %174, %196 ]
  %203 = phi i64 [ %244, %241 ], [ %191, %196 ]
  %204 = phi i64 [ %245, %241 ], [ %178, %196 ]
  %205 = phi i64* [ %246, %241 ], [ %175, %196 ]
  %206 = phi i64 [ %247, %241 ], [ %191, %196 ]
  %207 = phi i64 [ %248, %241 ], [ %178, %196 ]
  %208 = phi i64 [ %228, %241 ], [ %199, %196 ]
  %209 = phi i64 [ %249, %241 ], [ %178, %196 ]
  %210 = icmp slt i64 %209, %208
  br i1 %210, label %211, label %250

211:                                              ; preds = %200
  %212 = icmp slt i64 %207, %191
  br i1 %212, label %213, label %225

213:                                              ; preds = %211
  %214 = icmp sge i64 %206, %199
  br i1 %214, label %221, label %215

215:                                              ; preds = %213
  %216 = getelementptr inbounds i64, i64* %205, i64 %204
  %217 = load i64, i64* %216, align 8
  %218 = getelementptr inbounds i64, i64* %205, i64 %203
  %219 = load i64, i64* %218, align 8
  %220 = icmp slt i64 %217, %219
  br label %221

221:                                              ; preds = %215, %213
  %222 = phi i64 [ %206, %213 ], [ %203, %215 ]
  %223 = phi i64 [ %207, %213 ], [ %204, %215 ]
  %224 = phi i1 [ true, %213 ], [ %220, %215 ]
  br label %225

225:                                              ; preds = %221, %211
  %226 = phi i64 [ %206, %211 ], [ %222, %221 ]
  %227 = phi i64 [ %207, %211 ], [ %223, %221 ]
  %228 = phi i64 [ %208, %211 ], [ %199, %221 ]
  %229 = phi i1 [ false, %211 ], [ %224, %221 ]
  %230 = zext i1 %229 to i8
  store i8 %230, i8* %74, align 1
  br i1 %229, label %231, label %236

231:                                              ; preds = %225
  %232 = getelementptr inbounds i64, i64* %75, i64 %204
  %233 = load i64, i64* %232, align 8
  %234 = getelementptr inbounds i64, i64* %76, i64 %209
  store i64 %233, i64* %234, align 8
  %235 = add nsw i64 %204, 1
  store i64 %235, i64* %68, align 8
  br label %241

236:                                              ; preds = %225
  %237 = getelementptr inbounds i64, i64* %202, i64 %203
  %238 = load i64, i64* %237, align 8
  %239 = getelementptr inbounds i64, i64* %201, i64 %209
  store i64 %238, i64* %239, align 8
  %240 = add nsw i64 %203, 1
  store i64 %240, i64* %70, align 8
  br label %241

241:                                              ; preds = %236, %231
  %242 = phi i64* [ %201, %236 ], [ %76, %231 ]
  %243 = phi i64* [ %202, %236 ], [ %75, %231 ]
  %244 = phi i64 [ %240, %236 ], [ %203, %231 ]
  %245 = phi i64 [ %204, %236 ], [ %235, %231 ]
  %246 = phi i64* [ %202, %236 ], [ %75, %231 ]
  %247 = phi i64 [ %240, %236 ], [ %226, %231 ]
  %248 = phi i64 [ %227, %236 ], [ %235, %231 ]
  %249 = add nsw i64 %209, 1
  store i64 %249, i64* %72, align 8
  br label %200, !llvm.loop !6

250:                                              ; preds = %200
  store i64 %192, i64* %60, align 8
  %251 = add nsw i64 %179, 1
  store i64 %251, i64* %66, align 8
  br label %172, !llvm.loop !8

252:                                              ; preds = %183, %172
  ret void
}

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #4

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.y() #4

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.z() #4

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #4

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.y() #4

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.z() #4

; Function Attrs: argmemonly nounwind willreturn
declare void @llvm.lifetime.start.p5i8(i64 immarg, i8 addrspace(5)* nocapture) #5

; Function Attrs: argmemonly nounwind willreturn
declare void @llvm.lifetime.end.p5i8(i64 immarg, i8 addrspace(5)* nocapture) #5

attributes #0 = { convergent noinline nounwind "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="all" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { cold noreturn nounwind }
attributes #2 = { alwaysinline convergent nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="all" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+add-no-carry-insts,+aperture-regs,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+ds-src2-insts,+enable-ds128,+enable-prt-strict-null,+fast-denormal-f32,+fast-fmaf,+flat-address-space,+flat-for-global,+flat-global-insts,+flat-inst-offsets,+flat-scratch-insts,+fma-mix-insts,+fp64,+gcn3-encoding,+gfx7-gfx8-gfx9-insts,+gfx8-insts,+gfx9,+gfx9-insts,+half-rate-64-ops,+image-gather4-d16-bug,+int-clamp-insts,+inv-2pi-inline-imm,+ldsbankcount32,+load-store-opt,+localmemorysize65536,+mad-mac-f32-insts,+promote-alloca,+r128-a16,+s-memrealtime,+s-memtime-inst,+scalar-atomics,+scalar-flat-scratch-insts,+scalar-stores,+sdwa,+sdwa-omod,+sdwa-scalar,+sdwa-sdst,+sramecc-support,+trap-handler,+unaligned-access-mode,+unaligned-buffer-access,+unaligned-ds-access,+vgpr-index-mode,+vop3p,-wavefrontsize16,-wavefrontsize32,+wavefrontsize64,+xnack-support" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #3 = { convergent noinline norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="all" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #4 = { nounwind readnone speculatable willreturn }
attributes #5 = { argmemonly nounwind willreturn }
attributes #6 = { convergent nounwind }
attributes #7 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3, !3}
!opencl.ocl.version = !{!4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!3 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!4 = !{i32 2, i32 0}
!5 = !{i32 0, i32 1024}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
