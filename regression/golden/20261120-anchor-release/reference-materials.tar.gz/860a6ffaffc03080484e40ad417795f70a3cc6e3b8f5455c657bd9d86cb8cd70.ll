; ModuleID = '/data/home/chh/simplify-v2/build/simplify-fingerprint/active/MapAiry/trial-318/fused.ll'
source_filename = "/home/chh/kernel-benchmark-suite/cases/boost-mapairy/source/kernel.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

@_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction = internal local_unnamed_addr addrspace(4) constant [5 x double] [double 0x3FE428A2F98D728B, double 0x3FE965FEA53D6E3D, double 1.000000e+00, double 0x3FF428A2F98D728B, double 0x3FF965FEA53D6E3D], align 16

; Function Attrs: nofree norecurse nounwind
define protected amdgpu_kernel void @evaluate(double addrspace(1)* nocapture readonly %input.coerce, double addrspace(1)* nocapture %output.coerce, i32 %n) local_unnamed_addr #0 {
entry:
  %0 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %1 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %2 = getelementptr i8, i8 addrspace(4)* %1, i64 4
  %3 = bitcast i8 addrspace(4)* %2 to i16 addrspace(4)*
  %4 = load i16, i16 addrspace(4)* %3, align 4, !range !5, !invariant.load !6
  %5 = zext i16 %4 to i32
  %6 = mul i32 %0, %5
  %7 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !7
  %add = add i32 %6, %7
  %cmp = icmp slt i32 %add, %n
  br i1 %cmp, label %if.end8.i.i, label %if.end

if.end8.i.i:                                      ; preds = %entry
  %idxprom = sext i32 %add to i64
  %arrayidx11 = getelementptr inbounds double, double addrspace(1)* %input.coerce, i64 %idxprom
  %arrayidx.val = load double, double addrspace(1)* %arrayidx11, align 8, !tbaa !8
  %cmp.i3.i.i = fcmp olt double %arrayidx.val, 0.000000e+00
  %cmp1.i.i.i = fcmp ogt double %arrayidx.val, 1.000000e+00
  %or.cond.i.i.i = or i1 %cmp.i3.i.i, %cmp1.i.i.i
  br i1 %or.cond.i.i.i, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %lor.lhs.false2.i.i.i

lor.lhs.false2.i.i.i:                             ; preds = %if.end8.i.i
  %cmp.i.i.i.i.i = fcmp uno double %arrayidx.val, 0.000000e+00
  %cmp.i3.i.i.i.i = fcmp ogt double %arrayidx.val, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i4.i.i = fcmp olt double %arrayidx.val, 0xFFEFFFFFFFFFFFFF
  %lnot.i.i.i.i.not = or i1 %cmp.i3.i.i.i.i, %cmp1.i.i.i4.i.i
  %brmerge = or i1 %cmp.i.i.i.i.i, %lnot.i.i.i.i.not
  br i1 %brmerge, label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, label %if.end14.i.i

if.end14.i.i:                                     ; preds = %lor.lhs.false2.i.i.i
  %cmp.i.i.i = fcmp ogt double %arrayidx.val, 5.000000e-01
  br i1 %cmp.i.i.i, label %if.then.i.i.i, label %cond.false7.i.i.i

if.then.i.i.i:                                    ; preds = %if.end14.i.i
  %sub.i.i.i = fsub double 1.000000e+00, %arrayidx.val
  %decision.interval4 = fcmp ult double %sub.i.i.i, 1.250000e-01
  br i1 %decision.interval4, label %if.else9.i.i.i.i, label %decision.dispatch3, !decision.condition_prefix !6

decision.dispatch3:                               ; preds = %if.then.i.i.i
  %cmp.i.i.i.i = fcmp ult double %sub.i.i.i, 2.500000e-01
  %8 = select i1 %cmp.i.i.i.i, double -1.250000e-01, double -2.500000e-01
  %9 = fadd double %sub.i.i.i, %8
  %10 = fmul double %9, %9
  %11 = fmul double %10, 0x409819CEF5B4E6C7
  %12 = fadd double %11, 0xC096FC492E087B38
  %13 = select i1 %cmp.i.i.i.i, double 0x4051B7FD7FEEB259, double 0x404567B47A5D8CA4
  %14 = fmul double %10, %13
  %15 = select i1 %cmp.i.i.i.i, double 0xC07E56261CB553E9, double 0x405E69E51891A050
  %16 = fsub double %15, %14
  %17 = fmul double %10, 0x4050AAC38C60A1E3
  %18 = fsub double 0x40548E4AE13E33D8, %17
  %19 = fmul double %10, %16
  %20 = select i1 %cmp.i.i.i.i, double %12, double %18
  %21 = fmul double %10, %20
  %.op = fadd double %19, 0xC04860792DC1D02E
  %22 = select i1 %cmp.i.i.i.i, double 0x4036AD73494335DA, double 0xC0407FAA65922A12
  %23 = fadd double %21, %22
  %24 = fmul double %10, %.op
  %.op1 = fadd double %19, 0x4034FFCB850049DF
  %25 = fmul double %10, %23
  %.op2 = fadd double %24, 0xC005F196AB7EF904
  %26 = select i1 %cmp.i.i.i.i, double 0x3FFB3E8B8B7EC8F9, double 0x3FDED118296B2018
  %27 = fadd double %25, %26
  %28 = select i1 %cmp.i.i.i.i, double %.op1, double %.op2
  %29 = fmul double %9, %28
  %30 = fadd double %27, %29
  br i1 %cmp.i.i.i.i, label %fusion.common11, label %fusion.side12

if.else9.i.i.i.i:                                 ; preds = %if.then.i.i.i
  %31 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %sub.i.i.i) #3
  %32 = add nsw i32 %31, -1
  %33 = fcmp uno double %sub.i.i.i, 0.000000e+00
  %34 = tail call double @llvm.fabs.f64(double %sub.i.i.i) #4
  %35 = fcmp oeq double %34, 0x7FF0000000000000
  %36 = or i1 %33, %35
  %37 = select i1 %36, i32 2147483647, i32 %32
  %38 = fcmp oeq double %sub.i.i.i, 0.000000e+00
  %39 = select i1 %38, i32 -2147483648, i32 %37
  %cmp11.i.i.i.i = icmp sgt i32 %39, -5
  br i1 %cmp11.i.i.i.i, label %if.then12.i.i.i.i, label %if.else21.i.i.i.i

if.then12.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %40 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 3) #3
  %41 = tail call double @llvm.amdgcn.frexp.mant.f64(double %40) #3
  %42 = fcmp olt double %41, 0x3FE5555555555555
  %43 = zext i1 %42 to i32
  %44 = tail call double @llvm.amdgcn.ldexp.f64(double %41, i32 %43) #3
  %45 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %40) #3
  %46 = sub nsw i32 %45, %43
  %47 = fadd double %44, -1.000000e+00
  %48 = fadd double %44, 1.000000e+00
  %49 = fsub double %48, %44
  %50 = fsub double %48, %49
  %51 = fsub double %44, %50
  %52 = fsub double 1.000000e+00, %49
  %53 = fadd double %52, %51
  %54 = tail call double @llvm.amdgcn.rcp.f64(double %48) #3
  %55 = fneg double %48
  %56 = tail call double @llvm.fma.f64(double %55, double %54, double 1.000000e+00) #3
  %57 = tail call double @llvm.fma.f64(double %56, double %54, double %54) #3
  %58 = tail call double @llvm.fma.f64(double %55, double %57, double 1.000000e+00) #3
  %59 = tail call double @llvm.fma.f64(double %58, double %57, double %57) #3
  %60 = fmul double %47, %59
  %61 = fmul double %48, %60
  %62 = fneg double %61
  %63 = tail call double @llvm.fma.f64(double %60, double %48, double %62) #3
  %64 = tail call double @llvm.fma.f64(double %60, double %53, double %63) #3
  %65 = fadd double %61, %64
  %66 = fsub double %65, %61
  %67 = fsub double %64, %66
  %68 = fsub double %47, %65
  %69 = fsub double %47, %68
  %70 = fsub double %69, %65
  %71 = fsub double %70, %67
  %72 = fadd double %68, %71
  %73 = fmul double %59, %72
  %74 = fadd double %60, %73
  %75 = fsub double %74, %60
  %76 = fsub double %73, %75
  %77 = fmul double %74, %74
  %78 = fneg double %77
  %79 = tail call double @llvm.fma.f64(double %74, double %74, double %78) #3
  %80 = fmul double %76, 2.000000e+00
  %81 = tail call double @llvm.fma.f64(double %74, double %80, double %79) #3
  %82 = tail call double @llvm.fma.f64(double %76, double %76, double %81) #3
  %83 = fadd double %77, %82
  %84 = fsub double %83, %77
  %85 = fsub double %82, %84
  %86 = tail call double @llvm.fma.f64(double %83, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %87 = tail call double @llvm.fma.f64(double %83, double %86, double 0x3FC7474DD7F4DF2E) #3
  %88 = tail call double @llvm.fma.f64(double %83, double %87, double 0x3FCC71C016291751) #3
  %89 = tail call double @llvm.fma.f64(double %83, double %88, double 0x3FD249249B27ACF1) #3
  %90 = tail call double @llvm.fma.f64(double %83, double %89, double 0x3FD99999998EF7B6) #3
  %91 = tail call double @llvm.fma.f64(double %83, double %90, double 0x3FE5555555555780) #3
  %92 = tail call double @llvm.amdgcn.ldexp.f64(double %74, i32 1) #3
  %93 = tail call double @llvm.amdgcn.ldexp.f64(double %76, i32 1) #3
  %94 = fmul double %74, %83
  %95 = fneg double %94
  %96 = tail call double @llvm.fma.f64(double %74, double %83, double %95) #3
  %97 = fmul double %76, %83
  %98 = tail call double @llvm.fma.f64(double %74, double %85, double %97) #3
  %99 = fadd double %96, %98
  %100 = fadd double %94, %99
  %101 = fsub double %100, %94
  %102 = fsub double %99, %101
  %103 = fmul double %100, %91
  %104 = fneg double %103
  %105 = tail call double @llvm.fma.f64(double %100, double %91, double %104) #3
  %106 = tail call double @llvm.fma.f64(double %102, double %91, double %105) #3
  %107 = fadd double %103, %106
  %108 = fsub double %107, %103
  %109 = fsub double %106, %108
  %110 = fadd double %92, %107
  %111 = fsub double %110, %92
  %112 = fsub double %110, %111
  %113 = fsub double %92, %112
  %114 = fsub double %107, %111
  %115 = fadd double %114, %113
  %116 = fadd double %93, %109
  %117 = fsub double %116, %93
  %118 = fsub double %116, %117
  %119 = fsub double %93, %118
  %120 = fsub double %109, %117
  %121 = fadd double %120, %119
  %122 = fadd double %116, %115
  %123 = fadd double %110, %122
  %124 = fsub double %123, %110
  %125 = fsub double %122, %124
  %126 = fadd double %121, %125
  %127 = fadd double %123, %126
  %128 = fsub double %127, %123
  %129 = fsub double %126, %128
  %130 = sitofp i32 %46 to double
  %131 = fmul double %127, 0x3FF71547652B82FE
  %132 = fneg double %131
  %133 = fmul double %127, 0x3C7777D0FFDA0D24
  %134 = insertelement <2 x double> undef, double %127, i32 0
  %135 = insertelement <2 x double> %134, double %129, i32 1
  %136 = insertelement <2 x double> undef, double %132, i32 0
  %137 = insertelement <2 x double> %136, double %133, i32 1
  %138 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %135, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %137) #3
  %139 = extractelement <2 x double> %138, i32 0
  %140 = extractelement <2 x double> %138, i32 1
  %141 = fadd double %139, %140
  %142 = fadd double %131, %141
  %143 = fsub double %142, %131
  %144 = fsub double %141, %143
  %145 = fadd double %142, %130
  %146 = fsub double %145, %130
  %147 = fsub double %146, %145
  %148 = fadd double %147, %130
  %149 = fsub double %142, %146
  %150 = fadd double %149, %148
  %151 = fadd double %144, %150
  %152 = fadd double %145, %151
  %153 = tail call double @llvm.fabs.f64(double %40) #4
  %154 = fcmp oeq double %153, 0x7FF0000000000000
  %155 = select i1 %154, double %40, double %152
  %156 = fcmp olt double %40, 0.000000e+00
  %157 = select i1 %156, double 0x7FF8000000000000, double %155
  %158 = fcmp oeq double %40, 0.000000e+00
  %159 = select i1 %158, double 0xFFF0000000000000, double %157
  %mul.i.i682.i.i.i.i = fmul double %159, %159
  %mul1.i.i683.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3ED3E1F985CBB733
  %add.i.i684.i.i.i.i = fadd double %mul1.i.i683.i.i.i.i, 0x3F385DA443F57737
  %mul5.i.i685.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F24E9382EAABDBB
  %add7.i.i686.i.i.i.i = fadd double %mul5.i.i685.i.i.i.i, 0x3F77E2A342AA4E3B
  %mul10.i.i687.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i684.i.i.i.i
  %mul12.i.i688.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i686.i.i.i.i
  %add15.i.i689.i.i.i.i = fadd double %mul10.i.i687.i.i.i.i, 0x3F9808F2B640E69B
  %add18.i.i690.i.i.i.i = fadd double %mul12.i.i688.i.i.i.i, 0x3F9DD5C523A6CF6D
  %mul20.i.i691.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i689.i.i.i.i
  %mul22.i.i692.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i690.i.i.i.i
  %add25.i.i693.i.i.i.i = fadd double %mul20.i.i691.i.i.i.i, 0x3FD3E6D375851610
  %add28.i.i694.i.i.i.i = fadd double %mul22.i.i692.i.i.i.i, 0x3FDB3E8B8B7EC8FA
  %160 = fmul double %159, %add25.i.i693.i.i.i.i
  %add33.i.i696.i.i.i.i = fsub double %add28.i.i694.i.i.i.i, %160
  %mul1.i.i668.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3EF03AD80F271435
  %add.i.i669.i.i.i.i = fadd double %mul1.i.i668.i.i.i.i, 0x3F577B23357A1929
  %mul5.i.i670.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, 0x3F27C5B13F4BAFF2
  %add7.i.i671.i.i.i.i = fadd double %mul5.i.i670.i.i.i.i, 0x3F825620F70E4E86
  %mul10.i.i672.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add.i.i669.i.i.i.i
  %mul12.i.i673.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add7.i.i671.i.i.i.i
  %add15.i.i674.i.i.i.i = fadd double %mul10.i.i672.i.i.i.i, 0x3FA38976FFA62DF3
  %add18.i.i675.i.i.i.i = fadd double %mul12.i.i673.i.i.i.i, 0x3FBACD3553111974
  %mul20.i.i676.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add15.i.i674.i.i.i.i
  %mul22.i.i677.i.i.i.i = fmul double %mul.i.i682.i.i.i.i, %add18.i.i675.i.i.i.i
  %add25.i.i678.i.i.i.i = fadd double %mul20.i.i676.i.i.i.i, 0x3FDA8C1A7A09CF75
  %add28.i.i679.i.i.i.i = fadd double %mul22.i.i677.i.i.i.i, 1.000000e+00
  %161 = fmul double %159, %add25.i.i678.i.i.i.i
  %add33.i.i681.i.i.i.i = fsub double %add28.i.i679.i.i.i.i, %161
  %mul.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i590.i.i.i.i = fcmp ogt double %mul.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i591.i.i.i.i = fcmp oeq double %mul.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i592.i.i.i.i = or i1 %cmp.i.i.i.i590.i.i.i.i, %cmp.i.i.i591.i.i.i.i
  br i1 %or.cond.i.i.i592.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end.i.i.i594.i.i.i.i

if.end.i.i.i594.i.i.i.i:                          ; preds = %if.then12.i.i.i.i
  %cmp.i.i.i.i.i593.i.i.i.i = fcmp uno double %mul.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i593.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i, label %if.end7.i.i.i620.i.i.i.i

if.end7.i.i.i620.i.i.i.i:                         ; preds = %if.end.i.i.i594.i.i.i.i
  %162 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul.i.i.i.i) #3
  %163 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul.i.i.i.i) #3
  %164 = tail call i1 @llvm.amdgcn.class.f64(double %mul.i.i.i.i, i32 519) #3
  %165 = select i1 %164, i32 0, i32 %162
  %166 = select i1 %164, double %mul.i.i.i.i, double %163
  %mul.i.i.i.i.i606.i.i.i.i = fmul double %166, %166
  %mul1.i.i.i.i.i607.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i608.i.i.i.i = fadd double %mul1.i.i.i.i.i607.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i609.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, 0x3FE479D17050CA47
  %167 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i609.i.i.i.i
  %mul10.i.i.i.i.i611.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %add.i.i.i.i.i608.i.i.i.i
  %mul12.i.i.i.i.i612.i.i.i.i = fmul double %mul.i.i.i.i.i606.i.i.i.i, %167
  %add15.i.i.i.i.i613.i.i.i.i = fadd double %mul10.i.i.i.i.i611.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i614.i.i.i.i = fadd double %mul12.i.i.i.i.i612.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i615.i.i.i.i = fmul double %166, %add15.i.i.i.i.i613.i.i.i.i
  %add23.i.i.i.i.i616.i.i.i.i = fadd double %add18.i.i.i.i.i614.i.i.i.i, %mul20.i.i.i.i.i615.i.i.i.i
  %.frozen = freeze i32 %165
  %div.i.i.i617.i.i.i.i = sdiv i32 %.frozen, 3
  %168 = call i32 @llvm.abs.i32(i32 %div.i.i.i617.i.i.i.i, i1 true)
  %cmp11.i.i.i619.i.i.i.i = icmp ult i32 %168, 64
  %169 = sub nsw i32 0, %div.i.i.i617.i.i.i.i
  %170 = icmp sgt i32 %165, 2
  %171 = select i1 %170, i32 %div.i.i.i617.i.i.i.i, i32 %169
  %172 = zext i32 %171 to i64
  %173 = shl nuw i64 1, %172
  %174 = uitofp i64 %173 to double
  %not.cmp11.i.i.i619.i.i.i.i = xor i1 %cmp11.i.i.i619.i.i.i.i, true
  %175 = or i1 %170, %not.cmp11.i.i.i619.i.i.i.i
  br i1 %175, label %merged.bb3, label %merged.bb4

do.body.i.i.i651.i.i.i.i:                         ; preds = %merged.bb5, %do.body.i.i.i651.i.i.i.i
  %guess.i.i.i589.i.i.i.i.1 = phi double [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ], [ %mul24.i.i.i638.i.i.i.i, %merged.bb5 ]
  %mul28.i.i.i641.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %guess.i.i.i589.i.i.i.i.1
  %mul29.i.i.i642.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %mul28.i.i.i641.i.i.i.i
  %add30.i.i.i643.i.i.i.i = fadd double %mul.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add31.i.i.i644.i.i.i.i = fadd double %mul.i.i.i.i, %add30.i.i.i643.i.i.i.i
  %add32.i.i.i645.i.i.i.i = fadd double %mul29.i.i.i642.i.i.i.i, %mul29.i.i.i642.i.i.i.i
  %add33.i.i.i646.i.i.i.i = fadd double %mul.i.i.i.i, %add32.i.i.i645.i.i.i.i
  %div34.i.i.i647.i.i.i.i = fdiv double %add31.i.i.i644.i.i.i.i, %add33.i.i.i646.i.i.i.i
  %mul35.i.i.i648.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.1, %div34.i.i.i647.i.i.i.i
  %sub36.i.i.i649.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i647.i.i.i.i
  %176 = tail call double @llvm.fabs.f64(double %sub36.i.i.i649.i.i.i.i) #3
  %cmp38.i.i.i650.i.i.i.i = fcmp ogt double %176, 0x3EC0000000000000
  br i1 %cmp38.i.i.i650.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

do.body40.i.i.i662.i.i.i.i:                       ; preds = %merged.bb5, %do.body40.i.i.i662.i.i.i.i
  %guess.i.i.i589.i.i.i.i.2 = phi double [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ], [ %mul24.i.i.i638.i.i.i.i, %merged.bb5 ]
  %mul41.i.i.i652.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, %guess.i.i.i589.i.i.i.i.2
  %div42.i.i.i653.i.i.i.i = fdiv double %mul.i.i.i.i, %guess.i.i.i589.i.i.i.i.2
  %sub43.i.i.i654.i.i.i.i = fsub double %mul41.i.i.i652.i.i.i.i, %div42.i.i.i653.i.i.i.i
  %mul44.i.i.i655.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i656.i.i.i.i = fdiv double %mul.i.i.i.i, %mul41.i.i.i652.i.i.i.i
  %add46.i.i.i657.i.i.i.i = fadd double %mul44.i.i.i655.i.i.i.i, %div45.i.i.i656.i.i.i.i
  %div47.i.i.i658.i.i.i.i = fdiv double %sub43.i.i.i654.i.i.i.i, %add46.i.i.i657.i.i.i.i
  %sub48.i.i.i659.i.i.i.i = fsub double %guess.i.i.i589.i.i.i.i.2, %div47.i.i.i658.i.i.i.i
  %mul50.i.i.i660.i.i.i.i = fmul double %sub48.i.i.i659.i.i.i.i, 0x3EC0000000000000
  %177 = tail call double @llvm.fabs.f64(double %div47.i.i.i658.i.i.i.i) #3
  %cmp52.i.i.i661.i.i.i.i = fcmp olt double %mul50.i.i.i660.i.i.i.i, %177
  br i1 %cmp52.i.i.i661.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i: ; preds = %do.body40.i.i.i662.i.i.i.i, %do.body.i.i.i651.i.i.i.i, %if.end.i.i.i594.i.i.i.i, %if.then12.i.i.i.i
  %retval.0.i.i.i665.i.i.i.i = phi double [ %mul.i.i.i.i, %if.then12.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i594.i.i.i.i ], [ %mul35.i.i.i648.i.i.i.i, %do.body.i.i.i651.i.i.i.i ], [ %sub48.i.i.i659.i.i.i.i, %do.body40.i.i.i662.i.i.i.i ]
  %mul19.i.i.i.i = fmul double %add33.i.i681.i.i.i.i, %retval.0.i.i.i665.i.i.i.i
  %div20.i.i.i.i = fdiv double %add33.i.i696.i.i.i.i, %mul19.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else21.i.i.i.i:                                ; preds = %if.else9.i.i.i.i
  %cmp23.i.i.i.i = icmp sgt i32 %39, -9
  br i1 %cmp23.i.i.i.i, label %if.then24.i.i.i.i, label %if.else35.i.i.i.i

if.then24.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %178 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 4) #3
  %179 = tail call double @llvm.amdgcn.frexp.mant.f64(double %178) #3
  %180 = fcmp olt double %179, 0x3FE5555555555555
  %181 = zext i1 %180 to i32
  %182 = tail call double @llvm.amdgcn.ldexp.f64(double %179, i32 %181) #3
  %183 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %178) #3
  %184 = sub nsw i32 %183, %181
  %185 = fadd double %182, -1.000000e+00
  %186 = fadd double %182, 1.000000e+00
  %187 = fsub double %186, %182
  %188 = fsub double %186, %187
  %189 = fsub double %182, %188
  %190 = fsub double 1.000000e+00, %187
  %191 = fadd double %190, %189
  %192 = tail call double @llvm.amdgcn.rcp.f64(double %186) #3
  %193 = fneg double %186
  %194 = tail call double @llvm.fma.f64(double %193, double %192, double 1.000000e+00) #3
  %195 = tail call double @llvm.fma.f64(double %194, double %192, double %192) #3
  %196 = tail call double @llvm.fma.f64(double %193, double %195, double 1.000000e+00) #3
  %197 = tail call double @llvm.fma.f64(double %196, double %195, double %195) #3
  %198 = fmul double %185, %197
  %199 = fmul double %186, %198
  %200 = fneg double %199
  %201 = tail call double @llvm.fma.f64(double %198, double %186, double %200) #3
  %202 = tail call double @llvm.fma.f64(double %198, double %191, double %201) #3
  %203 = fadd double %199, %202
  %204 = fsub double %203, %199
  %205 = fsub double %202, %204
  %206 = fsub double %185, %203
  %207 = fsub double %185, %206
  %208 = fsub double %207, %203
  %209 = fsub double %208, %205
  %210 = fadd double %206, %209
  %211 = fmul double %197, %210
  %212 = fadd double %198, %211
  %213 = fsub double %212, %198
  %214 = fsub double %211, %213
  %215 = fmul double %212, %212
  %216 = fneg double %215
  %217 = tail call double @llvm.fma.f64(double %212, double %212, double %216) #3
  %218 = fmul double %214, 2.000000e+00
  %219 = tail call double @llvm.fma.f64(double %212, double %218, double %217) #3
  %220 = tail call double @llvm.fma.f64(double %214, double %214, double %219) #3
  %221 = fadd double %215, %220
  %222 = fsub double %221, %215
  %223 = fsub double %220, %222
  %224 = tail call double @llvm.fma.f64(double %221, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %225 = tail call double @llvm.fma.f64(double %221, double %224, double 0x3FC7474DD7F4DF2E) #3
  %226 = tail call double @llvm.fma.f64(double %221, double %225, double 0x3FCC71C016291751) #3
  %227 = tail call double @llvm.fma.f64(double %221, double %226, double 0x3FD249249B27ACF1) #3
  %228 = tail call double @llvm.fma.f64(double %221, double %227, double 0x3FD99999998EF7B6) #3
  %229 = tail call double @llvm.fma.f64(double %221, double %228, double 0x3FE5555555555780) #3
  %230 = tail call double @llvm.amdgcn.ldexp.f64(double %212, i32 1) #3
  %231 = tail call double @llvm.amdgcn.ldexp.f64(double %214, i32 1) #3
  %232 = fmul double %212, %221
  %233 = fneg double %232
  %234 = tail call double @llvm.fma.f64(double %212, double %221, double %233) #3
  %235 = fmul double %214, %221
  %236 = tail call double @llvm.fma.f64(double %212, double %223, double %235) #3
  %237 = fadd double %234, %236
  %238 = fadd double %232, %237
  %239 = fsub double %238, %232
  %240 = fsub double %237, %239
  %241 = fmul double %238, %229
  %242 = fneg double %241
  %243 = tail call double @llvm.fma.f64(double %238, double %229, double %242) #3
  %244 = tail call double @llvm.fma.f64(double %240, double %229, double %243) #3
  %245 = fadd double %241, %244
  %246 = fsub double %245, %241
  %247 = fsub double %244, %246
  %248 = fadd double %230, %245
  %249 = fsub double %248, %230
  %250 = fsub double %248, %249
  %251 = fsub double %230, %250
  %252 = fsub double %245, %249
  %253 = fadd double %252, %251
  %254 = fadd double %231, %247
  %255 = fsub double %254, %231
  %256 = fsub double %254, %255
  %257 = fsub double %231, %256
  %258 = fsub double %247, %255
  %259 = fadd double %258, %257
  %260 = fadd double %254, %253
  %261 = fadd double %248, %260
  %262 = fsub double %261, %248
  %263 = fsub double %260, %262
  %264 = fadd double %259, %263
  %265 = fadd double %261, %264
  %266 = fsub double %265, %261
  %267 = fsub double %264, %266
  %268 = sitofp i32 %184 to double
  %269 = fmul double %265, 0x3FF71547652B82FE
  %270 = fneg double %269
  %271 = fmul double %265, 0x3C7777D0FFDA0D24
  %272 = insertelement <2 x double> undef, double %265, i32 0
  %273 = insertelement <2 x double> %272, double %267, i32 1
  %274 = insertelement <2 x double> undef, double %270, i32 0
  %275 = insertelement <2 x double> %274, double %271, i32 1
  %276 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %273, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %275) #3
  %277 = extractelement <2 x double> %276, i32 0
  %278 = extractelement <2 x double> %276, i32 1
  %279 = fadd double %277, %278
  %280 = fadd double %269, %279
  %281 = fsub double %280, %269
  %282 = fsub double %279, %281
  %283 = fadd double %280, %268
  %284 = fsub double %283, %268
  %285 = fsub double %284, %283
  %286 = fadd double %285, %268
  %287 = fsub double %280, %284
  %288 = fadd double %287, %286
  %289 = fadd double %282, %288
  %290 = fadd double %283, %289
  %291 = tail call double @llvm.fabs.f64(double %178) #4
  %292 = fcmp oeq double %291, 0x7FF0000000000000
  %293 = select i1 %292, double %178, double %290
  %294 = fcmp olt double %178, 0.000000e+00
  %295 = select i1 %294, double 0x7FF8000000000000, double %293
  %296 = fcmp oeq double %178, 0.000000e+00
  %297 = select i1 %296, double 0xFFF0000000000000, double %295
  %mul.i.i565.i.i.i.i = fmul double %297, %297
  %mul1.i.i566.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3E919A5BE1262808
  %add.i.i567.i.i.i.i = fadd double %mul1.i.i566.i.i.i.i, 0x3F07A5175B4661FC
  %mul5.i.i568.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3ED3058F91E15D9E
  %add7.i.i569.i.i.i.i = fadd double %mul5.i.i568.i.i.i.i, 0x3F360A6A52B6CEE1
  %mul10.i.i570.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i567.i.i.i.i
  %mul12.i.i571.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i569.i.i.i.i
  %add15.i.i572.i.i.i.i = fadd double %mul10.i.i570.i.i.i.i, 0x3F5C5B8FA36BAEC3
  %add18.i.i573.i.i.i.i = fadd double %mul12.i.i571.i.i.i.i, 0x3F80EDCAE3A5BFEE
  %mul20.i.i574.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i572.i.i.i.i
  %mul22.i.i575.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i573.i.i.i.i
  %add25.i.i576.i.i.i.i = fadd double %mul20.i.i574.i.i.i.i, 0x3F9A5E78F653B833
  %add28.i.i577.i.i.i.i = fadd double %mul22.i.i575.i.i.i.i, 0x3FB5AC2080A26513
  %mul30.i.i578.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i576.i.i.i.i
  %mul32.i.i579.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i577.i.i.i.i
  %add35.i.i580.i.i.i.i = fadd double %mul30.i.i578.i.i.i.i, 0x3FC65686F7A4EE22
  %add38.i.i581.i.i.i.i = fadd double %mul32.i.i579.i.i.i.i, 0x3FD3F40EF6582604
  %mul40.i.i582.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i580.i.i.i.i
  %add43.i.i583.i.i.i.i = fadd double %mul40.i.i582.i.i.i.i, 0x3FE03C236600AD0B
  %298 = fmul double %297, %add38.i.i581.i.i.i.i
  %add48.i.i585.i.i.i.i = fsub double %add43.i.i583.i.i.i.i, %298
  %mul1.i.i547.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EA0457562E8B20F
  %add.i.i548.i.i.i.i = fadd double %mul1.i.i547.i.i.i.i, 0x3F16154BBE28AEB9
  %mul5.i.i549.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, 0x3EE174949F46ED05
  %add7.i.i550.i.i.i.i = fadd double %mul5.i.i549.i.i.i.i, 0x3F43E3B25F7FFBED
  %mul10.i.i551.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add.i.i548.i.i.i.i
  %mul12.i.i552.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add7.i.i550.i.i.i.i
  %add15.i.i553.i.i.i.i = fadd double %mul10.i.i551.i.i.i.i, 0x3F6B2284D418EE28
  %add18.i.i554.i.i.i.i = fadd double %mul12.i.i552.i.i.i.i, 0x3F8DC663E91E38DD
  %mul20.i.i555.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add15.i.i553.i.i.i.i
  %mul22.i.i556.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add18.i.i554.i.i.i.i
  %add25.i.i557.i.i.i.i = fadd double %mul20.i.i555.i.i.i.i, 0x3FA9F261B3019817
  %add28.i.i558.i.i.i.i = fadd double %mul22.i.i556.i.i.i.i, 0x3FC29CC24A62017B
  %mul30.i.i559.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add25.i.i557.i.i.i.i
  %mul32.i.i560.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add28.i.i558.i.i.i.i
  %add35.i.i561.i.i.i.i = fadd double %mul30.i.i559.i.i.i.i, 0x3FD660DD0F65AD11
  %add38.i.i562.i.i.i.i = fadd double %mul32.i.i560.i.i.i.i, 0x3FE0E738E979F959
  %mul40.i.i563.i.i.i.i = fmul double %mul.i.i565.i.i.i.i, %add35.i.i561.i.i.i.i
  %add43.i.i564.i.i.i.i = fadd double %mul40.i.i563.i.i.i.i, 1.000000e+00
  %299 = fmul double %297, %add38.i.i562.i.i.i.i
  %add48.i.i.i.i.i.i = fsub double %add43.i.i564.i.i.i.i, %299
  %mul31.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i469.i.i.i.i = fcmp ogt double %mul31.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i470.i.i.i.i = fcmp oeq double %mul31.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i471.i.i.i.i = or i1 %cmp.i.i.i.i469.i.i.i.i, %cmp.i.i.i470.i.i.i.i
  br i1 %or.cond.i.i.i471.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end.i.i.i473.i.i.i.i

if.end.i.i.i473.i.i.i.i:                          ; preds = %if.then24.i.i.i.i
  %cmp.i.i.i.i.i472.i.i.i.i = fcmp uno double %mul31.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i472.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, label %if.end7.i.i.i499.i.i.i.i

if.end7.i.i.i499.i.i.i.i:                         ; preds = %if.end.i.i.i473.i.i.i.i
  %300 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul31.i.i.i.i) #3
  %301 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul31.i.i.i.i) #3
  %302 = tail call i1 @llvm.amdgcn.class.f64(double %mul31.i.i.i.i, i32 519) #3
  %303 = select i1 %302, i32 0, i32 %300
  %304 = select i1 %302, double %mul31.i.i.i.i, double %301
  %mul.i.i.i.i.i485.i.i.i.i = fmul double %304, %304
  %mul1.i.i.i.i.i486.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i487.i.i.i.i = fadd double %mul1.i.i.i.i.i486.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i488.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, 0x3FE479D17050CA47
  %305 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i488.i.i.i.i
  %mul10.i.i.i.i.i490.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %add.i.i.i.i.i487.i.i.i.i
  %mul12.i.i.i.i.i491.i.i.i.i = fmul double %mul.i.i.i.i.i485.i.i.i.i, %305
  %add15.i.i.i.i.i492.i.i.i.i = fadd double %mul10.i.i.i.i.i490.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i493.i.i.i.i = fadd double %mul12.i.i.i.i.i491.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i494.i.i.i.i = fmul double %304, %add15.i.i.i.i.i492.i.i.i.i
  %add23.i.i.i.i.i495.i.i.i.i = fadd double %add18.i.i.i.i.i493.i.i.i.i, %mul20.i.i.i.i.i494.i.i.i.i
  %.frozen209 = freeze i32 %303
  %div.i.i.i496.i.i.i.i = sdiv i32 %.frozen209, 3
  %306 = call i32 @llvm.abs.i32(i32 %div.i.i.i496.i.i.i.i, i1 true)
  %cmp11.i.i.i498.i.i.i.i = icmp ult i32 %306, 64
  %307 = sub nsw i32 0, %div.i.i.i496.i.i.i.i
  %308 = icmp sgt i32 %303, 2
  %309 = select i1 %308, i32 %div.i.i.i496.i.i.i.i, i32 %307
  %310 = zext i32 %309 to i64
  %311 = shl nuw i64 1, %310
  %312 = uitofp i64 %311 to double
  %not.cmp11.i.i.i498.i.i.i.i = xor i1 %cmp11.i.i.i498.i.i.i.i, true
  %313 = or i1 %308, %not.cmp11.i.i.i498.i.i.i.i
  br i1 %313, label %merged.bb6, label %merged.bb7

do.body.i.i.i530.i.i.i.i:                         ; preds = %merged.bb8, %do.body.i.i.i530.i.i.i.i
  %guess.i.i.i468.i.i.i.i.1 = phi double [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ], [ %mul24.i.i.i517.i.i.i.i, %merged.bb8 ]
  %mul28.i.i.i520.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %guess.i.i.i468.i.i.i.i.1
  %mul29.i.i.i521.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %mul28.i.i.i520.i.i.i.i
  %add30.i.i.i522.i.i.i.i = fadd double %mul31.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add31.i.i.i523.i.i.i.i = fadd double %mul31.i.i.i.i, %add30.i.i.i522.i.i.i.i
  %add32.i.i.i524.i.i.i.i = fadd double %mul29.i.i.i521.i.i.i.i, %mul29.i.i.i521.i.i.i.i
  %add33.i.i.i525.i.i.i.i = fadd double %mul31.i.i.i.i, %add32.i.i.i524.i.i.i.i
  %div34.i.i.i526.i.i.i.i = fdiv double %add31.i.i.i523.i.i.i.i, %add33.i.i.i525.i.i.i.i
  %mul35.i.i.i527.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.1, %div34.i.i.i526.i.i.i.i
  %sub36.i.i.i528.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i526.i.i.i.i
  %314 = tail call double @llvm.fabs.f64(double %sub36.i.i.i528.i.i.i.i) #3
  %cmp38.i.i.i529.i.i.i.i = fcmp ogt double %314, 0x3EC0000000000000
  br i1 %cmp38.i.i.i529.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

do.body40.i.i.i541.i.i.i.i:                       ; preds = %merged.bb8, %do.body40.i.i.i541.i.i.i.i
  %guess.i.i.i468.i.i.i.i.2 = phi double [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ], [ %mul24.i.i.i517.i.i.i.i, %merged.bb8 ]
  %mul41.i.i.i531.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, %guess.i.i.i468.i.i.i.i.2
  %div42.i.i.i532.i.i.i.i = fdiv double %mul31.i.i.i.i, %guess.i.i.i468.i.i.i.i.2
  %sub43.i.i.i533.i.i.i.i = fsub double %mul41.i.i.i531.i.i.i.i, %div42.i.i.i532.i.i.i.i
  %mul44.i.i.i534.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i535.i.i.i.i = fdiv double %mul31.i.i.i.i, %mul41.i.i.i531.i.i.i.i
  %add46.i.i.i536.i.i.i.i = fadd double %mul44.i.i.i534.i.i.i.i, %div45.i.i.i535.i.i.i.i
  %div47.i.i.i537.i.i.i.i = fdiv double %sub43.i.i.i533.i.i.i.i, %add46.i.i.i536.i.i.i.i
  %sub48.i.i.i538.i.i.i.i = fsub double %guess.i.i.i468.i.i.i.i.2, %div47.i.i.i537.i.i.i.i
  %mul50.i.i.i539.i.i.i.i = fmul double %sub48.i.i.i538.i.i.i.i, 0x3EC0000000000000
  %315 = tail call double @llvm.fabs.f64(double %div47.i.i.i537.i.i.i.i) #3
  %cmp52.i.i.i540.i.i.i.i = fcmp olt double %mul50.i.i.i539.i.i.i.i, %315
  br i1 %cmp52.i.i.i540.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i: ; preds = %do.body40.i.i.i541.i.i.i.i, %do.body.i.i.i530.i.i.i.i, %if.end.i.i.i473.i.i.i.i, %if.then24.i.i.i.i
  %retval.0.i.i.i544.i.i.i.i = phi double [ %mul31.i.i.i.i, %if.then24.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i473.i.i.i.i ], [ %mul35.i.i.i527.i.i.i.i, %do.body.i.i.i530.i.i.i.i ], [ %sub48.i.i.i538.i.i.i.i, %do.body40.i.i.i541.i.i.i.i ]
  %mul33.i.i.i.i = fmul double %add48.i.i.i.i.i.i, %retval.0.i.i.i544.i.i.i.i
  %div34.i.i.i.i = fdiv double %add48.i.i585.i.i.i.i, %mul33.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else35.i.i.i.i:                                ; preds = %if.else21.i.i.i.i
  %cmp37.i.i.i.i = icmp sgt i32 %39, -17
  br i1 %cmp37.i.i.i.i, label %if.then38.i.i.i.i, label %if.else49.i.i.i.i

if.then38.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %316 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 8) #3
  %317 = tail call double @llvm.amdgcn.frexp.mant.f64(double %316) #3
  %318 = fcmp olt double %317, 0x3FE5555555555555
  %319 = zext i1 %318 to i32
  %320 = tail call double @llvm.amdgcn.ldexp.f64(double %317, i32 %319) #3
  %321 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %316) #3
  %322 = sub nsw i32 %321, %319
  %323 = fadd double %320, -1.000000e+00
  %324 = fadd double %320, 1.000000e+00
  %325 = fsub double %324, %320
  %326 = fsub double %324, %325
  %327 = fsub double %320, %326
  %328 = fsub double 1.000000e+00, %325
  %329 = fadd double %328, %327
  %330 = tail call double @llvm.amdgcn.rcp.f64(double %324) #3
  %331 = fneg double %324
  %332 = tail call double @llvm.fma.f64(double %331, double %330, double 1.000000e+00) #3
  %333 = tail call double @llvm.fma.f64(double %332, double %330, double %330) #3
  %334 = tail call double @llvm.fma.f64(double %331, double %333, double 1.000000e+00) #3
  %335 = tail call double @llvm.fma.f64(double %334, double %333, double %333) #3
  %336 = fmul double %323, %335
  %337 = fmul double %324, %336
  %338 = fneg double %337
  %339 = tail call double @llvm.fma.f64(double %336, double %324, double %338) #3
  %340 = tail call double @llvm.fma.f64(double %336, double %329, double %339) #3
  %341 = fadd double %337, %340
  %342 = fsub double %341, %337
  %343 = fsub double %340, %342
  %344 = fsub double %323, %341
  %345 = fsub double %323, %344
  %346 = fsub double %345, %341
  %347 = fsub double %346, %343
  %348 = fadd double %344, %347
  %349 = fmul double %335, %348
  %350 = fadd double %336, %349
  %351 = fsub double %350, %336
  %352 = fsub double %349, %351
  %353 = fmul double %350, %350
  %354 = fneg double %353
  %355 = tail call double @llvm.fma.f64(double %350, double %350, double %354) #3
  %356 = fmul double %352, 2.000000e+00
  %357 = tail call double @llvm.fma.f64(double %350, double %356, double %355) #3
  %358 = tail call double @llvm.fma.f64(double %352, double %352, double %357) #3
  %359 = fadd double %353, %358
  %360 = fsub double %359, %353
  %361 = fsub double %358, %360
  %362 = tail call double @llvm.fma.f64(double %359, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %363 = tail call double @llvm.fma.f64(double %359, double %362, double 0x3FC7474DD7F4DF2E) #3
  %364 = tail call double @llvm.fma.f64(double %359, double %363, double 0x3FCC71C016291751) #3
  %365 = tail call double @llvm.fma.f64(double %359, double %364, double 0x3FD249249B27ACF1) #3
  %366 = tail call double @llvm.fma.f64(double %359, double %365, double 0x3FD99999998EF7B6) #3
  %367 = tail call double @llvm.fma.f64(double %359, double %366, double 0x3FE5555555555780) #3
  %368 = tail call double @llvm.amdgcn.ldexp.f64(double %350, i32 1) #3
  %369 = tail call double @llvm.amdgcn.ldexp.f64(double %352, i32 1) #3
  %370 = fmul double %350, %359
  %371 = fneg double %370
  %372 = tail call double @llvm.fma.f64(double %350, double %359, double %371) #3
  %373 = fmul double %352, %359
  %374 = tail call double @llvm.fma.f64(double %350, double %361, double %373) #3
  %375 = fadd double %372, %374
  %376 = fadd double %370, %375
  %377 = fsub double %376, %370
  %378 = fsub double %375, %377
  %379 = fmul double %376, %367
  %380 = fneg double %379
  %381 = tail call double @llvm.fma.f64(double %376, double %367, double %380) #3
  %382 = tail call double @llvm.fma.f64(double %378, double %367, double %381) #3
  %383 = fadd double %379, %382
  %384 = fsub double %383, %379
  %385 = fsub double %382, %384
  %386 = fadd double %368, %383
  %387 = fsub double %386, %368
  %388 = fsub double %386, %387
  %389 = fsub double %368, %388
  %390 = fsub double %383, %387
  %391 = fadd double %390, %389
  %392 = fadd double %369, %385
  %393 = fsub double %392, %369
  %394 = fsub double %392, %393
  %395 = fsub double %369, %394
  %396 = fsub double %385, %393
  %397 = fadd double %396, %395
  %398 = fadd double %392, %391
  %399 = fadd double %386, %398
  %400 = fsub double %399, %386
  %401 = fsub double %398, %400
  %402 = fadd double %397, %401
  %403 = fadd double %399, %402
  %404 = fsub double %403, %399
  %405 = fsub double %402, %404
  %406 = sitofp i32 %322 to double
  %407 = fmul double %403, 0x3FF71547652B82FE
  %408 = fneg double %407
  %409 = fmul double %403, 0x3C7777D0FFDA0D24
  %410 = insertelement <2 x double> undef, double %403, i32 0
  %411 = insertelement <2 x double> %410, double %405, i32 1
  %412 = insertelement <2 x double> undef, double %408, i32 0
  %413 = insertelement <2 x double> %412, double %409, i32 1
  %414 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %411, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %413) #3
  %415 = extractelement <2 x double> %414, i32 0
  %416 = extractelement <2 x double> %414, i32 1
  %417 = fadd double %415, %416
  %418 = fadd double %407, %417
  %419 = fsub double %418, %407
  %420 = fsub double %417, %419
  %421 = fadd double %418, %406
  %422 = fsub double %421, %406
  %423 = fsub double %422, %421
  %424 = fadd double %423, %406
  %425 = fsub double %418, %422
  %426 = fadd double %425, %424
  %427 = fadd double %420, %426
  %428 = fadd double %421, %427
  %429 = tail call double @llvm.fabs.f64(double %316) #4
  %430 = fcmp oeq double %429, 0x7FF0000000000000
  %431 = select i1 %430, double %316, double %428
  %432 = fcmp olt double %316, 0.000000e+00
  %433 = select i1 %432, double 0x7FF8000000000000, double %431
  %434 = fcmp oeq double %316, 0.000000e+00
  %435 = select i1 %434, double 0xFFF0000000000000, double %433
  %mul.i.i450.i.i.i.i = fmul double %435, %435
  %mul1.i.i451.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3D1C49F35743D651
  %add.i.i452.i.i.i.i = fadd double %mul1.i.i451.i.i.i.i, 0x3EC5BDF8ABE0C4D2
  %mul5.i.i453.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E74DE722017F09B
  %add7.i.i454.i.i.i.i = fadd double %mul5.i.i453.i.i.i.i, 0x3F08B20867234AE0
  %mul10.i.i455.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i452.i.i.i.i
  %mul12.i.i456.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i454.i.i.i.i
  %add15.i.i457.i.i.i.i = fadd double %mul10.i.i455.i.i.i.i, 0x3F43291C59111954
  %add18.i.i458.i.i.i.i = fadd double %mul12.i.i456.i.i.i.i, 0x3F7555F81DC90AE6
  %mul20.i.i459.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i457.i.i.i.i
  %mul22.i.i460.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i458.i.i.i.i
  %add25.i.i461.i.i.i.i = fadd double %mul20.i.i459.i.i.i.i, 0x3FA118409603E368
  %add28.i.i462.i.i.i.i = fadd double %mul22.i.i460.i.i.i.i, 0x3FC2F812CF93403D
  %mul30.i.i463.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i461.i.i.i.i
  %mul32.i.i.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add28.i.i462.i.i.i.i
  %add35.i.i.i.i.i.i = fadd double %mul30.i.i463.i.i.i.i, 0x3FDA4ECF31EE23E1
  %add38.i.i464.i.i.i.i = fadd double %mul32.i.i.i.i.i.i, 0x3FE15637BD9C1C6C
  %436 = fmul double %435, %add35.i.i.i.i.i.i
  %add43.i.i.i.i.i.i = fsub double %add38.i.i464.i.i.i.i, %436
  %mul1.i.i434.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3E834146FFF39045
  %add.i.i435.i.i.i.i = fadd double %mul1.i.i434.i.i.i.i, 0x3F16C942D4A0C545
  %mul5.i.i436.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, 0x3ED40F287F6755C5
  %add7.i.i437.i.i.i.i = fadd double %mul5.i.i436.i.i.i.i, 0x3F51AD434F5D94BA
  %mul10.i.i438.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add.i.i435.i.i.i.i
  %mul12.i.i439.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add7.i.i437.i.i.i.i
  %add15.i.i440.i.i.i.i = fadd double %mul10.i.i438.i.i.i.i, 0x3F83AFF5A756295F
  %add18.i.i441.i.i.i.i = fadd double %mul12.i.i439.i.i.i.i, 0x3FAF8A313C5B71D0
  %mul20.i.i442.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add15.i.i440.i.i.i.i
  %mul22.i.i443.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add18.i.i441.i.i.i.i
  %add25.i.i444.i.i.i.i = fadd double %mul20.i.i442.i.i.i.i, 0x3FD1813788B6276A
  %add28.i.i445.i.i.i.i = fadd double %mul22.i.i443.i.i.i.i, 0x3FE84455F48DB67F
  %mul30.i.i446.i.i.i.i = fmul double %mul.i.i450.i.i.i.i, %add25.i.i444.i.i.i.i
  %add33.i.i447.i.i.i.i = fadd double %mul30.i.i446.i.i.i.i, 1.000000e+00
  %437 = fmul double %435, %add28.i.i445.i.i.i.i
  %add38.i.i449.i.i.i.i = fsub double %add33.i.i447.i.i.i.i, %437
  %mul45.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i356.i.i.i.i = fcmp ogt double %mul45.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i357.i.i.i.i = fcmp oeq double %mul45.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i358.i.i.i.i = or i1 %cmp.i.i.i.i356.i.i.i.i, %cmp.i.i.i357.i.i.i.i
  br i1 %or.cond.i.i.i358.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end.i.i.i360.i.i.i.i

if.end.i.i.i360.i.i.i.i:                          ; preds = %if.then38.i.i.i.i
  %cmp.i.i.i.i.i359.i.i.i.i = fcmp uno double %mul45.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i359.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, label %if.end7.i.i.i386.i.i.i.i

if.end7.i.i.i386.i.i.i.i:                         ; preds = %if.end.i.i.i360.i.i.i.i
  %438 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul45.i.i.i.i) #3
  %439 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul45.i.i.i.i) #3
  %440 = tail call i1 @llvm.amdgcn.class.f64(double %mul45.i.i.i.i, i32 519) #3
  %441 = select i1 %440, i32 0, i32 %438
  %442 = select i1 %440, double %mul45.i.i.i.i, double %439
  %mul.i.i.i.i.i372.i.i.i.i = fmul double %442, %442
  %mul1.i.i.i.i.i373.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i374.i.i.i.i = fadd double %mul1.i.i.i.i.i373.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i375.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, 0x3FE479D17050CA47
  %443 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i375.i.i.i.i
  %mul10.i.i.i.i.i377.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %add.i.i.i.i.i374.i.i.i.i
  %mul12.i.i.i.i.i378.i.i.i.i = fmul double %mul.i.i.i.i.i372.i.i.i.i, %443
  %add15.i.i.i.i.i379.i.i.i.i = fadd double %mul10.i.i.i.i.i377.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i380.i.i.i.i = fadd double %mul12.i.i.i.i.i378.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i381.i.i.i.i = fmul double %442, %add15.i.i.i.i.i379.i.i.i.i
  %add23.i.i.i.i.i382.i.i.i.i = fadd double %add18.i.i.i.i.i380.i.i.i.i, %mul20.i.i.i.i.i381.i.i.i.i
  %.frozen210 = freeze i32 %441
  %div.i.i.i383.i.i.i.i = sdiv i32 %.frozen210, 3
  %444 = call i32 @llvm.abs.i32(i32 %div.i.i.i383.i.i.i.i, i1 true)
  %cmp11.i.i.i385.i.i.i.i = icmp ult i32 %444, 64
  %445 = sub nsw i32 0, %div.i.i.i383.i.i.i.i
  %446 = icmp sgt i32 %441, 2
  %447 = select i1 %446, i32 %div.i.i.i383.i.i.i.i, i32 %445
  %448 = zext i32 %447 to i64
  %449 = shl nuw i64 1, %448
  %450 = uitofp i64 %449 to double
  %not.cmp11.i.i.i385.i.i.i.i = xor i1 %cmp11.i.i.i385.i.i.i.i, true
  %451 = or i1 %446, %not.cmp11.i.i.i385.i.i.i.i
  br i1 %451, label %merged.bb9, label %merged.bb10

do.body.i.i.i417.i.i.i.i:                         ; preds = %merged.bb11, %do.body.i.i.i417.i.i.i.i
  %guess.i.i.i355.i.i.i.i.1 = phi double [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ], [ %mul24.i.i.i404.i.i.i.i, %merged.bb11 ]
  %mul28.i.i.i407.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %guess.i.i.i355.i.i.i.i.1
  %mul29.i.i.i408.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %mul28.i.i.i407.i.i.i.i
  %add30.i.i.i409.i.i.i.i = fadd double %mul45.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add31.i.i.i410.i.i.i.i = fadd double %mul45.i.i.i.i, %add30.i.i.i409.i.i.i.i
  %add32.i.i.i411.i.i.i.i = fadd double %mul29.i.i.i408.i.i.i.i, %mul29.i.i.i408.i.i.i.i
  %add33.i.i.i412.i.i.i.i = fadd double %mul45.i.i.i.i, %add32.i.i.i411.i.i.i.i
  %div34.i.i.i413.i.i.i.i = fdiv double %add31.i.i.i410.i.i.i.i, %add33.i.i.i412.i.i.i.i
  %mul35.i.i.i414.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.1, %div34.i.i.i413.i.i.i.i
  %sub36.i.i.i415.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i413.i.i.i.i
  %452 = tail call double @llvm.fabs.f64(double %sub36.i.i.i415.i.i.i.i) #3
  %cmp38.i.i.i416.i.i.i.i = fcmp ogt double %452, 0x3EC0000000000000
  br i1 %cmp38.i.i.i416.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

do.body40.i.i.i428.i.i.i.i:                       ; preds = %merged.bb11, %do.body40.i.i.i428.i.i.i.i
  %guess.i.i.i355.i.i.i.i.2 = phi double [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ], [ %mul24.i.i.i404.i.i.i.i, %merged.bb11 ]
  %mul41.i.i.i418.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, %guess.i.i.i355.i.i.i.i.2
  %div42.i.i.i419.i.i.i.i = fdiv double %mul45.i.i.i.i, %guess.i.i.i355.i.i.i.i.2
  %sub43.i.i.i420.i.i.i.i = fsub double %mul41.i.i.i418.i.i.i.i, %div42.i.i.i419.i.i.i.i
  %mul44.i.i.i421.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i422.i.i.i.i = fdiv double %mul45.i.i.i.i, %mul41.i.i.i418.i.i.i.i
  %add46.i.i.i423.i.i.i.i = fadd double %mul44.i.i.i421.i.i.i.i, %div45.i.i.i422.i.i.i.i
  %div47.i.i.i424.i.i.i.i = fdiv double %sub43.i.i.i420.i.i.i.i, %add46.i.i.i423.i.i.i.i
  %sub48.i.i.i425.i.i.i.i = fsub double %guess.i.i.i355.i.i.i.i.2, %div47.i.i.i424.i.i.i.i
  %mul50.i.i.i426.i.i.i.i = fmul double %sub48.i.i.i425.i.i.i.i, 0x3EC0000000000000
  %453 = tail call double @llvm.fabs.f64(double %div47.i.i.i424.i.i.i.i) #3
  %cmp52.i.i.i427.i.i.i.i = fcmp olt double %mul50.i.i.i426.i.i.i.i, %453
  br i1 %cmp52.i.i.i427.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i: ; preds = %do.body40.i.i.i428.i.i.i.i, %do.body.i.i.i417.i.i.i.i, %if.end.i.i.i360.i.i.i.i, %if.then38.i.i.i.i
  %retval.0.i.i.i431.i.i.i.i = phi double [ %mul45.i.i.i.i, %if.then38.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i360.i.i.i.i ], [ %mul35.i.i.i414.i.i.i.i, %do.body.i.i.i417.i.i.i.i ], [ %sub48.i.i.i425.i.i.i.i, %do.body40.i.i.i428.i.i.i.i ]
  %mul47.i.i.i.i = fmul double %add38.i.i449.i.i.i.i, %retval.0.i.i.i431.i.i.i.i
  %div48.i.i.i.i = fdiv double %add43.i.i.i.i.i.i, %mul47.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else49.i.i.i.i:                                ; preds = %if.else35.i.i.i.i
  %cmp51.i.i.i.i = icmp sgt i32 %39, -33
  br i1 %cmp51.i.i.i.i, label %if.then52.i.i.i.i, label %if.else63.i.i.i.i

if.then52.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %454 = tail call double @llvm.amdgcn.ldexp.f64(double %sub.i.i.i, i32 16) #3
  %455 = tail call double @llvm.amdgcn.frexp.mant.f64(double %454) #3
  %456 = fcmp olt double %455, 0x3FE5555555555555
  %457 = zext i1 %456 to i32
  %458 = tail call double @llvm.amdgcn.ldexp.f64(double %455, i32 %457) #3
  %459 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %454) #3
  %460 = sub nsw i32 %459, %457
  %461 = fadd double %458, -1.000000e+00
  %462 = fadd double %458, 1.000000e+00
  %463 = fsub double %462, %458
  %464 = fsub double %462, %463
  %465 = fsub double %458, %464
  %466 = fsub double 1.000000e+00, %463
  %467 = fadd double %466, %465
  %468 = tail call double @llvm.amdgcn.rcp.f64(double %462) #3
  %469 = fneg double %462
  %470 = tail call double @llvm.fma.f64(double %469, double %468, double 1.000000e+00) #3
  %471 = tail call double @llvm.fma.f64(double %470, double %468, double %468) #3
  %472 = tail call double @llvm.fma.f64(double %469, double %471, double 1.000000e+00) #3
  %473 = tail call double @llvm.fma.f64(double %472, double %471, double %471) #3
  %474 = fmul double %461, %473
  %475 = fmul double %462, %474
  %476 = fneg double %475
  %477 = tail call double @llvm.fma.f64(double %474, double %462, double %476) #3
  %478 = tail call double @llvm.fma.f64(double %474, double %467, double %477) #3
  %479 = fadd double %475, %478
  %480 = fsub double %479, %475
  %481 = fsub double %478, %480
  %482 = fsub double %461, %479
  %483 = fsub double %461, %482
  %484 = fsub double %483, %479
  %485 = fsub double %484, %481
  %486 = fadd double %482, %485
  %487 = fmul double %473, %486
  %488 = fadd double %474, %487
  %489 = fsub double %488, %474
  %490 = fsub double %487, %489
  %491 = fmul double %488, %488
  %492 = fneg double %491
  %493 = tail call double @llvm.fma.f64(double %488, double %488, double %492) #3
  %494 = fmul double %490, 2.000000e+00
  %495 = tail call double @llvm.fma.f64(double %488, double %494, double %493) #3
  %496 = tail call double @llvm.fma.f64(double %490, double %490, double %495) #3
  %497 = fadd double %491, %496
  %498 = fsub double %497, %491
  %499 = fsub double %496, %498
  %500 = tail call double @llvm.fma.f64(double %497, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %501 = tail call double @llvm.fma.f64(double %497, double %500, double 0x3FC7474DD7F4DF2E) #3
  %502 = tail call double @llvm.fma.f64(double %497, double %501, double 0x3FCC71C016291751) #3
  %503 = tail call double @llvm.fma.f64(double %497, double %502, double 0x3FD249249B27ACF1) #3
  %504 = tail call double @llvm.fma.f64(double %497, double %503, double 0x3FD99999998EF7B6) #3
  %505 = tail call double @llvm.fma.f64(double %497, double %504, double 0x3FE5555555555780) #3
  %506 = tail call double @llvm.amdgcn.ldexp.f64(double %488, i32 1) #3
  %507 = tail call double @llvm.amdgcn.ldexp.f64(double %490, i32 1) #3
  %508 = fmul double %488, %497
  %509 = fneg double %508
  %510 = tail call double @llvm.fma.f64(double %488, double %497, double %509) #3
  %511 = fmul double %490, %497
  %512 = tail call double @llvm.fma.f64(double %488, double %499, double %511) #3
  %513 = fadd double %510, %512
  %514 = fadd double %508, %513
  %515 = fsub double %514, %508
  %516 = fsub double %513, %515
  %517 = fmul double %514, %505
  %518 = fneg double %517
  %519 = tail call double @llvm.fma.f64(double %514, double %505, double %518) #3
  %520 = tail call double @llvm.fma.f64(double %516, double %505, double %519) #3
  %521 = fadd double %517, %520
  %522 = fsub double %521, %517
  %523 = fsub double %520, %522
  %524 = fadd double %506, %521
  %525 = fsub double %524, %506
  %526 = fsub double %524, %525
  %527 = fsub double %506, %526
  %528 = fsub double %521, %525
  %529 = fadd double %528, %527
  %530 = fadd double %507, %523
  %531 = fsub double %530, %507
  %532 = fsub double %530, %531
  %533 = fsub double %507, %532
  %534 = fsub double %523, %531
  %535 = fadd double %534, %533
  %536 = fadd double %530, %529
  %537 = fadd double %524, %536
  %538 = fsub double %537, %524
  %539 = fsub double %536, %538
  %540 = fadd double %535, %539
  %541 = fadd double %537, %540
  %542 = fsub double %541, %537
  %543 = fsub double %540, %542
  %544 = sitofp i32 %460 to double
  %545 = fmul double %541, 0x3FF71547652B82FE
  %546 = fneg double %545
  %547 = fmul double %541, 0x3C7777D0FFDA0D24
  %548 = insertelement <2 x double> undef, double %541, i32 0
  %549 = insertelement <2 x double> %548, double %543, i32 1
  %550 = insertelement <2 x double> undef, double %546, i32 0
  %551 = insertelement <2 x double> %550, double %547, i32 1
  %552 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %549, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %551) #3
  %553 = extractelement <2 x double> %552, i32 0
  %554 = extractelement <2 x double> %552, i32 1
  %555 = fadd double %553, %554
  %556 = fadd double %545, %555
  %557 = fsub double %556, %545
  %558 = fsub double %555, %557
  %559 = fadd double %556, %544
  %560 = fsub double %559, %544
  %561 = fsub double %560, %559
  %562 = fadd double %561, %544
  %563 = fsub double %556, %560
  %564 = fadd double %563, %562
  %565 = fadd double %558, %564
  %566 = fadd double %559, %565
  %567 = tail call double @llvm.fabs.f64(double %454) #4
  %568 = fcmp oeq double %567, 0x7FF0000000000000
  %569 = select i1 %568, double %454, double %566
  %570 = fcmp olt double %454, 0.000000e+00
  %571 = select i1 %570, double 0x7FF8000000000000, double %569
  %572 = fcmp oeq double %454, 0.000000e+00
  %573 = select i1 %572, double 0xFFF0000000000000, double %571
  %mul.i.i335.i.i.i.i = fmul double %573, %573
  %mul1.i.i336.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EBF7344DBF5E403
  %add.i.i337.i.i.i.i = fadd double %mul1.i.i336.i.i.i.i, 0x3F2CFF1E2D54E4E7
  %mul5.i.i338.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EEF8CF23CAED047
  %add7.i.i339.i.i.i.i = fadd double %mul5.i.i338.i.i.i.i, 0x3F5CF8F0FF9B6F59
  %mul10.i.i340.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i337.i.i.i.i
  %mul12.i.i341.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i339.i.i.i.i
  %add15.i.i342.i.i.i.i = fadd double %mul10.i.i340.i.i.i.i, 0x3F8857AD74D33625
  %add18.i.i343.i.i.i.i = fadd double %mul12.i.i341.i.i.i.i, 0x3FAE52179C3AEDE6
  %mul20.i.i344.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i342.i.i.i.i
  %mul22.i.i345.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i343.i.i.i.i
  %add25.i.i346.i.i.i.i = fadd double %mul20.i.i344.i.i.i.i, 0x3FCB21A22303D8FC
  %add28.i.i347.i.i.i.i = fadd double %mul22.i.i345.i.i.i.i, 0x3FDF29CE00A8804B
  %mul30.i.i348.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i346.i.i.i.i
  %add33.i.i349.i.i.i.i = fadd double %mul30.i.i348.i.i.i.i, 0x3FE15775564555E5
  %574 = fmul double %573, %add28.i.i347.i.i.i.i
  %add38.i.i351.i.i.i.i = fsub double %add33.i.i349.i.i.i.i, %574
  %mul1.i.i321.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3ECD04621671DBCE
  %add.i.i322.i.i.i.i = fadd double %mul1.i.i321.i.i.i.i, 0x3F3AC0D433DC2A4E
  %mul5.i.i323.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, 0x3EFD1C12EAA62BE9
  %add7.i.i324.i.i.i.i = fadd double %mul5.i.i323.i.i.i.i, 0x3F6ABB215A001E96
  %mul10.i.i325.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add.i.i322.i.i.i.i
  %mul12.i.i326.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add7.i.i324.i.i.i.i
  %add15.i.i327.i.i.i.i = fadd double %mul10.i.i325.i.i.i.i, 0x3F967590758A1B1A
  %add18.i.i328.i.i.i.i = fadd double %mul12.i.i326.i.i.i.i, 0x3FBBF9941AE7DFDE
  %mul20.i.i329.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add15.i.i327.i.i.i.i
  %mul22.i.i330.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add18.i.i328.i.i.i.i
  %add25.i.i331.i.i.i.i = fadd double %mul20.i.i329.i.i.i.i, 0x3FD90848F242167F
  %add28.i.i332.i.i.i.i = fadd double %mul22.i.i330.i.i.i.i, 0x3FECC09A37BCEE76
  %mul30.i.i333.i.i.i.i = fmul double %mul.i.i335.i.i.i.i, %add25.i.i331.i.i.i.i
  %add33.i.i334.i.i.i.i = fadd double %mul30.i.i333.i.i.i.i, 1.000000e+00
  %575 = fmul double %573, %add28.i.i332.i.i.i.i
  %add38.i.i.i.i.i.i = fsub double %add33.i.i334.i.i.i.i, %575
  %mul59.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp.i.i.i.i243.i.i.i.i = fcmp ogt double %mul59.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i244.i.i.i.i = fcmp oeq double %mul59.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i245.i.i.i.i = or i1 %cmp.i.i.i.i243.i.i.i.i, %cmp.i.i.i244.i.i.i.i
  br i1 %or.cond.i.i.i245.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end.i.i.i247.i.i.i.i

if.end.i.i.i247.i.i.i.i:                          ; preds = %if.then52.i.i.i.i
  %cmp.i.i.i.i.i246.i.i.i.i = fcmp uno double %mul59.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i246.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, label %if.end7.i.i.i273.i.i.i.i

if.end7.i.i.i273.i.i.i.i:                         ; preds = %if.end.i.i.i247.i.i.i.i
  %576 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul59.i.i.i.i) #3
  %577 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul59.i.i.i.i) #3
  %578 = tail call i1 @llvm.amdgcn.class.f64(double %mul59.i.i.i.i, i32 519) #3
  %579 = select i1 %578, i32 0, i32 %576
  %580 = select i1 %578, double %mul59.i.i.i.i, double %577
  %mul.i.i.i.i.i259.i.i.i.i = fmul double %580, %580
  %mul1.i.i.i.i.i260.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i261.i.i.i.i = fadd double %mul1.i.i.i.i.i260.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i262.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, 0x3FE479D17050CA47
  %581 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i262.i.i.i.i
  %mul10.i.i.i.i.i264.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %add.i.i.i.i.i261.i.i.i.i
  %mul12.i.i.i.i.i265.i.i.i.i = fmul double %mul.i.i.i.i.i259.i.i.i.i, %581
  %add15.i.i.i.i.i266.i.i.i.i = fadd double %mul10.i.i.i.i.i264.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i267.i.i.i.i = fadd double %mul12.i.i.i.i.i265.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i268.i.i.i.i = fmul double %580, %add15.i.i.i.i.i266.i.i.i.i
  %add23.i.i.i.i.i269.i.i.i.i = fadd double %add18.i.i.i.i.i267.i.i.i.i, %mul20.i.i.i.i.i268.i.i.i.i
  %.frozen211 = freeze i32 %579
  %div.i.i.i270.i.i.i.i = sdiv i32 %.frozen211, 3
  %582 = call i32 @llvm.abs.i32(i32 %div.i.i.i270.i.i.i.i, i1 true)
  %cmp11.i.i.i272.i.i.i.i = icmp ult i32 %582, 64
  %583 = sub nsw i32 0, %div.i.i.i270.i.i.i.i
  %584 = icmp sgt i32 %579, 2
  %585 = select i1 %584, i32 %div.i.i.i270.i.i.i.i, i32 %583
  %586 = zext i32 %585 to i64
  %587 = shl nuw i64 1, %586
  %588 = uitofp i64 %587 to double
  %not.cmp11.i.i.i272.i.i.i.i = xor i1 %cmp11.i.i.i272.i.i.i.i, true
  %589 = or i1 %584, %not.cmp11.i.i.i272.i.i.i.i
  br i1 %589, label %merged.bb12, label %merged.bb13

do.body.i.i.i304.i.i.i.i:                         ; preds = %merged.bb14, %do.body.i.i.i304.i.i.i.i
  %guess.i.i.i242.i.i.i.i.1 = phi double [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ], [ %mul24.i.i.i291.i.i.i.i, %merged.bb14 ]
  %mul28.i.i.i294.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %guess.i.i.i242.i.i.i.i.1
  %mul29.i.i.i295.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %mul28.i.i.i294.i.i.i.i
  %add30.i.i.i296.i.i.i.i = fadd double %mul59.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add31.i.i.i297.i.i.i.i = fadd double %mul59.i.i.i.i, %add30.i.i.i296.i.i.i.i
  %add32.i.i.i298.i.i.i.i = fadd double %mul29.i.i.i295.i.i.i.i, %mul29.i.i.i295.i.i.i.i
  %add33.i.i.i299.i.i.i.i = fadd double %mul59.i.i.i.i, %add32.i.i.i298.i.i.i.i
  %div34.i.i.i300.i.i.i.i = fdiv double %add31.i.i.i297.i.i.i.i, %add33.i.i.i299.i.i.i.i
  %mul35.i.i.i301.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.1, %div34.i.i.i300.i.i.i.i
  %sub36.i.i.i302.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i300.i.i.i.i
  %590 = tail call double @llvm.fabs.f64(double %sub36.i.i.i302.i.i.i.i) #3
  %cmp38.i.i.i303.i.i.i.i = fcmp ogt double %590, 0x3EC0000000000000
  br i1 %cmp38.i.i.i303.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

do.body40.i.i.i315.i.i.i.i:                       ; preds = %merged.bb14, %do.body40.i.i.i315.i.i.i.i
  %guess.i.i.i242.i.i.i.i.2 = phi double [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ], [ %mul24.i.i.i291.i.i.i.i, %merged.bb14 ]
  %mul41.i.i.i305.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, %guess.i.i.i242.i.i.i.i.2
  %div42.i.i.i306.i.i.i.i = fdiv double %mul59.i.i.i.i, %guess.i.i.i242.i.i.i.i.2
  %sub43.i.i.i307.i.i.i.i = fsub double %mul41.i.i.i305.i.i.i.i, %div42.i.i.i306.i.i.i.i
  %mul44.i.i.i308.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i309.i.i.i.i = fdiv double %mul59.i.i.i.i, %mul41.i.i.i305.i.i.i.i
  %add46.i.i.i310.i.i.i.i = fadd double %mul44.i.i.i308.i.i.i.i, %div45.i.i.i309.i.i.i.i
  %div47.i.i.i311.i.i.i.i = fdiv double %sub43.i.i.i307.i.i.i.i, %add46.i.i.i310.i.i.i.i
  %sub48.i.i.i312.i.i.i.i = fsub double %guess.i.i.i242.i.i.i.i.2, %div47.i.i.i311.i.i.i.i
  %mul50.i.i.i313.i.i.i.i = fmul double %sub48.i.i.i312.i.i.i.i, 0x3EC0000000000000
  %591 = tail call double @llvm.fabs.f64(double %div47.i.i.i311.i.i.i.i) #3
  %cmp52.i.i.i314.i.i.i.i = fcmp olt double %mul50.i.i.i313.i.i.i.i, %591
  br i1 %cmp52.i.i.i314.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i: ; preds = %do.body40.i.i.i315.i.i.i.i, %do.body.i.i.i304.i.i.i.i, %if.end.i.i.i247.i.i.i.i, %if.then52.i.i.i.i
  %retval.0.i.i.i318.i.i.i.i = phi double [ %mul59.i.i.i.i, %if.then52.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i247.i.i.i.i ], [ %mul35.i.i.i301.i.i.i.i, %do.body.i.i.i304.i.i.i.i ], [ %sub48.i.i.i312.i.i.i.i, %do.body40.i.i.i315.i.i.i.i ]
  %mul61.i.i.i.i = fmul double %add38.i.i.i.i.i.i, %retval.0.i.i.i318.i.i.i.i
  %div62.i.i.i.i = fdiv double %add38.i.i351.i.i.i.i, %mul61.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else63.i.i.i.i:                                ; preds = %if.else49.i.i.i.i
  %mul64.i.i.i.i = fmul double %sub.i.i.i, %sub.i.i.i
  %cmp1.i.i.i.i.i = fcmp oge double %mul64.i.i.i.i, 0x10000000000000
  %cmp2.i.i.i.i.i = fcmp ole double %mul64.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %592 = and i1 %cmp1.i.i.i.i.i, %cmp2.i.i.i.i.i
  br i1 %592, label %if.then66.i.i.i.i, label %if.else71.i.i.i.i

if.then66.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %mul68.i.i.i.i = fmul double %mul64.i.i.i.i, 0x401921FB54442D18
  %cmp.i.i.i.i162.i.i.i.i = fcmp ogt double %mul68.i.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp.i.i.i163.i.i.i.i = fcmp oeq double %mul68.i.i.i.i, 0.000000e+00
  %or.cond.i.i.i164.i.i.i.i = or i1 %cmp.i.i.i.i162.i.i.i.i, %cmp.i.i.i163.i.i.i.i
  br i1 %or.cond.i.i.i164.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end.i.i.i166.i.i.i.i

if.end.i.i.i166.i.i.i.i:                          ; preds = %if.then66.i.i.i.i
  %cmp.i.i.i.i.i165.i.i.i.i = fcmp uno double %mul68.i.i.i.i, 0.000000e+00
  br i1 %cmp.i.i.i.i.i165.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, label %if.end7.i.i.i192.i.i.i.i

if.end7.i.i.i192.i.i.i.i:                         ; preds = %if.end.i.i.i166.i.i.i.i
  %593 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %mul68.i.i.i.i) #3
  %594 = tail call double @llvm.amdgcn.frexp.mant.f64(double %mul68.i.i.i.i) #3
  %595 = tail call i1 @llvm.amdgcn.class.f64(double %mul68.i.i.i.i, i32 519) #3
  %596 = select i1 %595, i32 0, i32 %593
  %597 = select i1 %595, double %mul68.i.i.i.i, double %594
  %mul.i.i.i.i.i178.i.i.i.i = fmul double %597, %597
  %mul1.i.i.i.i.i179.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i180.i.i.i.i = fadd double %mul1.i.i.i.i.i179.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i181.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, 0x3FE479D17050CA47
  %598 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i181.i.i.i.i
  %mul10.i.i.i.i.i183.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %add.i.i.i.i.i180.i.i.i.i
  %mul12.i.i.i.i.i184.i.i.i.i = fmul double %mul.i.i.i.i.i178.i.i.i.i, %598
  %add15.i.i.i.i.i185.i.i.i.i = fadd double %mul10.i.i.i.i.i183.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i186.i.i.i.i = fadd double %mul12.i.i.i.i.i184.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i187.i.i.i.i = fmul double %597, %add15.i.i.i.i.i185.i.i.i.i
  %add23.i.i.i.i.i188.i.i.i.i = fadd double %add18.i.i.i.i.i186.i.i.i.i, %mul20.i.i.i.i.i187.i.i.i.i
  %.frozen212 = freeze i32 %596
  %div.i.i.i189.i.i.i.i = sdiv i32 %.frozen212, 3
  %599 = call i32 @llvm.abs.i32(i32 %div.i.i.i189.i.i.i.i, i1 true)
  %cmp11.i.i.i191.i.i.i.i = icmp ult i32 %599, 64
  %600 = sub nsw i32 0, %div.i.i.i189.i.i.i.i
  %601 = icmp sgt i32 %596, 2
  %602 = select i1 %601, i32 %div.i.i.i189.i.i.i.i, i32 %600
  %603 = zext i32 %602 to i64
  %604 = shl nuw i64 1, %603
  %605 = uitofp i64 %604 to double
  %not.cmp11.i.i.i191.i.i.i.i = xor i1 %cmp11.i.i.i191.i.i.i.i, true
  %606 = or i1 %601, %not.cmp11.i.i.i191.i.i.i.i
  br i1 %606, label %merged.bb15, label %merged.bb16

do.body.i.i.i223.i.i.i.i:                         ; preds = %merged.bb17, %do.body.i.i.i223.i.i.i.i
  %guess.i.i.i161.i.i.i.i.1 = phi double [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ], [ %mul24.i.i.i210.i.i.i.i, %merged.bb17 ]
  %mul28.i.i.i213.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %guess.i.i.i161.i.i.i.i.1
  %mul29.i.i.i214.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %mul28.i.i.i213.i.i.i.i
  %add30.i.i.i215.i.i.i.i = fadd double %mul68.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add31.i.i.i216.i.i.i.i = fadd double %mul68.i.i.i.i, %add30.i.i.i215.i.i.i.i
  %add32.i.i.i217.i.i.i.i = fadd double %mul29.i.i.i214.i.i.i.i, %mul29.i.i.i214.i.i.i.i
  %add33.i.i.i218.i.i.i.i = fadd double %mul68.i.i.i.i, %add32.i.i.i217.i.i.i.i
  %div34.i.i.i219.i.i.i.i = fdiv double %add31.i.i.i216.i.i.i.i, %add33.i.i.i218.i.i.i.i
  %mul35.i.i.i220.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.1, %div34.i.i.i219.i.i.i.i
  %sub36.i.i.i221.i.i.i.i = fsub double 1.000000e+00, %div34.i.i.i219.i.i.i.i
  %607 = tail call double @llvm.fabs.f64(double %sub36.i.i.i221.i.i.i.i) #3
  %cmp38.i.i.i222.i.i.i.i = fcmp ogt double %607, 0x3EC0000000000000
  br i1 %cmp38.i.i.i222.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

do.body40.i.i.i234.i.i.i.i:                       ; preds = %merged.bb17, %do.body40.i.i.i234.i.i.i.i
  %guess.i.i.i161.i.i.i.i.2 = phi double [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ], [ %mul24.i.i.i210.i.i.i.i, %merged.bb17 ]
  %mul41.i.i.i224.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, %guess.i.i.i161.i.i.i.i.2
  %div42.i.i.i225.i.i.i.i = fdiv double %mul68.i.i.i.i, %guess.i.i.i161.i.i.i.i.2
  %sub43.i.i.i226.i.i.i.i = fsub double %mul41.i.i.i224.i.i.i.i, %div42.i.i.i225.i.i.i.i
  %mul44.i.i.i227.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.2, 2.000000e+00
  %div45.i.i.i228.i.i.i.i = fdiv double %mul68.i.i.i.i, %mul41.i.i.i224.i.i.i.i
  %add46.i.i.i229.i.i.i.i = fadd double %mul44.i.i.i227.i.i.i.i, %div45.i.i.i228.i.i.i.i
  %div47.i.i.i230.i.i.i.i = fdiv double %sub43.i.i.i226.i.i.i.i, %add46.i.i.i229.i.i.i.i
  %sub48.i.i.i231.i.i.i.i = fsub double %guess.i.i.i161.i.i.i.i.2, %div47.i.i.i230.i.i.i.i
  %mul50.i.i.i232.i.i.i.i = fmul double %sub48.i.i.i231.i.i.i.i, 0x3EC0000000000000
  %608 = tail call double @llvm.fabs.f64(double %div47.i.i.i230.i.i.i.i) #3
  %cmp52.i.i.i233.i.i.i.i = fcmp olt double %mul50.i.i.i232.i.i.i.i, %608
  br i1 %cmp52.i.i.i233.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i, label %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i

_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i: ; preds = %do.body40.i.i.i234.i.i.i.i, %do.body.i.i.i223.i.i.i.i, %if.end.i.i.i166.i.i.i.i, %if.then66.i.i.i.i
  %retval.0.i.i.i237.i.i.i.i = phi double [ %mul68.i.i.i.i, %if.then66.i.i.i.i ], [ 0x7FF8000000000000, %if.end.i.i.i166.i.i.i.i ], [ %mul35.i.i.i220.i.i.i.i, %do.body.i.i.i223.i.i.i.i ], [ %sub48.i.i.i231.i.i.i.i, %do.body40.i.i.i234.i.i.i.i ]
  %div70.i.i.i.i = fdiv double 1.000000e+00, %retval.0.i.i.i237.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.else71.i.i.i.i:                                ; preds = %if.else63.i.i.i.i
  %cmp72.i.i.i.i = fcmp ogt double %sub.i.i.i, 0.000000e+00
  br i1 %cmp72.i.i.i.i, label %if.then73.i.i.i.i, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

if.then73.i.i.i.i:                                ; preds = %if.else71.i.i.i.i
  %cmp.i.i.i.i79.i.i.i.i = fcmp ogt double %sub.i.i.i, 0x7FEFFFFFFFFFFFFF
  %cmp1.i.i.i.i80.i.i.i.i = fcmp olt double %sub.i.i.i, 0xFFEFFFFFFFFFFFFF
  %609 = or i1 %cmp.i.i.i.i79.i.i.i.i, %cmp1.i.i.i.i80.i.i.i.i
  %or.cond.i.i.i82.i.i.i.i = or i1 %38, %609
  %brmerge170 = or i1 %33, %or.cond.i.i.i82.i.i.i.i
  %sub.i.i.i.mux = select i1 %or.cond.i.i.i82.i.i.i.i, double %sub.i.i.i, double 0x7FF8000000000000
  br i1 %brmerge170, label %if.end7.i.i.i.i.i.i.i, label %if.end4.i.i.i92.i.i.i.i

if.end4.i.i.i92.i.i.i.i:                          ; preds = %if.then73.i.i.i.i
  %cmp5.i.i.i91.i.i.i.i = fcmp olt double %sub.i.i.i, 0.000000e+00
  %fneg.i.i.i93.i.i.i.i = fneg double %sub.i.i.i
  %z.addr.i.i.i76.i.i.i.i.0 = select i1 %cmp5.i.i.i91.i.i.i.i, double %fneg.i.i.i93.i.i.i.i, double %sub.i.i.i
  %610 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %611 = tail call double @llvm.amdgcn.frexp.mant.f64(double %z.addr.i.i.i76.i.i.i.i.0) #3
  %612 = tail call i1 @llvm.amdgcn.class.f64(double %z.addr.i.i.i76.i.i.i.i.0, i32 519) #3
  %613 = select i1 %612, i32 0, i32 %610
  %614 = select i1 %612, double %z.addr.i.i.i76.i.i.i.i.0, double %611
  %mul.i.i.i.i.i97.i.i.i.i = fmul double %614, %614
  %mul1.i.i.i.i.i98.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FC1635D9C8A0E53
  %add.i.i.i.i.i99.i.i.i.i = fadd double %mul1.i.i.i.i.i98.i.i.i.i, 0x3FF499D5B196941B
  %mul5.i.i.i.i.i100.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, 0x3FE479D17050CA47
  %615 = fsub double 0xBFF7D5DA52FA76A3, %mul5.i.i.i.i.i100.i.i.i.i
  %mul10.i.i.i.i.i102.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %add.i.i.i.i.i99.i.i.i.i
  %mul12.i.i.i.i.i103.i.i.i.i = fmul double %mul.i.i.i.i.i97.i.i.i.i, %615
  %add15.i.i.i.i.i104.i.i.i.i = fadd double %mul10.i.i.i.i.i102.i.i.i.i, 0x3FF549B716277AF3
  %add18.i.i.i.i.i105.i.i.i.i = fadd double %mul12.i.i.i.i.i103.i.i.i.i, 0x3FD80B2F68E5F6AD
  %mul20.i.i.i.i.i106.i.i.i.i = fmul double %614, %add15.i.i.i.i.i104.i.i.i.i
  %add23.i.i.i.i.i107.i.i.i.i = fadd double %add18.i.i.i.i.i105.i.i.i.i, %mul20.i.i.i.i.i106.i.i.i.i
  %.frozen213 = freeze i32 %613
  %div.i.i.i108.i.i.i.i = sdiv i32 %.frozen213, 3
  %616 = sub nsw i32 0, %div.i.i.i108.i.i.i.i
  %617 = call i32 @llvm.abs.i32(i32 %div.i.i.i108.i.i.i.i, i1 true)
  %cmp11.i.i.i110.i.i.i.i = icmp ult i32 %617, 64
  %618 = icmp sgt i32 %613, 2
  %619 = select i1 %618, i32 %div.i.i.i108.i.i.i.i, i32 %616
  %620 = zext i32 %619 to i64
  %621 = shl nuw i64 1, %620
  %622 = uitofp i64 %621 to double
  %not.cmp11.i.i.i110.i.i.i.i = xor i1 %cmp11.i.i.i110.i.i.i.i, true
  %623 = or i1 %618, %not.cmp11.i.i.i110.i.i.i.i
  br i1 %623, label %merged.bb18, label %merged.bb19

if.then12.i.i.i32.i.i.i.i:                        ; preds = %merged.bb23
  br i1 %618, label %if.then14.i.i.i37.i.i.i.i, label %if.else.i.i.i43.i.i.i.i, !decision.merged_from !12, !decision.origin !13

if.then14.i.i.i37.i.i.i.i:                        ; preds = %if.then12.i.i.i32.i.i.i.i
  %mul.i.i.i36.i.i.i.i = fmul double %add23.i.i.i.i.i107.i.i.i.i, %622
  br label %if.end23.i.i.i50.i.i.i.i

if.else.i.i.i43.i.i.i.i:                          ; preds = %if.then12.i.i.i32.i.i.i.i
  %div19.i.i.i42.i.i.i.i = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %622
  br label %if.end23.i.i.i50.i.i.i.i

if.else21.i.i.i44.i.i.i.i:                        ; preds = %merged.bb23
  %624 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  br label %if.end23.i.i.i50.i.i.i.i

if.end23.i.i.i50.i.i.i.i:                         ; preds = %if.else21.i.i.i44.i.i.i.i, %if.else.i.i.i43.i.i.i.i, %if.then14.i.i.i37.i.i.i.i
  %guess.i.i.i10.i.i.i.i.0 = phi double [ %mul.i.i.i36.i.i.i.i, %if.then14.i.i.i37.i.i.i.i ], [ %div19.i.i.i42.i.i.i.i, %if.else.i.i.i43.i.i.i.i ], [ %624, %if.else21.i.i.i44.i.i.i.i ]
  %mul24.i.i.i48.i.i.i.i = fmul double %984, %guess.i.i.i10.i.i.i.i.0
  br label %merged.bb

if.end7.i.i.i.i.i.i.i:                            ; preds = %merged.bb21, %if.then73.i.i.i.i
  %retval.0.i.i.i156.i.i.i.i162 = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %1100, %merged.bb21 ]
  %retval.0.i.i.i.i.i.i.i = phi double [ %sub.i.i.i.mux, %if.then73.i.i.i.i ], [ %1006, %merged.bb21 ]
  %mul76.i.i.i.i = fmul double %retval.0.i.i.i156.i.i.i.i162, %retval.0.i.i.i.i.i.i.i
  %mul79.i.i.i.i = fmul double %mul76.i.i.i.i, 0x3FFD8639FDCB60EB
  %div80.i.i.i.i = fdiv double 1.000000e+00, %mul79.i.i.i.i
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

cond.false7.i.i.i:                                ; preds = %if.end14.i.i
  %decision.interval6 = fcmp ult double %arrayidx.val, 1.250000e-01
  br i1 %decision.interval6, label %if.else17.i.i.i.i, label %decision.dispatch5, !decision.condition_prefix !6

decision.dispatch5:                               ; preds = %cond.false7.i.i.i
  %decision.interval = fcmp ult double %arrayidx.val, 2.500000e-01
  %625 = fcmp ult double %arrayidx.val, 3.750000e-01
  %626 = select i1 %625, double -2.500000e-01, double -3.750000e-01
  %627 = select i1 %decision.interval, double -1.250000e-01, double %626
  %628 = select i1 %decision.interval, i1 poison, i1 %625
  %629 = fadd double %arrayidx.val, %627
  %630 = fmul double %629, %629
  %631 = select i1 %628, double 0x402A50B00A1E7B86, double 0x40132BDEE3243B58
  %632 = select i1 %decision.interval, double 0x406D392CDE09E490, double %631
  %633 = fmul double %630, %632
  br i1 %decision.interval, label %fusion.side1, label %fusion.side4

if.else17.i.i.i.i:                                ; preds = %cond.false7.i.i.i
  %634 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %arrayidx.val) #3
  %635 = add nsw i32 %634, -1
  %636 = tail call double @llvm.fabs.f64(double %arrayidx.val) #4
  %637 = fcmp oeq double %636, 0x7FF0000000000000
  %638 = select i1 %637, i32 2147483647, i32 %635
  %639 = fcmp oeq double %arrayidx.val, 0.000000e+00
  %640 = select i1 %639, i32 -2147483648, i32 %638
  %cmp106.i.i.i.i = icmp sgt i32 %640, -1025
  br i1 %cmp106.i.i.i.i, label %decision.dispatch, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, !decision.condition_prefix !6

decision.dispatch:                                ; preds = %if.else17.i.i.i.i
  %cmp19.i.i.i.i = icmp sgt i32 %640, -5
  br i1 %cmp19.i.i.i.i, label %fusion.common, label %fusion.side

fusion.side:                                      ; preds = %decision.dispatch
  %641 = icmp sgt i32 %640, -65
  %642 = select i1 %641, i32 -17, i32 -257
  %643 = icmp sgt i32 %640, %642
  %644 = select i1 %641, i32 -9, i32 -129
  %645 = select i1 %641, i32 -33, i32 -513
  %646 = select i1 %643, i32 %644, i32 %645
  %647 = icmp sgt i32 %640, %646
  %648 = select i1 %641, i32 4, i32 64
  %649 = select i1 %641, i32 16, i32 256
  %650 = select i1 %643, i32 %648, i32 %649
  %651 = select i1 %641, i32 8, i32 128
  %652 = select i1 %641, i32 32, i32 512
  %653 = select i1 %643, i32 %651, i32 %652
  %654 = select i1 %647, i32 %650, i32 %653
  br label %fusion.common

fusion.common:                                    ; preds = %fusion.side, %decision.dispatch
  %655 = phi i32 [ 3, %decision.dispatch ], [ %654, %fusion.side ]
  %656 = phi i1 [ poison, %decision.dispatch ], [ %641, %fusion.side ]
  %657 = phi i1 [ poison, %decision.dispatch ], [ %643, %fusion.side ]
  %658 = phi i1 [ poison, %decision.dispatch ], [ %647, %fusion.side ]
  %659 = tail call double @llvm.amdgcn.ldexp.f64(double %arrayidx.val, i32 %655) #3
  %660 = tail call double @llvm.amdgcn.frexp.mant.f64(double %659) #3
  %661 = fcmp olt double %660, 0x3FE5555555555555
  %662 = zext i1 %661 to i32
  %663 = tail call double @llvm.amdgcn.ldexp.f64(double %660, i32 %662) #3
  %664 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %659) #3
  %665 = sub nsw i32 %664, %662
  %666 = fadd double %663, -1.000000e+00
  %667 = fadd double %663, 1.000000e+00
  %668 = fsub double %667, %663
  %669 = fsub double %667, %668
  %670 = fsub double %663, %669
  %671 = fsub double 1.000000e+00, %668
  %672 = fadd double %671, %670
  %673 = tail call double @llvm.amdgcn.rcp.f64(double %667) #3
  %674 = fneg double %667
  %675 = tail call double @llvm.fma.f64(double %674, double %673, double 1.000000e+00) #3
  %676 = tail call double @llvm.fma.f64(double %675, double %673, double %673) #3
  %677 = tail call double @llvm.fma.f64(double %674, double %676, double 1.000000e+00) #3
  %678 = tail call double @llvm.fma.f64(double %677, double %676, double %676) #3
  %679 = fmul double %666, %678
  %680 = fmul double %667, %679
  %681 = fneg double %680
  %682 = tail call double @llvm.fma.f64(double %679, double %667, double %681) #3
  %683 = tail call double @llvm.fma.f64(double %679, double %672, double %682) #3
  %684 = fadd double %680, %683
  %685 = fsub double %684, %680
  %686 = fsub double %683, %685
  %687 = fsub double %666, %684
  %688 = fsub double %666, %687
  %689 = fsub double %688, %684
  %690 = fsub double %689, %686
  %691 = fadd double %687, %690
  %692 = fmul double %678, %691
  %693 = fadd double %679, %692
  %694 = fsub double %693, %679
  %695 = fsub double %692, %694
  %696 = fmul double %693, %693
  %697 = fneg double %696
  %698 = tail call double @llvm.fma.f64(double %693, double %693, double %697) #3
  %699 = fmul double %695, 2.000000e+00
  %700 = tail call double @llvm.fma.f64(double %693, double %699, double %698) #3
  %701 = tail call double @llvm.fma.f64(double %695, double %695, double %700) #3
  %702 = fadd double %696, %701
  %703 = fsub double %702, %696
  %704 = fsub double %701, %703
  %705 = tail call double @llvm.fma.f64(double %702, double 0x3FC3AB76BF559E2B, double 0x3FC385386B47B09A) #3
  %706 = tail call double @llvm.fma.f64(double %702, double %705, double 0x3FC7474DD7F4DF2E) #3
  %707 = tail call double @llvm.fma.f64(double %702, double %706, double 0x3FCC71C016291751) #3
  %708 = tail call double @llvm.fma.f64(double %702, double %707, double 0x3FD249249B27ACF1) #3
  %709 = tail call double @llvm.fma.f64(double %702, double %708, double 0x3FD99999998EF7B6) #3
  %710 = tail call double @llvm.fma.f64(double %702, double %709, double 0x3FE5555555555780) #3
  %711 = tail call double @llvm.amdgcn.ldexp.f64(double %693, i32 1) #3
  %712 = tail call double @llvm.amdgcn.ldexp.f64(double %695, i32 1) #3
  %713 = fmul double %693, %702
  %714 = fneg double %713
  %715 = tail call double @llvm.fma.f64(double %693, double %702, double %714) #3
  %716 = fmul double %695, %702
  %717 = tail call double @llvm.fma.f64(double %693, double %704, double %716) #3
  %718 = fadd double %715, %717
  %719 = fadd double %713, %718
  %720 = fsub double %719, %713
  %721 = fsub double %718, %720
  %722 = fmul double %719, %710
  %723 = fneg double %722
  %724 = tail call double @llvm.fma.f64(double %719, double %710, double %723) #3
  %725 = tail call double @llvm.fma.f64(double %721, double %710, double %724) #3
  %726 = fadd double %722, %725
  %727 = fsub double %726, %722
  %728 = fsub double %725, %727
  %729 = fadd double %711, %726
  %730 = fsub double %729, %711
  %731 = fsub double %729, %730
  %732 = fsub double %711, %731
  %733 = fsub double %726, %730
  %734 = fadd double %733, %732
  %735 = fadd double %712, %728
  %736 = fsub double %735, %712
  %737 = fsub double %735, %736
  %738 = fsub double %712, %737
  %739 = fsub double %728, %736
  %740 = fadd double %739, %738
  %741 = fadd double %735, %734
  %742 = fadd double %729, %741
  %743 = fsub double %742, %729
  %744 = fsub double %741, %743
  %745 = fadd double %740, %744
  %746 = fadd double %742, %745
  %747 = fsub double %746, %742
  %748 = fsub double %745, %747
  %749 = sitofp i32 %665 to double
  %750 = select i1 %cmp19.i.i.i.i, double %749, double poison
  %751 = fmul double %746, 0x3FF71547652B82FE
  %752 = fneg double %751
  %753 = fmul double %746, 0x3C7777D0FFDA0D24
  br i1 %cmp19.i.i.i.i, label %fusion.side5, label %fusion.common4

fusion.side5:                                     ; preds = %fusion.common
  %754 = insertelement <2 x double> undef, double %746, i32 0
  %755 = insertelement <2 x double> %754, double %748, i32 1
  %756 = insertelement <2 x double> undef, double %752, i32 0
  %757 = insertelement <2 x double> %756, double %753, i32 1
  %758 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %755, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %757) #3
  %759 = extractelement <2 x double> %758, i32 0
  %760 = extractelement <2 x double> %758, i32 1
  %761 = fadd double %759, %760
  %762 = fadd double %751, %761
  %763 = fsub double %762, %751
  %764 = fsub double %761, %763
  %765 = fadd double %762, %750
  %766 = fsub double %765, %750
  %767 = fsub double %766, %765
  %768 = fadd double %767, %750
  %769 = fsub double %762, %766
  %770 = fadd double %769, %768
  %771 = fadd double %764, %770
  %772 = fadd double %765, %771
  %773 = tail call double @llvm.fabs.f64(double %659) #4
  %774 = fcmp oeq double %773, 0x7FF0000000000000
  %775 = select i1 %774, double %659, double %772
  %776 = fcmp olt double %659, 0.000000e+00
  %777 = select i1 %776, double 0x7FF8000000000000, double %775
  %778 = fcmp oeq double %659, 0.000000e+00
  %779 = select i1 %778, double 0xFFF0000000000000, double %777
  %780 = fmul double %779, %779
  %781 = fmul double %780, 0x3F1989D450BBA5CA
  %782 = fsub double 0xBFBD94CCEC41CB08, %781
  %783 = fmul double %780, 0x3F7B3A00DD9C9429
  %784 = fsub double 0xBFE8DDD719DA7D3E, %783
  %785 = fmul double %780, %782
  %786 = fmul double %780, %784
  %787 = fadd double %785, 0xC001974D2C397C76
  %788 = fadd double %786, 0xC001804F92FE2A82
  %789 = fmul double %779, %787
  %790 = fsub double %788, %789
  %791 = fmul double %780, 0x3EDBEC7AF5AC0D6F
  %792 = fadd double %791, 0x3F98BA1DB321D0E9
  %793 = fmul double %780, 0x3F4ED662BB480251
  %794 = fadd double %793, 0x3FCBD444F5D4FCC2
  %795 = fmul double %780, %792
  %796 = fmul double %780, %794
  %797 = fadd double %795, 0x3FE957680773BEB6
  %798 = fadd double %796, 1.000000e+00
  %799 = fmul double %779, %797
  %800 = fsub double %798, %799
  %801 = fdiv double %790, %800
  br label %fusion.common4

fusion.common4:                                   ; preds = %fusion.side5, %fusion.common
  %802 = phi double [ poison, %fusion.common ], [ %801, %fusion.side5 ]
  br i1 %cmp19.i.i.i.i, label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, label %decision.dispatch1

decision.dispatch1:                               ; preds = %fusion.common4
  br i1 %658, label %merged.bb73, label %merged.bb74

fusion.side12:                                    ; preds = %decision.dispatch3
  %803 = fmul double %10, 0x3FF51F0306685285
  %804 = fsub double 0xBFEEB82FAA589934, %803
  %805 = fmul double %10, 0x3FEFDC5AEE1525E4
  %806 = fsub double 0x4043A793DEC20DEB, %805
  br label %fusion.common11

fusion.common11:                                  ; preds = %fusion.side12, %decision.dispatch3
  %807 = phi double [ 0x40354F2A1256B431, %decision.dispatch3 ], [ 0x4020675EC4F85A38, %fusion.side12 ]
  %808 = phi double [ 0x4063AA2F5D62DCD3, %decision.dispatch3 ], [ 0x403058D46A8EC004, %fusion.side12 ]
  %809 = phi double [ 0x407BA4300BFE5087, %decision.dispatch3 ], [ 0xC02E8C55CA7195EF, %fusion.side12 ]
  %810 = phi double [ 0xC083E59B9D34A0F1, %decision.dispatch3 ], [ 0x401A11C0BB0DC22E, %fusion.side12 ]
  %811 = phi double [ 0x406113A5A6902AC1, %decision.dispatch3 ], [ %804, %fusion.side12 ]
  %812 = phi double [ poison, %decision.dispatch3 ], [ %806, %fusion.side12 ]
  %813 = fmul double %10, %811
  %814 = fmul double %10, %812
  %815 = fadd double %813, %810
  %.op3 = fadd double %814, 0xC04B158FF790C730
  %816 = fmul double %10, 0x4071AEC837B9190D
  %817 = fsub double 0x406A5A0FD2D4B901, %816
  %fusion.paired18 = select i1 %cmp.i.i.i.i, double %817, double %.op3
  %818 = fmul double %10, %815
  %819 = fmul double %10, %fusion.paired18
  %820 = fadd double %818, %809
  %821 = fadd double %819, %808
  %822 = fmul double %10, %820
  %823 = fmul double %10, %821
  %824 = fadd double %822, %807
  %825 = fadd double %823, 1.000000e+00
  %826 = fmul double %9, %824
  %827 = fadd double %825, %826
  %828 = fdiv double %30, %827
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

fusion.side1:                                     ; preds = %decision.dispatch5
  %829 = fsub double 0x408C7AAA9D225E9A, %633
  %830 = fmul double %630, 0x408B6249334DA816
  %831 = fsub double 0x408C1B9BAF952B96, %830
  %832 = fmul double %630, %829
  %833 = fadd double %832, 0xC05E9BCF5C362E51
  br label %fusion.common1

fusion.side4:                                     ; preds = %decision.dispatch5
  %834 = select i1 %628, double 0xC03EAAFBAB179207, double 0xC0360FDD97954BA2
  %835 = fadd double %633, %834
  %836 = select i1 %628, double 0x403CBAD71AE3B29A, double 0x401CB5EDEDB31A3B
  %837 = fmul double %630, %836
  %838 = fadd double %837, 0xC017CB97C9E45E0D
  %839 = fsub double 0x4040A8BCD7811DE4, %837
  %840 = select i1 %628, double %839, double %838
  br label %fusion.common1

fusion.common1:                                   ; preds = %fusion.side4, %fusion.side1
  %841 = phi double [ 0xC0320C17B7F0ED52, %fusion.side1 ], [ 0x401B5545C0CB5BDA, %fusion.side4 ]
  %842 = phi double [ 0x404C078043CB129C, %fusion.side1 ], [ 0x3FF693D2420640AD, %fusion.side4 ]
  %843 = phi double [ %833, %fusion.side1 ], [ %840, %fusion.side4 ]
  %fusion.paired4 = phi double [ %831, %fusion.side1 ], [ %835, %fusion.side4 ]
  %844 = fmul double %630, %fusion.paired4
  %845 = fmul double %630, %843
  %846 = select i1 %628, double 0x402CB09090084637, double 0x4027FEF192CFFD80
  %847 = select i1 %628, double 0xC013B1AD6B90733F, double 0x3FF83BDAD25D5F48
  %848 = select i1 %decision.interval, double 0xC04249A2BD20D346, double %847
  %849 = fadd double %845, %848
  %850 = select i1 %628, double 0xBFFA1FFFE7A41296, double 0xBFF2C5AD0DCDC29A
  %.v.v = select i1 %decision.interval, double 0xC066A4A24A4E1713, double %846
  %.v = fadd double %844, %.v.v
  %851 = fmul double %630, %.v
  %852 = select i1 %decision.interval, double 0xC001804F92FE2A82, double %850
  %853 = fadd double %851, %852
  %854 = fmul double %629, %849
  %855 = fadd double %854, %853
  %856 = fmul double %630, 0x405E5232607614DB
  %857 = fadd double %856, 0xC0809E1D789AFFE5
  %858 = fmul double %630, %842
  %859 = fsub double %841, %858
  %860 = select i1 %628, double 0x40296F06194D60C2, double 0x40074E9A9F865729
  %861 = select i1 %decision.interval, double %857, double %860
  %862 = fmul double %630, %861
  %863 = select i1 %628, double 0xC030F25386AA802B, double 0xC016B372910B83AB
  %864 = fmul double %630, %859
  %865 = select i1 %decision.interval, double 0x4071A64A34042F35, double %863
  %866 = fadd double %862, %865
  %867 = select i1 %628, double 0x40199996D51EE9B7, double %859
  %868 = fmul double %630, %867
  %869 = fsub double 0x40034649FCCCF81F, %868
  %.op4 = fadd double %864, 0x405F12CC60181A8F
  %870 = select i1 %decision.interval, double poison, double %869
  %871 = fmul double %630, %866
  %.op5 = fadd double %868, 0xC0138A29DF206C0B
  %872 = select i1 %628, double 0x40158CEB587D3265, double 0x3FFC33F0B4C09D66
  %873 = select i1 %decision.interval, double poison, double %.op5
  %874 = select i1 %decision.interval, double 0x40332E0500972875, double %872
  %875 = fadd double %871, %874
  %876 = select i1 %628, double %870, double %873
  %.v6 = select i1 %decision.interval, double %.op4, double %876
  %877 = fmul double %630, %.v6
  %878 = fadd double %877, 1.000000e+00
  %879 = fmul double %629, %875
  %880 = fadd double %879, %878
  %881 = fdiv double %855, %880
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i: ; preds = %merged.bb70, %fusion.common1, %fusion.common11, %fusion.common4, %if.else17.i.i.i.i, %if.end7.i.i.i.i.i.i.i, %if.else71.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i
  %retval.0.i.i.i = phi double [ %div20.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit666.i.i.i.i ], [ %div34.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit545.i.i.i.i ], [ %div48.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit432.i.i.i.i ], [ %div62.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit319.i.i.i.i ], [ %div70.i.i.i.i, %_ZN5boost4math4cbrtIdEENS0_5tools12promote_argsIJT_EE4typeES4_.exit238.i.i.i.i ], [ 0x7FF0000000000000, %if.else71.i.i.i.i ], [ %div80.i.i.i.i, %if.end7.i.i.i.i.i.i.i ], [ 0xFFF0000000000000, %if.else17.i.i.i.i ], [ %802, %fusion.common4 ], [ %828, %fusion.common11 ], [ %881, %fusion.common1 ], [ %942, %merged.bb70 ]
  %add.i.i = fadd double %retval.0.i.i.i, 0.000000e+00
  br label %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit

_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit: ; preds = %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i, %lor.lhs.false2.i.i.i, %if.end8.i.i
  %retval.0.i.i = phi double [ 0x7FF8000000000000, %if.end8.i.i ], [ 0x7FF8000000000000, %lor.lhs.false2.i.i.i ], [ %add.i.i, %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i ]
  %arrayidx712 = getelementptr inbounds double, double addrspace(1)* %output.coerce, i64 %idxprom
  store double %retval.0.i.i, double addrspace(1)* %arrayidx712, align 8, !tbaa !8
  br label %if.end

if.end:                                           ; preds = %_ZN5boost4math8quantileIdNS0_8policies6policyINS2_14default_policyES4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_S4_EEEET_RKNS0_20mapairy_distributionIS6_T0_EERKS6_.exit, %entry
  ret void

merged.bb70:                                      ; preds = %merged.branch.split83, %merged.bb75
  %merged.select99 = phi double [ %1050, %merged.bb75 ], [ %1078, %merged.branch.split83 ]
  %merged.select98 = phi double [ %1049, %merged.bb75 ], [ %1077, %merged.branch.split83 ]
  %merged.select97 = phi double [ %1048, %merged.bb75 ], [ %1076, %merged.branch.split83 ]
  %merged.select96 = phi double [ %1047, %merged.bb75 ], [ %1075, %merged.branch.split83 ]
  %merged.select95 = phi double [ %1046, %merged.bb75 ], [ %1074, %merged.branch.split83 ]
  %merged.select94 = phi double [ %1045, %merged.bb75 ], [ %1073, %merged.branch.split83 ]
  %merged.select93 = phi double [ %1044, %merged.bb75 ], [ %1072, %merged.branch.split83 ]
  %merged.select92 = phi double [ %1043, %merged.bb75 ], [ %1071, %merged.branch.split83 ]
  %merged.select91 = phi double [ %1042, %merged.bb75 ], [ %1070, %merged.branch.split83 ]
  %merged.select90 = phi double [ %1041, %merged.bb75 ], [ %1069, %merged.branch.split83 ]
  %merged.select89 = phi double [ %1040, %merged.bb75 ], [ %1068, %merged.branch.split83 ]
  %merged.select88 = phi double [ %1039, %merged.bb75 ], [ %1067, %merged.branch.split83 ]
  %merged.select87 = phi double [ %1038, %merged.bb75 ], [ %1066, %merged.branch.split83 ]
  %merged.select86 = phi double [ %1037, %merged.bb75 ], [ %1065, %merged.branch.split83 ]
  %merged.select124 = phi double [ %1036, %merged.bb75 ], [ %1064, %merged.branch.split83 ]
  %merged.select123 = phi double [ %1035, %merged.bb75 ], [ %1063, %merged.branch.split83 ]
  %merged.select122 = phi double [ %1034, %merged.bb75 ], [ %1062, %merged.branch.split83 ]
  %merged.select121 = phi double [ %1033, %merged.bb75 ], [ %1061, %merged.branch.split83 ]
  %merged.select120 = phi double [ %1032, %merged.bb75 ], [ %1060, %merged.branch.split83 ]
  %merged.select119 = phi double [ %1031, %merged.bb75 ], [ %1059, %merged.branch.split83 ]
  %merged.select118 = phi double [ %1030, %merged.bb75 ], [ %1058, %merged.branch.split83 ]
  %merged.select117 = phi double [ %1029, %merged.bb75 ], [ %1057, %merged.branch.split83 ]
  %merged.select116 = phi double [ %1028, %merged.bb75 ], [ %1056, %merged.branch.split83 ]
  %merged.select115 = phi double [ %1027, %merged.bb75 ], [ %1055, %merged.branch.split83 ]
  %merged.select114 = phi double [ %1026, %merged.bb75 ], [ %1054, %merged.branch.split83 ]
  %merged.select113 = phi double [ %1025, %merged.bb75 ], [ %1053, %merged.branch.split83 ]
  %merged.select112 = phi double [ %1024, %merged.bb75 ], [ %1052, %merged.branch.split83 ]
  %merged.select111 = phi double [ %1023, %merged.bb75 ], [ %1051, %merged.branch.split83 ]
  %882 = fadd double %1021, %1022
  %883 = fadd double %751, %882
  %884 = fsub double %883, %751
  %885 = fsub double %882, %884
  %886 = fadd double %883, %749
  %887 = fsub double %886, %749
  %888 = fsub double %887, %886
  %889 = fadd double %888, %749
  %890 = fsub double %883, %887
  %891 = fadd double %890, %889
  %892 = fadd double %885, %891
  %893 = fadd double %886, %892
  %894 = tail call double @llvm.fabs.f64(double %659) #4
  %895 = fcmp oeq double %894, 0x7FF0000000000000
  %896 = select i1 %895, double %659, double %893
  %897 = fcmp olt double %659, 0.000000e+00
  %898 = select i1 %897, double 0x7FF8000000000000, double %896
  %899 = fcmp oeq double %659, 0.000000e+00
  %900 = select i1 %899, double 0xFFF0000000000000, double %898
  %901 = fmul double %900, %900
  %902 = select i1 %657, double %merged.select86, double %merged.select111
  %903 = fmul double %901, %902
  %904 = select i1 %657, double %merged.select87, double %merged.select112
  %905 = fsub double %904, %903
  %906 = select i1 %657, double %merged.select88, double %merged.select113
  %907 = fmul double %901, %906
  %908 = select i1 %657, double %merged.select89, double %merged.select114
  %909 = fsub double %908, %907
  %910 = fmul double %901, %905
  %911 = fmul double %901, %909
  %912 = select i1 %657, double %merged.select90, double %merged.select115
  %913 = fadd double %910, %912
  %914 = select i1 %657, double %merged.select91, double %merged.select116
  %915 = fadd double %911, %914
  %916 = fmul double %901, %913
  %917 = fmul double %901, %915
  %918 = select i1 %657, double %merged.select92, double %merged.select117
  %919 = fadd double %916, %918
  %920 = select i1 %657, double %merged.select93, double %merged.select118
  %921 = fadd double %917, %920
  %922 = fmul double %900, %919
  %923 = fsub double %921, %922
  %924 = select i1 %657, double %merged.select94, double %merged.select119
  %925 = fmul double %901, %924
  %926 = select i1 %657, double %merged.select95, double %merged.select120
  %927 = fadd double %925, %926
  %928 = select i1 %657, double %merged.select96, double %merged.select121
  %929 = fmul double %901, %928
  %930 = select i1 %657, double %merged.select97, double %merged.select122
  %931 = fadd double %929, %930
  %932 = fmul double %901, %927
  %933 = fmul double %901, %931
  %934 = select i1 %657, double %merged.select98, double %merged.select123
  %935 = fadd double %932, %934
  %936 = select i1 %657, double %merged.select99, double %merged.select124
  %937 = fadd double %933, %936
  %938 = fmul double %901, %935
  %939 = fadd double %938, 1.000000e+00
  %940 = fmul double %900, %937
  %941 = fsub double %939, %940
  %942 = fdiv double %923, %941
  br label %_ZN5boost4math6detail25mapairy_quantile_imp_precIdEET_RKS3_bRKSt17integral_constantIiLi53EE.exit.i.i

merged.bb3:                                       ; preds = %if.end7.i.i.i620.i.i.i.i
  %943 = fmul double %add23.i.i.i.i.i616.i.i.i.i, %174
  %944 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i616.i.i.i.i, i32 %div.i.i.i617.i.i.i.i) #3
  %guard.value = select i1 %cmp11.i.i.i619.i.i.i.i, double %943, double undef
  %guard.value7 = select i1 %cmp11.i.i.i619.i.i.i.i, double undef, double %944
  br label %merged.bb5

merged.bb4:                                       ; preds = %if.end7.i.i.i620.i.i.i.i
  %945 = fdiv double %add23.i.i.i.i.i616.i.i.i.i, %174
  br label %merged.bb5

merged.bb5:                                       ; preds = %merged.bb4, %merged.bb3
  %946 = phi double [ %guard.value, %merged.bb3 ], [ %945, %merged.bb4 ]
  %947 = phi double [ %guard.value7, %merged.bb3 ], [ undef, %merged.bb4 ]
  %guess.i.i.i589.i.i.i.i.0 = select i1 %cmp11.i.i.i619.i.i.i.i, double %946, double %947
  %.neg6 = mul nsw i32 %div.i.i.i617.i.i.i.i, -3
  %rem.i.i.i635.i.i.i.i.decomposed = add i32 %.frozen, 2
  %add.i.i.i636.i.i.i.i = add i32 %rem.i.i.i635.i.i.i.i.decomposed, %.neg6
  %948 = zext i32 %add.i.i.i636.i.i.i.i to i64
  %arrayidx1.i.i.i637.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %948
  %949 = load double, double addrspace(4)* %arrayidx1.i.i.i637.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i638.i.i.i.i = fmul double %guess.i.i.i589.i.i.i.i.0, %949
  %cmp26.i.i.i639.i.i.i.i = icmp slt i32 %165, 1021
  br i1 %cmp26.i.i.i639.i.i.i.i, label %do.body.i.i.i651.i.i.i.i, label %do.body40.i.i.i662.i.i.i.i

merged.bb6:                                       ; preds = %if.end7.i.i.i499.i.i.i.i
  %950 = fmul double %add23.i.i.i.i.i495.i.i.i.i, %312
  %951 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i495.i.i.i.i, i32 %div.i.i.i496.i.i.i.i) #3
  %guard.value10 = select i1 %cmp11.i.i.i498.i.i.i.i, double %950, double undef
  %guard.value11 = select i1 %cmp11.i.i.i498.i.i.i.i, double undef, double %951
  br label %merged.bb8

merged.bb7:                                       ; preds = %if.end7.i.i.i499.i.i.i.i
  %952 = fdiv double %add23.i.i.i.i.i495.i.i.i.i, %312
  br label %merged.bb8

merged.bb8:                                       ; preds = %merged.bb7, %merged.bb6
  %953 = phi double [ %guard.value10, %merged.bb6 ], [ %952, %merged.bb7 ]
  %954 = phi double [ %guard.value11, %merged.bb6 ], [ undef, %merged.bb7 ]
  %guess.i.i.i468.i.i.i.i.0 = select i1 %cmp11.i.i.i498.i.i.i.i, double %953, double %954
  %.neg5 = mul nsw i32 %div.i.i.i496.i.i.i.i, -3
  %rem.i.i.i514.i.i.i.i.decomposed = add i32 %.frozen209, 2
  %add.i.i.i515.i.i.i.i = add i32 %rem.i.i.i514.i.i.i.i.decomposed, %.neg5
  %955 = zext i32 %add.i.i.i515.i.i.i.i to i64
  %arrayidx1.i.i.i516.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %955
  %956 = load double, double addrspace(4)* %arrayidx1.i.i.i516.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i517.i.i.i.i = fmul double %guess.i.i.i468.i.i.i.i.0, %956
  %cmp26.i.i.i518.i.i.i.i = icmp slt i32 %303, 1021
  br i1 %cmp26.i.i.i518.i.i.i.i, label %do.body.i.i.i530.i.i.i.i, label %do.body40.i.i.i541.i.i.i.i

merged.bb9:                                       ; preds = %if.end7.i.i.i386.i.i.i.i
  %957 = fmul double %add23.i.i.i.i.i382.i.i.i.i, %450
  %958 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i382.i.i.i.i, i32 %div.i.i.i383.i.i.i.i) #3
  %guard.value13 = select i1 %cmp11.i.i.i385.i.i.i.i, double %957, double undef
  %guard.value14 = select i1 %cmp11.i.i.i385.i.i.i.i, double undef, double %958
  br label %merged.bb11

merged.bb10:                                      ; preds = %if.end7.i.i.i386.i.i.i.i
  %959 = fdiv double %add23.i.i.i.i.i382.i.i.i.i, %450
  br label %merged.bb11

merged.bb11:                                      ; preds = %merged.bb10, %merged.bb9
  %960 = phi double [ %guard.value13, %merged.bb9 ], [ %959, %merged.bb10 ]
  %961 = phi double [ %guard.value14, %merged.bb9 ], [ undef, %merged.bb10 ]
  %guess.i.i.i355.i.i.i.i.0 = select i1 %cmp11.i.i.i385.i.i.i.i, double %960, double %961
  %.neg4 = mul nsw i32 %div.i.i.i383.i.i.i.i, -3
  %rem.i.i.i401.i.i.i.i.decomposed = add i32 %.frozen210, 2
  %add.i.i.i402.i.i.i.i = add i32 %rem.i.i.i401.i.i.i.i.decomposed, %.neg4
  %962 = zext i32 %add.i.i.i402.i.i.i.i to i64
  %arrayidx1.i.i.i403.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %962
  %963 = load double, double addrspace(4)* %arrayidx1.i.i.i403.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i404.i.i.i.i = fmul double %guess.i.i.i355.i.i.i.i.0, %963
  %cmp26.i.i.i405.i.i.i.i = icmp slt i32 %441, 1021
  br i1 %cmp26.i.i.i405.i.i.i.i, label %do.body.i.i.i417.i.i.i.i, label %do.body40.i.i.i428.i.i.i.i

merged.bb12:                                      ; preds = %if.end7.i.i.i273.i.i.i.i
  %964 = fmul double %add23.i.i.i.i.i269.i.i.i.i, %588
  %965 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i269.i.i.i.i, i32 %div.i.i.i270.i.i.i.i) #3
  %guard.value16 = select i1 %cmp11.i.i.i272.i.i.i.i, double %964, double undef
  %guard.value17 = select i1 %cmp11.i.i.i272.i.i.i.i, double undef, double %965
  br label %merged.bb14

merged.bb13:                                      ; preds = %if.end7.i.i.i273.i.i.i.i
  %966 = fdiv double %add23.i.i.i.i.i269.i.i.i.i, %588
  br label %merged.bb14

merged.bb14:                                      ; preds = %merged.bb13, %merged.bb12
  %967 = phi double [ %guard.value16, %merged.bb12 ], [ %966, %merged.bb13 ]
  %968 = phi double [ %guard.value17, %merged.bb12 ], [ undef, %merged.bb13 ]
  %guess.i.i.i242.i.i.i.i.0 = select i1 %cmp11.i.i.i272.i.i.i.i, double %967, double %968
  %.neg3 = mul nsw i32 %div.i.i.i270.i.i.i.i, -3
  %rem.i.i.i288.i.i.i.i.decomposed = add i32 %.frozen211, 2
  %add.i.i.i289.i.i.i.i = add i32 %rem.i.i.i288.i.i.i.i.decomposed, %.neg3
  %969 = zext i32 %add.i.i.i289.i.i.i.i to i64
  %arrayidx1.i.i.i290.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %969
  %970 = load double, double addrspace(4)* %arrayidx1.i.i.i290.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i291.i.i.i.i = fmul double %guess.i.i.i242.i.i.i.i.0, %970
  %cmp26.i.i.i292.i.i.i.i = icmp slt i32 %579, 1021
  br i1 %cmp26.i.i.i292.i.i.i.i, label %do.body.i.i.i304.i.i.i.i, label %do.body40.i.i.i315.i.i.i.i

merged.bb15:                                      ; preds = %if.end7.i.i.i192.i.i.i.i
  %971 = fmul double %add23.i.i.i.i.i188.i.i.i.i, %605
  %972 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i188.i.i.i.i, i32 %div.i.i.i189.i.i.i.i) #3
  %guard.value19 = select i1 %cmp11.i.i.i191.i.i.i.i, double %971, double undef
  %guard.value20 = select i1 %cmp11.i.i.i191.i.i.i.i, double undef, double %972
  br label %merged.bb17

merged.bb16:                                      ; preds = %if.end7.i.i.i192.i.i.i.i
  %973 = fdiv double %add23.i.i.i.i.i188.i.i.i.i, %605
  br label %merged.bb17

merged.bb17:                                      ; preds = %merged.bb16, %merged.bb15
  %974 = phi double [ %guard.value19, %merged.bb15 ], [ %973, %merged.bb16 ]
  %975 = phi double [ %guard.value20, %merged.bb15 ], [ undef, %merged.bb16 ]
  %guess.i.i.i161.i.i.i.i.0 = select i1 %cmp11.i.i.i191.i.i.i.i, double %974, double %975
  %.neg2 = mul nsw i32 %div.i.i.i189.i.i.i.i, -3
  %rem.i.i.i207.i.i.i.i.decomposed = add i32 %.frozen212, 2
  %add.i.i.i208.i.i.i.i = add i32 %rem.i.i.i207.i.i.i.i.decomposed, %.neg2
  %976 = zext i32 %add.i.i.i208.i.i.i.i to i64
  %arrayidx1.i.i.i209.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %976
  %977 = load double, double addrspace(4)* %arrayidx1.i.i.i209.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i210.i.i.i.i = fmul double %guess.i.i.i161.i.i.i.i.0, %977
  %cmp26.i.i.i211.i.i.i.i = icmp slt i32 %596, 1021
  br i1 %cmp26.i.i.i211.i.i.i.i, label %do.body.i.i.i223.i.i.i.i, label %do.body40.i.i.i234.i.i.i.i

merged.bb18:                                      ; preds = %if.end4.i.i.i92.i.i.i.i
  %978 = fmul double %add23.i.i.i.i.i107.i.i.i.i, %622
  %979 = tail call double @llvm.amdgcn.ldexp.f64(double %add23.i.i.i.i.i107.i.i.i.i, i32 %div.i.i.i108.i.i.i.i) #3
  %guard.value22 = select i1 %cmp11.i.i.i110.i.i.i.i, double %978, double undef
  %guard.value23 = select i1 %cmp11.i.i.i110.i.i.i.i, double undef, double %979
  br label %merged.bb20

merged.bb19:                                      ; preds = %if.end4.i.i.i92.i.i.i.i
  %980 = fdiv double %add23.i.i.i.i.i107.i.i.i.i, %622
  br label %merged.bb20

merged.bb20:                                      ; preds = %merged.bb19, %merged.bb18
  %981 = phi double [ %guard.value22, %merged.bb18 ], [ %980, %merged.bb19 ]
  %982 = phi double [ %guard.value23, %merged.bb18 ], [ undef, %merged.bb19 ]
  %guess.i.i.i78.i.i.i.i.0 = select i1 %cmp11.i.i.i110.i.i.i.i, double %981, double %982
  %.neg = mul nsw i32 %div.i.i.i108.i.i.i.i, -3
  %rem.i.i.i126.i.i.i.i.decomposed = add i32 %.frozen213, 2
  %add.i.i.i127.i.i.i.i = add i32 %rem.i.i.i126.i.i.i.i.decomposed, %.neg
  %983 = zext i32 %add.i.i.i127.i.i.i.i to i64
  %arrayidx1.i.i.i128.i.i.i.i = getelementptr inbounds [5 x double], [5 x double] addrspace(4)* @_ZZN5boost4math6detail8cbrt_impIdNS0_8policies6policyINS3_14default_policyES5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_S5_EEEET_S7_RKT0_E10correction, i64 0, i64 %983
  %984 = load double, double addrspace(4)* %arrayidx1.i.i.i128.i.i.i.i, align 8, !tbaa !8
  %mul24.i.i.i129.i.i.i.i = fmul double %guess.i.i.i78.i.i.i.i.0, %984
  %cmp26.i.i.i130.i.i.i.i = icmp slt i32 %613, 1021
  br label %merged.bb22

merged.bb:                                        ; preds = %predication.join, %if.end23.i.i.i50.i.i.i.i
  %985 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %1000, %predication.join ]
  %986 = phi double [ %mul24.i.i.i48.i.i.i.i, %if.end23.i.i.i50.i.i.i.i ], [ %999, %predication.join ]
  %merged.select22 = select i1 %cmp26.i.i.i130.i.i.i.i, double %985, double %986
  %987 = fmul double %merged.select22, %merged.select22
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.tail, label %predication.split

predication.split:                                ; preds = %merged.bb
  %988 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %986
  %989 = fsub double %987, %988
  br label %predication.tail

predication.tail:                                 ; preds = %predication.split, %merged.bb
  %merged.select25 = phi double [ %987, %merged.bb ], [ 2.000000e+00, %predication.split ]
  %990 = phi double [ undef, %merged.bb ], [ %989, %predication.split ]
  %991 = fmul double %merged.select22, %merged.select25
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.first, label %predication.second

predication.first:                                ; preds = %predication.tail
  %992 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %991
  %993 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %992
  %994 = fadd double %991, %991
  br label %predication.join

predication.second:                               ; preds = %predication.tail
  %995 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %987
  br label %predication.join

predication.join:                                 ; preds = %predication.second, %predication.first
  %merged.select28 = phi double [ %993, %predication.first ], [ %990, %predication.second ]
  %merged.select26 = phi double [ %z.addr.i.i.i76.i.i.i.i.0, %predication.first ], [ %991, %predication.second ]
  %guard.result = phi double [ %994, %predication.first ], [ %995, %predication.second ]
  %996 = fadd double %merged.select26, %guard.result
  %997 = fdiv double %merged.select28, %996
  %998 = fsub double %986, %997
  %999 = select i1 %cmp26.i.i.i130.i.i.i.i, double undef, double %998
  %merged.select29 = select i1 %cmp26.i.i.i130.i.i.i.i, double %985, double %998
  %merged.select30 = select i1 %cmp26.i.i.i130.i.i.i.i, double %997, double 0x3EC0000000000000
  %1000 = fmul double %merged.select29, %merged.select30
  %1001 = fsub double 1.000000e+00, %997
  %merged.select31 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1001, double %997
  %1002 = tail call double @llvm.fabs.f64(double %merged.select31) #3
  %1003 = fcmp ogt double %1002, 0x3EC0000000000000
  %1004 = fcmp olt double %1000, %1002
  %guard.result45 = select i1 %cmp26.i.i.i130.i.i.i.i, i1 %1003, i1 %1004
  br i1 %guard.result45, label %merged.bb, label %merged.bb21

merged.bb21:                                      ; preds = %predication.join
  %guess.i.i.i10.i.i.i.i.3 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1000, double %998
  %1005 = fneg double %guess.i.i.i10.i.i.i.i.3
  %1006 = select i1 %cmp5.i.i.i91.i.i.i.i, double %1005, double %guess.i.i.i10.i.i.i.i.3
  br label %if.end7.i.i.i.i.i.i.i

merged.bb73:                                      ; preds = %decision.dispatch1
  %1007 = insertelement <2 x double> undef, double %746, i32 0
  %1008 = insertelement <2 x double> %1007, double %748, i32 1
  %1009 = insertelement <2 x double> undef, double %752, i32 0
  %1010 = insertelement <2 x double> %1009, double %753, i32 1
  %1011 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1008, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1010) #3
  %1012 = extractelement <2 x double> %1011, i32 0
  %1013 = extractelement <2 x double> %1011, i32 1
  br label %merged.bb75

merged.bb74:                                      ; preds = %decision.dispatch1
  %1014 = insertelement <2 x double> undef, double %746, i32 0
  %1015 = insertelement <2 x double> %1014, double %748, i32 1
  %1016 = insertelement <2 x double> undef, double %752, i32 0
  %1017 = insertelement <2 x double> %1016, double %753, i32 1
  %1018 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %1015, <2 x double> <double 0x3FF71547652B82FE, double 0x3FF71547652B82FE>, <2 x double> %1017) #3
  %1019 = extractelement <2 x double> %1018, i32 0
  %1020 = extractelement <2 x double> %1018, i32 1
  br label %merged.bb75

merged.bb75:                                      ; preds = %merged.bb74, %merged.bb73
  %1021 = phi double [ %1012, %merged.bb73 ], [ %1019, %merged.bb74 ]
  %1022 = phi double [ %1013, %merged.bb73 ], [ %1020, %merged.bb74 ]
  %1023 = phi double [ 0x3D5866A3E6D0F156, %merged.bb73 ], [ 0x3CED1FCD2AD8841F, %merged.bb74 ]
  %1024 = phi double [ 0xBE9C2F1FFD2FFECD, %merged.bb73 ], [ 0xBE512769C01EA7C5, %merged.bb74 ]
  %1025 = phi double [ 0x3E1390C28573DB0F, %merged.bb73 ], [ 0x3DB79116B58241AA, %merged.bb74 ]
  %1026 = phi double [ 0xBF0B3634004E0F5C, %merged.bb73 ], [ 0xBED0C1E92AD969EF, %merged.bb74 ]
  %1027 = phi double [ 0xBF676495E4B7EAAA, %merged.bb73 ], [ 0xBF3D2E78945F9AC6, %merged.bb74 ]
  %1028 = phi double [ 0xBFB3B5B6F694BB9E, %merged.bb73 ], [ 0xBF98ED20B1D6A6D8, %merged.bb74 ]
  %1029 = phi double [ 0xBFEFD66AE54A0BCB, %merged.bb73 ], [ 0xBFE46D859460DB51, %merged.bb74 ]
  %1030 = phi double [ 0xC013B000D66B8269, %merged.bb73 ], [ 0xC019A861C808DCFC, %merged.bb74 ]
  %1031 = phi double [ 0x3DCCD7C812F40049, %merged.bb73 ], [ 0x3D6B7BD497A2CD17, %merged.bb74 ]
  %1032 = phi double [ 0x3ED66AFC954DE682, %merged.bb73 ], [ 0x3E95BA568EDD3BFB, %merged.bb74 ]
  %1033 = phi double [ 0x3E6129D961D79065, %merged.bb73 ], [ 0x3E107ECF99D6009A, %merged.bb74 ]
  %1034 = phi double [ 0x3F380B62C1407B15, %merged.bb73 ], [ 0x3F077F4625619D43, %merged.bb74 ]
  %1035 = phi double [ 0x3F882FD20DA34F30, %merged.bb73 ], [ 0x3F67D3564F778B21, %merged.bb74 ]
  %1036 = phi double [ 0x3FC6B0CE3157BCB1, %merged.bb73 ], [ 0x3FB68627D1A51CB5, %merged.bb74 ]
  %1037 = phi double [ 0x3E32022ABCFF5DE7, %merged.bb73 ], [ 0x3DC4C8BD76453064, %merged.bb74 ]
  %1038 = phi double [ 0xBF336C13BBA203F3, %merged.bb73 ], [ 0xBEE755F1646665DB, %merged.bb74 ]
  %1039 = phi double [ 0x3ECBFD524C94F258, %merged.bb73 ], [ 0x3E70731CF2A765F0, %merged.bb74 ]
  %1040 = phi double [ 0xBF81F96D17A7115B, %merged.bb73 ], [ 0xBF4625660A41D7B1, %merged.bb74 ]
  %1041 = phi double [ 0xBFBD7935AC58B5B5, %merged.bb73 ], [ 0xBF92AE2345C460A0, %merged.bb74 ]
  %1042 = phi double [ 0xBFE78F054AC7A90B, %merged.bb73 ], [ 0xBFCED54905311121, %merged.bb74 ]
  %1043 = phi double [ 0xC001F1CD6A03BCAA, %merged.bb73 ], [ 0xBFF8595CA25899FD, %merged.bb74 ]
  %1044 = phi double [ 0xC004C929A952DE48, %merged.bb73 ], [ 0xC00D636ADAEC3C05, %merged.bb74 ]
  %1045 = phi double [ 0x3E9090FBB4B042AE, %merged.bb73 ], [ 0x3E2EB2F3F6504F32, %merged.bb74 ]
  %1046 = phi double [ 0x3F586FC94B9EAD30, %merged.bb73 ], [ 0x3F1751EF5755C229, %merged.bb74 ]
  %1047 = phi double [ 0x3F0330822740ADF9, %merged.bb73 ], [ 0x3EB20E304F6E5BCE, %merged.bb74 ]
  %1048 = phi double [ 0x3F999857B526C821, %merged.bb73 ], [ 0x3F68BF137C253BD1, %merged.bb74 ]
  %1049 = phi double [ 0x3FC92E7DCCD1B70C, %merged.bb73 ], [ 0x3FA8A45F1AE4ADBE, %merged.bb74 ]
  %1050 = phi double [ 0x3FE7235AE26E3A60, %merged.bb73 ], [ 0x3FD6E5B7AB236028, %merged.bb74 ]
  %1051 = phi double [ 0x3BAA9A26E0297ED8, %merged.bb73 ], [ 0x3B408480D3491A50, %merged.bb74 ]
  %1052 = phi double [ 0xBD7021DF3392EE60, %merged.bb73 ], [ 0xBD241E51766A91FB, %merged.bb74 ]
  %1053 = phi double [ 0x3CA5D280D4B5A285, %merged.bb73 ], [ 0x3C4B275AC5F91B68, %merged.bb74 ]
  %1054 = phi double [ 0xBE2007A65CA14E38, %merged.bb73 ], [ 0xBDE40A018263D493, %merged.bb74 ]
  %1055 = phi double [ 0xBEBC6E261AE99633, %merged.bb73 ], [ 0xBE91D0F7FEBA5A35, %merged.bb74 ]
  %1056 = phi double [ 0xBF48C2CA21FD14A5, %merged.bb73 ], [ 0xBF2F1E266EB4C824, %merged.bb74 ]
  %1057 = phi double [ 0xBFC4B5F131A679CC, %merged.bb73 ], [ 0xBFBA19EDB555D8AD, %merged.bb74 ]
  %1058 = phi double [ 0xC02A92BAF87A7B72, %merged.bb73 ], [ 0xC030CB31255FFA09, %merged.bb74 ]
  %1059 = phi double [ 0x3C495387D39D2504, %merged.bb73 ], [ 0x3BE8FEBB5A4047D7, %merged.bb74 ]
  %1060 = phi double [ 0x3DD49301DA58AEFA, %merged.bb73 ], [ 0x3D9463E48A976F97, %merged.bb74 ]
  %1061 = phi double [ 0x3D1ED0326F0CBDDC, %merged.bb73 ], [ 0x3CCE78F4A7F13C7D, %merged.bb74 ]
  %1062 = phi double [ 0x3E768F19E4302EF3, %merged.bb73 ], [ 0x3E46680C94743FD9, %merged.bb74 ]
  %1063 = phi double [ 0x3F0730EC426E6E84, %merged.bb73 ], [ 0x3EE71602E8EA99F3, %merged.bb74 ]
  %1064 = phi double [ 0x3F86397D81A61D6E, %merged.bb73 ], [ 0x3F762C8C65771E78, %merged.bb74 ]
  %1065 = phi double [ 0x3C819FA1E5E36C20, %merged.bb73 ], [ 0x3C158FD8B3C1B0C0, %merged.bb74 ]
  %1066 = phi double [ 0xBE050B1B8007F8FF, %merged.bb73 ], [ 0xBDB9FC7E20BD04CC, %merged.bb74 ]
  %1067 = phi double [ 0x3D5CB3C39661DD79, %merged.bb73 ], [ 0x3D01A287ED1019B8, %merged.bb74 ]
  %1068 = phi double [ 0xBE94B8A80FB81310, %merged.bb73 ], [ 0xBE59BA2A0439E4A9, %merged.bb74 ]
  %1069 = phi double [ 0xBF1232A95F4E8466, %merged.bb73 ], [ 0xBEE6B9C7BCE39403, %merged.bb74 ]
  %1070 = phi double [ 0xBF7F5FDEC6827012, %merged.bb73 ], [ 0xBF63B612102F3C24, %merged.bb74 ]
  %1071 = phi double [ 0xBFD9F6368DFEFDDF, %merged.bb73 ], [ 0xBFD06A8AF4A3FC55, %merged.bb74 ]
  %1072 = phi double [ 0xC0207852FA1731C0, %merged.bb73 ], [ 0xC024F817DD06EE79, %merged.bb74 ]
  %1073 = phi double [ 0x3D0A81E9CB6A1EA5, %merged.bb73 ], [ 0x3CA9D032740CF69A, %merged.bb74 ]
  %1074 = phi double [ 0x3E553724D72BE5C7, %merged.bb73 ], [ 0x3E14D76BE5BA042B, %merged.bb74 ]
  %1075 = phi double [ 0x3DC001D96C7E2C9D, %merged.bb73 ], [ 0x3D6F4FAB0C90F842, %merged.bb74 ]
  %1076 = phi double [ 0x3ED71590B83839D8, %merged.bb73 ], [ 0x3EA6C7746378848A, %merged.bb74 ]
  %1077 = phi double [ 0x3F478C82425FFDCE, %merged.bb73 ], [ 0x3F275783E6F9B4DA, %merged.bb74 ]
  %1078 = phi double [ 0x3FA66506CA3FCEB3, %merged.bb73 ], [ 0x3F964BEF3074CF28, %merged.bb74 ]
  br i1 %656, label %merged.bb70, label %merged.branch.split83

merged.branch.split83:                            ; preds = %merged.bb75
  br label %merged.bb70

merged.bb22:                                      ; preds = %predication.join44, %merged.bb20
  %1079 = phi double [ %mul24.i.i.i129.i.i.i.i, %merged.bb20 ], [ %1094, %predication.join44 ]
  %1080 = phi double [ %mul24.i.i.i129.i.i.i.i, %merged.bb20 ], [ %1093, %predication.join44 ]
  %merged.select = select i1 %cmp26.i.i.i130.i.i.i.i, double %1079, double %1080
  %1081 = fmul double %merged.select, %merged.select
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.tail41, label %predication.split40

predication.split40:                              ; preds = %merged.bb22
  %1082 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %1080
  %1083 = fsub double %1081, %1082
  br label %predication.tail41

predication.tail41:                               ; preds = %predication.split40, %merged.bb22
  %merged.select32 = phi double [ %1081, %merged.bb22 ], [ 2.000000e+00, %predication.split40 ]
  %1084 = phi double [ undef, %merged.bb22 ], [ %1083, %predication.split40 ]
  %1085 = fmul double %merged.select, %merged.select32
  br i1 %cmp26.i.i.i130.i.i.i.i, label %predication.first42, label %predication.second43

predication.first42:                              ; preds = %predication.tail41
  %1086 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %1085
  %1087 = fadd double %z.addr.i.i.i76.i.i.i.i.0, %1086
  %1088 = fadd double %1085, %1085
  br label %predication.join44

predication.second43:                             ; preds = %predication.tail41
  %1089 = fdiv double %z.addr.i.i.i76.i.i.i.i.0, %1081
  br label %predication.join44

predication.join44:                               ; preds = %predication.second43, %predication.first42
  %merged.select35 = phi double [ %1087, %predication.first42 ], [ %1084, %predication.second43 ]
  %merged.select33 = phi double [ %z.addr.i.i.i76.i.i.i.i.0, %predication.first42 ], [ %1085, %predication.second43 ]
  %guard.result48 = phi double [ %1088, %predication.first42 ], [ %1089, %predication.second43 ]
  %1090 = fadd double %merged.select33, %guard.result48
  %1091 = fdiv double %merged.select35, %1090
  %1092 = fsub double %1080, %1091
  %1093 = select i1 %cmp26.i.i.i130.i.i.i.i, double undef, double %1092
  %merged.select36 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1079, double %1092
  %merged.select37 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1091, double 0x3EC0000000000000
  %1094 = fmul double %merged.select36, %merged.select37
  %1095 = fsub double 1.000000e+00, %1091
  %merged.select38 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1095, double %1091
  %1096 = tail call double @llvm.fabs.f64(double %merged.select38) #3
  %1097 = fcmp ogt double %1096, 0x3EC0000000000000
  %1098 = fcmp olt double %1094, %1096
  %guard.result58 = select i1 %cmp26.i.i.i130.i.i.i.i, i1 %1097, i1 %1098
  br i1 %guard.result58, label %merged.bb22, label %merged.bb23

merged.bb23:                                      ; preds = %predication.join44
  %guess.i.i.i78.i.i.i.i.3 = select i1 %cmp26.i.i.i130.i.i.i.i, double %1094, double %1092
  %1099 = fneg double %guess.i.i.i78.i.i.i.i.3
  %1100 = select i1 %cmp5.i.i.i91.i.i.i.i, double %1099, double %guess.i.i.i78.i.i.i.i.3
  br i1 %cmp11.i.i.i110.i.i.i.i, label %if.then12.i.i.i32.i.i.i.i, label %if.else21.i.i.i44.i.i.i.i
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.frexp.exp.i32.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.frexp.mant.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i1 @llvm.amdgcn.class.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.ldexp.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rcp.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fma.v2f64(<2 x double>, <2 x double>, <2 x double>) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.abs.i32(i32, i1 immarg) #1

attributes #0 = { nofree norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="128" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }
attributes #4 = { nounwind readnone }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"clang version 12.0.0 (https://github.com/charitha22/cgo22ae-darm-code.git e9bc0540325ad9806313d34e84fc901496fd8be6)"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i16 1, i16 1025}
!6 = !{}
!7 = !{i32 0, i32 1024}
!8 = !{!9, !9, i64 0}
!9 = !{!"double", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = !{!"evaluate:%if.then14.i.i.i37.i.i.i.i", !"evaluate:%if.else.i.i.i43.i.i.i.i"}
!13 = !{!"merge(evaluate:%if.then14.i.i.i37.i.i.i.i,evaluate:%if.else.i.i.i43.i.i.i.i)"}
