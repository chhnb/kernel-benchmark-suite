; ModuleID = 'cases/ced/source/native.hip'
source_filename = "cases/ced/source/native.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7"
target triple = "amdgcn-amd-amdhsa"

@l_mem = external hidden local_unnamed_addr addrspace(3) global [0 x i32], align 4

; Function Attrs: convergent norecurse nounwind willreturn mustprogress
define protected amdgpu_kernel void @_Z19non_max_supp_kernelPKhPhS0_ii(i8 addrspace(1)* noalias nocapture readonly %0, i8 addrspace(1)* noalias nocapture %1, i8 addrspace(1)* noalias nocapture readonly %2, i32 %3, i32 %4) local_unnamed_addr #0 {
  %6 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %7 = getelementptr inbounds i8, i8 addrspace(4)* %6, i64 4
  %8 = bitcast i8 addrspace(4)* %7 to i16 addrspace(4)*
  %9 = load i16, i16 addrspace(4)* %8, align 4, !tbaa !3
  %10 = zext i16 %9 to i32
  %11 = getelementptr inbounds i8, i8 addrspace(4)* %6, i64 6
  %12 = bitcast i8 addrspace(4)* %11 to i16 addrspace(4)*
  %13 = load i16, i16 addrspace(4)* %12, align 2, !tbaa !3
  %14 = zext i16 %13 to i32
  %15 = tail call i32 @llvm.amdgcn.workitem.id.y(), !range !7
  %16 = add nuw nsw i32 %15, 1
  %17 = tail call i32 @llvm.amdgcn.workitem.id.x(), !range !7
  %18 = add nuw nsw i32 %17, 1
  %19 = tail call i32 @llvm.amdgcn.workgroup.id.y()
  %20 = mul i32 %19, %14
  %21 = add i32 %20, %16
  %22 = tail call i32 @llvm.amdgcn.workgroup.id.x()
  %23 = mul i32 %22, %10
  %24 = add i32 %23, %18
  %25 = mul nsw i32 %21, %4
  %26 = add nsw i32 %24, %25
  %27 = sext i32 %26 to i64
  %28 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %27
  %29 = load i8, i8 addrspace(1)* %28, align 1, !tbaa !8
  %30 = zext i8 %29 to i32
  %31 = add nuw nsw i32 %10, 2
  %32 = mul nuw nsw i32 %31, %16
  %33 = add nuw nsw i32 %32, %18
  %34 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %33
  store i32 %30, i32 addrspace(3)* %34, align 4, !tbaa !9
  %35 = icmp eq i32 %15, 0
  br i1 %35, label %36, label %60

36:                                               ; preds = %5
  %37 = sub nsw i32 %26, %4
  %38 = sext i32 %37 to i64
  %39 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %38
  %40 = load i8, i8 addrspace(1)* %39, align 1, !tbaa !8
  %41 = zext i8 %40 to i32
  %42 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %18
  store i32 %41, i32 addrspace(3)* %42, align 4, !tbaa !9
  %43 = icmp eq i32 %17, 0
  br i1 %43, label %44, label %50

44:                                               ; preds = %36
  %45 = add nsw i32 %37, -1
  %46 = sext i32 %45 to i64
  %47 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %46
  %48 = load i8, i8 addrspace(1)* %47, align 1, !tbaa !8
  %49 = zext i8 %48 to i32
  store i32 %49, i32 addrspace(3)* getelementptr inbounds ([0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 0), align 4, !tbaa !9
  br label %90

50:                                               ; preds = %36
  %51 = icmp eq i32 %18, %10
  br i1 %51, label %52, label %90

52:                                               ; preds = %50
  %53 = add nuw nsw i32 %10, 1
  %54 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %53
  %55 = add nsw i32 %37, 1
  %56 = sext i32 %55 to i64
  %57 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %56
  %58 = load i8, i8 addrspace(1)* %57, align 1, !tbaa !8
  %59 = zext i8 %58 to i32
  store i32 %59, i32 addrspace(3)* %54, align 4, !tbaa !9
  br label %90

60:                                               ; preds = %5
  %61 = icmp eq i32 %16, %10
  br i1 %61, label %62, label %90

62:                                               ; preds = %60
  %63 = add nsw i32 %26, %4
  %64 = sext i32 %63 to i64
  %65 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %64
  %66 = load i8, i8 addrspace(1)* %65, align 1, !tbaa !8
  %67 = zext i8 %66 to i32
  %68 = add nuw nsw i32 %10, 1
  %69 = mul nsw i32 %68, %31
  %70 = add nuw nsw i32 %69, %18
  %71 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %70
  store i32 %67, i32 addrspace(3)* %71, align 4, !tbaa !9
  %72 = icmp eq i32 %17, 0
  br i1 %72, label %73, label %80

73:                                               ; preds = %62
  %74 = add nsw i32 %63, -1
  %75 = sext i32 %74 to i64
  %76 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %75
  %77 = load i8, i8 addrspace(1)* %76, align 1, !tbaa !8
  %78 = zext i8 %77 to i32
  %79 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %69
  store i32 %78, i32 addrspace(3)* %79, align 4, !tbaa !9
  br label %90

80:                                               ; preds = %62
  %81 = icmp eq i32 %18, %10
  br i1 %81, label %82, label %90

82:                                               ; preds = %80
  %83 = add nuw nsw i32 %69, %68
  %84 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %83
  %85 = add nsw i32 %63, 1
  %86 = sext i32 %85 to i64
  %87 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %86
  %88 = load i8, i8 addrspace(1)* %87, align 1, !tbaa !8
  %89 = zext i8 %88 to i32
  store i32 %89, i32 addrspace(3)* %84, align 4, !tbaa !9
  br label %90

90:                                               ; preds = %60, %80, %82, %73, %44, %52, %50
  %91 = icmp eq i32 %17, 0
  br i1 %91, label %92, label %99

92:                                               ; preds = %90
  %93 = add nsw i32 %26, -1
  %94 = sext i32 %93 to i64
  %95 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %94
  %96 = load i8, i8 addrspace(1)* %95, align 1, !tbaa !8
  %97 = zext i8 %96 to i32
  %98 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %32
  store i32 %97, i32 addrspace(3)* %98, align 4, !tbaa !9
  br label %110

99:                                               ; preds = %90
  %100 = icmp eq i32 %18, %10
  br i1 %100, label %101, label %110

101:                                              ; preds = %99
  %102 = add nuw nsw i32 %10, 1
  %103 = add nuw nsw i32 %102, %32
  %104 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %103
  %105 = add nsw i32 %26, 1
  %106 = sext i32 %105 to i64
  %107 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %106
  %108 = load i8, i8 addrspace(1)* %107, align 1, !tbaa !8
  %109 = zext i8 %108 to i32
  store i32 %109, i32 addrspace(3)* %104, align 4, !tbaa !9
  br label %110

110:                                              ; preds = %92, %101, %99
  fence syncscope("workgroup") seq_cst
  tail call void @llvm.amdgcn.s.barrier()
  fence syncscope("workgroup") seq_cst
  %111 = load i32, i32 addrspace(3)* %34, align 4, !tbaa !9
  %112 = trunc i32 %111 to i8
  %113 = getelementptr inbounds i8, i8 addrspace(1)* %2, i64 %27
  %114 = load i8, i8 addrspace(1)* %113, align 1, !tbaa !8
  switch i8 %114, label %174 [
    i8 0, label %115
    i8 45, label %127
    i8 90, label %143
    i8 -121, label %158
  ]

115:                                              ; preds = %110
  %116 = and i32 %111, 255
  %117 = add nuw nsw i32 %33, 1
  %118 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %117
  %119 = load i32, i32 addrspace(3)* %118, align 4, !tbaa !9
  %120 = icmp sgt i32 %116, %119
  br i1 %120, label %121, label %174

121:                                              ; preds = %115
  %122 = add nuw nsw i32 %32, %17
  %123 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %122
  %124 = load i32, i32 addrspace(3)* %123, align 4, !tbaa !9
  %125 = icmp sgt i32 %116, %124
  %126 = select i1 %125, i8 %112, i8 0
  br label %174

127:                                              ; preds = %110
  %128 = and i32 %111, 255
  %129 = mul nuw nsw i32 %31, %15
  %130 = add nuw nsw i32 %17, 2
  %131 = add nuw nsw i32 %130, %129
  %132 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %131
  %133 = load i32, i32 addrspace(3)* %132, align 4, !tbaa !9
  %134 = icmp sgt i32 %128, %133
  br i1 %134, label %135, label %174

135:                                              ; preds = %127
  %136 = add nuw nsw i32 %15, 2
  %137 = mul nuw nsw i32 %31, %136
  %138 = add nuw nsw i32 %137, %17
  %139 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %138
  %140 = load i32, i32 addrspace(3)* %139, align 4, !tbaa !9
  %141 = icmp sgt i32 %128, %140
  %142 = select i1 %141, i8 %112, i8 0
  br label %174

143:                                              ; preds = %110
  %144 = and i32 %111, 255
  %145 = mul nuw nsw i32 %31, %15
  %146 = add nuw nsw i32 %145, %18
  %147 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %146
  %148 = load i32, i32 addrspace(3)* %147, align 4, !tbaa !9
  %149 = icmp sgt i32 %144, %148
  br i1 %149, label %150, label %174

150:                                              ; preds = %143
  %151 = add nuw nsw i32 %15, 2
  %152 = mul nuw nsw i32 %31, %151
  %153 = add nuw nsw i32 %152, %18
  %154 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %153
  %155 = load i32, i32 addrspace(3)* %154, align 4, !tbaa !9
  %156 = icmp sgt i32 %144, %155
  %157 = select i1 %156, i8 %112, i8 0
  br label %174

158:                                              ; preds = %110
  %159 = and i32 %111, 255
  %160 = mul nuw nsw i32 %31, %15
  %161 = add nuw nsw i32 %160, %17
  %162 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %161
  %163 = load i32, i32 addrspace(3)* %162, align 4, !tbaa !9
  %164 = icmp sgt i32 %159, %163
  br i1 %164, label %165, label %174

165:                                              ; preds = %158
  %166 = add nuw nsw i32 %15, 2
  %167 = mul nuw nsw i32 %31, %166
  %168 = add nuw nsw i32 %17, 2
  %169 = add nuw nsw i32 %168, %167
  %170 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %169
  %171 = load i32, i32 addrspace(3)* %170, align 4, !tbaa !9
  %172 = icmp sgt i32 %159, %171
  %173 = select i1 %172, i8 %112, i8 0
  br label %174

174:                                              ; preds = %165, %150, %135, %121, %110, %158, %143, %127, %115
  %175 = phi i8 [ 0, %115 ], [ 0, %127 ], [ 0, %143 ], [ 0, %158 ], [ %112, %110 ], [ %126, %121 ], [ %142, %135 ], [ %157, %150 ], [ %173, %165 ]
  %176 = getelementptr inbounds i8, i8 addrspace(1)* %1, i64 %27
  store i8 %175, i8 addrspace(1)* %176, align 1, !tbaa !8
  ret void
}

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.y() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.y() #1

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #1

attributes #0 = { convergent norecurse nounwind willreturn mustprogress "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nounwind readnone speculatable willreturn }
attributes #2 = { convergent nounwind willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!3 = !{!4, !4, i64 0}
!4 = !{!"short", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C++ TBAA"}
!7 = !{i32 0, i32 1024}
!8 = !{!5, !5, i64 0}
!9 = !{!10, !10, i64 0}
!10 = !{!"int", !5, i64 0}
