; ModuleID = '/data/home/chh/simplify-v2/build/b2b-layouts/anchor-ablation/heldout/CED/active/trial-6/fused.ll'
source_filename = "cases/ced/source/native.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7"
target triple = "amdgcn-amd-amdhsa"

@l_mem = external hidden local_unnamed_addr addrspace(3) global [0 x i32], align 4

; Function Attrs: convergent norecurse nounwind willreturn mustprogress
define protected amdgpu_kernel void @_Z19non_max_supp_kernelPKhPhS0_ii(i8 addrspace(1)* noalias nocapture readonly %0, i8 addrspace(1)* noalias nocapture %1, i8 addrspace(1)* noalias nocapture readonly %2, i32 %3, i32 %4) local_unnamed_addr #0 {
  %6 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %7 = getelementptr inbounds i8, i8 addrspace(4)* %6, i64 4
  %8 = bitcast i8 addrspace(4)* %7 to i16 addrspace(4)*
  %9 = load i16, i16 addrspace(4)* %8, align 4, !tbaa !3
  %10 = zext i16 %9 to i32
  %11 = getelementptr inbounds i8, i8 addrspace(4)* %6, i64 6
  %12 = bitcast i8 addrspace(4)* %11 to i16 addrspace(4)*
  %13 = load i16, i16 addrspace(4)* %12, align 2, !tbaa !3
  %14 = zext i16 %13 to i32
  %15 = tail call i32 @llvm.amdgcn.workitem.id.y(), !range !7
  %16 = add nuw nsw i32 %15, 1
  %17 = tail call i32 @llvm.amdgcn.workitem.id.x(), !range !7
  %18 = add nuw nsw i32 %17, 1
  %19 = tail call i32 @llvm.amdgcn.workgroup.id.y()
  %20 = mul i32 %19, %14
  %21 = add i32 %20, %16
  %22 = tail call i32 @llvm.amdgcn.workgroup.id.x()
  %23 = mul i32 %22, %10
  %24 = add i32 %23, %18
  %25 = mul nsw i32 %21, %4
  %26 = add nsw i32 %24, %25
  %27 = sext i32 %26 to i64
  %28 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %27
  %29 = load i8, i8 addrspace(1)* %28, align 1, !tbaa !8
  %30 = zext i8 %29 to i32
  %31 = add nuw nsw i32 %10, 2
  %32 = mul nuw nsw i32 %31, %16
  %33 = add nuw nsw i32 %32, %18
  %34 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %33
  store i32 %30, i32 addrspace(3)* %34, align 4, !tbaa !9
  %35 = icmp eq i32 %15, 0
  %36 = icmp eq i32 %16, %10
  %decision.take = or i1 %35, %36
  br i1 %decision.take, label %merged.bb, label %.pair.join, !decision.condition_prefix !11

.pair.join:                                       ; preds = %leaf.union, %merged.bb, %5
  %37 = icmp eq i32 %17, 0
  %38 = icmp eq i32 %18, %10
  %leaf.enter2 = or i1 %37, %38
  br i1 %leaf.enter2, label %leaf.union1, label %49, !fusion.logical.arm !12

leaf.union1:                                      ; preds = %.pair.join
  %39 = select i1 %37, i32 -1, i32 1
  %40 = add nsw i32 %26, %39
  %41 = sext i32 %40 to i64
  %42 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %41
  %43 = load i8, i8 addrspace(1)* %42, align 1, !tbaa !8
  %44 = zext i8 %43 to i32
  %45 = add nuw nsw i32 %10, 1
  %46 = select i1 %37, i32 0, i32 %45
  %47 = add nuw nsw i32 %32, %46
  %48 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %47
  store i32 %44, i32 addrspace(3)* %48, align 4, !tbaa !9
  br label %49

49:                                               ; preds = %leaf.union1, %.pair.join
  fence syncscope("workgroup") seq_cst
  tail call void @llvm.amdgcn.s.barrier()
  fence syncscope("workgroup") seq_cst
  %50 = load i32, i32 addrspace(3)* %34, align 4, !tbaa !9
  %51 = trunc i32 %50 to i8
  %52 = getelementptr inbounds i8, i8 addrspace(1)* %2, i64 %27
  %53 = load i8, i8 addrspace(1)* %52, align 1, !tbaa !8
  switch i8 %53, label %113 [
    i8 0, label %54
    i8 45, label %66
    i8 90, label %82
    i8 -121, label %97
  ]

54:                                               ; preds = %49
  %55 = and i32 %50, 255
  %56 = add nuw nsw i32 %33, 1
  %57 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %56
  %58 = load i32, i32 addrspace(3)* %57, align 4, !tbaa !9
  %59 = icmp sgt i32 %55, %58
  br i1 %59, label %60, label %113

60:                                               ; preds = %54
  %61 = add nuw nsw i32 %32, %17
  %62 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %61
  %63 = load i32, i32 addrspace(3)* %62, align 4, !tbaa !9
  %64 = icmp sgt i32 %55, %63
  %65 = select i1 %64, i8 %51, i8 0
  br label %113

66:                                               ; preds = %49
  %67 = and i32 %50, 255
  %68 = mul nuw nsw i32 %31, %15
  %69 = add nuw nsw i32 %17, 2
  %70 = add nuw nsw i32 %69, %68
  %71 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %70
  %72 = load i32, i32 addrspace(3)* %71, align 4, !tbaa !9
  %73 = icmp sgt i32 %67, %72
  br i1 %73, label %74, label %113

74:                                               ; preds = %66
  %75 = add nuw nsw i32 %15, 2
  %76 = mul nuw nsw i32 %31, %75
  %77 = add nuw nsw i32 %76, %17
  %78 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %77
  %79 = load i32, i32 addrspace(3)* %78, align 4, !tbaa !9
  %80 = icmp sgt i32 %67, %79
  %81 = select i1 %80, i8 %51, i8 0
  br label %113

82:                                               ; preds = %49
  %83 = and i32 %50, 255
  %84 = mul nuw nsw i32 %31, %15
  %85 = add nuw nsw i32 %84, %18
  %86 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %85
  %87 = load i32, i32 addrspace(3)* %86, align 4, !tbaa !9
  %88 = icmp sgt i32 %83, %87
  br i1 %88, label %89, label %113

89:                                               ; preds = %82
  %90 = add nuw nsw i32 %15, 2
  %91 = mul nuw nsw i32 %31, %90
  %92 = add nuw nsw i32 %91, %18
  %93 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %92
  %94 = load i32, i32 addrspace(3)* %93, align 4, !tbaa !9
  %95 = icmp sgt i32 %83, %94
  %96 = select i1 %95, i8 %51, i8 0
  br label %113

97:                                               ; preds = %49
  %98 = and i32 %50, 255
  %99 = mul nuw nsw i32 %31, %15
  %100 = add nuw nsw i32 %99, %17
  %101 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %100
  %102 = load i32, i32 addrspace(3)* %101, align 4, !tbaa !9
  %103 = icmp sgt i32 %98, %102
  br i1 %103, label %104, label %113

104:                                              ; preds = %97
  %105 = add nuw nsw i32 %15, 2
  %106 = mul nuw nsw i32 %31, %105
  %107 = add nuw nsw i32 %17, 2
  %108 = add nuw nsw i32 %107, %106
  %109 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %108
  %110 = load i32, i32 addrspace(3)* %109, align 4, !tbaa !9
  %111 = icmp sgt i32 %98, %110
  %112 = select i1 %111, i8 %51, i8 0
  br label %113

113:                                              ; preds = %104, %97, %89, %82, %74, %66, %60, %54, %49
  %114 = phi i8 [ %51, %49 ], [ 0, %54 ], [ %65, %60 ], [ 0, %66 ], [ %81, %74 ], [ 0, %82 ], [ %96, %89 ], [ 0, %97 ], [ %112, %104 ]
  %115 = getelementptr inbounds i8, i8 addrspace(1)* %1, i64 %27
  store i8 %114, i8 addrspace(1)* %115, align 1, !tbaa !8
  ret void

merged.bb:                                        ; preds = %5
  %116 = sub i32 0, %4
  %guard.result.p = select i1 %35, i32 %116, i32 %4
  %guard.result = add i32 %26, %guard.result.p
  %117 = sext i32 %guard.result to i64
  %118 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %117
  %119 = load i8, i8 addrspace(1)* %118, align 1, !tbaa !8
  %120 = zext i8 %119 to i32
  %121 = add nuw nsw i32 %10, 1
  %122 = mul nsw i32 %121, %31
  %123 = select i1 %35, i32 0, i32 %122
  %merged.select6 = add nuw nsw i32 %18, %123
  %124 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %merged.select6
  store i32 %120, i32 addrspace(3)* %124, align 4, !tbaa !9
  %125 = icmp eq i32 %17, 0
  %126 = icmp eq i32 %18, %10
  %leaf.enter = or i1 %125, %126
  br i1 %leaf.enter, label %leaf.union, label %.pair.join, !fusion.logical.arm !13

leaf.union:                                       ; preds = %merged.bb
  %127 = select i1 %125, i32 undef, i32 %10
  %128 = select i1 %35, i32 %127, i32 %122
  %129 = select i1 %125, i32 -1, i32 1
  %130 = add nsw i32 %guard.result, %129
  %131 = sext i32 %130 to i64
  %132 = getelementptr inbounds i8, i8 addrspace(1)* %0, i64 %131
  %133 = load i8, i8 addrspace(1)* %132, align 1, !tbaa !8
  %134 = zext i8 %133 to i32
  %135 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %128
  %136 = select i1 %35, i32 addrspace(3)* getelementptr inbounds ([0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 0), i32 addrspace(3)* %135
  %137 = select i1 %35, i32 1, i32 %121
  %138 = add nuw nsw i32 %128, %137
  %139 = getelementptr inbounds [0 x i32], [0 x i32] addrspace(3)* @l_mem, i32 0, i32 %138
  %fusion.paired = select i1 %125, i32 addrspace(3)* %136, i32 addrspace(3)* %139
  store i32 %134, i32 addrspace(3)* %fusion.paired, align 4, !tbaa !9
  br label %.pair.join
}

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.y() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.y() #1

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #1

attributes #0 = { convergent norecurse nounwind willreturn mustprogress "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nounwind readnone speculatable willreturn }
attributes #2 = { convergent nounwind willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!3 = !{!4, !4, i64 0}
!4 = !{!"short", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C++ TBAA"}
!7 = !{i32 0, i32 1024}
!8 = !{!5, !5, i64 0}
!9 = !{!10, !10, i64 0}
!10 = !{!"int", !5, i64 0}
!11 = !{}
!12 = !{!"%39", !"%47"}
!13 = !{!"merged.bb2", !"merged.bb4"}
