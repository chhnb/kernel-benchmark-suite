; ModuleID = '/data/home/chh/simplify-v2/build/dp1-removal/stable-darm/PCM32/trial-29/fused.ll'
source_filename = "/data/home/chh/kernel-benchmark-suite/build/full-regression-rerun/snapshot.TxCJ3u/artifact-benchmarks/benchmarks/PCM/pcm.hip.cpp"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-ni:7"
target triple = "amdgcn-amd-amdhsa"

%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockDim>::X" = type { i8 }

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockDimE1xE = comdat any

@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockDimE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockDim>::X" undef, comdat, align 1
@_ZZ3pcmPiE2sR = internal unnamed_addr addrspace(3) global [8192 x i32] undef, align 16
@_ZZ3pcmPiE2sC = internal unnamed_addr addrspace(3) global [8192 x i32] undef, align 16

; Function Attrs: convergent norecurse nounwind
define protected amdgpu_kernel void @_Z3pcmPi(i32 addrspace(1)* nocapture %0) local_unnamed_addr #0 {
unify.bb1:
  %1 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !5
  %2 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %3 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %4 = getelementptr i8, i8 addrspace(4)* %3, i64 4
  %5 = bitcast i8 addrspace(4)* %4 to i16 addrspace(4)*
  %6 = load i16, i16 addrspace(4)* %5, align 4, !range !6, !invariant.load !7
  %7 = zext i16 %6 to i32
  %8 = mul i32 %2, %7
  %9 = add i32 %8, %1
  %10 = icmp slt i32 %9, 268435456
  %11 = shl nsw i32 %9, 8
  %12 = select i1 %10, i32 %11, i32 undef
  %13 = shl nuw nsw i32 %1, 8
  br i1 %10, label %merged.branch.split, label %merged.branch.split2

merged.branch.split:                              ; preds = %merged.branch.split, %unify.bb1
  %14 = phi i32 [ 0, %unify.bb1 ], [ %126, %merged.branch.split ]
  %15 = add nuw nsw i32 %14, %12
  %16 = sext i32 %15 to i64
  %17 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %16
  %18 = load i32, i32 addrspace(1)* %17, align 4, !tbaa !8
  %19 = add nuw nsw i32 %14, %13
  %20 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %19
  store i32 %18, i32 addrspace(3)* %20, align 16, !tbaa !8
  %21 = or i32 %14, 1
  %22 = add nuw nsw i32 %21, %12
  %23 = sext i32 %22 to i64
  %24 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %23
  %25 = load i32, i32 addrspace(1)* %24, align 4, !tbaa !8
  %26 = add nuw nsw i32 %21, %13
  %27 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %26
  store i32 %25, i32 addrspace(3)* %27, align 4, !tbaa !8
  %28 = or i32 %14, 2
  %29 = add nuw nsw i32 %28, %12
  %30 = sext i32 %29 to i64
  %31 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %30
  %32 = load i32, i32 addrspace(1)* %31, align 4, !tbaa !8
  %33 = add nuw nsw i32 %28, %13
  %34 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %33
  store i32 %32, i32 addrspace(3)* %34, align 8, !tbaa !8
  %35 = or i32 %14, 3
  %36 = add nuw nsw i32 %35, %12
  %37 = sext i32 %36 to i64
  %38 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %37
  %39 = load i32, i32 addrspace(1)* %38, align 4, !tbaa !8
  %40 = add nuw nsw i32 %35, %13
  %41 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %40
  store i32 %39, i32 addrspace(3)* %41, align 4, !tbaa !8
  %42 = or i32 %14, 4
  %43 = add nuw nsw i32 %42, %12
  %44 = sext i32 %43 to i64
  %45 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %44
  %46 = load i32, i32 addrspace(1)* %45, align 4, !tbaa !8
  %47 = add nuw nsw i32 %42, %13
  %48 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %47
  store i32 %46, i32 addrspace(3)* %48, align 16, !tbaa !8
  %49 = or i32 %14, 5
  %50 = add nuw nsw i32 %49, %12
  %51 = sext i32 %50 to i64
  %52 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %51
  %53 = load i32, i32 addrspace(1)* %52, align 4, !tbaa !8
  %54 = add nuw nsw i32 %49, %13
  %55 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %54
  store i32 %53, i32 addrspace(3)* %55, align 4, !tbaa !8
  %56 = or i32 %14, 6
  %57 = add nuw nsw i32 %56, %12
  %58 = sext i32 %57 to i64
  %59 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %58
  %60 = load i32, i32 addrspace(1)* %59, align 4, !tbaa !8
  %61 = add nuw nsw i32 %56, %13
  %62 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %61
  store i32 %60, i32 addrspace(3)* %62, align 8, !tbaa !8
  %63 = or i32 %14, 7
  %64 = add nuw nsw i32 %63, %12
  %65 = sext i32 %64 to i64
  %66 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %65
  %67 = load i32, i32 addrspace(1)* %66, align 4, !tbaa !8
  %68 = add nuw nsw i32 %63, %13
  %69 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %68
  store i32 %67, i32 addrspace(3)* %69, align 4, !tbaa !8
  %70 = or i32 %14, 8
  %71 = add nuw nsw i32 %70, %12
  %72 = sext i32 %71 to i64
  %73 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %72
  %74 = load i32, i32 addrspace(1)* %73, align 4, !tbaa !8
  %75 = add nuw nsw i32 %70, %13
  %76 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %75
  store i32 %74, i32 addrspace(3)* %76, align 16, !tbaa !8
  %77 = or i32 %14, 9
  %78 = add nuw nsw i32 %77, %12
  %79 = sext i32 %78 to i64
  %80 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %79
  %81 = load i32, i32 addrspace(1)* %80, align 4, !tbaa !8
  %82 = add nuw nsw i32 %77, %13
  %83 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %82
  store i32 %81, i32 addrspace(3)* %83, align 4, !tbaa !8
  %84 = or i32 %14, 10
  %85 = add nuw nsw i32 %84, %12
  %86 = sext i32 %85 to i64
  %87 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %86
  %88 = load i32, i32 addrspace(1)* %87, align 4, !tbaa !8
  %89 = add nuw nsw i32 %84, %13
  %90 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %89
  store i32 %88, i32 addrspace(3)* %90, align 8, !tbaa !8
  %91 = or i32 %14, 11
  %92 = add nuw nsw i32 %91, %12
  %93 = sext i32 %92 to i64
  %94 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %93
  %95 = load i32, i32 addrspace(1)* %94, align 4, !tbaa !8
  %96 = add nuw nsw i32 %91, %13
  %97 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %96
  store i32 %95, i32 addrspace(3)* %97, align 4, !tbaa !8
  %98 = or i32 %14, 12
  %99 = add nuw nsw i32 %98, %12
  %100 = sext i32 %99 to i64
  %101 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %100
  %102 = load i32, i32 addrspace(1)* %101, align 4, !tbaa !8
  %103 = add nuw nsw i32 %98, %13
  %104 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %103
  store i32 %102, i32 addrspace(3)* %104, align 16, !tbaa !8
  %105 = or i32 %14, 13
  %106 = add nuw nsw i32 %105, %12
  %107 = sext i32 %106 to i64
  %108 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %107
  %109 = load i32, i32 addrspace(1)* %108, align 4, !tbaa !8
  %110 = add nuw nsw i32 %105, %13
  %111 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %110
  store i32 %109, i32 addrspace(3)* %111, align 4, !tbaa !8
  %112 = or i32 %14, 14
  %113 = add nuw nsw i32 %112, %12
  %114 = sext i32 %113 to i64
  %115 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %114
  %116 = load i32, i32 addrspace(1)* %115, align 4, !tbaa !8
  %117 = add nuw nsw i32 %112, %13
  %118 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %117
  store i32 %116, i32 addrspace(3)* %118, align 8, !tbaa !8
  %119 = or i32 %14, 15
  %120 = add nuw nsw i32 %119, %12
  %121 = sext i32 %120 to i64
  %122 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %121
  %123 = load i32, i32 addrspace(1)* %122, align 4, !tbaa !8
  %124 = add nuw nsw i32 %119, %13
  %125 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %124
  store i32 %123, i32 addrspace(3)* %125, align 4, !tbaa !8
  %126 = add nuw nsw i32 %14, 16
  %127 = icmp eq i32 %126, 256
  br i1 %127, label %merged.branch.split2, label %merged.branch.split, !llvm.loop !12

merged.branch.split2:                             ; preds = %merged.branch.split, %unify.bb1
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %128 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sR, i32 0, i32 %13
  %129 = and i32 %1, 1
  %130 = icmp ne i32 %129, 0
  %131 = icmp ult i32 %1, 31
  %132 = xor i1 %130, true
  %133 = and i1 %131, %132
  %134 = add nsw i32 %13, -256
  %135 = add nuw nsw i32 %13, 256
  %136 = icmp ult i32 %1, 32
  %137 = and i1 %131, %130
  %138 = icmp eq i32 %1, 0
  br label %140

139:                                              ; preds = %764
  br i1 %10, label %767, label %882

140:                                              ; preds = %764, %merged.branch.split2
  %141 = phi i32 [ 0, %merged.branch.split2 ], [ %765, %764 ]
  br i1 %133, label %142, label %unify.bb

142:                                              ; preds = %142, %140
  %143 = phi i32 [ 0, %140 ], [ %265, %142 ]
  %144 = phi i32 [ 0, %140 ], [ %263, %142 ]
  %145 = phi i32 [ 0, %140 ], [ %261, %142 ]
  %146 = add nsw i32 %145, %13
  %147 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %146
  %148 = load i32, i32 addrspace(3)* %147, align 4, !tbaa !8
  %149 = add nsw i32 %135, %144
  %150 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %149
  %151 = load i32, i32 addrspace(3)* %150, align 4, !tbaa !8
  %152 = icmp sgt i32 %148, %151
  %153 = select i1 %152, i32 %151, i32 %148
  %154 = xor i1 %152, true
  %155 = zext i1 %154 to i32
  %156 = add nuw nsw i32 %145, %155
  %157 = zext i1 %152 to i32
  %158 = add nuw nsw i32 %144, %157
  %159 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %143
  store i32 %153, i32 addrspace(3)* %159, align 16
  %160 = or i32 %143, 1
  %161 = add nsw i32 %156, %13
  %162 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %161
  %163 = load i32, i32 addrspace(3)* %162, align 4, !tbaa !8
  %164 = add nsw i32 %135, %158
  %165 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %164
  %166 = load i32, i32 addrspace(3)* %165, align 4, !tbaa !8
  %167 = icmp sgt i32 %163, %166
  %168 = select i1 %167, i32 %166, i32 %163
  %169 = xor i1 %167, true
  %170 = zext i1 %169 to i32
  %171 = add nuw nsw i32 %156, %170
  %172 = zext i1 %167 to i32
  %173 = add nuw nsw i32 %158, %172
  %174 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %160
  store i32 %168, i32 addrspace(3)* %174, align 4
  %175 = or i32 %143, 2
  %176 = add nsw i32 %171, %13
  %177 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %176
  %178 = load i32, i32 addrspace(3)* %177, align 4, !tbaa !8
  %179 = add nsw i32 %135, %173
  %180 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %179
  %181 = load i32, i32 addrspace(3)* %180, align 4, !tbaa !8
  %182 = icmp sgt i32 %178, %181
  %183 = select i1 %182, i32 %181, i32 %178
  %184 = xor i1 %182, true
  %185 = zext i1 %184 to i32
  %186 = add nuw nsw i32 %171, %185
  %187 = zext i1 %182 to i32
  %188 = add nuw nsw i32 %173, %187
  %189 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %175
  store i32 %183, i32 addrspace(3)* %189, align 8
  %190 = or i32 %143, 3
  %191 = add nsw i32 %186, %13
  %192 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %191
  %193 = load i32, i32 addrspace(3)* %192, align 4, !tbaa !8
  %194 = add nsw i32 %135, %188
  %195 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %194
  %196 = load i32, i32 addrspace(3)* %195, align 4, !tbaa !8
  %197 = icmp sgt i32 %193, %196
  %198 = select i1 %197, i32 %196, i32 %193
  %199 = xor i1 %197, true
  %200 = zext i1 %199 to i32
  %201 = add nuw nsw i32 %186, %200
  %202 = zext i1 %197 to i32
  %203 = add nuw nsw i32 %188, %202
  %204 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %190
  store i32 %198, i32 addrspace(3)* %204, align 4
  %205 = or i32 %143, 4
  %206 = add nsw i32 %201, %13
  %207 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %206
  %208 = load i32, i32 addrspace(3)* %207, align 4, !tbaa !8
  %209 = add nsw i32 %135, %203
  %210 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %209
  %211 = load i32, i32 addrspace(3)* %210, align 4, !tbaa !8
  %212 = icmp sgt i32 %208, %211
  %213 = select i1 %212, i32 %211, i32 %208
  %214 = xor i1 %212, true
  %215 = zext i1 %214 to i32
  %216 = add nuw nsw i32 %201, %215
  %217 = zext i1 %212 to i32
  %218 = add nuw nsw i32 %203, %217
  %219 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %205
  store i32 %213, i32 addrspace(3)* %219, align 16
  %220 = or i32 %143, 5
  %221 = add nsw i32 %216, %13
  %222 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %221
  %223 = load i32, i32 addrspace(3)* %222, align 4, !tbaa !8
  %224 = add nsw i32 %135, %218
  %225 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %224
  %226 = load i32, i32 addrspace(3)* %225, align 4, !tbaa !8
  %227 = icmp sgt i32 %223, %226
  %228 = select i1 %227, i32 %226, i32 %223
  %229 = xor i1 %227, true
  %230 = zext i1 %229 to i32
  %231 = add nuw nsw i32 %216, %230
  %232 = zext i1 %227 to i32
  %233 = add nuw nsw i32 %218, %232
  %234 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %220
  store i32 %228, i32 addrspace(3)* %234, align 4
  %235 = or i32 %143, 6
  %236 = add nsw i32 %231, %13
  %237 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %236
  %238 = load i32, i32 addrspace(3)* %237, align 4, !tbaa !8
  %239 = add nsw i32 %135, %233
  %240 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %239
  %241 = load i32, i32 addrspace(3)* %240, align 4, !tbaa !8
  %242 = icmp sgt i32 %238, %241
  %243 = select i1 %242, i32 %241, i32 %238
  %244 = xor i1 %242, true
  %245 = zext i1 %244 to i32
  %246 = add nuw nsw i32 %231, %245
  %247 = zext i1 %242 to i32
  %248 = add nuw nsw i32 %233, %247
  %249 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %235
  store i32 %243, i32 addrspace(3)* %249, align 8
  %250 = or i32 %143, 7
  %251 = add nsw i32 %246, %13
  %252 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %251
  %253 = load i32, i32 addrspace(3)* %252, align 4, !tbaa !8
  %254 = add nsw i32 %135, %248
  %255 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %254
  %256 = load i32, i32 addrspace(3)* %255, align 4, !tbaa !8
  %257 = icmp sgt i32 %253, %256
  %258 = select i1 %257, i32 %256, i32 %253
  %259 = xor i1 %257, true
  %260 = zext i1 %259 to i32
  %261 = add nuw nsw i32 %246, %260
  %262 = zext i1 %257 to i32
  %263 = add nuw nsw i32 %248, %262
  %264 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %250
  store i32 %258, i32 addrspace(3)* %264, align 4
  %265 = add nuw nsw i32 %143, 8
  %266 = icmp eq i32 %265, 256
  br i1 %266, label %368, label %142, !llvm.loop !14

unify.bb:                                         ; preds = %unify.bb, %140
  %267 = phi i32 [ 0, %140 ], [ %366, %unify.bb ]
  %268 = phi i32 [ 255, %140 ], [ %365, %unify.bb ]
  %269 = phi i32 [ 255, %140 ], [ %364, %unify.bb ]
  %270 = add nsw i32 %268, %13
  %271 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %270
  %272 = load i32, i32 addrspace(3)* %271, align 4, !tbaa !8
  %273 = add nsw i32 %134, %269
  %274 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %273
  %275 = load i32, i32 addrspace(3)* %274, align 4, !tbaa !8
  %276 = icmp sgt i32 %272, %275
  %277 = sub nuw nsw i32 255, %267
  %278 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %277
  %merged.select = select i1 %276, i32 %272, i32 %275
  store i32 %merged.select, i32 addrspace(3)* %278, align 4, !tbaa !8
  %merged.select1 = select i1 %276, i32 %268, i32 %269
  %279 = add nsw i32 %merged.select1, -1
  %280 = select i1 %276, i32 %269, i32 %279
  %281 = select i1 %276, i32 %279, i32 %268
  %282 = add nsw i32 %281, %13
  %283 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %282
  %284 = load i32, i32 addrspace(3)* %283, align 4, !tbaa !8
  %285 = add nsw i32 %134, %280
  %286 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %285
  %287 = load i32, i32 addrspace(3)* %286, align 4, !tbaa !8
  %288 = icmp sgt i32 %284, %287
  %289 = sub nsw i32 254, %267
  %290 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %289
  %merged.select31 = select i1 %288, i32 %284, i32 %287
  store i32 %merged.select31, i32 addrspace(3)* %290, align 8, !tbaa !8
  %merged.select32 = select i1 %288, i32 %281, i32 %280
  %291 = add nsw i32 %merged.select32, -1
  %292 = select i1 %288, i32 %280, i32 %291
  %293 = select i1 %288, i32 %291, i32 %281
  %294 = add nsw i32 %293, %13
  %295 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %294
  %296 = load i32, i32 addrspace(3)* %295, align 4, !tbaa !8
  %297 = add nsw i32 %134, %292
  %298 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %297
  %299 = load i32, i32 addrspace(3)* %298, align 4, !tbaa !8
  %300 = icmp sgt i32 %296, %299
  %301 = sub nsw i32 253, %267
  %302 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %301
  %merged.select19 = select i1 %300, i32 %296, i32 %299
  store i32 %merged.select19, i32 addrspace(3)* %302, align 4, !tbaa !8
  %merged.select20 = select i1 %300, i32 %293, i32 %292
  %303 = add nsw i32 %merged.select20, -1
  %304 = select i1 %300, i32 %292, i32 %303
  %305 = select i1 %300, i32 %303, i32 %293
  %306 = add nsw i32 %305, %13
  %307 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %306
  %308 = load i32, i32 addrspace(3)* %307, align 4, !tbaa !8
  %309 = add nsw i32 %134, %304
  %310 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %309
  %311 = load i32, i32 addrspace(3)* %310, align 4, !tbaa !8
  %312 = icmp sgt i32 %308, %311
  %313 = sub nsw i32 252, %267
  %314 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %313
  %merged.select21 = select i1 %312, i32 %308, i32 %311
  store i32 %merged.select21, i32 addrspace(3)* %314, align 16, !tbaa !8
  %merged.select22 = select i1 %312, i32 %305, i32 %304
  %315 = add nsw i32 %merged.select22, -1
  %316 = select i1 %312, i32 %304, i32 %315
  %317 = select i1 %312, i32 %315, i32 %305
  %318 = add nsw i32 %317, %13
  %319 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %318
  %320 = load i32, i32 addrspace(3)* %319, align 4, !tbaa !8
  %321 = add nsw i32 %134, %316
  %322 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %321
  %323 = load i32, i32 addrspace(3)* %322, align 4, !tbaa !8
  %324 = icmp sgt i32 %320, %323
  %325 = sub nsw i32 251, %267
  %326 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %325
  %merged.select23 = select i1 %324, i32 %320, i32 %323
  store i32 %merged.select23, i32 addrspace(3)* %326, align 4, !tbaa !8
  %merged.select24 = select i1 %324, i32 %317, i32 %316
  %327 = add nsw i32 %merged.select24, -1
  %328 = select i1 %324, i32 %316, i32 %327
  %329 = select i1 %324, i32 %327, i32 %317
  %330 = add nsw i32 %329, %13
  %331 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %330
  %332 = load i32, i32 addrspace(3)* %331, align 4, !tbaa !8
  %333 = add nsw i32 %134, %328
  %334 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %333
  %335 = load i32, i32 addrspace(3)* %334, align 4, !tbaa !8
  %336 = icmp sgt i32 %332, %335
  %337 = sub nsw i32 250, %267
  %338 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %337
  %merged.select25 = select i1 %336, i32 %332, i32 %335
  store i32 %merged.select25, i32 addrspace(3)* %338, align 8, !tbaa !8
  %merged.select26 = select i1 %336, i32 %329, i32 %328
  %339 = add nsw i32 %merged.select26, -1
  %340 = select i1 %336, i32 %328, i32 %339
  %341 = select i1 %336, i32 %339, i32 %329
  %342 = add nsw i32 %341, %13
  %343 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %342
  %344 = load i32, i32 addrspace(3)* %343, align 4, !tbaa !8
  %345 = add nsw i32 %134, %340
  %346 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %345
  %347 = load i32, i32 addrspace(3)* %346, align 4, !tbaa !8
  %348 = icmp sgt i32 %344, %347
  %349 = sub nsw i32 249, %267
  %350 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %349
  %merged.select27 = select i1 %348, i32 %344, i32 %347
  store i32 %merged.select27, i32 addrspace(3)* %350, align 4, !tbaa !8
  %merged.select28 = select i1 %348, i32 %341, i32 %340
  %351 = add nsw i32 %merged.select28, -1
  %352 = select i1 %348, i32 %340, i32 %351
  %353 = select i1 %348, i32 %351, i32 %341
  %354 = add nsw i32 %353, %13
  %355 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %354
  %356 = load i32, i32 addrspace(3)* %355, align 4, !tbaa !8
  %357 = add nsw i32 %134, %352
  %358 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %357
  %359 = load i32, i32 addrspace(3)* %358, align 4, !tbaa !8
  %360 = icmp sgt i32 %356, %359
  %361 = sub nsw i32 248, %267
  %362 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %361
  %merged.select29 = select i1 %360, i32 %356, i32 %359
  store i32 %merged.select29, i32 addrspace(3)* %362, align 16, !tbaa !8
  %merged.select30 = select i1 %360, i32 %353, i32 %352
  %363 = add nsw i32 %merged.select30, -1
  %364 = select i1 %360, i32 %352, i32 %363
  %365 = select i1 %360, i32 %363, i32 %353
  %366 = add nuw nsw i32 %267, 8
  %367 = icmp eq i32 %366, 256
  br i1 %367, label %368, label %unify.bb, !llvm.loop !15

368:                                              ; preds = %unify.bb, %142
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %136, label %369, label %452

369:                                              ; preds = %369, %368
  %370 = phi i32 [ 0, %368 ], [ %450, %369 ]
  %371 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %370
  %372 = load i32, i32 addrspace(3)* %371, align 16, !tbaa !8
  %373 = add nuw nsw i32 %370, %13
  %374 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %373
  store i32 %372, i32 addrspace(3)* %374, align 16, !tbaa !8
  %375 = or i32 %370, 1
  %376 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %375
  %377 = load i32, i32 addrspace(3)* %376, align 4, !tbaa !8
  %378 = add nuw nsw i32 %375, %13
  %379 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %378
  store i32 %377, i32 addrspace(3)* %379, align 4, !tbaa !8
  %380 = or i32 %370, 2
  %381 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %380
  %382 = load i32, i32 addrspace(3)* %381, align 8, !tbaa !8
  %383 = add nuw nsw i32 %380, %13
  %384 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %383
  store i32 %382, i32 addrspace(3)* %384, align 8, !tbaa !8
  %385 = or i32 %370, 3
  %386 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %385
  %387 = load i32, i32 addrspace(3)* %386, align 4, !tbaa !8
  %388 = add nuw nsw i32 %385, %13
  %389 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %388
  store i32 %387, i32 addrspace(3)* %389, align 4, !tbaa !8
  %390 = or i32 %370, 4
  %391 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %390
  %392 = load i32, i32 addrspace(3)* %391, align 16, !tbaa !8
  %393 = add nuw nsw i32 %390, %13
  %394 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %393
  store i32 %392, i32 addrspace(3)* %394, align 16, !tbaa !8
  %395 = or i32 %370, 5
  %396 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %395
  %397 = load i32, i32 addrspace(3)* %396, align 4, !tbaa !8
  %398 = add nuw nsw i32 %395, %13
  %399 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %398
  store i32 %397, i32 addrspace(3)* %399, align 4, !tbaa !8
  %400 = or i32 %370, 6
  %401 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %400
  %402 = load i32, i32 addrspace(3)* %401, align 8, !tbaa !8
  %403 = add nuw nsw i32 %400, %13
  %404 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %403
  store i32 %402, i32 addrspace(3)* %404, align 8, !tbaa !8
  %405 = or i32 %370, 7
  %406 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %405
  %407 = load i32, i32 addrspace(3)* %406, align 4, !tbaa !8
  %408 = add nuw nsw i32 %405, %13
  %409 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %408
  store i32 %407, i32 addrspace(3)* %409, align 4, !tbaa !8
  %410 = or i32 %370, 8
  %411 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %410
  %412 = load i32, i32 addrspace(3)* %411, align 16, !tbaa !8
  %413 = add nuw nsw i32 %410, %13
  %414 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %413
  store i32 %412, i32 addrspace(3)* %414, align 16, !tbaa !8
  %415 = or i32 %370, 9
  %416 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %415
  %417 = load i32, i32 addrspace(3)* %416, align 4, !tbaa !8
  %418 = add nuw nsw i32 %415, %13
  %419 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %418
  store i32 %417, i32 addrspace(3)* %419, align 4, !tbaa !8
  %420 = or i32 %370, 10
  %421 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %420
  %422 = load i32, i32 addrspace(3)* %421, align 8, !tbaa !8
  %423 = add nuw nsw i32 %420, %13
  %424 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %423
  store i32 %422, i32 addrspace(3)* %424, align 8, !tbaa !8
  %425 = or i32 %370, 11
  %426 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %425
  %427 = load i32, i32 addrspace(3)* %426, align 4, !tbaa !8
  %428 = add nuw nsw i32 %425, %13
  %429 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %428
  store i32 %427, i32 addrspace(3)* %429, align 4, !tbaa !8
  %430 = or i32 %370, 12
  %431 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %430
  %432 = load i32, i32 addrspace(3)* %431, align 16, !tbaa !8
  %433 = add nuw nsw i32 %430, %13
  %434 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %433
  store i32 %432, i32 addrspace(3)* %434, align 16, !tbaa !8
  %435 = or i32 %370, 13
  %436 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %435
  %437 = load i32, i32 addrspace(3)* %436, align 4, !tbaa !8
  %438 = add nuw nsw i32 %435, %13
  %439 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %438
  store i32 %437, i32 addrspace(3)* %439, align 4, !tbaa !8
  %440 = or i32 %370, 14
  %441 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %440
  %442 = load i32, i32 addrspace(3)* %441, align 8, !tbaa !8
  %443 = add nuw nsw i32 %440, %13
  %444 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %443
  store i32 %442, i32 addrspace(3)* %444, align 8, !tbaa !8
  %445 = or i32 %370, 15
  %446 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %445
  %447 = load i32, i32 addrspace(3)* %446, align 4, !tbaa !8
  %448 = add nuw nsw i32 %445, %13
  %449 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %448
  store i32 %447, i32 addrspace(3)* %449, align 4, !tbaa !8
  %450 = add nuw nsw i32 %370, 16
  %451 = icmp eq i32 %450, 256
  br i1 %451, label %452, label %369, !llvm.loop !16

452:                                              ; preds = %369, %368
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %137, label %453, label %578

453:                                              ; preds = %453, %452
  %454 = phi i32 [ 0, %452 ], [ %576, %453 ]
  %455 = phi i32 [ 0, %452 ], [ %574, %453 ]
  %456 = phi i32 [ 0, %452 ], [ %572, %453 ]
  %457 = add nsw i32 %456, %13
  %458 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %457
  %459 = load i32, i32 addrspace(3)* %458, align 4, !tbaa !8
  %460 = add nsw i32 %135, %455
  %461 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %460
  %462 = load i32, i32 addrspace(3)* %461, align 4, !tbaa !8
  %463 = icmp sgt i32 %459, %462
  %464 = select i1 %463, i32 %462, i32 %459
  %465 = xor i1 %463, true
  %466 = zext i1 %465 to i32
  %467 = add nuw nsw i32 %456, %466
  %468 = zext i1 %463 to i32
  %469 = add nuw nsw i32 %455, %468
  %470 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %454
  store i32 %464, i32 addrspace(3)* %470, align 16
  %471 = or i32 %454, 1
  %472 = add nsw i32 %467, %13
  %473 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %472
  %474 = load i32, i32 addrspace(3)* %473, align 4, !tbaa !8
  %475 = add nsw i32 %135, %469
  %476 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %475
  %477 = load i32, i32 addrspace(3)* %476, align 4, !tbaa !8
  %478 = icmp sgt i32 %474, %477
  %479 = select i1 %478, i32 %477, i32 %474
  %480 = xor i1 %478, true
  %481 = zext i1 %480 to i32
  %482 = add nuw nsw i32 %467, %481
  %483 = zext i1 %478 to i32
  %484 = add nuw nsw i32 %469, %483
  %485 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %471
  store i32 %479, i32 addrspace(3)* %485, align 4
  %486 = or i32 %454, 2
  %487 = add nsw i32 %482, %13
  %488 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %487
  %489 = load i32, i32 addrspace(3)* %488, align 4, !tbaa !8
  %490 = add nsw i32 %135, %484
  %491 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %490
  %492 = load i32, i32 addrspace(3)* %491, align 4, !tbaa !8
  %493 = icmp sgt i32 %489, %492
  %494 = select i1 %493, i32 %492, i32 %489
  %495 = xor i1 %493, true
  %496 = zext i1 %495 to i32
  %497 = add nuw nsw i32 %482, %496
  %498 = zext i1 %493 to i32
  %499 = add nuw nsw i32 %484, %498
  %500 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %486
  store i32 %494, i32 addrspace(3)* %500, align 8
  %501 = or i32 %454, 3
  %502 = add nsw i32 %497, %13
  %503 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %502
  %504 = load i32, i32 addrspace(3)* %503, align 4, !tbaa !8
  %505 = add nsw i32 %135, %499
  %506 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %505
  %507 = load i32, i32 addrspace(3)* %506, align 4, !tbaa !8
  %508 = icmp sgt i32 %504, %507
  %509 = select i1 %508, i32 %507, i32 %504
  %510 = xor i1 %508, true
  %511 = zext i1 %510 to i32
  %512 = add nuw nsw i32 %497, %511
  %513 = zext i1 %508 to i32
  %514 = add nuw nsw i32 %499, %513
  %515 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %501
  store i32 %509, i32 addrspace(3)* %515, align 4
  %516 = or i32 %454, 4
  %517 = add nsw i32 %512, %13
  %518 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %517
  %519 = load i32, i32 addrspace(3)* %518, align 4, !tbaa !8
  %520 = add nsw i32 %135, %514
  %521 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %520
  %522 = load i32, i32 addrspace(3)* %521, align 4, !tbaa !8
  %523 = icmp sgt i32 %519, %522
  %524 = select i1 %523, i32 %522, i32 %519
  %525 = xor i1 %523, true
  %526 = zext i1 %525 to i32
  %527 = add nuw nsw i32 %512, %526
  %528 = zext i1 %523 to i32
  %529 = add nuw nsw i32 %514, %528
  %530 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %516
  store i32 %524, i32 addrspace(3)* %530, align 16
  %531 = or i32 %454, 5
  %532 = add nsw i32 %527, %13
  %533 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %532
  %534 = load i32, i32 addrspace(3)* %533, align 4, !tbaa !8
  %535 = add nsw i32 %135, %529
  %536 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %535
  %537 = load i32, i32 addrspace(3)* %536, align 4, !tbaa !8
  %538 = icmp sgt i32 %534, %537
  %539 = select i1 %538, i32 %537, i32 %534
  %540 = xor i1 %538, true
  %541 = zext i1 %540 to i32
  %542 = add nuw nsw i32 %527, %541
  %543 = zext i1 %538 to i32
  %544 = add nuw nsw i32 %529, %543
  %545 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %531
  store i32 %539, i32 addrspace(3)* %545, align 4
  %546 = or i32 %454, 6
  %547 = add nsw i32 %542, %13
  %548 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %547
  %549 = load i32, i32 addrspace(3)* %548, align 4, !tbaa !8
  %550 = add nsw i32 %135, %544
  %551 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %550
  %552 = load i32, i32 addrspace(3)* %551, align 4, !tbaa !8
  %553 = icmp sgt i32 %549, %552
  %554 = select i1 %553, i32 %552, i32 %549
  %555 = xor i1 %553, true
  %556 = zext i1 %555 to i32
  %557 = add nuw nsw i32 %542, %556
  %558 = zext i1 %553 to i32
  %559 = add nuw nsw i32 %544, %558
  %560 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %546
  store i32 %554, i32 addrspace(3)* %560, align 8
  %561 = or i32 %454, 7
  %562 = add nsw i32 %557, %13
  %563 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %562
  %564 = load i32, i32 addrspace(3)* %563, align 4, !tbaa !8
  %565 = add nsw i32 %135, %559
  %566 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %565
  %567 = load i32, i32 addrspace(3)* %566, align 4, !tbaa !8
  %568 = icmp sgt i32 %564, %567
  %569 = select i1 %568, i32 %567, i32 %564
  %570 = xor i1 %568, true
  %571 = zext i1 %570 to i32
  %572 = add nuw nsw i32 %557, %571
  %573 = zext i1 %568 to i32
  %574 = add nuw nsw i32 %559, %573
  %575 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %561
  store i32 %569, i32 addrspace(3)* %575, align 4
  %576 = add nuw nsw i32 %454, 8
  %577 = icmp eq i32 %576, 256
  br i1 %577, label %680, label %453, !llvm.loop !17

578:                                              ; preds = %452
  br i1 %138, label %680, label %unify.bb2

unify.bb2:                                        ; preds = %unify.bb2, %578
  %579 = phi i32 [ 0, %578 ], [ %678, %unify.bb2 ]
  %580 = phi i32 [ 255, %578 ], [ %677, %unify.bb2 ]
  %581 = phi i32 [ 255, %578 ], [ %676, %unify.bb2 ]
  %582 = add nsw i32 %580, %13
  %583 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %582
  %584 = load i32, i32 addrspace(3)* %583, align 4, !tbaa !8
  %585 = add nsw i32 %134, %581
  %586 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %585
  %587 = load i32, i32 addrspace(3)* %586, align 4, !tbaa !8
  %588 = icmp sgt i32 %584, %587
  %589 = sub nuw nsw i32 255, %579
  %590 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %589
  %merged.select3 = select i1 %588, i32 %584, i32 %587
  store i32 %merged.select3, i32 addrspace(3)* %590, align 4, !tbaa !8
  %merged.select4 = select i1 %588, i32 %580, i32 %581
  %591 = add nsw i32 %merged.select4, -1
  %592 = select i1 %588, i32 %581, i32 %591
  %593 = select i1 %588, i32 %591, i32 %580
  %594 = add nsw i32 %593, %13
  %595 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %594
  %596 = load i32, i32 addrspace(3)* %595, align 4, !tbaa !8
  %597 = add nsw i32 %134, %592
  %598 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %597
  %599 = load i32, i32 addrspace(3)* %598, align 4, !tbaa !8
  %600 = icmp sgt i32 %596, %599
  %601 = sub nsw i32 254, %579
  %602 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %601
  %merged.select5 = select i1 %600, i32 %596, i32 %599
  store i32 %merged.select5, i32 addrspace(3)* %602, align 8, !tbaa !8
  %merged.select6 = select i1 %600, i32 %593, i32 %592
  %603 = add nsw i32 %merged.select6, -1
  %604 = select i1 %600, i32 %592, i32 %603
  %605 = select i1 %600, i32 %603, i32 %593
  %606 = add nsw i32 %605, %13
  %607 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %606
  %608 = load i32, i32 addrspace(3)* %607, align 4, !tbaa !8
  %609 = add nsw i32 %134, %604
  %610 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %609
  %611 = load i32, i32 addrspace(3)* %610, align 4, !tbaa !8
  %612 = icmp sgt i32 %608, %611
  %613 = sub nsw i32 253, %579
  %614 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %613
  %merged.select7 = select i1 %612, i32 %608, i32 %611
  store i32 %merged.select7, i32 addrspace(3)* %614, align 4, !tbaa !8
  %merged.select8 = select i1 %612, i32 %605, i32 %604
  %615 = add nsw i32 %merged.select8, -1
  %616 = select i1 %612, i32 %604, i32 %615
  %617 = select i1 %612, i32 %615, i32 %605
  %618 = add nsw i32 %617, %13
  %619 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %618
  %620 = load i32, i32 addrspace(3)* %619, align 4, !tbaa !8
  %621 = add nsw i32 %134, %616
  %622 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %621
  %623 = load i32, i32 addrspace(3)* %622, align 4, !tbaa !8
  %624 = icmp sgt i32 %620, %623
  %625 = sub nsw i32 252, %579
  %626 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %625
  %merged.select9 = select i1 %624, i32 %620, i32 %623
  store i32 %merged.select9, i32 addrspace(3)* %626, align 16, !tbaa !8
  %merged.select10 = select i1 %624, i32 %617, i32 %616
  %627 = add nsw i32 %merged.select10, -1
  %628 = select i1 %624, i32 %616, i32 %627
  %629 = select i1 %624, i32 %627, i32 %617
  %630 = add nsw i32 %629, %13
  %631 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %630
  %632 = load i32, i32 addrspace(3)* %631, align 4, !tbaa !8
  %633 = add nsw i32 %134, %628
  %634 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %633
  %635 = load i32, i32 addrspace(3)* %634, align 4, !tbaa !8
  %636 = icmp sgt i32 %632, %635
  %637 = sub nsw i32 251, %579
  %638 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %637
  %merged.select11 = select i1 %636, i32 %632, i32 %635
  store i32 %merged.select11, i32 addrspace(3)* %638, align 4, !tbaa !8
  %merged.select12 = select i1 %636, i32 %629, i32 %628
  %639 = add nsw i32 %merged.select12, -1
  %640 = select i1 %636, i32 %628, i32 %639
  %641 = select i1 %636, i32 %639, i32 %629
  %642 = add nsw i32 %641, %13
  %643 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %642
  %644 = load i32, i32 addrspace(3)* %643, align 4, !tbaa !8
  %645 = add nsw i32 %134, %640
  %646 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %645
  %647 = load i32, i32 addrspace(3)* %646, align 4, !tbaa !8
  %648 = icmp sgt i32 %644, %647
  %649 = sub nsw i32 250, %579
  %650 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %649
  %merged.select13 = select i1 %648, i32 %644, i32 %647
  store i32 %merged.select13, i32 addrspace(3)* %650, align 8, !tbaa !8
  %merged.select14 = select i1 %648, i32 %641, i32 %640
  %651 = add nsw i32 %merged.select14, -1
  %652 = select i1 %648, i32 %640, i32 %651
  %653 = select i1 %648, i32 %651, i32 %641
  %654 = add nsw i32 %653, %13
  %655 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %654
  %656 = load i32, i32 addrspace(3)* %655, align 4, !tbaa !8
  %657 = add nsw i32 %134, %652
  %658 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %657
  %659 = load i32, i32 addrspace(3)* %658, align 4, !tbaa !8
  %660 = icmp sgt i32 %656, %659
  %661 = sub nsw i32 249, %579
  %662 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %661
  %merged.select15 = select i1 %660, i32 %656, i32 %659
  store i32 %merged.select15, i32 addrspace(3)* %662, align 4, !tbaa !8
  %merged.select16 = select i1 %660, i32 %653, i32 %652
  %663 = add nsw i32 %merged.select16, -1
  %664 = select i1 %660, i32 %652, i32 %663
  %665 = select i1 %660, i32 %663, i32 %653
  %666 = add nsw i32 %665, %13
  %667 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %666
  %668 = load i32, i32 addrspace(3)* %667, align 4, !tbaa !8
  %669 = add nsw i32 %134, %664
  %670 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %669
  %671 = load i32, i32 addrspace(3)* %670, align 4, !tbaa !8
  %672 = icmp sgt i32 %668, %671
  %673 = sub nsw i32 248, %579
  %674 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %673
  %merged.select17 = select i1 %672, i32 %668, i32 %671
  store i32 %merged.select17, i32 addrspace(3)* %674, align 16, !tbaa !8
  %merged.select18 = select i1 %672, i32 %665, i32 %664
  %675 = add nsw i32 %merged.select18, -1
  %676 = select i1 %672, i32 %664, i32 %675
  %677 = select i1 %672, i32 %675, i32 %665
  %678 = add nuw nsw i32 %579, 8
  %679 = icmp eq i32 %678, 256
  br i1 %679, label %680, label %unify.bb2, !llvm.loop !18

680:                                              ; preds = %unify.bb2, %578, %453
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  br i1 %136, label %681, label %764

681:                                              ; preds = %681, %680
  %682 = phi i32 [ 0, %680 ], [ %762, %681 ]
  %683 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %682
  %684 = load i32, i32 addrspace(3)* %683, align 16, !tbaa !8
  %685 = add nuw nsw i32 %682, %13
  %686 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %685
  store i32 %684, i32 addrspace(3)* %686, align 16, !tbaa !8
  %687 = or i32 %682, 1
  %688 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %687
  %689 = load i32, i32 addrspace(3)* %688, align 4, !tbaa !8
  %690 = add nuw nsw i32 %687, %13
  %691 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %690
  store i32 %689, i32 addrspace(3)* %691, align 4, !tbaa !8
  %692 = or i32 %682, 2
  %693 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %692
  %694 = load i32, i32 addrspace(3)* %693, align 8, !tbaa !8
  %695 = add nuw nsw i32 %692, %13
  %696 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %695
  store i32 %694, i32 addrspace(3)* %696, align 8, !tbaa !8
  %697 = or i32 %682, 3
  %698 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %697
  %699 = load i32, i32 addrspace(3)* %698, align 4, !tbaa !8
  %700 = add nuw nsw i32 %697, %13
  %701 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %700
  store i32 %699, i32 addrspace(3)* %701, align 4, !tbaa !8
  %702 = or i32 %682, 4
  %703 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %702
  %704 = load i32, i32 addrspace(3)* %703, align 16, !tbaa !8
  %705 = add nuw nsw i32 %702, %13
  %706 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %705
  store i32 %704, i32 addrspace(3)* %706, align 16, !tbaa !8
  %707 = or i32 %682, 5
  %708 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %707
  %709 = load i32, i32 addrspace(3)* %708, align 4, !tbaa !8
  %710 = add nuw nsw i32 %707, %13
  %711 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %710
  store i32 %709, i32 addrspace(3)* %711, align 4, !tbaa !8
  %712 = or i32 %682, 6
  %713 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %712
  %714 = load i32, i32 addrspace(3)* %713, align 8, !tbaa !8
  %715 = add nuw nsw i32 %712, %13
  %716 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %715
  store i32 %714, i32 addrspace(3)* %716, align 8, !tbaa !8
  %717 = or i32 %682, 7
  %718 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %717
  %719 = load i32, i32 addrspace(3)* %718, align 4, !tbaa !8
  %720 = add nuw nsw i32 %717, %13
  %721 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %720
  store i32 %719, i32 addrspace(3)* %721, align 4, !tbaa !8
  %722 = or i32 %682, 8
  %723 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %722
  %724 = load i32, i32 addrspace(3)* %723, align 16, !tbaa !8
  %725 = add nuw nsw i32 %722, %13
  %726 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %725
  store i32 %724, i32 addrspace(3)* %726, align 16, !tbaa !8
  %727 = or i32 %682, 9
  %728 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %727
  %729 = load i32, i32 addrspace(3)* %728, align 4, !tbaa !8
  %730 = add nuw nsw i32 %727, %13
  %731 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %730
  store i32 %729, i32 addrspace(3)* %731, align 4, !tbaa !8
  %732 = or i32 %682, 10
  %733 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %732
  %734 = load i32, i32 addrspace(3)* %733, align 8, !tbaa !8
  %735 = add nuw nsw i32 %732, %13
  %736 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %735
  store i32 %734, i32 addrspace(3)* %736, align 8, !tbaa !8
  %737 = or i32 %682, 11
  %738 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %737
  %739 = load i32, i32 addrspace(3)* %738, align 4, !tbaa !8
  %740 = add nuw nsw i32 %737, %13
  %741 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %740
  store i32 %739, i32 addrspace(3)* %741, align 4, !tbaa !8
  %742 = or i32 %682, 12
  %743 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %742
  %744 = load i32, i32 addrspace(3)* %743, align 16, !tbaa !8
  %745 = add nuw nsw i32 %742, %13
  %746 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %745
  store i32 %744, i32 addrspace(3)* %746, align 16, !tbaa !8
  %747 = or i32 %682, 13
  %748 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %747
  %749 = load i32, i32 addrspace(3)* %748, align 4, !tbaa !8
  %750 = add nuw nsw i32 %747, %13
  %751 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %750
  store i32 %749, i32 addrspace(3)* %751, align 4, !tbaa !8
  %752 = or i32 %682, 14
  %753 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %752
  %754 = load i32, i32 addrspace(3)* %753, align 8, !tbaa !8
  %755 = add nuw nsw i32 %752, %13
  %756 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %755
  store i32 %754, i32 addrspace(3)* %756, align 8, !tbaa !8
  %757 = or i32 %682, 15
  %758 = getelementptr inbounds i32, i32 addrspace(3)* %128, i32 %757
  %759 = load i32, i32 addrspace(3)* %758, align 4, !tbaa !8
  %760 = add nuw nsw i32 %757, %13
  %761 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %760
  store i32 %759, i32 addrspace(3)* %761, align 4, !tbaa !8
  %762 = add nuw nsw i32 %682, 16
  %763 = icmp eq i32 %762, 256
  br i1 %763, label %764, label %681, !llvm.loop !19

764:                                              ; preds = %681, %680
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  %765 = add nuw nsw i32 %141, 1
  %766 = icmp eq i32 %765, 16
  br i1 %766, label %139, label %140, !llvm.loop !20

767:                                              ; preds = %767, %139
  %768 = phi i32 [ 0, %139 ], [ %880, %767 ]
  %769 = add nuw nsw i32 %768, %13
  %770 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %769
  %771 = load i32, i32 addrspace(3)* %770, align 16, !tbaa !8
  %772 = add nuw nsw i32 %768, %11
  %773 = sext i32 %772 to i64
  %774 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %773
  store i32 %771, i32 addrspace(1)* %774, align 4, !tbaa !8
  %775 = or i32 %768, 1
  %776 = add nuw nsw i32 %775, %13
  %777 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %776
  %778 = load i32, i32 addrspace(3)* %777, align 4, !tbaa !8
  %779 = add nuw nsw i32 %775, %11
  %780 = sext i32 %779 to i64
  %781 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %780
  store i32 %778, i32 addrspace(1)* %781, align 4, !tbaa !8
  %782 = or i32 %768, 2
  %783 = add nuw nsw i32 %782, %13
  %784 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %783
  %785 = load i32, i32 addrspace(3)* %784, align 8, !tbaa !8
  %786 = add nuw nsw i32 %782, %11
  %787 = sext i32 %786 to i64
  %788 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %787
  store i32 %785, i32 addrspace(1)* %788, align 4, !tbaa !8
  %789 = or i32 %768, 3
  %790 = add nuw nsw i32 %789, %13
  %791 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %790
  %792 = load i32, i32 addrspace(3)* %791, align 4, !tbaa !8
  %793 = add nuw nsw i32 %789, %11
  %794 = sext i32 %793 to i64
  %795 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %794
  store i32 %792, i32 addrspace(1)* %795, align 4, !tbaa !8
  %796 = or i32 %768, 4
  %797 = add nuw nsw i32 %796, %13
  %798 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %797
  %799 = load i32, i32 addrspace(3)* %798, align 16, !tbaa !8
  %800 = add nuw nsw i32 %796, %11
  %801 = sext i32 %800 to i64
  %802 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %801
  store i32 %799, i32 addrspace(1)* %802, align 4, !tbaa !8
  %803 = or i32 %768, 5
  %804 = add nuw nsw i32 %803, %13
  %805 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %804
  %806 = load i32, i32 addrspace(3)* %805, align 4, !tbaa !8
  %807 = add nuw nsw i32 %803, %11
  %808 = sext i32 %807 to i64
  %809 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %808
  store i32 %806, i32 addrspace(1)* %809, align 4, !tbaa !8
  %810 = or i32 %768, 6
  %811 = add nuw nsw i32 %810, %13
  %812 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %811
  %813 = load i32, i32 addrspace(3)* %812, align 8, !tbaa !8
  %814 = add nuw nsw i32 %810, %11
  %815 = sext i32 %814 to i64
  %816 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %815
  store i32 %813, i32 addrspace(1)* %816, align 4, !tbaa !8
  %817 = or i32 %768, 7
  %818 = add nuw nsw i32 %817, %13
  %819 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %818
  %820 = load i32, i32 addrspace(3)* %819, align 4, !tbaa !8
  %821 = add nuw nsw i32 %817, %11
  %822 = sext i32 %821 to i64
  %823 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %822
  store i32 %820, i32 addrspace(1)* %823, align 4, !tbaa !8
  %824 = or i32 %768, 8
  %825 = add nuw nsw i32 %824, %13
  %826 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %825
  %827 = load i32, i32 addrspace(3)* %826, align 16, !tbaa !8
  %828 = add nuw nsw i32 %824, %11
  %829 = sext i32 %828 to i64
  %830 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %829
  store i32 %827, i32 addrspace(1)* %830, align 4, !tbaa !8
  %831 = or i32 %768, 9
  %832 = add nuw nsw i32 %831, %13
  %833 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %832
  %834 = load i32, i32 addrspace(3)* %833, align 4, !tbaa !8
  %835 = add nuw nsw i32 %831, %11
  %836 = sext i32 %835 to i64
  %837 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %836
  store i32 %834, i32 addrspace(1)* %837, align 4, !tbaa !8
  %838 = or i32 %768, 10
  %839 = add nuw nsw i32 %838, %13
  %840 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %839
  %841 = load i32, i32 addrspace(3)* %840, align 8, !tbaa !8
  %842 = add nuw nsw i32 %838, %11
  %843 = sext i32 %842 to i64
  %844 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %843
  store i32 %841, i32 addrspace(1)* %844, align 4, !tbaa !8
  %845 = or i32 %768, 11
  %846 = add nuw nsw i32 %845, %13
  %847 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %846
  %848 = load i32, i32 addrspace(3)* %847, align 4, !tbaa !8
  %849 = add nuw nsw i32 %845, %11
  %850 = sext i32 %849 to i64
  %851 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %850
  store i32 %848, i32 addrspace(1)* %851, align 4, !tbaa !8
  %852 = or i32 %768, 12
  %853 = add nuw nsw i32 %852, %13
  %854 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %853
  %855 = load i32, i32 addrspace(3)* %854, align 16, !tbaa !8
  %856 = add nuw nsw i32 %852, %11
  %857 = sext i32 %856 to i64
  %858 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %857
  store i32 %855, i32 addrspace(1)* %858, align 4, !tbaa !8
  %859 = or i32 %768, 13
  %860 = add nuw nsw i32 %859, %13
  %861 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %860
  %862 = load i32, i32 addrspace(3)* %861, align 4, !tbaa !8
  %863 = add nuw nsw i32 %859, %11
  %864 = sext i32 %863 to i64
  %865 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %864
  store i32 %862, i32 addrspace(1)* %865, align 4, !tbaa !8
  %866 = or i32 %768, 14
  %867 = add nuw nsw i32 %866, %13
  %868 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %867
  %869 = load i32, i32 addrspace(3)* %868, align 8, !tbaa !8
  %870 = add nuw nsw i32 %866, %11
  %871 = sext i32 %870 to i64
  %872 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %871
  store i32 %869, i32 addrspace(1)* %872, align 4, !tbaa !8
  %873 = or i32 %768, 15
  %874 = add nuw nsw i32 %873, %13
  %875 = getelementptr inbounds [8192 x i32], [8192 x i32] addrspace(3)* @_ZZ3pcmPiE2sC, i32 0, i32 %874
  %876 = load i32, i32 addrspace(3)* %875, align 4, !tbaa !8
  %877 = add nuw nsw i32 %873, %11
  %878 = sext i32 %877 to i64
  %879 = getelementptr inbounds i32, i32 addrspace(1)* %0, i64 %878
  store i32 %876, i32 addrspace(1)* %879, align 4, !tbaa !8
  %880 = add nuw nsw i32 %768, 16
  %881 = icmp eq i32 %880, 256
  br i1 %881, label %882, label %767, !llvm.loop !21

882:                                              ; preds = %767, %139
  fence syncscope("workgroup") release
  tail call void @llvm.amdgcn.s.barrier() #3
  fence syncscope("workgroup") acquire
  ret void
}

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

attributes #0 = { convergent norecurse nounwind "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { convergent nounwind willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{i32 0, i32 1024}
!6 = !{i16 1, i16 1025}
!7 = !{}
!8 = !{!9, !9, i64 0}
!9 = !{!"int", !10, i64 0}
!10 = !{!"omnipotent char", !11, i64 0}
!11 = !{!"Simple C++ TBAA"}
!12 = distinct !{!12, !13}
!13 = !{!"llvm.loop.mustprogress"}
!14 = distinct !{!14, !13}
!15 = distinct !{!15, !13}
!16 = distinct !{!16, !13}
!17 = distinct !{!17, !13}
!18 = distinct !{!18, !13}
!19 = distinct !{!19, !13}
!20 = distinct !{!20, !13}
!21 = distinct !{!21, !13}
