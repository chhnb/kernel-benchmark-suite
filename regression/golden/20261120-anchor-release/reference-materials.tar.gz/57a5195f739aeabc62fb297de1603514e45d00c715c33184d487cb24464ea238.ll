; ModuleID = '/data/home/chh/simplify-v2/build/b2b-layouts/anchor-ablation/heldout/SW2D/start.ll'
source_filename = "cases/sw2d/source/flux.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7"
target triple = "amdgcn-amd-amdhsa"

%"struct.__HIP_Coordinates<__HIP_BlockDim>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" = type { i8 }
%"struct.__HIP_Coordinates<__HIP_GridDim>::X" = type { i8 }

$_ZN17__HIP_CoordinatesI14__HIP_BlockDimE1xE = comdat any

$_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = comdat any

$_ZN17__HIP_CoordinatesI13__HIP_GridDimE1xE = comdat any

@_ZN17__HIP_CoordinatesI14__HIP_BlockDimE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockDim>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI14__HIP_BlockIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_BlockIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI15__HIP_ThreadIdxE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_ThreadIdx>::X" undef, comdat, align 1
@_ZN17__HIP_CoordinatesI13__HIP_GridDimE1xE = weak protected local_unnamed_addr addrspace(4) externally_initialized constant %"struct.__HIP_Coordinates<__HIP_GridDim>::X" undef, comdat, align 1

; Function Attrs: nofree norecurse nounwind
define protected amdgpu_kernel void @_Z4fluxPdddPiS_S0_S0_S_S_S_S_S_S_S_S_S_S_S_S_iiiddd(double addrspace(1)* nocapture readonly %0, double %1, double %2, i32 addrspace(1)* nocapture readonly %3, double addrspace(1)* nocapture readonly %4, i32 addrspace(1)* nocapture readonly %5, i32 addrspace(1)* nocapture readonly %6, double addrspace(1)* nocapture readonly %7, double addrspace(1)* nocapture %8, double addrspace(1)* nocapture readonly %9, double addrspace(1)* nocapture readonly %10, double addrspace(1)* nocapture readonly %11, double addrspace(1)* nocapture readonly %12, double addrspace(1)* nocapture readonly %13, double addrspace(1)* nocapture %14, double addrspace(1)* nocapture readonly %15, double addrspace(1)* nocapture readonly %16, double addrspace(1)* nocapture readonly %17, double addrspace(1)* nocapture readnone %18, i32 %19, i32 %20, i32 %21, double %22, double %23, double %24) local_unnamed_addr #0 {
  %26 = tail call align 4 dereferenceable(64) i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #3
  %27 = getelementptr inbounds i8, i8 addrspace(4)* %26, i64 12
  %28 = bitcast i8 addrspace(4)* %27 to i32 addrspace(4)*
  %29 = load i32, i32 addrspace(4)* %28, align 4, !tbaa !5
  %30 = getelementptr i8, i8 addrspace(4)* %26, i64 4
  %31 = bitcast i8 addrspace(4)* %30 to i16 addrspace(4)*
  %32 = load i16, i16 addrspace(4)* %31, align 4, !range !14, !invariant.load !15
  %33 = tail call i32 @llvm.amdgcn.workgroup.id.x() #3
  %34 = zext i16 %32 to i32
  %35 = mul i32 %33, %34
  %36 = tail call i32 @llvm.amdgcn.workitem.id.x() #3, !range !16
  %37 = add i32 %35, %36
  %38 = icmp slt i32 %37, %19
  br i1 %38, label %39, label %1044

39:                                               ; preds = %25
  %40 = fdiv double %24, %22
  %41 = fdiv double %24, %23
  %42 = fmul double %1, %2
  %43 = fmul double %42, %2
  %44 = fneg double %40
  %45 = fmul double %1, 2.000000e+00
  %46 = icmp sgt i32 %20, -1
  br label %47

47:                                               ; preds = %1039, %39
  %48 = phi i32 [ %37, %39 ], [ %1042, %1039 ]
  %49 = freeze i32 %48
  %50 = freeze i32 %20
  %51 = sdiv i32 %49, %50
  %52 = mul i32 %51, %50
  %53 = sub i32 %49, %52
  %54 = icmp sgt i32 %51, 0
  %55 = icmp slt i32 %51, %21
  %56 = and i1 %54, %55
  %57 = sext i32 %48 to i64
  br i1 %56, label %58, label %544

58:                                               ; preds = %47
  %59 = getelementptr inbounds i32, i32 addrspace(1)* %3, i64 %57
  %60 = load i32, i32 addrspace(1)* %59, align 4, !tbaa !17
  %61 = icmp eq i32 %60, 0
  br i1 %61, label %544, label %62

62:                                               ; preds = %58
  %63 = sub nsw i32 %48, %20
  %64 = sext i32 %63 to i64
  %65 = getelementptr inbounds i32, i32 addrspace(1)* %3, i64 %64
  %66 = load i32, i32 addrspace(1)* %65, align 4, !tbaa !17
  %67 = icmp eq i32 %66, 0
  br i1 %67, label %544, label %68

68:                                               ; preds = %62
  %69 = getelementptr inbounds double, double addrspace(1)* %4, i64 %64
  %70 = load double, double addrspace(1)* %69, align 8, !tbaa !21
  %71 = load double, double addrspace(1)* %0, align 8, !tbaa !21
  %72 = fcmp ogt double %70, %71
  br i1 %72, label %77, label %73

73:                                               ; preds = %68
  %74 = getelementptr inbounds double, double addrspace(1)* %4, i64 %57
  %75 = load double, double addrspace(1)* %74, align 8, !tbaa !21
  %76 = fcmp ogt double %75, %71
  br i1 %76, label %77, label %544

77:                                               ; preds = %73, %68
  %78 = getelementptr inbounds i32, i32 addrspace(1)* %5, i64 %57
  %79 = load i32, i32 addrspace(1)* %78, align 4, !tbaa !17
  %80 = icmp eq i32 %79, 1
  br i1 %80, label %544, label %81

81:                                               ; preds = %77
  %82 = getelementptr inbounds double, double addrspace(1)* %4, i64 %57
  %83 = load double, double addrspace(1)* %82, align 8, !tbaa !21
  %84 = getelementptr inbounds double, double addrspace(1)* %7, i64 %57
  %85 = load double, double addrspace(1)* %84, align 8, !tbaa !21
  %86 = fadd double %83, %85
  %87 = getelementptr inbounds double, double addrspace(1)* %7, i64 %64
  %88 = load double, double addrspace(1)* %87, align 8, !tbaa !21
  %89 = fsub double %83, %71
  %90 = fsub double %70, %71
  %91 = fcmp olt double %86, %88
  br i1 %91, label %92, label %119

92:                                               ; preds = %81
  br i1 %72, label %93, label %544

93:                                               ; preds = %92
  %94 = fmul double %70, 5.440000e-01
  %95 = fmul double %70, %1
  %96 = fcmp olt double %95, 0x1000000000000000
  %97 = select i1 %96, double 0x4FF0000000000000, double 1.000000e+00
  %98 = fmul double %95, %97
  %99 = tail call double @llvm.amdgcn.rsq.f64(double %98) #3
  %100 = fmul double %98, %99
  %101 = fmul double %99, 5.000000e-01
  %102 = fneg double %101
  %103 = tail call double @llvm.fma.f64(double %102, double %100, double 5.000000e-01) #3
  %104 = tail call double @llvm.fma.f64(double %101, double %103, double %101) #3
  %105 = tail call double @llvm.fma.f64(double %100, double %103, double %100) #3
  %106 = fneg double %105
  %107 = tail call double @llvm.fma.f64(double %106, double %105, double %98) #3
  %108 = tail call double @llvm.fma.f64(double %107, double %104, double %105) #3
  %109 = fneg double %108
  %110 = tail call double @llvm.fma.f64(double %109, double %108, double %98) #3
  %111 = tail call double @llvm.fma.f64(double %110, double %104, double %108) #3
  %112 = select i1 %96, double 0x37F0000000000000, double 1.000000e+00
  %113 = fmul double %112, %111
  %114 = fcmp oeq double %98, 0.000000e+00
  %115 = fcmp oeq double %98, 0x7FF0000000000000
  %116 = or i1 %114, %115
  %117 = select i1 %116, double %98, double %113
  %118 = fmul double %94, %117
  br label %544

119:                                              ; preds = %81
  %120 = fadd double %70, %88
  %121 = fcmp olt double %120, %85
  br i1 %121, label %122, label %150

122:                                              ; preds = %119
  %123 = fcmp ogt double %83, %71
  br i1 %123, label %124, label %544

124:                                              ; preds = %122
  %125 = fmul double %83, -5.440000e-01
  %126 = fmul double %83, %1
  %127 = fcmp olt double %126, 0x1000000000000000
  %128 = select i1 %127, double 0x4FF0000000000000, double 1.000000e+00
  %129 = fmul double %126, %128
  %130 = tail call double @llvm.amdgcn.rsq.f64(double %129) #3
  %131 = fmul double %129, %130
  %132 = fmul double %130, 5.000000e-01
  %133 = fneg double %132
  %134 = tail call double @llvm.fma.f64(double %133, double %131, double 5.000000e-01) #3
  %135 = tail call double @llvm.fma.f64(double %132, double %134, double %132) #3
  %136 = tail call double @llvm.fma.f64(double %131, double %134, double %131) #3
  %137 = fneg double %136
  %138 = tail call double @llvm.fma.f64(double %137, double %136, double %129) #3
  %139 = tail call double @llvm.fma.f64(double %138, double %135, double %136) #3
  %140 = fneg double %139
  %141 = tail call double @llvm.fma.f64(double %140, double %139, double %129) #3
  %142 = tail call double @llvm.fma.f64(double %141, double %135, double %139) #3
  %143 = select i1 %127, double 0x37F0000000000000, double 1.000000e+00
  %144 = fmul double %143, %142
  %145 = fcmp oeq double %129, 0.000000e+00
  %146 = fcmp oeq double %129, 0x7FF0000000000000
  %147 = or i1 %145, %146
  %148 = select i1 %147, double %129, double %144
  %149 = fmul double %125, %148
  br label %544

150:                                              ; preds = %119
  %151 = fmul double %90, %89
  %152 = fcmp olt double %151, 0.000000e+00
  br i1 %152, label %153, label %191

153:                                              ; preds = %150
  %154 = fcmp ogt double %83, 0.000000e+00
  %155 = fcmp ogt double %70, 0.000000e+00
  %156 = or i1 %155, %154
  br i1 %156, label %157, label %544

157:                                              ; preds = %153
  %158 = fsub double %89, %90
  %159 = tail call double @llvm.fabs.f64(double %158) #3
  %160 = tail call double @llvm.maxnum.f64(double %86, double %120) #3
  %161 = tail call double @llvm.maxnum.f64(double %85, double %88) #3
  %162 = fsub double %160, %161
  %163 = fneg double %158
  %164 = fdiv double %163, %159
  %165 = fmul double %164, 3.500000e-01
  %166 = fmul double %165, %162
  %167 = fmul double %45, %162
  %168 = fcmp olt double %167, 0x1000000000000000
  %169 = select i1 %168, double 0x4FF0000000000000, double 1.000000e+00
  %170 = fmul double %167, %169
  %171 = tail call double @llvm.amdgcn.rsq.f64(double %170) #3
  %172 = fmul double %170, %171
  %173 = fmul double %171, 5.000000e-01
  %174 = fneg double %173
  %175 = tail call double @llvm.fma.f64(double %174, double %172, double 5.000000e-01) #3
  %176 = tail call double @llvm.fma.f64(double %173, double %175, double %173) #3
  %177 = tail call double @llvm.fma.f64(double %172, double %175, double %172) #3
  %178 = fneg double %177
  %179 = tail call double @llvm.fma.f64(double %178, double %177, double %170) #3
  %180 = tail call double @llvm.fma.f64(double %179, double %176, double %177) #3
  %181 = fneg double %180
  %182 = tail call double @llvm.fma.f64(double %181, double %180, double %170) #3
  %183 = tail call double @llvm.fma.f64(double %182, double %176, double %180) #3
  %184 = select i1 %168, double 0x37F0000000000000, double 1.000000e+00
  %185 = fmul double %184, %183
  %186 = fcmp oeq double %170, 0.000000e+00
  %187 = fcmp oeq double %170, 0x7FF0000000000000
  %188 = or i1 %186, %187
  %189 = select i1 %188, double %170, double %185
  %190 = fmul double %166, %189
  br label %544

191:                                              ; preds = %150
  %192 = getelementptr inbounds double, double addrspace(1)* %9, i64 %57
  %193 = load double, double addrspace(1)* %192, align 8, !tbaa !21
  %194 = fmul double %193, %1
  %195 = fmul double %40, %194
  %196 = fsub double %86, %70
  %197 = fsub double %196, %88
  %198 = fmul double %197, %195
  %199 = add nsw i32 %48, %20
  %200 = sext i32 %199 to i64
  %201 = getelementptr inbounds double, double addrspace(1)* %10, i64 %200
  %202 = load double, double addrspace(1)* %201, align 8, !tbaa !21
  %203 = getelementptr inbounds double, double addrspace(1)* %10, i64 %57
  %204 = load double, double addrspace(1)* %203, align 8, !tbaa !21
  %205 = fadd double %202, %204
  %206 = fmul double %205, 5.000000e-01
  %207 = getelementptr inbounds double, double addrspace(1)* %10, i64 %64
  %208 = load double, double addrspace(1)* %207, align 8, !tbaa !21
  %209 = fadd double %204, %208
  %210 = fmul double %209, 5.000000e-01
  %211 = getelementptr inbounds double, double addrspace(1)* %11, i64 %200
  %212 = load double, double addrspace(1)* %211, align 8, !tbaa !21
  %213 = getelementptr inbounds double, double addrspace(1)* %11, i64 %57
  %214 = load double, double addrspace(1)* %213, align 8, !tbaa !21
  %215 = fadd double %212, %214
  %216 = fmul double %206, %215
  %217 = fmul double %216, 5.000000e-01
  %218 = tail call double @llvm.fabs.f64(double %206) #3
  %219 = fsub double %214, %212
  %220 = fmul double %218, %219
  %221 = fmul double %220, 5.000000e-01
  %222 = fadd double %217, %221
  %223 = getelementptr inbounds double, double addrspace(1)* %11, i64 %64
  %224 = load double, double addrspace(1)* %223, align 8, !tbaa !21
  %225 = fadd double %214, %224
  %226 = fmul double %210, %225
  %227 = fmul double %226, 5.000000e-01
  %228 = tail call double @llvm.fabs.f64(double %210) #3
  %229 = fsub double %224, %214
  %230 = fmul double %228, %229
  %231 = fmul double %230, 5.000000e-01
  %232 = fadd double %227, %231
  %233 = fsub double %222, %232
  %234 = icmp eq i32 %53, 0
  br i1 %234, label %276, label %235

235:                                              ; preds = %191
  %236 = add nsw i32 %48, 1
  %237 = sext i32 %236 to i64
  %238 = getelementptr inbounds double, double addrspace(1)* %12, i64 %237
  %239 = load double, double addrspace(1)* %238, align 8, !tbaa !21
  %240 = add nsw i32 %63, 1
  %241 = sext i32 %240 to i64
  %242 = getelementptr inbounds double, double addrspace(1)* %12, i64 %241
  %243 = load double, double addrspace(1)* %242, align 8, !tbaa !21
  %244 = fadd double %239, %243
  %245 = fmul double %244, 5.000000e-01
  %246 = getelementptr inbounds double, double addrspace(1)* %12, i64 %57
  %247 = load double, double addrspace(1)* %246, align 8, !tbaa !21
  %248 = getelementptr inbounds double, double addrspace(1)* %12, i64 %64
  %249 = load double, double addrspace(1)* %248, align 8, !tbaa !21
  %250 = fadd double %247, %249
  %251 = fmul double %250, 5.000000e-01
  %252 = getelementptr inbounds double, double addrspace(1)* %11, i64 %237
  %253 = load double, double addrspace(1)* %252, align 8, !tbaa !21
  %254 = fadd double %214, %253
  %255 = fmul double %245, %254
  %256 = fmul double %255, 5.000000e-01
  %257 = tail call double @llvm.fabs.f64(double %245) #3
  %258 = fsub double %214, %253
  %259 = fmul double %257, %258
  %260 = fmul double %259, 5.000000e-01
  %261 = fadd double %256, %260
  %262 = add nsw i32 %48, -1
  %263 = sext i32 %262 to i64
  %264 = getelementptr inbounds double, double addrspace(1)* %11, i64 %263
  %265 = load double, double addrspace(1)* %264, align 8, !tbaa !21
  %266 = fadd double %214, %265
  %267 = fmul double %251, %266
  %268 = fmul double %267, 5.000000e-01
  %269 = tail call double @llvm.fabs.f64(double %251) #3
  %270 = fsub double %265, %214
  %271 = fmul double %269, %270
  %272 = fmul double %271, 5.000000e-01
  %273 = fadd double %268, %272
  %274 = fsub double %261, %273
  %275 = fmul double %41, %274
  br label %276

276:                                              ; preds = %235, %191
  %277 = phi double [ 0.000000e+00, %191 ], [ %275, %235 ]
  %278 = fmul double %204, %204
  %279 = getelementptr inbounds double, double addrspace(1)* %13, i64 %57
  %280 = load double, double addrspace(1)* %279, align 8, !tbaa !21
  %281 = fmul double %280, %280
  %282 = fadd double %278, %281
  %283 = fcmp olt double %282, 0x1000000000000000
  %284 = select i1 %283, double 0x4FF0000000000000, double 1.000000e+00
  %285 = fmul double %282, %284
  %286 = tail call double @llvm.amdgcn.rsq.f64(double %285) #3
  %287 = fmul double %285, %286
  %288 = fmul double %286, 5.000000e-01
  %289 = fneg double %288
  %290 = tail call double @llvm.fma.f64(double %289, double %287, double 5.000000e-01) #3
  %291 = tail call double @llvm.fma.f64(double %288, double %290, double %288) #3
  %292 = tail call double @llvm.fma.f64(double %287, double %290, double %287) #3
  %293 = fneg double %292
  %294 = tail call double @llvm.fma.f64(double %293, double %292, double %285) #3
  %295 = tail call double @llvm.fma.f64(double %294, double %291, double %292) #3
  %296 = fneg double %295
  %297 = tail call double @llvm.fma.f64(double %296, double %295, double %285) #3
  %298 = tail call double @llvm.fma.f64(double %297, double %291, double %295) #3
  %299 = select i1 %283, double 0x37F0000000000000, double 1.000000e+00
  %300 = fmul double %299, %298
  %301 = fcmp oeq double %285, 0.000000e+00
  %302 = fcmp oeq double %285, 0x7FF0000000000000
  %303 = or i1 %301, %302
  %304 = select i1 %303, double %285, double %300
  %305 = tail call double @llvm.fabs.f64(double %193) #3
  %306 = tail call double @llvm.amdgcn.frexp.mant.f64(double %305) #3
  %307 = fcmp olt double %306, 0x3FE5555555555555
  %308 = zext i1 %307 to i32
  %309 = tail call double @llvm.amdgcn.ldexp.f64(double %306, i32 %308) #3
  %310 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %305) #3
  %311 = sub nsw i32 %310, %308
  %312 = fadd double %309, -1.000000e+00
  %313 = fadd double %309, 1.000000e+00
  %314 = fsub double %313, %309
  %315 = fsub double %313, %314
  %316 = fsub double %309, %315
  %317 = fsub double 1.000000e+00, %314
  %318 = fadd double %317, %316
  %319 = tail call double @llvm.amdgcn.rcp.f64(double %313) #3
  %320 = fneg double %313
  %321 = tail call double @llvm.fma.f64(double %320, double %319, double 1.000000e+00) #3
  %322 = tail call double @llvm.fma.f64(double %321, double %319, double %319) #3
  %323 = tail call double @llvm.fma.f64(double %320, double %322, double 1.000000e+00) #3
  %324 = tail call double @llvm.fma.f64(double %323, double %322, double %322) #3
  %325 = fmul double %312, %324
  %326 = fmul double %313, %325
  %327 = fneg double %326
  %328 = tail call double @llvm.fma.f64(double %325, double %313, double %327) #3
  %329 = tail call double @llvm.fma.f64(double %325, double %318, double %328) #3
  %330 = fadd double %326, %329
  %331 = fsub double %330, %326
  %332 = fsub double %329, %331
  %333 = fsub double %312, %330
  %334 = fsub double %312, %333
  %335 = fsub double %334, %330
  %336 = fsub double %335, %332
  %337 = fadd double %333, %336
  %338 = fmul double %324, %337
  %339 = fadd double %325, %338
  %340 = fsub double %339, %325
  %341 = fsub double %338, %340
  %342 = fmul double %339, %339
  %343 = fneg double %342
  %344 = tail call double @llvm.fma.f64(double %339, double %339, double %343) #3
  %345 = fmul double %341, 2.000000e+00
  %346 = tail call double @llvm.fma.f64(double %339, double %345, double %344) #3
  %347 = tail call double @llvm.fma.f64(double %341, double %341, double %346) #3
  %348 = fadd double %342, %347
  %349 = fsub double %348, %342
  %350 = fsub double %347, %349
  %351 = tail call double @llvm.fma.f64(double %348, double 0x3FBDEE674222DE17, double 0x3FBA6564968915A9) #3
  %352 = tail call double @llvm.fma.f64(double %348, double %351, double 0x3FBE25E43ABE935A) #3
  %353 = tail call double @llvm.fma.f64(double %348, double %352, double 0x3FC110EF47E6C9C2) #3
  %354 = tail call double @llvm.fma.f64(double %348, double %353, double 0x3FC3B13BCFA74449) #3
  %355 = tail call double @llvm.fma.f64(double %348, double %354, double 0x3FC745D171BF3C30) #3
  %356 = tail call double @llvm.fma.f64(double %348, double %355, double 0x3FCC71C71C7792CE) #3
  %357 = tail call double @llvm.fma.f64(double %348, double %356, double 0x3FD24924924920DA) #3
  %358 = tail call double @llvm.fma.f64(double %348, double %357, double 0x3FD999999999999C) #3
  %359 = sitofp i32 %311 to double
  %360 = fmul double %359, 0x3FE62E42FEFA39EF
  %361 = fneg double %360
  %362 = tail call double @llvm.fma.f64(double %359, double 0x3FE62E42FEFA39EF, double %361) #3
  %363 = tail call double @llvm.fma.f64(double %359, double 0x3C7ABC9E3B39803F, double %362) #3
  %364 = fadd double %360, %363
  %365 = fsub double %364, %360
  %366 = fsub double %363, %365
  %367 = tail call double @llvm.amdgcn.ldexp.f64(double %339, i32 1) #3
  %368 = tail call double @llvm.amdgcn.ldexp.f64(double %341, i32 1) #3
  %369 = fmul double %339, %348
  %370 = fneg double %369
  %371 = tail call double @llvm.fma.f64(double %348, double %339, double %370) #3
  %372 = fmul double %339, %350
  %373 = tail call double @llvm.fma.f64(double %348, double %341, double %372) #3
  %374 = fadd double %371, %373
  %375 = fadd double %369, %374
  %376 = fsub double %375, %369
  %377 = fsub double %374, %376
  %378 = fmul double %348, %358
  %379 = fneg double %378
  %380 = tail call double @llvm.fma.f64(double %348, double %358, double %379) #3
  %381 = tail call double @llvm.fma.f64(double %350, double %358, double %380) #3
  %382 = fadd double %378, %381
  %383 = fsub double %382, %378
  %384 = fsub double %381, %383
  %385 = fadd double %382, 0x3FE5555555555555
  %386 = fadd double %385, 0xBFE5555555555555
  %387 = fsub double %382, %386
  %388 = fadd double %384, 0x3C8543B0D5DF274D
  %389 = fadd double %387, %388
  %390 = fadd double %385, %389
  %391 = fsub double %390, %385
  %392 = fsub double %389, %391
  %393 = fmul double %375, %390
  %394 = fneg double %393
  %395 = fmul double %377, %390
  %396 = insertelement <2 x double> undef, double %375, i32 0
  %397 = shufflevector <2 x double> %396, <2 x double> undef, <2 x i32> zeroinitializer
  %398 = insertelement <2 x double> undef, double %390, i32 0
  %399 = insertelement <2 x double> %398, double %392, i32 1
  %400 = insertelement <2 x double> undef, double %394, i32 0
  %401 = insertelement <2 x double> %400, double %395, i32 1
  %402 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %397, <2 x double> %399, <2 x double> %401) #3
  %403 = extractelement <2 x double> %402, i32 0
  %404 = extractelement <2 x double> %402, i32 1
  %405 = fadd double %403, %404
  %406 = fadd double %393, %405
  %407 = fsub double %406, %393
  %408 = fsub double %405, %407
  %409 = fadd double %367, %406
  %410 = fsub double %409, %367
  %411 = fsub double %406, %410
  %412 = fadd double %368, %408
  %413 = fadd double %411, %412
  %414 = fadd double %409, %413
  %415 = fsub double %414, %409
  %416 = fsub double %413, %415
  %417 = fadd double %364, %414
  %418 = fsub double %417, %364
  %419 = fsub double %417, %418
  %420 = fsub double %364, %419
  %421 = fsub double %414, %418
  %422 = fadd double %421, %420
  %423 = fadd double %366, %416
  %424 = fsub double %423, %366
  %425 = fsub double %423, %424
  %426 = fsub double %366, %425
  %427 = fsub double %416, %424
  %428 = fadd double %427, %426
  %429 = fadd double %423, %422
  %430 = fadd double %417, %429
  %431 = fsub double %430, %417
  %432 = fsub double %429, %431
  %433 = fadd double %428, %432
  %434 = fadd double %430, %433
  %435 = fsub double %434, %430
  %436 = fsub double %433, %435
  %437 = fmul double %434, 0x3FF55554FBDAD752
  %438 = fneg double %437
  %439 = tail call double @llvm.fma.f64(double %434, double 0x3FF55554FBDAD752, double %438) #3
  %440 = tail call double @llvm.fma.f64(double %436, double 0x3FF55554FBDAD752, double %439) #3
  %441 = fadd double %437, %440
  %442 = fsub double %441, %437
  %443 = fsub double %440, %442
  %444 = tail call double @llvm.fabs.f64(double %437) #4
  %445 = fcmp oeq double %444, 0x7FF0000000000000
  %446 = select i1 %445, double %437, double %441
  %447 = tail call double @llvm.fabs.f64(double %446) #4
  %448 = fcmp oeq double %447, 0x7FF0000000000000
  %449 = select i1 %448, double 0.000000e+00, double %443
  %450 = fmul double %446, 0x3FF71547652B82FE
  %451 = tail call double @llvm.rint.f64(double %450) #3
  %452 = fmul double %451, 0x3FE62E42FEFA3000
  %453 = fsub double %446, %452
  %454 = fsub double %453, %446
  %455 = fsub double %453, %454
  %456 = fsub double %446, %455
  %457 = fadd double %452, %454
  %458 = fsub double %456, %457
  %459 = fadd double %449, %458
  %460 = fadd double %453, %459
  %461 = fsub double %460, %453
  %462 = fsub double %459, %461
  %463 = fmul double %451, 0x3D53DE6AF278E000
  %464 = fsub double %460, %463
  %465 = fsub double %460, %464
  %466 = fsub double %465, %463
  %467 = fadd double %462, %466
  %468 = fadd double %464, %467
  %469 = fsub double %468, %464
  %470 = fsub double %467, %469
  %471 = fmul double %451, 0x3AC9CC01F97B57A0
  %472 = fsub double %468, %471
  %473 = fsub double %468, %472
  %474 = fsub double %473, %471
  %475 = fadd double %470, %474
  %476 = fadd double %472, %475
  %477 = fsub double %476, %472
  %478 = fsub double %475, %477
  %479 = tail call double @llvm.fma.f64(double %476, double 0x3E5ADE156A5DCB37, double 0x3E928AF3FCA7AB0C) #3
  %480 = tail call double @llvm.fma.f64(double %476, double %479, double 0x3EC71DEE623FDE64) #3
  %481 = tail call double @llvm.fma.f64(double %476, double %480, double 0x3EFA01997C89E6B0) #3
  %482 = tail call double @llvm.fma.f64(double %476, double %481, double 0x3F2A01A014761F6E) #3
  %483 = tail call double @llvm.fma.f64(double %476, double %482, double 0x3F56C16C1852B7B0) #3
  %484 = tail call double @llvm.fma.f64(double %476, double %483, double 0x3F81111111122322) #3
  %485 = tail call double @llvm.fma.f64(double %476, double %484, double 0x3FA55555555502A1) #3
  %486 = tail call double @llvm.fma.f64(double %476, double %485, double 0x3FC5555555555511) #3
  %487 = tail call double @llvm.fma.f64(double %476, double %486, double 0x3FE000000000000B) #3
  %488 = fmul double %476, %476
  %489 = fneg double %488
  %490 = tail call double @llvm.fma.f64(double %476, double %476, double %489) #3
  %491 = fmul double %478, 2.000000e+00
  %492 = tail call double @llvm.fma.f64(double %476, double %491, double %490) #3
  %493 = tail call double @llvm.fma.f64(double %478, double %478, double %492) #3
  %494 = fadd double %488, %493
  %495 = fsub double %494, %488
  %496 = fsub double %493, %495
  %497 = fmul double %494, %487
  %498 = fneg double %497
  %499 = tail call double @llvm.fma.f64(double %494, double %487, double %498) #3
  %500 = tail call double @llvm.fma.f64(double %496, double %487, double %499) #3
  %501 = fadd double %497, %500
  %502 = fsub double %501, %497
  %503 = fsub double %500, %502
  %504 = fadd double %476, %501
  %505 = fsub double %504, %476
  %506 = fsub double %501, %505
  %507 = fadd double %478, %503
  %508 = fadd double %506, %507
  %509 = fadd double %504, %508
  %510 = fadd double %509, 1.000000e+00
  %511 = fptosi double %451 to i32
  %512 = tail call double @llvm.amdgcn.ldexp.f64(double %510, i32 %511) #3
  %513 = fcmp ogt double %446, 7.100000e+02
  %514 = select i1 %513, double 0x7FF0000000000000, double %512
  %515 = fcmp olt double %446, -7.450000e+02
  %516 = select i1 %515, double 0.000000e+00, double %514
  %517 = fcmp uno double %193, 0.000000e+00
  %518 = tail call i1 @llvm.amdgcn.class.f64(double %193, i32 512) #3
  %519 = tail call i1 @llvm.amdgcn.class.f64(double %193, i32 4) #3
  %520 = or i1 %518, %519
  %521 = fcmp oeq double %193, 0.000000e+00
  %522 = tail call i1 @llvm.amdgcn.class.f64(double %193, i32 960) #3
  %523 = tail call double @llvm.fabs.f64(double %516) #3
  %524 = select i1 %522, double %523, double 0x7FF8000000000000
  %525 = select i1 %521, double 0.000000e+00, double %524
  %526 = select i1 %520, double 0x7FF0000000000000, double %525
  %527 = select i1 %517, double %193, double %526
  %528 = fcmp oeq double %193, 1.000000e+00
  %529 = select i1 %528, double 1.000000e+00, double %527
  %530 = fmul double %43, %304
  %531 = fdiv double %530, %529
  %532 = fcmp ugt double %193, %71
  %533 = select i1 %532, double %531, double 0.000000e+00
  %534 = fmul double %533, %24
  %535 = fmul double %534, 5.000000e-01
  %536 = fsub double 1.000000e+00, %535
  %537 = fmul double %214, %536
  %538 = fmul double %233, %44
  %539 = fsub double %538, %277
  %540 = fsub double %539, %198
  %541 = fadd double %540, %537
  %542 = fadd double %535, 1.000000e+00
  %543 = fdiv double %541, %542
  br label %544

544:                                              ; preds = %276, %157, %153, %124, %122, %93, %92, %77, %73, %62, %58, %47
  %545 = phi double [ 0.000000e+00, %47 ], [ 0.000000e+00, %58 ], [ 0.000000e+00, %62 ], [ 0.000000e+00, %73 ], [ 0.000000e+00, %77 ], [ 0.000000e+00, %92 ], [ %118, %93 ], [ 0.000000e+00, %122 ], [ %149, %124 ], [ 0.000000e+00, %153 ], [ %190, %157 ], [ %543, %276 ]
  %546 = getelementptr inbounds double, double addrspace(1)* %8, i64 %57
  store double %545, double addrspace(1)* %546, align 8, !tbaa !21
  %547 = icmp sgt i32 %53, 0
  %548 = and i1 %46, %547
  br i1 %548, label %549, label %1039

549:                                              ; preds = %544
  %550 = getelementptr inbounds i32, i32 addrspace(1)* %3, i64 %57
  %551 = load i32, i32 addrspace(1)* %550, align 4, !tbaa !17
  %552 = icmp eq i32 %551, 0
  br i1 %552, label %1039, label %553

553:                                              ; preds = %549
  %554 = add nsw i32 %48, -1
  %555 = sext i32 %554 to i64
  %556 = getelementptr inbounds i32, i32 addrspace(1)* %3, i64 %555
  %557 = load i32, i32 addrspace(1)* %556, align 4, !tbaa !17
  %558 = icmp eq i32 %557, 0
  br i1 %558, label %1039, label %559

559:                                              ; preds = %553
  %560 = getelementptr inbounds double, double addrspace(1)* %4, i64 %555
  %561 = load double, double addrspace(1)* %560, align 8, !tbaa !21
  %562 = load double, double addrspace(1)* %0, align 8, !tbaa !21
  %563 = fcmp ogt double %561, %562
  br i1 %563, label %568, label %564

564:                                              ; preds = %559
  %565 = getelementptr inbounds double, double addrspace(1)* %4, i64 %57
  %566 = load double, double addrspace(1)* %565, align 8, !tbaa !21
  %567 = fcmp ogt double %566, %562
  br i1 %567, label %568, label %1039

568:                                              ; preds = %564, %559
  %569 = getelementptr inbounds i32, i32 addrspace(1)* %6, i64 %57
  %570 = load i32, i32 addrspace(1)* %569, align 4, !tbaa !17
  %571 = icmp eq i32 %570, 1
  br i1 %571, label %1039, label %572

572:                                              ; preds = %568
  %573 = getelementptr inbounds double, double addrspace(1)* %4, i64 %57
  %574 = load double, double addrspace(1)* %573, align 8, !tbaa !21
  %575 = getelementptr inbounds double, double addrspace(1)* %7, i64 %57
  %576 = load double, double addrspace(1)* %575, align 8, !tbaa !21
  %577 = fadd double %574, %576
  %578 = getelementptr inbounds double, double addrspace(1)* %7, i64 %555
  %579 = load double, double addrspace(1)* %578, align 8, !tbaa !21
  %580 = fsub double %574, %562
  %581 = fsub double %561, %562
  %582 = fcmp olt double %577, %579
  br i1 %582, label %583, label %610

583:                                              ; preds = %572
  br i1 %563, label %584, label %1039

584:                                              ; preds = %583
  %585 = fmul double %561, 5.440000e-01
  %586 = fmul double %561, %1
  %587 = fcmp olt double %586, 0x1000000000000000
  %588 = select i1 %587, double 0x4FF0000000000000, double 1.000000e+00
  %589 = fmul double %586, %588
  %590 = tail call double @llvm.amdgcn.rsq.f64(double %589) #3
  %591 = fmul double %589, %590
  %592 = fmul double %590, 5.000000e-01
  %593 = fneg double %592
  %594 = tail call double @llvm.fma.f64(double %593, double %591, double 5.000000e-01) #3
  %595 = tail call double @llvm.fma.f64(double %592, double %594, double %592) #3
  %596 = tail call double @llvm.fma.f64(double %591, double %594, double %591) #3
  %597 = fneg double %596
  %598 = tail call double @llvm.fma.f64(double %597, double %596, double %589) #3
  %599 = tail call double @llvm.fma.f64(double %598, double %595, double %596) #3
  %600 = fneg double %599
  %601 = tail call double @llvm.fma.f64(double %600, double %599, double %589) #3
  %602 = tail call double @llvm.fma.f64(double %601, double %595, double %599) #3
  %603 = select i1 %587, double 0x37F0000000000000, double 1.000000e+00
  %604 = fmul double %603, %602
  %605 = fcmp oeq double %589, 0.000000e+00
  %606 = fcmp oeq double %589, 0x7FF0000000000000
  %607 = or i1 %605, %606
  %608 = select i1 %607, double %589, double %604
  %609 = fmul double %585, %608
  br label %1039

610:                                              ; preds = %572
  %611 = fadd double %561, %579
  %612 = fcmp olt double %611, %576
  br i1 %612, label %613, label %641

613:                                              ; preds = %610
  %614 = fcmp ogt double %574, %562
  br i1 %614, label %615, label %1039

615:                                              ; preds = %613
  %616 = fmul double %574, -5.440000e-01
  %617 = fmul double %574, %1
  %618 = fcmp olt double %617, 0x1000000000000000
  %619 = select i1 %618, double 0x4FF0000000000000, double 1.000000e+00
  %620 = fmul double %617, %619
  %621 = tail call double @llvm.amdgcn.rsq.f64(double %620) #3
  %622 = fmul double %620, %621
  %623 = fmul double %621, 5.000000e-01
  %624 = fneg double %623
  %625 = tail call double @llvm.fma.f64(double %624, double %622, double 5.000000e-01) #3
  %626 = tail call double @llvm.fma.f64(double %623, double %625, double %623) #3
  %627 = tail call double @llvm.fma.f64(double %622, double %625, double %622) #3
  %628 = fneg double %627
  %629 = tail call double @llvm.fma.f64(double %628, double %627, double %620) #3
  %630 = tail call double @llvm.fma.f64(double %629, double %626, double %627) #3
  %631 = fneg double %630
  %632 = tail call double @llvm.fma.f64(double %631, double %630, double %620) #3
  %633 = tail call double @llvm.fma.f64(double %632, double %626, double %630) #3
  %634 = select i1 %618, double 0x37F0000000000000, double 1.000000e+00
  %635 = fmul double %634, %633
  %636 = fcmp oeq double %620, 0.000000e+00
  %637 = fcmp oeq double %620, 0x7FF0000000000000
  %638 = or i1 %636, %637
  %639 = select i1 %638, double %620, double %635
  %640 = fmul double %616, %639
  br label %1039

641:                                              ; preds = %610
  %642 = fmul double %581, %580
  %643 = fcmp olt double %642, 0.000000e+00
  br i1 %643, label %644, label %fusion.common

644:                                              ; preds = %641
  %645 = fcmp ogt double %574, 0.000000e+00
  %646 = fcmp ogt double %561, 0.000000e+00
  %647 = or i1 %646, %645
  br i1 %647, label %648, label %1039

648:                                              ; preds = %644
  %649 = fsub double %580, %581
  %650 = tail call double @llvm.fabs.f64(double %649) #3
  %651 = tail call double @llvm.maxnum.f64(double %577, double %611) #3
  %652 = tail call double @llvm.maxnum.f64(double %576, double %579) #3
  %653 = fsub double %651, %652
  %654 = fneg double %649
  %655 = fdiv double %654, %650
  %656 = fmul double %655, 3.500000e-01
  %657 = fmul double %656, %653
  %658 = fmul double %45, %653
  %659 = fcmp olt double %658, 0x1000000000000000
  %660 = select i1 %659, double 0x4FF0000000000000, double 1.000000e+00
  %661 = fmul double %658, %660
  %662 = tail call double @llvm.amdgcn.rsq.f64(double %661) #3
  %663 = fmul double %661, %662
  %664 = fmul double %662, 5.000000e-01
  %665 = fneg double %664
  %666 = tail call double @llvm.fma.f64(double %665, double %663, double 5.000000e-01) #3
  %667 = tail call double @llvm.fma.f64(double %664, double %666, double %664) #3
  %668 = tail call double @llvm.fma.f64(double %663, double %666, double %663) #3
  %669 = fneg double %668
  %670 = tail call double @llvm.fma.f64(double %669, double %668, double %661) #3
  %671 = tail call double @llvm.fma.f64(double %670, double %667, double %668) #3
  %672 = fneg double %671
  %673 = tail call double @llvm.fma.f64(double %672, double %671, double %661) #3
  %674 = tail call double @llvm.fma.f64(double %673, double %667, double %671) #3
  %675 = select i1 %659, double 0x37F0000000000000, double 1.000000e+00
  %676 = fmul double %675, %674
  %677 = fcmp oeq double %661, 0.000000e+00
  %678 = fcmp oeq double %661, 0x7FF0000000000000
  %679 = or i1 %677, %678
  %680 = select i1 %679, double %661, double %676
  %681 = fmul double %657, %680
  br label %1039

fusion.common:                                    ; preds = %641
  %682 = getelementptr inbounds double, double addrspace(1)* %15, i64 %57
  %683 = load double, double addrspace(1)* %682, align 8, !tbaa !21
  %684 = fmul double %683, %1
  %685 = fmul double %41, %684
  %686 = fsub double %577, %561
  %687 = fsub double %686, %579
  %688 = fmul double %687, %685
  %689 = icmp eq i32 %51, 0
  %690 = icmp eq i32 %51, %21
  %691 = or i1 %689, %690
  %692 = add nsw i32 %48, %20
  %693 = sext i32 %692 to i64
  %694 = select i1 %691, double addrspace(1)* %16, double addrspace(1)* %10
  %695 = select i1 %691, i64 %57, i64 %693
  %696 = getelementptr inbounds double, double addrspace(1)* %694, i64 %695
  %697 = load double, double addrspace(1)* %696, align 8, !tbaa !21
  br i1 %691, label %736, label %fusion.side1

fusion.side1:                                     ; preds = %fusion.common
  %698 = add nsw i32 %692, -1
  %699 = sext i32 %698 to i64
  %700 = getelementptr inbounds double, double addrspace(1)* %10, i64 %699
  %701 = load double, double addrspace(1)* %700, align 8, !tbaa !21
  %702 = fadd double %697, %701
  %703 = fmul double %702, 5.000000e-01
  %704 = getelementptr inbounds double, double addrspace(1)* %10, i64 %57
  %705 = load double, double addrspace(1)* %704, align 8, !tbaa !21
  %706 = getelementptr inbounds double, double addrspace(1)* %10, i64 %555
  %707 = load double, double addrspace(1)* %706, align 8, !tbaa !21
  %708 = fadd double %705, %707
  %709 = fmul double %708, 5.000000e-01
  %710 = getelementptr inbounds double, double addrspace(1)* %16, i64 %693
  %711 = load double, double addrspace(1)* %710, align 8, !tbaa !21
  %712 = getelementptr inbounds double, double addrspace(1)* %16, i64 %57
  %713 = load double, double addrspace(1)* %712, align 8, !tbaa !21
  %714 = fadd double %711, %713
  %715 = fmul double %703, %714
  %716 = fmul double %715, 5.000000e-01
  %717 = tail call double @llvm.fabs.f64(double %703) #3
  %718 = fsub double %713, %711
  %719 = fmul double %717, %718
  %720 = fmul double %719, 5.000000e-01
  %721 = fadd double %716, %720
  %722 = sub nsw i32 %48, %20
  %723 = sext i32 %722 to i64
  %724 = getelementptr inbounds double, double addrspace(1)* %16, i64 %723
  %725 = load double, double addrspace(1)* %724, align 8, !tbaa !21
  %726 = fadd double %713, %725
  %727 = fmul double %709, %726
  %728 = fmul double %727, 5.000000e-01
  %729 = tail call double @llvm.fabs.f64(double %709) #3
  %730 = fsub double %725, %713
  %731 = fmul double %729, %730
  %732 = fmul double %731, 5.000000e-01
  %733 = fadd double %728, %732
  %734 = fsub double %721, %733
  %735 = fmul double %40, %734
  br label %736

736:                                              ; preds = %fusion.side1, %fusion.common
  %737 = phi double [ %697, %fusion.common ], [ %713, %fusion.side1 ]
  %738 = phi double [ 0.000000e+00, %fusion.common ], [ %735, %fusion.side1 ]
  %739 = add nsw i32 %48, 1
  %740 = sext i32 %739 to i64
  %741 = getelementptr inbounds double, double addrspace(1)* %12, i64 %740
  %742 = load double, double addrspace(1)* %741, align 8, !tbaa !21
  %743 = getelementptr inbounds double, double addrspace(1)* %12, i64 %57
  %744 = load double, double addrspace(1)* %743, align 8, !tbaa !21
  %745 = fadd double %742, %744
  %746 = fmul double %745, 5.000000e-01
  %747 = getelementptr inbounds double, double addrspace(1)* %12, i64 %555
  %748 = load double, double addrspace(1)* %747, align 8, !tbaa !21
  %749 = fadd double %744, %748
  %750 = fmul double %749, 5.000000e-01
  %751 = getelementptr inbounds double, double addrspace(1)* %16, i64 %740
  %752 = load double, double addrspace(1)* %751, align 8, !tbaa !21
  %753 = fadd double %752, %737
  %754 = fmul double %746, %753
  %755 = fmul double %754, 5.000000e-01
  %756 = tail call double @llvm.fabs.f64(double %746) #3
  %757 = fsub double %737, %752
  %758 = fmul double %756, %757
  %759 = fmul double %758, 5.000000e-01
  %760 = fadd double %755, %759
  %761 = getelementptr inbounds double, double addrspace(1)* %16, i64 %555
  %762 = load double, double addrspace(1)* %761, align 8, !tbaa !21
  %763 = fadd double %737, %762
  %764 = fmul double %750, %763
  %765 = fmul double %764, 5.000000e-01
  %766 = tail call double @llvm.fabs.f64(double %750) #3
  %767 = fsub double %762, %737
  %768 = fmul double %766, %767
  %769 = fmul double %768, 5.000000e-01
  %770 = fadd double %765, %769
  %771 = fsub double %760, %770
  %772 = fmul double %41, %771
  %773 = getelementptr inbounds double, double addrspace(1)* %17, i64 %57
  %774 = load double, double addrspace(1)* %773, align 8, !tbaa !21
  %775 = fmul double %774, %774
  %776 = fmul double %744, %744
  %777 = fadd double %776, %775
  %778 = fcmp olt double %777, 0x1000000000000000
  %779 = select i1 %778, double 0x4FF0000000000000, double 1.000000e+00
  %780 = fmul double %777, %779
  %781 = tail call double @llvm.amdgcn.rsq.f64(double %780) #3
  %782 = fmul double %780, %781
  %783 = fmul double %781, 5.000000e-01
  %784 = fneg double %783
  %785 = tail call double @llvm.fma.f64(double %784, double %782, double 5.000000e-01) #3
  %786 = tail call double @llvm.fma.f64(double %783, double %785, double %783) #3
  %787 = tail call double @llvm.fma.f64(double %782, double %785, double %782) #3
  %788 = fneg double %787
  %789 = tail call double @llvm.fma.f64(double %788, double %787, double %780) #3
  %790 = tail call double @llvm.fma.f64(double %789, double %786, double %787) #3
  %791 = fneg double %790
  %792 = tail call double @llvm.fma.f64(double %791, double %790, double %780) #3
  %793 = tail call double @llvm.fma.f64(double %792, double %786, double %790) #3
  %794 = select i1 %778, double 0x37F0000000000000, double 1.000000e+00
  %795 = fmul double %794, %793
  %796 = fcmp oeq double %780, 0.000000e+00
  %797 = fcmp oeq double %780, 0x7FF0000000000000
  %798 = or i1 %796, %797
  %799 = select i1 %798, double %780, double %795
  %800 = tail call double @llvm.fabs.f64(double %683) #3
  %801 = tail call double @llvm.amdgcn.frexp.mant.f64(double %800) #3
  %802 = fcmp olt double %801, 0x3FE5555555555555
  %803 = zext i1 %802 to i32
  %804 = tail call double @llvm.amdgcn.ldexp.f64(double %801, i32 %803) #3
  %805 = tail call i32 @llvm.amdgcn.frexp.exp.i32.f64(double %800) #3
  %806 = sub nsw i32 %805, %803
  %807 = fadd double %804, -1.000000e+00
  %808 = fadd double %804, 1.000000e+00
  %809 = fsub double %808, %804
  %810 = fsub double %808, %809
  %811 = fsub double %804, %810
  %812 = fsub double 1.000000e+00, %809
  %813 = fadd double %812, %811
  %814 = tail call double @llvm.amdgcn.rcp.f64(double %808) #3
  %815 = fneg double %808
  %816 = tail call double @llvm.fma.f64(double %815, double %814, double 1.000000e+00) #3
  %817 = tail call double @llvm.fma.f64(double %816, double %814, double %814) #3
  %818 = tail call double @llvm.fma.f64(double %815, double %817, double 1.000000e+00) #3
  %819 = tail call double @llvm.fma.f64(double %818, double %817, double %817) #3
  %820 = fmul double %807, %819
  %821 = fmul double %808, %820
  %822 = fneg double %821
  %823 = tail call double @llvm.fma.f64(double %820, double %808, double %822) #3
  %824 = tail call double @llvm.fma.f64(double %820, double %813, double %823) #3
  %825 = fadd double %821, %824
  %826 = fsub double %825, %821
  %827 = fsub double %824, %826
  %828 = fsub double %807, %825
  %829 = fsub double %807, %828
  %830 = fsub double %829, %825
  %831 = fsub double %830, %827
  %832 = fadd double %828, %831
  %833 = fmul double %819, %832
  %834 = fadd double %820, %833
  %835 = fsub double %834, %820
  %836 = fsub double %833, %835
  %837 = fmul double %834, %834
  %838 = fneg double %837
  %839 = tail call double @llvm.fma.f64(double %834, double %834, double %838) #3
  %840 = fmul double %836, 2.000000e+00
  %841 = tail call double @llvm.fma.f64(double %834, double %840, double %839) #3
  %842 = tail call double @llvm.fma.f64(double %836, double %836, double %841) #3
  %843 = fadd double %837, %842
  %844 = fsub double %843, %837
  %845 = fsub double %842, %844
  %846 = tail call double @llvm.fma.f64(double %843, double 0x3FBDEE674222DE17, double 0x3FBA6564968915A9) #3
  %847 = tail call double @llvm.fma.f64(double %843, double %846, double 0x3FBE25E43ABE935A) #3
  %848 = tail call double @llvm.fma.f64(double %843, double %847, double 0x3FC110EF47E6C9C2) #3
  %849 = tail call double @llvm.fma.f64(double %843, double %848, double 0x3FC3B13BCFA74449) #3
  %850 = tail call double @llvm.fma.f64(double %843, double %849, double 0x3FC745D171BF3C30) #3
  %851 = tail call double @llvm.fma.f64(double %843, double %850, double 0x3FCC71C71C7792CE) #3
  %852 = tail call double @llvm.fma.f64(double %843, double %851, double 0x3FD24924924920DA) #3
  %853 = tail call double @llvm.fma.f64(double %843, double %852, double 0x3FD999999999999C) #3
  %854 = sitofp i32 %806 to double
  %855 = fmul double %854, 0x3FE62E42FEFA39EF
  %856 = fneg double %855
  %857 = tail call double @llvm.fma.f64(double %854, double 0x3FE62E42FEFA39EF, double %856) #3
  %858 = tail call double @llvm.fma.f64(double %854, double 0x3C7ABC9E3B39803F, double %857) #3
  %859 = fadd double %855, %858
  %860 = fsub double %859, %855
  %861 = fsub double %858, %860
  %862 = tail call double @llvm.amdgcn.ldexp.f64(double %834, i32 1) #3
  %863 = tail call double @llvm.amdgcn.ldexp.f64(double %836, i32 1) #3
  %864 = fmul double %834, %843
  %865 = fneg double %864
  %866 = tail call double @llvm.fma.f64(double %843, double %834, double %865) #3
  %867 = fmul double %834, %845
  %868 = tail call double @llvm.fma.f64(double %843, double %836, double %867) #3
  %869 = fadd double %866, %868
  %870 = fadd double %864, %869
  %871 = fsub double %870, %864
  %872 = fsub double %869, %871
  %873 = fmul double %843, %853
  %874 = fneg double %873
  %875 = tail call double @llvm.fma.f64(double %843, double %853, double %874) #3
  %876 = tail call double @llvm.fma.f64(double %845, double %853, double %875) #3
  %877 = fadd double %873, %876
  %878 = fsub double %877, %873
  %879 = fsub double %876, %878
  %880 = fadd double %877, 0x3FE5555555555555
  %881 = fadd double %880, 0xBFE5555555555555
  %882 = fsub double %877, %881
  %883 = fadd double %879, 0x3C8543B0D5DF274D
  %884 = fadd double %882, %883
  %885 = fadd double %880, %884
  %886 = fsub double %885, %880
  %887 = fsub double %884, %886
  %888 = fmul double %870, %885
  %889 = fneg double %888
  %890 = fmul double %872, %885
  %891 = insertelement <2 x double> undef, double %870, i32 0
  %892 = shufflevector <2 x double> %891, <2 x double> undef, <2 x i32> zeroinitializer
  %893 = insertelement <2 x double> undef, double %885, i32 0
  %894 = insertelement <2 x double> %893, double %887, i32 1
  %895 = insertelement <2 x double> undef, double %889, i32 0
  %896 = insertelement <2 x double> %895, double %890, i32 1
  %897 = tail call <2 x double> @llvm.fma.v2f64(<2 x double> %892, <2 x double> %894, <2 x double> %896) #3
  %898 = extractelement <2 x double> %897, i32 0
  %899 = extractelement <2 x double> %897, i32 1
  %900 = fadd double %898, %899
  %901 = fadd double %888, %900
  %902 = fsub double %901, %888
  %903 = fsub double %900, %902
  %904 = fadd double %862, %901
  %905 = fsub double %904, %862
  %906 = fsub double %901, %905
  %907 = fadd double %863, %903
  %908 = fadd double %906, %907
  %909 = fadd double %904, %908
  %910 = fsub double %909, %904
  %911 = fsub double %908, %910
  %912 = fadd double %859, %909
  %913 = fsub double %912, %859
  %914 = fsub double %912, %913
  %915 = fsub double %859, %914
  %916 = fsub double %909, %913
  %917 = fadd double %916, %915
  %918 = fadd double %861, %911
  %919 = fsub double %918, %861
  %920 = fsub double %918, %919
  %921 = fsub double %861, %920
  %922 = fsub double %911, %919
  %923 = fadd double %922, %921
  %924 = fadd double %918, %917
  %925 = fadd double %912, %924
  %926 = fsub double %925, %912
  %927 = fsub double %924, %926
  %928 = fadd double %923, %927
  %929 = fadd double %925, %928
  %930 = fsub double %929, %925
  %931 = fsub double %928, %930
  %932 = fmul double %929, 0x3FF55554FBDAD752
  %933 = fneg double %932
  %934 = tail call double @llvm.fma.f64(double %929, double 0x3FF55554FBDAD752, double %933) #3
  %935 = tail call double @llvm.fma.f64(double %931, double 0x3FF55554FBDAD752, double %934) #3
  %936 = fadd double %932, %935
  %937 = fsub double %936, %932
  %938 = fsub double %935, %937
  %939 = tail call double @llvm.fabs.f64(double %932) #4
  %940 = fcmp oeq double %939, 0x7FF0000000000000
  %941 = select i1 %940, double %932, double %936
  %942 = tail call double @llvm.fabs.f64(double %941) #4
  %943 = fcmp oeq double %942, 0x7FF0000000000000
  %944 = select i1 %943, double 0.000000e+00, double %938
  %945 = fmul double %941, 0x3FF71547652B82FE
  %946 = tail call double @llvm.rint.f64(double %945) #3
  %947 = fmul double %946, 0x3FE62E42FEFA3000
  %948 = fsub double %941, %947
  %949 = fsub double %948, %941
  %950 = fsub double %948, %949
  %951 = fsub double %941, %950
  %952 = fadd double %947, %949
  %953 = fsub double %951, %952
  %954 = fadd double %944, %953
  %955 = fadd double %948, %954
  %956 = fsub double %955, %948
  %957 = fsub double %954, %956
  %958 = fmul double %946, 0x3D53DE6AF278E000
  %959 = fsub double %955, %958
  %960 = fsub double %955, %959
  %961 = fsub double %960, %958
  %962 = fadd double %957, %961
  %963 = fadd double %959, %962
  %964 = fsub double %963, %959
  %965 = fsub double %962, %964
  %966 = fmul double %946, 0x3AC9CC01F97B57A0
  %967 = fsub double %963, %966
  %968 = fsub double %963, %967
  %969 = fsub double %968, %966
  %970 = fadd double %965, %969
  %971 = fadd double %967, %970
  %972 = fsub double %971, %967
  %973 = fsub double %970, %972
  %974 = tail call double @llvm.fma.f64(double %971, double 0x3E5ADE156A5DCB37, double 0x3E928AF3FCA7AB0C) #3
  %975 = tail call double @llvm.fma.f64(double %971, double %974, double 0x3EC71DEE623FDE64) #3
  %976 = tail call double @llvm.fma.f64(double %971, double %975, double 0x3EFA01997C89E6B0) #3
  %977 = tail call double @llvm.fma.f64(double %971, double %976, double 0x3F2A01A014761F6E) #3
  %978 = tail call double @llvm.fma.f64(double %971, double %977, double 0x3F56C16C1852B7B0) #3
  %979 = tail call double @llvm.fma.f64(double %971, double %978, double 0x3F81111111122322) #3
  %980 = tail call double @llvm.fma.f64(double %971, double %979, double 0x3FA55555555502A1) #3
  %981 = tail call double @llvm.fma.f64(double %971, double %980, double 0x3FC5555555555511) #3
  %982 = tail call double @llvm.fma.f64(double %971, double %981, double 0x3FE000000000000B) #3
  %983 = fmul double %971, %971
  %984 = fneg double %983
  %985 = tail call double @llvm.fma.f64(double %971, double %971, double %984) #3
  %986 = fmul double %973, 2.000000e+00
  %987 = tail call double @llvm.fma.f64(double %971, double %986, double %985) #3
  %988 = tail call double @llvm.fma.f64(double %973, double %973, double %987) #3
  %989 = fadd double %983, %988
  %990 = fsub double %989, %983
  %991 = fsub double %988, %990
  %992 = fmul double %989, %982
  %993 = fneg double %992
  %994 = tail call double @llvm.fma.f64(double %989, double %982, double %993) #3
  %995 = tail call double @llvm.fma.f64(double %991, double %982, double %994) #3
  %996 = fadd double %992, %995
  %997 = fsub double %996, %992
  %998 = fsub double %995, %997
  %999 = fadd double %971, %996
  %1000 = fsub double %999, %971
  %1001 = fsub double %996, %1000
  %1002 = fadd double %973, %998
  %1003 = fadd double %1001, %1002
  %1004 = fadd double %999, %1003
  %1005 = fadd double %1004, 1.000000e+00
  %1006 = fptosi double %946 to i32
  %1007 = tail call double @llvm.amdgcn.ldexp.f64(double %1005, i32 %1006) #3
  %1008 = fcmp ogt double %941, 7.100000e+02
  %1009 = select i1 %1008, double 0x7FF0000000000000, double %1007
  %1010 = fcmp olt double %941, -7.450000e+02
  %1011 = select i1 %1010, double 0.000000e+00, double %1009
  %1012 = fcmp uno double %683, 0.000000e+00
  %1013 = tail call i1 @llvm.amdgcn.class.f64(double %683, i32 512) #3
  %1014 = tail call i1 @llvm.amdgcn.class.f64(double %683, i32 4) #3
  %1015 = or i1 %1013, %1014
  %1016 = fcmp oeq double %683, 0.000000e+00
  %1017 = tail call i1 @llvm.amdgcn.class.f64(double %683, i32 960) #3
  %1018 = tail call double @llvm.fabs.f64(double %1011) #3
  %1019 = select i1 %1017, double %1018, double 0x7FF8000000000000
  %1020 = select i1 %1016, double 0.000000e+00, double %1019
  %1021 = select i1 %1015, double 0x7FF0000000000000, double %1020
  %1022 = select i1 %1012, double %683, double %1021
  %1023 = fcmp oeq double %683, 1.000000e+00
  %1024 = select i1 %1023, double 1.000000e+00, double %1022
  %1025 = fmul double %43, %799
  %1026 = fdiv double %1025, %1024
  %1027 = fcmp ugt double %683, %562
  %1028 = select i1 %1027, double %1026, double 0.000000e+00
  %1029 = fmul double %1028, %24
  %1030 = fmul double %1029, 5.000000e-01
  %1031 = fsub double 1.000000e+00, %1030
  %1032 = fmul double %737, %1031
  %1033 = fneg double %738
  %1034 = fsub double %1033, %772
  %1035 = fsub double %1034, %688
  %1036 = fadd double %1035, %1032
  %1037 = fadd double %1030, 1.000000e+00
  %1038 = fdiv double %1036, %1037
  br label %1039

1039:                                             ; preds = %736, %648, %644, %615, %613, %584, %583, %568, %564, %553, %549, %544
  %1040 = phi double [ 0.000000e+00, %544 ], [ 0.000000e+00, %549 ], [ 0.000000e+00, %553 ], [ 0.000000e+00, %564 ], [ 0.000000e+00, %568 ], [ 0.000000e+00, %583 ], [ %609, %584 ], [ 0.000000e+00, %613 ], [ %640, %615 ], [ 0.000000e+00, %644 ], [ %681, %648 ], [ %1038, %736 ]
  %1041 = getelementptr inbounds double, double addrspace(1)* %14, i64 %57
  store double %1040, double addrspace(1)* %1041, align 8, !tbaa !21
  %1042 = add i32 %48, %29
  %1043 = icmp slt i32 %1042, %19
  br i1 %1043, label %47, label %1044, !llvm.loop !23

1044:                                             ; preds = %1039, %25
  ret void
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.maxnum.f64(double, double) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i1 @llvm.amdgcn.class.f64(double, i32) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.rint.f64(double) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.ldexp.f64(double, i32) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.frexp.mant.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.frexp.exp.i32.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rcp.f64(double) #2

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fma.v2f64(<2 x double>, <2 x double>, <2 x double>) #1

; Function Attrs: nounwind readnone speculatable willreturn
declare double @llvm.amdgcn.rsq.f64(double) #2

; Function Attrs: nounwind readnone speculatable willreturn
declare align 4 i8 addrspace(4)* @llvm.amdgcn.dispatch.ptr() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #2

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #2

attributes #0 = { nofree norecurse nounwind "amdgpu-flat-work-group-size"="1,1024" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="128" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }
attributes #4 = { nounwind readnone }

!llvm.module.flags = !{!0, !1}
!opencl.ocl.version = !{!2}
!llvm.ident = !{!3, !4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{i32 2, i32 0}
!3 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!4 = !{!"clang version 12.0.0 (/src/external/llvm-project/clang dac2bfceaa8d4a90257dc8a6d58f268e172ce00e)"}
!5 = !{!6, !10, i64 12}
!6 = !{!"hsa_kernel_dispatch_packet_s", !7, i64 0, !7, i64 2, !7, i64 4, !7, i64 6, !7, i64 8, !7, i64 10, !10, i64 12, !10, i64 16, !10, i64 20, !10, i64 24, !10, i64 28, !11, i64 32, !12, i64 40, !11, i64 48, !13, i64 56}
!7 = !{!"short", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C/C++ TBAA"}
!10 = !{!"int", !8, i64 0}
!11 = !{!"long", !8, i64 0}
!12 = !{!"any pointer", !8, i64 0}
!13 = !{!"hsa_signal_s", !11, i64 0}
!14 = !{i16 1, i16 1025}
!15 = !{}
!16 = !{i32 0, i32 1024}
!17 = !{!18, !18, i64 0}
!18 = !{!"int", !19, i64 0}
!19 = !{!"omnipotent char", !20, i64 0}
!20 = !{!"Simple C++ TBAA"}
!21 = !{!22, !22, i64 0}
!22 = !{!"double", !19, i64 0}
!23 = distinct !{!23, !24}
!24 = !{!"llvm.loop.mustprogress"}
