; ModuleID = 'cases/tpacf/source/source.hip'
source_filename = "cases/tpacf/source/source.hip"
target datalayout = "e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7"
target triple = "amdgcn-amd-amdhsa"

%struct.double3 = type { double, double, double }
%struct.cartesian = type { double*, double*, double*, i32* }

@binbounds = protected local_unnamed_addr addrspace(4) externally_initialized global [63 x double] zeroinitializer, align 16
@sdata = external hidden local_unnamed_addr addrspace(3) global [0 x %struct.double3], align 8

; Function Attrs: convergent norecurse nounwind mustprogress
define protected amdgpu_kernel void @ACFKernelSymm(%struct.cartesian addrspace(4)* nocapture readonly byref(%struct.cartesian) align 8 %0, i32 addrspace(1)* nocapture %1) local_unnamed_addr #0 {
  %3 = getelementptr inbounds %struct.cartesian, %struct.cartesian addrspace(4)* %0, i64 0, i32 0
  %4 = load double*, double* addrspace(4)* %3, align 8
  %5 = getelementptr inbounds %struct.cartesian, %struct.cartesian addrspace(4)* %0, i64 0, i32 1
  %6 = load double*, double* addrspace(4)* %5, align 8
  %7 = getelementptr inbounds %struct.cartesian, %struct.cartesian addrspace(4)* %0, i64 0, i32 2
  %8 = load double*, double* addrspace(4)* %7, align 8
  %9 = tail call i32 @llvm.amdgcn.workgroup.id.x()
  %10 = shl i32 %9, 7
  %11 = tail call i32 @llvm.amdgcn.workitem.id.x(), !range !3
  %12 = add i32 %10, %11
  %13 = tail call i32 @llvm.amdgcn.workgroup.id.y()
  %14 = icmp ult i32 %9, %13
  br i1 %14, label %15, label %26

15:                                               ; preds = %2
  %16 = shl i32 %13, 19
  %17 = add nsw i32 %12, %16
  br label %18

18:                                               ; preds = %15, %18
  %19 = phi i32 [ 0, %15 ], [ %24, %18 ]
  %20 = shl nuw nsw i32 %19, 12
  %21 = add nsw i32 %17, %20
  %22 = sext i32 %21 to i64
  %23 = getelementptr inbounds i32, i32 addrspace(1)* %1, i64 %22
  store i32 2088533116, i32 addrspace(1)* %23, align 4, !tbaa !4
  %24 = add nuw nsw i32 %19, 4
  %25 = icmp ult i32 %19, 124
  br i1 %25, label %18, label %518, !llvm.loop !8

26:                                               ; preds = %2
  %27 = shl i32 %13, 7
  %28 = icmp ugt i32 %9, %13
  %29 = sext i32 %12 to i64
  %30 = getelementptr inbounds double, double* %4, i64 %29
  %31 = addrspacecast double* %30 to double addrspace(1)*
  %32 = load double, double addrspace(1)* %31, align 8, !tbaa !11
  %33 = getelementptr inbounds double, double* %6, i64 %29
  %34 = addrspacecast double* %33 to double addrspace(1)*
  %35 = load double, double addrspace(1)* %34, align 8, !tbaa !11
  %36 = getelementptr inbounds double, double* %8, i64 %29
  %37 = addrspacecast double* %36 to double addrspace(1)*
  %38 = load double, double addrspace(1)* %37, align 8, !tbaa !11
  %39 = add i32 %27, %11
  %40 = zext i32 %39 to i64
  %41 = getelementptr inbounds double, double* %4, i64 %40
  %42 = addrspacecast double* %41 to double addrspace(1)*
  %43 = load double, double addrspace(1)* %42, align 8, !tbaa !11
  %44 = getelementptr inbounds [0 x %struct.double3], [0 x %struct.double3] addrspace(3)* @sdata, i32 0, i32 %11, i32 0
  store double %43, double addrspace(3)* %44, align 8, !tbaa !13
  %45 = getelementptr inbounds double, double* %6, i64 %40
  %46 = addrspacecast double* %45 to double addrspace(1)*
  %47 = load double, double addrspace(1)* %46, align 8, !tbaa !11
  %48 = getelementptr inbounds [0 x %struct.double3], [0 x %struct.double3] addrspace(3)* @sdata, i32 0, i32 %11, i32 1
  store double %47, double addrspace(3)* %48, align 8, !tbaa !15
  %49 = getelementptr inbounds double, double* %8, i64 %40
  %50 = addrspacecast double* %49 to double addrspace(1)*
  %51 = load double, double addrspace(1)* %50, align 8, !tbaa !11
  %52 = getelementptr inbounds [0 x %struct.double3], [0 x %struct.double3] addrspace(3)* @sdata, i32 0, i32 %11, i32 2
  store double %51, double addrspace(3)* %52, align 8, !tbaa !16
  fence syncscope("workgroup") seq_cst
  tail call void @llvm.amdgcn.s.barrier()
  fence syncscope("workgroup") seq_cst
  %53 = shl i32 %13, 19
  %54 = add nsw i32 %12, %53
  %55 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 30), align 16
  %56 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 29), align 8
  %57 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 28), align 16
  %58 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 27), align 8
  %59 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 26), align 16
  %60 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 25), align 8
  %61 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 24), align 16
  %62 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 23), align 8
  %63 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 22), align 16
  %64 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 21), align 8
  %65 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 20), align 16
  %66 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 19), align 8
  %67 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 18), align 16
  %68 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 17), align 8
  %69 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 16), align 16
  %70 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 15), align 8
  %71 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 14), align 16
  %72 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 13), align 8
  %73 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 12), align 16
  %74 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 11), align 8
  %75 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 10), align 16
  %76 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 9), align 8
  %77 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 8), align 16
  %78 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 7), align 8
  %79 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 6), align 16
  %80 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 5), align 8
  %81 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 4), align 16
  %82 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 3), align 8
  %83 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 2), align 16
  %84 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 1), align 8
  %85 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 0), align 16
  br i1 %28, label %86, label %299

86:                                               ; preds = %26, %88
  %87 = phi i32 [ %93, %88 ], [ 0, %26 ]
  br label %95

88:                                               ; preds = %295
  %89 = shl i32 %87, 12
  %90 = add nsw i32 %54, %89
  %91 = sext i32 %90 to i64
  %92 = getelementptr inbounds i32, i32 addrspace(1)* %1, i64 %91
  store i32 %296, i32 addrspace(1)* %92, align 4, !tbaa !4
  %93 = add nuw nsw i32 %87, 4
  %94 = icmp ult i32 %87, 124
  br i1 %94, label %86, label %518, !llvm.loop !17

95:                                               ; preds = %86, %295
  %96 = phi i32 [ 0, %86 ], [ %296, %295 ]
  %97 = phi i32 [ 0, %86 ], [ %297, %295 ]
  %98 = add nuw nsw i32 %97, %87
  %99 = getelementptr inbounds [0 x %struct.double3], [0 x %struct.double3] addrspace(3)* @sdata, i32 0, i32 %98, i32 0
  %100 = load double, double addrspace(3)* %99, align 8, !tbaa.struct !18
  %101 = getelementptr inbounds [0 x %struct.double3], [0 x %struct.double3] addrspace(3)* @sdata, i32 0, i32 %98, i32 1
  %102 = load double, double addrspace(3)* %101, align 8, !tbaa.struct !19
  %103 = getelementptr inbounds [0 x %struct.double3], [0 x %struct.double3] addrspace(3)* @sdata, i32 0, i32 %98, i32 2
  %104 = load double, double addrspace(3)* %103, align 8, !tbaa.struct !20
  %105 = fmul double %32, %100
  %106 = fmul double %35, %102
  %107 = fadd double %105, %106
  %108 = fmul double %38, %104
  %109 = fadd double %107, %108
  %110 = fcmp olt double %109, %55
  br i1 %110, label %111, label %115

111:                                              ; preds = %95
  %112 = shl nuw nsw i32 %97, 3
  %113 = shl nuw nsw i32 124, %112
  %114 = add i32 %113, %96
  br label %295

115:                                              ; preds = %95
  %116 = fcmp olt double %109, %56
  br i1 %116, label %117, label %121

117:                                              ; preds = %115
  %118 = shl nuw nsw i32 %97, 3
  %119 = shl nuw nsw i32 120, %118
  %120 = add i32 %119, %96
  br label %295

121:                                              ; preds = %115
  %122 = fcmp olt double %109, %57
  br i1 %122, label %123, label %127

123:                                              ; preds = %121
  %124 = shl nuw nsw i32 %97, 3
  %125 = shl nuw nsw i32 116, %124
  %126 = add i32 %125, %96
  br label %295

127:                                              ; preds = %121
  %128 = fcmp olt double %109, %58
  br i1 %128, label %129, label %133

129:                                              ; preds = %127
  %130 = shl nuw nsw i32 %97, 3
  %131 = shl nuw nsw i32 112, %130
  %132 = add i32 %131, %96
  br label %295

133:                                              ; preds = %127
  %134 = fcmp olt double %109, %59
  br i1 %134, label %135, label %139

135:                                              ; preds = %133
  %136 = shl nuw nsw i32 %97, 3
  %137 = shl nuw nsw i32 108, %136
  %138 = add i32 %137, %96
  br label %295

139:                                              ; preds = %133
  %140 = fcmp olt double %109, %60
  br i1 %140, label %141, label %145

141:                                              ; preds = %139
  %142 = shl nuw nsw i32 %97, 3
  %143 = shl nuw nsw i32 104, %142
  %144 = add i32 %143, %96
  br label %295

145:                                              ; preds = %139
  %146 = fcmp olt double %109, %61
  br i1 %146, label %147, label %151

147:                                              ; preds = %145
  %148 = shl nuw nsw i32 %97, 3
  %149 = shl nuw nsw i32 100, %148
  %150 = add i32 %149, %96
  br label %295

151:                                              ; preds = %145
  %152 = fcmp olt double %109, %62
  br i1 %152, label %153, label %157

153:                                              ; preds = %151
  %154 = shl nuw nsw i32 %97, 3
  %155 = shl nuw nsw i32 96, %154
  %156 = add i32 %155, %96
  br label %295

157:                                              ; preds = %151
  %158 = fcmp olt double %109, %63
  br i1 %158, label %159, label %163

159:                                              ; preds = %157
  %160 = shl nuw nsw i32 %97, 3
  %161 = shl nuw nsw i32 92, %160
  %162 = add i32 %161, %96
  br label %295

163:                                              ; preds = %157
  %164 = fcmp olt double %109, %64
  br i1 %164, label %165, label %169

165:                                              ; preds = %163
  %166 = shl nuw nsw i32 %97, 3
  %167 = shl nuw nsw i32 88, %166
  %168 = add i32 %167, %96
  br label %295

169:                                              ; preds = %163
  %170 = fcmp olt double %109, %65
  br i1 %170, label %171, label %175

171:                                              ; preds = %169
  %172 = shl nuw nsw i32 %97, 3
  %173 = shl nuw nsw i32 84, %172
  %174 = add i32 %173, %96
  br label %295

175:                                              ; preds = %169
  %176 = fcmp olt double %109, %66
  br i1 %176, label %177, label %181

177:                                              ; preds = %175
  %178 = shl nuw nsw i32 %97, 3
  %179 = shl nuw nsw i32 80, %178
  %180 = add i32 %179, %96
  br label %295

181:                                              ; preds = %175
  %182 = fcmp olt double %109, %67
  br i1 %182, label %183, label %187

183:                                              ; preds = %181
  %184 = shl nuw nsw i32 %97, 3
  %185 = shl nuw nsw i32 76, %184
  %186 = add i32 %185, %96
  br label %295

187:                                              ; preds = %181
  %188 = fcmp olt double %109, %68
  br i1 %188, label %189, label %193

189:                                              ; preds = %187
  %190 = shl nuw nsw i32 %97, 3
  %191 = shl nuw nsw i32 72, %190
  %192 = add i32 %191, %96
  br label %295

193:                                              ; preds = %187
  %194 = fcmp olt double %109, %69
  br i1 %194, label %195, label %199

195:                                              ; preds = %193
  %196 = shl nuw nsw i32 %97, 3
  %197 = shl nuw nsw i32 68, %196
  %198 = add i32 %197, %96
  br label %295

199:                                              ; preds = %193
  %200 = fcmp olt double %109, %70
  br i1 %200, label %201, label %205

201:                                              ; preds = %199
  %202 = shl nuw nsw i32 %97, 3
  %203 = shl nuw nsw i32 64, %202
  %204 = add i32 %203, %96
  br label %295

205:                                              ; preds = %199
  %206 = fcmp olt double %109, %71
  br i1 %206, label %207, label %211

207:                                              ; preds = %205
  %208 = shl nuw nsw i32 %97, 3
  %209 = shl nuw nsw i32 60, %208
  %210 = add i32 %209, %96
  br label %295

211:                                              ; preds = %205
  %212 = fcmp olt double %109, %72
  br i1 %212, label %213, label %217

213:                                              ; preds = %211
  %214 = shl nuw nsw i32 %97, 3
  %215 = shl nuw nsw i32 56, %214
  %216 = add i32 %215, %96
  br label %295

217:                                              ; preds = %211
  %218 = fcmp olt double %109, %73
  br i1 %218, label %219, label %223

219:                                              ; preds = %217
  %220 = shl nuw nsw i32 %97, 3
  %221 = shl nuw nsw i32 52, %220
  %222 = add i32 %221, %96
  br label %295

223:                                              ; preds = %217
  %224 = fcmp olt double %109, %74
  br i1 %224, label %225, label %229

225:                                              ; preds = %223
  %226 = shl nuw nsw i32 %97, 3
  %227 = shl nuw nsw i32 48, %226
  %228 = add i32 %227, %96
  br label %295

229:                                              ; preds = %223
  %230 = fcmp olt double %109, %75
  br i1 %230, label %231, label %235

231:                                              ; preds = %229
  %232 = shl nuw nsw i32 %97, 3
  %233 = shl nuw nsw i32 44, %232
  %234 = add i32 %233, %96
  br label %295

235:                                              ; preds = %229
  %236 = fcmp olt double %109, %76
  br i1 %236, label %237, label %241

237:                                              ; preds = %235
  %238 = shl nuw nsw i32 %97, 3
  %239 = shl nuw nsw i32 40, %238
  %240 = add i32 %239, %96
  br label %295

241:                                              ; preds = %235
  %242 = fcmp olt double %109, %77
  br i1 %242, label %243, label %247

243:                                              ; preds = %241
  %244 = shl nuw nsw i32 %97, 3
  %245 = shl nuw nsw i32 36, %244
  %246 = add i32 %245, %96
  br label %295

247:                                              ; preds = %241
  %248 = fcmp olt double %109, %78
  br i1 %248, label %249, label %253

249:                                              ; preds = %247
  %250 = shl nuw nsw i32 %97, 3
  %251 = shl nuw nsw i32 32, %250
  %252 = add i32 %251, %96
  br label %295

253:                                              ; preds = %247
  %254 = fcmp olt double %109, %79
  br i1 %254, label %255, label %259

255:                                              ; preds = %253
  %256 = shl nuw nsw i32 %97, 3
  %257 = shl nuw nsw i32 28, %256
  %258 = add i32 %257, %96
  br label %295

259:                                              ; preds = %253
  %260 = fcmp olt double %109, %80
  br i1 %260, label %261, label %265

261:                                              ; preds = %259
  %262 = shl nuw nsw i32 %97, 3
  %263 = shl nuw nsw i32 24, %262
  %264 = add i32 %263, %96
  br label %295

265:                                              ; preds = %259
  %266 = fcmp olt double %109, %81
  br i1 %266, label %267, label %271

267:                                              ; preds = %265
  %268 = shl nuw nsw i32 %97, 3
  %269 = shl nuw nsw i32 20, %268
  %270 = add i32 %269, %96
  br label %295

271:                                              ; preds = %265
  %272 = fcmp olt double %109, %82
  br i1 %272, label %273, label %277

273:                                              ; preds = %271
  %274 = shl nuw nsw i32 %97, 3
  %275 = shl nuw nsw i32 16, %274
  %276 = add i32 %275, %96
  br label %295

277:                                              ; preds = %271
  %278 = fcmp olt double %109, %83
  br i1 %278, label %279, label %283

279:                                              ; preds = %277
  %280 = shl nuw nsw i32 %97, 3
  %281 = shl nuw nsw i32 12, %280
  %282 = add i32 %281, %96
  br label %295

283:                                              ; preds = %277
  %284 = fcmp olt double %109, %84
  br i1 %284, label %285, label %289

285:                                              ; preds = %283
  %286 = shl nuw nsw i32 %97, 3
  %287 = shl nuw nsw i32 8, %286
  %288 = add i32 %287, %96
  br label %295

289:                                              ; preds = %283
  %290 = fcmp olt double %109, %85
  br i1 %290, label %291, label %295

291:                                              ; preds = %289
  %292 = shl nuw nsw i32 %97, 3
  %293 = shl nuw nsw i32 4, %292
  %294 = add i32 %293, %96
  br label %295

295:                                              ; preds = %289, %111, %123, %135, %147, %159, %171, %183, %195, %207, %219, %231, %243, %255, %267, %279, %291, %285, %273, %261, %249, %237, %225, %213, %201, %189, %177, %165, %153, %141, %129, %117
  %296 = phi i32 [ %114, %111 ], [ %120, %117 ], [ %126, %123 ], [ %132, %129 ], [ %138, %135 ], [ %144, %141 ], [ %150, %147 ], [ %156, %153 ], [ %162, %159 ], [ %168, %165 ], [ %174, %171 ], [ %180, %177 ], [ %186, %183 ], [ %192, %189 ], [ %198, %195 ], [ %204, %201 ], [ %210, %207 ], [ %216, %213 ], [ %222, %219 ], [ %228, %225 ], [ %234, %231 ], [ %240, %237 ], [ %246, %243 ], [ %252, %249 ], [ %258, %255 ], [ %264, %261 ], [ %270, %267 ], [ %276, %273 ], [ %282, %279 ], [ %288, %285 ], [ %294, %291 ], [ %96, %289 ]
  %297 = add nuw nsw i32 %97, 1
  %298 = icmp eq i32 %297, 4
  br i1 %298, label %88, label %95, !llvm.loop !21

299:                                              ; preds = %26, %301
  %300 = phi i32 [ %306, %301 ], [ 0, %26 ]
  br label %308

301:                                              ; preds = %514
  %302 = shl i32 %300, 12
  %303 = add nsw i32 %54, %302
  %304 = sext i32 %303 to i64
  %305 = getelementptr inbounds i32, i32 addrspace(1)* %1, i64 %304
  store i32 %515, i32 addrspace(1)* %305, align 4, !tbaa !4
  %306 = add nuw nsw i32 %300, 4
  %307 = icmp ult i32 %300, 124
  br i1 %307, label %299, label %518, !llvm.loop !22

308:                                              ; preds = %299, %514
  %309 = phi i32 [ 0, %299 ], [ %516, %514 ]
  %310 = phi i32 [ 0, %299 ], [ %515, %514 ]
  %311 = add nuw nsw i32 %309, %300
  %312 = icmp ugt i32 %11, %311
  br i1 %312, label %317, label %313

313:                                              ; preds = %308
  %314 = shl nuw nsw i32 %309, 3
  %315 = shl nuw nsw i32 124, %314
  %316 = add i32 %315, %310
  br label %514

317:                                              ; preds = %308
  %318 = getelementptr inbounds [0 x %struct.double3], [0 x %struct.double3] addrspace(3)* @sdata, i32 0, i32 %311, i32 0
  %319 = load double, double addrspace(3)* %318, align 8, !tbaa.struct !18
  %320 = getelementptr inbounds [0 x %struct.double3], [0 x %struct.double3] addrspace(3)* @sdata, i32 0, i32 %311, i32 1
  %321 = load double, double addrspace(3)* %320, align 8, !tbaa.struct !19
  %322 = getelementptr inbounds [0 x %struct.double3], [0 x %struct.double3] addrspace(3)* @sdata, i32 0, i32 %311, i32 2
  %323 = load double, double addrspace(3)* %322, align 8, !tbaa.struct !20
  %324 = fmul double %32, %319
  %325 = fmul double %35, %321
  %326 = fadd double %324, %325
  %327 = fmul double %38, %323
  %328 = fadd double %326, %327
  %329 = fcmp olt double %328, %55
  br i1 %329, label %330, label %334

330:                                              ; preds = %317
  %331 = shl i32 %309, 3
  %332 = shl i32 124, %331
  %333 = add i32 %332, %310
  br label %514

334:                                              ; preds = %317
  %335 = fcmp olt double %328, %56
  br i1 %335, label %336, label %340

336:                                              ; preds = %334
  %337 = shl i32 %309, 3
  %338 = shl i32 120, %337
  %339 = add i32 %338, %310
  br label %514

340:                                              ; preds = %334
  %341 = fcmp olt double %328, %57
  br i1 %341, label %342, label %346

342:                                              ; preds = %340
  %343 = shl i32 %309, 3
  %344 = shl i32 116, %343
  %345 = add i32 %344, %310
  br label %514

346:                                              ; preds = %340
  %347 = fcmp olt double %328, %58
  br i1 %347, label %348, label %352

348:                                              ; preds = %346
  %349 = shl i32 %309, 3
  %350 = shl i32 112, %349
  %351 = add i32 %350, %310
  br label %514

352:                                              ; preds = %346
  %353 = fcmp olt double %328, %59
  br i1 %353, label %354, label %358

354:                                              ; preds = %352
  %355 = shl i32 %309, 3
  %356 = shl i32 108, %355
  %357 = add i32 %356, %310
  br label %514

358:                                              ; preds = %352
  %359 = fcmp olt double %328, %60
  br i1 %359, label %360, label %364

360:                                              ; preds = %358
  %361 = shl i32 %309, 3
  %362 = shl i32 104, %361
  %363 = add i32 %362, %310
  br label %514

364:                                              ; preds = %358
  %365 = fcmp olt double %328, %61
  br i1 %365, label %366, label %370

366:                                              ; preds = %364
  %367 = shl i32 %309, 3
  %368 = shl i32 100, %367
  %369 = add i32 %368, %310
  br label %514

370:                                              ; preds = %364
  %371 = fcmp olt double %328, %62
  br i1 %371, label %372, label %376

372:                                              ; preds = %370
  %373 = shl i32 %309, 3
  %374 = shl i32 96, %373
  %375 = add i32 %374, %310
  br label %514

376:                                              ; preds = %370
  %377 = fcmp olt double %328, %63
  br i1 %377, label %378, label %382

378:                                              ; preds = %376
  %379 = shl i32 %309, 3
  %380 = shl i32 92, %379
  %381 = add i32 %380, %310
  br label %514

382:                                              ; preds = %376
  %383 = fcmp olt double %328, %64
  br i1 %383, label %384, label %388

384:                                              ; preds = %382
  %385 = shl i32 %309, 3
  %386 = shl i32 88, %385
  %387 = add i32 %386, %310
  br label %514

388:                                              ; preds = %382
  %389 = fcmp olt double %328, %65
  br i1 %389, label %390, label %394

390:                                              ; preds = %388
  %391 = shl i32 %309, 3
  %392 = shl i32 84, %391
  %393 = add i32 %392, %310
  br label %514

394:                                              ; preds = %388
  %395 = fcmp olt double %328, %66
  br i1 %395, label %396, label %400

396:                                              ; preds = %394
  %397 = shl i32 %309, 3
  %398 = shl i32 80, %397
  %399 = add i32 %398, %310
  br label %514

400:                                              ; preds = %394
  %401 = fcmp olt double %328, %67
  br i1 %401, label %402, label %406

402:                                              ; preds = %400
  %403 = shl i32 %309, 3
  %404 = shl i32 76, %403
  %405 = add i32 %404, %310
  br label %514

406:                                              ; preds = %400
  %407 = fcmp olt double %328, %68
  br i1 %407, label %408, label %412

408:                                              ; preds = %406
  %409 = shl i32 %309, 3
  %410 = shl i32 72, %409
  %411 = add i32 %410, %310
  br label %514

412:                                              ; preds = %406
  %413 = fcmp olt double %328, %69
  br i1 %413, label %414, label %418

414:                                              ; preds = %412
  %415 = shl i32 %309, 3
  %416 = shl i32 68, %415
  %417 = add i32 %416, %310
  br label %514

418:                                              ; preds = %412
  %419 = fcmp olt double %328, %70
  br i1 %419, label %420, label %424

420:                                              ; preds = %418
  %421 = shl i32 %309, 3
  %422 = shl i32 64, %421
  %423 = add i32 %422, %310
  br label %514

424:                                              ; preds = %418
  %425 = fcmp olt double %328, %71
  br i1 %425, label %426, label %430

426:                                              ; preds = %424
  %427 = shl i32 %309, 3
  %428 = shl i32 60, %427
  %429 = add i32 %428, %310
  br label %514

430:                                              ; preds = %424
  %431 = fcmp olt double %328, %72
  br i1 %431, label %432, label %436

432:                                              ; preds = %430
  %433 = shl i32 %309, 3
  %434 = shl i32 56, %433
  %435 = add i32 %434, %310
  br label %514

436:                                              ; preds = %430
  %437 = fcmp olt double %328, %73
  br i1 %437, label %438, label %442

438:                                              ; preds = %436
  %439 = shl i32 %309, 3
  %440 = shl i32 52, %439
  %441 = add i32 %440, %310
  br label %514

442:                                              ; preds = %436
  %443 = fcmp olt double %328, %74
  br i1 %443, label %444, label %448

444:                                              ; preds = %442
  %445 = shl i32 %309, 3
  %446 = shl i32 48, %445
  %447 = add i32 %446, %310
  br label %514

448:                                              ; preds = %442
  %449 = fcmp olt double %328, %75
  br i1 %449, label %450, label %454

450:                                              ; preds = %448
  %451 = shl i32 %309, 3
  %452 = shl i32 44, %451
  %453 = add i32 %452, %310
  br label %514

454:                                              ; preds = %448
  %455 = fcmp olt double %328, %76
  br i1 %455, label %456, label %460

456:                                              ; preds = %454
  %457 = shl i32 %309, 3
  %458 = shl i32 40, %457
  %459 = add i32 %458, %310
  br label %514

460:                                              ; preds = %454
  %461 = fcmp olt double %328, %77
  br i1 %461, label %462, label %466

462:                                              ; preds = %460
  %463 = shl i32 %309, 3
  %464 = shl i32 36, %463
  %465 = add i32 %464, %310
  br label %514

466:                                              ; preds = %460
  %467 = fcmp olt double %328, %78
  br i1 %467, label %468, label %472

468:                                              ; preds = %466
  %469 = shl i32 %309, 3
  %470 = shl i32 32, %469
  %471 = add i32 %470, %310
  br label %514

472:                                              ; preds = %466
  %473 = fcmp olt double %328, %79
  br i1 %473, label %474, label %478

474:                                              ; preds = %472
  %475 = shl i32 %309, 3
  %476 = shl i32 28, %475
  %477 = add i32 %476, %310
  br label %514

478:                                              ; preds = %472
  %479 = fcmp olt double %328, %80
  br i1 %479, label %480, label %484

480:                                              ; preds = %478
  %481 = shl i32 %309, 3
  %482 = shl i32 24, %481
  %483 = add i32 %482, %310
  br label %514

484:                                              ; preds = %478
  %485 = fcmp olt double %328, %81
  br i1 %485, label %486, label %490

486:                                              ; preds = %484
  %487 = shl i32 %309, 3
  %488 = shl i32 20, %487
  %489 = add i32 %488, %310
  br label %514

490:                                              ; preds = %484
  %491 = fcmp olt double %328, %82
  br i1 %491, label %492, label %496

492:                                              ; preds = %490
  %493 = shl i32 %309, 3
  %494 = shl i32 16, %493
  %495 = add i32 %494, %310
  br label %514

496:                                              ; preds = %490
  %497 = fcmp olt double %328, %83
  br i1 %497, label %498, label %502

498:                                              ; preds = %496
  %499 = shl i32 %309, 3
  %500 = shl i32 12, %499
  %501 = add i32 %500, %310
  br label %514

502:                                              ; preds = %496
  %503 = fcmp olt double %328, %84
  br i1 %503, label %504, label %508

504:                                              ; preds = %502
  %505 = shl i32 %309, 3
  %506 = shl i32 8, %505
  %507 = add i32 %506, %310
  br label %514

508:                                              ; preds = %502
  %509 = fcmp olt double %328, %85
  br i1 %509, label %510, label %514

510:                                              ; preds = %508
  %511 = shl i32 %309, 3
  %512 = shl i32 4, %511
  %513 = add i32 %512, %310
  br label %514

514:                                              ; preds = %508, %313, %336, %348, %360, %372, %384, %396, %408, %420, %432, %444, %456, %468, %480, %492, %504, %510, %498, %486, %474, %462, %450, %438, %426, %414, %402, %390, %378, %366, %354, %342, %330
  %515 = phi i32 [ %316, %313 ], [ %333, %330 ], [ %339, %336 ], [ %345, %342 ], [ %351, %348 ], [ %357, %354 ], [ %363, %360 ], [ %369, %366 ], [ %375, %372 ], [ %381, %378 ], [ %387, %384 ], [ %393, %390 ], [ %399, %396 ], [ %405, %402 ], [ %411, %408 ], [ %417, %414 ], [ %423, %420 ], [ %429, %426 ], [ %435, %432 ], [ %441, %438 ], [ %447, %444 ], [ %453, %450 ], [ %459, %456 ], [ %465, %462 ], [ %471, %468 ], [ %477, %474 ], [ %483, %480 ], [ %489, %486 ], [ %495, %492 ], [ %501, %498 ], [ %507, %504 ], [ %513, %510 ], [ %310, %508 ]
  %516 = add nuw nsw i32 %309, 1
  %517 = icmp eq i32 %516, 4
  br i1 %517, label %301, label %308, !llvm.loop !23

518:                                              ; preds = %301, %88, %18
  ret void
}

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workgroup.id.y() #1

; Function Attrs: nounwind readnone speculatable willreturn
declare i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: convergent nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #2

; Function Attrs: convergent norecurse nounwind mustprogress
define protected amdgpu_kernel void @ACFKernel(%struct.cartesian addrspace(4)* nocapture readonly byref(%struct.cartesian) align 8 %0, %struct.cartesian addrspace(4)* nocapture readonly byref(%struct.cartesian) align 8 %1, i32 addrspace(1)* nocapture %2) local_unnamed_addr #0 {
  %4 = getelementptr inbounds %struct.cartesian, %struct.cartesian addrspace(4)* %0, i64 0, i32 0
  %5 = load double*, double* addrspace(4)* %4, align 8
  %6 = getelementptr inbounds %struct.cartesian, %struct.cartesian addrspace(4)* %0, i64 0, i32 1
  %7 = load double*, double* addrspace(4)* %6, align 8
  %8 = getelementptr inbounds %struct.cartesian, %struct.cartesian addrspace(4)* %0, i64 0, i32 2
  %9 = load double*, double* addrspace(4)* %8, align 8
  %10 = getelementptr inbounds %struct.cartesian, %struct.cartesian addrspace(4)* %1, i64 0, i32 0
  %11 = load double*, double* addrspace(4)* %10, align 8
  %12 = getelementptr inbounds %struct.cartesian, %struct.cartesian addrspace(4)* %1, i64 0, i32 1
  %13 = load double*, double* addrspace(4)* %12, align 8
  %14 = getelementptr inbounds %struct.cartesian, %struct.cartesian addrspace(4)* %1, i64 0, i32 2
  %15 = load double*, double* addrspace(4)* %14, align 8
  %16 = tail call i32 @llvm.amdgcn.workgroup.id.x()
  %17 = shl i32 %16, 7
  %18 = tail call i32 @llvm.amdgcn.workitem.id.x(), !range !3
  %19 = add i32 %17, %18
  %20 = tail call i32 @llvm.amdgcn.workgroup.id.y()
  %21 = shl i32 %20, 7
  %22 = sext i32 %19 to i64
  %23 = getelementptr inbounds double, double* %11, i64 %22
  %24 = addrspacecast double* %23 to double addrspace(1)*
  %25 = load double, double addrspace(1)* %24, align 8, !tbaa !11
  %26 = getelementptr inbounds double, double* %13, i64 %22
  %27 = addrspacecast double* %26 to double addrspace(1)*
  %28 = load double, double addrspace(1)* %27, align 8, !tbaa !11
  %29 = getelementptr inbounds double, double* %15, i64 %22
  %30 = addrspacecast double* %29 to double addrspace(1)*
  %31 = load double, double addrspace(1)* %30, align 8, !tbaa !11
  %32 = add i32 %21, %18
  %33 = zext i32 %32 to i64
  %34 = getelementptr inbounds double, double* %5, i64 %33
  %35 = addrspacecast double* %34 to double addrspace(1)*
  %36 = load double, double addrspace(1)* %35, align 8, !tbaa !11
  %37 = getelementptr inbounds [0 x %struct.double3], [0 x %struct.double3] addrspace(3)* @sdata, i32 0, i32 %18, i32 0
  store double %36, double addrspace(3)* %37, align 8, !tbaa !13
  %38 = getelementptr inbounds double, double* %7, i64 %33
  %39 = addrspacecast double* %38 to double addrspace(1)*
  %40 = load double, double addrspace(1)* %39, align 8, !tbaa !11
  %41 = getelementptr inbounds [0 x %struct.double3], [0 x %struct.double3] addrspace(3)* @sdata, i32 0, i32 %18, i32 1
  store double %40, double addrspace(3)* %41, align 8, !tbaa !15
  %42 = getelementptr inbounds double, double* %9, i64 %33
  %43 = addrspacecast double* %42 to double addrspace(1)*
  %44 = load double, double addrspace(1)* %43, align 8, !tbaa !11
  %45 = getelementptr inbounds [0 x %struct.double3], [0 x %struct.double3] addrspace(3)* @sdata, i32 0, i32 %18, i32 2
  store double %44, double addrspace(3)* %45, align 8, !tbaa !16
  fence syncscope("workgroup") seq_cst
  tail call void @llvm.amdgcn.s.barrier()
  fence syncscope("workgroup") seq_cst
  %46 = shl i32 %20, 19
  %47 = add nsw i32 %19, %46
  %48 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 30), align 16, !tbaa !11
  %49 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 29), align 8
  %50 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 28), align 16
  %51 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 27), align 8
  %52 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 26), align 16
  %53 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 25), align 8
  %54 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 24), align 16
  %55 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 23), align 8
  %56 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 22), align 16
  %57 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 21), align 8
  %58 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 20), align 16
  %59 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 19), align 8
  %60 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 18), align 16
  %61 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 17), align 8
  %62 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 16), align 16
  %63 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 15), align 8
  %64 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 14), align 16
  %65 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 13), align 8
  %66 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 12), align 16
  %67 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 11), align 8
  %68 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 10), align 16
  %69 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 9), align 8
  %70 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 8), align 16
  %71 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 7), align 8
  %72 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 6), align 16
  %73 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 5), align 8
  %74 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 4), align 16
  %75 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 3), align 8
  %76 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 2), align 16
  %77 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 1), align 8
  %78 = load double, double addrspace(4)* getelementptr inbounds ([63 x double], [63 x double] addrspace(4)* @binbounds, i64 0, i64 0), align 16
  br label %79

79:                                               ; preds = %3, %82
  %80 = phi i32 [ 0, %3 ], [ %87, %82 ]
  br label %89

81:                                               ; preds = %82
  ret void

82:                                               ; preds = %289
  %83 = shl i32 %80, 12
  %84 = add nsw i32 %47, %83
  %85 = sext i32 %84 to i64
  %86 = getelementptr inbounds i32, i32 addrspace(1)* %2, i64 %85
  store i32 %290, i32 addrspace(1)* %86, align 4, !tbaa !4
  %87 = add nuw nsw i32 %80, 4
  %88 = icmp ult i32 %80, 124
  br i1 %88, label %79, label %81, !llvm.loop !24

89:                                               ; preds = %79, %289
  %90 = phi i32 [ 0, %79 ], [ %291, %289 ]
  %91 = phi i32 [ 0, %79 ], [ %290, %289 ]
  %92 = add nuw nsw i32 %90, %80
  %93 = getelementptr inbounds [0 x %struct.double3], [0 x %struct.double3] addrspace(3)* @sdata, i32 0, i32 %92, i32 0
  %94 = load double, double addrspace(3)* %93, align 8, !tbaa.struct !18
  %95 = getelementptr inbounds [0 x %struct.double3], [0 x %struct.double3] addrspace(3)* @sdata, i32 0, i32 %92, i32 1
  %96 = load double, double addrspace(3)* %95, align 8, !tbaa.struct !19
  %97 = getelementptr inbounds [0 x %struct.double3], [0 x %struct.double3] addrspace(3)* @sdata, i32 0, i32 %92, i32 2
  %98 = load double, double addrspace(3)* %97, align 8, !tbaa.struct !20
  %99 = fmul double %25, %94
  %100 = fmul double %28, %96
  %101 = fadd double %99, %100
  %102 = fmul double %31, %98
  %103 = fadd double %101, %102
  %104 = fcmp olt double %103, %48
  br i1 %104, label %105, label %109

105:                                              ; preds = %89
  %106 = shl nuw nsw i32 %90, 3
  %107 = shl nuw nsw i32 124, %106
  %108 = add i32 %107, %91
  br label %289

109:                                              ; preds = %89
  %110 = fcmp olt double %103, %49
  br i1 %110, label %111, label %115

111:                                              ; preds = %109
  %112 = shl i32 %90, 3
  %113 = shl i32 120, %112
  %114 = add i32 %113, %91
  br label %289

115:                                              ; preds = %109
  %116 = fcmp olt double %103, %50
  br i1 %116, label %117, label %121

117:                                              ; preds = %115
  %118 = shl i32 %90, 3
  %119 = shl i32 116, %118
  %120 = add i32 %119, %91
  br label %289

121:                                              ; preds = %115
  %122 = fcmp olt double %103, %51
  br i1 %122, label %123, label %127

123:                                              ; preds = %121
  %124 = shl i32 %90, 3
  %125 = shl i32 112, %124
  %126 = add i32 %125, %91
  br label %289

127:                                              ; preds = %121
  %128 = fcmp olt double %103, %52
  br i1 %128, label %129, label %133

129:                                              ; preds = %127
  %130 = shl i32 %90, 3
  %131 = shl i32 108, %130
  %132 = add i32 %131, %91
  br label %289

133:                                              ; preds = %127
  %134 = fcmp olt double %103, %53
  br i1 %134, label %135, label %139

135:                                              ; preds = %133
  %136 = shl i32 %90, 3
  %137 = shl i32 104, %136
  %138 = add i32 %137, %91
  br label %289

139:                                              ; preds = %133
  %140 = fcmp olt double %103, %54
  br i1 %140, label %141, label %145

141:                                              ; preds = %139
  %142 = shl i32 %90, 3
  %143 = shl i32 100, %142
  %144 = add i32 %143, %91
  br label %289

145:                                              ; preds = %139
  %146 = fcmp olt double %103, %55
  br i1 %146, label %147, label %151

147:                                              ; preds = %145
  %148 = shl i32 %90, 3
  %149 = shl i32 96, %148
  %150 = add i32 %149, %91
  br label %289

151:                                              ; preds = %145
  %152 = fcmp olt double %103, %56
  br i1 %152, label %153, label %157

153:                                              ; preds = %151
  %154 = shl i32 %90, 3
  %155 = shl i32 92, %154
  %156 = add i32 %155, %91
  br label %289

157:                                              ; preds = %151
  %158 = fcmp olt double %103, %57
  br i1 %158, label %159, label %163

159:                                              ; preds = %157
  %160 = shl i32 %90, 3
  %161 = shl i32 88, %160
  %162 = add i32 %161, %91
  br label %289

163:                                              ; preds = %157
  %164 = fcmp olt double %103, %58
  br i1 %164, label %165, label %169

165:                                              ; preds = %163
  %166 = shl i32 %90, 3
  %167 = shl i32 84, %166
  %168 = add i32 %167, %91
  br label %289

169:                                              ; preds = %163
  %170 = fcmp olt double %103, %59
  br i1 %170, label %171, label %175

171:                                              ; preds = %169
  %172 = shl i32 %90, 3
  %173 = shl i32 80, %172
  %174 = add i32 %173, %91
  br label %289

175:                                              ; preds = %169
  %176 = fcmp olt double %103, %60
  br i1 %176, label %177, label %181

177:                                              ; preds = %175
  %178 = shl i32 %90, 3
  %179 = shl i32 76, %178
  %180 = add i32 %179, %91
  br label %289

181:                                              ; preds = %175
  %182 = fcmp olt double %103, %61
  br i1 %182, label %183, label %187

183:                                              ; preds = %181
  %184 = shl i32 %90, 3
  %185 = shl i32 72, %184
  %186 = add i32 %185, %91
  br label %289

187:                                              ; preds = %181
  %188 = fcmp olt double %103, %62
  br i1 %188, label %189, label %193

189:                                              ; preds = %187
  %190 = shl i32 %90, 3
  %191 = shl i32 68, %190
  %192 = add i32 %191, %91
  br label %289

193:                                              ; preds = %187
  %194 = fcmp olt double %103, %63
  br i1 %194, label %195, label %199

195:                                              ; preds = %193
  %196 = shl i32 %90, 3
  %197 = shl i32 64, %196
  %198 = add i32 %197, %91
  br label %289

199:                                              ; preds = %193
  %200 = fcmp olt double %103, %64
  br i1 %200, label %201, label %205

201:                                              ; preds = %199
  %202 = shl i32 %90, 3
  %203 = shl i32 60, %202
  %204 = add i32 %203, %91
  br label %289

205:                                              ; preds = %199
  %206 = fcmp olt double %103, %65
  br i1 %206, label %207, label %211

207:                                              ; preds = %205
  %208 = shl i32 %90, 3
  %209 = shl i32 56, %208
  %210 = add i32 %209, %91
  br label %289

211:                                              ; preds = %205
  %212 = fcmp olt double %103, %66
  br i1 %212, label %213, label %217

213:                                              ; preds = %211
  %214 = shl i32 %90, 3
  %215 = shl i32 52, %214
  %216 = add i32 %215, %91
  br label %289

217:                                              ; preds = %211
  %218 = fcmp olt double %103, %67
  br i1 %218, label %219, label %223

219:                                              ; preds = %217
  %220 = shl i32 %90, 3
  %221 = shl i32 48, %220
  %222 = add i32 %221, %91
  br label %289

223:                                              ; preds = %217
  %224 = fcmp olt double %103, %68
  br i1 %224, label %225, label %229

225:                                              ; preds = %223
  %226 = shl i32 %90, 3
  %227 = shl i32 44, %226
  %228 = add i32 %227, %91
  br label %289

229:                                              ; preds = %223
  %230 = fcmp olt double %103, %69
  br i1 %230, label %231, label %235

231:                                              ; preds = %229
  %232 = shl i32 %90, 3
  %233 = shl i32 40, %232
  %234 = add i32 %233, %91
  br label %289

235:                                              ; preds = %229
  %236 = fcmp olt double %103, %70
  br i1 %236, label %237, label %241

237:                                              ; preds = %235
  %238 = shl i32 %90, 3
  %239 = shl i32 36, %238
  %240 = add i32 %239, %91
  br label %289

241:                                              ; preds = %235
  %242 = fcmp olt double %103, %71
  br i1 %242, label %243, label %247

243:                                              ; preds = %241
  %244 = shl i32 %90, 3
  %245 = shl i32 32, %244
  %246 = add i32 %245, %91
  br label %289

247:                                              ; preds = %241
  %248 = fcmp olt double %103, %72
  br i1 %248, label %249, label %253

249:                                              ; preds = %247
  %250 = shl i32 %90, 3
  %251 = shl i32 28, %250
  %252 = add i32 %251, %91
  br label %289

253:                                              ; preds = %247
  %254 = fcmp olt double %103, %73
  br i1 %254, label %255, label %259

255:                                              ; preds = %253
  %256 = shl i32 %90, 3
  %257 = shl i32 24, %256
  %258 = add i32 %257, %91
  br label %289

259:                                              ; preds = %253
  %260 = fcmp olt double %103, %74
  br i1 %260, label %261, label %265

261:                                              ; preds = %259
  %262 = shl i32 %90, 3
  %263 = shl i32 20, %262
  %264 = add i32 %263, %91
  br label %289

265:                                              ; preds = %259
  %266 = fcmp olt double %103, %75
  br i1 %266, label %267, label %271

267:                                              ; preds = %265
  %268 = shl i32 %90, 3
  %269 = shl i32 16, %268
  %270 = add i32 %269, %91
  br label %289

271:                                              ; preds = %265
  %272 = fcmp olt double %103, %76
  br i1 %272, label %273, label %277

273:                                              ; preds = %271
  %274 = shl i32 %90, 3
  %275 = shl i32 12, %274
  %276 = add i32 %275, %91
  br label %289

277:                                              ; preds = %271
  %278 = fcmp olt double %103, %77
  br i1 %278, label %279, label %283

279:                                              ; preds = %277
  %280 = shl i32 %90, 3
  %281 = shl i32 8, %280
  %282 = add i32 %281, %91
  br label %289

283:                                              ; preds = %277
  %284 = fcmp olt double %103, %78
  br i1 %284, label %285, label %289

285:                                              ; preds = %283
  %286 = shl i32 %90, 3
  %287 = shl i32 4, %286
  %288 = add i32 %287, %91
  br label %289

289:                                              ; preds = %283, %105, %117, %129, %141, %153, %165, %177, %189, %201, %213, %225, %237, %249, %261, %273, %285, %279, %267, %255, %243, %231, %219, %207, %195, %183, %171, %159, %147, %135, %123, %111
  %290 = phi i32 [ %108, %105 ], [ %114, %111 ], [ %120, %117 ], [ %126, %123 ], [ %132, %129 ], [ %138, %135 ], [ %144, %141 ], [ %150, %147 ], [ %156, %153 ], [ %162, %159 ], [ %168, %165 ], [ %174, %171 ], [ %180, %177 ], [ %186, %183 ], [ %192, %189 ], [ %198, %195 ], [ %204, %201 ], [ %210, %207 ], [ %216, %213 ], [ %222, %219 ], [ %228, %225 ], [ %234, %231 ], [ %240, %237 ], [ %246, %243 ], [ %252, %249 ], [ %258, %255 ], [ %264, %261 ], [ %270, %267 ], [ %276, %273 ], [ %282, %279 ], [ %288, %285 ], [ %91, %283 ]
  %291 = add nuw nsw i32 %90, 1
  %292 = icmp eq i32 %291, 4
  br i1 %292, label %82, label %89, !llvm.loop !25
}

attributes #0 = { convergent norecurse nounwind mustprogress "amdgpu-flat-work-group-size"="1,256" "amdgpu-implicitarg-num-bytes"="56" "amdgpu-unsafe-fp-atomics"="true" "disable-tail-calls"="false" "frame-pointer"="none" "less-precise-fpmad"="false" "min-legal-vector-width"="0" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="gfx906" "target-features"="+16-bit-insts,+ci-insts,+dl-insts,+dot1-insts,+dot2-insts,+dpp,+flat-address-space,+gfx8-insts,+gfx9-insts,+s-memrealtime" "uniform-work-group-size"="true" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nounwind readnone speculatable willreturn }
attributes #2 = { convergent nounwind willreturn }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 1}
!2 = !{!"Ubuntu clang version 12.0.1-19ubuntu3"}
!3 = !{i32 0, i32 1024}
!4 = !{!5, !5, i64 0}
!5 = !{!"int", !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C++ TBAA"}
!8 = distinct !{!8, !9, !10}
!9 = !{!"llvm.loop.mustprogress"}
!10 = !{!"llvm.loop.unroll.disable"}
!11 = !{!12, !12, i64 0}
!12 = !{!"double", !6, i64 0}
!13 = !{!14, !12, i64 0}
!14 = !{!"_ZTS7double3", !12, i64 0, !12, i64 8, !12, i64 16}
!15 = !{!14, !12, i64 8}
!16 = !{!14, !12, i64 16}
!17 = distinct !{!17, !9, !10}
!18 = !{i64 0, i64 8, !11, i64 8, i64 8, !11, i64 16, i64 8, !11}
!19 = !{i64 0, i64 8, !11, i64 8, i64 8, !11}
!20 = !{i64 0, i64 8, !11}
!21 = distinct !{!21, !9, !10}
!22 = distinct !{!22, !9, !10}
!23 = distinct !{!23, !9, !10}
!24 = distinct !{!24, !9, !10}
!25 = distinct !{!25, !9, !10}
